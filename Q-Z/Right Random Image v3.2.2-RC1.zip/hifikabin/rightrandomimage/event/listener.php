<?php
/**
*
* @package phpBB Extension - Right Random Image
* @copyright (c) 2015 - HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\rightrandomimage\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\db\driver\driver_interface */
	protected $db;

	/** @var \phpbb\config\config */
	protected $config;

	/**
	* Constructor
	*
	* @param \phpbb\template\template			$template
	* @param \phpbb\db\driver\driver_interface	$db
	* @param string								$rightrandomimage_table
	* @param \phpbb\config\config				$config
	*/

	public function __construct(\phpbb\template\template $template, \phpbb\user $user, \phpbb\db\driver\driver_interface $db,
	\phpbb\request\request $request, $rightrandomimage_table, \phpbb\config\config $config)
	{
		$this->template = $template;
		$this->db = $db;
		$this->request = $request;
		$this->rightrandomimage_table = $rightrandomimage_table;
		$this->config = $config;
	}

	public static function getSubscribedEvents()
	{
		return array(
			'core.user_setup'	=> 'load_language_on_setup',
			'core.page_header'	=> 'rightrandomimage',
		);
	}

	public function load_language_on_setup($event)
	{
		$lang_set_ext		= $event['lang_set_ext'];
		$lang_set_ext[]		= array(
			'ext_name'		=> 'hifikabin/rightrandomimage',
			'lang_set'		=> 'common',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}

	public function rightrandomimage($event)
	{
		$this->template->assign_vars(array(
			'RIGHTRANDOMIMAGE_ENABLE'		=> $this->config['rightrandomimage_enable'],
			'RIGHTRANDOMIMAGE_SEARCH'		=> $this->config['rightrandomimage_search'],
			'RIGHTRANDOMIMAGE_OPEN'			=> $this->config['rightrandomimage_open'] ? true : false,	
			'RIGHTRANDOMIMAGE_RESIZE'		=> $this->config['rightrandomimage_resize'],
			'S_IN_SEARCH' 					=> $this->config['rightrandomimage_enable'] ? true : false,	
			));

		$sql = 'SELECT * 
		FROM '. $this->rightrandomimage_table;
		$result	 = $this->db->sql_query($sql,86400);

		if ( isset($this->config['rightrandomimage_enable']) && $this->config['rightrandomimage_enable'] )
		{
			while ($row = $this->db->sql_fetchrow($result))
			{
			if (!empty($row['rri_image']))
				{
				$this->template->assign_block_vars('rri_images', array(
					'RRI_IMAGE'			=> $row['rri_image'],
					'RRI_LINK'			=> $row['rri_link'],
					));
				}
			}
			$this->db->sql_freeresult($result);
		}
	}
}
