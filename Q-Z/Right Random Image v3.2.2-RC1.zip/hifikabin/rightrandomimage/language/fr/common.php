<?php
/**
 *
 * Right Random Image. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 HiFiKabin
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_RIGHTRANDOMIMAGE_TITLE'			=> 'Paramètres',
	'RIGHTRANDOMIMAGE_SAVED'				=> 'Les paramètres ont été sauvegardés avec succès !.',
	'RIGHTRANDOMIMAGE_CONFIG_SET'			=> 'Configuration',

	'LOG_RIGHTRANDOMIMAGE_SAVE'				=> 'Paramètres de l’extension « Right Random Image » mis à jour.',

	'RIGHTRANDOMIMAGE_ENABLE'				=> 'Activer l’affichage des images aléatoires',
	'RIGHTRANDOMIMAGE_ENABLE_EXPLAIN'		=> 'Permet d’activer l’extension « Right Random Image ».',

	'RIGHTRANDOMIMAGE_SEARCH'				=> 'Emplacement de la recherche',
	'RIGHTRANDOMIMAGE_SEARCH_EXPLAIN'		=> 'Permet de modifier l’emplacement de la recherche du forum dans la barre de navigation lorsque l’affichage de l’image aléatoire de l’entête est activé.',

	'RIGHTRANDOMIMAGE_RESIZE'				=> 'Dimensions des images aléatoires',
	'RIGHTRANDOMIMAGE_RESIZE_EXPLAIN'		=> 'Permet de modifier les dimensions maximales des images aléatoires, aussi, merci de considérer que des images plus grandes pourraient modifier la mise en plage de l’entête du forum.',

	'RIGHTRANDOMIMAGE_OPEN'					=> 'Comportement du clic sur l’image',
	'RIGHTRANDOMIMAGE_OPEN_EXPLAIN'			=> 'Permet d’ouvrir le lien dans un nouvel onglet/fenêtre lors du clic sur l’image.',
	
	'RIGHTRANDOMIMAGE_INSTRUCTIONS'			=> 'Instructions',

	'RIGHTRANDOMIMAGE_RANDOM'				=> 'Mode aléatoire',
	'RIGHTRANDOMIMAGE_RANDOM_INFO'			=> 'Le mode aléatoire permet d’afficher une image aléatoirement lors du chargement de la page. Il n’y a pas d’historique des images précédemment chargées, ainsi il y aura des fois où la même image sera chargée plusieurs fois de suite.',
	'RIGHTRANDOMIMAGE_IMAGE_INFO'			=> 'Les images sont stockées sur le forum ou de manière externe.</br> Ainsi, il est nécessaire de charger l’adresse URL complète vers l’image dans le champ « Adresse URL complète de l’image ».</br>Si ce champ est laissé vide l’image associée et son lien seront supprimés.',
	'RIGHTRANDOMIMAGE_LINK_INFO'			=> 'Saisir l’adresse URL complète de la page souhaitée pour la rattacher à l’image.</br>Si ce champ est laissé vide un clic sur l’image redirigera l’utilisateur vers la page de l’index du forum.',

	'RIGHTRANDOMIMAGE_NOTE'					=> 'Notes',
	'RIGHTRANDOMIMAGE_NOTE_INFO'			=> 'L’affichage des images aléatoires est masqué sur les petits écrans.<br>Il est possible d’ajouter autant d’images que souhaités.</br>Pour un meilleur résultat toutes les images doivent posséder des dimensions identiques.',

	'RIGHTRANDOMIMAGE_IMAGE'				=> 'Adresse URL complète de l’image',
	'RIGHTRANDOMIMAGE_LINK'					=> 'Adresse URL du lien associé à l’image',

	'RIGHTRANDOMIMAGE_MORE_IMAGES'			=> 'Ajouter une autre image',
	'RIGHTRSANDOMIMAGE_REQUIRE_3.1.4'		=> 'Cette extension nécessite phpBB 3.1.4 à minima et n’est pas compatible sous phpBB 3.2.x.',
	'RIGHTRSANDOMIMAGE_REQUIRE_3.2.0'		=> 'Cette extension est dédiée à phpBB 3.2.x et n’est pas compatible avec phpBB 3.1.x.',
));

