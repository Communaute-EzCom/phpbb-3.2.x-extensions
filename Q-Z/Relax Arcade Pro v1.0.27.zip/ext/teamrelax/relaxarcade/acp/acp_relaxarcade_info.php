<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\acp;

class acp_relaxarcade_info
{
	function module()
	{
		return array(
			'filename'	=> '\teamrelax\relaxarcade\acp\acp_relaxarcade_module',
			'title'		=> 'ACP_CAT_RELAXARCADE',
			'modes'		=> array(
				'settings' => array(
					'title'	=> 'ACP_RELAXARCADE_SETTINGS',
					'auth'	=> 'ext_teamrelax/relaxarcade && acl_a_board',
					'cat'	=> array('ACP_CAT_RELAXARCADE'),
				),
				'manage' => array(
					'title'	=> 'ACP_CATEGORY_MANAGE',
					'auth'	=> 'ext_teamrelax/relaxarcade && acl_a_board',
					'cat'	=> array('ACP_CAT_RELAXARCADE'),
				),
				'setting_category' => array(
					'title'	=> 'ACP_SETTING_CATEGORY',
					'auth'	=> 'ext_teamrelax/relaxarcade && acl_a_board',
					'cat'	=> array('ACP_CAT_RELAXARCADE'),
				),
				'setting_groups' => array(
					'title'	=> 'ACP_SETTING_GROUPS',
					'auth'	=> 'ext_teamrelax/relaxarcade && acl_a_board',
					'cat'	=> array('ACP_CAT_RELAXARCADE'),
				),
				'install' => array(
					'title'	=> 'ACP_GAMES_INSTALL',
					'auth'	=> 'ext_teamrelax/relaxarcade && acl_a_board',
					'cat'	=> array('ACP_CAT_RELAXARCADE'),
				),
				'cheat' => array(
					'title'	=> 'ACP_CHEATERS_MANAGE',
					'auth'	=> 'ext_teamrelax/relaxarcade && acl_a_board',
					'cat'	=> array('ACP_CAT_RELAXARCADE'),
				),
				'acp_championnat' => array(
					'title'	=> 'ACP_CHAMPIONNAT_MANAGE',
					'auth'	=> 'ext_teamrelax/relaxarcade && acl_a_board',
					'cat'	=> array('ACP_CAT_RELAXARCADE'),
				),
				'acp_defis' => array(
					'title'	=> 'ACP_DEFIS_MANAGE',
					'auth'	=> 'ext_teamrelax/relaxarcade && acl_a_board',
					'cat'	=> array('ACP_CAT_RELAXARCADE'),
				),
			),
		);
	}
}
