<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class camembert
{
	/** @var config */
	protected $config;
	
	/** @var helper */
	protected $helper;	

	/** @var db_interface */
	protected $db;


	/** @var request_interface */
	protected $request;
	
	/** @var template */
	protected $template;

	/** @var user */
	protected $user;
	
	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->config 		= $config;
		$this->helper 		= $helper;
		$this->db 			= $db;
		$this->request 		= $request;
		$this->template 	= $template;		
		$this->user 		= $user;
		$this->root_path 	= $root_path;
		$this->php_ext 		= $php_ext;
	}

	public function handle()
	{
		
			$group_id	= $this->request->variable('g', 0);
			$ra_cat_id	= $this->request->variable('c', 0);
			$mode = $this->request->variable('mode', '');
			
					// Switch the mode
		switch ($mode)
		{
			
			case 'cat':			
			$this->template->assign_vars(array(  'IMGCABEMBERT' => '<img src="'.$this->helper->route('teamrelax_relaxarcade_page_cabembert',  array('mode' =>'cat','g' => $group_id,'c' => $ra_cat_id)).'">'    ));       
			break;

			case 'news':
			$this->template->assign_vars(array(  'IMGCABEMBERT' => '<img src="'.$this->helper->route('teamrelax_relaxarcade_page_cabembert',  array('mode' =>'news','g' => $group_id)).'">'    ));       
		
			break;
		}	
			
			return $this->helper->render('camembert.html');

	
	}
	


	
}

