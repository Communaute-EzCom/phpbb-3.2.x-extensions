<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_games_new
{
	/** @var config */
	protected $config;
	
	/** @var helper */
	protected $helper;	

	/** @var db_interface */
	protected $db;

	/** @var pagination */
	protected $pagination;

	/** @var request_interface */
	protected $request;
	
	/** @var template */
	protected $template;

	/** @var user */
	protected $user;
	
	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\pagination $pagination,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->config 		= $config;
		$this->helper 		= $helper;
		$this->db 			= $db;
		$this->pagination	= $pagination;
		$this->request 		= $request;
		$this->template 	= $template;		
		$this->user 		= $user;
		$this->root_path 	= $root_path;
		$this->php_ext 		= $php_ext;
	}

	public function handle()
	{
		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);
		include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);

		
		// Arcade fermée
		// Accès fondateur quand même autorisé
		if ($this->config['arcade_close'] && $this->user->data['user_type'] != USER_FOUNDER)
		{
			$message = $this->user->lang('INFO_ARCADE_CLOSE') . '<br /><br />' . $this->user->lang('CLICK_RETURN_INDEX', '<a href="' . append_sid("index." . $this->php_ext) . '">', '</a> ');
			trigger_error($message);
		}

		//Récupération des valeurs
		$arcade_catid = $this->request->variable('cid', 0);
		$start = $this->request->variable('start', 0);
		$start = ($start < 0) ? 0 : $start;
		$mode = $this->request->variable('mode', '');

		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);

		$liste_cat = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);
		$nbcat = count($liste_cat);

		if (!$nbcat)
		{
			trigger_error($this->user->lang('RA_NO_CAT'));
		}

		//
		// Recherche des catégories visibles pour l'utilisateur
		//
		$is_auth_ary = arcade_auth(AUTH_VIEW, AUTH_LIST_ALL, $liste_cat);
		$j = 0;
		$liste_cat_auth = array();
		for ($i = 0; $i < $nbcat; $i++)
		{
			$arcade_cid = (int)$liste_cat[$i]['ra_cat_id'];
			if ($is_auth_ary[$arcade_cid]['ra_cat_auth_view'])
			{
				$liste_cat_auth[$j] = $liste_cat[$i];
				$liste_cat_id_auth[$j] = $liste_cat[$i]['ra_cat_id'];
				$j++;
			}
		}
		$nbcat_auth = count($liste_cat_auth);

		// Catagorie activée ?
		// Accès fondateur quand même autorisé
		if (!$nbcat_auth > 0)
		{
			trigger_error($this->user->lang('SORRY_ARCADE_CAT_NOACCESS'));
		}

		$arcade_catid = ($arcade_catid > 0) ? $arcade_catid : intval($liste_cat_auth[0]['ra_cat_id']);

		for ($i = 0; $i < $nbcat; $i++)
		{
			if ($arcade_catid === intval($liste_cat[$i]['ra_cat_id']))
			{
				if (intval($liste_cat[$i]['ra_cat_active']) === 0 && $this->user->data['user_type'] != USER_FOUNDER)
				{
					$message = $this->user->lang('INFO_ARCADECAT_NOT_ACTIVATED') . '<br /><br />' . $this->user->lang('CLICK_RETURN_INDEX', '<a href="' . append_sid("index." . $this->php_ext) . '">', '</a> ');
					trigger_error($message);
				}
			}
		}

		
		$sql = 'SELECT user_id
			FROM ' . RA_BOOKMARKS_TABLE . '
			WHERE user_id = ' . (int)$this->user->data['user_id'];
			$result = $this->db->sql_query($sql);
			$favories = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);		
		
		$this->template->assign_vars(array(
			'L_LIST_CAT' 	=> $this->user->lang('LIST_ARCADE_CAT'),
				'FAV_GAMES' => ($favories) ? true : false,
			'IS_RELAX' =>true,
			'IS_RELAXINDEX' =>false,
			'L_TOP_PLAYERS' => $this->user->lang('ARCADE_BEST_PLAYERS'),
			'U_TOP_PLAYERS' => $this->helper->route('teamrelax_relaxarcade_page_topplayers'),
			// deb modif pour l'affichage des derniers jeux
			'U_NEW_GAMES' => $this->helper->route('teamrelax_relaxarcade_page_games_new'),
			'L_NEW_GAMES' => $this->user->lang('NEW_GAMES'),
			// fin modif pour l'affichage des derniers jeux
			'L_FAV_GAMES'   => $this->user->lang('RA_FAV_GAMES'),
			'U_FAV_GAMES'   => $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark')),
			//'U_SEARCH_GAMES'   => append_sid('arcade_search.'.$phpEx),
			'L_RECHERCHER_JEU' => $this->user->lang('RA_SEARCH'),
			)
		);

		//
		// Start auth check
		//
		if (!$is_auth_ary[$arcade_catid]['ra_cat_auth_view'])
		{
			trigger_error(sprintf($this->user->lang('SORRY_ARCADE_CAT_AUTH_VIEW'), $is_auth_ary[$arcade_catid]['ra_cat_auth_view_type']));
		}
		//
		// End auth check
		//
		// Créer une condition sql à partir du tableau liste_cat_auth
		$liste_sql_cat_auth = '';
		if ($nbcat_auth > 0)
		{
			$liste_sql_cat_auth = '(';
			for ($i = 0; $i < $nbcat_auth; $i++)
			{
				if ($i == 0)
				{
					$liste_sql_cat_auth .= (int) $liste_cat_auth[$i]['ra_cat_id'];
				}
				else
				{
					$liste_sql_cat_auth .= ',' . (int) $liste_cat_auth[$i]['ra_cat_id'];
				}
			}
			$liste_sql_cat_auth .= ')';
		}
		unset($liste_cat_auth);
		$topultime =array();
		// Meilleur de score de tous les temps
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.ra_cat_id, g.us_score_game, g.us_user_id, g.us_score_date, u.username, u.user_id, u.user_colour',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'g.us_user_id = u.user_id'
				)
			),
			'WHERE' => 'g.us_score_game AND g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'ORDER_BY'	=> 'g.us_score_date DESC',
		);
		$result = $this->db->sql_query($this->db->sql_build_query('SELECT', $sql_array));	
		while( $row = $this->db->sql_fetchrow($result) )
		{	
			$topultime[$row['game_id']]['us_user_id'] = get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']);
		}
		
		// Affichage de la liste de jeux
		// deb modif pour l'affichage des derniers jeux
		$games_per_page = $this->config['games_per_page'] ;
		
		$order_by = 'game_id DESC';

		//Liste des jeux avec catégories
		$sql_array = array(
			'SELECT'	=> 'c.* , g.* , u.username , u.user_id, u.user_colour , s.score_game , s.score_date , a.gamestat_highscore ,
							a.gamestat_highdate , a.gamestat_set, a.gamestat_rating , a.gamestat_rating_set, r.game_rating_val, b.game_id as fav',
			'FROM'		=> array(
				RA_CAT_TABLE	=> 'c',
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_GAMESTAT_TABLE => 'a'),
					'ON'	=> 'g.game_id = a.game_id'
				),
				array(
					'FROM'	=> array(RA_GAME_RATING_TABLE => 'r'),
					'ON'	=> 'g.game_id = r.game_id
								AND r.user_id = ' . (int) $this->user->data['user_id']
				),
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's'),
					'ON'	=> 'g.game_id = s.game_id
								AND s.user_id = ' . (int) $this->user->data['user_id']
				),
				array(
					'FROM'	=> array(RA_BOOKMARKS_TABLE => 'b'),
					'ON'	=> 'g.game_id = b.game_id
								AND b.user_id = ' . (int) $this->user->data['user_id']
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'a.gamestat_user_id = u.user_id'
				),
			),
			// deb modif pour l'affichage des derniers jeux
			'WHERE'		=>	'c.ra_cat_id = g.ra_cat_id AND g.ra_cat_id IN ' . $liste_sql_cat_auth,
			// fin modif pour l'affichage des derniers jeux
			'ORDER_BY'	=> $order_by
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $games_per_page, $start);


		
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

		while (false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$gamename = $row['game_name'];
			$gamenote = is_null($row['gamestat_rating']) ? 0 : $row['gamestat_rating'];
			$username = get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']);
			if($row['game_cont'] == 0 || !$row['game_cont']){
					$bulle_info = $this->user->lang['CONTROLES_INCONNUS'];
				}elseif($row['game_cont'] == 1){
					$bulle_info = $this->user->lang['CLAVIER_UNIQUEMENT'];
				}elseif($row['game_cont'] == 2){
					$bulle_info = $this->user->lang['SOURIS_UNIQUEMENT'];
				}elseif($row['game_cont'] == 3){
					$bulle_info = $this->user->lang['CLAVIER_SOURIS'];
				}else{
					$bulle_info = '';
				}
				if($row['game_html5'] == 0 || !$row['game_html5']){
			$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif($row['game_html5'] == 1){
			$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$info = '';
			}
			$this->template->assign_block_vars('gamerow', array(
				'GAMENAME' => $gamename,
				'GAME_TYPE'	=>$info,
				'GAMEPIC' => $row['game_pic'] != '' ? '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '"><img src="' . generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'] . '" width="80px" height="60px" alt="' . $gamename . '" title="' . $gamename . '" /></a>' : '',
				'GAMESET' => $row['gamestat_set'] != 0 ? ($this->user->lang('GAME_NBSET') . ' : ' . $row['gamestat_set']) : '',
				'GAMEDESC' => htmlspecialchars_decode($row['game_desc']),
				'GAMECONT' => '<img src="' . generate_board_url() . '/arcade/pics_controle/' . $row['game_cont'] . '.png" title="' . $bulle_info . '" alt="' . $bulle_info . '" />',
				'HIGHSCORE' =>($row['gamestat_highscore']== 0) ? $this->user->lang('NO_RECORD') : $row['gamestat_highscore']+ 0,
				'YOURHIGHSCORE' =>($row['score_game']== 0) ? '<br/>'.$this->user->lang('NO_SCORE') : ($row['user_id'] == $this->user->data['user_id'] ? '<img src="' . $ra_theme_basepath . '/images/couronne.png" alt="first" /><br/>' : '') . ($row['score_game'] + 0),
				'ULHIGHSCORE' =>($row['us_score_game']== 0) ? $this->user->lang('NO_RECORD') : $row['us_score_game'] + 0,
				'ULHIGHUSER' => ($row['us_user_id'] != 0) ? '(' . $topultime[$row['game_id']]['us_user_id'] . ')' : '',
				'ULDATEHIGH' => ($row['us_score_date'] == 0) ? '' :  date("d/m/Y H:i",$row['us_score_date']).'<br />'.'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $row['game_id'])) . '">' . $this->user->lang('SEE_SCORES') . '</a>',
				'GAMENOTE' => $gamenote == 0 ? $this->user->lang('NO_GAME_NOTE') : $gamenote + 0 . '/10',
				'GAMERATING' => $gamenote * 10,
				'L_GAME_NBVOTE' => $gamenote == 0 ? '' : ($row['gamestat_rating_set'] > 1 ? $this->user->lang('GAMENBVOTES') . ']' : $this->user->lang('GAMEVOTE') . ']'),
				'GAME_NBVOTE' => $gamenote == 0 ? '' : '[' . $row['gamestat_rating_set'],
				'HIGHUSER' => $row['user_id'] != 0 ? '(' . $username . ')' : '' ,
				'GAMEID' => $row['game_id'],
				'DISPLAY_POS' =>($row['score_game']== 0)  ?  '' : $this->display_pos($row['game_id'],$row['game_scoretype']) ,
				'U_MOD' => '<a href="' . append_sid($this->root_path . 'adm/index.' . $this->php_ext . '?i=-teamrelax-relaxarcade-acp-acp_relaxarcade_module&amp;mode=manage&amp;action=game&amp;gaction=gameedit&amp;c=' . $arcade_catid . '&amp;gid=' . $row['game_id'] . '&amp;sid=' . $this->user->data["session_id"]) . '">' . $this->user->lang('MOD_SCORE') . '</a>',
				'GAMEFPS' => $row['game_fps'] != 0 ? $this->user->lang('GAME_FPS') . ' : ' . $row['game_fps'] : '',
				'GAMESIZE' => $row['game_size'] != 0 ? $this->user->lang('GAME_SIZE') . ' : ' . size_hum_read($row['game_size']) : '',
				'DATEHIGH' => ($row['gamestat_highdate'] == 0) ? '' : $this->user->format_date($row['gamestat_highdate']).'<br />'.'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $row['game_id'])) . '">' . $this->user->lang('SEE_SCORES') . '</a>',
				'YOURDATEHIGH' => ($row['score_date'] == 0) ? '' : $this->user->format_date($row['score_date']),
				'IMGRATING' => !is_null($row['game_rating_val']) ? '<img src="' . $ra_theme_basepath . '/images/arcade_rating_check.png" title = "' . $this->user->lang('GAME_YOUR_NOTE') . ' : ' . $row['game_rating_val'] . '" alt="'. $this->user->lang('GAME_YOUR_NOTE') . ' : ' . $row['game_rating_val'] . '" "/>' : '',
				'IMGBOOKMARK' => is_null($row['fav']) ? '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark', 'cid' => $arcade_catid, 'start' => $start, 'gid' => $row['game_id'])) . '"><img src="' . $ra_theme_basepath . '/images/ra_favoris.png" title="' . $this->user->lang('RA_FAV_ADD_GAME') . '" alt="'. $this->user->lang('RA_FAV_ADD_GAME') . '" /></a>' : '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark', 'cid' => $arcade_catid, 'start' => $start, 'gid' => $row['game_id'])) . '"><img src="' . $ra_theme_basepath . '/images/ra_fav_del.png" title="' . $this->user->lang('RA_FAV_DEL_GAME') . '" alt="'. $this->user->lang('RA_FAV_DEL_GAME') . '" /></a>',
				'GAMELINK' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])) . '">' . $row['game_name'] . '</a> ',
							));
			  
			
			
		}
		$this->db->sql_freeresult($result);

			 // nombre de jeux pagination // $liste_sql_cat_auth a tester //
			$sql = 'SELECT COUNT(g.game_id) AS total_games
				FROM (' . RA_GAMES_TABLE. ' g)
				WHERE g.ra_cat_id IN ' . $liste_sql_cat_auth .' 
				ORDER BY game_id';
				$result = $this->db->sql_query($sql);
				$totalgames = (int) $this->db->sql_fetchfield('total_games');
				$this->db->sql_freeresult($result);
				$total_games  = ($totalgames) ? $totalgames : 1;
		
		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME' => $this->user->lang('ARCADE_PAGE'),
			'U_VIEW_FORUM' => $this->helper->route('teamrelax_relaxarcade_page_list'),
		));

		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME' =>$total_games.'&nbsp;'.$this->user->lang('LAST_GAMES'),
			'U_VIEW_FORUM' =>$this->helper->route('teamrelax_relaxarcade_page_games_new'),
		));

		$this->pagination->generate_template_pagination($this->helper->route('teamrelax_relaxarcade_page_games_new', array('mode' => $mode)), 'pagination', 'start', $total_games, $games_per_page, $start, true);

		$this->template->assign_vars(array(
			'L_CAT' => $total_games,
			'TOTAL_GAMES' => $total_games,			
			'PAGE_NUMBER' 	=>$this->pagination->get_on_page($total_games, $games_per_page, $start), 
			'L_GAME' => $this->user->lang('GAMES'),
			// fin modif pour l'affichage des derniers jeux
			'L_HIGHSCORE' => $this->user->lang('ARCADE_HIGHSCORE'),
			'L_YOURSCORE' => $this->user->lang('ARCADE_YOURSCORE'),
			'L_DESC' => $this->user->lang('DESC_GAME'),
			'L_NOTE' => $this->user->lang('GAME_NOTE'),
			'L_LIST_GAMES' => $this->user->lang('arcade_new'),
			'LAST_RECORDS' => $this->user->lang('ARCADE_LAST_RECORDS'),
			'5_LAST_RECORDS' => $this->user->lang('FIVE_LAST_RECORDS'),
			'5_LAST_SCORES' => $this->user->lang('FIVE_LAST_SCORES'),
			'5_GAMES_POP' => $this->user->lang('FIVE_GAMES_POP'),
			'BY' => $this->user->lang('ARCADE_BY'),
			'ON' => $this->user->lang('ARCADE_ON'),
			'PARTY' => $this->user->lang('PARTY'),
			'L_ARCADE_PLAYING' => $this->user->lang('ARCADEPLAYING'),
		));
		
		
		
		// Affichage du qui joue
		$tab_player = arcade_view_playing($is_auth_ary);
		if ($tab_player !== false && isset($tab_player[0]))
		{
			$nb_players = count($tab_player);
			for ($i = 0; $i < $nb_players; $i++)
			{
				$is_admin = $this->user->data['session_admin'] && $this->user->data['is_registered'] && $this->user->data['user_id'] != ANONYMOUS;
				if ($tab_player[$i]['user_allow_viewonline'] || $is_admin)
				{
					$this->template->assign_block_vars('arcadeplaying_row', array(
						'GAMENAME' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $tab_player[$i]['gid'])) . '">' . $tab_player[$i]['gamename'] . '</a>' . ' : ',
						'PLAYERLIST' => $tab_player[$i]['playerlist'],
						'GAME_PIC' => isset($tab_player['game_pic']) ? (generate_board_url() . '/arcade/games/' . nom_sans_ext($tab_player['game_pic']) . '/pics/' . $tab_player['game_pic']) : '',
					));
				}
			}
		}
		else
		{
			$this->template->assign_block_vars('arcadeplaying_row', array(
				'GAMENAME' => $this->user->lang('ARCADE_NOPLAYING'),
			));
		}

		return $this->helper->render('arcade_games_new_body.html', $this->user->lang('ARCADE_PAGE'));
	}
	
		function display_pos($gid,$highscore_type)
	{
	
	$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';

	$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.score_game, s1.score_date, u.username, u.user_id, u.user_colour',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($highscore_type == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id '
				)
			),
			'WHERE'		=> 's1.game_id = ' . $gid .' and s1.user_id = '.(int) $this->user->data['user_id'] ,
			'GROUP_BY'	=> 's1.user_id ',
			'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$position = '';
		while ($row = $this->db->sql_fetchrow($result))
		{
			$position = $row['position'];
			
		}
		$this->db->sql_freeresult($result);

		$img = '<img src="' . $ra_theme_basepath . '/images/pos.png" alt="'.$this->user->lang['ARCADE_POSITION'].'" />';
		if($position == 1)$position = $img." <b>".$position."</b>".$this->user->lang['RA_POS'];
		elseif($position == 2)$position = $img." <b>".$position."</b>".$this->user->lang['RA_POS_D'];
		elseif($position == 3)$position = $img." <b>".$position."</b>".$this->user->lang['RA_POS_T'];
		else $position = $img. " <b>".$position."</b>".$this->user->lang['RA_POS_L'];
		
		return $position;
	
	
	
	}
}
