<?php

/** 
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */
 
 namespace teamrelax\relaxarcade\controller;

class admin_championnat
{
	
	
	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\db\driver\driver_interface */
	protected $db;

	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\log\log */
	protected $log;

			/** @var \phpbb\extension\manager "Extension Manager" */
	protected $ext_manager;

	/** @var \phpbb\path_helper */
	protected $path_helper;

	/** @var string phpBB root path */
	protected $root_path;

	/** @var string php_ext */
	protected $php_ext;


	/**
	* The database tables
	*
	* @var string
	*/

	
	/**
	* Constructor
	*	
	* @param \phpbb\template\template		 			$template
	* @param \phpbb\user								$user
	* @param \phpbb\auth\auth							$auth
	* @param \phpbb\db\driver\driver_interface			$db
	* @param \phpbb\request\request		 				$request
	* @param \phpbb\config\config						$config
	* @param \phpbb\log\log					 			$log
	* @param string 									$root_path
	* @param string 									$php_ext
	*
	*/
	public function __construct(		
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\config\config $config,
		\phpbb\log\log $log,
		\phpbb\extension\manager $ext_manager,
		\phpbb\path_helper $path_helper,
		$root_path,
		$php_ext
	)
	{
		$this->template 					= $template;
		$this->user 						= $user;
		$this->auth 						= $auth;
		$this->db 							= $db;
		$this->request 						= $request;
		$this->config 						= $config;
		$this->log 							= $log;
		$this->ext_manager	 = $ext_manager;
		$this->path_helper	 = $path_helper;
		$this->root_path 					= $root_path;
		$this->php_ext 						= $php_ext;	
		$this->ext_path = $this->ext_manager->get_extension_path('teamrelax/relaxarcade', true);
		$this->ext_path_web = $this->path_helper->update_web_root_path($this->ext_path);
	}

	public function acp_championnat()
	{
			include($this->ext_path . 'arcade/includes/constants.' . $this->php_ext);


			$form_name = 'acp_championnat';
			add_form_key($form_name);
			$error = '';

		if ($this->request->is_set_post('submit'))
		{
			if (!check_form_key($form_name))
			{
				$error = $this->user->lang('FORM_INVALID');
			}
					
				
			if (empty($error) && $this->request->is_set_post('submit'))
			{
			
						$this->config->set('enable_tournoi', $this->request->variable('enable_tournoi', false));
						$this->config->set('not_classement', $this->request->variable('not_classement', false));
						$this->config->set('mc_no_equipe', $this->request->variable('mc_no_equipe', ''));		
						$this->config->set('equipe_tournoi', $this->request->variable('equipe_tournoi', ''));	
						$this->config->set('ra_last_upd_start', $this->request->variable('ra_last_upd_start', ''));	
						$this->config->set('ra_last_upd', $this->request->variable('ra_last_upd', ''));	   
						$this->config->set('active_time', $this->request->variable('active_time', false));	
						$this->config->set('ra_tournoi_text_debut',  utf8_normalize_nfc($this->request->variable('ra_tournoi_text_debut', '',true)));	 
						$this->config->set('ra_tournoi_text_fin',  utf8_normalize_nfc($this->request->variable('ra_tournoi_text_fin','',true)));	
						$this->config->set('ra_top_classement_points_category', $this->request->variable('ra_top_classement_points_category', ''));	

						
				//  news data
				if ($this->config['ra_top_classement_points_category'] && ($this->request->variable('active_time', true)) && (!empty($this->config['ra_last_upd_start'])) && (!empty($this->config['ra_last_upd'])))
				{

					
					$sqlary = array(
							'ra_cat_active'	=> 0,
							'ra_cat_submit'	=> 0,
							'ra_cat_class'	=> 0,		
					);
					
					$sql = "UPDATE " . RA_CAT_TABLE . " SET " . $this->db->sql_build_array('UPDATE', $sqlary) . "
								  WHERE ra_cat_id = ".$this->config['ra_top_classement_points_category'];
					$this->db->sql_query($sql);
					
				}
				
			
			
				
				if ($this->config['ra_top_classement_points_category'] == -1 )
				{
					

				$sql_ary = array(
							'config_value'	=> 0,
					);
					$sql = "UPDATE " . CONFIG_TABLE . " SET " . $this->db->sql_build_array('UPDATE', $sql_ary) . "
								  WHERE config_name = 'active_time'";
					$this->db->sql_query($sql);
				}
				
				
				if ($this->request->variable('active_time', true))
				{
		
				
					if (empty($this->request->variable('ra_last_upd_start', '')))
					{
						trigger_error($this->user->lang['DATE_ERROR1'] . adm_back_link($this->u_action), E_USER_WARNING);
					}
					
					if (empty($this->request->variable('ra_last_upd', '')))
					{
						trigger_error($this->user->lang['DATE_ERROR2'] . adm_back_link($this->u_action), E_USER_WARNING);
					}
				
				
				}
				
				
				$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_CHAMPIONNAT_UPDATED');
				trigger_error($this->user->lang('ARCADE_CHAMPIONNAT_UPDATED') . adm_back_link($this->u_action));
			}

		}


			$sql_array = array(
				'SELECT'	=> 'c.ra_cat_id, c.ra_cat_title, c.ra_cat_order',
					
				'FROM'		=> array(
					RA_CAT_TABLE => 'c'
				),
				'WHERE'    => 'c.ra_cat_order NOT IN (1)',	
				'ORDER_BY' => 'c.ra_cat_title',				
			);
			
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
			
			$category_list_classement = '<option value="0" '.(($this->config['ra_top_classement_points_category'] == 0) ? 'selected' : '' ).'> '.$this->user->lang('RA_DESACTIVER').'</option><option value="-1" '.(($this->config['ra_top_classement_points_category'] == -1) ? 'selected' : '' ).'>'.$this->user->lang('RA_TOUTES_CATÉGORIES').'</option>';
			
			
			while( $rowcat = $this->db->sql_fetchrow($result) )
			{	
				$category_list_classement .= '<option value="'.$rowcat['ra_cat_id'].'"'.(($this->config['ra_top_classement_points_category'] == $rowcat['ra_cat_id']) ? 'selected' : $this->config['ra_top_classement_points_category'] ).'>'.stripslashes($rowcat['ra_cat_title']).'</option>';
			}

							$this->template->assign_vars(array(
							'ENABLE_TOURNOI'	=> $this->config['enable_tournoi'],
							'STYLE_TOURNOI'	=> $this->config['not_classement'],
							'RA_MC_NO_EQUIPE'	=> $this->config['mc_no_equipe'],
							'EQUIPE_TOURNOI'	=> $this->config['equipe_tournoi'],
							'TIME_TOURNOI_START'	=> $this->config['ra_last_upd_start'],
							'TIME_TOURNOI'	=> $this->config['ra_last_upd'],
							'ACTIVE_TIME'	=> $this->config['active_time'],
							'TOURNOI_TEXT_DEBUT'	=> $this->config['ra_tournoi_text_debut'],
							'TOURNOI_TEXT_FIN'	=> $this->config['ra_tournoi_text_fin'],
							'TOP_CLASSEMENT_POINTS_CATEGORY_SELECT'	=> $category_list_classement,
							'S_CHAMPIONNAT_SETTINGS'	=>true,
					
							'U_ACTION'			=> $this->u_action,
							));
	}


		public function set_page_url($u_action)
		{
			$this->u_action = $u_action;
		}
}
