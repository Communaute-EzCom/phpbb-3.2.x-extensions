<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

 namespace teamrelax\relaxarcade\controller;

class admin_defis
{


    /** @var \phpbb\template\template */
    protected $template;

    /** @var \phpbb\user */
    protected $user;

    /** @var \phpbb\auth\auth */
    protected $auth;

    /** @var \phpbb\db\driver\driver_interface */
    protected $db;

    /** @var \phpbb\request\request */
    protected $request;

    /** @var \phpbb\config\config */
    protected $config;

    /** @var pagination */
    protected $pagination;


    /** @var \phpbb\log\log */
    protected $log;

            /** @var \phpbb\extension\manager "Extension Manager" */
    protected $ext_manager;

    /** @var \phpbb\path_helper */
    protected $path_helper;

    /** @var string phpBB root path */
    protected $root_path;

    /** @var string php_ext */
    protected $php_ext;


    /**
    * The database tables
    *
    * @var string
    */


    /**
    * Constructor
    *
    * @param \phpbb\template\template                   $template
    * @param \phpbb\user                                $user
    * @param \phpbb\auth\auth                           $auth
    * @param \phpbb\db\driver\driver_interface          $db
    * @param \phpbb\request\request                     $request
    * @param \phpbb\config\config                       $config
    * @param \phpbb\log\log                             $log
    * @param string                                     $root_path
    * @param string                                     $php_ext
    *
    */
    public function __construct(
        \phpbb\template\template $template,
        \phpbb\user $user,
        \phpbb\auth\auth $auth,
        \phpbb\db\driver\driver_interface $db,
        \phpbb\request\request $request,
        \phpbb\config\config $config,
        \phpbb\pagination $pagination,
        \phpbb\log\log $log,
        \phpbb\extension\manager $ext_manager,
        \phpbb\path_helper $path_helper,
        $root_path,
        $php_ext
    )
    {
        $this->template                     = $template;
        $this->user                         = $user;
        $this->auth                         = $auth;
        $this->db                           = $db;
        $this->request                      = $request;
        $this->config                       = $config;
        $this->pagination   = $pagination;
        $this->log                          = $log;
        $this->ext_manager   = $ext_manager;
        $this->path_helper   = $path_helper;
        $this->root_path                    = $root_path;
        $this->php_ext                      = $php_ext;
        $this->ext_path = $this->ext_manager->get_extension_path('teamrelax/relaxarcade', true);
        $this->ext_path_web = $this->path_helper->update_web_root_path($this->ext_path);
    }

        public function acp_defis()
        {
            include($this->ext_path . 'arcade/includes/constants.' . $this->php_ext);
                // Grab some vars
            $action = $this->request->variable('action', '');
            $mode = $this->request->variable('mode', '');

            switch($action)
            {

                case 'del' :
                    $this->remove_defis($action, $mode);
                break;

                case 'activate' :
                    $this->activate_defis();
                break;

                default :
                    $this->display_defis();
                break;
            }

        }






        public function remove_defis($action, $mode)
        {
            $defis_id = $this->request->variable('d',0);



            if (confirm_box(true))
            {
                $sql_array = array(
                    'SELECT'    => 'd.id',

                    'FROM'      => array(
                        RA_DEFIS_TABLE  => 'd'
                    ),

                    'WHERE'     => 'd.id = '.(int)$defis_id
                );

                $sql = $this->db->sql_build_query('SELECT', $sql_array);
                $result = $this->db->sql_query($sql);

                if (!$row = $this->db->sql_fetchrow($result))
                {
                    trigger_error($this->user->lang['NO_DEFIS'] . adm_back_link($this->u_action), E_USER_WARNING);
                }



                $this->db->sql_query('DELETE FROM '.RA_DEFIS_TABLE.' WHERE id = '.(int)$defis_id);

                $this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_DEFIS_DELETED');
                trigger_error($this->user->lang['DEFIS_DELETED']. adm_back_link($this->u_action));
            }
            else
            {
                confirm_box(false, $this->user->lang['CONFIRM_OPERATION_DEFIS'], build_hidden_fields(array(
                    'd'         => $defis_id,
                    'mode'      => $mode,
                    'action'    => $action,
                    )));
            }
        }

        public function activate_defis()
        {

            $defis_id = $this->request->variable('d',0);
            $activate = $this->request->variable('selection','',true);
            $desactivate = $this->request->variable('desactive','',true);
            $date_end = $this->request->variable('end','',true);

            if ($activate)
            {

                    $this->defis_activate($defis_id,$date_end);

            }
            if ($desactivate)
            {

                    $this->defis_desactivate($defis_id);

            }

        }

        public function defis_desactivate($defis_id)
        {
           
            $sql_ary = array();
            $sql_ary['actif_index'] = 0;

            $sql = 'UPDATE ' . RA_DEFIS_TABLE . ' SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
                          WHERE id = '.$defis_id;
            $this->db->sql_query($sql);

            $this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_DEFIS_DESACTIVATE');
            trigger_error( $this->user->lang['DEFIS_DESACTIVATE']. adm_back_link($this->u_action), E_USER_WARNING);
        }


        public function defis_activate($defis_id,$date_end)
        {

            $date_end = $this->request->variable('end','',true);

            $sql = 'SELECT COUNT(d.id) AS total_defis
            FROM (' . RA_DEFIS_TABLE. ' d)
            WHERE d.actif_index = 1
            ORDER BY id';
            $result = $this->db->sql_query($sql);
            $totaldefis = (int) $this->db->sql_fetchfield('total_defis');
            $this->db->sql_freeresult($result);



            if ($totaldefis >= 1 )
            {
                trigger_error($this->user->lang['DEFIS_UP_ACTIF'] . adm_back_link($this->u_action), E_USER_WARNING);
            }
            else
            {

            $sql_ary = array();
            $sql_ary['timeend'] = (time() + $date_end);
            $sql_ary['timestart'] = time();
            $sql_ary['actif'] = 1;
            $sql_ary['actif_index'] = 1;


            $sql = 'UPDATE ' . RA_DEFIS_TABLE . ' SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
                          WHERE id = '.$defis_id;
            $this->db->sql_query($sql);

            $this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_DEFIS_ACTIVATE');
            trigger_error( $this->user->lang['DEFIS_ACTIVATE']. adm_back_link($this->u_action));

            }
        }







    public function display_defis()
    {
			$form_name = 'acp_defis';
			add_form_key($form_name);
			$error = '';

		if ($this->request->is_set_post('submit'))
		{
			if (!check_form_key($form_name))
			{
				$error = $this->user->lang('FORM_INVALID');
			}
       
			$this->config->set('radefis_forum_id', $this->request->variable('radefis_forum_id', ''));
			$this->config->set('radefis_disable_forum_id', $this->request->variable('radefis_disable_forum_id', false));
			 trigger_error( $this->user->lang['RADEFIS_CONFIG']. adm_back_link($this->u_action));
		}

		   $start  = $this->request->variable('start', 0);

            $date_end = $this->request->variable('end','',true);
            $user_id = array();

            $sql = 'SELECT user_id, username, user_colour, group_id
                FROM ' . USERS_TABLE;
            $result = $this->db->sql_query($sql);

            while( $row = $this->db->sql_fetchrow($result))
            {
                $user_id [$row['user_id']] =   get_username_string('full', $row['user_id'], $row['username'], $row['user_colour'])  ;

            }


            $sql_array = array(
                'SELECT'    => 'd.*, g.game_name ',

                'FROM'      => array(
                    RA_DEFIS_TABLE  => 'd'
                ),
                'LEFT_JOIN' => array(

                array(
                    'FROM'  => array(RA_GAMES_TABLE => 'g'),
                    'ON'    => 'g.game_id = d.gid'
                )
            ),


                'ORDER_BY' => 'd.id DESC'
            );

            $sql = $this->db->sql_build_query('SELECT', $sql_array);
            $result = $this->db->sql_query_limit($sql,20, $start);

	
			$um = (60*30);
            $unh = (60*60);
			$deh = (60*60*2);
			$th = (60*60*3);
			$qh = (60*60*4); 
			$ch = (60*60*5);
			$sh = (60*60*6);
			$seh = (60*60*7);
			$huh = (60*60*8);
			$neh = (60*60*9);
			$dih = (60*60*10);
			$onh = (60*60*11);
			$doh = (60*60*12);
			$vqh = (60*60*24);
			$qhh = (60*60*24*2);
			$end ='<option value="'.$um.'" >'.$this->user->lang['ARCADE_30MIN'].'</option>
					<option value="'.$unh.'" >'.$this->user->lang['ARCADE_1HOURS'].'</option>
				   <option value="'.$deh.'" >'.$this->user->lang['ARCADE_2HOURS'].'</option>
					<option value="'.$th.'" >'.$this->user->lang['ARCADE_3HOURS'].'</option>
					<option value="'.$qh.'" >'.$this->user->lang['ARCADE_4HOURS'].'</option>
					<option value="'.$ch.'" >'.$this->user->lang['ARCADE_5HOURS'].'</option> 
					<option value="'.$sh.'" >'.$this->user->lang['ARCADE_6HOURS'].'</option>
					<option value="'.$seh.'" >'.$this->user->lang['ARCADE_7HOURS'].'</option>
					<option value="'.$huh.'" >'.$this->user->lang['ARCADE_8HOURS'].'</option>
					<option value="'.$neh.'" >'.$this->user->lang['ARCADE_9HOURS'].'</option>
					<option value="'.$dih.'" >'.$this->user->lang['ARCADE_10HOURS'].'</option>
					<option value="'.$onh.'" >'.$this->user->lang['ARCADE_11HOURS'].'</option>
					<option value="'.$doh.'" >'.$this->user->lang['ARCADE_12HOURS'].'</option>
					<option value="'.$vqh.'" >'.$this->user->lang['ARCADE_24HOURS'].'</option>
					<option value="'.$qhh.'" >'.$this->user->lang['ARCADE_48HOURS'].'</option>';

            while( $row = $this->db->sql_fetchrow($result) )
            {
                $this->template->assign_block_vars('defis', array(
                    'ID' =>$row['id'],
                    'USER' => $user_id [$row['user']],
                    'USERS' =>$user_id [$row['users']],
                    'GID' => (!empty($row['game_name'])) ? $row['game_name'] : $this->user->lang['GAME_INC'],
                    'DATESELECT'    => $end,
                    'TIMEEND' => ($row['timeend'] > 0) ? (  ($row['timeend'] > time()) ? sprintf($this->user->lang['EN_DEFIS'],$this->user->format_date($row['timeend'])) : sprintf($this->user->lang['TER_DEFIS'],$this->user->format_date($row['timeend']))) : sprintf($this->user->lang['ATT_DEFIS'],$this->user->format_date($row['timestart'])),
                    'ACTIF' =>($row['actif_index'] == 1) ? $this->user->lang['DEFIS_ON'] : $this->user->lang['DEFIS_OFF'],
                    'U_ACTIVATE' => $this->u_action . "&amp;action=activate&amp;d=".(int)$row['id'],
                    'U_DELETE' => $this->u_action . "&amp;action=del&amp;d=".(int)$row['id']
                    ));
            }

            $sql = 'SELECT COUNT(d.id) AS total_defis
            FROM (' . RA_DEFIS_TABLE. ' d)
            ORDER BY id';
            $result = $this->db->sql_query($sql);
            $totaldefis = (int) $this->db->sql_fetchfield('total_defis');
            $this->db->sql_freeresult($result);
            $total_defi  = ($totaldefis) ? $totaldefis : 1;
            $pagination_url = $this->u_action;

            $this->template->assign_vars( array(
				'RADEFIS_FORUM_ID'	=> $this->config['radefis_forum_id'],
				'RADEFIS_DISABLE'	=> $this->config['radefis_disable_forum_id'],
				'U_ACTION'			=> $this->u_action,
                'PAGINATION'        => $this->pagination->generate_template_pagination($pagination_url, 'pagination', 'start', $total_defi, 20, $start),
                'S_ON_PAGE'         =>$this->pagination->get_on_page($total_defi, 20, $start)

            ));


    }


    /**
    * Set page url
    *
    * @param string $u_action Custom form action
    * @return null
    * @access public
    */
    public function set_page_url($u_action)
    {
        $this->u_action = $u_action;
    }
}
