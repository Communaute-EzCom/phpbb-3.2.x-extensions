function toggleDiv(div,days){
 var obj=document.getElementById(div);
 obj.style.display=obj.style.display=='none'?'block':'none'
 document.cookie=div+'='+obj.style.display+';expires='+(new Date(new Date().getTime()+(days||-1)*86400000).toGMTString())+';path=/';
}

function cookie(nme){
  var re=new RegExp(nme+'[^;]+','i');
  if (document.cookie.match(re)){
   return document.cookie.match(re)[0].split("=")[1];
  }
  return null
 }

function checkcookie(nme){
 if (cookie(nme)){
  document.getElementById(nme).style.display=cookie(nme);
 }
}

document.body.onload = checkcookie('div0');
document.body.onload = checkcookie('div2');
document.body.onload = checkcookie('div3');
document.body.onload = checkcookie('div4');
document.body.onload = checkcookie('div5');
document.body.onload = checkcookie('div6');
document.body.onload = checkcookie('div7');