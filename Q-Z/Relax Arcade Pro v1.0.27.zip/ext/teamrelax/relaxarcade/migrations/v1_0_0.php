<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\migrations;

use phpbb\db\migration\migration;

class v1_0_0 extends migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v31x\v319rc1');
	}

	public function update_data()
	{
		return array(
			array('config.add', array('ra_version', '1.0.0')),
			array('config.add', array('arcade_close', '0')),
			array('config.add', array('gamesKey', '75zW6L8DmS22qRj75P6kL3P8')),
			array('config.add', array('game_fps_tolerance', '30')),
			array('config.add', array('game_time_tolerance', '10')),
			array('config.add', array('cheater_submit', '1')),
			array('config.add', array('games_per_page', '15')),
			array('config.add', array('games_order', 'RA_GAMES_ORDER_NEWS')),
			array('config.add', array('games_order_acp', 'RA_GAMES_ORDER_FIXED')),
			array('config.add', array('arcade_post_restrict', '0')),
			array('config.add', array('posts_needed', '1')),
			array('config.add', array('days_limit', '30')),
			array('config.add', array('avatar_maxsize', '150')),
			array('config.add', array('games_per_page_acp', '10')),
			array('config.add', array('nb_cat_per_row', '4')),
			array('config.add', array('ra_allow_privmsg', '1')),
			array('config.add', array('ra_allow_bookmark', '1')),
			array('config.add', array('ra_bookmark_limit', '50')),
			array('config.add', array('ra_last_installed', '1')),
			array('config.add', array('ra_top_leader', '3')),
			array('config.add', array('ra_top_points', '3')),

			array('module.add', array(
				'acp',
				'ACP_CAT_DOT_MODS',
				'ACP_CAT_RELAXARCADE',
			)),

			array('module.add', array(
				'acp',
				'ACP_CAT_RELAXARCADE',
				array(
					'module_basename'	=> '\teamrelax\relaxarcade\acp\acp_relaxarcade_module',
					'modes'             => array(
						'settings',
						'manage',
						'setting_category',
						'setting_groups',
						'install',
						'cheat',
					),
				),
			)),
		);
	}

	public function update_schema()
	{
		return array(
			'add_tables' => array(
				$this->table_prefix . 'ra_auth_access' => array(
					'COLUMNS'		=> array(
						'group_id'					=> array('UINT', 0),
						'ra_cat_id'					=> array('UINT', 1),
						'ra_cat_auth_view'			=> array('BOOL', 0),
						'ra_cat_auth_play'			=> array('BOOL', 0),
						'ra_cat_auth_submit'		=> array('BOOL', 0),
						'ra_cat_auth_vote'			=> array('BOOL', 0),
					),
					'PRIMARY_KEY'	=> array('group_id', 'ra_cat_id'),
				),

				$this->table_prefix . 'ra_cat' => array(
					'COLUMNS'		=> array(
						'ra_cat_id'					=> array('UINT', null, 'auto_increment'),
						'ra_cat_title'				=> array('VCHAR', ''),
						'ra_cat_pic'				=> array('VCHAR', ''),
						'ra_cat_order'				=> array('USINT', 0),
						'ra_cat_active'				=> array('BOOL', 0),
						'ra_cat_submit'				=> array('BOOL', 0),
						'ra_cat_nbgames'			=> array('UINT', 0),
						'ra_cat_auth_view'			=> array('BOOL', 1),
						'ra_cat_auth_play'			=> array('BOOL', 1),
						'ra_cat_auth_submit'		=> array('BOOL', 1),
						'ra_cat_auth_vote'			=> array('BOOL', 1),
						'ra_cat_class'				=> array('BOOL', 1),
					),
					'PRIMARY_KEY' => 'ra_cat_id',
				),

				$this->table_prefix . 'ra_cheaters' => array(
					'COLUMNS'		=> array(
						'cheater_id'			=> array('UINT', null, 'auto_increment'),
						'user_id'				=> array('UINT', 0),
						'game_id'				=> array('UINT', 0),
						'score_game'			=> array('DECIMAL:16', 0),
						'cheater_date'			=> array('TIMESTAMP', 0),
						'cheater_flashtime'		=> array('TIMESTAMP', 0),
						'cheater_realtime'		=> array('TIMESTAMP', 0),
						'cheater_type'			=> array('BOOL', 0),
					),
					'PRIMARY_KEY' => 'cheater_id',
				),

				$this->table_prefix . 'ra_game_rating' => array(
					'COLUMNS'		=> array(
						'game_rating_id'		=> array('UINT', null, 'auto_increment'),
						'game_id'				=> array('UINT', 0),
						'user_id'				=> array('UINT', 0),
						'game_rating_val'		=> array('TINT:3', 0),
						'game_rating_date'		=> array('INT:11', 0),
					),
					'PRIMARY_KEY' => 'game_rating_id',
				),

				$this->table_prefix . 'ra_games' => array(
					'COLUMNS'		=> array(
						'game_id'				=> array('UINT', null, 'auto_increment'),
						'game_pic'				=> array('VCHAR', ''),
						'game_desc'				=> array('VCHAR', ''),
						'game_cont'				=> array('USINT', 0),
						'game_name'				=> array('VCHAR', ''),
						'game_swf'				=> array('VCHAR', ''),
						'game_scorevar'			=> array('VCHAR', ''),
						'game_width'			=> array('USINT', 550),
						'game_height'			=> array('USINT', 400),
						'game_type'				=> array('TINT:3', 1),
						'game_order'			=> array('USINT', 0),
						'game_cheat_control'	=> array('BOOL', 0),
						'game_scoretype'		=> array('BOOL', 0),
						'game_fps'				=> array('USINT', 0),
						'game_size'				=> array('UINT:11', 0),
						'game_bgcolor'			=> array('CHAR:6', 'FFFFFF'),
						'game_nbdecimal'		=> array('TINT:3', 0),
						'ra_cat_id'				=> array('UINT', 1),
						'us_user_id'			=> array('UINT', 0),
						'us_score_game'			=> array('DECIMAL:16', 0),
						'us_score_date'			=> array('INT:11', 0),
					),
					'PRIMARY_KEY' => 'game_id',
				),

				$this->table_prefix . 'ra_gamestat' => array(
					'COLUMNS'		=> array(
						'game_id'				=> array('UINT', 0),
						'gamestat_user_id'		=> array('UINT', 0),
						'gamestat_highscore'	=> array('DECIMAL:16', 0),
						'gamestat_highdate'		=> array('TIMESTAMP', 0),
						'gamestat_set'			=> array('UINT', 0),
						'gamestat_rating'		=> array('DECIMAL', 0),
						'gamestat_rating_set'	=> array('UINT', 0),
					),
					'PRIMARY_KEY' => 'game_id',
				),

				$this->table_prefix . 'ra_scores' => array(
					'COLUMNS'		=> array(
						'game_id'				=> array('UINT', 0),
						'user_id'				=> array('UINT', 0),
						'score_game'			=> array('DECIMAL:16', 0),
						'score_date'			=> array('TIMESTAMP', 0),
						'score_time'			=> array('TIMESTAMP', 0),
						'score_set'				=> array('UINT', 0),
						'score_comment'			=> array('VCHAR', ''),
						'score_fps'				=> array('USINT', 0),
						'score_points'			=> array('TINT:3', 0),
					),
					'PRIMARY_KEY' => array('game_id', 'user_id'),
				),

				$this->table_prefix . 'ra_sessions' => array(
					'COLUMNS'		=> array(
						'gamekey'				=> array('INT:11', 0),
						'gid'					=> array('UINT', 0),
						'user_id'				=> array('UINT', 0),
						'date_deb'				=> array('INT:11', 0),
						'arcade_cat_id'			=> array('USINT', 1),
						'gamename'				=> array('VCHAR', ''),
						'username'				=> array('TEXT', ''),
						'user_allow_viewonline'	=> array('BOOL', 1),
						'user_colour'			=> array('VARBINARY', ''),
						'ra_session_id'			=> array('CHAR:32', ''),
					),
					'PRIMARY_KEY' => 'user_id',
				),

				$this->table_prefix . 'ra_bookmarks' => array(
					'COLUMNS'		=> array(
						'game_id'				=> array('UINT', 0),
						'user_id'				=> array('UINT', 0),
					),
					'PRIMARY_KEY' => array('game_id', 'user_id'),
				),
			),

			'add_columns' => array(
				$this->table_prefix . 'users' => array(
					'user_allow_rapm'			=> array('BOOL', 1),
				),
			),
		);
	}

	public function revert_schema()
	{
		return array(
			'drop_tables' => array(
				$this->table_prefix . 'ra_auth_access',
				$this->table_prefix . 'ra_cat',
				$this->table_prefix . 'ra_cheaters',
				$this->table_prefix . 'ra_game_rating',
				$this->table_prefix . 'ra_games',
				$this->table_prefix . 'ra_gamestat',
				$this->table_prefix . 'ra_scores',
				$this->table_prefix . 'ra_sessions',
				$this->table_prefix . 'ra_bookmarks',
			),

			'drop_columns' => array(
				$this->table_prefix . 'users' => array(
					'user_allow_rapm',
				),
			),
		);
	}
}
