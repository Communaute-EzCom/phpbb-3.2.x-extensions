<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\migrations;

use phpbb\db\migration\migration;

class v1_0_27 extends migration
{
	static public function depends_on()
	{
		return array('\teamrelax\relaxarcade\migrations\v1_0_26');
	}
	
	public function update_data()
	{
		return array(
			
			array('config.add', array('radefis_disable_forum_id', '0')),
			array('config.add', array('radefis_forum_id', '2')),
			array('config.update', array('ra_version', '1.0.27')),
			array('module.add', array(
				'acp',
				'ACP_CAT_RELAXARCADE',
				array(
					'module_basename'	=> '\teamrelax\relaxarcade\acp\acp_relaxarcade_module',
					'modes'             => array(
						'acp_defis',
						
					),
				),
			)),
		);
	}


	
	
		public function update_schema()
	{
		//Create the columns tables
		return array(
			'add_tables' => array(
				$this->table_prefix . 'ra_defis'	=> array(				
					'COLUMNS'			=> array(
						'id' 			=> array('INT:11', null, 'auto_increment'),
						'user'  		=> array('VCHAR:100' , 0),
						'users'		=> array('VCHAR:100' , 0),
						'gid'			=> array('INT:11' , 0),
						'timestart'	=> array('INT:11' , 0),
						'timeend'		=> array('INT:11' , 0),
						'actif' 		=> array('INT:11' , 0),
						'actif_index' => array('INT:11' , 0),
						'user_score' 	=> array('INT:11' , 0),
						'users_score'	=> array('INT:11' , 0),
					),
					'PRIMARY_KEY'	=> 'id',				

				),
			),
			
		);
	}
	
	
	
	
	
	
	
	
	
	
	
	


	
	
	
	
	
	
	

	
	
}
