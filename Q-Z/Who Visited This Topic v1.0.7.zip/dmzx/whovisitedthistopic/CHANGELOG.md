## Who Visited This Topic Changelog

### 1.0.7 - 2019-10-09

- Drop support 3.1.x
- Twig update.
- Code update memberlist.


