## Changelog

### 1.0.5 - 2019-05-27

- Added duration of videos.
- Added statistics from youtube.
- Twig update.

### 1.0.4 - 2018-06-22

- Added code for mChat video add and comment.
- Updated website link in files.
