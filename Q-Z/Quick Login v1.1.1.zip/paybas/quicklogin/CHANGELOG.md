### Changelog

- 1.1.0 (17/09/2017)
  - [FIX] update for phpBB 3.2
- 1.1.1 (01/10/2017)
  - [FIX] listener fixes
  - [NEW] support pbwow3