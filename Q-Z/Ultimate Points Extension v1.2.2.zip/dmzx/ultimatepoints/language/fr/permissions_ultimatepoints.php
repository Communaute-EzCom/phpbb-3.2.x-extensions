<?php
/**
*
* @package phpBB Extension - Ultimate Points
* @copyright (c) 2016 dmzx & posey - http://www.dmzx-web.net
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters for use
// ’ » “ ” …

$lang = array_merge($lang, array(
	'ACL_U_USE_POINTS'		=> 'Peut utiliser Ultimate Points',
	'ACL_U_USE_ROBBERY'		=> 'Peut utliser le module de vol',
	'ACL_U_USE_BANK'		=> 'Peut utliser le module Banque',
	'ACL_U_USE_LOGS'		=> 'Peut utliser le module registration',
	'ACL_U_USE_LOTTERY'		=> 'Peut utliser le module de Lotterie',
	'ACL_U_USE_TRANSFER'	=> 'Can use Transfer Module de transfert',
	'ACL_F_PAY_ATTACHMENT'	=> 'Doit payer pour pouvoir télécharger des fichiers',
	'ACL_F_PAY_TOPIC'		=> 'Doit payer pour créer un nouveau sujet',
	'ACL_F_PAY_POST'		=> 'Doit payer pour créer un nouveau poste',
	'ACL_M_CHG_POINTS'		=> 'Peut changer les points des utilisateurs',
	'ACL_M_CHG_BANK'		=> 'Peut changer les montants de la Banque',
	'ACL_A_POINTS'			=> 'Peut administrer Ultimate Points',
	'ACL_CAT_POINTS'			=> 'Gestion des points',
));



	
