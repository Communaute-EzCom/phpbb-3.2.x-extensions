<?php
/**
*
* @package phpBB Extension - Ultimate Points
* @copyright (c) 2016 dmzx & posey - http://www.dmzx-web.net
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_POINTS'						=> 'Ultimate Points',
	'ACP_POINTS_BANK_EXPLAIN'			=> 'Ici vous pouvez modifier les paramètres du module Banque',
	'ACP_POINTS_BANK_TITLE'				=> 'Paramètres bancaires',
	'ACP_POINTS_DEACTIVATED'			=> 'Ultimate Points est actuellement désactivé!',
	'ACP_POINTS_FORUM_EXPLAIN'			=> 'Ici vous pouvez définir les points de forum par défaut pour tous les forums à la fois. Donc idéal pour vos premiers réglages.<br />S&apos;il vous plaît garder à l&apos;esprit, que ces paramètres sont pour <strong>TOUS</strong> les forums. Donc, si vous avez modifié manuellement l&apos;un des paramètres de vos points du forum avec des valeurs individuelles, vous devez le refaire après avoir utilisé cette option!',
	'ACP_POINTS_FORUM_TITLE'			=> 'Paramètre des points',
	'ACP_POINTS_INDEX_EXPLAIN'			=> 'Ici vous pouvez modifier les paramètres généraux de Ultimate Points',
	'ACP_POINTS_INDEX_TITLE'			=> 'Paramètres de point',
	'ACP_POINTS_LOTTERY_EXPLAIN'		=> 'Ici vous pouvez modifier les paramètres du module Loterie',
	'ACP_POINTS_LOTTERY_TITLE'			=> 'Paramètres de loterie',
	'ACP_POINTS_ROBBERY_EXPLAIN'		=> 'Ici vous pouvez modifier les paramètres du module de vol',
	'ACP_POINTS_ROBBERY_TITLE'			=> 'Paramètres de vol',
	'ACP_POINTS_VALUES_HINT'			=> '<strong>Info: </strong>Entrez toujours des valeurs sans le séparateur de milliers<br />et décimales avec un point, c&apos;est-à-dire 1000.50',
	'ACP_USER_POINTS_TITLE'				=> 'Ultimate Points Paramètres',

	'BANK_COST'							=> 'Le coût de gestion d&apos;un compte bancaire',
	'BANK_COST_EXPLAIN'					=> 'Ici vous définissez le prix que les utilisateurs doivent payer à chaque période pour leur compte bancaire (mettre 0 pour désactiver cette fonctionnalité)',
	'BANK_ENABLE'						=> 'Activer le module de banque',
	'BANK_ENABLE_EXPLAIN'				=> 'Cela permettra aux utilisateurs d&apos;utiliser le module de banque',
	'BANK_FEES'							=> 'Retirer des frais',
	'BANK_FEES_ERROR'					=> 'Les frais de retrait ne peuvent être supérieurs à 100% !',
	'BANK_FEES_EXPLAIN'					=> 'Le montant en pourcentage (%) que les utilisateurs devront payer, lorsqu&apos;ils se retireront de la banque',
	'BANK_INTEREST'						=> 'Taux d&apos;intérêt',
	'BANK_INTERESTCUT'					=> 'Désactiver l&apos;intérêt à',
	'BANK_INTERESTCUTP'					=> '(mettre 0 pour désactiver cette fonctionnalité)',
	'BANK_INTERESTCUT_EXPLAIN'			=> 'C&apos;est le montant maximum pour lequel un utilisateur obtiendra le taux d&apos;intérêt. Si elles possèdent plus, la valeur de consigne est le maximum! Définissez 0 pour désactiver cette fonctionnalité.',
	'BANK_INTEREST_ERROR'				=> 'Le taux d&apos;intérêt ne peut pas être supérieur à 100% !',
	'BANK_INTEREST_EXPLAIN'				=> 'Le montant en % d&apos;intérêt',
	'BANK_MINDEPOSIT'					=> 'Dépôt minimum',
	'BANK_MINDEPOSIT_EXPLAIN'			=> 'Le montant minimum que les utilisateurs peuvent déposer dans la banque',
	'BANK_MINWITHDRAW'					=> 'Retrait minimum',
	'BANK_MINWITHDRAW_EXPLAIN'			=> 'Le montant minimum que les utilisateurs peuvent retirer de la banque',
	'BANK_NAME'							=> 'Nom de votre banque',
	'BANK_NAME_EXPLAIN'					=> 'Entrez un nom pour votre banque, c&apos;est-à-dire notre banque de forum',
	'BANK_OPTIONS'						=> 'Paramètres bancaires',
	'BANK_PAY'							=> 'Temps de paiement d&apos;intérêt',
	'BANK_PAY_EXPLAIN'					=> 'La période entre les paiements bancaires',
	'BANK_TIME'							=> 'jours',
	'BANK_VIEW'							=> 'Activer la banque de points',
	'BANK_VIEW_EXPLAIN'					=> 'Cela activera le module de banque',

	'FORUM_OPTIONS'						=> 'Points du forum',
	'FORUM_PEREDIT'						=> 'Points par édition',
	'FORUM_PEREDIT_EXPLAIN'				=> 'Entrez ici, combien de points les utilisateurs recevront pour <strong> l&apos;édition</strong> d&apos;un message.Sachez qu&apos;ils recevront également des points supplémentaires que vous avez définis dans les paramètres de points avancés.<br />Réglez sur 0 pour désactiver les points de réception pour ce forum.',
	'FORUM_PERPOST'						=> 'Points par message',
	'FORUM_PERPOST_EXPLAIN'				=> 'Entrez ici, combien de points les utilisateurs recevront pour l&apos;envoi <strong>messages (réponses)</strong>. Sachez qu&apos;ils recevront également des points supplémentaires que vous avez définis dans les paramètres de points avancés.<br />Réglez sur 0 pour désactiver les points de réception pour ce forum. De cette façon, les paramètres de points avancés sont désactivés pour ce forum!',
	'FORUM_PERTOPIC'					=> 'Points par sujet',
	'FORUM_PERTOPIC_EXPLAIN'			=> 'Entrez ici, combien de points les utilisateurs recevront pour la création d&apos;un <strong>nouveau sujet</strong>. Sachez qu&apos;ils recevront également des points supplémentaires que vous avez définis dans les paramètres de points avancés.<br />Réglez sur 0 pour désactiver les points de réception pour ce forum. De cette façon, les paramètres de points avancés sont désactivés pour ce forum!',
	'FORUM_COST'						=> 'Points par pièce jointe téléchargée',
	'FORUM_COST_EXPLAIN'				=> 'Entrez ici, combien de points les utilisateurs devront payer pour <strong>le téléchargement d&apos;une pièce jointe</strong>.<br />Réglez sur 0 pour désactiver cette fonctionnalité.',
	'FORUM_COST_TOPIC'					=> 'Points à payer pour un nouveau sujet',
	'FORUM_COST_TOPIC_EXPLAIN'			=> 'Entrez ici, combien de points un utilisateur doit payer pour commencer un nouveau sujet dans ce forum',
	'FORUM_COST_POST'					=> 'Points à payer pour le nouveau poste',
	'FORUM_COST_POST_EXPLAIN'			=> 'Entrez ici, combien de points un utilisateur doit payer pour faire un nouveau post dans ce forum',
	'FORUM_POINT_SETTINGS'				=> 'Ultimate Points Paramètres',
	'FORUM_POINT_SETTINGS_EXPLAIN'		=> 'Ici, vous pouvez configurer, combien de points les utilisateurs gagneront pour placer de nouveaux sujets, de nouveaux messages (réponses) et éditer leurs messages. Ces paramètres sont définis par forum. De cette façon, vous pouvez le rendre très détaillé, où les utilisateurs obtiendront des points et où pas.',
	'FORUM_POINT_SETTINGS_UPDATED'		=> 'Points du forum global mis à jour',
	'FORUM_POINT_UPDATE'				=> 'Mettre à jour les points du forum global',
	'FORUM_POINT_UPDATE_CONFIRM'		=> '<br />Êtes-vous sûr de vouloir mettre à jour tous les points du forum avec les valeurs données?<br />Cette étape écrase tous les paramètres actuels et ne peut pas être inversée!',

	'LOG_GROUP_TRANSFER_ADD'			=> 'Points transférés à un groupe',
	'LOG_GROUP_TRANSFER_SET'			=> 'Définir les point pour un groupe',
	'LOG_MOD_BANK'						=> '<strong>Points de banque modifiés</strong><br />» %1$s',
	'LOG_MOD_POINTS'					=> '<strong>Points édités</strong><br />» %1$s',
	'LOG_MOD_POINTS_BANK'				=> '<strong>Paramètres de banque modifiés</strong>',
	'LOG_MOD_POINTS_BANK_PAYS'			=> '<strong>Paiements d&apos;intérêts bancaires</strong><br />» %1$s',
	'LOG_MOD_POINTS_FORUM'				=> '<strong>Paramètres des points du forum global modifiés</strong>',
	'LOG_MOD_POINTS_FORUM_SWITCH'		=> '<strong>Edited Forum Point Switches</strong>',
	'LOG_MOD_POINTS_FORUM_VALUES'		=> '<strong>Valeurs de point de forum modifiées</strong>',
	'LOG_MOD_POINTS_LOTTERY'			=> '<strong>Paramètres de loterie modifiée</strong>',
	'LOG_MOD_POINTS_RANDOM'				=> '<strong>Points aléatoires gagnés par</strong><br />» %1$s',
	'LOG_MOD_POINTS_ROBBERY'			=> '<strong>Paramètres de vol </strong>',
	'LOG_MOD_POINTS_SETTINGS'			=> '<strong>Paramètres des points édités</strong>',
	'LOG_RESYNC_LOTTERY_HISTORY'		=> '<strong>L&apos;historique de la loterie a été réinitialisé avec succès</strong>',
	'LOG_RESYNC_POINTSCOUNTS'			=> '<strong>Tous les points d&apos;utilisateurs ont été réinitialisés avec succès</strong>',
	'LOG_RESYNC_POINTSLOGSCOUNTS'		=> '<strong>Tous les journaux d&apos;utilisateurs ont été réinitialisés avec succès</strong>',
	'LOTTERY_BASE_AMOUNT'				=> 'Base du Jackpot',
	'LOTTERY_BASE_AMOUNT_EXPLAIN'		=> 'Le jackpot commencera initialement avec ce montant. Si elle est augmentée pendant une période de tirage, des sommes supplémentaires seront ajoutées au tirage suivant. Le Jackpot ne diminuera pas s&apos;il est abaissé.',
	'LOTTERY_CHANCE'					=> 'Chance de gagner le jackpot',
	'LOTTERY_CHANCE_ERROR'				=> 'La chance de gagner ne peut pas être supérieure à 100% !',
	'LOTTERY_CHANCE_EXPLAIN'			=> 'Ici vous pouvez définir le pourcentage pour gagner le jackpot (plus la valeur est élevée, plus la chance de gagner est grande)',
	'LOTTERY_DISPLAY_STATS'				=> 'Afficher le temps du prochain tirage sur la page d&apos;index',
	'LOTTERY_DISPLAY_STATS_EXPLAIN'		=> 'Cela affichera le prochain tirage de la loterie sur la page d&apos;index.',
	'LOTTERY_DRAW_PERIOD'				=> 'Période de tirage',
	'LOTTERY_DRAW_PERIOD_EXPLAIN'		=> 'Temps en heures entre chaque tirage. Changer cela affectera le jour / l&apos;heure du tirage actuel. Mettre à 0 pour désactiver le tirage, les billets / jackpot actuels resteront.',
	'LOTTERY_DRAW_PERIOD_SHORT'			=> 'La période de tirage doit être supérieure à 0!',
	'LOTTERY_ENABLE'					=> 'Activer le module de loterie',
	'LOTTERY_ENABLE_EXPLAIN'			=> 'Cela permettra aux utilisateurs d&apos;utiliser le module de loterie',
	'LOTTERY_MAX_TICKETS'				=> 'Nombre maximum de billets',
	'LOTTERY_MAX_TICKETS_EXPLAIN'		=> 'Définir le nombre maximum de billets qu&apos;un utilisateur peut acheter',
	'LOTTERY_MULTI_TICKETS'				=> 'Autoriser plusieurs billets',
	'LOTTERY_MULTI_TICKETS_EXPLAIN'		=> 'Définissez cette option sur "Oui" pour permettre aux utilisateurs d&apos;acheter plus d&apos;un billet',
	'LOTTERY_NAME'						=> 'Nom de votre loterie',
	'LOTTERY_NAME_EXPLAIN'				=> 'Entrez un nom pour votre loterie, c&apos;est-à-dire notre loterie de forum',
	'LOTTERY_OPTIONS'					=> 'Paramètres de loterie',
	'LOTTERY_PM_ID'						=> 'Expéditeur ID',
	'LOTTERY_PM_ID_EXPLAIN'				=> 'Entrez ici l&apos;identifiant de l&apos;utilisateur, qui sera utilisé comme expéditeur du MP à l&apos;heureux gagnant (0 = utilisez l&apos;identifiant du gagnant)',
	'LOTTERY_TICKET_COST'				=> 'Coût du billet',
	'LOTTERY_VIEW'						=> 'Activer la loterie des points',
	'LOTTERY_VIEW_EXPLAIN'				=> 'Cela activera le module de loterie',

	'NO_RECIPIENT'						=> 'Aucun destinataire défini.',

	'POINTS_ADV_OPTIONS'				=> 'Paramètres avancés de points',
	'POINTS_ADV_OPTIONS_EXPLAIN'		=> 'Si les points du forum sont définis sur 0 (désactivé), tous les paramètres ne sont pas calculés ici.',
	'POINTS_ATTACHMENT'					=> 'Généralités sur l&apos;ajout de pièces jointes dans un message',
	'POINTS_ATTACHMENT_PER_FILE'		=> 'Points supplémentaires pour chaque pièce jointe',
	'POINTS_BONUS_CHANCE'				=> 'Point Bonus Chance',
	'POINTS_BONUS_CHANCE_EXPLAIN'		=> 'La chance qu&apos;un utilisateur reçoive des points bonus pour faire un nouveau sujet, poster ou modifier<br />La chance est entre 0 et 100%, vous pouvez utiliser des décimales.<br />Set to <strong>0</strong> to disable this feature.',
	'POINTS_BONUS_VALUE'				=> 'Valeur Bonus Point',
	'POINTS_BONUS_VALUE_EXPLAIN'		=> 'Donner des limites entre lesquelles nous choisirons un montant de bonus aléatoire.<br />Si vous voulez un montant fixe, définissez le minimum identique au maximum.',
	'POINTS_COMMENTS'					=> 'Autoriser les commentaires',
	'POINTS_COMMENTS_EXPLAIN'			=> 'Permettre aux utilisateurs de laisser des commentaires avec leurs points de transfert / don',
	'POINTS_CONFIG_SUCCESS'				=> 'Les paramètres des points finaux ont été mis à jour avec succès',
	'POINTS_DISABLEMSG'					=> 'Message de désactivation',
	'POINTS_DISABLEMSG_EXPLAIN'			=> 'Message à afficher lorsque le système de points ultime est désactivé',
	'POINTS_ENABLE'						=> 'Activer les points',
	'POINTS_ENABLE_EXPLAIN'				=> 'Autoriser les utilisateurs à utiliser les points ultimes',
	'POINTS_GROUP_TRANSFER'				=> 'Transfert de groupe',
	'POINTS_GROUP_TRANSFER_ADD'			=> 'Ajouter',
	'POINTS_GROUP_TRANSFER_EXPLAIN'		=> 'Ici vous pouvez ajouter, soustraire ou définir des valeurs pour un certain groupe. Vous pouvez également envoyer un message personnel à chaque membre du groupe. Pratique, si vous aimez envoyer des vœux de Noël avec un petit cadeau (vous pouvez utiliser des smileys et des bbCodes). Si vous ne voulez pas envoyer un message personnel avec votre transfert, il suffit de laisser les champs sujets et commentaires vides.',
	'POINTS_GROUP_TRANSFER_FUNCTION'	=> 'Fonction',
	'POINTS_GROUP_TRANSFER_PM_COMMENT'	=> 'Commentaire pour votre message personnel',
	'POINTS_GROUP_TRANSFER_PM_ERROR'	=> 'Vous devez entrer le sujet <strong>ET</strong> le commentaire afin d&apos;envoyer un message personnel avec votre transfert de groupe!',
	'POINTS_GROUP_TRANSFER_PM_SUCCESS'	=> 'Le transfert de groupe a été traité avec succès et<br />les membres du groupe ont reçu votre message personnel.',
	'POINTS_GROUP_TRANSFER_PM_TITLE'	=> 'Sujet pour le message personnel',
	'POINTS_GROUP_TRANSFER_SEL_ERROR'	=> 'Vous ne pouvez pas effectuer de transfert de groupe vers les groupes Bots et Invités!',
	'POINTS_GROUP_TRANSFER_SET'			=> 'Ensemble',
	'POINTS_GROUP_TRANSFER_SUBSTRACT'	=> 'Soustraire',
	'POINTS_GROUP_TRANSFER_SUCCESS'		=> 'Le transfert de groupe a été traité avec succès.',
	'POINTS_GROUP_TRANSFER_USER'		=> 'Groupe d&apos;utilisateurs',
	'POINTS_GROUP_TRANSFER_VALUE'		=> 'Valeur',
	'POINTS_IMAGES_MEMBERLIST'			=> 'Afficher une image au lieu de points dans le profil',
	'POINTS_IMAGES_MEMBERLIST_EXPLAIN'	=> 'Afficher une image au lieu du nom des points dans les profils d&apos;utilisateurs',
	'POINTS_IMAGES_TOPIC'				=> 'Afficher une image au lieu de points',
	'POINTS_IMAGES_TOPIC_EXPLAIN'		=> 'Afficher une image dans les sujets au lieu du nom des points',
	'POINTS_LOGS'						=> 'Activer les journaux de points',
	'POINTS_LOGS_EXPLAIN'				=> 'Autoriser les utilisateurs à afficher les journaux de transfert',
	'POINTS_MINIMUM'					=> '&nbsp;Minimum', // &nbsp; is for alignment of input boxes for Points Bonus Value
	'POINTS_MAXIMUM'					=> 'Maximum',
	'POINTS_NAME'						=> 'Points',
	'POINTS_NAME_EXPLAIN'				=> 'Le nom que vous voulez afficher à la place du mot <em>Points</em> sur votre tableau',
	'POINTS_POLL'						=> 'Points par nouveau sondage',
	'POINTS_POLL_PER_OPTION'			=> 'Points par option dans un sondage',
	'POINTS_POST_PER_CHARACTER'			=> 'Points par caractère dans les nouveaux messages',
	'POINTS_POST_PER_WORD'				=> 'Points par mot dans les nouveaux messages',
	'POINTS_SHOW_PER_PAGE'				=> 'Nombre d&apos;entrées par page',
	'POINTS_SHOW_PER_PAGE_ERROR'		=> 'Le nombre par page à afficher doit être au moins 5 entrées.',
	'POINTS_SHOW_PER_PAGE_EXPLAIN'		=> 'Entrez ici le nombre d&apos;entrées, qui devrait être indiqué par page dans les journaux et l&apos;histoirique de la loterie (au moins 5)',
	'POINTS_SMILIES'					=> 'Smilies',
	'POINTS_STATS'						=> 'Afficher les statistiques de points sur l&apos;index',
	'POINTS_STATS_EXPLAIN'				=> 'Afficher les statistiques des points sur la page d&apos;index du forum principal',
	'POINTS_TOPIC_PER_CHARACTER'		=> 'Points par caractère sur de nouveaux sujets',
	'POINTS_TOPIC_PER_WORD'				=> 'Points par mot sur de nouveaux sujets',
	'POINTS_TRANSFER'					=> 'Autoriser les transferts',
	'POINTS_TRANSFER_EXPLAIN'			=> 'Autoriser les utilisateurs à transférer / donner des points les uns aux autres',
	'POINTS_TRANSFER_FEE'				=> 'Frais de transfert',
	'POINTS_TRANSFER_FEE_EXPLAIN'		=> 'Pourcentage renvoyé par transfert',
	'POINTS_TRANSFER_FEE_ERROR'			=> 'Les frais de transfert ne peuvent pas être supérieur ou égale à 100%.',
	'POINTS_TRANSFER_PM'				=> 'Avertir l&apos;utilisateur par MP d&apos;un transfert',
	'POINTS_TRANSFER_PM_EXPLAIN'		=> 'Autoriser les utilisateurs à recevoir un avis par MP, lorsque quelqu&apos;un leur envoie des points',
	'POINTS_WARN'						=> 'Nombre de points à soustraire par avertissement d&apos;utilisateur (mettre 0 pour désactiver cette fonctionnalité)',

	'REG_POINTS_BONUS'					=> 'Bonus de points d&apos;enregistrement',
	'RESYNC_ATTENTION'					=> 'Les actions suivantes ne peuvent pas être annulées !',
	'RESYNC_DESC'						=> 'Réinitialiser les points d&apos;utilisateur et les journaux',
	'RESYNC_LOTTERY_HISTORY'			=> 'Réinitialiser l&apos;historique de la loterie',
	'RESYNC_LOTTERY_HISTORY_CONFIRM'	=> 'Êtes-vous sûr de vouloir réinitialiser l&apos;historique de la loterie?<br />Remarque: Cette action ne peut pas être annulée!',
	'RESYNC_LOTTERY_HISTORY_EXPLAIN'	=> 'Cela réinitialisera l&apos;historique complet de la loterie',
	'RESYNC_POINTS'						=> 'Réinitialiser les points utilisateurs',
	'RESYNC_POINTSLOGS'					=> 'Réinitialiser les journaux utilisateurs',
	'RESYNC_POINTSLOGS_CONFIRM'			=> 'Êtes-vous sûr de vouloir réinitialiser les journaux des utilisateurs?<br />Remarque: Cette action ne peut pas être annulée!',
	'RESYNC_POINTSLOGS_EXPLAIN'			=> 'Supprimer tous les journaux d&apos;utilisateurs',
	'RESYNC_POINTS_CONFIRM'				=> 'Êtes-vous sûr de vouloir réinitialiser tous les points utilisateurs?<br />Note: Ceci ne peut pas être annulé!',
	'RESYNC_POINTS_EXPLAIN'				=> 'Réinitialiser tous les comptes de points des utilisateurs à zéro',
	'ROBBERY_CHANCE'					=> 'Chance de faire un vol réussi',
	'ROBBERY_CHANCE_ERROR'				=> 'La chance pour un vol réussi ne peut pas être supérieure à 100% !',
	'ROBBERY_CHANCE_EXPLAIN'			=> 'Ici vous pouvez définir le pourcentage pour réussir un vol (plus la valeur est élevée, plus grande est la chance de réussir)',
	'ROBBERY_CHANCE_MINIMUM'			=> 'La chance pour un vol réussi doit être supérieure à 0% !',
	'ROBBERY_ENABLE'					=> 'Activer le module de vol',
	'ROBBERY_ENABLE_EXPLAIN'			=> 'Cela permettra aux utilisateurs d&apos;utiliser le module de vol',
	'ROBBERY_LOOSE'						=> 'Pénalité sur un vol raté',
	'ROBBERY_LOOSE_ERROR'				=> 'La pénalité sur un vol raté ne peut pas être supérieure à 100% !',
	'ROBBERY_LOOSE_EXPLAIN'				=> 'Si un vol sur une victime échoue, le voleur qui a tenté de voler perdra x% de la valeur de vol désirée',
	'ROBBERY_LOOSE_MINIMUM'				=> 'La pénalité pour un vol raté ne devrait pas être de 0%. Vous devriez vraiment donner une pénalité au voleur !',
	'ROBBERY_MAX_ROB'					=> 'Pourcentage maximum de vol',
	'ROBBERY_MAX_ROB_ERROR'				=> 'Vous ne pouvez pas définir une valeur supérieure à 100% !',
	'ROBBERY_MAX_ROB_EXPLAIN'			=> 'Cette valeur est le pourcentage du montant qui peut être volé en une fois',
	'ROBBERY_MAX_ROB_MINIMUM'			=> 'Le montant maximal volé devrait être supérieure à 0%. Sinon, cette option n&apos;a pas de sens!',
	'ROBBERY_NOTIFY'					=> 'Envoyer une notification à l&apos;utilisateur volé',
	'ROBBERY_NOTIFY_EXPLAIN'			=> 'Cela activera l&apos;option d&apos;envoyer une notification aux utilisateurs attaqués',
	'ROBBERY_OPTIONS'					=> 'Paramètres de vol',

	'TOP_POINTS'						=> 'Top des membres des plus riches à afficher',
	'TOP_POINTS_EXPLAIN'				=> 'Ici, vous pouvez définir la valeur pour les utilisateurs les plus riches à afficher. Fonctionne dans différents points de vue',

	'UPLIST_ENABLE'						=> 'Activer Ultimate Points List',
	'UPLIST_ENABLE_EXPLAIN'				=> 'Autoriser les membres à utiliser Ultimate Points List',
	'USER_POINTS'						=> 'Points d&apos;utilisateur',
	'USER_POINTS_EXPLAIN'				=> 'Nombre de points que l&apos;utilisateur possède',
));
