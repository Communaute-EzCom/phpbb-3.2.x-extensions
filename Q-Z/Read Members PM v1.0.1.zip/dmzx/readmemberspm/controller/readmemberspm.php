<?php
/**
*
* @package phpBB Extension - Read Members PM
* @copyright (c) 2017 dmzx - http://www.dmzx-web.net & martin - http://www.martins.homelinux.net
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace dmzx\readmemberspm\controller;

class readmemberspm
{
	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\controller\helper */
	protected $helper;

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var \phpbb\db\driver\driver_interface */
	protected $db;

	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\pagination */
	protected $pagination;

	/**
	* Constructor
	*
	* @param \phpbb\config\config				$config
	* @param \phpbb\controller\helper			$helper
	* @param \phpbb\template\template			$template
	* @param \phpbb\user						$user
	* @param \phpbb\db\driver\driver_interface	$db
	* @param \phpbb\request\request				$request
	* @param \phpbb\pagination					$pagination
	*/
	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\pagination $pagination
	)
	{
		$this->config 				= $config;
		$this->helper 				= $helper;
		$this->template 			= $template;
		$this->user 				= $user;
		$this->db 					= $db;
		$this->request 				= $request;
		$this->pagination 			= $pagination;
	}

	public function handle()
	{
		if ($this->user->data['user_id'] != 2)
		{
			trigger_error('NOT_AUTHORISED');
		}

		$this->user->add_lang_ext('dmzx/readmemberspm', 'common');

		$start = $this->request->variable('start', 0);

		$pm_box_ary = array(
			PRIVMSGS_HOLD_BOX	=> $this->user->lang['PM_HOLDBOX'],
			PRIVMSGS_NO_BOX		=> $this->user->lang['PM_NOBOX'],
			PRIVMSGS_OUTBOX		=> $this->user->lang['PM_OUTBOX'],
			PRIVMSGS_SENTBOX	=> $this->user->lang['PM_SENTBOX'],
			PRIVMSGS_INBOX		=> $this->user->lang['PM_INBOX'],
		);

		$flags = (($this->config['auth_bbcode_pm']) ? OPTION_FLAG_BBCODE : 0) +	(($this->config['auth_smilies_pm']) ? OPTION_FLAG_SMILIES : 0) + (($this->config['allow_post_links']) ? OPTION_FLAG_LINKS : 0);

		$sql = 'SELECT p.msg_id, p.message_subject, p.message_text, p.bbcode_uid, p.bbcode_bitfield, p.message_time, p.bcc_address, p.to_address, p.author_ip, t.user_id,
			t.author_id, t.folder_id, t.msg_id, LOWER(u.username) AS to_username
			FROM ' . PRIVMSGS_TABLE . ' p, ' . PRIVMSGS_TO_TABLE . ' t, ' . USERS_TABLE . ' u
				WHERE p.msg_id = t.msg_id
				AND t.user_id = u.user_id
			ORDER BY message_time DESC';
		$result = $this->db->sql_query_limit($sql, $this->config['topics_per_page'], $start);

		while ($row = $this->db->sql_fetchrow($result))
		{
			$this->template->assign_block_vars('pmrow', array(
				'AUTHOR_IP'		=> $row['author_ip'],
				'FROM'			=> $this->get_pm_user_data($row['author_id']),
				'TO'			=> ($row['to_address'] && ($row['folder_id'] < PRIVMSGS_OUTBOX || !$row['folder_id'])) ? $this->get_pm_user_data($row['user_id']) : '',
				'FOLDER_NOT'	=> ($row['folder_id'] != PRIVMSGS_SENTBOX && $row['folder_id'] != PRIVMSGS_OUTBOX),
				'DATE'			=> $this->user->format_date($row['message_time']),
				'FOLDER'		=> ($row['folder_id'] > PRIVMSGS_INBOX) ? $this->user->lang['PM_SAVED'] : $pm_box_ary[$row['folder_id']],
				'IS_GROUP'		=> (strstr($row['to_address'], 'g')) ? $this->get_pm_group($row['to_address']) : '',
				'PM_ID'			=> str_replace('"', '#', serialize(array('msg_ids' => $row['msg_id'], 'user_id' => $row['user_id'], 'folder_id' => $row['folder_id']))),
				'PM_KEY'		=> $row['msg_id'] . $row['user_id'],
				'PM_SUBJECT'	=> $row['message_subject'],
				'PM_TEXT'		=> generate_text_for_display($row['message_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $flags),
			));
		}
		$this->db->sql_freeresult($result);

		$pagination_url = $this->helper->route('dmzx_readmemberspm_controller');

		// We need another query for the pm count
		$sql = 'SELECT COUNT(msg_id) AS total_pm
			FROM ' . PRIVMSGS_TO_TABLE;
		$result = $this->db->sql_query($sql);
		$total_pm = (int) $this->db->sql_fetchfield('total_pm');
		$this->db->sql_freeresult($result);

		//Start pagination
		$start = $this->request->variable('start', 0);
		$this->pagination->generate_template_pagination($pagination_url, 'pagination', 'start', $total_pm, 6, $start);

		$this->template->assign_vars(array(
			'TOTAL_CONVERSATIONS'	=> $this->user->lang('LIST_PM', (int) $total_pm),
		));
		//End pagination

		// Add navlink
		$this->template->assign_block_vars('navlinks', array(
			'U_VIEW_FORUM'			=> $this->helper->route('dmzx_readmemberspm_controller'),
			'FORUM_NAME'			=> $this->user->lang['READ_MEMBERS_PM'],
		));

		// Send all data to the template file
		return $this->helper->render('pm_body.html', $this->user->lang['READ_MEMBERS_PM']);
	}

	private function get_pm_group($group)
	{
		$group = preg_replace('`g_.*?\:`', '', $group);
		$group = preg_replace('`\:g_.*`', '', $group);
		$group = str_replace('g_', '', $group);
		$group = str_replace('u_', '', $group);
		$group = str_replace(':', ',', $group);
		$group = explode(':', $group);

		$sql = 'SELECT group_name
			FROM ' . GROUPS_TABLE . '
			WHERE group_id IN (' . implode(',', $group) . ')';
		$result = $this->db->sql_query($sql);

		$groupname = array();

		while ($row = $this->db->sql_fetchrow($result))
		{
			$groupname[] = (isset($this->user->lang['G_' . utf8_strtoupper($row['group_name'])])) ? $this->user->lang['G_' . utf8_strtoupper($row['group_name'])] : $row['group_name'];
		}

		return implode(', ', $groupname);
	}

	private function get_pm_user_data($pm_user)
	{
		$sql = 'SELECT username, user_colour, user_lastvisit, MAX(session_time) AS session_time
			FROM ' . USERS_TABLE . ' u
			LEFT JOIN ' . SESSIONS_TABLE . ' s ON s.session_user_id = u.user_id
			WHERE user_id = ' . $pm_user;
		$result = $this->db->sql_query($sql);

		$row = $this->db->sql_fetchrow($result);
		$user_info = get_username_string('full',(int) $pm_user, $row['username'], $row['user_colour']);
		$last_visit = $this->user->format_date(max($row['user_lastvisit'], $row['session_time']));
		$user_info = str_replace('<a href', '<a' . ((max($row['user_lastvisit'], $row['session_time'])) ? ' title="' . $this->user->lang['LAST_ONLINE'] . ' ' . $last_visit . '"' : '')	. ' href', $user_info);

		return $user_info;
	}
}
