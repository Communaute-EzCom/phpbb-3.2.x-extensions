<?php
/**
*
* @package phpBB Extension - Read Members PM
* @copyright (c) 2017 dmzx - http://www.dmzx-web.net & martin - http://www.martins.homelinux.net
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace dmzx\readmemberspm\migrations;

class readmemberspm_install extends \phpbb\db\migration\migration
{
	public function update_data()
	{
		return array(
			// Add configs
			array('config.add', array('readmemberspm_version', '1.0.0')),
		);
	}
}
