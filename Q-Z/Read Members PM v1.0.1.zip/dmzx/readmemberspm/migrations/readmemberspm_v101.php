<?php
/**
*
* @package phpBB Extension - Read Members PM
* @copyright (c) 2017 dmzx - http://www.dmzx-web.net & martin - http://www.martins.homelinux.net
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace dmzx\readmemberspm\migrations;

use phpbb\db\migration\migration;

class readmemberspm_v101 extends migration
{
	static public function depends_on()
	{
		return array(
			'\dmzx\readmemberspm\migrations\readmemberspm_install',
		);
	}

	public function update_data()
	{
		return array(
			array('config.update', array('readmemberspm_version', '1.0.1')),
		);
	}
}
