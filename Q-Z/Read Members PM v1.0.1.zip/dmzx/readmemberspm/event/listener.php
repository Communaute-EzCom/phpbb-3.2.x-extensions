<?php
/**
*
* @package phpBB Extension - Read Members PM
* @copyright (c) 2017 dmzx - http://www.dmzx-web.net & martin - http://www.martins.homelinux.net
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace dmzx\readmemberspm\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\controller\helper */
	protected $helper;

	/** @var \phpbb\user */
	protected $user;

	/** @var phpbb\language\language */
	protected $language;

	/** @var string phpEx */
	protected $php_ext;

	/**
	* Constructor
	*
	* @param \phpbb\controller\helper	$helper
	* @param \phpbb\template\template	$template
	* @param \phpbb\user				$user
	* @param phpbb\language\language	$language
	* @param string						$php_ext
	*/
	public function __construct(
		\phpbb\controller\helper $helper,
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\language\language $language,
		$php_ext
	)
	{
		$this->helper 		= $helper;
		$this->template 	= $template;
		$this->user 		= $user;
		$this->language		= $language;
		$this->php_ext	 	= $php_ext;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.viewonline_overwrite_location'	=> 'viewonline_page',
			'core.page_header'						=> 'page_header',
		);
	}

	public function viewonline_page($event)
	{
		$this->language->add_lang('common', 'dmzx/readmemberspm');

		if ($event['on_page'][1] == 'app')
		{
			if (strrpos($event['row']['session_page'], 'app.' . $this->php_ext . '/readmemberspm') === 0)
			{
				$event['location'] = $this->user->lang('VIEWING_READMEMBERSPM');
				$event['location_url'] = $this->helper->route('dmzx_readmemberspm_controller');
			}
		}
	}

	public function page_header($event)
	{
		$this->language->add_lang('common', 'dmzx/readmemberspm');

		$this->template->assign_vars(array(
			'U_READMEMBERSPM' 	=> $this->helper->route('dmzx_readmemberspm_controller'),
			'SHOW_FOUNDER'		=> ($this->user->data['user_id'] == 2) ? true : false,
		));
	}
}
