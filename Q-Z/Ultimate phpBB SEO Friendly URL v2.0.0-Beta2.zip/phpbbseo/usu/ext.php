<?php
/**
*
* @package Ultimate phpBB SEO Friendly URL
* @version $$
* @copyright (c) 2017 www.phpbb-seo.org
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace phpbbseo\usu;

/**
* ext Class
* www.phpBB-SEO.org
* @package Ultimate phpBB SEO Friendly URL
*/
class ext extends \phpbb\extension\base
{
}
