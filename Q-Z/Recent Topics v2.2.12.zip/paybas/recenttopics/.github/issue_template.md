### Expected Behavior


### Actual Behavior


### Steps to Reproduce the Problem

  1.
  1.
  1.

### Specifications

  - phpbb version:
  - recenttopics version:

