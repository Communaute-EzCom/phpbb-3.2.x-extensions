<?php
/**
 *
 * Topic/Post Reactions. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2017 Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'REACTIONS'						=> 'Réactions',	
	'REACTION_COPY'					=> '',
	'REACTIONS_TITLE'				=> 'Réactions aux messages/sujets',
	'REACTIONS_TITLES'				=> 'Réactions aux messages/sujets &bull; page %d',
	//
//Actions
	'ENABLE_POST_REACTIONS'			=> 'Activer les réactions pour ce message',
	'ENABLE_TOPIC_REACTIONS'		=> 'Activer les réactions pour ce sujet',
	'EXPLAIN_REACTIONS_POSTING'		=> 'Options des réactions au message/sujet',
	
	'LOG_ACP_REACTION_ADDED'		=> '<strong>Réaction « %1$s » ajoutée</strong>',
	'LOG_ACP_REACTION_EDITED'		=> '<strong>Réaction « %1$s » modifiée',
	'LOG_ACP_REACTION_DELETED'		=> '<strong>Réaction « %1$s » supprimée</strong>',

	'ADD_REACTION'					=> 'Réagir au message',
	'DELETE_REACTION'				=> 'Supprimer sa réaction',	
	'REACTION_ADDED'				=> 'Réaction ajoutée',
	'REACTION_DELETED'				=> 'Réaction supprimée',
	'REACTION_DUPLICATE'			=> 'Une réaction a déjà été publiée pour ce message',
	'REACTIONS_LIST_VIEW'			=> 'Voir toutes les réactions',
	'REACTION_NOTIFICATION'			=> '<strong>Nouvelle réaction</strong> <img src="%1$s" class="reaction-notification" alt="%2$s" /> de %3$s au message :<br /> « %4$s »',
	'REACTION_TYPES'				=> 'Types de réactions',
	'REACTION_TYPE_DUPLICATE'		=> 'La réaction sélectionnée est la même que celle déjà publiée.',
	'REACTION_UPDATED'				=> 'Réaction modifiée',
	'RESYNC_REACTIONS'				=> 'Resynchroniser les réactions',
	'SELECT_REACTION_TYPES'			=> 'Réactions interdites aux utilisateurs concernant vos messages',	
	'UPDATE_REACTION'				=> 'Modifier sa réaction',

//Errors
	'NOT_AUTHORISED_REACTIONS'		=> 'Vous n’êtes pas autorisé à voir les réactions aux messages/sujets.',
	'NOTIFICATION_TYPE_STEVE_REACTION' 		=> 'Quelqu’un a réagi à votre message/sujet',	
	'REACTIONS_DISABLED'			=> 'La page « Vue des réactions » est actuellement désactivée.',
	'REACTIONS_DISABLED_USER'		=> 'Cette réaction ne peut être affichée car l’auteur du message a désactivé les réactions ou n’a pas les permissions nécessaires.',	
	'REACTIONS_NOT_FOUND'			=> 'Une <strong>erreur</strong> a été rencontrée.',//?
	'REACTION_ERROR'				=> 'Une <strong>erreur</strong> a été rencontrée merci de recharger la page ou d’essayer à nouveau.',
	'RESYNC_DISABLED'				=> 'La resynchronisation des extensions est actuellement désactivée.',
	//

	'TOO_FEW_CHARS'					=> 'Le message ne contient pas assez de caractères.',
/* 	
	'USER_REACTION'	=> array(
		1 => 'Reaction',
		2 => 'Reactions',
	),
*/	
	'HR_RECENT_REACTIONS'			=> 'Réactions récentes reçues :',
	'RECENT_REACTIONS'				=> '%d réactions affichées sur un total de %2d',
	'REACTION_COUNT_TOTAL'			=> 'Total des réactions aux messages',
	'REACTIONS_TOTAL'				=> 'Total des réactions',
	
	'USER_REACTION'					=> '%d réaction',
	'USER_REACTIONS'				=> '%d réactions',
	'VIEW_REACTIONS'				=> 'Vue des réactions',	
	'VIEWING_REACTIONS'				=> 'Consulte la page « Vue des réactions »',
	'WELCOME_REACTIONS_PAGE'		=> 'Bienvenue %1$s,<br />Un total de %2$s membres ont reçu des réactions pour leur messages, il est possible de cliquer sur l’image de la réaction pour voir les messages pour lesquels ils ont reçu des réactions.',

//pre populated reactions
	'REACTION_CRY'					=> 'Pleure',
	'REACTION_DISLIKE'				=> 'Désapprouve',
	'REACTION_FUNNY'				=> 'Rigole',
	'REACTION_HAPPY'				=> 'Content',
	'REACTION_LIKE'					=> 'Apprécie',
	'REACTION_LOVE'					=> 'Adore',
	'REACTION_MAD'					=> 'Énervé',
	'REACTION_NEUTRAL'				=> 'Neutre',
	'REACTION_SAD'					=> 'Triste',
	'REACTION_SURPRISED'			=> 'Surpris',
	'REACTION_UNHAPPY'				=> 'Mécontent',
));
