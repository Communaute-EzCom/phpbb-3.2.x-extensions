<?php
/**
*
* Tapatalk Plugin for phpBB 3.1/3.2 extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2017 phpBB Limited <https://www.phpbb.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(

	// UMIL stuff
	'ACP_MOBIQUO_TITLE'				=> 'Tapatalk',
	'ACP_MOBIQUO_TITLE_EXPLAIN'		=> 'Extension « Tapatalk Plugin for phpBB 3.1/3.2 » pour son forum phpBB.',
	'MOBIQUO_TABLE_DELETED'			=> 'La table Tapatalk a été supprimée avec succès.',
	'MOBIQUO_TABLE_CREATED'			=> 'La table Tapatalk a été créée avec succès.',
	'MOBIQUO_TABLE_UPDATED'			=> 'La table Tapatalk a été mise à jour avec succès.',
	'MOBIQUO_NOTHING_TO_UPDATE'		=> 'Aucune action effectuée… poursuivre',
	'ACP_MOBIQUO'					=> 'Paramètres de Tapatalk',
	'ACP_MOBIQUO_SETTINGS'			=> 'Paramètres de Tapatalk',
	'ACP_MOBIQUO_SETTINGS_EXPLAIN'	=> 'Permet de paramétrer les options générales de l’extension « Tapatalk Plugin for phpBB 3.1/3.2 ».',
	'ACP_MOBIQUO_MOD_VER'			=> 'Version de l’extension',
	'LOG_CONFIG_MOBIQUO'			=> 'Paramètres Tapatalk mis à jour',
	'acl_a_mobiquo'					=> array('lang' => 'Peut gérer les paramètres Tapatalk.', 'cat' => 'Divers'),

	'TP_PUSHENABLED'				=> 'Activer les notifications PUSH',
	'TP_PUSHENABLED_EXPLAIN'		=> 'Permet d’activer la fonctionnalité PUSH autorisant l’envoi instantané de messages aux utilisateurs.',
	'MOBIQUO_HIDE_FORUM_ID'			=> 'Masquer des forums ',
	'MOBIQUO_HIDE_FORUM_ID_EXPLAIN'	=> 'Permet de sélectionner des forums qui seront masqués de la liste des forums affichée dans l’application Tapatalk.',
	'MOBIQUO_NAME' 					=> 'Répertoire du plugin Tapatalk ',
	'MOBIQUO_NAME_EXPLAIN'			=> 'Permet de modifier le nom du répertoire du plugin Tapatalk. Si une modification est soumise sur cette page, merci de modifier en conséquence le nom du répertoire sur son espace FTP, ainsi que de mettre à jour son nom sur le site Web de Tapatalk dans la rubrique : « <a href="https://siteowners.tapatalk.com/forums/dashboard">See All Sites</a> ». La valeur par défaut est : « <em>mobiquo</em> ».',
	'TAPATALK_PUSH_KEY' 			=> 'Clé de l’API Tapatalk ',
	'TAPATALK_PUSH_KEY_EXPLAIN'		=> 'Permet de saisir la clé de l’API Tapatalk. Auparavant nommée « Clé PUSH », cette clé est dorénavant requise afin de sécuriser les échanges entre son forum et le serveur de Tapatalk. Par ailleurs, des fonctionnalités telles que les notifications PUSH & l’authentification unique requièrent que cette clé soit renseignée.',

	'ACP_TAPATALK_REBRANDING'			=> 'Options Tapatalk BYO',
	'ACP_TAPATALK_REBRANDING_EXPLAIN'	=> 'Permet d’utiliser les options offertes par « <a href="https://tapatalk.com/build-your-own-app.php">Tapatalk - Build Your Own</a> ».',
	'TAPATALK_FORUM_READ_ONLY'			=> 'Désactiver la création de nouveaux sujets ',
	'TAPATALK_FORUM_READ_ONLY_EXPLAIN'	=> 'Permet d’exclure les forums sélectionnés de toute création de nouveaux sujets. Cette fonctionnalité est particulièrement utile lorsque certains forums requièrent des champs additionnels ou des permissions particulières que Tapatalk ne supportent pas.',

	'TAPATALK_ANDROID_URL'				=> 'ID de produit Android',
	'TAPATALK_KINDLE_URL'				=> 'URL de produit Amazon Kindle Fire',
	'TAPATALK_ANDROID_URL_EXPLAIN'		=> 'Permet de saisir l’ID de l’application BYO provenant de Google Play, afin d’être utilisée sur des périphériques Android, telle que par exemple : « com.quoord.tapatalkpro.activity ».',
	'TAPATALK_KINDLE_URL_EXPLAIN'		=> 'Permet de saisir l’URL de l’application BYO provenant de Amazon App Store, afin d’être utilisée sur les périphériques Kindle Fire.',

	'TAPATALK_ALLOW_APP_ADS'			=> 'Écran de bienvenue aux appareils mobiles',
	'TAPATALK_ALLOW_APP_ADS_EXPLAIN'	=> 'Permet d’afficher un écran de bienvenue lors de la première connexion des utilisateurs mobiles leur proposant de télécharger l’application Tapatalk.',

	'TAPATALK_CUSTOM_REPLACE'			=> 'Remplacement du contenu des messages (Option Avancée) ',
	'TAPATALK_CUSTOM_REPLACE_EXPLAIN'	=> 'Permet de trouver puis remplacer du contenu en utilisant la fonction PHP « preg_replace — Rechercher et remplacer par expression rationnelle standard » (<a href="http://php.net/manual/fr/function.preg-replace.php">Voir davantage d’informations</a>). Par exemple : « <em>pattern</em>,<em>replacement</em> » . Il est possible de définir une règle de remplacement sur chaque nouvelle ligne.',


	'TAPATALK_APP_BANNER_MSG'			=> 'Message de la bannière de l’application BYO',
	'TAPATALK_APP_IOS_ID'				=> 'ID de l’application iOS BYO',
	'TAPATALK_APP_BANNER_MSG_EXPLAIN'	=> 'Permet de saisir par exemple : «  Suivre {your_forum_name} avec {app_name} sur [os_platform] ». Ne pas modifier le noms de ces trois tags {your_forum_name}, {app_name} & [os_platform] car ils sont générés de manière automatique selon les informations renseignées sur le compte Tapatalk utilisé et suivant la plateforme utilisée sur le périphérique de l’utilisateur.',
	'TAPATALK_APP_IOS_ID_EXPLAIN'		=> 'Permet de saisir l’ID de l’application BYO provenant de Apple App Store, afin d’être utilisée sur les périphériques iOS.',

	'ACP_MOBIQUO_REGISTER_SETTINGS'			=> 'Enregistrement depuis l’application Tapatalk',
	'ACP_MOBIQUO_REGISTER_SETTINGS_EXPLAIN'	=> 'Permet aux utilisateurs de s’enregistrer depuis l’application Tapatalk.',
	'TAPATALK_REGISTER_GROUP'				=> 'Assigner un groupe d’utilisateurs ',
	'TAPATALK_REGISTER_GROUP_EXPLAIN'		=> 'Permet d’ajouter les nouveaux utilisateurs enregistrés au moyen de l’application Tapatalk à des groupes d’utilisateurs spécifiques. Si aucun groupe n’est spécifié, ils seront ajoutés au groupe par défaut.', 
	'TAPATALK_REGISTER_STATUS'				=> 'Options d’enregistrement',
	'TAPATALK_REGISTER_STATUS_EXPLAIN'		=> 'Permet de proposer l’enregistrement et l’authentification unique au moyen de ses identifiants de connexion Facebook (Recommandé). Les utilisateurs ne souhaitant pas s’enregistrer par ce moyen-ci peuvent le faire via un formulaire d’enregistrement proposé depuis l’application.<br/>
Ou de proposer l’enregistrement seul - Aucune authentification unique (SSO) ne sera disponible pour les utilisateurs Facebook. Tous les utilisateurs devront s’enregistrer au moyen du formulaire d’enregistrement proposé par l’application Tapatalk.<br/>
Ou de rediriger vers une adresse URL d’enregistrement externe - Tous les utilisateurs s’enregistrant seront redirigés hors de l’application, sur leur navigateur pour terminer leur enregistrement.',


	'TAPATALK_REGISTER_STATUS_SSO'			=> 'Enregistrement & authentification unique (Recommandé)',
	'TAPATALK_REGISTER_STATUS_NATIVE'		=> 'Enregistrement seul',
	'TAPATALK_REGISTER_STATUS_URL'			=> 'Redirection vers une adresse URL d’enregistrement externe',

	'ACP_TAPATALK_DEEPLINK'					=> 'Liens profonds mobiles (Applications BYO & Tapatalk)',
	'ACP_TAPATALK_DEEPLINK_EXPLAIN'			=> 'Permet d’activer les liens profonds mobiles pour les applications BYO et Tapatalk.',
	'TAPATALK_ALLOW_APP_BANNER'				=> 'Bannière de l’application ',
	'TAPATALK_ALLOW_APP_BANNER_EXPLAIN'		=> 'Permet d’activer la bannière pour les applications BYO et Tapatalk.',
	'TAPATALK_GOOGLE_INDEXING'				=> 'Indexation des applications Google ',
	'TAPATALK_GOOGLE_INDEXING_EXPLAIN'		=> 'Permet d’activer les liens profonds des sujets depuis les résultats de la recherche Google.',
	'TAPATALK_FACEBOOK_INDEXING'			=> 'Liens profonds mobiles Facebook ',
	'TAPATALK_FACEBOOK_INDEXING_EXPLAIN'	=> 'Permet d’activer les liens profonds des sujets depuis les liens de l’application Facebook.',
	'TAPATALK_TWITTER_INDEXING'				=> 'Liens profonds mobiles Twitter ',
	'TAPATALK_TWITTER_INDEXING_EXPLAIN'		=> 'Permet d’activer les liens profonds des sujets depuis les liens de l’application Twitter.',


	'TAPATALK_SPAM_STATUS'						=> 'Prévention de spam',
	'TAPATALK_SPAM_STATUS_EXPLAIN'				=> 'Permet d’activer le service Stop Forum Spam lors de tout nouvel enregistrement effectué depuis l’application Tapatalk et/ou depuis le Web pour prévenir le forum des « spammeurs ».',
	'TAPATALK_SPAM_STATUS_0'					=> 'Désactiver le service Stop Forum Spam',
	'TAPATALK_SPAM_STATUS_1'					=> 'Activer le service Stop Forum Spam lors des enregistrements depuis l’application Tapatalk',
	'TAPATALK_SPAM_STATUS_2'					=> 'Activer le service Stop Forum Spam lors des enregistrements depuis le Web',
	'TAPATALK_SPAM_STATUS_3'					=> 'Activer le service Stop Forum Spam lors de tous les enregistrements',
	'LOG_CONFIG_REBRANDING'						=> 'Paramètres Tapatalk BYO mis à jour',
	'LOG_CONFIG_REGISTER'						=> 'Paramètres d’enregistrement Tapatalk mis à jour',
	'TAPATALK_AD_FILTER'						=> 'Désactiver les publicités pour les groupes ',
	'TAPATALK_AD_FILTER_EXPLAIN'				=> 'Permet de désactiver l’affichage de publicités aux utilisateurs des groupes sélectionnés lors de l’utilisation de l’application Tapatalk.',
	'TAPATALK_AUTO_APPROVE'						=> 'Approuver automatiquement les utilisateurs Tapatalk vérifiés ',
	'TAPATALK_AUTO_APPROVE_EXPLAIN'				=> 'Permet d’approuver automatiquement les utilisateurs Tapatalk vérifiés sans nécessité de modération ou toute autre étape.',
	'TAPATALK_ALLOW_TWITTERFACEBOOK'			=> 'Liens profonds Facebook & Twitter',
	'TAPATALK_ALLOW_TWITTERFACEBOOK_EXPLAIN'	=> 'Permet d’autoriser les membres d’ouvrir le même sujet dans Tapatalk depuis les messages de Facebook & les tweets de Twitter.',
	'TAPATALK_SSO'								=> 'Enregistrement depuis l’application Tapatalk ',
	'TAPATALK_SSO_EXPLAIN'						=> 'Permet aux utilisateurs Tapatalk vérifiés via Facebook, Google ou toute autre adresse e-mail de s’enregistrer sur le forum depuis l’application Tapatalk. Les utilisateurs régis par le statut COPPA ou tout autre champ personnalisé sont aussi supportés, bien qu’il soit recommandé de limiter autant que faire se peut le nombre de champs personnalisés afin de faciliter l’enregistrement depuis un périphérique mobile.'
	)
);