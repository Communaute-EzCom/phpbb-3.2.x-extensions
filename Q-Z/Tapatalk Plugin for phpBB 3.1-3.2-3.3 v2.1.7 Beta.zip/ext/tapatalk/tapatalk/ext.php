<?php
/**
*
* @package phpBB Extension - Tapatalk Plugin Demo
* @copyright (c) 2013 phpBB Group
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace tapatalk\tapatalk;

/**
* @ignore
*/

class ext extends \phpbb\extension\base
{
}
