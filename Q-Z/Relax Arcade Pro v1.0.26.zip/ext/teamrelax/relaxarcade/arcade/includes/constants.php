<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

if (!defined('IN_PHPBB'))
{
	die("Hacking attempt");
}

global $table_prefix;

// Page numbers for session handling
if (!defined('PAGE_GAMES')) define('PAGE_GAMES', -150);
if (!defined('PAGE_ARCADE')) define('PAGE_ARCADE', -151);
if (!defined('PAGE_SCOREGAME')) define('PAGE_SCOREGAME', -152);
if (!defined('PAGE_TOPPLAYERS')) define('PAGE_TOPPLAYERS', -153);


//Relax Arcade tables
if (!defined('RA_CONFIG_TABLE')) define('RA_CONFIG_TABLE',			$table_prefix . 'ra_config');
if (!defined('RA_CAT_TABLE')) define('RA_CAT_TABLE',				$table_prefix . 'ra_cat');
if (!defined('RA_GAMES_TABLE')) define('RA_GAMES_TABLE',			$table_prefix . 'ra_games');
if (!defined('RA_SCORES_TABLE')) define('RA_SCORES_TABLE',			$table_prefix . 'ra_scores');
if (!defined('RA_GAMESTAT_TABLE')) define('RA_GAMESTAT_TABLE',			$table_prefix . 'ra_gamestat');
if (!defined('RA_GAME_RATING_TABLE')) define('RA_GAME_RATING_TABLE',		$table_prefix . 'ra_game_rating');
if (!defined('RA_AUTH_ACCESS_TABLE')) define('RA_AUTH_ACCESS_TABLE', 		$table_prefix . 'ra_auth_access');
if (!defined('RA_CHEATERS_TABLE')) define('RA_CHEATERS_TABLE', 		$table_prefix . 'ra_cheaters');
if (!defined('RA_SESSIONS_TABLE')) define('RA_SESSIONS_TABLE', 		$table_prefix . 'ra_sessions');
if (!defined('RA_BOOKMARKS_TABLE')) define('RA_BOOKMARKS_TABLE', 		$table_prefix . 'ra_bookmarks');

//Relax Arcade Auth
if (!defined('AUTH_LIST_ALL')) define('AUTH_LIST_ALL', 0);
if (!defined('AUTH_ALL')) define('AUTH_ALL', 0);
if (!defined('AUTH_REG')) define('AUTH_REG', 1);
if (!defined('AUTH_ACL')) define('AUTH_ACL', 2);
if (!defined('AUTH_MOD')) define('AUTH_MOD', 3);
if (!defined('AUTH_ADMIN')) define('AUTH_ADMIN', 5);
if (!defined('AUTH_VIEW')) define('AUTH_VIEW', 1);
if (!defined('AUTH_VOTE')) define('AUTH_VOTE', 10);
if (!defined('AUTH_PLAY')) define('AUTH_PLAY', 30);
if (!defined('AUTH_SUBMIT')) define('AUTH_SUBMIT', 31);

