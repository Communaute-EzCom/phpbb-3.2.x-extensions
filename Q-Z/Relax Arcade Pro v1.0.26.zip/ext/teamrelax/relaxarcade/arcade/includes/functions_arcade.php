<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

if (!defined('IN_PHPBB'))
{
	die('Hacking attempt');
}

//
// Fonction vérification de l'accès aux jeux arcade
//
function arcade_access_game()
{
	global $db, $config, $user;

	$days_limit = intval($config['days_limit']);
	$posts_needed = intval($config['posts_needed']);

	if ($days_limit || $posts_needed)
	{
		if ($posts_needed)
		{
			$sql = 'SELECT COUNT(post_id) as number_post
				FROM ' . POSTS_TABLE . '
				WHERE poster_id = ' . (int) $user->data['user_id'];

			if ($days_limit)
			{
				$min_post_time = time() - ($days_limit * 86400);
				$sql .= ' and post_time > ' . $min_post_time;
			}

			$result=$db->sql_query($sql);
			$row = $db->sql_fetchrow($result);

			//$arcade_restrict_day = intval($config['arcade_post_restrict_day']);
			if ($row['number_post'] < $posts_needed)
			{
				$user_posts_needed = $posts_needed - $row['number_post'];
				$message = $user->lang('NOT_AUTHORISED');

				if ($posts_needed && $days_limit)
				{
					$message = $user->lang('SORRY_ARCADE_RESTRICT_DATE', $config['posts_needed'], $config['days_limit'], $user_posts_needed);
				}
				else if ($posts_needed)
				{
					$message = $user->lang('SORRY_ARCADE_RESTRICT_DAY', $config['posts_needed'], $user_posts_needed);
				}
				trigger_error($message);
			}
		}
	}

	return true;
}

//
// Fonction vérification jeu déjà noté par le joueur
//
function arcade_game_noted($gid)
{
	global $db, $user;

	$sql = 'SELECT game_rating_id
		FROM ' . RA_GAME_RATING_TABLE . '
		WHERE game_id = ' . (int) $gid . '
			AND user_id = ' . (int) $user->data['user_id'];
	$result = $db->sql_query($sql);
	$row = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);
	return (bool) $row;
}

//
// Fonction notation d'un jeu
//
function arcade_game_rating($gid, $rating)
{
	global $db, $user;

	$sql_data = array(
		'game_id' 			=> $gid,
		'user_id' 			=> $user->data['user_id'],
		'game_rating_val'	=> $rating,
		'game_rating_date'	=> time()
	);
	$sql = 'INSERT INTO ' . RA_GAME_RATING_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);

	if (!$result = $db->sql_query($sql))
	{
		return false;
	}

	//Recalcul de la nouvelle note moyenne du jeu
	$sql = 'SELECT AVG(game_rating_val) AS rating_avg
		FROM ' . RA_GAME_RATING_TABLE . '
		WHERE game_id = ' . (int) $gid;
	if (!$result = $db->sql_query($sql))
	{
		return false;
	}

	$row = $db->sql_fetchrow($result);
	$rating_avg = $row['rating_avg'];
	$db->sql_freeresult($result);

	$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . '
		SET gamestat_rating = ' . (float)$rating_avg . ' , gamestat_rating_set = gamestat_rating_set + 1
		WHERE game_id = ' . (int) $gid;
	if (!$result = $db->sql_query($sql))
	{
		return false;
	}

	return $rating_avg;
}

//
// Fonction vérification submit possible pour une catégorie
//
function arcade_cat_submit($cid)
{
	global $db;

	$sql = 'SELECT ra_cat_submit FROM ' . RA_CAT_TABLE . '
		WHERE ra_cat_id = ' . (int) $cid;
	$result = $db->sql_query($sql);
	$row = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);

	return intval($row['ra_cat_submit']) === 1;
}

//
// Fonction pour voir qui joue à quoi
//
function arcade_view_playing($is_auth_ary)
{
	$ar_gamename = $ar_username = $row = $tab_player = array();
	$num_gid = $j = -1;
	$arcade_session_time = 300; //5 mn

	$ret = arcade_sessgames_list($arcade_session_time);

	if (isset($ret[0]))
	{
		// Obtient une liste de colonnes
		foreach ($ret as $key => $row)
		{
			$ar_gamename[$key] = isset($row['gamename']) ? $row['gamename'] : '';
			$ar_username[$key] = isset($row['username']) ? $row['username'] : '';
		}
		// Trie les données par $ar_gamename croissant, $ar_user_id croissant
		// Ajoute $ret en tant que dernier paramètre, pour trier par la clé commune
		array_multisort($ar_gamename, SORT_ASC, $ar_username, SORT_ASC, $ret);
		$count = count($ret);

		//Grouper les joueurs par id de jeu
		for ($i = 0; $i < $count; $i++)
		{
			//Si autorisation de voir ce jeu
			if (isset($ret[$i]['arcade_cat_id']))
			{
				$catid = intval($ret[$i]['arcade_cat_id']);
				if ($is_auth_ary[$catid]['ra_cat_auth_view'] && ($ret[$i]['date_deb'] >= time() - $arcade_session_time))
				{
					$username = get_username_string('full', $ret[$i]['user_id'], $ret[$i]['username'], $ret[$i]['user_colour']);

					if (!$ret[$i]['user_allow_viewonline'])
					{
						$username = '<i>' . $username . '</i>';
					}

					if ($ret[$i]['gid'] == $num_gid)
					{
						$tab_player[$j]['playerlist'] = isset($tab_player[$j]['playerlist']) ? $tab_player[$j]['playerlist'] . ', ' . $username : $username;
					}
					else
					{
						$j++;
						$tab_player[$j]['playerlist'] = $username;
						$tab_player[$j]['gamename'] = $ret[$i]['gamename'];
						$tab_player[$j]['gid'] = $ret[$i]['gid'];
						$tab_player[$j]['date_deb'] = $ret[$i]['date_deb'];
						$tab_player[$j]['user_allow_viewonline'] = $ret[$i]['user_allow_viewonline'];
						$tab_player[$j]['game_pic'] = $ret[$i]['game_pic'];
					}
					$num_gid = $ret[$i]['gid'];
				}
			}
		}
		return $tab_player;
	}
	else
	{
		return false;
	}
}

//
// Fonction listant les sessions de jeu depuis le paramètre time
//
function arcade_sessgames_list($time)
{
	global $db;

	$delta_time = time() - $time;

	$sql_array = array(
		'SELECT'	=> 's.*, g.game_pic',
		'FROM'		=> array(RA_SESSIONS_TABLE	=> 's',
		),
		'LEFT_JOIN'	=> array(
			array(
				'FROM'	=> array(RA_GAMES_TABLE => 'g'),
				'ON'	=> 'g.game_id = s.gid',
			),
		),
		'WHERE'		=> 'date_deb >= ' . $delta_time,
	);

	$sql = $db->sql_build_query('SELECT', $sql_array);
	$result = $db->sql_query($sql);
	$sess_games = $db->sql_fetchrowset($result);
	$db->sql_freeresult($result);

	return $sess_games;
}

function ra_sess_init($gid, $cat_id, $gamename)
{
	global $db, $user;

	//Nettoyage des sessions de jeu du joueur
	$db->sql_query('DELETE FROM ' . RA_SESSIONS_TABLE . ' WHERE user_id = ' . (int) $user->data['user_id']);

	//Insertion de la session du joueur
	$sql_ary = array(
		'gamekey'				=> mt_rand(),
		'gid'					=> $gid,
		'date_deb'				=> time(),
		'user_id'				=> $user->data['user_id'],
		'arcade_cat_id'			=> $cat_id,
		'gamename'				=> $gamename,
		'username'				=> $user->data['username'],
		'user_allow_viewonline'	=> $user->data['user_allow_viewonline'],
		'user_colour'			=> $user->data['user_colour'],
		'ra_session_id'			=> $user->data['session_id'],
	);
	$db->sql_query('INSERT INTO ' . RA_SESSIONS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_ary));
}

function ra_sess_start()
{
	global $db, $user;

	$sql = 'SELECT gamekey
		FROM ' . RA_SESSIONS_TABLE . '
		WHERE user_id = ' . (int) $user->data['user_id'];
	$result = $db->sql_query($sql);
	$row = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);

	return $row['gamekey'];
}

function ra_sess_submit()
{
	global $db, $user;

	$sql = 'SELECT *
		FROM ' . RA_SESSIONS_TABLE . '
		WHERE user_id = ' . (int) $user->data['user_id'];
	$result = $db->sql_query($sql);
	$ra_session = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);

	return $ra_session;
}

function ra_bookmark($gid, $liste_cat_id_auth)
{
	global $db, $user, $config;
	$ret = array();

	if ($config['ra_allow_bookmark'] && $user->data['is_registered'] && $gid)
	{
		/* Vérification du jeu */
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.ra_cat_id, b.user_id as bookmarked',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g',
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_BOOKMARKS_TABLE => 'b'),
					'ON'	=> 'g.game_id = b.game_id AND b.user_id = ' . $user->data['user_id'],
				)
			),
			'WHERE'		=> 'g.game_id = ' . (int) $gid,
		);

		$sql = $db->sql_build_query('SELECT', $sql_array);
		$result = $db->sql_query($sql);
		$game_data = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		if (!in_array($game_data['ra_cat_id'], $liste_cat_id_auth))
		{
			$ret['errors'][] = $user->lang['RA_NOT_AUTHORIZED'];
			return $ret;
		}

		//Contrôle limite de jeux autorisés en favoris
		if (($config['ra_bookmark_limit']) && !$game_data['bookmarked'])
		{
			$sql = 'SELECT COUNT(game_id) AS tot_fav
					FROM ' . RA_BOOKMARKS_TABLE . '
					WHERE user_id = ' . (int)$user->data['user_id'];
			$result = $db->sql_query($sql);
			$row = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);
			if ($row['tot_fav'] > (int) $config['ra_bookmark_limit'])
			{
				$ret['errors'][] = $user->lang['RA_BOOKMARK_MAX'];
				return $ret;
			}
		}

		if (!$game_data['bookmarked'])
		{
			$sql = 'INSERT INTO ' . RA_BOOKMARKS_TABLE . ' ' . $db->sql_build_array('INSERT', array(
				'game_id'	=> $gid,
				'user_id'	=> $user->data['user_id'],
			));
		}
		else
		{
			$sql = 'DELETE FROM ' . RA_BOOKMARKS_TABLE . '
				WHERE user_id = ' . (int) $user->data['user_id'] . '
					AND game_id = ' . (int) $gid;
		}
		$db->sql_query($sql);

		$ret['message'][] = isset($game_data) ? $game_data : array();
	}
	else
	{
		$ret['errors'][] = $user->lang['RA_BOOKMARK_INACTIV'];
	}

	return $ret;
}




		
		
		

function ra_scores_us_delete($gid, $del_score_row, $new_score_row)
{
	global $db;

	if ($new_score_row !== false && isset($new_score_row['user_id']))
	{
		$sql_ary = array(
			'us_user_id'	=> $new_score_row['user_id'],
			'us_score_game'	=> $new_score_row['score_game'],
			'us_score_date'	=> $new_score_row['score_date'],
		);
	}
	else
	{
		$sql_ary = array(
			'us_user_id'	=> 0,
			'us_score_game'	=> 0,
			'us_score_date'	=> 0
		);
	}

	$sql = 'UPDATE ' . RA_GAMES_TABLE . '
		SET ' . $db->sql_build_array('UPDATE', $sql_ary) . '
		WHERE game_id = ' . (int) $gid;
	$db->sql_query($sql);

	if ($new_score_row !== false && isset($new_score_row['user_id']))
	{
		$sql_ary = array(
			'gamestat_user_id'		=> $new_score_row['user_id'],
			'gamestat_highscore'	=> $new_score_row['score_game'],
			'gamestat_highdate'		=> $new_score_row['score_date'],
		);

		$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . '
			SET ' . $db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE game_id = ' . (int) $gid . '
				AND gamestat_user_id = ' . (int) $del_score_row['user_id'];
	}
	else
	{
		$sql = 'DELETE FROM ' . RA_GAMESTAT_TABLE . '
			WHERE game_id = ' . (int) $gid . '
				AND gamestat_user_id = ' . (int) $del_score_row['user_id'];
	}
	$db->sql_query($sql);

	$sql = 'DELETE FROM ' . RA_SCORES_TABLE . '
		WHERE game_id = ' . (int) $gid . '
			AND user_id = ' . (int) $del_score_row['user_id'];
	$db->sql_query($sql);
}
