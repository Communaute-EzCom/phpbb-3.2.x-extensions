<?php
class camembert
{
	var $dim;

	function camembert() 
	{  
		$this->dim = 0;  
		$this->tot = 0;    
		$this->tabVal=array();  
		$this->tabNom=array();		
	} 

	function add_tab($val, $nom) 
	{  
		if ($val > 0) 
		{   
			$this->tabVal[$this->dim] = $val;   
			$this->tabNom[$this->dim] = $nom;   
			$this->tot = $this->tot + $val; 
			$this->dim++; 
		} 
	} 

	function trier_tab() 
	{  
		if ($this->dim > 1) 
		{ 
	   
			for($i=0;$i<$this->dim-1;$i++) 
			{    
				$maxi = $this->tabVal[$i];    
				
				for($j=$i+1;$j<$this->dim;$j++) 
				{     
					
					if ($maxi < $this->tabVal[$j]) 
					{      
						$maxi  = $this->tabVal[$j];      
						$inter = $this->tabNom[$j];            
						$this->tabVal[$j] = $this->tabVal[$i];      
						$this->tabNom[$j] = $this->tabNom[$i];      
						$this->tabVal[$i] = $maxi;      
						$this->tabNom[$i] = $inter;           
					}    
				}   
			} 
		}
	}

		
	function affiche_tab() 
	{  
		for($i=0; $i<$this->dim; $i++) 
		{   
			
			echo $this->tabNom[$i].' '.$this->tabVal[$i].'<br />';  
		}  
	}

	function stat2png($mode, $hauteur_effet_3D) 
	{  
		$width       = 420; 
		$height      = 220; 
		$centre_x    = 110; 
		$centre_y    = 110; 
		$cam_largeur = 200; 
		$cam_hauteur = 160; 

		$img = imagecreatetruecolor($width, $height) or die("Probleme : Chargement de la lib GD impossible");  

		$noir  = imagecolorallocate($img,0,0,0);  
		$vert  = imagecolorallocate($img,90,160,90);  
		$blanc = imagecolorallocate($img,255,255,255); 
	 
		ImageFill( $img, 0, 0, $blanc );
	  
		if ($mode<>2 && $mode<>3) 
		{ 
			$mode = 2;  
		}    
		if ($mode == 2) 
		{   
			$cam_largeur = $cam_hauteur; 
		}    

		$tot_angle = -90; 

		$v2 = 185;  
		$v1 = 75;  
		$c  = 0;    
		
		for($i=0; $i<$this->dim; $i++) 
		{ 
			if ($c==0) 
			{    
				$tab_couleurs[$i][0][0] = $v1;   
				$tab_couleurs[$i][0][1] = $v2; 
				$tab_couleurs[$i][0][2] = $v2;   
			}   
			else if ($c==1) 
			{    
				$tab_couleurs[$i][0][0] = $v2;    
				$tab_couleurs[$i][0][1] = $v1; 
				$tab_couleurs[$i][0][2] = $v2; 
			}   
			else if ($c==2) 
			{    
				$tab_couleurs[$i][0][0] = $v2;     
				$tab_couleurs[$i][0][1] = $v2;    
				$tab_couleurs[$i][0][2] = $v1;   
			}      
			$c++;   
		  
			if ($c==3) 
			{    
				$c   = 0;    
				$v1 += 60;    
				$v2 -= 40;
				
				if (abs($v1-$v2) < 40) 
				{     
					$v1 += 30;     
					$v2 -= 30;    
				} 
			}  

			$dark = 35; 

			for($k=0; $k<3; $k++) 
			{
			
				if ($tab_couleurs[$i][0][$k] - $dark > 0) $tab_couleurs[$i][1][$k] = $tab_couleurs[$i][0][$k] - $dark;    
				else $tab_couleurs[$i][1][$k] = 0;   
			}
		  
			$tab_angle[$i] = $tot_angle;   
			$angle = ($this->tabVal[$i] * 360) / $this->tot;   
			$tot_angle += $angle;  
		}
		
		$tab_angle[$this->dim] = $tot_angle; 
	   
		if ($mode == 3) 
		{       
			for($k=$centre_y + $hauteur_effet_3D; $k > $centre_y; $k--) 
			{ 
				for($i=0; $i<$this->dim; $i++) 
				{ 
					$color = imagecolorallocate( $img, $tab_couleurs[$i][1][0], $tab_couleurs[$i][1][1], $tab_couleurs[$i][1][2] );     	 
		  
					imagefilledarc($img, $centre_x, $k, $cam_largeur, $cam_hauteur, $tab_angle[$i], $tab_angle[$i+1], $color, IMG_ARC_PIE);    
				}   
			}
		}  
		
		for($i=0; $i<$this->dim; $i++) 
		{ 
			$color = imagecolorallocate( $img, $tab_couleurs[$i][0][0], $tab_couleurs[$i][0][1], $tab_couleurs[$i][0][2] );  
			 
			imagefilledarc($img, $centre_x, $centre_y, $cam_largeur, $cam_hauteur, $tab_angle[$i], $tab_angle[$i+1], $color, IMG_ARC_PIE);      
			  
			$x = 235;   
			$y = 15 + $i*16;
			   
			imagefilledrectangle($img, $x, $y, $x+9, $y+9, $color);
			
			imagestring($img, 2, $x+15, $y-2, $this->tabNom[$i].' - '.$this->tabVal[$i].' points', $noir);  
		}    
	  
		if($this->dim == 0)imagestring( $img, 2, 136, 100, "Pas de statistique disponible", $noir); 
		
		header("Content-type: image/png");
		
		$fond = imagecolorallocate($img, 255, 255, 255);  

		imagecolortransparent($img, $fond);      

		imagepng($img);     


		imagedestroy($img); 
	} 

}
?>