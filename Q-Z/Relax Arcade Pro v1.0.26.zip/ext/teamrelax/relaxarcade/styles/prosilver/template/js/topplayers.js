function onComplete(responseText, textStatus) {
	$('#arcade_indicator').hide();
	if (textStatus == "error") {
		alert('Error!');
	}
}

function getTopvictories(url, start, place_topvict, nbvictprec, placetemp) {
	$('#arcade_indicator').show();
	$('#topvictories').load(url, {
		start: start,
		place_topvict: place_topvict,
		nbvictprec: nbvictprec,
		placetemp: placetemp
	}, onComplete);
}

function getToppoints(url, start, place_toppoints, nbpointsprec, placetemp2) {
	$('#arcade_indicator').show();
	$('#toppoints').load(url, {
		start: start,
		place_toppoints: place_toppoints,
		nbpointsprec: nbpointsprec,
		placetemp2: placetemp2
	}, onComplete);
}

function getTopultime(url, start, place_topultime, nbultimeprec, placetemp3) {
	$('#arcade_indicator').show();
	$('#ultimetop').load(url, {
		start: start,
		place_topultime: place_topultime,
		nbultimeprec: nbultimeprec,
		placetemp3: placetemp3
	}, onComplete);
}

function reAlert(content) {
	phpbb.alert('', content);
}

function showModalBox(url, uid) {
	$.get(url, {uid: uid}, reAlert);
}

jQuery(function($) {
	$('#phpbb_alert').on('click', '.pagination.relaxarcade-ajax a', function(e) {
		e.preventDefault();
		$.get(this.href, reAlert);
	});
});
