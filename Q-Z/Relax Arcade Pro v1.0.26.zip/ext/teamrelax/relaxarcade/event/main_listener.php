<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class main_listener implements EventSubscriberInterface
{
	/* @var user */
	protected $user;

	/** @var template */
	protected $template;

	/** @var config */
	protected $config;

	/** @var db_interface */
	protected $db;

	/** @var helper */
	protected $helper;

	/** @var request_interface */
	protected $request;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

		/** @var bool */
	public $is_phpbb32;
	/** @var bool */
	public $is_phpbb31;
	
	/**
 	 * Constructor
	 *
	 * @param user				$user
	 * @param template			$template
	 * @param config			$config
	 * @param db_interface		$db
	 * @param helper			$helper
	 * @param request_interface	$request
	 * @param string			$root_path
	 * @param string			$php_ext
	 */
	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->user			= $user;
		$this->template		= $template;
		$this->config		= $config;
		$this->db			= $db;
		$this->helper		= $helper;
		$this->request		= $request;
		$this->root_path	= $root_path;
		$this->php_ext		= $php_ext;
		$this->is_phpbb31	= phpbb_version_compare($config['version'], '3.1.0@dev', '>=') && phpbb_version_compare($config['version'], '3.2.0@dev', '<');
		$this->is_phpbb32	= phpbb_version_compare($config['version'], '3.2.0@dev', '>=') && phpbb_version_compare($config['version'], '3.3.0@dev', '<');
		$this->template->assign_vars(array(
			'IS_PHPBB31' => $this->is_phpbb31,
			'IS_PHPBB32' => $this->is_phpbb32,
		));
	}

	/**
	 * @return array
	 */
	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'						=> 'user_setup',
			'core.index_modify_page_title'			=> 'index_modify_page_title',
			'core.delete_user_after'				=> 'delete_user_after',
			'core.ucp_prefs_personal_data'			=> 'ucp_prefs_personal_data',
			'core.ucp_prefs_personal_update_data'	=> 'ucp_prefs_personal_update_data',
			'core.ucp_prefs_modify_common'			=> 'ucp_prefs_modify_common',
			'core.viewtopic_post_rowset_data'				=> 'viewtopic_post_rowset_data',
			'core.viewtopic_modify_post_row'				=> 'viewtopic_modify_post_row',
			'core.memberlist_view_profile'					=> 'memberlist_view_profile',
			'core.page_header'								=> 'page_header',

		
		);
	}
	

	
	
	public function page_header($event)
	{
		


		
		
		if ((!defined('RA_SCORES_TABLE') &&  (!defined('RA_GAMESTAT_TABLE'))))
		{
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		}
		
			if (!empty($this->config['ra_active_zero'])){
				list($endDate,$endTime) = explode(' ', $this->config['ra_active_zero']);
				list($endYear,$endMonth,$endDay) = explode('/',$endDate);
				list($endHrs,$endMin,$endSec) = explode(':',$endTime);
				$now = strtotime("now");				
				$then = strtotime("$endYear/$endMonth/$endDay $endHrs:$endMin:$endSec"); 

				if ($now > $then){
					$sqla = 'TRUNCATE ' . RA_SCORES_TABLE;
					$this->db->sql_query($sqla);
					
					$sqlb = 'UPDATE ' . RA_GAMESTAT_TABLE . ' SET gamestat_user_id = 0, gamestat_highscore = 0, gamestat_highdate = 0';
					$this->db->sql_query($sqlb);
					
					$this->config->set('ra_active_zero', '');	
					
				
					
							
				}
				
			if ($now < $then){
								
					$this->template->assign_vars( array(
						'S_RA_ACTIVE_ZERO' => true,
						'RA_ACTIVE_ZERO'			=> $this->config['ra_active_zero'],
					));
			}
			
			else
			{
				$this->template->assign_vars( array(
					'S_RA_ACTIVE_ZERO' => false,
				));
			}
		}
		else
		{
			$this->template->assign_vars( array(
				'S_RA_ACTIVE_ZERO' => false,
			));
		}			
			
	}

	/**
	 *
	 * @param Event $event
	 */
	public function user_setup($event)
	{
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'teamrelax/relaxarcade',
			'lang_set' => 'relaxarcade',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	
		$ra_cat_id = $this->request->variable('cid', 0);
		$this->template->assign_vars(array(
			'VERSION_RELAXARCADE'		=> $this->config['ra_version'],
			'S_BLOC_TWO'		=> (!empty($this->config['bloc_two_three'])) ? false : true,
			'IS_RELAXINDEX'			=> true,
			'U_RELAXARCADE'		=> $this->helper->route('teamrelax_relaxarcade_page_list'),
			'U_RA_TOPPLAYERS'	=> $this->helper->route('teamrelax_relaxarcade_page_topplayers'),
			'U_RA_TOPPLAYERSCAT'	=> $this->helper->route('teamrelax_relaxarcade_page_topplayers_category', array('cid' => $ra_cat_id)),
			'U_TOP_PLAYERS' => $this->helper->route('teamrelax_relaxarcade_page_topplayers'),
			'U_NEW_GAMES' => $this->config['ra_last_installed'] ? $this->helper->route('teamrelax_relaxarcade_page_games_new') : '',
			'U_FAV_GAMES' => $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark')),
			'S_EQUIPE_TOURNOI' => $this->config['equipe_tournoi'] ? true : false,
		));
	}

	
	
	public function memberlist_view_profile($event)
	{
		
		if ((!defined('RA_SCORES_TABLE') &&  (!defined('RA_GAMESTAT_TABLE'))))
		{
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		}
		
		$member = $event['member'];
		$user_id = $member['user_id'];
	
		$sql = "SELECT COUNT(s.game_id) AS nbvictories, s.user_id
			FROM " . RA_SCORES_TABLE . " s,	" . RA_GAMESTAT_TABLE . " st
			WHERE st.game_id = s.game_id
    		AND st.gamestat_highscore = s.score_game
    		AND s.user_id  = '$user_id' ";
			$result = $this->db->sql_query($sql);	
			$row = $this->db->sql_fetchrow($result);
			$victories = $row['nbvictories'];	
			
		$this->template->assign_vars(array(
			'S_VICTORY'			=> ($victories > 0 ) ? true : false,
			'VICTORY'			=> $victories,
			'U_RA_PRIZE' => $this->helper->route('teamrelax_relaxarcade_page_prize'),
			'UID' => $user_id,
		));
			
			
	}
	
	
	public function viewtopic_post_rowset_data($event)
	{
		if ((!defined('RA_SCORES_TABLE') &&  (!defined('RA_GAMESTAT_TABLE'))))
		{
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		}
		
		$rowset_data = $event['rowset_data'];
		$row = $event['row'];
		$poster_id = $event['row']['poster_id'];
		
		$nbvictories = (empty($nbvictories)) ? array() : $nbvictories;
	
		if (empty($nbvictories[$poster_id]))
		{
			
			$sql = "SELECT COUNT(s.game_id) AS nbvictories, s.user_id
			FROM " . RA_SCORES_TABLE . " s,	" . RA_GAMESTAT_TABLE . " st
			WHERE st.game_id = s.game_id
    		AND st.gamestat_highscore = s.score_game
    		AND s.user_id  = '$poster_id' ";
			$result = $this->db->sql_query($sql);	
			$nbvictories_row = $this->db->sql_fetchrow($result);
			$nbvictories[$poster_id] = ($nbvictories_row['nbvictories']) ? $nbvictories_row['nbvictories'] : '0';
			$nbvictories_row = '';
		}
		
		$nbvictories = (empty($nbvictories)) ? array() : $nbvictories;

		$rowset_data = array_merge($rowset_data, array(
		'nbvictories'		=> $nbvictories[$poster_id],
		));
	
	$event['rowset_data'] = $rowset_data;
	}

	public function viewtopic_modify_post_row($event)
	{
		$row = $event['row'];
		$user_poster_data = $event['user_poster_data'];
		$post_row = $event['post_row'];
		$post_id = (int) $row['post_id'];
		$poster_id = (int) $event['poster_id'];
		
		$post_row = array_merge($post_row, array(
			'S_VICTORY'			=> ($row['nbvictories'] > 0 ) ? true :false,
			'VICTORY'			=> $row['nbvictories'],
			'U_RA_PRIZE' => $this->helper->route('teamrelax_relaxarcade_page_prize'),
			'UID' => $poster_id,
		));
	
	$event['post_row'] = $post_row;
	}
	
	
	
	
	/**
	 * @param Event $event
	 */
	public function index_modify_page_title($event)
	{
		$this->assign_top_players();
		$this->assign_latest_games();
		$this->assign_topchamp_players();
		$this->assign_display_challenge();

	}
	
	protected function assign_display_challenge()
	{
		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
		
			if ((!defined('RA_GAMES_TABLE'))  && (!defined(' RA_SCORES_TABLE')))
		{
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		}
		if (!function_exists('nom_sans_ext'))
		{
			include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		}
		
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
		
		$games = array();				
		

		$sql_array = array(
			'SELECT'	=> 'g.game_id,g.game_name,g.game_scoretype, g.game_desc, g.game_pic, g.game_swf, g.us_score_game, g.us_user_id, g.us_score_date,g.game_html5,a.gamestat_set',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(

				array(
					'FROM' => array(RA_GAMESTAT_TABLE => 'a'),
					'ON' => 'g.game_id = a.game_id',
				)
			),
			
			'WHERE'      => 'g.game_id = ' . (int)$this->config['challenge_day'],
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);		
		$result = $this->db->sql_query($sql);
		$games = $this->db->sql_fetchrow($result);
		$challenge_day = (int)$this->config['challenge_day'];
		$challenge_index = (int)$this->config['active_challenge'];
		
		if ($challenge_day && $challenge_index)
		{
		
		$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.*, u.username,u.user_avatar_width,u.user_avatar_height, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, g.game_name',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($games['game_scoretype'] == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id'
				),
					array(
					'FROM'	=> array(RA_GAMES_TABLE => 'g'),
					'ON'	=> 'g.game_id = s1.game_id'
				)
			),
			'WHERE'		=> 's1.game_id = ' . (int) $challenge_day,
			'GROUP_BY'	=> 's1.user_id',
			'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 5,  0);
		$score_rowset = array();
		$gamename = '';
		$total_score = 0;

		while( false !== ($row = $this->db->sql_fetchrow($result)))
		{
			$score_rowset[] = $row;
		
			$total_score++;
		}
		$this->db->sql_freeresult($result);
		if( $games['game_html5'] == 0 || ! $games['game_html5']){
			$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif( $games['game_html5'] == 1){
			$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$info = '';
			}
		
			$this->template->assign_vars( array(					
				'CHALLENGE_GAME_NAME' => $info.'<br/><a href="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('gid' => $games['game_id'])) . '">' . stripslashes($games['game_name']) . '</a>',
				'CHALLENGE_GAME_LINK' =>'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $games['game_id'])) . '">' . $this->user->lang('SEE_SCORES') . '</a>',
				'ICON_CHALLENGE_DAY' =>'<img src="' . $ra_theme_basepath . '/images/icon_challenge.png" alt="challenge" width="25" height="22" />',
				'CHALLENGE_GAMEDESC' => $games['game_desc'],
				'CHALLENGE_PART' =>$games['gamestat_set'] != 0 ? $this->user->lang('GAME_NBSET') . ' : ' . $games['gamestat_set'] : '',
				
				'CHALLENGE_GAMEPIC' =>'<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $games['game_id'])) . '"><img  class="imggrrelax" src="' . generate_board_url() . '/arcade/games/' . nom_sans_ext($games['game_swf']) . '/pics/' . $games['game_pic'] . '" width="80px" height="60px" alt="' . $games['game_name'] . '" title="' . $games['game_name'] . '" /></a>' ,
				));

		for($i = 0; $i < $total_score; $i++)
			{
				
				$display_avatar = $this->user->optionget('viewavatars');	
			
				$user_avatars[$score_rowset[$i]['user_id']] = !$display_avatar || !$score_rowset[$i]['user_avatar'] ? '' : phpbb_get_user_avatar(array(
					'avatar'		=> $score_rowset[$i]['user_avatar'],
					'avatar_type'	=> $score_rowset[$i]['user_avatar_type'],
					'avatar_width'	=> $score_rowset[$i]['user_avatar_width'] >= $score_rowset[$i]['user_avatar_height'] ? 40 : 0,
					'avatar_height'	=>$score_rowset[$i]['user_avatar_width'] >= $score_rowset[$i]['user_avatar_height'] ? 0 : 40,
				));
				
				
				$this->template->assign_block_vars('challenger', array(
					'POS' => '<img src="' . $ra_theme_basepath . '/images/icon_challenge.png" alt="challenge" width="23" height="20" />',					
					'CHALLENGE_DAY_CHAMPION_AVATAR' =>($score_rowset[$i]['user_avatar']) ? $user_avatars[$score_rowset[$i]['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="40" height="40" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',
					
					'CHALLENGE_DAY_POINTS' =>$score_rowset[$i]['score_game']+ 0,
					'CHALLENGE_DATE' => date("d/m/Y H:i",$score_rowset[$i]['score_date']),
					'S_CHALLENGE_DAY_CHAMPION' => isset($score_rowset[$i]['user_id']) ?  true : false,
					'CHALLENGE_DAY_CHAMPION_NAME' => get_username_string('full',$score_rowset[$i]['user_id'],$score_rowset[$i]['username'],$score_rowset[$i]['user_colour'],$score_rowset[$i]['username']),
				));
		
			}			
			
				$this->template->assign_vars( array(
					'S_CHALLENGE_DAY' => true,
					'S_CHALLENGE_INDEX' => true,
				));
		
			}
			else
			{
				$this->template->assign_vars( array(
					'S_CHALLENGE_DAY' => false,
					'S_CHALLENGE_INDEX' => false,
				));
			}
		
		
		
	}	
	
	protected function display_avatars()
	{
		return $this->user->optionget('viewavatars');
	}
	
		

	
			function point_equipecat($ra_cat_id)
		{
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);

		// equipe exclus ACP
		$exclude_equipe_config = '';
		if ( $this->config['mc_no_equipe'])
		{
			$exclude_equipe_config = ' AND ' . $this->db->sql_in_set('gr.group_id', explode(',',  $this->config['mc_no_equipe']), true);
		}
		// equipe exclus ACP
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
			//recuperation victory groupes
			$sql_array = array(
				'SELECT' => 'COUNT(s.game_id) AS nbvictories,u.group_id, s.user_id, u.username, u.user_colour',
				'FROM' => array(
					RA_SCORES_TABLE => 's',
					RA_GAMESTAT_TABLE => 'st',
					RA_GAMES_TABLE  => 'g',
					USERS_TABLE => 'u',
				),
				'WHERE' => 's.game_id = g.game_id AND st.game_id = s.game_id
					AND st.gamestat_highscore = s.score_game
					AND s.user_id = u.user_id AND g.ra_cat_id = ' . $ra_cat_id,
					'LEFT_JOIN' => array(
								array(
							'FROM' => array(GROUPS_TABLE => 'gr'),
							'ON' => 'gr.group_id = u.group_id')
					),
				'GROUP_BY' => 'gr.group_id',
				'ORDER_BY' => 'nbvictories DESC, gr.group_id ASC',
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
			$cup_tab = Array();	
			while ($row = $this->db->sql_fetchrow($result))
				{
					
					$cup_tab[$row['group_id']] = $row['nbvictories'] ;
				}
				$this->db->sql_freeresult($result);


					// Affichage de la liste des points equipe avec egalitée
				 $a = 0;  
				   $b = 0;
				   $c = 0;
						
		
			$sql_array = array(
							'SELECT'	=> 'u.user_id,u.group_id, u.username, u.user_colour, SUM(score_points) AS pts,count(DISTINCT u.group_id), gr.group_name, gr.group_id, gr.group_colour, gr.group_type',
							'FROM'		=> array(
								USERS_TABLE		=> 'u',
								RA_GAMES_TABLE	=> 'g',
								RA_SCORES_TABLE	=> 's',
							),
							
							'LEFT_JOIN' => array(
								array(
							'FROM' => array(GROUPS_TABLE => 'gr'),
							'ON' => 'gr.group_id = u.group_id')
					),
					'WHERE'		=>' u.user_id = s.user_id AND s.game_id = g.game_id'. $exclude_equipe_config.' AND g.ra_cat_id = ' . (int) $ra_cat_id,
							'GROUP_BY'	=> 'gr.group_id',
							'ORDER_BY'	=> 'pts DESC',
						);
							$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query($sql);
					
					$equipe = array();
					
						while ($row = $this->db->sql_fetchrow($result))
						{
							$equipe[] = $row;
						}  
				
					$ptsNbr = sizeof($equipe);
				 

			for ($i=0 ; $i< $ptsNbr; $i++)
				{
						

						if ($equipe[$i]['pts'] != $b){$a++;}
					$colour_text = ($equipe[$i]['group_colour']) ? ' style="color:#' . $equipe[$i]['group_colour'] . '"' : '';
					$group_name =  ($equipe[$i]['group_type'] == GROUP_SPECIAL) ? $this->user->lang['G_' . $equipe[$i]['group_name']] : $equipe[$i]['group_name'];
				
				
				   $this->template->assign_block_vars('equipe', array(
					 					  
					  'POINT'      =>  $equipe[$i]['pts'],
					  'RANG'      =>   $a,
					  'ICON_CAM' =>'<img src="' . $ra_theme_basepath . '/images/cam.png" alt="Répartitions" width="16" height="14" />',
					  'UCAM' => $this->helper->route('teamrelax_relaxarcade_page_cabembert', array('g' => $equipe[$i]['group_id'])),
					  'NBVICTORIES' =>empty($cup_tab[ $equipe[$i]['group_id']]) ? '0' : $cup_tab[ $equipe[$i]['group_id']],
					  'GROUPE'      =>'<a' . $colour_text . ' href="' . append_sid("{$this->root_path}memberlist.".$this->php_ext, 'mode=group&amp;g=' . $equipe[$i]['group_id']) . '">' . $group_name . '</a>'
				   ));
					   $b = $equipe[$i]['pts']; 
					  
				}

		}
	

	function point_equipe()
		{
				$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		// equipe exclus ACP
		$exclude_equipe_config = '';
		if ( $this->config['mc_no_equipe'])
		{
			$exclude_equipe_config = ' AND ' . $this->db->sql_in_set('gr.group_id', explode(',',  $this->config['mc_no_equipe']), true);
		}
		// equipe exclus ACP
			$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
		//recuperation victory groupes
			$sql_array = array(
				'SELECT' => 'COUNT(s.game_id) AS nbvictories,u.group_id, s.user_id, u.username, u.user_colour',
				'FROM' => array(
					RA_SCORES_TABLE => 's',
					RA_GAMESTAT_TABLE => 'st',
					USERS_TABLE => 'u',
				),
				'WHERE' => 'st.game_id = s.game_id
					AND st.gamestat_highscore = s.score_game
					AND s.user_id = u.user_id',
					'LEFT_JOIN' => array(
								array(
							'FROM' => array(GROUPS_TABLE => 'gr'),
							'ON' => 'gr.group_id = u.group_id')
					),
				'GROUP_BY' => 'gr.group_id',
				'ORDER_BY' => 'nbvictories DESC, gr.group_id ASC',
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
			$cup_tab = Array();	
			while ($row = $this->db->sql_fetchrow($result))
				{
					
					$cup_tab[$row['group_id']] = $row['nbvictories'] ;
				}
				$this->db->sql_freeresult($result);

					// Affichage de la liste des points equipe avec egalitée
				 $a = 0;  
				   $b = 0;
				   $c = 0;		
				$sql_array = array(
							'SELECT'	=> 'u.user_id,u.group_id, u.username, u.user_colour, SUM(score_points) AS pts,count(DISTINCT u.group_id), gr.group_name, gr.group_id, gr.group_colour, gr.group_type',
							'FROM'		=> array(
								USERS_TABLE		=> 'u',
								RA_GAMES_TABLE	=> 'g',
								RA_SCORES_TABLE	=> 's',
							),
							
							'LEFT_JOIN' => array(
								array(
							'FROM' => array(GROUPS_TABLE => 'gr'),
							'ON' => 'gr.group_id = u.group_id')
					),
					'WHERE'		=> 'u.user_id = s.user_id AND s.game_id = g.game_id'. $exclude_equipe_config,
							'GROUP_BY'	=> 'gr.group_id',
							'ORDER_BY'	=> 'pts DESC',
						);
					$sql = $this->db->sql_build_query('SELECT', $sql_array);

					$result = $this->db->sql_query($sql);
					
					$equipe = array();				
						while ($row = $this->db->sql_fetchrow($result))
						{
							$equipe[] = $row;
						}  
				
				$ptsNbr = sizeof($equipe);
				for ($i=0 ; $i< $ptsNbr; $i++)
				{

					if ($equipe[$i]['pts'] != $b){$a++;}
					$colour_text = ($equipe[$i]['group_colour']) ? ' style="color:#' . $equipe[$i]['group_colour'] . '"' : '';
					$group_name =  ($equipe[$i]['group_type'] == GROUP_SPECIAL) ? $this->user->lang['G_' . $equipe[$i]['group_name']] : $equipe[$i]['group_name'];
										
				 
					
				   $this->template->assign_block_vars('equipe', array(
					
					  'POINT'      =>  $equipe[$i]['pts'],
					  'RANG'      =>   $a,
					  'ICON_CAM' =>'<img src="' . $ra_theme_basepath . '/images/cam.png" alt="Répartitions" width="16" height="14" />',
					  'UCAM' => $this->helper->route('teamrelax_relaxarcade_page_cabembert', array('g' => $equipe[$i]['group_id'])),
					  'NBVICTORIES' =>empty($cup_tab[ $equipe[$i]['group_id']]) ? '0' : $cup_tab[ $equipe[$i]['group_id']],
					  'GROUPE'      =>'<a' . $colour_text . ' href="' . append_sid("{$this->root_path}memberlist.".$this->php_ext, 'mode=group&amp;g=' . $equipe[$i]['group_id']) . '">' . $group_name . '</a>'
				   ));
					   $b = $equipe[$i]['pts'];
				
						
					
					   
				}
				
				
				
				
					

		}
	
	
	
	
	protected function assign_topchamp_players()
	{
		if ($this->config['ra_top_point'] <= 0)
		{
			return;
		}
		
		if ((!defined('RA_GAMES_TABLE')) && (!defined(' RA_SCORES_TABLE')))
		{
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		}
		
		// equipe exclus ACP
		$exclude_equipe_config = '';
		if ( $this->config['mc_no_equipe'])
		{
			$exclude_equipe_config = ' AND ' . $this->db->sql_in_set('u.group_id', explode(',',  $this->config['mc_no_equipe']), true);
		}
		// equipe exclus ACP
		
		$ra_cat_id = $this->config['ra_top_classement_points_category'];
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
		if( $ra_cat_id == -1 )
				{
					$sql_array = array(
						'SELECT'	=> 'u.group_id, u.user_id, u.username, u.user_colour, SUM(score_points) AS total_points',
						'FROM'		=> array(
							USERS_TABLE		=> 'u',
							RA_GAMES_TABLE	=> 'g',
							RA_SCORES_TABLE	=> 's',
						),
						'WHERE'		=> 'u.user_id = s.user_id AND s.game_id = g.game_id'. $exclude_equipe_config,
						'GROUP_BY'	=> 's.user_id HAVING total_points > 0',
						'ORDER_BY'	=> 'total_points DESC',
					);
						$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, $this->config['ra_top_point']);

			$tovict_imgs = array(
				1 => '1st.gif',
				2 => '2nd.gif',
				3 => '3rd.gif',
				4 => '4th.gif',
				5 => '5th.gif',
				6 => '6rd.gif',
				7 => '7rd.gif',
				8 => '8rd.gif',
				9 => '9rd.gif',
				10 => '10rd.gif',
				11 => '11rd.gif',
				12 => '12rd.gif',
				13 => '13rd.gif',
				14 => '14rd.gif',
				15 => '15rd.gif',
			);

			$placetemp3 = 0;
			$nbpointsprec3 = 0;
			$place_toppoints3 = 0;
			while ($row = $this->db->sql_fetchrow($result))
			{
				$placetemp3++;

				if ($nbpointsprec3 <> $row['total_points'])
				{
					$place_toppoints3 = $placetemp3;
					$nbpointsprec3 = $row['total_points'];
				}

				$this->template->assign_block_vars('categorie_row', array(
					'CLASSEMENT' => $place_toppoints3,
					'PLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
					'IMG' => isset($tovict_imgs[$placetemp3]) ? ($ra_theme_basepath . '/images/' . $tovict_imgs[$placetemp3]) : '',
					'TOTALPOINTS' => $row['total_points'],
				));
			}
			$this->db->sql_freeresult($result);
			$this->point_equipe();
			$this->template->assign_vars(array(
				'TOUTECATEGORIE' =>  $this->user->lang('TOUTE_CATEGORIE'),
				'S_TOUTECATEGORIE' => true,
				'U_TOP_CLASSEMENT_CAT' => true,
			));
		}
		if ($ra_cat_id)
		{
			$sql_array = array(
				'SELECT'	=> 'u.group_id,u.user_id, u.username, u.user_colour, SUM(score_points) AS total_points',
				'FROM'		=> array(
					USERS_TABLE		=> 'u',
					RA_GAMES_TABLE	=> 'g',
					RA_SCORES_TABLE	=> 's',
				),
				'WHERE'		=> 'u.user_id = s.user_id AND s.game_id = g.game_id'. $exclude_equipe_config.' AND g.ra_cat_id = ' . (int) $ra_cat_id,
				'GROUP_BY'	=> 's.user_id HAVING total_points > 0',
				'ORDER_BY'	=> 'total_points DESC',
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, $this->config['ra_top_point']);

			$tovict_imgs = array(
				1 => '1st.gif',
				2 => '2nd.gif',
				3 => '3rd.gif',
				4 => '4th.gif',
				5 => '5th.gif',
				6 => '6rd.gif',
				7 => '7rd.gif',
				8 => '8rd.gif',
				9 => '9rd.gif',
				10 => '10rd.gif',
				11 => '11rd.gif',
				12 => '12rd.gif',
				13 => '13rd.gif',
				14 => '14rd.gif',
				15 => '15rd.gif',
			);

			$placetemp3 = 0;
			$nbpointsprec3 = 0;
			$place_toppoints3 = 0;
			while ($row = $this->db->sql_fetchrow($result))
			{
				$placetemp3++;

				if ($nbpointsprec3 <> $row['total_points'])
				{
					$place_toppoints3 = $placetemp3;
					$nbpointsprec3 = $row['total_points'];
				}

				$this->template->assign_block_vars('categorie_row', array(
					'CLASSEMENT' => $place_toppoints3,
					'PLAYER' => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
					'IMG' => isset($tovict_imgs[$placetemp3]) ? ($ra_theme_basepath . '/images/' . $tovict_imgs[$placetemp3]) : '',
					'TOTALPOINTS' => $row['total_points'],
				));
			}
			$this->db->sql_freeresult($result);
 $this->point_equipecat($ra_cat_id);
			$this->template->assign_vars(array(
				'TOPCHP' =>(!empty($this->config['enable_tournoi'])) ? $this->user->lang('RA_TOP_CHP') : $this->user->lang('CHAMPIONSHIP_POINTS'),
				'U_TOP_CLASSEMENT_CAT' => $this->helper->route('teamrelax_relaxarcade_page_topplayers_category', array('cid' => $ra_cat_id)),
			));
		}
		
	}

	protected function assign_top_players()
	{
		if ($this->config['ra_top_leader'] <= 0)
		{
			return;
		}

		if ((!defined('RA_SCORES_TABLE')) && (!defined('RA_GAMESTAT_TABLE')))
		{
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		}

		$sql_array = array(
			'SELECT' => 'COUNT(s.game_id) AS nbvictories, s.user_id, u.username, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height',
			'FROM' => array(
				RA_SCORES_TABLE => 's',
				RA_GAMESTAT_TABLE => 'st',
				USERS_TABLE => 'u',
			),
			'WHERE' => 'st.game_id = s.game_id
    			AND st.gamestat_highscore = s.score_game
    			AND s.user_id = u.user_id',
			'GROUP_BY' => 's.user_id, u.username',
			'ORDER_BY' => 'nbvictories DESC, s.user_id ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, (int) $this->config['ra_top_leader']);

		
			$place = 0;
			$nbpointsprec = 0;
			$place_topvict = 0;
			while ($row = $this->db->sql_fetchrow($result))
			{
				$place++;

				if ($nbpointsprec <> $row['nbvictories'])
				{
					$place_topvict = $place;
					$nbpointsprec = $row['nbvictories'];
				}

				$display_avatar = $this->user->optionget('viewavatars');	
			
				$user_avatars[$row['user_id']] = !$display_avatar || !$row['user_avatar'] ? '' : phpbb_get_user_avatar(array(
					'avatar'		=> $row['user_avatar'],
					'avatar_type'	=> $row['user_avatar_type'],
					'avatar_width'	=> $row['user_avatar_width'] >= $row['user_avatar_height'] ? 28 : 0,
					'avatar_height'	=> $row['user_avatar_width'] >= $row['user_avatar_height'] ? 0 : 28,
				));	
				
					$this->template->assign_block_vars('victories_row', array(
					'VICT_CHAMPION_AVATAR' =>($row['user_avatar']) ? $user_avatars[$row['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="28" height="28" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',
	
					'CLASSEMENT'	=> $place,
					'UID' => $row['user_id'],
					'U_RA_PRIZE' => $this->helper->route('teamrelax_relaxarcade_page_prize'),
					'PLAYER'		=> get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
					'NBVICTORIES'	=> $row['nbvictories'],
				));
				
				$this->template->assign_vars(array(
				'S_VICTORY'			=> ($this->config['ra_top_leader'] > 0 ) ? true : false,
				));
				
				if ($place >= $this->config['ra_top_leader'])
				{
				break;
				}
			}
			$this->db->sql_freeresult($result);
	}

	protected function assign_latest_games()
	{
		
		
		

		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';
		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
	
		

		if (!function_exists('arcade_auth'))
		{
			include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);
		}

		if (!function_exists('nom_sans_ext'))
		{
			include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		}
		if (!function_exists('arcade_view_playing'))
		{
			include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);
		}
		
		
		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);
		$liste_cat = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);
		$is_auth_ary = arcade_auth(AUTH_VIEW, AUTH_LIST_ALL, $liste_cat);

		//
		// Affichage du qui joue
		$is_admin = $this->user->data['session_admin'] && $this->user->data['is_registered'] && $this->user->data['user_id'] != ANONYMOUS;
		$tab_player = arcade_view_playing($is_auth_ary);
		if ($tab_player !== false && isset($tab_player[0]))
		{
			$nb_players = count($tab_player);
			for ($i = 0; $i < $nb_players; $i++)
			{
				if ($tab_player[$i]['user_allow_viewonline'] || $is_admin)
				{
					$this->template->assign_block_vars('arcadeplaying_row', array(
						'GAMENAME' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $tab_player[$i]['gid'])) . '">' . $tab_player[$i]['gamename'] . '</a>' . ' : ',
						'PLAYERLIST' => $tab_player[$i]['playerlist'],
					));
				}
			}
		}
		else
		{
			$this->template->assign_block_vars('arcadeplaying_row', array(
				'GAMENAME' => $this->user->lang('ARCADE_NOPLAYING'))
			);
		}
		
		 $total_games =  $total_parts =	 $played_total_times = '';
		
		//Nombre total de parties jouées
		$sql = 'SELECT SUM(gamestat_set) as total_parts 
			FROM ' . RA_GAMESTAT_TABLE; 
		$result = $this->db->sql_query($sql);
		if ($row = $this->db->sql_fetchrow($result))
		{
		if (!is_null($row['total_parts']))
		{
		$total_parts = $row['total_parts']; 
		}
		$this->db->sql_freeresult($result);
		}

		//Temps total de parties jouées
		$sql = 'SELECT SUM(score_time) as played_total_times 
			FROM ' . RA_SCORES_TABLE; 
		$result = $this->db->sql_query($sql);
		if ($row = $this->db->sql_fetchrow($result))
		{
		if (!is_null($row['played_total_times']))
		{
		$played_total_times = arcade_time($row['played_total_times']);
		}
		$this->db->sql_freeresult($result);
		}
		
		
		//Nombre total de jeux
		$sql = 'SELECT SUM(ra_cat_nbgames) as total_games
			FROM ' . RA_CAT_TABLE;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);
		$total_games = $row && !is_null($row['total_games']) ? $row['total_games'] : 0;

		
		$this->template->assign_vars(array(
		'S_STAT_INDEX' => ( $this->config['enable_lastgames']) ? true : false,
		'S_ENABLE_LASTGAMES' =>($this->config['ra_der_index'] > 0) ? true : false,
		'TOTAL_GAMES' => $total_games,
		'TOTAL_PARTS' => $total_parts,
		'PLAYED_TIME' => $played_total_times,
		));
		
	
		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_order ASC';
		$result = $this->db->sql_query($sql);
		$liste_cat = $this->db->sql_fetchrowset($result);

		$nbcat = count($liste_cat);
		$j = 0;
		$is_auth_ary = arcade_auth(AUTH_VIEW, AUTH_LIST_ALL, $liste_cat);
		$liste_cat_auth = array();
		for ($i = 0; $i < $nbcat; $i++)
		{
			$arcade_cid = (int) $liste_cat[$i]['ra_cat_id'];
			if ($is_auth_ary[$arcade_cid]['ra_cat_auth_view'])
			{
				$liste_cat_auth[$j] = $liste_cat[$i];
				$j++;
			}
		}

		$nbcat_auth = count($liste_cat_auth);
		
		
		$i = 0;

		$this->template->assign_vars(array(
		'S_VOIR_CATS' =>$this->config['ra_voir_cats'] ? true : false,
		'S_POS_CATS' =>$this->config['ra_voir_poscats'] ? true : false,
		'S_DEF_CATS' =>($this->config['ra_voir_nbcats']<= 8) ? false : true,
		
		));
		
		while ($i <  $this->config['ra_voir_nbcats'])
		{
	
				
				$cat_href = isset($liste_cat_auth[$i]['ra_cat_id']) ? $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $liste_cat_auth[$i]['ra_cat_id'])) : false;
				if(!empty($liste_cat_auth[$i]['ra_cat_nbgames']))
				{	
				if(strlen($liste_cat_auth[$i]['ra_cat_title']) > 10 )
				{
					$namecourt = substr($liste_cat_auth[$i]['ra_cat_title'], 0, 10).'...';    // limite 
				}
				else
				{
					$namecourt = $liste_cat_auth[$i]['ra_cat_title'];
				}
				
				
					$this->template->assign_block_vars('arcadecat', array(
					'CAT_CHAMP'   =>($this->display_cat_champ($liste_cat_auth[$i]['ra_cat_id']))  ?  $this->display_cat_champ($liste_cat_auth[$i]['ra_cat_id'])  :     $this->user->lang['RA_NOCHAMP_CATS'] ,
				    'ARCADE_CAT_PIC'   => !empty($liste_cat_auth[$i]['ra_cat_pic']) ? '<a href="' . $cat_href . '#cat">' . '<img src="' . generate_board_url() . '/arcade/pics_cat/' . $liste_cat_auth[$i]['ra_cat_pic'] . '" title="' . $liste_cat_auth[$i]['ra_cat_title'] . '" alt="' . $liste_cat_auth[$i]['ra_cat_title'] . '" /></a>' : '',
				   'CAT'            => $cat_href ? '<a href="' . $cat_href . '#cat">' . $namecourt . '</a>' : '',
				   'NB_GAMES'         => !empty($liste_cat_auth[$i]['ra_cat_nbgames']) ? '(' . $liste_cat_auth[$i]['ra_cat_nbgames'] . ')&nbsp;'.$this->user->lang('GAMES') : '',
				   'CAT_CLASS'       => $liste_cat_auth[$i]['ra_cat_class'] ? ('<a href="' . $this->helper->route('teamrelax_relaxarcade_page_topplayers_category', array('cid' => $liste_cat_auth[$i]['ra_cat_id'])) . '">' . $this->user->lang('RA_CLASS_CAT') . '</a>') : '<br />',
					));		
				}	
				
		
		$i++;

		}
		
		
		
		
		$liste_sql_cat_auth = '';
		if ($nbcat_auth > 0)
		{
			$liste_sql_cat_auth = '(';
			for ($i = 0; $i < $nbcat_auth; $i++)
			{
				if ($i == 0)
				{
					$liste_sql_cat_auth .= $liste_cat_auth[$i]['ra_cat_id'];
				}
				else
				{
					$liste_sql_cat_auth .= ',' . $liste_cat_auth[$i]['ra_cat_id'];
				}
			}
			$liste_sql_cat_auth .= ')';
		}
		unset($liste_cat_auth);
			
	
	

			$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';


		
		if ($liste_sql_cat_auth && (int)$total_games > 0 )
		{
			
		$sql_array = array(
			'SELECT' => 'g.game_id, g.game_name, g.game_pic, gamestat_set, g.game_html5',
			'FROM' => array(
				RA_GAMESTAT_TABLE => 's',
			),
			'LEFT_JOIN' => array(
				array(
					'FROM' => array(RA_GAMES_TABLE => 'g'),
					'ON' => 's.game_id = g.game_id',
				)
			),
			'WHERE' => 's.gamestat_set AND g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'ORDER_BY' => 'g.game_id DESC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql,$this->config['ra_der_index'],0);

		while (false !== ($row = $this->db->sql_fetchrow($result)))
		{
			if($row['game_html5'] == 0 || !$row['game_html5']){
			$infos = '<img class="ra_arcade_desc" src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif($row['game_html5'] == 1){
			$infos = '<img class="ra_arcade_desc" src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$infos = '';
			}
			if($row['game_html5'] == 0 || !$row['game_html5']){
			$info = '<img style="text-align: center;margin-top:5px;display: inline-block;"  width="15px" height="15px" src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif($row['game_html5'] == 1){
			$info = '<img style="text-align: center;margin-top:5px;display: inline-block;"  width="15px" height="15px" src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$info = '';
			}
	
		
			$this->template->assign_block_vars('last_playrow', array(
				'LAST_PLAYGAME' => $row['game_name'],
				'LAST_PLAYGAMETYPES' =>'<a style="margin-top:5px" href="'.$this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])).'" >'.$row['game_name'].'<br/>'.$info.'</a>',
				'GAME_TYPES'	=>$infos,
				'LAST_GAMEPIC' => generate_board_url() . '/arcade/games/' . nom_sans_ext($row['game_pic']) . '/pics/' . $row['game_pic'],
				'LAST_GAMELINK' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $row['game_id'])),
				'LAST_PLAYNB' => $row['gamestat_set'],
			));
		}


		$this->template->assign_vars(array(
			'DER_GAMES' => $this->config['ra_der_index'],
			'TOTAL_GAMES' => $total_games,
			));
		
		}
	}

	function display_cat_champ($cat)
	{
	
	
		// Compte du nombre de premières places par joueur (prise en compte des égalités)
		$sql_array = array(
			'SELECT'	=> 'COUNT(s.game_id) AS nbvictories, s.user_id, u.username, u.user_colour,s.score_date',
			'FROM'		=> array(
				RA_SCORES_TABLE		=> 's',
				RA_GAMESTAT_TABLE	=> 'st',
				RA_GAMES_TABLE  => 'g',
				USERS_TABLE			=> 'u'
			),
			'WHERE'		=> 's.game_id = g.game_id AND st.game_id = s.game_id
							AND st.gamestat_highscore = s.score_game
							AND s.user_id = u.user_id AND g.ra_cat_id = ' . $cat,
			'GROUP_BY'	=> 's.user_id, u.username',
			'ORDER_BY'	=> 'nbvictories DESC, s.user_id ASC, s.score_date ASC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 1, 0);
		$champion = '';
		while ($row = $this->db->sql_fetchrow($result))
		{
				
			
			$champion =	 $this->user->lang['RA_CHAMP_CATS'] .'<br/>'.   get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']) .'<a href="#"  onclick="showModalBox(\''.$this->helper->route('teamrelax_relaxarcade_page_prizecat', array('c' => $cat)).'\','. $row['user_id'].'); return false;">&nbsp;('.$row['nbvictories'].')</a>';




		}
		$this->db->sql_freeresult($result);
	
	
		
		return $champion;

	
	}
	
	
	
	
	
	
	
	/**
	 * @param Event $event
	 */
	public function delete_user_after($event)
	{
		if (!function_exists('arcade_user_delete'))
		{
			$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

			include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
			include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		}

		foreach ($event['user_ids'] as $user_id)
		{
			$this->arcade_user_delete($user_id);
		}
	}

	/**
	 * @param Event $event
	 */
	public function ucp_prefs_personal_data($event)
	{
		$event['data'] = array_merge($event['data'], array(
			'allowrapm' => $this->request->variable('allowrapm', (bool) $this->user->data['user_allow_rapm'])
		));
	}

	/**
	 * @param Event $event
	 */
	public function ucp_prefs_personal_update_data($event)
	{
		$event['sql_ary'] = array_merge($event['sql_ary'], array(
			'user_allow_rapm' => $event['data']['allowrapm'],
		));
	}

	/**
	 * @param Event $event
	 */
	public function ucp_prefs_modify_common($event)
	{
		$this->user->add_lang_ext('teamrelax/relaxarcade', 'relaxarcade_ucp');
		$this->template->assign_var('S_ALLOW_RAPM', $event['data']['allowrapm']);
	}

	/**
	 * @param $user_id
	 */
	protected function arcade_user_delete($user_id)
	{
		//Tableau contenant les id des jeux pour lesquels les points sont à recalculer
		$sql_array = array(
			'SELECT' => 'g.game_id, g.game_name, g.game_scoretype, s.user_id, gs.gamestat_user_id',
			'FROM' => array(RA_GAMES_TABLE => 'g'),
			'LEFT_JOIN' => array(
				array(
					'FROM' => array(RA_SCORES_TABLE => 's'),
					'ON' => 's.game_id = g.game_id'
				), array(
					'FROM' => array(RA_GAMESTAT_TABLE => 'gs'),
					'ON' => 's.user_id = gs.gamestat_user_id AND s.game_id = gs.game_id'
				)
			),
			'WHERE' => 's.user_id = ' . (int) $user_id . ' AND s.score_points > 0',
			'ORDER_BY' => 'g.game_id',
		);
		$sql_tab = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql_tab);

		$tab_games = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$tab_games[] = $row;
		}
		$this->db->sql_freeresult($result);
		$nb_games = sizeof($tab_games);

		//Suppression des scores du user
		$sql = 'DELETE FROM ' . RA_SCORES_TABLE . '
			  WHERE user_id = ' . (int) $user_id;
		$this->db->sql_query($sql);

		if ($nb_games > 0)
		{
			reset($tab_games);
			for ($i = 0; $i < $nb_games; $i++)
			{
				$gid = $tab_games[$i]['game_id'];
				$game_scoretype = $tab_games[$i]['game_scoretype'];
				$sql_array = array(
					'SELECT' => 's1.user_id, (count(s2.user_id)+1) position',
					'FROM' => array(RA_SCORES_TABLE => 's1'),
					'LEFT_JOIN' => array(
						array(
							'FROM' => array(RA_SCORES_TABLE => 's2'),
							'ON' => ($game_scoretype == 0) ? '(s1.game_id = s2.game_id AND s1.score_game < s2.score_game)' : '(s1.game_id = s2.game_id AND s1.score_game > s2.score_game)',
						),
					),
					'WHERE' => 's1.game_id = ' . $gid,
					'GROUP_BY' => 's1.user_id HAVING position <= 8',
					'ORDER_BY' => 'position'
				);
				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);

				while (false !== ($row = $this->db->sql_fetchrow($result)))
				{
					$sql = 'UPDATE ' . RA_SCORES_TABLE . '
							SET score_points = ' . (int) arcade_points($row['position']) . '
							WHERE game_id = ' . (int) $gid . '
							AND user_id = ' . (int) $row['user_id'];
					$this->db->sql_query($sql);
				}
				$this->db->sql_freeresult($result);

				//Mise à jour des highscores
				if (!is_null($tab_games[$i]['gamestat_user_id']))
				{
					if ($game_scoretype == 0)
					{
						$sql = 'SELECT user_id, score_game, score_date
								FROM ' . RA_SCORES_TABLE . '
								WHERE game_id = ' . (int) $gid . '
								ORDER BY score_game DESC, score_date ASC LIMIT 0,1';
					} else
					{
						$sql = 'SELECT user_id, score_game, score_date
								FROM ' . RA_SCORES_TABLE . '
								WHERE game_id = ' . (int) $gid . '
								ORDER BY score_game ASC, score_date ASC LIMIT 0,1';
					}
					$result = $this->db->sql_query($sql);
					$rows = $this->db->sql_fetchrowset($result);
					$this->db->sql_freeresult($result);

					if ($rows)
					{
						foreach ($rows as $row)
						{
							$sql_data = array(
								'gamestat_user_id'		=> $row['user_id'],
								'gamestat_highscore'	=> $row['score_game'],
								'gamestat_highdate'		=> $row['score_date'],
							);
							$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . '
									SET ' . $this->db->sql_build_array('UPDATE', $sql_data) . '
									WHERE game_id = ' . (int) $gid;
							$this->db->sql_query($sql);
						}
					}
					else
					{
						$sql = 'DELETE FROM ' . RA_GAMESTAT_TABLE . '
								WHERE game_id = ' . (int) $gid;
						$this->db->sql_query($sql);
					}
				}
				$i++;
			}
		}
		unset($tab_games);

		//Suppression des scores du user
		$sql = 'DELETE FROM ' . RA_CHEATERS_TABLE . '
			  WHERE user_id = ' . (int)$user_id;
		$this->db->sql_query($sql);

		//Passage des votes du user en user anonymous
		$sql = 'UPDATE ' . RA_GAME_RATING_TABLE . ' SET user_id = ' . ANONYMOUS . ' WHERE user_id = ' . (int)$user_id;
		$this->db->sql_query($sql);
	}
}
