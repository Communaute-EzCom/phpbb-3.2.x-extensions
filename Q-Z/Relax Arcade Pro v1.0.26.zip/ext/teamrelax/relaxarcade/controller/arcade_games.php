<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_games
{
	/** @var user */
	protected $user;

	/** @var config */
	protected $config;

	/** @var request_interface */
	protected $request;

	/** @var db_interface */
	protected $db;

	/** @var template */
	protected $template;

	/** @var helper */
	protected $helper;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->user				= $user;
		$this->config			= $config;
		$this->request			= $request;
		$this->db				= $db;
		$this->template			= $template;
		$this->helper			= $helper;
		$this->root_path		= $root_path;
		$this->php_ext			= $php_ext;
	}

	public function handle()
	{
		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);
		include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);

	

		// Contrôle restriction arcade
		if ($this->user->data['user_type'] != USER_FOUNDER)
		{
			arcade_access_game();
		}

		// Arcade fermé ?
		$gid = $this->request->variable('gid', 0);

		if ($this->config['arcade_close'] && $this->user->data['user_type'] != USER_FOUNDER)
		{
			$message = $this->user->lang('INFO_ARCADE_CLOSE') . '<br /><br />' . $this->user->lang('RETURN_INDEX', '<a href="' . append_sid($this->root_path . "index." . $this->php_ext) . '">', '</a>');
			trigger_error($message);
		}

		if (!$gid)
		{
		   trigger_error($this->user->lang('RA_NO_GID'));
		}
		
		if ($this->request->variable('action', '') === 'del' && $this->user->data['user_type'] == USER_FOUNDER)
		{
			$user = $this->request->variable('user', 0);
			$this->ra_scores_delete($gid, $user);
			redirect($this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $gid)));
		}
		
		//Infos sur le jeu
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.ra_cat_id, g.game_name, g.game_desc, g.game_cont, g.game_html5, g.game_pic, g.game_swf, g.game_scoretype, g.game_width, g.game_height, g.game_bgcolor,
							u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar_width, u.user_avatar_height, u.user_avatar, st.gamestat_highscore, st.gamestat_highdate, b.game_id as fav',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_GAMESTAT_TABLE => 'st'),
					'ON'	=> 'g.game_id = st.game_id'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'st.gamestat_user_id = u.user_id'
				),
				array(
					'FROM' => array(RA_BOOKMARKS_TABLE => 'b'),
					'ON' => 'g.game_id = b.game_id AND b.user_id = ' . (int) $this->user->data['user_id']
				),
			),
			'WHERE'		=> 'g.game_id = '. $gid,
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);

		$rowgame = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$rowgame)
		{
			trigger_error($this->user->lang('RA_NO_GAME'));
		}

		$highscore_type = $rowgame['game_scoretype'];
		$arcade_cat_id = $rowgame['ra_cat_id'];
		// Affichage du champion
		$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.score_game, s1.score_date, u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($highscore_type == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id'
				)
			),
			'WHERE'		=> 's1.game_id = ' . $gid,
			'GROUP_BY'	=> 's1.user_id',
			'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 1);
		$rowtop = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);
	
		$username = get_username_string('full', $rowtop['user_id'], $rowtop['username'], $rowtop['user_colour']);
		$gamestat_highscore = $rowtop['score_game'];
		$gamestat_highdate = $rowtop['score_date'];
	
		if (!isset($rowtop)){
		$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . '
		 SET gamestat_user_id = 0, gamestat_highscore = 0,  gamestat_highdate = 0
		 WHERE game_id = ' . (int)$gid;
		$result = $this->db->sql_query($sql);			
		}
		if ($rowtop)
		{
		$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . '
		 SET gamestat_user_id = ' . $rowtop['user_id'] . ', gamestat_highscore = '. $rowtop['score_game'] .',  gamestat_highdate = '. $rowtop['score_date'] .'
		 WHERE game_id = ' . (int)$gid;
		$result = $this->db->sql_query($sql);
		}
		// Meilleur de score de tous les temps
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.ra_cat_id, g.game_name, g.game_desc, g.game_pic, g.game_swf, g.game_scoretype, g.game_width, g.game_height, g.game_bgcolor, g.us_score_game, g.us_user_id, g.us_score_date,
							u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height',
			'FROM'		=> array(
				RA_GAMES_TABLE	=> 'g'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'g.us_user_id = u.user_id'
				)
			),
			'WHERE'      => 'g.game_id = ' . (int) $gid,
			'ORDER_BY'	=> 'g.us_score_date DESC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 1,  0);
		$rowgame_us = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$rowgame_us)
		{
			trigger_error($this->user->lang('RA_NO_GAME'));
		}

		$usernameus = get_username_string('full', $rowgame_us['user_id'], $rowgame_us['username'], $rowgame_us['user_colour']);
		// Meilleur de score de tous les temps

		$sql = 'SELECT * from ' . RA_CAT_TABLE . '
				WHERE ra_cat_id = ' . (int) $arcade_cat_id ;
		$result = $this->db->sql_query($sql);
		$arcade_cat_row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$arcade_cat_row)
		{
			trigger_error($this->user->lang('RA_GID_CAT_INC'));
		}

		//
		// Start auth check
		//
		$is_auth = arcade_auth(AUTH_PLAY, $arcade_cat_id);
		if (empty($is_auth['ra_cat_auth_play']))
		{
			trigger_error($this->user->lang('NOT_AUTHORISED'));
		}
		//
		// End auth check
		//
		
		// Déplace jeu
		$sql = 'SELECT ra_cat_id, ra_cat_title, ra_cat_nbgames
			FROM ' . RA_CAT_TABLE . '
			ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);

		while ($row = $this->db->sql_fetchrow($result))
		{
			$selected = $row['ra_cat_id'] == $arcade_cat_id ? ' selected="selected"' : '';
			$cat_url = '<option value="' . $row['ra_cat_id'] . '"' . $selected . '>' . $row['ra_cat_title'] . ' (' . $row['ra_cat_nbgames'] . ')</option>';
			$this->template->assign_block_vars('arcade_categories_select', array(
				'U_CATEGORIES_PLAY' => $cat_url
			));
		}
		$this->db->sql_freeresult($result);

		$this->template->assign_var('L_CAT_BOOKMARK', '<option>' . $this->user->lang('RA_FAV_GAMES') . '</option>');

		if ($this->request->is_set_post('do') && $this->request->is_set_post('g_id') && $this->request->is_set_post('arcade_categories_move'))
		{
			$g_id = $this->request->variable('g_id', 0);

			$sql = 'UPDATE ' . RA_CAT_TABLE . '
					SET ra_cat_nbgames = (ra_cat_nbgames-1)
					WHERE ra_cat_id = ' . (int) $arcade_cat_row['ra_cat_id'];
			$this->db->sql_query($sql);

			$sql = 'UPDATE ' . RA_CAT_TABLE . '
					SET ra_cat_nbgames = (ra_cat_nbgames+1)
					WHERE ra_cat_id = ' . (int) $this->request->variable('arcade_categories_move', 0);
			$this->db->sql_query($sql);

			$sql = 'UPDATE ' . RA_GAMES_TABLE . '
					SET ra_cat_id = ' . $this->request->variable('arcade_categories_move', 0) . '
					WHERE game_id = ' . (int) $g_id;
			$this->db->sql_query($sql);

			redirect($this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $g_id)));
		}
		// Déplace jeu
		// Affichage de la liste des 10 meilleurs scores
		$sql_array = array(
			'SELECT'	=> '(count(s2.user_id)+1) as position, s1.score_game, s1.score_date, u.username, u.user_id, u.user_colour',
			'FROM'		=> array(
				RA_SCORES_TABLE	=> 's1'
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(RA_SCORES_TABLE => 's2'),
					'ON'	=> ($highscore_type == 0) ? '(s1.score_game < s2.score_game and s1.game_id = s2.game_id)'
													  : '(s1.score_game > s2.score_game and s1.game_id = s2.game_id)'
				),
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 's1.user_id = u.user_id'
				)
			),
			'WHERE'		=> 's1.game_id = ' . $gid,
			'GROUP_BY'	=> 's1.user_id',
			'ORDER_BY'	=> 'position ASC, s1.score_date ASC',
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, 10);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		if ($this->user->data['user_type'] == USER_FOUNDER && $this->request->variable('action', '') === 'delultimescore' && $rows)
		{
			ra_scores_us_delete($gid, reset($rows), next($rows));
			redirect($this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $gid)));
		}

		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
		
		foreach ($rows as $row)
		{
			$usertop = get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']);
			$this->template->assign_block_vars('scorerow', array(
				'POS' => $row['position'],
				'PLAYER' => $usertop,
				'SCORE' => $row['score_game'] + 0,
				'U_DEL_UI' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('action' => 'del', 'gid' => $rowgame['game_id'], 'user' => $row['user_id'])) . '" onclick="return(confirm(\'Etes-vous sûr de vouloir supprimer ce score '. $row['score_game'] .' (' . $row['username'] . ')?\'));"><img src="' . $ra_theme_basepath . '/images/suppr.png" border="0" alt="' . $this->user->lang('DEL_SCORE') . '" title="' . $this->user->lang('DEL_SCORE') . '" /></a>',
			));
		}

		// Affichage du champion du jeu
		$display_avatar = $this->user->optionget('viewavatars');	
		$user_avatars[$rowtop['user_id']] = !$display_avatar || !$rowtop['user_avatar'] ? '' : phpbb_get_user_avatar(array(
			'avatar'		=> $rowtop['user_avatar'],
			'avatar_type'	=> $rowtop['user_avatar_type'],
			'avatar_width'	=> $rowtop['user_avatar_width'] >= $rowtop['user_avatar_height'] ? $this->config['avatar_maxsize'] : 0,
			'avatar_height'	=> $rowtop['user_avatar_width'] >= $rowtop['user_avatar_height'] ? 0 : $this->config['avatar_maxsize'],
			));
			
		$user_avatars[$rowgame_us['user_id']] = !$display_avatar || !$rowgame_us['user_avatar'] ? '' : phpbb_get_user_avatar(array(
			'avatar'		=> $rowgame_us['user_avatar'],
			'avatar_type'	=> $rowgame_us['user_avatar_type'],
			'avatar_width'	=> $rowgame_us['user_avatar_width'] >= $rowgame_us['user_avatar_height'] ? $this->config['avatar_maxsize'] : 0,
			'avatar_height'	=> $rowgame_us['user_avatar_width'] >= $rowgame_us['user_avatar_height'] ? 0 : $this->config['avatar_maxsize'],
			));	
		
		
		$sql = 'SELECT user_id
			FROM ' . RA_BOOKMARKS_TABLE . '
			WHERE user_id = ' . (int)$this->user->data['user_id'];
			$result = $this->db->sql_query($sql);
			$favories = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);
			
		// Build navigation links
		
		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME'		=> $this->user->lang('ARCADE_PAGE'),
			'U_VIEW_FORUM'	=> $this->helper->route('teamrelax_relaxarcade_page_list'),
		));
		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME'		=> $arcade_cat_row['ra_cat_title'],
			'U_VIEW_FORUM'	=> $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $arcade_cat_row['ra_cat_id'])),
		));
		$this->template->assign_block_vars('navlinks', array(
			'FORUM_NAME'		=> $rowgame['game_name'],
			'U_VIEW_FORUM'	=> $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $rowgame['game_id'])),
		));
		

		if($rowgame['game_cont'] == 0 || !$rowgame['game_cont']){
		$bulle_info = $this->user->lang['CONTROLES_INCONNUS'];
		}elseif($rowgame['game_cont'] == 1){
		$bulle_info = $this->user->lang['CLAVIER_UNIQUEMENT'];
		}elseif($rowgame['game_cont'] == 2){
		$bulle_info = $this->user->lang['SOURIS_UNIQUEMENT'];
		}elseif($rowgame['game_cont'] == 3){
		$bulle_info = $this->user->lang['CLAVIER_SOURIS'];
		}else{
		$bulle_info = '';
		}
		if($rowgame['game_html5'] == 0 || !$rowgame['game_html5']){
			$info = '<img src="' . $ra_theme_basepath . '/images/flash.png" alt="'.$this->user->lang['JEUX_FLASH'].'" />';
			}elseif($rowgame['game_html5'] == 1){
			$info = '<img src="' . $ra_theme_basepath . '/images/html.png" alt="'.$this->user->lang['JEUX_HTML5'].'" />';
			}else{
			$info = '';
			}
	
		$ra_theme_basepath = generate_board_url() . '/ext/teamrelax/relaxarcade/styles/prosilver/theme';
		global $phpbb_container;
		if ($this->config['ra_mchat_games'] && $phpbb_container->has('dmzx.mchat.settings'))
		{
			
			if ($phpbb_container->has('dmzx.mchat.settings'))
			{
			   // We use the page_index() method to render mChat so we need
			   // to enable mChat on the index page only for this request
			   $this->user->data['user_mchat_index'] = 1;
			   $phpbb_container->get('dmzx.mchat.settings')->set_cfg('mchat_index', 1, true);
			   $phpbb_container->get('dmzx.mchat.core')->page_index();
			   $this->template->assign_var('MCHAT_PAGE', 'mchat_on_arcade_page_games');
			}
		}
		
		
		
		$this->template->assign_vars(array(
			'S_RELAX_BUG' =>$this->config['ra_disable_forum_id'] ? true : false,
			'S_RA_MCHAT_GAMES' =>$this->config['ra_mchat_games'] ? true : false,
			'U_RELAXBUG' => $this->helper->route('teamrelax_relaxarcade_page_bug', array('gid' => $rowgame['game_id'],'name'=>$rowgame['game_name'])),
			'IS_RELAX' =>true,
			'IS_RELAXINDEX' =>false,
			'FAV_GAMES' => ($favories) ? true : false,
			'U_RELAXARCADE' => $this->helper->route('teamrelax_relaxarcade_page_list'),
			'L_ARCADE' => $this->user->lang('ARCADE_PAGE'),
			'IMGBOOKMARK' => is_null($rowgame['fav']) ? '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark', 'gid' => $rowgame['game_id'])) . '"><img src="' . $ra_theme_basepath . '/images/ra_favoris.png" title="' . $this->user->lang('RA_FAV_ADD_GAME') . '" alt="' . $this->user->lang('RA_FAV_ADD_GAME') . '" /></a>' : '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('mode' => 'bookmark', 'gid' => $rowgame['game_id'])) . '"><img src="' . $ra_theme_basepath . '/images/ra_fav_del.png" title="' . $this->user->lang('RA_FAV_DEL_GAME') . '" alt="'. $this->user->lang('RA_FAV_DEL_GAME') . '" /></a>',
			'U_CAT' => $this->helper->route('teamrelax_relaxarcade_page_list', array('cid' => $arcade_cat_row['ra_cat_id'])),
			'L_CAT' => $arcade_cat_row['ra_cat_title'],
			'GAME_ID' => $rowgame['game_id'],
			'GAME_DESCRIPTION' => htmlspecialchars_decode($rowgame['game_desc']),
			'GAME_DESC' => $this->user->lang('DESC_GAME'),
			'GAME_CONTROLE'	=> '<img src="' . generate_board_url() . '/arcade/pics_controle/' . $rowgame['game_cont'] . '.png" title="' . $bulle_info . '" alt="' . $bulle_info . '" />',
			'GAME_NAME' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_list', array('gid' => $rowgame['game_id'])) . '">' . $rowgame['game_name'] . '</a>',
			'GAME_NAME_NOLINK' => $rowgame['game_name'],
			'GAME_TYPE'	=>$info,
			'GAME_TYPEJEU_EXPLAIN'	=> $rowgame['game_html5'],
			'GAME_LIBCHAMPION' => $this->user->lang('GAME_CHAMPION'),
			'SCORE_ULTIME_L' => $this->user->lang['SCORE_ULTIME'],
			'PLAYER_ULTIME' => ($rowgame_us['us_score_game'] == 0) ? $this->user->lang('NO_RECORD') : ($rowgame_us['us_score_game'] + 0).'&nbsp;('.$usernameus.')<br />'.  $this->user->format_date($rowgame_us['us_score_date']),
			'AVATAR_CHAMPION_SU' =>($rowgame_us['user_avatar']) ? $user_avatars[$rowgame_us['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="'.$this->config['avatar_maxsize'].'" height="'.$this->config['avatar_maxsize'].'" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',
        	'AVATARCHAMPION_SU' =>($rowgame_us['us_score_game'] == 0) ? false : true,
			'L_GAME_CHAMPION_SU' => $rowgame_us['username'],        	
			'U_DEL_US' => $this->user->data['user_type'] == USER_FOUNDER && $rowgame_us['us_score_game'] > 0 ? '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('action' => 'delultimescore', 'gid' => $rowgame['game_id'])) . '"  onclick="return(confirm(\'Etes-vous sûr de vouloir supprimer ce score ultime '. $rowgame_us['us_score_game'] .' (' . $rowgame_us['username'] . ') ?\'));" /><img src="' . $ra_theme_basepath . '/images/suppr.png" border="0" alt="' . $this->user->lang('DEL_SCORE') . '" title="' . $this->user->lang('DEL_SCORE') . '" /></a>' : '',
			'L_BESTSCORES' => $this->user->lang('BESTSCORES'),
			'AVATARCHAMPION' =>($gamestat_highscore == 0) ? false : true,
			'AVATAR_CHAMPION' =>($rowtop['user_avatar']) ? $user_avatars[$rowtop['user_id']] : '<img src="'.generate_board_url() . '/styles/'.$this->user->style['style_path'].'/theme/images/no_avatar.gif" width="'.$this->config['avatar_maxsize'].'" height="'.$this->config['avatar_maxsize'].'" alt="' . ((!empty($this->user->lang['USER_AVATAR'])) ? $this->user->lang['USER_AVATAR'] : '') . '" />',
			'L_GAME_CHAMPION' => $rowgame['username'],
			'U_MOD' => '<a href="' . append_sid($this->root_path . 'adm/index.' . $this->php_ext . '?i=-teamrelax-relaxarcade-acp-acp_relaxarcade_module&amp;mode=manage&amp;action=game&amp;gaction=gameedit&amp;c=' . $arcade_cat_id . '&amp;gid=' . $rowgame['game_id'] . '&amp;sid=' . $this->user->data["session_id"]) . '">' . $this->user->lang('MOD_SCORE') . '</a>',
			'CHAMP_PLAYER' => ($gamestat_highscore == 0) ? $this->user->lang('NO_SCORE') : ($gamestat_highscore + 0) .'&nbsp;('. $username.')<br />'. $this->user->format_date($gamestat_highdate),
			'L_ARCADE_PLAYING' => $this->user->lang('ARCADEPLAYING'),
			'U_THIS_GAME' => $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $rowgame['game_id'])),
		));
		
		

		$sql = 'SELECT game_id
				FROM ' . RA_GAMESTAT_TABLE . '
				WHERE game_id = ' . (int)$gid;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		if (!isset($row['game_id']))
		{
			$sql_ary = array(
				'game_id'			=> $gid,
				'gamestat_set'		=> 1,
			);
			$this->db->sql_query('INSERT INTO ' . RA_GAMESTAT_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
		}
		else
		{
			$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . '
					SET gamestat_set = gamestat_set + 1
					WHERE game_id = ' . (int)$gid;
			$this->db->sql_query($sql);
		}

		//Enregistrement de la session du jeu
		ra_sess_init($gid, $arcade_cat_id, $rowgame['game_name']);

		$this->template->assign_vars(array(
			'SWF_GAME' => generate_board_url() . '/arcade/games/' . nom_sans_ext($rowgame['game_swf']) . '/' . $rowgame['game_swf'],
			'GAME_WIDTH' => $rowgame['game_width'] ,
			'GAME_HEIGHT' => $rowgame['game_height'] ,
			'GAME_BGCOLOR' => $rowgame['game_bgcolor'],
			'IMGPLUS' => '<img src="' . $ra_theme_basepath . '/images/ra_plus.png" alt="Agrandir" title="Augmenter la taille du jeu" onclick="increasesize()" />',
			'IMGMOINS' => '<img src="' . $ra_theme_basepath . '/images/ra_moins.png" alt="Diminuer" title="Diminuer la taille du jeu" onclick="decreasesize()" />',
			'IMGRAZ' => '<img src="' . $ra_theme_basepath . '/images/ra_raz.png" alt="RAZ" title="Retourner à la taille d’origine" onclick="razsize()" />',
			'IMGRELOAD' => '<img src="' . $ra_theme_basepath . '/images/ra_reload.png" alt="Recharger" title="Recharger le jeu" onclick="location.reload()" />',
			'IMGFULLSCREEN' => '<img src="' . $ra_theme_basepath . '/images/fullscreenmini.png" alt="fullscreen" title="jeu plein ecran" onclick="toggleFullScreen();" />',
			'L_GAME' => $rowgame['game_name']
		));

		// Liste des catégories
		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);
		$liste_cat = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$is_auth_ary = arcade_auth(AUTH_VIEW, AUTH_LIST_ALL, $liste_cat);

		//
		// Affichage du qui joue
		$is_admin = $this->user->data['session_admin'] && $this->user->data['is_registered'] && $this->user->data['user_id'] != ANONYMOUS;
		$tab_player = arcade_view_playing($is_auth_ary);
		if ($tab_player !== false && isset($tab_player[0]))
		{
			$nb_players = count($tab_player);
			for ($i = 0; $i < $nb_players; $i++)
			{
				if ($tab_player[$i]['user_allow_viewonline'] || $is_admin)
				{
					$this->template->assign_block_vars('arcadeplaying_row', array(
						'GAMENAME' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $tab_player[$i]['gid'])) . '">' . $tab_player[$i]['gamename'] . '</a>' . ' : ',
						'PLAYERLIST' => $tab_player[$i]['playerlist'],
					));
				}
			}
		}
		else
		{
			$this->template->assign_block_vars('arcadeplaying_row', array(
				'GAMENAME' => $this->user->lang('ARCADE_NOPLAYING'))
			);
		}

		return $this->helper->render('arcade_games_body.html', $this->user->lang('ARCADE_GAME'));
	}

	protected function ra_scores_delete($game, $user)
	{
		if (!$user)
		{
			$sql = 'DELETE FROM ' . RA_SCORES_TABLE . ' WHERE game_id = ' . (int) $game;
			$this->db->sql_query($sql);

			$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . '
          		SET gamestat_user_id = 0, gamestat_highscore = NULL, gamestat_highdate = 0
          		WHERE game_id = ' . (int) $game;
			$this->db->sql_query($sql);
		}
		else
		{
			$sql = 'DELETE FROM ' . RA_SCORES_TABLE . '
				WHERE game_id = ' . (int) $game . '
					AND user_id = ' . (int) $user;
			$this->db->sql_query($sql);

			$sql = 'SELECT * FROM ' . RA_GAMES_TABLE . '
				WHERE game_id = ' . (int) $game;
			$result = $this->db->sql_query($sql);
			$row = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			if ($row)
			{
				$order = $row['game_scoretype'] == 0 ? 'DESC' : 'ASC';

				$sql = 'SELECT * FROM ' . RA_GAMESTAT_TABLE . '
					WHERE game_id = ' . (int) $game;
				$result = $this->db->sql_query($sql);
				$row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				if ($row['gamestat_user_id'] == $user)
				{
					$sql = 'SELECT * FROM ' . RA_SCORES_TABLE . '
						WHERE game_id = ' . (int) $game . '
						ORDER BY score_game ' . $order;
					$result = $this->db->sql_query_limit($sql, 1);
					$row = $this->db->sql_fetchrow($result);
					$this->db->sql_freeresult($result);

					if ($row)
					{
						$gamestat_highscore = $row['score_game'];
						$gamestat_highdate = (int) $row['score_date'];
						$gamestat_user_id = (int) $row['user_id'];
					}
					else
					{
						$gamestat_highscore = 0;
						$gamestat_highdate = 0;
						$gamestat_user_id = 0;
					}

					$sql = 'UPDATE ' . RA_GAMESTAT_TABLE . '
              			SET gamestat_user_id = "' . $gamestat_user_id . '", gamestat_highscore = ' . $gamestat_highscore . ', gamestat_highdate = "' . $gamestat_highdate . '"
              			WHERE game_id = ' . (int) $game;
					$this->db->sql_query($sql);
				}
			}
		}
	}
}