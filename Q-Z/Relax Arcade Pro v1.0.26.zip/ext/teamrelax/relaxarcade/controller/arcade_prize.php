<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_prize
{
	/** @var user */
	protected $user;

	/** @var config */
	protected $config;

	/** @var request_interface */
	protected $request;

	/** @var db_interface */
	protected $db;

	/** @var template */
	protected $template;

	/** @var pagination */
	protected $pagination;

	/** @var helper */
	protected $helper;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\pagination $pagination,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext
	)
	{
		$this->user = $user;
		$this->config = $config;
		$this->request = $request;
		$this->db = $db;
		$this->template = $template;
		$this->pagination = $pagination;
		$this->helper = $helper;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function handle()
	{
		$ext_path = $this->root_path . 'ext/teamrelax/relaxarcade/';

		include($ext_path . 'arcade/includes/constants.' . $this->php_ext);
		include($ext_path . 'arcade/includes/ra_common.' . $this->php_ext);
		include($ext_path . 'arcade/includes/functions_arcade.' . $this->php_ext);
		include($ext_path . 'arcade/includes/arcade_auth.' . $this->php_ext);

	

		if ($this->user->data['user_id'] == ANONYMOUS)
		{
			login_box('', $this->user->lang('LOGIN_EXPLAIN_RATOPPLAYERS'));
		}

		// Arcade fermé ?
		if ($this->config['arcade_close'] && $this->user->data['user_type'] != USER_FOUNDER)
		{
			$message = $this->user->lang('INFO_ARCADE_CLOSE') . '<br /><br />' . $this->user->lang('RETURN_INDEX', '<a href="' . append_sid($this->root_path . "index." . $this->php_ext) . '">', '</a>');
			trigger_error($message);
		}

		$start = $this->request->variable('start', 0);
		$uid = $this->request->variable('uid', 0);

		if (!$uid)
		{
			$this->template->assign_vars(array(
				'MESSAGE_TITLE'	=> $this->user->lang('INFORMATION'),
				'MESSAGE_TEXT'	=> 'Missing user ID',
			));

			return $this->helper->render('message_body.html');
		}

		$sql = 'SELECT *
				FROM ' . RA_CAT_TABLE . '
				ORDER BY ra_cat_order';
		$result = $this->db->sql_query($sql);

		$liste_cat = $this->db->sql_fetchrowset($result);
		$nbcat = count($liste_cat);
		$this->db->sql_freeresult($result);

		if (!$nbcat)
		{
			trigger_error($this->user->lang('RA_NO_CAT'));
		}

		//
		// Recherche des catégories visibles pour l'utilisateur
		//
		$is_auth_ary = arcade_auth(AUTH_VIEW, AUTH_LIST_ALL, $liste_cat);
		$liste_cat_auth = array();
		for ($i = 0; $i < $nbcat; $i++)
		{
			$arcade_cid = $liste_cat[$i]['ra_cat_id'];
			if ($is_auth_ary[$arcade_cid]['ra_cat_auth_view'])
			{
				$liste_cat_auth[] = $liste_cat[$i];
			}
		}
		$nbcat_auth = count($liste_cat_auth);
		unset($liste_cat);

		// Créer une condition sql à partir du tableau liste_cat_auth
		$liste_sql_cat_auth = '';
		if ($nbcat_auth > 0)
		{
			$liste_sql_cat_auth = '(';
			for ($i = 0; $i < $nbcat_auth; $i++)
			{
				if ($i == 0)
				{
					$liste_sql_cat_auth .= $liste_cat_auth[$i]['ra_cat_id'];
				}
				else
				{
					$liste_sql_cat_auth .= ',' . $liste_cat_auth[$i]['ra_cat_id'];
				}
			}
			$liste_sql_cat_auth .= ')';
		}
		unset($liste_cat_auth);

		// Total des premières places du joueur
		$sql_array = array(
			'SELECT'	=> 'COUNT(s.game_id) AS nbvictories',
			'FROM'		=> array(
				RA_SCORES_TABLE		=> 's',
				RA_GAMESTAT_TABLE	=> 'st',
				USERS_TABLE			=> 'u'
			),
			'WHERE' => 'st.game_id = s.game_id
				AND st.gamestat_highscore = s.score_game
				AND s.user_id = u.user_id
				AND u.user_id = ' . (int) $uid,
		);
		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$total_games = $row !== false && isset($row['nbvictories']) ? $row['nbvictories'] : 0;
		$this->db->sql_freeresult($result);

		// Recherche des jeux où le joueur a obtenu une première place
		$sql_array = array(
			'SELECT' => 'g.game_id, g.game_name, g.game_desc, g.game_pic, g.game_swf, g.ra_cat_id, s.score_game,
							s.score_date, u.username, u.user_id, u.user_colour',
			'FROM' => array(
				RA_SCORES_TABLE		=> 's',
				RA_GAMESTAT_TABLE	=> 'st',
				RA_GAMES_TABLE		=> 'g',
				USERS_TABLE			=> 'u',
			),
			'WHERE' => 'st.game_id = s.game_id
				AND st.gamestat_highscore = s.score_game
				AND st.game_id = g.game_id
				AND s.user_id = u.user_id
				AND u.user_id = ' . (int) $uid .'
				AND g.ra_cat_id IN ' . $liste_sql_cat_auth,
			'GROUP_BY' => 's.score_date DESC',
		);

		$limit = 10;

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $limit, $start);

		$game_list = $this->db->sql_fetchrowset($result);
		$nbgames = sizeof($game_list);
		$this->db->sql_freeresult($result);

		if (!$nbgames)
		{
			trigger_error($this->user->lang('RA_PLAYER_NO_VICT'));
		}

		$username = get_username_string('full', $game_list[0]['user_id'], $game_list[0]['username'], $game_list[0]['user_colour']);

		$this->pagination->generate_template_pagination($this->helper->route('teamrelax_relaxarcade_page_prize', array('uid' => $uid)), 'pagination', 'start', $total_games, $limit, $start, true);

		$this->template->assign_vars(array(
			'USERNAME' => $username,
			'TOT_VICTORIES' => $total_games . ' ' . $this->user->lang($total_games > 1 ? 'NB_VICTORIES' : 'NB_VICTORIE'),
			'L_ARCADE_PRIZE' => $this->user->lang('ARCADE_PRIZE_OF'),
			'L_SCORE' => $this->user->lang('BOARDSCORE'),
			'L_DATE' => $this->user->lang('BOARDDATE'),
			'PLAYER' => $username,
			'L_GAME_DESC' => $this->user->lang('DESC_GAME'),
			'L_CHAMP_OF' => $this->user->lang('GAME_CHAMPION_OF'),
			'L_BASE_URL' => $this->helper->route('teamrelax_relaxarcade_page_topplayers'),
		));

		for ($i = 0; $i < $nbgames; $i++)
		{
			$gamename = $game_list[$i]['game_name'];

			$this->template->assign_block_vars('gamerow', array(
				'GAMENAME' => $gamename,
				'GAMEPIC' => $game_list[$i]['game_pic'] != '' ? '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $game_list[$i]['game_id'])) . '"><img src="' . generate_board_url() . '/arcade/games/' . nom_sans_ext($game_list[$i]['game_swf']) . '/pics/' . $game_list[$i]['game_pic'] . '" width="80px" height="60px" alt="' . $gamename . '" title="' . $gamename . '"></a>' : '',
				'GAMEDESC' => $game_list[$i]['game_desc'],
				'HIGHSCORE' => $game_list[$i]['score_game'] + 0,
				'GAMEID' => $game_list[$i]['game_id'],
				'DATEHIGH' => $this->user->format_date($game_list[$i]['score_date']),
				'GAMELINK' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $game_list[$i]['game_id'])) . '">' . $game_list[$i]['game_name'] . '</a>',
				'VOIRSCORES' => '<a href="' . $this->helper->route('teamrelax_relaxarcade_page_gamescores', array('gid' => $game_list[$i]['game_id'])) . '">' . $this->user->lang('SEE_SCORES') . '</a>',
			));
		}

		return $this->helper->render('arcade_prize.html');
	}
}
