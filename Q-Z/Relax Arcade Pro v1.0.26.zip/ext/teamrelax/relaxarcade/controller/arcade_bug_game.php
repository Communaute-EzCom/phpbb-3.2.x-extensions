<?php

/**
 *
 * @package phpBB Extension - Relax Arcade
 * @copyright (c) 2008 Ours - bigours@hotmail.fr
 * @copyright (c) 2016 Team Relax
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace teamrelax\relaxarcade\controller;


class arcade_bug_game
{
	/** @var config */
	protected $config;
	
	/** @var helper */
	protected $helper;	

	/** @var db_interface */
	protected $db;


	/** @var request_interface */
	protected $request;
	
	/** @var template */
	protected $template;

	/** @var user */
	protected $user;
	
	protected $auth;


	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var string */
	protected $ext_path;

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		$root_path,
		$php_ext
	)
	{
		$this->config 		= $config;
		$this->helper 		= $helper;
		$this->db 			= $db;
		$this->request 		= $request;
		$this->template 	= $template;		
		$this->user 		= $user;
		$this->auth 				= $auth;
		$this->root_path 	= $root_path;
		$this->php_ext 		= $php_ext;
	}

	public function handle()
	{

			$this->user->add_lang(array('posting'));
			include($this->root_path . 'includes/message_parser.' . $this->php_ext);
			$name 			= $this->request->variable('name', '', true);
			$gid   	=  $this->helper->route('teamrelax_relaxarcade_page_games', array('gid' => $this->request->variable('gid', '', true)));

			$submit 		= $this->request->is_set_post('post');
			$preview		= $this->request->is_set_post('preview');
			$sujet 			= utf8_normalize_nfc($name);
			$playname   	= utf8_normalize_nfc( $gid);
			$message 		=  '[list][b]' . $this->user->lang['PLAYNAME'] . '[/b][URL]' . $playname . '[/URL][/list]' ."\n\n".'[list][b]' . $this->user->lang['DEMANDE'] . '[/b]'. utf8_normalize_nfc( $this->request->variable('message', '', true))  ."\n\n". $this->user->lang['VOTRETITLE'].'[/list]';

			if (!function_exists('display_custom_bbcodes'))
			{
				include($this->root_path . 'includes/functions_display.' . $this->php_ext);
			}
			display_custom_bbcodes();
		
		
			if (!function_exists('generate_smilies'))
			{
				include($this->root_path . 'includes/functions_posting.' . $this->php_ext);
			}

			generate_smilies('inline', 0);

			$forum_id = $this->config['ra_forum_id']; 	// Forum ou inserer le message
			
			// Si l'utilisateur n'est pas logg�
			if (!$this->user->data['is_registered'] )
			{
				login_box();
			}
			if (!$this->config['ra_disable_forum_id'])
			{
				trigger_error('NOT_AUTHORISED');
			}
			// Build Navigation Links
			$sql = 'SELECT *
				FROM ' . FORUMS_TABLE . "
				WHERE forum_id = $forum_id";
			$result = $this->db->sql_query($sql);
			$post_data = $this->db->sql_fetchrow($result);
			generate_forum_nav($post_data);

			// Build Forum Rules
			generate_forum_rules($post_data);

			// HTML, BBCode, Smilies, Images and Flash status
			
				add_form_key('posting');
				$this->template->assign_vars(array(
					'S_POST_ACTION' 	=> append_sid("{$this->root_path}posting.".$this->php_ext, 'mode=post&f=' . $forum_id),
					'BBCODE_STATUS'			=> $this->user->lang('BBCODE_IS_ON', '<a href="' . append_sid("{$this->root_path}faq.{$this->php_ext}", 'mode=bbcode') . '">', '</a>'),
					'S_BBCODE_ALLOWED'				=> true,
					'S_SMILIES_ALLOWED'				=> true,
					'S_BBCODE_IMG'					=> true,
					'S_BBCODE_FLASH'				=> true,
					'S_LINKS_ALLOWED'				=> true,						
					'SUJET' 			=> $sujet,
					'PLAYNAME' 			=> $playname,
					'DEMANDE' 			=> $message));

				if ($submit || $preview)
				{

					$message_parser = new \parse_message();
					
					// check form
					if (!check_form_key('posting'))
					{
						$error[] = $this->user->lang['FORM_INVALID'];
					}	
					

					$message_parser->message = $message;

					// DNSBL check
					if ($config['check_dnsbl'] && !$refresh)
					{
						if (($dnsbl = $this->user->check_dnsbl('post')) !== false)
						{
							$error[] = sprintf($this->user->lang['IP_BLACKLISTED'], $this->user->ip, $dnsbl[1]);
						}
					}

					// Pas d'erreurs, let's go baby
					if (!$error && $submit)
					{
						// variables to hold the parameters for submit_post
						$poll = $uid = $bitfield = $options = '';
						
						generate_text_for_storage($playname, $uid, $bitfield, $options, false, false, false);
						generate_text_for_storage($message, $uid, $bitfield, $options, true, true, true);

						$data = array(
							'forum_id'			=> $forum_id,
							'icon_id'			=> false,
							'enable_bbcode'		=> (!$bbcode_status) ? false : true,
							'enable_smilies'	=> (!$smilies_status) ? false : true,
							'enable_urls'		=> true,
							'enable_sig'		=> (!$this->config['allow_sig']) ? false : true,
							'message'			=> $message,
							'message_md5'		=> md5($message),
							'attachment_data'	=> 0,
							'bbcode_bitfield'	=> $bitfield,
							'bbcode_uid'		=> $uid,
							'post_edit_locked'	=> 0,
							'topic_title'		=> $sujet,
							'notify_set'		=> false,
							'notify'			=> true,
							'forum_name'		=> '',
							'enable_indexing'	=> true,
						);

						$redirect_url = submit_post('post', $sujet, '', POST_NORMAL, $poll, $data);


						$message .= '<br /><br />' . sprintf($this->user->lang['RETURN_FORUM'], '<a href="' . append_sid("{$this->root_path}viewforum".$this->php_ext, 'f=' . $data['forum_id']) . '">', '</a>');
						trigger_error($message);

					}
					else
					{
						$this->template->assign_vars( array(
							'ERROR'	=> (isset($error)) ? implode('<br />', $error) : ''
						));
					}
				}
				
				page_header('', false);

				$this->template->set_filenames(array(
					'body' => 'arcade_bug_body.html')
				);

				page_footer();

	}
	
}	
?>