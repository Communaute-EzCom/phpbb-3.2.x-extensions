<?php
/**
 *
 * Topic/Post Reactions. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2017 Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACL_CAT_REACTIONS'			=> 'Réactions aux messages/sujets',
));

// Admin Permissions //0.6
$lang = array_merge($lang, array(
	'ACL_A_DELETE_REACTIONS'	=> 'Peut supprimer les réactions aux messages/sujets.',
));

// Moderator Permissions //0.6
$lang = array_merge($lang, array(
	'ACL_M_DELETE_REACTIONS'	=> 'Peut supprimer les réactions aux messages/sujets.',
));

// User Permissions	
$lang = array_merge($lang, array(
	'ACL_U_ADD_REACTIONS'				=> 'Peut réagir aux messages.',
	'ACL_U_CHANGE_REACTIONS'			=> 'Peut modifier les réactions.',	
	'ACL_U_DELETE_REACTIONS'			=> 'Peut supprimer les réactions.',
	'ACL_U_DISABLE_REACTIONS'			=> 'Peut désactiver l’extension « Topic/Post Reactions ».',
	'ACL_U_DISABLE_REACTION_TYPES'		=> 'Peut désactiver les types de réaction pour ses messages.',
	'ACL_U_DISABLE_POST_REACTIONS'		=> 'Peut désactiver les réactions pour ses messages.',
	'ACL_U_DISABLE_TOPIC_REACTIONS'		=> 'Peut désactiver les réactions aux messages de ses sujets.',
	'ACL_U_MANAGE_REACTIONS_SETTINGS'	=> 'Peut gérer les paramètres des réactions aux messages/sujets depuis le panneau de l’utilisateur.',
	'ACL_U_RESYNC_REACTIONS'			=> 'Peut resynchroniser les réactions des messages.',
	'ACL_U_VIEW_REACTIONS'				=> 'Peut voir les réactions.',
	'ACL_U_VIEW_REACTIONS_PAGE'			=> 'Peut voir la page des réactions.',
	'ACL_U_VIEW_POST_REACTIONS_PAGE'	=> 'Peut voir la page des réactions des messages.',
));
