<?php
/**
 *
 * Topic/Post Reactions. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2017 Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'UCP_ENABLE_REACTIONS'				=> 'Activer les réactions aux messages/sujets',
	'UCP_ENABLE_REACTIONS_EXPLAIN'		=> 'Permet d’activer ou de désactiver la possibilité de réagir aux messages, de permettre aux utilisateurs de réagir à vos messages, d’accéder à la page des réactions, de voir les compteurs de réactions &amp; de recevoir des notifications.',
	'UCP_DEFAULT_POST_SETTINGS'			=> 'Paramètres par défaut des réactions aux messages/sujets',
	'SELECT_REACTION_TYPES'				=> 'Réactions interdites aux utilisateurs concernant vos messages',
	'UCP_REACTIONS_SAVED'				=> 'Les paramètres des réactions aux messages/sujets ont été sauvegardés avec succès !',
	'UCP_REACTIONS_SETTING'				=> 'Paramètres',
	'UCP_REACTIONS_TITLE'				=> 'Réactions aux messages/sujets',
	'UCP_FOE_REACTIONS_ENABLE'			=> 'Activer les réactions aux ignorés',
	'UCP_FOE_REACTIONS_EXPLAIN'			=> 'Permet aux utilisateurs vous ayant mis sur leur liste des ignorés de réagir à vos messages.',	
	'UCP_POST_REACTIONS_ENABLE'			=> 'Activer par défaut les réactions à vos messages',
	'UCP_POST_REACTIONS_EXPLAIN'		=> 'Permet d’activer par défaut la possibilité aux utilisateurs de réagir à vos messages lors de la création d’un nouveau message. Cette option active les réactions pour tous vos messages présents et futurs, exceptés ceux pour lesquels l’option est décochée.',
	'UCP_TOPIC_REACTIONS_ENABLE'		=> 'Activer par défaut les réactions à vos sujets',	
	'UCP_TOPIC_REACTIONS_EXPLAIN'		=> 'Permet d’activer par défaut la possibilité aux utilisateurs de réagir à vos sujets. Cette option active les réactions pour tous vos sujets présents et futurs, exceptés ceux pour lesquels l’option est décochée.',
));
