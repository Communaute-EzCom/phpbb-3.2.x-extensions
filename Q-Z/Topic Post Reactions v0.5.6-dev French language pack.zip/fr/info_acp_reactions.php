<?php
/**
 *
 * Topic/Post Reactions. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2017 Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
//ACP MAIN abc..
	'REACTIONS_VERSION'				=> 'Version : 0.5.6-dev',
	'ACP_TPR_DONATE'				=> 'Faire un don',
	'ACP_REACTIONS_EXPLAIN'			=> 'Sur cette page il est possible d’ajouter, modifier, supprimer, activer, désactiver et ordonner les types de réactions.',
	'ACP_REACTIONS_SETTINGS_EXPLAIN'=> 'Sur cette page il est possible de paramétrer les options générales des réactions aux messages et sujets.',
	'ACP_REACTIONS_TITLE'			=> 'Paramètres des réactions',
	'ACP_REACTIONS_SETTINGS'		=> 'Paramètres',
	'ACP_REACTIONS_ENABLE'			=> 'Activer les réactions aux messages/sujets',
	'ACP_REACTION_ENABLE_PAGE'		=> 'Activer la page « Vue des réactions » listant le nombre de réactions récentes par utilisateur',
	'ACP_REACTION_ENABLE_PAGES'		=> 'Activer les pages (pop-up) listant les réactions aux messages par utilisateur',
	'ACP_REACTIONS_RESYNC_ENABLE'	=> 'Activer la resynchronisation des réactions des messages',
	'ACP_REACTIONS_RESYNC_ENABLE_EXPLAIN'	=> 'Permet de resynchroniser les types et le compteur de réactions pour les messages.',
	'ACP_REACTIONS_SETTING_SAVED'	=> 'La paramètres ont été sauvegardés avec succès !',

	'ACP_CDN_REACTION_URL'			=> 'Adresse URL du CDN (Content Delivery Network)',
	'ACP_REACTION_ADD'				=> 'Ajouter un nouveau type de réaction',
	'ACP_REACTION_ADDED'			=> 'Ce nouveau type de réaction a été ajouté avec succès !',
	'ACP_REACTIONS_CACHE'			=> 'Durée du cache des images des types de réactions',
	'ACP_REACTIONS_CACHE_EXPLAIN'	=> 'Permet de saisir la durée du cache des images des types de réactions. La valeur minimale est de <strong>300</strong> secondes (5 minutes) et la valeur maximale est de <strong>86400</strong> secondes (1 jour).',
	'ACP_REACTION_DELETED_CONFIRM'	=> 'Confirmer la suppression des données associées à ce type de réaction.<br /><br />Toutes les données et paramètres seront supprimés et ne pourront pas être récupérés !',	
	'ACP_REACTION_TYPE_DELETED'		=> 'Ce type de réaction a été supprimé avec succès !',
	'ACP_REACTION_EDIT'				=> 'Modifier ce type de réaction',
	'ACP_REACTION_ENABLE'			=> 'Activer ce type de réaction',
	'ACP_REACTIONS_HEIGHT'			=> 'Dimensions des images des types de réactions',
	'ACP_REACTION_IMAGE'			=> 'Image de ce type de réaction',

	'ACP_REACTIONS_PER_PAGE'		=> 'Nombre d’utilisateurs affichés par page sur la « Vue des réactions » et dans les pop-up des messages, ainsi que le nombre de types de réactions affichés par page, dans le PCA, sur la page « Types de réactions »',
	'ACP_REACTION_PATH'				=> 'Répertoire des images des types de réactions',
	'ACP_REACTION_PATH_EXPLAIN'		=> 'Permet de saisir le chemin du répertoire de stockage des images des réactions. Le chemin est relatif au répertoire racine de phpBB, par exemple : images/emoji',
	'ACP_REACTION_TITLE'			=> 'Titre de ce type de réaction',
	'ACP_REACTION_TYPE'				=> 'Type de réaction',
	'ACP_REACTION_TYPES'			=> 'Types de réactions',
	'REACTION_TYPE_ID_EMPTY'		=> 'Le type de réaction demandé n’existe pas',
	'ACP_REACTION_TYPE_COUNT_ENABLE'=> 'Activer les compteurs des types de réaction dans les messages',
	'ACP_REACTION_UPDATED'			=> 'Ce type de réaction a été mis à jour avec succès !',
	'ACP_REACTIONS_WIDTH'			=> 'Largeur des images des types de réaction',
	'ACP_REACTIONS_REC_LIMIT'		=> 'Limite des réactions récentes',
	'ACP_REACTIONS_REC_LIMIT_EXP'	=> 'Permet de saisir le nombre de réactions récentes à afficher dans le profil des utilisateurs et sur la page « Vue des réactions ».',
	//Working on it... 
	'ACP_WORKING_ON_IT'				=> 'Processus en cours… Suppression de %1s réactions effectuée, %2s réactions restantes…<br /> Merci de ne pas quitter ou recharger cette page.',
	
	//
	'ACP_SELECT_REACTION_IMAGE'		=> 'Sélectionner une image',
	'ACP_SELECT_REACTION_IMAGE_ALT' => 'Aperçu de l’image',
	'ACP_NO_REACTION_IMAGE_SELECTED'=> 'Aucune image n’a été sélectionnée pour ce type de réaction.',
	'ACP_POST_AUTHOR_REACT'			=> 'Permettre aux auteurs de messages de réagir à leurs messages',//
	'CAT_REACTION_IMAGE'			=> 'Image',
	'CAT_REACTION_URL'				=> 'Adresse URL',
	'CAT_REACTION_TITLE'			=> 'Titre',
	'CAT_REACTION_ENABLED'			=> 'Activé',
	'UPLOAD_NOT_DIR'				=> 'Le chemin du répertoire de stockage des images ne semble pas exister, merci de le corriger.<br /> %1s',	
));
