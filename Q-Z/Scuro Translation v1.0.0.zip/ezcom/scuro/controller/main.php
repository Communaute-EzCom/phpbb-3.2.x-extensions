<?php
/**
 *
 * Scuro Translation. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2017, Raphaël M., http://www.ezcom-fr.com
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace ezcom\scuro\controller;

/**
 * Scuro Translation main controller.
 */
class main
{
	/* @var \phpbb\user */
	protected $user;

	/**
	 * Constructor
	 *
	 * @param \phpbb\user				$user
	 */
	public function __construct(\phpbb\user $user)
	{
		$this->user = $user;
	}
}
