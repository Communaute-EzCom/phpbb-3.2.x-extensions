<?php
/**
 *
 * Scuro Translation. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2017, Raphaël M., http://www.ezcom-fr.com
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'SCURO_DEFAULT_COLOUR'		=> 'Bleu électrique (couleur par défaut)',
	'SCURO_AQUA'				=> 'Bleu-vert',
	'SCURO_GREEN'				=> 'Vert pomme',
	'SCURO_ORANGE'				=> 'Orange',
	'SCURO_RED'					=> 'Cinabre',
	'SCURO_PINK'				=> 'Mure',
	'SCURO_PURPLE'				=> 'Améthyste',
	'SCURO_SWITCH_COLOURS'		=> 'Modifier la couleur',
));
