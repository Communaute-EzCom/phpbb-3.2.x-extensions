<?php
/**
 *
 * Scuro Translation. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2017, Raphaël M., http://www.ezcom-fr.com
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'SCURO_DEFAULT_COLOUR'		=> 'Mariner (Default colour)',
	'SCURO_AQUA'				=> 'Boston Blue',
	'SCURO_GREEN'				=> 'Apple',
	'SCURO_ORANGE'				=> 'Zest',
	'SCURO_RED'					=> 'Cinnabar',
	'SCURO_PINK'				=> 'Mulberry',
	'SCURO_PURPLE'				=> 'Fuchsia Pink',
	'SCURO_SWITCH_COLOURS'		=> 'Switch colours',
));
