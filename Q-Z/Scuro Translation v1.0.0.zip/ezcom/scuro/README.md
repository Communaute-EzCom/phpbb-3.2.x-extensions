# Scuro Translation

## Installation

Copy the extension to phpBB/ext/ezcom/scuro

Go to "ACP" > "Customise" > "Extensions" and enable the "Scuro Translation" extension.

## License

[GPLv2](license.txt)
