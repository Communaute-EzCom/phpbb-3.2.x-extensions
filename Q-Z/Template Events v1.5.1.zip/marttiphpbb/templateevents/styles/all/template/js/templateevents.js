;(function($, window, document) {
	$('document').ready(function(){
		$('ul > a.templateevents, ol > a.templateevents').wrap('<li></li>');
	});
})(jQuery, window, document);
