<?php
/**
*
* @package phpBB Extension -  radiolink
* @copyright (c) 2018 scotty - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/


namespace scotty\radiolink\controller;



class radiolink
{
	
	protected $radiolink_class;
	
	protected $auth;

	protected $request;

	protected $user;


	
	public function __construct(
		\scotty\radiolink\core\radiolink_class $radiolink_class,
		\phpbb\auth\auth $auth,
		\phpbb\request\request $request,
		\phpbb\user $user)
	{
		$this->radiolink_class			= $radiolink_class;
		$this->auth 				= $auth;
		$this->request = $request;		
		$this->user = $user;
		
	}
		

	public function handle()
	{

		// Check if you are locked or not
		if (!$this->auth->acl_get('u_use_radiolink'))
		{
			trigger_error('RADIOLINK_FORBIDDEN');
		}
		
		
		$id		= $this->request->variable('id', 0); 
		$mode = $this->request->variable('mode', '');
		switch ($mode)
		{
						
		default :			 
		 $this->radiolink_class->display_link();
	 
		break;
	
		
		}

	
	}



}

?>