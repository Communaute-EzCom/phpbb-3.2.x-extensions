<?php
/**
*
* @package phpBB Extension -  radiolink
* @copyright (c) 2018 scotty - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/


namespace scotty\radiolink\controller;



class admin_radiolink
{
	
	protected $config;
	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\db\driver\driver_interface */
	protected $db;

	/** @var \phpbb\request\request */
	protected $request;


	/** @var string phpBB root path */
	protected $root_path;

	/** @var string php_ext */
	protected $php_ext;	


	/**
	* The database tables
	*
	* @var string
	*/
	

	
	protected $radiolink_table;


	/** @var \phpbb\files\factory */

	
	/** @var string Custom form action */
	protected $u_action;

	
	public function __construct(
		\phpbb\config\config $config,
		\phpbb\template\template $template,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\request\request $request,
		$root_path,
		$php_ext,
		$radiolink_table)
	{
		$this->config		= $config;
		$this->template 					= $template;
		$this->user 						= $user;
		$this->auth 						= $auth;
		$this->db 							= $db;
		$this->request 						= $request;
		$this->root_path 					= $root_path;
		$this->php_ext 						= $php_ext;
		$this->radiolink_table				= $radiolink_table;
		
	}
		
	
	public function acp_radiolink()
	{
	
		// Grab some vars
		$action = $this->request->variable('action', '');
		$mode = $this->request->variable('mode', '');
		switch($action)
		{
			
			case 'new' :
			case 'confirm_edit' :
				$this->save_link($action);
			break;
			
			case 'edit' :
				$this->edit_link();
			break;
			case 'confirm_del' :
				$this->confirm_remove_link($action, $mode);
			break;
			
			default :
				$this->display_links();
			break;
		}

	}
	public function edit_link()
		{
			
			$link_id = $this->request->variable('c',0);
			if ($link_id <= 0 )
			{
				trigger_error($this->user->lang['NO_RADIOLINK'] . adm_back_link($this->u_action), E_USER_WARNING);
			}
			
			$sql_array = array(
				'SELECT'	=> 'c.style,c.name,c.exactname,  c.api_link, c.id',
						
				'FROM'		=> array(
					$this->radiolink_table	=> 'c'
				),
				
				'WHERE' => 'c.id = '.$link_id
			);	
			$sql = $this->db->sql_build_query('SELECT', $sql_array);				
			$result = $this->db->sql_query($sql);

			if (!$data = $this->db->sql_fetchrow($result) )
			{
				trigger_error($this->user->lang['NO_RADIOLINK'] . adm_back_link($this->u_action), E_USER_WARNING);
			}
			
			$this->template->assign_vars( array(
				'LINK_NAME' 	=> $data['exactname'],
				'RADIO_NAME' 	=> $data['name'],
				'API_LINK' => $data['api_link'],
				'STYLE' => $data['style'],
				'S_RADIO_CONFIG'					=> false,
				'S_EDIT_LINK' => true,
				'U_EDIT' => $this->u_action . "&amp;action=confirm_edit&amp;c=".$link_id
			));
			
	}

			public function save_link($action)
		{
			
			
			$link_id = $this->request->variable('c',0);
			$link_name = $this->request->variable('link_name','', true);
			$name = $this->request->variable('name','', true);
			$api_link = $this->request->variable('api_link', '', true);
			$style = $this->request->variable('style', '', true);

			
			
			if ($action == 'confirm_edit')
			{
				if ($link_id <= 0 )
				{
					trigger_error($this->user->lang['NO_RADIOLINK'] . adm_back_link($this->u_action), E_USER_WARNING);
				}
				
				
			}
			

			
			
			$sql_ary = array();	


				
			$sql_ary['name'] = $name;
			$sql_ary['exactname'] = $link_name;
			$sql_ary['api_link'] = $api_link;
		$sql_ary['style'] = $style;
			
			if ($action == 'confirm_edit')
			{
				$sql = 'UPDATE ' . $this->radiolink_table . ' SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
						  WHERE id = '.$link_id;
			}
			else
			{
				$sql = 'INSERT INTO ' . $this->radiolink_table . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
			}
			
			$this->db->sql_query($sql);

			if ($action == 'new')
			{
				$link_id = $this->db->sql_nextid();

				
			}

			trigger_error( (($action == 'new') ? $this->user->lang['RADIOLINK_ADDED'] : $this->user->lang['RADIOLINK_EDITED']). adm_back_link($this->u_action));
		}
		
	
		
	

	
		public function confirm_remove_link($action, $mode)
		{

			$link_id = $this->request->variable('c',0);
					
		
			if (confirm_box(true))
			{
				
				

				$this->db->sql_query('DELETE FROM '.$this->radiolink_table.' WHERE id = '.$link_id);
				

				$sql_ary = array(
					'id' => $next_link
				);

							
				trigger_error($this->user->lang['RADIOLINK_DELETED']. adm_back_link($this->u_action));
			}
			else
			{
				confirm_box(false, $this->user->lang['CONFIRM_OPERATION'], build_hidden_fields(array(
					'c'			=> $link_id,
					'next_link' => $next_link,
					'mode'		=> $mode,
					'action'	=> $action,
					)));
			}			
		}

	

		

		public function display_links()
		{
			
			$sql_array = array(
				'SELECT'	=> 'c.name, c.id',

						
				'FROM'		=> array(
					$this->radiolink_table	=> 'c',
					

				),
				
				'WHERE' => 'c.id',
				'ORDER_BY' => 'c.id DESC'
			);
				//}
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);			
		$result = $this->db->sql_query($sql);
	
		$option  .= '<select name="radiolink"><option value="0">'.$this->user->lang['DESACTIVER'].'</option>';
		while( $row = $this->db->sql_fetchrow($result) )
		{	
	
			$option .= '<option value="'.$row['id'].'" '.(($this->config['radiolink'] == $row['id'])? 'selected' : '').'>'.$row['name'].'</option>'; 	
		}
		$option  .= '</select>';
			
			
			$sql_array = array(
				'SELECT'	=> 'c.name, c.api_link,c.exactname,  c.id,c.style',
						
				'FROM'		=> array(
					$this->radiolink_table	=> 'c',
					
				),
				
				'WHERE' => 'c.id ',
				'ORDER_BY' => 'c.style ASC'
			);
						
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);


			while( $row = $this->db->sql_fetchrow($result) )
			{	
				$this->template->assign_block_vars('radiolink', array(
					'LINK_ID' => stripslashes($row['id']),
					'LINK_NAME' => $row['exactname'],
					'NAME' => $row['name'],
					'API_LINK' => $row['api_link'],
					'STYLE' => $row['style'],
					'U_DELETE' => $this->u_action . "&amp;action=confirm_del&amp;c=".(int)$row['id'],
					'U_EDIT' => $this->u_action . "&amp;action=edit&amp;c=".(int)$row['id']

					));			
			}
				
			$this->template->assign_vars( array(
				'S_EDIT_LINK' => false,
				'OPTION' 		=> $option,
				'RADIOLINK_VERSION' 		=> $this->config['radiolink_version'],
				'U_ADD_LINK' => $this->u_action . "&amp;action=new"
			));
		}


	/**
	* Set page url
	*
	* @param string $u_action Custom form action
	* @return null
	* @access public
	*/
	public function set_page_url($u_action)
	{
		$this->u_action = $u_action;
	}
}
