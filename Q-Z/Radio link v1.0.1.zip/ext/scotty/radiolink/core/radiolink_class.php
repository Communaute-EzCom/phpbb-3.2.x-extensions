<?php
/**
*
* @package phpBB Extension - radiolink
* @copyright (c) 2018 scotty - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

	
namespace scotty\radiolink\core;


class radiolink_class
{

	/** @var config */
	protected $config;


	/** @var \phpbb\db\driver\driver_interface */
	protected $db;


	/** @var \phpbb\controller\helper */
	protected $helper;

	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;


	/** @var string phpBB root path */
	protected $root_path;

	/** @var string phpEx */
	protected $php_ext;

/**
	* The database tables
	*
	* @var string
	*/
	protected $radiolink_table;
	

	public function __construct(
		\phpbb\config\config $config,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\controller\helper $helper,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$root_path,
		$php_ext,
		$radiolink_table)
	{
		$this->config		= $config;
		$this->db = $db;
		$this->helper = $helper;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->root_path 					= $root_path;
		$this->php_ext 						= $php_ext;
		$this->radiolink_table				= $radiolink_table;
	}
	
	
	
	
	function display_link()
	{
	
	
				$mode = $this->request->variable('mode', '');
					
			
			
			
			
			
			
		
		
	if($this->config['radiolink_enable'] == 0)
	{
$sql_array = array(
				'SELECT'	=> 'c.name,c.exactname,  c.api_link,  c.id',

						
				'FROM'		=> array(
					$this->radiolink_table	=> 'c',
					

				),
				
				'WHERE' => 'c.id = '. $this->config['radiolink']
			);
				//}
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
 
			while( $row = $this->db->sql_fetchrow($result) )
			{
				$this->template->assign_vars(array(
				'LINK_NAME' 		=> $row['exactname'],
				'API_LINK' 	=> $row['api_link'],
				'RADIONAME' 		=> $row['name'],				
				'AUTEUR_COPY' 		=> sprintf($this->user->lang['AUTEUR_COPY'],	$this->config['radiolink_version']),
				));
			}
}
if($this->config['radiolink_enable'] == 1)
	{
		
		
		
		
		$sql_array = array(
				'SELECT'	=> 'c.id, c.name',
					
				'FROM'		=> array(
					$this->radiolink_table => 'c'
				),
					
				'ORDER_BY'	=> 'c.name'
			);
			
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
		
			$option  .= $this->user->lang['CHOOSE_RADIO'] .'<br/>';
			$option  .= '<select name="user_radiolink">';
			while( $row = $this->db->sql_fetchrow($result) )
			{	
				
				$option .= '<option value="'.$row['id'].'" '.(($this->user->data['user_radiolink'] == $row['id'])? 'selected' : '').'>'.$row['name'].'</option>'; 	
			}
			$option  .= '</select>';
			
			$option  .= '<input type="submit" name="submit" value="'.$this->user->lang['SUBMIT'].'" class="button2" />';
			
			$this->template->assign_vars( array(
			'S_CHOOSE_RADIO' 		=> $this->helper->route('scotty_radiolink_page_radiolink', array('mode' => 'change')),
				'OPTIONS_SELECT' 		=> $option
			));
	
	$user_radiolink = (isset($this->user->data['user_radiolink'])) ? $this->user->data['user_radiolink'] : $this->config['radiolink'];
	
	
	$sql_array = array(	
	'SELECT'	=> 'c.name,c.exactname,  c.api_link,  c.id',

						
				'FROM'		=> array(
					$this->radiolink_table	=> 'c',
					

				),
				
				'WHERE' => 'c.id = '. $user_radiolink
			);
				//}
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
 
			while( $row = $this->db->sql_fetchrow($result) )
			{
				$this->template->assign_vars(array(
				'LINK_NAME' 		=> $row['exactname'],				
				'API_LINK' 	=> $row['api_link'],
				'RADIONAME' 		=> $row['name'],
				
				'AUTEUR_COPY' 		=> sprintf($this->user->lang['AUTEUR_COPY'],	$this->config['radiolink_version']),
				));
			}
}	
		
		
		if ($mode == 'change')
			{	
				
					
					
					$sql_ary = array(
						'user_radiolink'			=>$this->request->variable('user_radiolink', $this->user->data['user_radiolink']),
									);
		 
					$sql = 'UPDATE ' . USERS_TABLE . '
						SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
						WHERE user_id = ' . $this->user->data['user_id'];
					$this->db->sql_query($sql);
			  $redirect = $this->helper->route('scotty_radiolink_page_radiolink');
			redirect($redirect);
			
			}
		 

	

		//output
		page_header( $this->user->lang['RADIOLINK'] );
		
		$this->template->set_filenames(array(
			'body' => 'radiolink_body.html')
		);
				
		page_footer();
	}
	
	
	
	

	
}
?>