<?php
/**
*
* @package phpBB Extension -  radiolink
* @copyright (c) 2018 scotty - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace scotty\radiolink;



class ext extends \phpbb\extension\base
{

}
