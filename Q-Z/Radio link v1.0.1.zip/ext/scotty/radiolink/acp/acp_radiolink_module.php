<?php
/**
*
* @package phpBB Extension -  radiolink
* @copyright (c) 2018 scotty - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace scotty\radiolink\acp;

class acp_radiolink_module
{
	public	$u_action;

	function main($id, $mode)
	{
		global $phpbb_container, $user;

		
		global $db, $user, $auth, $template, $cache, $request;
		global $config, $phpbb_root_path, $phpbb_admin_path, $phpEx;

		$this->tpl_name = 'acp_radiolink';
		add_form_key('acp_radiolink_config');

		$submit = $request->is_set_post('submit');
		if ($submit)
		{
			if (!check_form_key('acp_radiolink_config'))
			{
				trigger_error('FORM_INVALID');
			}

			$config->set('radiolink_enable', $request->variable('radiolink_enable', 0));
			$config->set('radiolink', $request->variable('radiolink',''));
			$config->set('radiolinkname', $request->variable('radiolinkname', '', true));


			
			trigger_error($user->lang['RADIOLINK_CONFIG_SAVED'] . adm_back_link($this->u_action));
		}
		$template->assign_vars(array(
			'RADIOLINK_ENABLE'			=> (!empty($config['radiolink_enable'])) ? true : false,
			'RADIOLINK_VERSION'			=> (isset($config['radiolink_version'])) ? $config['radiolink_version'] : '',
			'RADIOLINK'			=> (isset($config['radiolink'])) ? $config['radiolink'] : '',
			'RADIOLINKNAME'			=> (isset($config['radiolinkname'])) ? $config['radiolinkname'] : '',
			'S_RADIO_CONFIG'					=> true,
			'U_ACTION'					=> $this->u_action,
		));		
		
		
		
		
		// Get an instance of the admin controller
		$admin_link = $phpbb_container->get('scotty.radiolink.admin.radiolink');
		
		// Make the $u_action url available in the admin controller

		$admin_link->set_page_url($this->u_action);


		switch ($mode)
		{
			
			
			case 'acp_radiolink':
				// Load a template from adm/style for our ACP page
				$this->tpl_name = 'acp_radiolink';
				// Set the page title for our ACP page
				$this->page_title = $user->lang['ACP_RADIOLINK_MANAGEMENT_TITLE'];
				// Load the display lottery in the admin controller
				$admin_link->acp_radiolink();
			break;
		
			
			
			
		}
	}
	
	
}
