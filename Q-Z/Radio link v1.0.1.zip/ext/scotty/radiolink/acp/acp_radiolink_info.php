<?php
/**
*
* @package phpBB Extension - radiolink
* @copyright (c) 2018 scotty - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace scotty\radiolink\acp;

class acp_radiolink_info
{
	function module()
	{
		return array(
			'filename'		=> '\scotty\radiolink\acp\acp_radiolink_module',
			'title'			=> 'ACP_RADIOLINK_SETTINGS',
			'modes'			=> array(
				'acp_radiolink'	=> array('title' => 'ACP_RADIOLINK_MANAGEMENT_TITLE', 'auth' => 'ext_scotty/radiolink && acl_a_board', 'cat' => array('ACP_RADIOLINK')),

			),
		);
	}
}
