<?php
/**
*
* @package phpBB Extension - radiolink
* @copyright (c) 2018 scotty
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
 
namespace scotty\radiolink\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;


class main_listener implements EventSubscriberInterface
{
	
	
	/** @var config */
	protected $config;

	/** @var \phpbb\user */
	protected $user;


	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\db\driver\driver_interface */
	protected $db;

	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\controller\helper */
	protected $helper;


	/** @var \phpbb\request\request */
	protected $request;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;
	
	protected $radiolink_table;

	/**
 	 * Constructor
	 *
	 * @param user				$user
	 * @param template			$template
	 * @param db_interface		$db
	 * @param helper			$helper
	 * @param \phpbb\cache\service		 		$cache
	 * @param request_interface	$request
	 * @param string			$root_path
	 * @param string			$php_ext
	 */
	public function __construct(
		\phpbb\config\config $config,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\user $user,
		\phpbb\auth\auth $auth,
		\phpbb\template\template $template,
		\phpbb\controller\helper $helper,
		\phpbb\request\request $request,
		$root_path,
		$php_ext,
		$radiolink_table)
	{
		$this->config		= $config;
		$this->db					= $db;
		$this->user					= $user;
		$this->auth 				= $auth;
		$this->template				= $template;
		$this->helper 				= $helper;
		$this->request 				= $request;
		$this->root_path 			= $root_path;
		$this->php_ext 				= $php_ext;
		$this->radiolink_table		= $radiolink_table;
	}

	/**
	 * @return array
	 */
	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'						=> 'user_setup',
			'core.permissions'								=> 'permissions',
			'core.page_header'								=> 'page_header',
		
		);
	}

	/**
	 *
	 * @param Event $event
	 */
	public function user_setup($event)
	{
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'scotty/radiolink',
			'lang_set' => 'radiolink',
		);
		$event['lang_set_ext'] = $lang_set_ext;

		$this->template->assign_vars(array(
			'U_RADIOLINK'		=> $this->helper->route('scotty_radiolink_page_radiolink'),
			'S_RADIOLINK'		=>$this->auth->acl_get('u_use_radiolink'),
			'S_RADIO'		=>($this->config['radiolink'] == 0) ? false : true ,
		
			
		));
	}
	
	
	public function page_header($event)
	{
		
			
		if(($this->config['radiolink_enable'] == 0))
	{
$sql_array = array(
				'SELECT'	=> 'c.name, c.id',

						
				'FROM'		=> array(
					$this->radiolink_table	=> 'c',
					

				),
				
				'WHERE' => 'c.id = '. $this->config['radiolink']
				
			);
				//}
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
 
			while( $row = $this->db->sql_fetchrow($result) )
			{
				$this->template->assign_vars(array(

				'RADIOLINKNAME_USER'			=>sprintf($this->user->lang['CQUILEPATRON'], (isset($this->config['radiolinkname'])) ? $this->config['radiolinkname'] : ''),
				'RADIONAME' 		=> $row['name'],
				
				));
			}
}
if(($this->config['radiolink_enable'] == 1))
	{
		
			$user_radiolink = (isset($this->user->data['user_radiolink'])) ? $this->user->data['user_radiolink'] : $this->config['radiolink'];
	
	
	$sql_array = array(	
	'SELECT'	=> 'c.name,c.exactname,  c.api_link,  c.id',

						
				'FROM'		=> array(
					$this->radiolink_table	=> 'c',
					

				),
				
				'WHERE' => 'c.id = '. $user_radiolink
			);
		
	
	
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
 
			while( $row = $this->db->sql_fetchrow($result) )
			{
				$this->template->assign_vars(array(				
				'RADIONAME' 		=> $row['name'],
				));
			}
}
				
		
	
	}	
	// Show permissions
	public function permissions($event)
	{
		$permissions = $event['permissions'];
		$permissions += array(
			'u_use_radiolink'		=> array(
				'lang'		=> 'ACL_U_USE_RADIOLINK',
				'cat'		=> 'radiolink'
			),
			
		);
		$event['permissions'] = $permissions;
		$categories['radiolink'] = 'ACL_CAT_RADIOLINK';
		$event['categories'] = array_merge($event['categories'], $categories);
	}
	
	
}
