<?php
/**
*
* @package phpBB Extension - radiolink
* @copyright (c) 2018 scotty  - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace scotty\radiolink\migrations;

class radiolink_install extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v310\gold');
	}

	public function update_data()
	{
				return array(
			array('permission.add', array('u_use_radiolink', true)),
			array('config.add', array('radiolink', '0')),
			array('config.add', array('radiolink_enable', '0')),
			array('config.add', array('radiolink_version', '1.0.0')),
			array('config.add', array('radiolinkname', '<strong>radio proposé par : </strong> administrateur')),
			array('module.add', array('acp', 'ACP_CAT_DOT_MODS', 'ACP_RADIOLINK')),
			array('module.add', array(
			'acp', 'ACP_RADIOLINK', array(
			'module_basename'	=> '\scotty\radiolink\acp\acp_radiolink_module', 'modes'		=> array('acp_radiolink'),
				),
			)),
			

		);
	}
		
	
		
	



public function update_schema()
	{
		return array(
			'add_tables'	=> array(				
				
			
				$this->table_prefix . 'radiolink'	=> array(				
					'COLUMNS'			=> array(
						'id'		=> array('INT:11', null, 'auto_increment'),
						'name'		=> array('VCHAR:50' , 0),
						'exactname'		=> array('VCHAR:50' , 0),
						'style'		=> array('VCHAR:50' , 0),	
						'api_link'		=> array('TEXT_UNI' , 0),		
					),
					'PRIMARY_KEY'	=> 'id',				

				),
				
				

			),
			
			'add_columns' => array(
								
				$this->table_prefix . 'users' => array(
					'user_radiolink' 			=> array('INT:50', 0),
				),
			),
			
		);
	}

	public function revert_schema()
	{
		return 	array(
			'drop_tables' => array(
			
				$this->table_prefix . 'radiolink',
				
			
			),
			
		);
	}


	public function insert_config_data()
	{
	
			
	}	
	
	
	

	
	
	
	


}
