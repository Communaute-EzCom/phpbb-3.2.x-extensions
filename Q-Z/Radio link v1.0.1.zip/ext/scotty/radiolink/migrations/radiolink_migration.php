<?php
/**
*
* @package phpBB Extension - radiolink
* @copyright (c) 2018 scotty  - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace scotty\radiolink\migrations;

class radiolink_migration extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v310\gold');
	}

	public function update_data()
	{
		return array(
			array('config.update', array('radiolink_version', '1.0.1')),
		

		);
	}
	

	
	


}
