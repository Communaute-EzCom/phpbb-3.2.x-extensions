<?php
/**
*
* @package phpBB Extension -  Arcadelink
* @copyright (c) 2018 scotty - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
	*/
	/**
	* DO NOT CHANGE
	*/
	if (!defined('IN_PHPBB'))
	{
	exit;
	}
	
	if (empty($lang) || !is_array($lang))
	{
	$lang = array();
	}
	// DEVELOPERS PLEASE NOTE
	//
	// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
	//
	// Placeholders can now contain order information, e.g. instead of
	// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
	// translators to re-order the output of data while ensuring it remains correct
	//
	// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
	// equally where a string contains only two placeholders which are used to wrap text
	// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
	// BEGIN Countdown
	$lang = array_merge($lang, array(
	'RADIOLINK_ENABLE'								=> 'allow members to choose the radio',
	'RADIOLINK_ENABLE_EXPLAIN'								=> 'allows the user to choose his radio in the list <br/> if "no" the default radio will be broadcast',
	'RADIOLINK_EXACTNAME'								=> 'Exact name of the radio',
	'ACP_RADIOLINK_MANAGEMENT_TITLEII'								=> 'available radio : <a href=" http://www.radio.fr"  onclick="open(\' http://www.radio.fr\', \'Popup\', \'scrollbars=1,resizable=1,height=600,width=700\'); return false;" >radios</a>',
	'CQUILEPATRON'								=> '<strong>radio proposed by : </strong>%s <br/>',
	'RADIOLINK'								=> 'univers radio',
	'DESACTIVER'								=> 'Disable',
	'CHOOSE_RADIO'								=> 'Selected your radio',	
	'RADIOLINKNAME'								=> '<i>Broadcast Radio</i> :',
	'RADIOLINKNAME_USER'								=> 'Indicated text ',
	'RADIOLINK_FORBIDDEN'					=> 'you are not allowed to see univers radio',	
	'RADIOLINKNAME'								=> '<i>Broadcast Radio</i> :',
	'ACL_CAT_RADIOLINK'		=> 'univers radio',
	'ACL_U_USE_RADIOLINK'		=> 'Can see / hear univers radio',
	'LINKRADIO' => 'Radios',	
	'RADIOLINK_NAME' => 'Name of the radio',	
	'API_LINK' => 'Api key of the radio',
	'EDIT_LINK'		=> 'radio edition',
	'ACP_RADIOLINK'		=> 'univers radio',
	'AUTEUR_COPY'		=> '<a title="radiolink v %s" href="http://arcade-scotty.fr"> Extension radiolink &copy by Scotty 2018</a>',	
	'ACP_RADIOLINK_MANAGEMENT_TITLE'		=> 'univers radio management',
	'RADIOLINK_ADDED'		=> 'Radio added successfully',
	'RADIOLINK_EDITED'		=> 'he Radio has been successfully edited',
	'RADIOLINK_DELETED'		=> 'adio has been successfully removed',
	'NO_RADIOLINK'		=> 'no radio of selected',
	'ADD_RADIOLINK'		=> 'Add a radio',
	'EDIT_RADIOLINK'		=> 'Validated the edition',
	'ACP_RADIOLINK_CONFIG_SET'		=> 'Broadcast configuration',
	'RADIOLINK_OFFSET' => 'Radio Id',
	'RADIOLINK_STYLE' => 'radio style',
	'RADIOLINK_OFFSET_EXPLAIN' => 'Indicate the id of the radio that will be broadcast',
	'RADIOLINK_TEXT' => 'Name of the radio',
	'RADIOLINK_TEXT_EXPLAIN' => 'Enter a name of the radio to be broadcast',
	'RADIOLINK_CONFIG_SAVED' => 'Broadcast configuration successfully updated <br/> <br/> Please check group permissions',
	));
	
?>