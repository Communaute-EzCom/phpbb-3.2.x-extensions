<?php
/**
*
* @package phpBB Extension -  radiolink
* @copyright (c) 2018 scotty - http://www.arcade-scotty.fr
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
	*/
	/**
	* DO NOT CHANGE
	*/
	if (!defined('IN_PHPBB'))
	{
	exit;
	}
	
	if (empty($lang) || !is_array($lang))
	{
	$lang = array();
	}
	// DEVELOPERS PLEASE NOTE
	//
	// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
	//
	// Placeholders can now contain order information, e.g. instead of
	// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
	// translators to re-order the output of data while ensuring it remains correct
	//
	// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
	// equally where a string contains only two placeholders which are used to wrap text
	// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
	// BEGIN Countdown
	$lang = array_merge($lang, array(
	'RADIOLINK_ENABLE'								=> 'autoriser les membres à choisir la radio',
	'RADIOLINK_ENABLE_EXPLAIN'								=> 'autorise l’utilisateur à choisir sa radio dans la liste<br/>si "non" la radio par défaut sera diffusée',
	'RADIOLINK_EXACTNAME'								=> 'Nom exact de la radio',
	'ACP_RADIOLINK_MANAGEMENT_TITLEII'								=> 'radio disponible : <a href=" http://www.radio.fr"  onclick="open(\' http://www.radio.fr\', \'Popup\', \'scrollbars=1,resizable=1,height=600,width=700\'); return false;" >les radios</a>',
	'RADIOLINK'								=> 'univers radio',
	'DESACTIVER'								=> 'Désactiver',
	'CQUILEPATRON'								=> '<strong>radio proposé par : </strong>%s<br/>',	
	'CHOOSE_RADIO'								=> 'Sélectionné votre radio',	
	'RADIOLINK_FORBIDDEN'					=> 'vous n’étes pas autoriser a voir univers radio',
	'RADIOLINKNAME'								=> '<i>Radio diffusée</i> :',
	'RADIOLINKNAME_USER'								=> 'Indiqué un texte ',
	'ACL_CAT_RADIOLINK'		=> 'univers radio',
	'ACL_U_USE_RADIOLINK'		=> 'Peux voir / écouter univers radio',
	'LINKRADIO' => 'Radios',
	'RADIOLINK_NAME' => 'Nom de la radio',	
	'API_LINK' => 'Api key de la radio',
	'EDIT_LINK'		=> 'édition de la radio',
	'ACP_RADIOLINK'		=> 'univers radio',
	'AUTEUR_COPY'		=> '<a title="radiolink v %s" href="http://arcade-scotty.fr"> Extension radiolink &copy by Scotty 2018</a>',	
	'ACP_RADIOLINK_MANAGEMENT_TITLE'		=> 'Gestion d’univers radio',
	'RADIOLINK_ADDED'		=> 'Radio ajouté avec succès',
	'RADIOLINK_EDITED'		=> 'La Radio a été éditer avec succès',
	'RADIOLINK_DELETED'		=> 'La Radio a été suprimer avec succès',
	'NO_RADIOLINK'		=> 'aucune radio de selectionné',
	'ADD_RADIOLINK'		=> 'Ajouter une radio',
	'EDIT_RADIOLINK'		=> 'Validé l’édition',
	'ACP_RADIOLINK_CONFIG_SET'		=> 'Configuration de diffusion',
	'RADIOLINK_OFFSET'		=> 'radio par défaut',
	'RADIOLINK_STYLE'		=> 'Genre de radio',
	'RADIOLINK_OFFSET_EXPLAIN'		=> 'Sélectionné la radio qui sera diffusée',
	'RADIOLINK_TEXT'		=> 'Nom de la radio',
	'RADIOLINK_TEXT_EXPLAIN'		=> 'Indiquer un nom de la radio qui sera diffusée',
	'RADIOLINK_CONFIG_SAVED'		=> 'Configuration de diffusion mise à jour avec succès<br/><br/> Veuillez vérifier les permissions des groupes ',
	));
	
?>