<?php
/**
*
* Welcome Guest
*
* @copyright (c) 2015 tomberaid
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace tomberaid\welcomeguest\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	/** @var \phpbb\config\config */
	protected $config;

	public function __construct(\phpbb\config\config $config)
	{
		$this->config = $config;
	}

	/**
	* Assign functions defined in this class to event listeners in the core
	*
	* @return array
	* @static
	* @access public
	*/
	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'			=> 'load_language_on_setup',
		);
	}

	/**
	* Load language files during user setup
	*
	* @param object $event The event object
	* @return null
	* @access public
	*/
	public function load_language_on_setup($event)
	{
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'tomberaid/welcomeguest',
			'lang_set' => 'welcome_guest',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}
}
