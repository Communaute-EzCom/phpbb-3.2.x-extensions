//==========================================
// Welcome Guest Popup
//==========================================
var cookieid = "phpbb3_";

/**
 * Get cookie
 */
function my_getcookie(name) {
	cname = cookieid + name + "=";
	cpos = document.cookie.indexOf(cname);

	if (cpos != -1) {
		cstart = cpos + cname.length;
		cend = document.cookie.indexOf(';', cstart);

		if (cend == -1) {
			cend = document.cookie.length;
		}

		return unescape(document.cookie.substring(cstart, cend));
	}

	return null;
}

/**
 * Set cookie
 */
function my_setcookie(name, value, days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		var expires = "; expires=" + date.toUTCString();
	} else var expires = "";

	document.cookie = cookieid + name + "=" + value + expires + "; path=/";
}

/**
 * Display Welcome Box
 */
$(function() {
	if (my_getcookie('welcome') != '1') {
		$('#welcome-box').fadeIn('fast');
		$('#welcome-wrapper').css('display', 'block');

		$('#welcome_close').click(function() {
			my_setcookie('welcome', '1', '3');
			$('#welcome-box').fadeOut('normal');
			$('#welcome-wrapper').css('display', 'none');
			return false;
		});
	}
});