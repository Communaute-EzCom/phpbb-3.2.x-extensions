<?php
/**
*
* Welcome Guest
*
* @copyright (c) 2015 tomberaid
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace tomberaid\welcomeguest\migrations;

class version_1_0_1 extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return isset($this->config['welcome_guest_version']) && version_compare($this->config['welcome_guest_version'], '1.0.1', '>=');
	}

	static public function depends_on()
	{
		return array('\tomberaid\welcomeguest\migrations\version_1_0_0');
	}

	public function update_data()
	{
		return array(
			// Current version
			array('config.update', array('welcome_guest_version', '1.0.1')),
		);
	}
}
