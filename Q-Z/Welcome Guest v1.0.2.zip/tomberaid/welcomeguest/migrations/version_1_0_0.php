<?php
/**
*
* Welcome Guest
*
* @copyright (c) 2015 tomberaid
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace tomberaid\welcomeguest\migrations;

class version_1_0_0 extends \phpbb\db\migration\migration
{
	public function update_data()
	{
		return array(
			array('config.add', array('welcome_guest_version', '1.0.0')),
		);
	}
}
