<?php
/**
*
* @package phpBB Extension - Wait before registration
* @copyright (c) 2016 dmzx - http://www.dmzx-web.net
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace dmzx\waitbeforeregistration\migrations;

class waitbeforeregistration_schema extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return isset($this->config['waitbeforeregistration_version']) && version_compare($this->config['waitbeforeregistration_version'], '1.0.0', '>=');
	}

	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v320\v320a1');
	}

	public function update_data()
	{
		return array(
			// Add configs
			array('config.add', array('waitbeforeregistration_value', 10)),
			array('config.add', array('waitbeforeregistration_version', '1.0.0')),
		);
	}
}
