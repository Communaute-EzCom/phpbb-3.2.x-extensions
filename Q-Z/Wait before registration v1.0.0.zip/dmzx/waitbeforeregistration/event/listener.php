<?php
/**
*
* @package phpBB Extension - Wait before registration
* @copyright (c) 2016 dmzx - http://www.dmzx-web.net
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace dmzx\waitbeforeregistration\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/** @var \phpbb\config\config */
	protected $config;

	/** @var phpbb\language\language */
	protected $language;

	/** @var \phpbb\template\template */
	protected $template;

	/**
	* Constructor
	*
	* @param \phpbb\config\config				$config
	* @param phpbb\language\language			$language
	* @param \phpbb\template\template			$template
	*
	*/
	public function __construct(\phpbb\config\config $config, \phpbb\language\language $language, \phpbb\template\template $template)
	{
		$this->config 		= $config;
		$this->language		= $language;
		$this->template 	= $template;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.page_footer_after'	=> 'page_footer_after',
		);
	}

	public function page_footer_after($event)
	{
		// Add language
		$this->language->add_lang('common', 'dmzx/waitbeforeregistration');

		$this->template->assign_vars(array(
			'WAITBEFORE_REGISTRATION'	=> $this->config['waitbeforeregistration_value'],
		));
	}
}
