var urlBase = './ext/prosk8er/snowstormlights/styles/all/template/snowstorm/lights/'; 
soundManager.url = './ext/prosk8er/snowstormlights/styles/all/template/snowstorm/lights/'; 