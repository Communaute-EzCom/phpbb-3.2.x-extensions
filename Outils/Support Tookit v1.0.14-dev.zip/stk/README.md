# phpBB3.2-STK
SupportTool Kit For phpBB3.2.x

Create folder called stk in the root folder of your board (where located file config.php) and just copy all files from folder PHPBB3.2-STK-MASTER, keeping folder structure.

Open file default_lang.txt and write there abbreviation used on your board default language, for example en or ru

Start-up (example) http://your_domain.ru/forum/stk/

Создать папку с именем stk в корневой папке конференции (там, где расположен файл config.php) и просто скопировать туда все файлы из папки PHPBB3.2-STK-MASTER, сохраняя структуру папок.

Откройте файл default_lang.txt и впишите туда аббревиатуру используемого на конференции языка по умолчанию, например en или ru

Запуск (пример) http://your_domain.ru/forum/stk/
