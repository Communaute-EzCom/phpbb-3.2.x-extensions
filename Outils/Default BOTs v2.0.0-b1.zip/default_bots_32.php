<?php
/***
* Usage:
* Download and unzip the file, upload it to your Board's root (i.e.: www.mydomain.com/phpBB3/)
* Point your browser to (i.e.: www.mydomain.com/phpBB3/default_bots_32.php)
*
* @package default phpBB's BOTS v2.0.0-b1 (06 03 2017)
* @copyright (c) 2016 3Di (Marco T.)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);

/* If ANONYMOUS = login box */
if ((int) $user->data['user_id'] == ANONYMOUS)
{
	login_box(request_var('redirect', ''));
}

/* Is the User correctly Authed? */
if ((int) $user->data['user_type'] == USER_FOUNDER || $auth->acl_get('a_'))
{
	/* Add search robots to the database */
	global $db, $lang, $config, $table_prefix, $cache;

	$tools_factory = new \phpbb\db\tools\factory();
	$db_tools = $tools_factory->get($db);

	/* Obtains BOTS' group ID */
	echo 'Obtaining BOTS\' group ID.... ';
	$sql = 'SELECT group_id
		FROM ' . GROUPS_TABLE . "
		WHERE group_name = 'BOTS'";
	$result = $db->sql_query($sql);
	$group_id = (int) $db->sql_fetchfield('group_id');
	$db->sql_freeresult($result);

	if (!$group_id)
	{
		/**
		** If we reach this point then something has gone very wrong.
		** Tell the user what's up and self-destroy
		*/
		remove_me();
		trigger_error('No group ID found for BOTS!<br />....I am self destroying, hasta la vista!</font><br />');
	}
	echo '<font color="green">Done!</font><br />';

	/**
	** Let's make sure there aren't BOTS, deleting all
	** of those belonging to the BOTS's group_id
	** We are doing the dirty job here, to restore defaults
	*/
	echo 'Deleting all entries for BOTS group from USERS_TABLE.... ';
	$sql = 'DELETE
		FROM ' . USERS_TABLE . "
		WHERE group_id = $group_id";
	$db->sql_query($sql);
	echo '<font color="green">Done!</font><br />';

	/**
	** At this very point we are emptying the BOTS_TABLE to prevent errors
	** and to effectively restore the BOTS as per default
	*/
	$bots_table = $db_tools->sql_table_exists($table_prefix . 'bots');
	/* If table exists */
	if ($bots_table)
	{
		echo 'Emptying BOT_TABLE.... ';
		$table = BOTS_TABLE;
		switch ($db->get_sql_layer())
		{
			case 'sqlite':
			case 'sqlite3':
				$db->sql_query("DELETE FROM $table");
			break;

			default:
				$db->sql_query("TRUNCATE TABLE $table");
			break;
		}
		echo '<font color="green">Done!</font><br />';
	}
	else
	{
		/* Tell the user what's up and self-destroy */
		remove_me();
		trigger_error('BOTs table does NOT exists!<br />....I am self destroying, hasta la vista!</font><br />');
	}

	/**
	** Let's start restoring phpBB's default BOTS
	** Calling user_add on purpose.
	*/
	if (!function_exists('user_add'))
	{
		include($phpbb_root_path . 'includes/functions_user.' . $phpEx);
	}

	$bot_list = array(
		'AdsBot [Google]'			=> array('AdsBot-Google', ''),
		'Alexa [Bot]'				=> array('ia_archiver', ''),
		'Alta Vista [Bot]'			=> array('Scooter/', ''),
		'Ask Jeeves [Bot]'			=> array('Ask Jeeves', ''),
		'Baidu [Spider]'			=> array('Baiduspider', ''),
		'Bing [Bot]'				=> array('bingbot/', ''),
		'Exabot [Bot]'				=> array('Exabot', ''),
		'FAST Enterprise [Crawler]'	=> array('FAST Enterprise Crawler', ''),
		'FAST WebCrawler [Crawler]'	=> array('FAST-WebCrawler/', ''),
		'Francis [Bot]'				=> array('http://www.neomo.de/', ''),
		'Gigabot [Bot]'				=> array('Gigabot/', ''),
		'Google Adsense [Bot]'		=> array('Mediapartners-Google', ''),
		'Google Desktop'			=> array('Google Desktop', ''),
		'Google Feedfetcher'		=> array('Feedfetcher-Google', ''),
		'Google [Bot]'				=> array('Googlebot', ''),
		'Heise IT-Markt [Crawler]'	=> array('heise-IT-Markt-Crawler', ''),
		'Heritrix [Crawler]'		=> array('heritrix/1.', ''),
		'IBM Research [Bot]'		=> array('ibm.com/cs/crawler', ''),
		'ICCrawler - ICjobs'		=> array('ICCrawler - ICjobs', ''),
		'ichiro [Crawler]'			=> array('ichiro/', ''),
		'Majestic-12 [Bot]'			=> array('MJ12bot/', ''),
		'Metager [Bot]'				=> array('MetagerBot/', ''),
		'MSN NewsBlogs'				=> array('msnbot-NewsBlogs/', ''),
		'MSN [Bot]'					=> array('msnbot/', ''),
		'MSNbot Media'				=> array('msnbot-media/', ''),
		'Nutch [Bot]'				=> array('http://lucene.apache.org/nutch/', ''),
		'Online link [Validator]'	=> array('online link validator', ''),
		'psbot [Picsearch]'			=> array('psbot/0', ''),
		'Sensis [Crawler]'			=> array('Sensis Web Crawler', ''),
		'SEO Crawler'				=> array('SEO search Crawler/', ''),
		'Seoma [Crawler]'			=> array('Seoma [SEO Crawler]', ''),
		'SEOSearch [Crawler]'		=> array('SEOsearch/', ''),
		'Snappy [Bot]'				=> array('Snappy/1.1 ( http://www.urltrends.com/ )', ''),
		'Steeler [Crawler]'			=> array('http://www.tkl.iis.u-tokyo.ac.jp/~crawler/', ''),
		'Telekom [Bot]'				=> array('crawleradmin.t-info@telekom.de', ''),
		'TurnitinBot [Bot]'			=> array('TurnitinBot/', ''),
		'Voyager [Bot]'				=> array('voyager/', ''),
		'W3 [Sitesearch]'			=> array('W3 SiteSearch Crawler', ''),
		'W3C [Linkcheck]'			=> array('W3C-checklink/', ''),
		'W3C [Validator]'			=> array('W3C_Validator', ''),
		'YaCy [Bot]'				=> array('yacybot', ''),
		'Yahoo MMCrawler [Bot]'		=> array('Yahoo-MMCrawler/', ''),
		'Yahoo Slurp [Bot]'			=> array('Yahoo! DE Slurp', ''),
		'Yahoo [Bot]'				=> array('Yahoo! Slurp', ''),
		'YahooSeeker [Bot]'			=> array('YahooSeeker/', ''),
	);

	foreach ($bot_list as $bot_name => $bot_ary)
	{
		$user_row = array(
			'user_type'				=> USER_IGNORE,
			'group_id'				=> (int) $group_id,
			'username'				=> (string) $bot_name,
			'user_regdate'			=> time(),
			'user_password'			=> '',
			'user_colour'			=> '9E8DA7',
			'user_email'			=> '',
			'user_lang'				=> (string) $config['default_lang'],
			'user_style'			=> 1,
			'user_timezone'			=> 'UTC',
			'user_dateformat'		=> $lang['default_dateformat'],
			'user_allow_massemail'	=> 0,
			'user_allow_pm'			=> 0,
		);
		echo 'Restoring default BOTs into USERS_TABLE.... ';
		$user_id = user_add($user_row);
		if (!$user_id)
		{
			/**
			** If we can't insert this user we need to delete the first one
			** already created to avoid inconsistent data
			*/
			$sql = 'DELETE
				FROM ' . USERS_TABLE . "
				WHERE group_id = $group_id";
			$db->sql_query($sql);

			remove_me();
			trigger_error('Unable to insert bot into users table<br />....I am self destroying, hasta la vista!</font><br />');
		}
		echo '<font color="green">Done!</font><br />';

		echo 'Restoring default BOTs into BOT_TABLE.... ';
		$sql = 'INSERT INTO ' . BOTS_TABLE . ' ' . $db->sql_build_array('INSERT', array(
			'bot_active'	=> 1,
			'bot_name'		=> (string) $bot_name,
			'user_id'		=> (int) $user_id,
			'bot_agent'		=> (string) $bot_ary[0],
			'bot_ip'		=> (string) $bot_ary[1],
		));
		$db->sql_query($sql);
		echo '<font color="green">Done!</font><br />';
	}

	/* Final step and thanks for all the fish */
	echo 'Purging cached BOTs .... ';
	$cache->destroy('_bots');
	echo '<font color="green">Done!</font><br />';

	echo '<br /><font color="blue">BOTs restore exited succesfully!... </font>';

	/* Hasta la vista! */
	echo '<br /><font color="blue"> ...I am self destroying, hasta la vista!</font><br /><br />';

	echo '<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="ZLN6KTV2WQSRN"><input type="image" src="https://www.paypal.com/en_GB/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online."><img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1"><font color="darkred"> Help the development of this Tool by a donation of your choice.</font></form>';

	/* comment out the following line to turn off the self-destroyer. */
	remove_me();
}
else
{
	/* If logged in without the right permissions, stop everything and self-destroy */
	remove_me();
	trigger_error('You don\'t have permission to access the database and files. You need to be logged in as a founder or administrator<br />....I am self destroying, hasta la vista!</font><br />');
}

/* Attempting to delete this file */
function remove_me()
{
	@unlink(__FILE__);

	/** Windows IIS servers may have a problem with unlinking recently created files.
	* * So check if file exists and give a message
	*/
	if (file_exists(__FILE__))
	{
		echo 'File could not be deleted. You will need to manually delete the ' . basename(__FILE__) . ' file from the server.';
	}
}
