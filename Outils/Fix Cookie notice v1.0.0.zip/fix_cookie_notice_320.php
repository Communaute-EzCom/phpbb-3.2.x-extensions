<?php
/**
*
* @package phpBB - fix_cookie_notice_320.php v1.0.0
* @ Fix the cookie_notice missing DB config for phpBB 3.2.0 Gold
* @copyright (c) 2017 3Di (Marco T.)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);

/* If ANONYMOUS = login box */
if ((int) $user->data['user_id'] == ANONYMOUS)
{
	login_box(request_var('redirect', "fix_cookie_notice_320.$phpEx"));
}

/* If no founders or admins no party. */
if ((int) $user->data['user_type'] <> USER_FOUNDER || !$auth->acl_get('a_'))
{
	/* If logged in without the right permissions, stop everything and self-destroy */
	trigger_error('You don\'t have permission to access the database and files. You need to be logged in as a founder or administrator.');
}
/* If are founders or admins let's party. */
else if ((int) $user->data['user_type'] == USER_FOUNDER || $auth->acl_get('a_'))
{
	if (!isset($config['cookie_notice']) && phpbb_version_compare($config['version'], '3.2.0', '>='))
	{
		$config = $phpbb_container->get('config');
		$config->set('cookie_notice', 0);

		echo 'The DB config for cookie_notice (phpBB 3.2.0 Gold) has been correctly added.';
		echo '<br>You can now enable it in ACP/general/server configuration/cookie settings.';
		echo '<br><br>';
		echo '<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="ZLN6KTV2WQSRN"><input type="image" src="https://www.paypal.com/en_GB/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal"><img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1"><font color="darkred">  If you like this tool consider to donate - Visit <a href="http://3di.space/32/">3Di\'s WHQ</a> for more.</font></form>';
	}

	else if (isset($config['cookie_notice']))
	{
		echo 'The DB config for cookie_notice already exists, nothing done.';
	}

	else if (phpbb_version_compare($config['version'], '3.2.0', '<'))
	{
		echo 'At least --> phpBB 3.2.0 Gold <-- it is required for this Tool to work.';
	}

	/* comment out the following line to turn off the self-destroyer. */
	remove_me();
}

/* Attempting to delete this file */
function remove_me()
{
	@unlink(__FILE__);

	/** Windows IIS servers may have a problem with unlinking recently created files.
	* * So check if file exists and give a message
	*/
	if (file_exists(__FILE__))
	{
		echo 'File could not be deleted. You will need to manually delete the ' . basename(__FILE__) . ' file from the server.';
	}
}
