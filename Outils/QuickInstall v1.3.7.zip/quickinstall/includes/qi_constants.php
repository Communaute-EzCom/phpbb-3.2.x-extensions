<?php
/**
*
* @package quickinstall
* @copyright (c) 2010 phpBB Limited
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

define('QI_VERSION', '1.3.7');

// Cookies set by QI
define('QI_PROFILE_COOKIE', 'qi_profile');	// Cookie with the latest used profile name as payload.
