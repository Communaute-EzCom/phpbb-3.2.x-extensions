# Canned Messages

This is the repository for the development of the Canned Messages phpBB extension.

[![Build Status](https://travis-ci.org/phpbb-extensions/cannedmessages.svg?branch=master)](https://travis-ci.org/phpbb-extensions/cannedmessages)

## Installation

Copy the extension to phpBB/ext/phpbb/cannedmessages

Go to "ACP" > "Customise" > "Extensions" and enable the "Canned Messages" extension.

## License

[GPLv2](license.txt)
