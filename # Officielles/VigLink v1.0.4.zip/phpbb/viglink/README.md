# VigLink Extension

This is the repository for the development of the VigLink extension for phpBB 3.2.x. The VigLink extension is currently bundled with phpBB 3.2.x releases.

[![Build Status](https://travis-ci.org/phpbb-extensions/viglink.svg)](https://travis-ci.org/phpbb-extensions/viglink)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/phpbb-extensions/viglink/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/phpbb-extensions/viglink/?branch=master)

## License
[GNU General Public License v2](http://opensource.org/licenses/GPL-2.0)
