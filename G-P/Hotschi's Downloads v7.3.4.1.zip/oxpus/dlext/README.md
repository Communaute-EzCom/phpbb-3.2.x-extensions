Hotschi's Downloads
===================

# phpBB 3.2 Downloads Extension

Downloads Extension for [phpBB 3.2] (https://www.phpbb.com/)
Based on Hotschi's Download MOD 7.1.x for phpBB 3.1

## Description

This extension adds a new panel to provide downloads.
The downloads can be sorted in categories with access controls for all users.

## Installation

Upload the content of the folder "ext" into your forum folder /ext/.
After this enable the extension under "ACP" > "Customise" > "Extensions" > "Download Extension for phpBB 3.2"

## Collaborate

* For support visit the forum under https://phpbb3.oxpus.net
* To post an issue with this extention please use the bug tracker https://phpbb3.oxpus.net/dlext/?view=bug_tracker

## License

[GPLv2](license.txt)
