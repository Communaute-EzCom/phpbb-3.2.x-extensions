## Changelog

##### 3.2.2 12/10/2017
- [FIX] #16 moved pbwowext css & assets to extension except style-dependent elements (video assets, premium backgrounds...)
- [CHG] #17 Converted to Twig syntax
- [FIX] #18 fixed the video display
- [FIX] #19 fixed the "fixed" background display
  
##### 3.2.1 09/09/2017
- [UPG] Fix for responsibe view in Topbar  
- [FIX] Versioncheck fix  

##### 3.2.0 03/09/2017
- [UPG] #4 compatible with pbWoW 3.2.1
- [DEL] #3 removed battle.NET avatars and profile fields. to be moved to another extension.    
 
##### 3.0.5b 30/12/2016
- [FIX] fix in migrations

##### 3.0.5 18/12/2016
- [FIX] ACP now correctly sets the version color to red when extension is not up to date. 
- [FIX] Blizzard Static Render Domains Update 

##### 3.0.4 13/11/2016
- [FIX] fix for phpbb 3.1.10

##### 3.0.3 13/11/2016
- [NEW] now uses phpbb native version_helper class to fetch latest version info in ACP.
- [NEW] added Demon hunter class for WoW
- [CHG] Level cap changed to 110
- [NEW] added uninstall feature

