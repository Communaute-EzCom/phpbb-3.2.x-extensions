/**
* bbstyle2
*/
function bbstyle2()
{
	insert_text('%sitename%');
	document.forms[form_name].elements[text_name].focus();
}
