<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

namespace empreintesduweb\hideposts\migrations\v10x;

class v100b3 extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return isset($this->config['edw_hideposts_version']) && version_compare($this->config['edw_hideposts_version'], '1.0.0-b3', '>=');
	}

	static public function depends_on()
	{
		return array('\empreintesduweb\hideposts\migrations\v10x\v100b2');
	}

	public function update_data()
	{
		return array(

			// Add configs
			array('config.add', array('edw_hideposts_search_active', '1')),

			// Add ACP modules
			array('module.add', array('acp', 'ACP_CAT_DOT_MODS', 'ACP_EDW_HIDEPOSTS_EXT_TITLE')),
			array('module.add', array(
				'acp',
				'ACP_EDW_HIDEPOSTS_EXT_TITLE',
				array(
					'module_basename'	=> '\empreintesduweb\hideposts\acp\hideposts_module',
					'modes'				=> array('general_settings'),
				)
			)),

			// Current version
			array('config.update', array('edw_hideposts_version', '1.0.0-b3')),
		);
	}
}