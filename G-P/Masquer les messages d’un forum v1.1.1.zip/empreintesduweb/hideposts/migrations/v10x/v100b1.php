<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

namespace empreintesduweb\hideposts\migrations\v10x;

class v100b1 extends \phpbb\db\migration\migration
{
	public function update_data()
	{
		return array(
			// Current version
			array('config.add', array('edw_hideposts_version', '1.0.0-b1')),

			// Add permission
			array('permission.add', array('f_edw_hideposts_active', false)),

			// Set permissions
			array('permission.permission_set', array('ROLE_FORUM_READONLY', 'f_edw_hideposts_active')),
			array('permission.permission_set', array('ROLE_FORUM_LIMITED', 'f_edw_hideposts_active')),
			array('permission.permission_set', array('ROLE_FORUM_LIMITED_POLLS', 'f_edw_hideposts_active')),
			array('permission.permission_set', array('ROLE_FORUM_STANDARD', 'f_edw_hideposts_active')),
			array('permission.permission_set', array('ROLE_FORUM_POLLS', 'f_edw_hideposts_active')),
			array('permission.permission_set', array('ROLE_FORUM_FULL', 'f_edw_hideposts_active')),
			array('permission.permission_set', array('ROLE_FORUM_ONQUEUE', 'f_edw_hideposts_active')),
		);
	}
}