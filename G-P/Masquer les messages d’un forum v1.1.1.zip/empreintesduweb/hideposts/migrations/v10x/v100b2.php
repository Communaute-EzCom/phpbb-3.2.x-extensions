<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

namespace empreintesduweb\hideposts\migrations\v10x;

class v100b2 extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return isset($this->config['edw_hideposts_version']) && version_compare($this->config['edw_hideposts_version'], '1.0.0-b2', '>=');
	}

	static public function depends_on()
	{
		return array('\empreintesduweb\hideposts\migrations\v10x\v100b1');
	}

	public function update_data()
	{
		return array(
			// Current version
			array('config.update', array('edw_hideposts_version', '1.0.0-b2')),
		);
	}
}