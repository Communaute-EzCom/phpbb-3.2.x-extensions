<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_EDW_HIDEPOSTS_EXT_TITLE'				=> 'Masquer les messages d’un forum',
	'ACP_EDW_HIDEPOSTS_TITLE_SETTINGS'			=> 'Configuration',

	// General
	'ACP_EDW_HIDEPOSTS_TITLE_PERMIT'			=> 'Permissions de l’utilisateur invité',
	'ACP_EDW_HIDEPOSTS_PERMIT_FORUMS'			=> 'Selection des forums dont l’accès au contenu des sujets sera masqué pour l’utilisateur invité',
	'ACP_EDW_HIDEPOSTS_PERMIT_FORUMS_EXPLAIN'	=> 'Choisissez ci-contre les forums dont l’accès au contenu des sujets <strong>ne sera PAS autorisé</strong> pour l’utilisateur invité.<br />Pour sélectionner / désélectionner plusieurs groupes maintenir la touche CTRL tout en cliquant.<br />Les catégories sont exclus par défaut.<br /><span style="color: #FF0000">Ce réglage ne concerne que l’utilisateur invité. Pour les autres membres, il faut régler les permissions groupes/forums.</span>',
	'ACP_EDW_HIDEPOSTS_TITLE_SEARCH'			=> 'Recherche',
	'ACP_EDW_HIDEPOSTS_SEARCH'					=> 'Masquer le contenu des messages sur la page de recherche',
	'ACP_EDW_HIDEPOSTS_SEARCH_EXPLAIN'			=> 'En activant cette option, les membres concernés par la restriction ne verront que le titre du sujet et un message d’information. En désactivant cette option les messages s’afficheront normalement au niveau des résultats de la recherche.',

	// Version check
	'ACP_EDW_HIDEPOSTS_VERSION_CHECK'			=> 'Détails de l’extension',
	'ACP_EDW_HIDEPOSTS_ANNOUNCEMENT_TOPIC'		=> 'Annonce de sortie',
	'ACP_EDW_HIDEPOSTS_CURRENT_VERSION'			=> 'Version',
	'ACP_EDW_HIDEPOSTS_DOWNLOAD_LATEST'			=> 'Télécharger la dernière version',
	'ACP_EDW_HIDEPOSTS_LATEST_VERSION'			=> 'Dernière version',
	'ACP_EDW_HIDEPOSTS_NO_INFO'					=> 'Le serveur n’a pu être contacté',
	'ACP_EDW_HIDEPOSTS_NOT_UP_TO_DATE'			=> '%s n’est pas à jour',
	'ACP_EDW_HIDEPOSTS_UP_TO_DATE'				=> '%s est à jour',
	'ACP_EDW_HIDEPOSTS_DOWNLOAD'				=> 'Télécharger la version %s',
));
