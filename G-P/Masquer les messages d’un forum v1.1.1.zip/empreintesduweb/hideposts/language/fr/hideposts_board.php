<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'EDW_HIDEPOSTS_EXPLAIN'						=> 'Vous n’avez pas l’autorisation de voir le contenu de ce sujet.<br />Pour plus d’informations concernant cette restriction, veuillez vous rapprochez d’un administrateur.',

	'EDW_HIDEPOSTS_INFO_TITRE'					=> 'Informations d’accès à ce forum',
	'EDW_HIDEPOSTS_INFO_EXPLAIN'				=> 'L’accès à ce forum a été restreint. Vous ne pouvez pas accéder au contenu des discussions.<br />Pour plus d’informations concernant cette restriction, veuillez vous rapprochez d’un administrateur.',
	'EDW_HIDEPOSTS_INFO_EXPLAIN_SEARCH'			=> '<span style="color: #137C1E; font-weight: bold;">L’accès à ce message a été restreint.<br />Pour plus d’informations concernant cette restriction, veuillez vous rapprochez d’un administrateur.</span>',
));
