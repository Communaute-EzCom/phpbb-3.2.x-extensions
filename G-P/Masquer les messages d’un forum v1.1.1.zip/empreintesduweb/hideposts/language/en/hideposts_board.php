<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'EDW_HIDEPOSTS_EXPLAIN'					=> 'You are not authorised to view the content of this topic.<br />For more information about this restriction, please contact an administrator.',

	'EDW_HIDEPOSTS_INFO_TITRE'				=> 'Information about accessing this forum',
	'EDW_HIDEPOSTS_INFO_EXPLAIN'			=> 'Full access to this forum is restricted. You cannot access the content of the discussions.<br />For more information about this restriction, please contact an administrator.',
	'EDW_HIDEPOSTS_INFO_EXPLAIN_SEARCH'		=> '<span style="color: #137C1E; font-weight: bold;">Access to this message is restricted.<br />For more information about this restriction, please contact an administrator.</span>',
));
