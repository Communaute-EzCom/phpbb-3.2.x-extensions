<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACL_F_EDW_HIDEPOSTS_ACTIVE'			=> '[EDW] Can see the messages in topics',
));
