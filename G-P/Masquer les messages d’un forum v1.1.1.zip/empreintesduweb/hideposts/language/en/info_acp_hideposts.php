<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_EDW_HIDEPOSTS_EXT_TITLE'				=> 'Hide the messages of a specific forum',
	'ACP_EDW_HIDEPOSTS_TITLE_SETTINGS'			=> 'Configuration',

	// General
	'ACP_EDW_HIDEPOSTS_TITLE_PERMIT'			=> 'Permissions of the guest user',
	'ACP_EDW_HIDEPOSTS_PERMIT_FORUMS'			=> 'Selection of the forums where access to topics content will be denied to the guest user',
	'ACP_EDW_HIDEPOSTS_PERMIT_FORUMS_EXPLAIN'	=> 'Please select the forums where access to the topics content <strong>will NOT be allowed</strong> for the guest user.<br />To select / deselect multiple groups hold the CTRL key while clicking.<br />The categories are excluded by default.<br /><span style="color: #FF0000">This setting only applies to the guest user. For other members, you must set the permissions groups/forums.</Span>',
	'ACP_EDW_HIDEPOSTS_TITLE_SEARCH'			=> 'Search',
	'ACP_EDW_HIDEPOSTS_SEARCH'					=> 'Hide messages on the search page',
	'ACP_EDW_HIDEPOSTS_SEARCH_EXPLAIN'			=> 'By enabling this option, the members affected by the restriction will only see the topic titles as well as an information message. By disabling this option the messages are fully displayed within the search results.',

	// Version check
	'ACP_EDW_HIDEPOSTS_VERSION_CHECK'			=> 'Details of the extension',
	'ACP_EDW_HIDEPOSTS_ANNOUNCEMENT_TOPIC'		=> 'Release announcement',
	'ACP_EDW_HIDEPOSTS_CURRENT_VERSION'			=> 'Version',
	'ACP_EDW_HIDEPOSTS_DOWNLOAD_LATEST'			=> 'Download the latest version',
	'ACP_EDW_HIDEPOSTS_LATEST_VERSION'			=> 'Latest version',
	'ACP_EDW_HIDEPOSTS_NO_INFO'					=> 'The server could not be contacted',
	'ACP_EDW_HIDEPOSTS_NOT_UP_TO_DATE'			=> '%s extension is outdated',
	'ACP_EDW_HIDEPOSTS_UP_TO_DATE'				=> '%s extension is up to date',
	'ACP_EDW_HIDEPOSTS_DOWNLOAD'				=> 'Download version %s',
));
