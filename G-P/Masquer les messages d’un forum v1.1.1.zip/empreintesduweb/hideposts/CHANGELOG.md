# Changelog

## 1.1.1 - 11-05-2016

- Corrections suggérées dans ce message par Skouat : http://forums.phpbb-fr.com/extensions-developpement-en-cours-phpbb31/sujet207711-60.html#p1626334
- Suppression de la vérification de version depuis l'espace de réglage de l'extension, car cette possibilité existe déjà dans phpBB

## 1.1.0 - 01-05-2016

- Ajout de la gestion des permissions pour l'utilisateur invité dans l'onglet "Extensions"

	Ce qui amène a modifier le comportement de l'option pour la partie recherche (penser à vérifier vos réglages si mis à jour depuis une version antérieure)

- Corrections suggérées dans ce message par Skouat : http://forums.phpbb-fr.com/extensions-developpement-en-cours-phpbb31/sujet207711-15.html#p1625531

## 1.0.0-b3 - 24-04-2016

- Ajout du suivi de version dans l’ACP
- Possibilité d’afficher ou non le contenu d’un message dans les résultats d’une recherche

## 1.0.0-b2 - 21-04-2016

- Ajout de la restriction dans les résultats d'une recherche avec message d'information
- Corrections suggérées dans ce message par Skouat : http://forums.phpbb-fr.com/extensions-developpement-en-cours-phpbb31/sujet207711.html#p1625310

## 1.0.0-b1 - 19-04-2016

- Première version de l'extension