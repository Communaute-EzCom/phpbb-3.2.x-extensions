<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

namespace empreintesduweb\hideposts\acp;

class hideposts_info
{
	function module()
	{
		return array(
			'filename'	=> '\empreintesduweb\hideposts\acp\hideposts_module',
			'title'		=> 'ACP_EDW_HIDEPOSTS_EXT_TITLE',
			'modes'		=> array(
				'general_settings'		=> array(
						'title' => 'ACP_EDW_HIDEPOSTS_TITLE_SETTINGS',
						'auth' => 'ext_empreintesduweb/hideposts && acl_a_board',
						'cat' => array('ACP_EDW_HIDEPOSTS_EXT_TITLE')
					),
			),
		);
	}
}
