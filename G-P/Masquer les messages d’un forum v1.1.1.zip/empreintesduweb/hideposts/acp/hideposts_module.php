<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

namespace empreintesduweb\hideposts\acp;

class hideposts_module
{
	public $u_action;
	protected $new_config = array();
	protected $phpbb_container;

	public function __construct()
	{
		global $phpbb_container;
		$this->phpbb_container = $phpbb_container;
	}

	public function main($id, $mode)
	{
		global $config, $user, $template, $request, $phpbb_container;

		$this->config_text = $phpbb_container->get('config_text');

		$this->page_title = 'ACP_EDW_HIDEPOSTS_EXT_TITLE';
		$this->tpl_name = 'acp_hideposts';

		$form_key = 'hideposts_module';
		add_form_key($form_key);

		if ($request->is_set_post('submit'))
		{
			// Test if form key is valid
			if (!check_form_key($form_key))
			{
				trigger_error($user->lang['FORM_INVALID'] . adm_back_link($this->u_action), E_USER_WARNING);
			}
			else
			{
				// Set the options the user configured
				$this->set_options();

				trigger_error($user->lang['CONFIG_UPDATED'] . adm_back_link($this->u_action));
			}
		}

		switch ($mode)
		{
			case 'general_settings':

				$template->assign_vars(array(
					'S_HIDEPOSTS_SEARCH_ACTIVE'		=> ($config['edw_hideposts_search_active']) ? true : false,
					'S_SELECTION_FORUMS'			=> make_forum_select(explode(',', $this->config_text->get('edw_hideposts_selection_forums')), false, false, true),
				));

				break;
		}

	}

	protected function set_options()
	{
		global $config, $request;

		$config->set('edw_hideposts_search_active', $request->variable('edw_hideposts_search_active', 0));
		$this->config_text->set('edw_hideposts_selection_forums', implode(',', $request->variable('edw_hideposts_selection_forums', array(0))));
	}
}