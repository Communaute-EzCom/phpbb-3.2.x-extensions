<?php
/**
* @copyright (c) EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*/

namespace empreintesduweb\hideposts\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $auth;
	protected $template;
	protected $user;
	protected $config;
	protected $config_text;
	protected $db;

	public function __construct(\phpbb\auth\auth $auth, \phpbb\template\template $template, \phpbb\user $user, \phpbb\config\config $config, \phpbb\config\db_text $config_text, \phpbb\db\driver\driver_interface $db)
	{
		$this->auth = $auth;
		$this->template = $template;
		$this->user = $user;
		$this->config = $config;
		$this->config_text = $config_text;
		$this->db = $db;
	}

	static public function getSubscribedEvents()
	{
		return array(
			// ACP event
			'core.permissions'								=> 'add_permission',
			'core.viewtopic_assign_template_vars_before'	=> 'hideposts_error',
			'core.viewforum_get_topic_data'					=> 'hideposts_info',
			'core.search_modify_tpl_ary'					=> 'core_search_modify_tpl_ary',

			// Language
			'core.user_setup'								=> 'hideposts_board',
		);
	}

	public function core_search_modify_tpl_ary($event)
	{
		if ($event['show_results'] == 'posts' && $this->config['edw_hideposts_search_active'])
		{
			$tpl_ary = $event['tpl_ary'];

			if ($this->selection_forums_and_groups($tpl_ary['FORUM_ID']))
			{
				$tpl_ary['MESSAGE'] = $this->user->lang['EDW_HIDEPOSTS_INFO_EXPLAIN_SEARCH'];
			}

			$event['tpl_ary'] = $tpl_ary;
		}
	}

	public function add_permission($event)
	{
		$permissions = $event['permissions'];
		$permissions['f_edw_hideposts_active'] = array('lang' => 'ACL_F_EDW_HIDEPOSTS_ACTIVE', 'cat' => 'actions');
		$event['permissions'] = $permissions;
	}

	public function hideposts_board($event)
	{
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'empreintesduweb/hideposts',
			'lang_set' => 'hideposts_board',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}

	public function hideposts_info($event)
	{

		$this->template->assign_vars(array(
			'S_EDW_HIDEPOSTS_INFO_ACTIVE'		=> ($this->selection_forums_and_groups($event['forum_id'])) ? true : false,
		));
	}

	public function hideposts_error($event)
	{
		if ($this->selection_forums_and_groups($event['forum_id']))
		{
			trigger_error('EDW_HIDEPOSTS_EXPLAIN');
		}
	}

	private function selection_forums_and_groups($forum_id)
	{
		if ($this->user->data['user_id'] == ANONYMOUS)
		{
			$forums_list = explode(',', $this->config_text->get('edw_hideposts_selection_forums'));

			$selection_forums_and_groups = (in_array($forum_id, $forums_list)) ? true : false;
		}
		else
		{
			$selection_forums_and_groups = (!$this->auth->acl_get('f_edw_hideposts_active', $forum_id)) ? true : false;
		}

		return $selection_forums_and_groups;
	}
}

?>