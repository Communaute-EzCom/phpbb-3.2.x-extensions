Credits

add.mp3		UI Buttons and Whooshes Pack 1 by Narfstuff http://www.narfstuff.co.uk/
edit.mp3	Scribble by TiesWijnen https://www.freesound.org/people/TiesWijnen/sounds/341738/
del.mp3		Paper Throw http://www.soundjay.com/
error.mp3	GUI Sound Effects by Lokif http://opengameart.org/content/gui-sound-effects
