<?php
/**
 *
 * JV Privacy Policy and data management tool. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 KillBill <https://jv-arcade.com>
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

/*
%1$s :: Website name
%2$s :: Controller name
%3$s :: Contact email address
%4$s :: Phone number of the controller
%5$s :: Description of cookies in use
%6$s :: Added plus one line if we disable cookies for guests
*/

$lang = array_merge($lang, array(
	'JVPPDMT_PRIVACY_POLICY'		=> 'Politique de vie privée',
	'JVPPDMT_PRIVACY_POLICY_DESC'	=> ' La protection des données tient une place importante sur le forum « %1$s ». La navigation sur les pages du forum « %1$s » est possible sans obligation de fournir une quelconque information personnelle. Cependant, si une fonctionnalité sur notre forum requiert l’utilisation d’un service tiers, le traitement de données personnelles pourrait être nécessaire. Si le traitement de données personnelles est nécessaire et qu’il n’existe aucune base légale pour un tel traitement alors nous sollicitons le consentement de l’utilisateur concerné.

Le traitement de données personnelles, tels que le nom, l’adresse, l’adresse e-mail ou le numéro de téléphone d’une personne concernée doit toujours être conforme au règlement général sur la protection des données (RGPD - <a onclick="window.open(this.href); return false;" href="https://www.cnil.fr/fr/reglement-europeen-protection-donnees">https://www.cnil.fr/fr/reglement-europeen-protection-donnees</a>) et conformément à la règlementation nationale en matière de protection des données applicable au forum « %1$s ». Par la présente déclaration de protection des données, nous souhaitons informer le grand public de la nature, de l’étendue et de la finalité des données personnelles que nous collectons, utilisons et traitons. En outre, les personnes concernées sont informées, au moyen de cette déclaration de protection des données, des droits auxquels elles ont droit.

Le responsable du forum « %1$s » a mis en place de nombreuses mesures techniques et organisationnelles pour s’assurer de la protection la plus complète des données personnelles traitées sur ce forum. Toutefois, les transmissions de données par Internet peuvent en principe présenter des lacunes de sécurité, de sorte qu’une protection absolue ne peut pas être garantie. Pour cette raison, chaque personne concernée est libre de nous transmettre des données personnelles par d’autres moyens, par exemple par téléphone.

<h3>Définitions</h3>
La déclaration de protection des données du forum « %1$s » est basée sur les termes utilisés par le législateur européen pour l’adoption du règlement général sur la protection des données (RGPD). Notre déclaration de protection des données doit être lisible et compréhensible pour le grand public, ainsi que pour nos clients et partenaires. Pour ce faire, nous souhaitons d’abord expliquer la terminologie utilisée.

Dans cette déclaration de protection des données, nous utilisons, entre autres, les termes suivants :

<strong>a) Données personnelles</strong>
Par données à caractère personnel, on entend toute information concernant une personne physique identifiée ou identifiable (« personne concernée »). Une personne physique identifiable est une personne qui peut être identifiée, directement ou indirectement, notamment par référence à un identifiant tel qu’un nom, un numéro d’identification, des données de localisation, un identifiant en ligne ou à un ou plusieurs facteurs spécifiques liés à l’identité physique, physiologique, génétique, mentale, économique, économique, culturelle ou sociale de cette personne physique.

<strong>b) Personnes concernées</strong>
La personne concernée est toute personne physique identifiée ou identifiable, dont les données à caractère personnel sont traitées par le responsable du traitement.

<strong>c) Traitement</strong>
Le traitement est toute opération ou ensemble d’opérations effectuées sur des données à caractère personnel ou sur des ensembles de données à caractère personnel, que ce soit ou non par des moyens automatisés, tels que la collecte, l’enregistrement, l’organisation, la structuration, le stockage, l’adaptation ou la modification, la récupération, la consultation, l’utilisation, la divulgation par transmission, la diffusion ou toute autre forme de mise à disposition, l’alignement ou la combinaison, la restriction, la suppression ou la destruction.

<strong>d) Restriction du traitement</strong>
La limitation du traitement est le marquage des données personnelles stockées dans le but de limiter leur traitement à l’avenir.

<strong>e) Contrôleur responsable du traitement</strong>
Le responsable du traitement est la personne physique ou morale, l’autorité publique, l’agence ou tout autre organisme qui, seul ou conjointement avec d’autres, détermine les finalités et les moyens du traitement des données à caractère personnel ; lorsque les finalités et les moyens de ce traitement sont déterminés par le droit de l’Union ou de l’État membre, le responsable du traitement ou les critères spécifiques de sa désignation peuvent être prévus par le droit de l’Union ou de l’État membre.

<strong>f) Sous-traitant</strong>
Le sous-traitant est une personne physique ou morale, une autorité publique, une agence ou tout autre organisme qui traite des données à caractère personnel pour le compte du responsable du traitement.

<strong>g) Destinataire (d’un traitement de données)</strong>
Le destinataire est une personne physique ou morale, une autorité publique, une agence ou un autre organisme auquel les données personnelles sont communiquées, qu’il s’agisse d’un tiers ou non. Toutefois, les autorités publiques qui peuvent recevoir des données à caractère personnel dans le cadre d’une enquête particulière conformément au droit de l’Union ou de l’État membre ne sont pas considérées comme des destinataires ; le traitement de ces données par ces autorités publiques se fait dans le respect des règles applicables en matière de protection des données, conformément aux finalités du traitement.

<strong>h) Tiers</strong>
Un tiers est une personne physique ou morale, une autorité publique, une agence ou un organisme autre que la personne concernée, le responsable du traitement, le sous-traitant et les personnes qui, sous l’autorité directe du responsable du traitement ou du sous-traitant, sont autorisées à traiter des données à caractère personnel.

<strong>i) Consentement explicite</strong>
Le consentement de la personne concernée est toute indication librement donnée, spécifique, informée et sans ambigüité de la volonté de la personne concernée, par laquelle celle-ci, par une déclaration ou par une action affirmative claire, signifie son consentement au traitement des données à caractère personnel la concernant.

<h3>Données du contrôleur</h3>
Responsable du traitement aux fins du règlement général sur la protection des données (RGPD), d’autres lois sur la protection des données applicables dans les États membres de l’Union européenne et d’autres dispositions relatives à la protection des données :

<strong>Contrôleur :</strong> %2$s

<strong>Adresse e-mail de contact :</strong> %3$s
<strong>Numéro de téléphone :</strong> %4$s

<h3>Cookies</h3>
Les pages web du forum « %1$s » utilisent des cookies. Les cookies sont des fichiers texte qui sont stockés dans un système informatique au moyen d’un navigateur web.

De nombreux sites web et serveurs utilisent des cookies. De nombreux cookies contiennent un identifiant de cookie. Un identifiant de cookie est un identifiant unique du cookie. Il s’agit d’une chaine de caractères à travers laquelle les pages web et les serveurs peuvent être affectés au navigateur web spécifique dans lequel le cookie a été stocké. Cela permet aux sites web visités et aux serveurs de différencier le navigateur individuel de la personne concernée des autres navigateurs web qui contiennent d’autres cookies. Un navigateur web spécifique peut être reconnu et identifié à l’aide d’un cookie unique.

Grâce à l’utilisation de cookies, le forum « %1$s » peut fournir aux utilisateurs de ce forum des services plus conviviaux qui ne seraient pas possibles sans l’utilisation de cookies.

Par le biais d’un cookie, les informations et les offres de notre forum peuvent être optimisées en fonction de l’utilisateur. Les cookies nous permettent, comme mentionné précédemment, de reconnaître les utilisateurs de notre forum. Le but de cette reconnaissance est de faciliter l’utilisation de notre forum. L’utilisateur du forum qui utilise des cookies, par exemple, n’a pas besoin d’entrer des données d’accès à chaque fois qu’il accède au forum, parce qu’il est pris en charge par le forum et le cookie est donc stocké sur le système informatique de l’utilisateur. Un autre exemple est le cookie d’un panier d’achat dans une boutique en ligne. La boutique en ligne se souvient des articles qu’un client a placés dans le panier virtuel via un cookie. Un jeu par navigateur peut enregistrer le score actuel ou le statut du niveau dans un cookie et à la fin du jeu, retourner au tableau d’affichage pour son stockage.

Exemples concrets de l’utilisation de cookies sur notre forum :

%5$s

À tout moment, la personne concernée peut, depuis son navigateur web, inhiber l’installation de cookies provenant de notre forum et refuser de façon permanente l’installation de cookies. De plus, les cookies déjà configurés peuvent être supprimés à tout moment de son navigateur web ou via d’autres logiciels. Ceci est possible dans tous les navigateurs web populaires. Si la personne concernée désactive la configuration des cookies depuis son navigateur web, toutes les fonctionnalités de notre forum ne seront pas disponibles et un message tel que celui ci-dessous s’affichera en rouge :
%6$s
<h3>Collecte de données et d’informations générales</h3>
Le forum « %1$s » collecte un ensemble de données et d’informations générales lorsqu’une personne concernée ou un système automatisé consulte le forum. Ces données et informations générales sont stockées dans les fichiers journaux du serveur. Les données collectées peuvent être (1) les types et versions de navigateurs web utilisés, (2) le système d’exploitation utilisé par le système d’accès, (3) le site Web à partir duquel un système informatique accède à notre forum (appelés référents), (4) les sous-sites web, (5) la date et l’heure d’accès au forum, (6) une adresse de protocole Internet (adresse IP), (7) le fournisseur de services Internet du système d’accès et (8) toute autre donnée et information similaire qui peut être utilisée en cas d’attaques sur nos systèmes de technologie de l’information.

Lors de l’utilisation de ces données et informations générales, le forum « %1$s » ne tire aucune conclusion sur la personne concernée. Ces informations sont plutôt nécessaires pour (1) diffuser correctement le contenu de notre forum, (2) optimiser le contenu de notre forum ainsi que sa publicité, (3) assurer la viabilité à long terme de nos systèmes informatiques et de la technologie de notre forum et (4) fournir aux autorités chargées de l’application de la loi les informations nécessaires aux poursuites pénales en cas de cyberattaque. Par conséquent, le forum « %1$s » analyse les données et informations collectées de manière anonyme et statistiquement, dans le but d’augmenter la protection des données et la sécurité des données de notre forum et d’assurer un niveau optimal de protection des données personnelles que nous traitons. Les données anonymes des fichiers journaux du serveur sont stockées séparément de toutes les données personnelles fournies par la personne concernée.

<h3>Enregistrement sur notre forum</h3>
La personne concernée a la possibilité de s’enregistrer sur le forum du responsable du traitement avec l’information des données personnelles. L’enregistrement de la personne concernée, avec indication volontaire de données à caractère personnel, est destiné à permettre au responsable du traitement d’offrir à la personne concernée des contenus ou des services qui ne peuvent être offerts qu’aux utilisateurs enregistrés en raison de la nature dont il est question ici. Les données personnelles transmises au responsable du traitement sont déterminées par le masque de saisie utilisé pour l’enregistrement. Les données personnelles saisies par la personne concernée sont collectées et conservées exclusivement pour l’usage interne du responsable du traitement et pour ses propres besoins.

Pour enregistrer un compte sur le forum du contrôleur, il faut au minimum les données personnelles suivantes : un nom d’utilisateur unique et identifiable, un mot de passe personnel utilisé pour se connecter à votre compte et une adresse e-mail personnelle et valide. Cette adresse e-mail est nécessaire pour recevoir le lien de confirmation utilisé pour authentifier l’enregistrement et pour recevoir d’autres messages du forum. Les différents types de notifications peuvent être configurés depuis le « Panneau de l’utilisateur » après s’être connecté au forum. Votre mot de passe est chiffré (hachage unidirectionnel) afin qu’il soit sécurisé. Cependant, il est recommandé de ne pas réutiliser le même mot de passe sur plusieurs sites Web différents. Votre mot de passe est le moyen d’accéder à votre compte sur ce forum, alors gardez-le soigneusement. En aucun cas, une personne affiliée à ce forum ou à un tiers ne vous demandera légitimement votre mot de passe. Si vous oubliez votre mot de passe pour votre compte, vous pouvez utiliser la fonctionnalité : « J’ai oublié mon mot de passe ». Ce processus vous demandera de soumettre le nom d’utilisateur utilisé et l’adresse e-mail que vous avez entré dans votre profil, puis le forum génèrera un nouveau mot de passe pour récupérer votre compte. Pour cette raison, il est recommandé de toujours tenir à jour l’adresse e-mail indiquée dans son profil.

En s’enregistrant sur le forum du responsable du traitement, l’adresse IP attribuée par le fournisseur d’accès à Internet (FAI) utilisée par la personne concernée et l’heure de l’enregistrement sont également stockées. Le stockage de ces données est effectué car c’est le seul moyen d’inhiber l’utilisation abusive de nos services et, si nécessaire, de permettre d’enquêter sur les infractions commises. Dans la mesure où le stockage de ces données est nécessaire pour sécuriser le responsable du traitement. Ces données ne sont pas transmises à des tiers, sauf s’il existe une obligation légale de transmettre les données ou si le transfert sert à des fins de poursuites pénales.

En s’enregistrant sur le forum du responsable du traitement, la personne concernée permet au responsable du traitement de stocker les données qu’elle a saisies lors de son enregistrement et dans son profil, ainsi que les données d’accès continu (date et heure d’utilisation, adresse IP, données de localisation, scores et autres données transmises par le navigateur de la personne concernée) et de les utiliser pour le fonctionnement du forum. Il convient de noter que toutes les données saisies dans le profil et les messages écrits par la personne concernée peuvent être disponibles sur Internet en fonction de la configuration et peuvent être consultés par n’importe qui. En outre, la personne concernée peut être contactée par le forum pour transmettre les messages administratifs nécessaires à la création et à la gestion du compte utilisateur.

Les personnes enregistrées sont libres de modifier à tout moment les données personnelles spécifiées lors de l’enregistrement ou de les faire supprimer complètement du stock de données du responsable du traitement.

Le responsable du traitement fournit à tout moment à chaque personne concernée qui en fait la demande des informations sur les données à caractère personnel stockées la concernant. En outre, le responsable du traitement rectifie ou supprime les données à caractère personnel à la demande ou sur indication de la personne concernée, dans la mesure où il n’y a pas d’obligation légale de conservation. L’ensemble des collaborateurs du responsable du traitement sont à cet égard à la disposition de la personne concernée en tant que personnes de contact.

<h3>Dispositions de contact via le forum</h3>
Le forum « %1$s » met à disposition des informations permettant de contacter rapidement, voire directement, l’équipe en charge du forum. Informations comprenant une adresse générale du courrier électronique (adresse e-mail) et le cas échéant un numéro de téléphone. Si une personne concernée contacte le responsable du traitement par courrier électronique ou via un formulaire de contact, les données personnelles transmises par la personne concernée sont automatiquement stockées. Ces données à caractère personnel transmises volontairement par une personne concernée au responsable du traitement sont conservées aux fins de traitement ou de prise de contact avec la personne concernée. Il n’y a pas de transfert de ces données personnelles à des tiers.

<h3>Suppression et blocage des données personnelles</h3>
Le responsable du traitement traite et stocke les données à caractère personnel de la personne concernée uniquement pour la période nécessaire à la réalisation de l’objectif de stockage ou dans la mesure où cela est autorisé par le législateur européen ou d’autres législateurs dans les lois ou règlements auxquels le responsable du traitement est soumis.

Si la finalité de conservation n’est pas applicable, ou si une période de conservation prescrite par le législateur européen ou un autre législateur compétent expire, les données à caractère personnel sont systématiquement bloquées ou supprimées conformément aux exigences légales.

<h3>Droits de la personne concernée</h3>
<strong>a) Droit de confirmation</strong>
Chaque personne concernée a le droit, accordé par le législateur européen, d’obtenir du responsable du traitement la confirmation que des données à caractère personnel la concernant font ou non l’objet d’un traitement. Si une personne concernée souhaite se prévaloir de ce droit de confirmation, elle peut, à tout moment, contacter n’importe quel collaborateur du responsable du traitement.

<strong>b) Droit d’accès</strong>
Chaque personne concernée a le droit, accordé par le législateur européen, d’obtenir du responsable du traitement des informations gratuites sur ses données à caractère personnel stockées à tout moment, ainsi qu’une copie de ces informations. En outre, les directives et règlements européens accordent à la personne concernée l’accès aux informations suivantes :
- les finalités du traitement ;
- les catégories de données à caractère personnel concernées ;
- les destinataires ou catégories de destinataires auxquels les données à caractère personnel ont été ou seront communiquées, en particulier les destinataires dans des pays tiers ou des organisations internationales ;
- si possible, la période envisagée pour laquelle les données à caractère personnel seront conservées ou, si ce n’est pas possible, les critères utilisés pour déterminer cette période ;
- l’existence d’un droit de demander au responsable du traitement la rectification ou la suppression des données à caractère personnel, ou la limitation du traitement des données à caractère personnel concernant la personne concernée, ou de s’opposer à un tel traitement ;
- l’existence du droit de déposer une plainte auprès d’une autorité de contrôle ;
- lorsque les données à caractère personnel ne sont pas collectées auprès de la personne concernée, toute information disponible sur l’origine de ces données ;
- l’existence d’un processus décisionnel automatisé, y compris le profilage, visé à l’article 22, paragraphes 1 et 4, du RGPD et, au moins dans ces cas, des informations utiles sur la logique en cause, ainsi que sur l’importance et les conséquences envisagées d’un tel traitement pour la personne concernée.

En outre, la personne concernée a le droit d’obtenir des informations sur le transfert de données à caractère personnel vers un pays tiers ou vers une organisation internationale. Dans ce cas, la personne concernée a le droit d’être informée des garanties appropriées relatives au transfert.

Si une personne concernée souhaite se prévaloir de ce droit d’accès, elle peut, à tout moment, contacter n’importe quel collaborateur du responsable du traitement.

<strong>c) Droit de rectification</strong>
Chaque personne concernée a le droit, accordé par le législateur européen, d’obtenir du responsable du traitement, sans retard injustifié, la rectification de données à caractère personnel inexactes la concernant. Compte tenu des finalités du traitement, la personne concernée a le droit de faire compléter des données à caractère personnel incomplètes, y compris en fournissant une déclaration supplémentaire.

Si une personne concernée souhaite exercer ce droit de rectification, elle peut, à tout moment, contacter n’importe quel collaborateur du responsable du traitement.

<strong>d) Droit à l’effacement (Droit à l’oubli)</strong>
Chaque personne concernée a le droit, accordé par le législateur européen, d’obtenir du responsable du traitement la suppression des données à caractère personnel la concernant sans retard injustifié et le responsable du traitement a l’obligation de supprimer les données à caractère personnel sans retard injustifié lorsque l’un des motifs suivants s’applique, pour autant que le traitement ne soit pas nécessaire :
- Les données à caractère personnel ne sont plus nécessaires au regard des finalités pour lesquelles elles ont été collectées ou traitées d’une autre manière ;
- La personne concernée retire le consentement sur la base duquel le traitement est fondé conformément à l’article 6, paragraphe 1, point a), du RGPD, ou à l’article 9, paragraphe 2, point a), du RGPD et lorsqu’il n’existe aucun autre motif légal pour le traitement ;
- La personne concernée s’oppose au traitement conformément à l’article 21, paragraphe 1, du RGPD et il n’existe aucune raison légitime justifiant le traitement, ou la personne concernée s’oppose au traitement conformément à l’article 21, paragraphe 2, du RGPD ;
- Les données à caractère personnel ont fait l’objet d’un traitement illicite ;
- Les données à caractère personnel doivent être supprimées afin de respecter une obligation légale du droit de l’Union ou de l’État membre auquel le responsable du traitement est soumis ;
- Les données à caractère personnel ont été collectées en relation avec l’offre de services de la société de l’information visée à l’article 8, paragraphe 1, du RGPD.

Si l’une des raisons susmentionnées s’applique et qu’une personne concernée souhaite demander la suppression des données personnelles stockées par le forum « %1$s », elle peut, à tout moment, contacter n’importe quel collaborateur du responsable du traitement. Un membre de l’équipe du forum « %1$s » devra s’assurer que la demande de suppression soit effectuée dans les plus brefs délais.

Lorsque le responsable du traitement a rendu publiques des données à caractère personnel et est tenu, en vertu de l’article 17, paragraphe 1, du RGPD, de supprimer les données à caractère personnel, le responsable du traitement, compte tenu de la technologie disponible et du cout de la mise en œuvre, prend des mesures raisonnables, y compris des mesures techniques, pour informer les autres responsables du traitement des données à caractère personnel que la personne concernée a demandé la suppression par ces responsables du traitement de tout lien avec ses données à caractère personnel, ou de toute copie ou reproduction de ses données, dans la mesure où le traitement n’est pas nécessaire. Un membre de l’équipe du forum « %1$s » prendra les mesures nécessaires dans des cas individuels.

<strong>e) Droit de restriction du traitement</strong>
Chaque personne concernée a le droit, accordé par le législateur européen, d’obtenir du responsable du traitement une limitation du traitement lorsque l’une des conditions suivantes s’applique :
- L’exactitude des données à caractère personnel est contestée par la personne concernée, pendant une période permettant au responsable du traitement de vérifier l’exactitude des données à caractère personnel ;
- Le traitement est illicite et la personne concernée s’oppose à l’effacement des données personnelles et demande au lieu de cela la limitation de leur utilisation ;
- Le responsable du traitement n’a plus besoin des données à caractère personnel aux fins du traitement, mais elles sont requises par la personne concernée pour la constatation, l’exercice ou la défense d’actions en justice ;
- La personne concernée s’est opposée au traitement conformément à l’article 21, paragraphe 1, du RGPD dans l’attente de la vérification du fait que les motifs légitimes du responsable du traitement l’emportent sur ceux de la personne concernée.

Si l’une des conditions susmentionnées est remplie et qu’une personne concernée souhaite demander la limitation du traitement des données personnelles stockées par le forum « %1$s », elle peut à tout moment contacter n’importe quel collaborateur du responsable du traitement. Alors, l’un des membres de l’équipe du forum « %1$s » s’occupera de restreindre le traitement.

<strong>f) Droit à la portabilité des données</strong>
Chaque personne concernée a le droit, accordé par le législateur européen, de recevoir les données à caractère personnel la concernant, qui ont été fournies à un responsable du traitement, dans un format structuré, couramment utilisé et lisible par une machine. Il a le droit de transmettre ces données à un autre responsable du traitement sans entrave de la part du responsable du traitement auquel les données à caractère personnel ont été communiquées, pour autant que le traitement soit fondé sur le consentement conformément à l’article 6, paragraphe 1, point a), du RGPD ou à l’article 9, paragraphe 2, point a), du RGPD, soit dans le cadre d’un contrat au sens de l’article 6, paragraphe 1, point b), du RGPD et que le traitement est effectué par des moyens automatisés, pour autant que le traitement n’est pas nécessaire à l’exécution d’une mission effectuée dans l’intérêt public ou dans l’exercice de l’autorité publique dont est investi le responsable du traitement.

En outre, dans l’exercice de son droit à la transférabilité des données conformément à l’article 20, paragraphe 1, du RGPD, la personne concernée a le droit de voir ses données à caractère personnel transmises directement d’un responsable du traitement à un autre, lorsque cela est techniquement possible et que cela ne porte pas atteinte aux droits et libertés d’autrui.

Pour faire valoir le droit à la transférabilité des données, la personne concernée peut à tout moment contacter n’importe quel membre de l’équipe du forum « %1$s ».

<strong>g) Droit d’opposition</strong>
Chaque personne concernée a le droit, accordé par le législateur européen, de s’opposer, à tout moment, pour des motifs liés à sa situation particulière, au traitement des données à caractère personnel la concernant, qui est fondé sur l’article 6, paragraphe 1, point e) ou f), du RGPD. Ceci s’applique également au profilage sur la base de ces dispositions.

Le forum « %1$s » ne traitera plus les données personnelles en cas d’objection, à moins que nous puissions démontrer des raisons légitimes pour le traitement qui l’emporteraient sur les intérêts, droits et libertés de la personne concernée, ou pour l’établissement, l’exercice ou la défense de droits légaux.

Si le forum « %1$s » traite des données à caractère personnel à des fins de marketing direct, la personne concernée a le droit de s’opposer à tout moment au traitement des données à caractère personnel la concernant à des fins de marketing direct. Cela s’applique au profilage dans la mesure où il est lié à ce type de marketing direct. Si la personne concernée s’oppose au traitement du forum « %1$s » à des fins de marketing direct, le forum « %1$s » ne traitera plus les données personnelles à ces fins.

En outre, la personne concernée a le droit, pour des motifs liés à sa situation particulière, de s’opposer au traitement de données à caractère personnel la concernant par le forum « %1$s » à des fins de recherche scientifique ou historique, ou à des fins statistiques conformément à l’article 89.1 du RGPD, à moins que le traitement ne soit nécessaire à l’exécution d’une mission effectuée pour des raisons d’intérêt public.

Afin d’exercer son droit d’opposition, la personne concernée peut contacter n’importe quel membre de l’équipe du forum « %1$s ». En outre, la personne concernée est libre, dans le cadre de l’utilisation des services de la société de l’information et nonobstant la directive 2002/58/CE, d’utiliser son droit d’opposition par des moyens automatisés utilisant des spécifications techniques.

<strong>h) Prise de décision individuelle automatisée, y compris le profilage</strong>
Chaque personne concernée a le droit, conféré par le législateur européen, de ne pas faire l’objet d’une décision fondée uniquement sur un traitement automatisé, y compris le profilage, qui produit des effets juridiques à son égard ou qui l’affecte de manière similaire de manière significative, tant que la décision (1) n’est pas nécessaire à la conclusion ou à l’exécution de, un contrat entre la personne concernée et un responsable du traitement, ou (2) n’est pas autorisé par le droit de l’Union ou de l’État membre auquel le responsable du traitement est soumis et qui prévoit également des mesures appropriées pour sauvegarder les droits et libertés et les intérêts légitimes de la personne concernée, ou (3) n’est pas fondé sur le consentement explicite de la personne concernée.

Si la décision (1) est nécessaire à la conclusion ou à l’exécution d’un contrat entre la personne concernée et un responsable du traitement, ou (2) si elle est fondée sur le consentement explicite de la personne concernée, le forum « %1$s » doit mettre en œuvre des mesures appropriées pour sauvegarder les droits et libertés et les intérêts légitimes de la personne concernée, au moins le droit d’obtenir une intervention humaine de la part du responsable du traitement, d’exprimer son point de vue et de contester la décision.

Si la personne concernée souhaite exercer les droits relatifs à la prise de décision individuelle automatisée, elle peut, à tout moment, contacter n’importe quel membre de l’équipe du forum « %1$s ».

<strong>i) Droit de retirer le consentement à la protection des données</strong>
Chaque personne concernée a le droit, accordé par le législateur européen, de retirer à tout moment son consentement au traitement de ses données à caractère personnel.

Si la personne concernée souhaite exercer son droit de retirer son consentement, elle peut, à tout moment, contacter n’importe quel membre de l’équipe du forum « %1$s ».

<strong>j) Réclamation en cas d’atteinte à la protection des données</strong>
En cas de violation de la protection des données, la personne concernée a le droit de porter plainte auprès de l’autorité de contrôle compétente. L’autorité de contrôle en matière de protection des données est le délégué à la protection des données du pays dans lequel la personne concernée a sa résidence principale.

Vous trouverez ici une vue d’ensemble des autorités nationales de protection des données ainsi que des liens et des adresses : <a onclick="window.open(this.href); return false;" href="https://www.cnil.fr/">https://www.cnil.fr/ - Adresse pour la France</a> (en français) ou <a onclick="window.open(this.href); return false;" href="http://ec.europa.eu/justice/article-29/structure/data-protection-authorities/index_en.htm">https://ec.europa.eu - Adresses & liens des autorités de protection des données (APD) européennes</a> (en anglais).

<h3>Dispositions relatives à la protection des données concernant l’outil des photos de profil « Gravatar »</h3>
Le contrôleur a intégré le service Gravatar sur ce forum afin de pouvoir utiliser l’aide de Gravatar pour donner aux auteurs de messages la possibilité de personnaliser leurs messages avec une image de profil de pages croisées (également connu sous le nom d’avatar). L’opérateur du service Gravatar est Automattic Inc, 132 Hawthorne Street San Francisco, CA 94107, USA.

Gravatar est un service où la personne concernée peut se connecter et enregistrer des photos de profil avec une adresse e-mail. L’image utilisateur choisie peut ensuite être utilisée sur de nombreux sites Web différents. Si la personne concernée écrit des messages ou des commentaires sur d’autres sites en ligne avec l’adresse électronique correspondante, l’image de son profil peut être affichée à côté des messages ou commentaires. Pour cela, l’adresse e-mail fournie par la personne concernée est envoyée cryptée à Gravatar afin de vérifier si un profil avec une image est stocké à cet effet. C’est le seul but du transfert de l’adresse e-mail.

En affichant les images, Gravatar aura connaissance de l’adresse IP actuelle des personnes concernées, car cela est nécessaire pour la communication entre un navigateur et un service en ligne. En outre, Gravatar reçoit des informations sur les sites Web visités et où la photo du profil est utilisée. Ces connexions de données ne sont pas sous notre contrôle et nous ne sommes pas au courant des données utilisées ou envoyées. Pour plus d’informations sur la façon dont Gravatar collecte et utilise les données, voir la Politique de confidentialité automatique : <a onclick="window.open(this.href); return false;" href="https://automattic.com/privacy/">https://automattic.com/privacy/</a>.

Si la personne concernée ne souhaite pas qu’une image apparaisse dans les messages, qui est liée à son adresse électronique à Gravatar, elle doit être utilisée dans le compte utilisateur et, pour les messages, une adresse électronique qui n’est pas déposée à Gravatar. Les utilisateurs peuvent interdire complètement la transmission de données en ne connectant pas une image Gravatar avec leur compte utilisateur, mais en choisissant de préférence une image d’utilisateur local sur le forum.

Automattic est certifié en vertu du Privacy Shield Agreement, qui garantit le respect de la législation européenne en matière de protection de la vie privée. Pour d’avantage d’informations vous pouvez consulter les pages : <a onclick="window.open(this.href); return false;" href="https://www.privacyshield.gov/participant?id=a2zt0000000CbqcAAC&status=Active">https://www.privacyshield.gov</a> (en anglais) & <a onclick="window.open(this.href); return false;" href="https://www.cnil.fr/fr/le-privacy-shield">https://www.cnil.fr/</a> (en français).

<h3>Dispositions relatives à la protection des données concernant l’outil de salle de jeux « phpBB Arcade »</h3>
Sur ce forum, le contrôleur a intégré un composant de salle de jeu (également appelé arcade) avec des jeux utilisables depuis son navigateur web. En utilisant les modules d’arcade, des cookies sont mis en place, comme expliqué ci-dessus, qui stockent les données de session et l’affichage personnalisé des jeux et des pages d’arcade. Pour le bon fonctionnement de cet outil, il est nécessaire de transmettre des données sur le score atteint par jeu, le niveau de jeu, la date du score atteint, le nombre de départs de jeu, la durée du jeu, le classement par rapport aux autres utilisateurs et des statistiques similaires et de les stocker en association avec le compte utilisateur. Il peut contenir des éléments d’un service de traduction de texte, tel que Google Translate. Consultez les règles de confidentialité de Google Translate ci-dessous (voir la partie 15). Il est également possible que les jeux établissent des liens de données vers des sites étrangers qui donneront lieu à un classement ou à des statistiques spécifiques pour ce jeu. Il peut également y avoir des liens dans les jeux vers ce qu’on appelle les médias sociaux, qui suivent les activités de leurs membres à cet égard.

Si la personne concernée possède un compte utilisateur sur ces sites tiers ou médias sociaux et y est connectée, ces sites web peuvent recevoir des informations sur la visite de notre forum, le jeu respectif et les scores obtenus. En retour, il est possible que des publicités soient envoyées à la personne concernée à partir de ces pages. Ces connexions de données ne sont pas sous notre contrôle et nous ne sommes pas au courant des données utilisées ou envoyées. La personne concernée peut interdire tout transfert de données personnelles en se déconnectant du compte correspondant ou en n’utilisant pas les jeux. L’arcade peut être utilisé en partie sans enregistrement et stockage de cookies ou de données. Cependant, de nombreuses fonctionnalités ne seront pas disponibles et les scores obtenus ne pourront pas être sauvegardés. Pour les clients, aucune information personnelle n’est stockée en dehors du journal général d’accès au serveur. Enfin, pour les joueurs ayant le statut « invité » sur le forum ils seront également incapables d’enregistrer leur score du jeu joué et de nombreuses fonctionnalités ne seront pas disponibles.

<h3>Dispositions relatives à la protection des données concernant des outils de tchat « JV Footer chat » & « JV Shoutbox »</h3>
Sur ce forum, le contrôleur a intégré des modules de tchat (également appelés « JV Shoutbox » ou « JV Footer chat »). L’objectif de ces modules est de permettre aux utilisateurs de communiquer directement entre eux en temps réel. En utilisant un module de tchat, des cookies sont définis (comme expliqué en partie 3), pour stocker les paramètres de la fenêtre de tchat respective (par exemple, son activé/désactivé, affichage de la fenêtre repliée ou étendue, ou position de la fenêtre dans une page) et les données de session ou d’historique. Pour faire fonctionner correctement un module de tchat, il est nécessaire de stocker les messages de l’utilisateur avec l’heure de création et en association avec son compte utilisateur dans la base de données. Les messages des invités sont stockés en association avec l’adresse IP. Ceci est nécessaire pour afficher les soumissions des utilisateurs dans l’ordre chronologique correct, les assigner aux auteurs et pour poursuivre toute violation des Conditions d’utilisation ou de la loi applicable. Le contenu des conversations dans les modules de chat peut être visible publiquement sur Internet, en fonction de la configuration et peut être lu ou révisé par n’importe qui.

<h3>Dispositions relatives à la protection des données concernant l’outil « Google AdSense »</h3>
Sur ce forum, le contrôleur a intégré Google AdSense, lequel est un service en ligne qui permet de placer de la publicité sur les sites Web. Google AdSense est basé sur un algorithme qui sélectionne les publicités affichées sur les sites Web pour qu’elles correspondent au contenu du site Web respectif. Google AdSense permet un ciblage basé sur les intérêts de l’utilisateur Internet, qui est mis en œuvre au moyen de la génération de profils d’utilisateurs individuels.

La société d’exploitation du composant AdSense de Google est Alphabet Inc, 1600 Amphithéâtre Pkwy, Mountain View, CA 94043-1351, États-Unis.

L’objectif du composant AdSense de Google est l’intégration de publicités sur notre forum. Google AdSense place un cookie dans le système informatique de la personne concernée. La définition des cookies est expliquée ci-dessus. Avec la mise en place du cookie, Alphabet Inc. est activé pour analyser l’utilisation de notre forum. Lors de chaque appel à l’une des pages individuelles de ce forum, qui est exploité par le contrôleur et dans lequel un composant Google AdSense est intégré, le navigateur web sur le système informatique de la personne concernée soumettra automatiquement des données par l’intermédiaire du composant Google AdSense à des fins de publicité en ligne et de règlement des commissions à Alphabet Inc. Au cours de cette procédure technique, l’entreprise Alphabet Inc. acquiert la connaissance des données personnelles, telles que l’adresse IP de la personne concernée, qui sert notamment à Alphabet Inc. pour comprendre l’origine des visiteurs et des clics et créer par la suite des règlements de commissions.

La personne concernée peut, comme indiqué ci-dessus, inhiber à tout moment l’installation de cookies par l’intermédiaire de notre forum par un ajustement correspondant du navigateur web utilisé et ainsi refuser définitivement l’installation de cookies. Une telle configuration du navigateur web utilisé interdirait également Alphabet Inc. d’implanter un cookie dans le système informatique de la personne concernée. De plus, les cookies déjà utilisés par Alphabet Inc. peuvent être supprimés à tout moment via un navigateur web ou d’autres logiciels.

De plus, Google AdSense utilise également ce qu’on appelle des pixels de suivi. Un pixel de suivi est un graphique miniature qui est incorporé dans des pages Web pour permettre l’enregistrement d’un fichier journal et l’analyse d’un fichier journal à travers lequel une analyse statistique peut être effectuée. En se basant sur les pixels de suivi intégrés, Alphabet Inc. est en mesure de déterminer si et quand un site Web a été ouvert par une personne concernée et quels liens ont été ouverts par la personne concernée. Les pixels de suivi servent, entre autres, à analyser le flux de visiteurs sur un site Web.

Par l’intermédiaire de Google AdSense, les données et informations personnelles - qui comprennent également l’adresse IP et qui sont nécessaires à la collecte et à la comptabilisation des publicités affichées - sont transmises à Alphabet Inc. aux États-Unis d’Amérique. Ces données personnelles seront stockées et traitées aux États-Unis d’Amérique. Alphabet Inc. peut divulguer les données personnelles collectées par le biais de cette procédure technique à des tiers.

Google AdSense est expliqué plus en détail sous le lien suivant : <a onclick="window.open(this.href); return false;" href="https://www.google.fr/intl/fr/adsense/start/">https://www.google.fr/intl/fr/adsense/start/</a> (en français).

<h3>Dispositions relatives à la protection des données concernant l’outil « Google Analytics » (avec fonction d’anonymisation)</h3>
Sur ce forum, le contrôleur a intégré le composant Google Analytics (avec la fonction d’anonymisation). Google Analytics est un service d’analyse web. L’analyse web est la collecte et l’analyse de données sur le comportement des visiteurs de sites Web. Un service d’analyse web collecte, entre autres, des données sur le site Web d’où provient une personne (ce qu’on appelle le référent), les sous-pages visitées ou la fréquence et la durée de consultation d’une sous-page. L’analyse web est principalement utilisée pour l’optimisation d’un site Web et pour effectuer une analyse coûts-avantages de la publicité sur Internet.

L’opérateur du composant Google Analytics est Google Inc. 1600 Amphithéâtre Pkwy, Mountain View, CA 94043-1351, États-Unis.

Pour l’analyse web à travers Google Analytics, le contrôleur utilise l’application "_gat. "Anonymiser". Grâce à cette application, l’adresse IP de la connexion Internet de la personne concernée est abrégée par Google et rendue anonyme lors de l’accès à notre forum à partir d’un État membre de l’Union européenne ou d’un autre État contractant à l’Accord sur l’Espace économique européen.

Le but du composant Google Analytics est d’analyser le trafic sur notre forum. Google utilise les données et informations collectées, entre autres, pour évaluer l’utilisation de notre forum et pour fournir des rapports en ligne, qui montrent les activités sur notre forum et pour nous fournir d’autres services concernant l’utilisation de notre forum.

Google Analytics place un cookie sur le système informatique de la personne concernée. La définition des cookies est expliquée ci-dessus. Avec la mise en place du cookie, Google Analytics est activé pour analyser l’utilisation de notre forum. Pour chaque appel à l’une des pages individuelles de ce forum, qui est exploité par le responsable du traitement et dans lequel un composant Google Analytics a été intégré, le navigateur web du système d’information de la personne concernée transmet automatiquement des données par l’intermédiaire du composant Google Analytics à des fins de publicité en ligne et de règlement des commissions à Google. Au cours de cette procédure technique, l’entreprise Google acquiert la connaissance d’informations personnelles, telles que l’adresse IP de la personne concernée, qui sert à Google, entre autres, pour comprendre l’origine des visiteurs et des clics et ensuite créer des règlements de commissions.

Le cookie est utilisé pour stocker des informations personnelles, tels que le temps d’accès, l’endroit à partir duquel l’accès a été effectué et la fréquence des visites de notre forum par la personne concernée. Lors de chaque visite sur notre forum, ces données personnelles, y compris l’adresse IP de l’accès Internet utilisée par la personne concernée, seront transmises à Google aux États-Unis d’Amérique. Ces données personnelles sont stockées par Google aux Etats-Unis d’Amérique. Google peut être amené à transmettre ces données personnelles collectées par le biais de la procédure technique à des tiers.

La personne concernée peut, comme indiqué ci-dessus, inhiber à tout moment l’installation de cookies par l’intermédiaire de notre forum au moyen d’une configuration sur le navigateur web utilisé et ainsi refuser définitivement l’installation de cookies. Un tel ajustement du navigateur web utilisé interdirait également Google Analytics d’implanter un cookie dans le système informatique de la personne concernée. En outre, les cookies déjà utilisés par Google Analytics peuvent être supprimés à tout moment via un navigateur web ou d’autres logiciels.

En outre, la personne concernée a la possibilité de s’opposer à la collecte de données générées par Google Analytics, qui est liée à l’utilisation de ce forum, ainsi qu’au traitement de ces données par Google et à la possibilité de s’opposer à une telle collecte. Pour ce faire, la personne concernée doit télécharger un complément de navigateur depuis la page suivante : <a onclick="window.open(this.href) ; return false ;" href="https://tools.google.com/dlpage/gaoptout">https://tools.google.com/dlpage/gaoptout</a> et l’installer. Ce module complémentaire de navigateur indique à Google Analytics par le biais du langage JavaScript, que les données et informations concernant les visites de pages Internet ne peuvent pas être transmises à Google Analytics. L’installation des extensions de navigateur est considérée comme une objection par Google. Si le système informatique de la personne concernée est ultérieurement supprimé, formaté ou nouvellement installé, la personne concernée doit réinstaller les extensions du navigateur pour désactiver Google Analytics à nouveau. Si l’extension du navigateur a été désinstallée par la personne concernée ou toute autre personne qui est imputable à son domaine de compétence, ou est désactivée, il est possible d’exécuter la réinstallation ou la réactivation des extensions du navigateur web.

Plus d’informations sur les dispositions de Google en matière de protection des données sont disponibles depuis les pages suivantes : <a onclick="window.open(this.href); return false;" href="https://policies.google.com/privacy">https://policies.google.com/privacy</a> et <a onclick="window.open(this.href); return false;" href="https://www.google.fr/analytics/terms/fr.html">https://www.google.fr/analytics/terms/fr.html</a>. Google Analytics est expliqué plus en détail depuis le lien suivant : <a onclick="window.open(this.href); return false;" href="https://support.google.com/analytics?hl=fr">https://support.google.com/analytics?hl=fr</a>.

<h3>Dispositions relatives à la protection des données concernant l’outil « DoubleClick »</h3>
Sur ce forum, le contrôleur a intégré des composants de DoubleClick par Google. DoubleClick est une marque de Google, sous laquelle des solutions spéciales de marketing en ligne sont principalement commercialisées auprès des agences de publicité et des éditeurs.

La société d’exploitation de DoubleClick par Google est Google Inc, 1600 Amphithéâtre Pkwy, Mountain View, CA 94043-1351, ÉTATS-UNIS.

DoubleClick de Google transmet les données au serveur DoubleClick à chaque impression, clics ou autre activité. Chacun de ces transferts de données déclenche une demande de cookie dans le navigateur de la personne concernée. Si le navigateur accepte cette demande, DoubleClick utilise un cookie sur le système informatique de la personne concernée. La définition des cookies est expliquée ci-dessus. Le but du cookie est l’optimisation et l’affichage de la publicité. Le cookie est utilisé, entre autres, pour afficher et placer des publicités pertinentes pour l’utilisateur ainsi que pour créer ou améliorer les rapports sur les campagnes publicitaires. De plus, le cookie sert à éviter l’affichage multiple de la même publicité.

DoubleClick utilise un identifiant de cookie nécessaire à l’exécution du processus technique. Par exemple, le cookie ID est nécessaire pour afficher une publicité dans un navigateur. DoubleClick peut également utiliser le Cookie ID pour enregistrer les publicités qui ont déjà été affichées dans un navigateur afin d’éviter les doublons. Il est également possible pour DoubleClick de suivre les conversions par le biais de l’ID de cookie. Par exemple, les conversions sont capturées lorsqu’un utilisateur a déjà reçu une publicité DoubleClick et qu’il effectue ensuite un achat sur le site Web de l’annonceur en utilisant le même navigateur Internet.

Un cookie de DoubleClick ne contient aucune donnée personnelle. Cependant, un cookie DoubleClick peut contenir des ID de campagne supplémentaires. Un ID de campagne est utilisé pour identifier les campagnes avec lesquelles l’utilisateur a déjà été en contact.

Lors de chaque appel vers l’une des pages individuelles de ce forum, qui est exploité par le responsable du traitement et sur lequel un composant DoubleClick a été intégré, le navigateur web du système informatique de la personne concernée est automatiquement invité par le composant DoubleClick concerné à envoyer des données à Google à des fins de publicité en ligne et de facturation des commissions. Au cours de cette procédure technique, Google prend connaissance de toutes les données que Google peut utiliser pour calculer les commissions. Google peut, entre autres, comprendre que la personne concernée a cliqué sur certains liens sur notre forum.

La personne concernée peut, comme indiqué ci-dessus, inhiber à tout moment l’installation de cookies par l’intermédiaire de notre forum au moyen d’une configuration sur le navigateur web utilisé et ainsi refuser définitivement l’installation de cookies. Un tel ajustement du navigateur web utilisé interdirait également Google d’implanter un cookie dans le système informatique de la personne concernée. En outre, les cookies déjà utilisés par Google peuvent être supprimés à tout moment par le biais d’un navigateur web ou d’autres logiciels.

Plus d’informations sur les dispositions applicables en matière de protection des données de DoubleClick sont disponibles depuis la page suivante : <a onclick="window.open(this.href); return false;" href="https://policies.google.com/">https://policies.google.com/</a>.

<h3>Dispositions relatives à la protection des données concernant l’outil « Google Translate »</h3>
Le contrôleur a intégré des composants de traduction de Google Translate sur ce forum. L’objectif de cette composante est d’améliorer notre service en ligne en permettant à la personne concernée de traduire automatiquement les messages en langues étrangères sur le forum des contrôleurs. La société d’exploitation de Google Translate est Google LLC, 1600 Amphithéâtre Pkwy, Mountain View, CA 94043-1351, USA. Google Translate est un service de traduction en ligne fourni par Google LLC qui permet aux utilisateurs de traduire automatiquement des mots, des textes, une page web ou des parties de celle-ci dans différentes langues. Cependant, les traductions ne sont pas toujours correctes et peuvent parfois inclure des expressions trompeuses, fausses ou offensantes. Nous n’assumons aucune responsabilité quant à l’exactitude, la fiabilité ou l’actualité des traductions et ne sommes pas responsables des dommages subis.

Lors de chaque appel vers l’une des pages individuelles de ce forum exploité par le contrôleur et sur lequel un composant de traduction a été intégré, les données sont transmises à Google Translate. Google Translate place des cookies sur le système informatique de la personne concernée comme décrit ci-dessus. Lors de chaque visite sur le forum du responsable du traitement, les données personnelles, y compris l’adresse IP de l’accès Internet utilisé par la personne concernée, seront transmises à Google à des serveurs situés aux États-Unis d’Amérique et y seront stockées. Google peut transmettre ces données personnelles collectées par le biais de la procédure technique à d’autres services Google et à des tiers. Pendant toute la durée de la visite sur le forum, Google reçoit toujours des informations indiquant que le service a été appelé, quand il a été appelé, à partir de quel site, avec quelle adresse IP et quel navigateur et quels textes ont été saisis ou récupérés par la personne concernée pour la traduction. Ces données sont traitées sur des serveurs étrangers, généralement aux États-Unis et sont collectées, stockées, analysées et traitées par Google. Ces données sont échangées entre les différents services de Google et les activités de la personne concernée sont suivies à l’aide de cookies, d’un identifiant de navigateur et de l’adresse IP. Si la personne concernée est connectée à Google en même temps, les données seront associées à la connexion de l’utilisateur Google et utilisées par exemple à des fins promotionnelles, également sur d’autres sites Web.

En utilisant Google Translate sur nos pages, la personne concernée accepte la collecte, le traitement et l’utilisation des données collectées automatiquement et des données saisies par la personne concernée elle-même par Google, l’un de ses agents, ses services ou des tiers, conformément aux conditions d’utilisation et à la politique de confidentialité de Google. Si les données de la personne concernée ne doivent pas être transmises à Google, les services de Google ne doivent pas être utilisés.

Les Conditions d’utilisation de Google Translate sont disponibles à l’adresse suivante : <a onclick="window.open(this.href); return false;" href="https://policies.google.com/terms">https://policies.google.com/terms</a>. Les dispositions relatives à la protection des données de Google Translate sont disponibles à l’adresse suivante : <a onclick="window.open(this.href); return false;" href="https://policies.google.com/privacy">https://policies.google.com/privacy</a>, informations sur la collecte, le traitement et l’utilisation des données personnelles par Google.

Plus d’informations sur Google Translate sont disponibles depuis la page suivante : <a onclick="window.open(this.href); return false;" href="http://translate.google.com/manager/website/">http://translate.google.com/manager/website/</a>.

<h3>Dispositions relatives à la protection des données concernant l’outil « Google Fonts »</h3>
Sur ce forum, le contrôleur a intégré des polices externes de Google Fonts. La société d’exploitation de Google Fonts est Google inc. 1600 Amphithéâtre Pkwy, Mountain View, CA 94043-1351, USA. Google Fonts est un service pour servir des polices en ligne pour l’utilisation sur plusieurs sites Web. Les fichiers de police doivent être téléchargés dans le système informatique de la personne concernée avant de pouvoir être affichés. Les polices servies par l’API Google Fonts sont automatiquement compressées pour un téléchargement plus rapide et une fois téléchargées, elles sont mises en cache dans le navigateur et réutilisées par toute autre page Web qui utilise l’API Google Fonts.

L’objectif de ces composants est d’améliorer la conception du forum des contrôleurs et la présentation cohérente des polices de caractères sur le système informatique des utilisateurs. L’intégration de ces polices se fait par un appel de serveur, généralement un serveur Google aux Etats-Unis. Le système informatique de la personne concernée télécharge les polices de caractères.

Lors de chaque visite sur le forum du contrôleur sur lequel Google Fonts a été intégré, les données personnelles, y compris l’adresse IP de l’accès Internet utilisé par la personne concernée, seront transmises à Google à des serveurs situés aux États-Unis d’Amérique et y seront stockées. Chaque fois qu’une seule page du site Web des contrôleurs est appelée sur laquelle Google Fonts a été intégré, une requête aux serveurs de Google Fonts sera faite pour les polices actuellement utilisées. Les demandes sont sauvegardées pendant durant 24 heures, les polices téléchargées sont stockées pendant un an maximum sur le système informatique de l’utilisateur. Pour ce faire, des cookies sont stockés sur l’appareil de l’utilisateur par Google, comme décrit ci-dessus, qui contiennent l’adresse IP, le temps d’accès et les données du navigateur de la personne concernée. Google peut transmettre ces données personnelles collectées par le biais de la procédure technique à d’autres services Google et à des tiers.

Pendant toute la durée de la visite sur le forum, Google reçoit toujours des informations indiquant que le service a été appelé, quand il a été appelé, à partir de quel site, avec quelle adresse IP et quel navigateur. Ces données sont traitées sur des serveurs étrangers, généralement aux États-Unis et sont collectées, stockées, analysées et traitées par Google. Ces données sont échangées entre les différents services de Google et les activités de la personne concernée sont suivies à l’aide de cookies, d’un identifiant de navigateur et de l’adresse IP. Si la personne concernée est connectée à Google en même temps, les données seront associées à la connexion de l’utilisateur Google et utilisées par exemple à des fins promotionnelles, également sur d’autres sites Web.

Si le navigateur ou les paramètres de l’utilisateur ne prennent pas en charge les polices Web, une police installée sur le système informatique de la personne concernée est utilisée. Les polices Web peuvent être désactivées par des scripts bloquant les addons dans le navigateur.

Plus d’informations sur les polices Google sont disponibles depuis les pages suivantes : <a onclick="window.open(this.href); return false;" href="https://fonts.google.com/about#">https://fonts.google.com/about#</a> (en anglais) et <a onclick="window.open(this.href); return false;"https://developers.google.com/fonts/faq"> https://developers.google.com/fonts/faq</a> (en anglais).

Les conditions d’utilisation de Google Fonts sont disponibles à l’adresse suivante : <a onclick="window.open(this.href); return false;" href="https://policies.google.com/terms">https://policies.google.com/terms</a>. Les dispositions relatives à la protection des données de Google Translate sont disponibles depuis la page suivante : <a onclick="window.open(this.href); return false;" href="https://policies.google.com/privacy">https://policies.google.com/privacy</a>, informations sur la collecte, le traitement et l’utilisation des données personnelles par Google.

<h3>Dispositions relatives à la protection des données concernant l’outil « Facebook »</h3>
Sur ce forum, le contrôleur a intégré des composants de l’entreprise Facebook. Facebook est un réseau social.

Un réseau social est un lieu de rencontres sociales sur Internet, une communauté en ligne, qui permet généralement aux utilisateurs de communiquer entre eux et d’interagir dans un espace virtuel. Un réseau social peut servir de plate-forme d’échange d’opinions et d’expériences, ou permettre à la communauté Internet de fournir des informations personnelles ou professionnelles. Facebook permet aux utilisateurs de réseaux sociaux d’inclure la création de profils privés, le téléchargement de photos et la mise en réseau par le biais de demandes d’amis.

La société d’exploitation de Facebook est Facebook, Inc, 1 Hacker Way, Menlo Park, CA 94025, États-Unis. Si une personne vit à l’extérieur des États-Unis ou du Canada, le contrôleur est Facebook Ireland Ltd, 4 Grand Canal Square, Grand Canal Harbour, Dublin 2, Irlande.

Pour chaque appel à l’une des pages individuelles de ce forum, qui est exploité par le contrôleur et dans lequel un composant Facebook (plug-ins Facebook) a été intégré, le navigateur web du système d’information de la personne concernée est automatiquement invité à télécharger l’affichage du composant Facebook correspondant à partir de Facebook via le composant Facebook. Un aperçu de tous les plug-ins Facebook est accessible depuis la page : <a onclick="window.open(this.href); return false;" href="https://developers.facebook.com/docs/plugins/">https://developers.facebook.com/docs/plugins/</a>. Au cours de cette procédure technique, Facebook est informé du sous-site spécifique de notre forum visité par la personne concernée.

Si la personne concernée est connectée en même temps sur Facebook, Facebook détecte chaque appel sur notre forum par la personne concernée - et pour toute la durée de sa visite sur notre forum - quel sous-site spécifique de notre page Internet a été visité par la personne concernée. Ces informations sont collectées par le biais de la composante Facebook et sont associées au compte Facebook respectif de la personne concernée. Si la personne concernée clique sur l’un des boutons Facebook intégrés à notre forum, par exemple le bouton « J’aime », ou si la personne concernée soumet un message, Facebook fait correspondre ces informations avec le compte d’utilisateur Facebook personnel de la personne concernée et stocke les données personnelles.

Facebook reçoit toujours, par l’intermédiaire de la composante Facebook, des informations concernant une visite sur notre forum par la personne concernée, chaque fois que la personne concernée est connectée en même temps sur Facebook au moment de l’appel sur notre forum. Cela se produit indépendamment du fait que la personne concernée clique ou non sur le composant Facebook. Si une telle transmission d’informations à Facebook n’est pas souhaitable pour la personne concernée, elle peut l’interdire en se déconnectant de son compte Facebook avant de consulter notre forum.

La directive sur la protection des données publiée par Facebook est disponible depuis la page suivante : <a onclick="window.open(this.href); return false;" href="https://facebook.com/about/privacy/">https://facebook.com/about/privacy/</a>, fournit des informations sur la collecte, le traitement et l’utilisation des données personnelles par Facebook. En outre, il y est expliqué quelles options de paramétrage Facebook offre pour protéger la vie privée de la personne concernée. De plus, différentes options de configuration sont disponibles pour permettre la désactivation de la transmission de données à Facebook. Ces applications peuvent être utilisées par la personne concernée pour éliminer une transmission de données à Facebook.

<h3>Dispositions relatives à la protection des données concernant l’outil « YouTube »</h3>
Sur ce forum, le contrôleur a intégré des composants de YouTube. YouTube est un portail vidéo sur Internet qui permet aux éditeurs de vidéos de publier des clips vidéo aux autres utilisateurs gratuitement, ce qui permet également de les visionner, de les examiner et de les commenter gratuitement. YouTube vous permet de publier toutes sortes de vidéos, de sorte que vous pouvez accéder à la fois aux films complets et aux émissions de télévision, ainsi qu’aux vidéos musicales, aux bandes-annonces et aux vidéos réalisées par les utilisateurs via le portail Internet.

La société d’exploitation de YouTube est YouTube, LLC, 901 Cherry Ave, San Bruno, CA 94066, ÉTATS-UNIS. Le YouTube, LLC est une filiale de Google Inc, 1600 Amphithéâtre Pkwy, Mountain View, CA 94043-1351, ÉTATS-UNIS.

Lors de chaque appel vers l’une des pages individuelles de ce forum, qui est exploité par le responsable du traitement et sur lequel un composant YouTube (vidéo YouTube) a été intégré, le navigateur Internet du système informatique de la personne concernée est automatiquement invité à télécharger un affichage du composant YouTube correspondant. De plus amples informations sur YouTube peuvent être obtenues depuis la page suivante : <a onclick="window.open(this.href); return false;" href="https://www.youtube.com/yt/about/">https://www.youtube.com/yt/about/</a>. Au cours de cette procédure technique, YouTube et Google prennent connaissance de la sous-page spécifique de notre forum qui a été visitée par la personne concernée.

Si la personne concernée est connectée sur YouTube, YouTube reconnait lors de chaque appel à une sous-page contenant une vidéo YouTube, quelle sous-page spécifique de notre forum a été visitée par la personne concernée. Ces informations sont collectées par YouTube et Google et affectées au compte YouTube respectif de la personne concernée.

YouTube et Google recevront par l’intermédiaire du composant YouTube des informations indiquant que la personne concernée a visité notre forum, si la personne concernée au moment de l’appel sur notre forum est connectée sur YouTube ; cela se produit indépendamment du fait que la personne clique sur une vidéo YouTube ou non. Si une telle transmission de ces informations à YouTube et à Google n’est pas souhaitable pour la personne concernée, la livraison peut être désactivée si la personne concernée se déconnecte de son propre compte YouTube avant de consulter notre forum.

Les dispositions relatives à la protection des données de YouTubes sont disponibles depuis la page suivante : <a onclick="window.open(this.href); return false;" href="https://policies.google.com/privacy">https://policies.google.com/privacy</a>, informations sur la collecte, le traitement et l’utilisation des données personnelles par YouTube et Google.

<h3>Mode de paiement : Dispositions relatives à la protection des données concernant l’outil « PayPal » en tant que prestataire de services de paiement</h3>
Sur ce forum, le contrôleur a intégré des composants de PayPal. PayPal est un fournisseur de services de paiement en ligne. Les paiements sont traités via des comptes PayPal, qui représentent des comptes privés ou professionnels virtuels. PayPal est également capable de traiter les paiements virtuels par cartes de crédit lorsqu’un utilisateur n’a pas de compte PayPal. Un compte PayPal est géré via une adresse e-mail, c’est pourquoi il n’y a pas de numéros de compte classique. PayPal permet de déclencher des paiements en ligne à des tiers ou de recevoir des paiements. PayPal accepte également les fonctions de fiduciaire et offre des services de protection des acheteurs.

La société opérationnelle européenne de PayPal est PayPal (Europe) S.à.r.l. & Cie. S.C.A., 22-24 Boulevard Royal, 2449 Luxembourg, Luxembourg.

Si la personne concernée choisit « PayPal » comme option de don lors du processus de commande, nous transmettons automatiquement les données de la personne concernée à PayPal. En sélectionnant cette option de paiement, la personne concernée accepte le transfert des données personnelles nécessaires au traitement du paiement.

Les données personnelles transmises à PayPal sont généralement le prénom, le nom, l’adresse, l’adresse e-mail, l’adresse IP, le numéro de téléphone, le numéro de téléphone portable ou d’autres données nécessaires au traitement du paiement.

La transmission des données est destinée au traitement des paiements et à la prévention de la fraude. Le responsable du traitement transmettra des données personnelles à PayPal, en particulier si un intérêt légitime à la transmission est donné. Les données personnelles échangées entre PayPal et le responsable du traitement des données seront transmises par PayPal aux agences de crédit économique. Cette transmission est destinée aux contrôles d’identité et de solvabilité.

PayPal transmettra, si nécessaire, les données personnelles à ses affiliés et fournisseurs de services ou sous-traitants dans la mesure où cela est nécessaire pour remplir les obligations contractuelles ou pour que les données soient traitées dans la commande.

La personne concernée a la possibilité de révoquer à tout moment le consentement de PayPal pour le traitement des données personnelles. Une révocation n’a aucun effet sur les données personnelles qui doivent être traitées, utilisées ou transmises conformément au traitement des paiements (contractuels).

Les dispositions applicables en matière de protection des données de PayPal peuvent être consultées depuis la page suivante : <a onclick="window.open(this.href); return false;" href="https://www.paypal.com/fr/webapps/mpp/ua/privacy-full">https://www.paypal.com/fr/webapps/mpp/ua/privacy-full</a>.

<h3>Base juridique du traitement</h3>
Art. 6, paragraphe 1, point a. Le RGPD sert de base légale pour les opérations de traitement pour lesquelles nous obtenons le consentement pour une finalité de traitement spécifique. Si le traitement de données à caractère personnel est nécessaire à l’exécution d’un contrat auquel la personne concernée fait partie, comme c’est le cas, par exemple, lorsque les traitements sont nécessaires à la livraison de biens ou à la prestation de tout autre service, le traitement est fondé sur l’article 6, paragraphe 1, point b. du RGPD. Il en va de même pour les traitements nécessaires à l’exécution de mesures précontractuelles, par exemple dans le cas de demandes concernant nos produits ou services. Notre structure est soumise à une obligation légale par laquelle le traitement des données personnelles est nécessaire, comme pour l’accomplissement des obligations fiscales, le traitement est basé sur l’article 6, paragraphe 1, point c du RGPD. Dans de rares cas, le traitement des données à caractère personnel peut être nécessaire pour protéger les intérêts vitaux de la personne concernée ou d’une autre personne physique. Ce serait le cas, par exemple, si un visiteur était blessé dans notre structure et que son nom, son âge, ses données d’assurance maladie ou d’autres informations vitales devraient être transmises à un médecin, un hôpital ou un autre tiers. Le traitement serait alors basé sur l’article 6, paragraphe 1, point d du RGPD. Enfin, les opérations de traitement pourraient être fondées sur l’article 6, paragraphe 1, point f du RGPD. Cette base légale est utilisée pour des opérations de traitement qui ne sont couvertes par aucune des bases légales susmentionnées, si le traitement est nécessaire aux fins des intérêts légitimes poursuivis par notre structure ou par un tiers, sauf lorsque ces intérêts sont lésés par les intérêts ou les droits et libertés fondamentaux de la personne concernée qui exigent la protection des données à caractère personnel. Ces traitements sont particulièrement autorisés parce qu’ils ont été expressément mentionnés par le législateur européen. Il a estimé qu’un intérêt légitime pouvait être présumé si la personne concernée est un client du responsable du traitement (raison 47, deuxième phrase du RGPD).

<h3>Période de conservation des données personnelles</h3>
Le critère utilisé pour déterminer la durée de conservation des données personnelles est la durée de conservation légale correspondante. Après l’expiration de cette période, les données correspondantes sont systématiquement supprimées, tant qu’elles ne sont plus nécessaires à l’exécution du contrat ou à l’initiation d’un contrat.

<h3>Mise à disposition de données personnelles en tant qu’exigence légale ou contractuelle ; Obligation de conclure un contrat ; Obligation de la personne concernée à fournir les données à caractère personnel ; conséquences éventuelles d’un défaut de fourniture de ces données</h3>
Nous précisons que la mise à disposition de données personnelles est en partie exigée par la loi (par exemple les règlementations fiscales) ou peut également résulter de dispositions contractuelles (par exemple des informations sur le partenaire contractuel). Il peut parfois s’avérer nécessaire de conclure un contrat en vertu duquel la personne concernée nous fournit des données personnelles qui doivent être traitées ultérieurement par nos soins. La personne concernée est, par exemple, obligée de nous fournir des données personnelles lorsque notre structure signe un contrat avec elle. La non communication des données à caractère personnel aurait pour conséquence que le contrat avec la personne concernée ne pourrait pas être conclu. Avant que les données à caractère personnel ne soient fournies par la personne concernée, la personne concernée doit prendre contact avec tout collaborateur. Un de nos collaborateurs précise à la personne concernée si la fourniture des données personnelles est exigée par la loi ou le contrat ou si elle est nécessaire à la conclusion du contrat, s’il existe une obligation de fournir les données personnelles et les conséquences de la non-communication des données personnelles.

<h3>Résiliation de votre contrat</h3>
À tout moment, n’importe qui ayant un compte sur notre forum et à sa discrétion peut supprimer son compte. Toutes les données personnelles seront effacées lors de la suppression du dit compte utilisateur. Une fois la suppression effectuée, nous ne pouvons plus récupérer les données.

<hr>
Adaptation & traduction française réalisée par la <a href="http://www.ezcom-fr.com" title="Communauté EzCom"><strong>Communauté EzCom</strong></a> à l’aide des recommandations publiées sur les sites de la « Commission Nationale de L’informatique et des Libertés » (CNIL) et de la société ACTECIL.',
	'JVPPDMT_USED_COOKIE' => array(
		'<strong>Cookies utilisés par le forum phpBB :</strong>',
		'%1$s_cookie_status : Utilisé lorsque vous visitez notre forum, ce dernier enregistre une confirmation d’acceptation d’utiliser des cookies.',
		'%1$s_k : Utilisé pour le fonctionnement de la connexion automatique (case à cocher nommée : « Se souvenir de moi »).',
		'%1$s_sid : Contient l’ID de session utilisateur. Ce cookie est utilisé pour identifier l’utilisateur ainsi que les informations suivantes : %1$s_u.',
		'%1$s_u : Correspond à l’ID utilisateur.',
		'%1$s_track : Utilisé pour le suivi des messages lus par les invités.',

		/* If you are not using the extension (phpBB Arcade) then add the comment // at the beginning of the line. */
		'<br><strong>Cookies utilisés par l’extension « phpBB Arcade » :</strong>',
		'%1$s_arcade_sid: Contient l’ID de session du jeu utilisé.',
		'%1$s_arcade_pd: Contient l’ID du jeu nécessaire à son utilisation.',
		'%1$s_arcade_popup: Contient les paramètres lorsque vous jouez à un jeu dans la fenêtre pop-up.',
		'%1$s_arcade_lighting: Contient la préférence utilisateur du rétroéclairage des jeux.',
		'%1$s_arcade_info_block: Contient la préférence utilisateur pour la visibilité du bloc d’informations affichés lors de l’utilisation des jeux.',

		/* If you are not using the extension (JV Footer chat) then add the comment // at the beginning of the line. */
		'<br><strong>Cookie utilisé par l’extension « JV Footer chat » :</strong>',
		'%1$s_jv_chat_data: Contient les paramètres du tchat et l’ID utilisateur de vos interlocuteurs.',

		/* If you are not using the extension (JV Shoutbox) then add the comment // at the beginning of the line. */
		'<br><strong>Cookie utilisé par l’extension « JV Shoutbox » :</strong>',
		'%1$s_jv_shout_close_: Utilisé sur toutes les pages où vous avez fermé le bloc « Shoutbox ». Chaque page crée un cookie avec son propre nom. Par exemple, la page de l’index du forum est nommée : %1$s_jv_shout_close_index.',

		/* If you are not using the extension (Collapsible Forum Categories) then add the comment // at the beginning of the line. */
		'<br><strong>Cookie utilisé par l’extension « Collapsible Forum Categories » :</strong>',
		'%1$s_ccat: Enregistre les préférences personnelles de l’utilisateur concernant les boites de catégories réduites ou étendues.',
	),
	'JVPPDMT_DISABLED_COOKIE_GUEST_USER'	=> 'Nous n’enregistrons pas de cookies sur les appareils des invités !',
	'JVPPDMT_COOKIE_DESC'					=> 'Votre attention ! Ce forum utilise des cookies pour vous assurer d’avoir la meilleure expérience utilisateur en ces lieux. <a onclick="window.open(this.href); return false;" href="https://cookiesandyou.com/">En savoir plus</a>.<br>Depuis les options ci-dessous, vous pouvez accepter ou refuser les cookies, aussi vous pouvez désactiver à tout moment l’utilisation des cookies depuis les paramètres de votre navigateur web.',
	'JVPPDMT_COOKIE_CONFIRM'				=> 'Veuillez sélectionner votre préférence concernant l’enregistrement des cookies du forum « %s » sur votre machine :',
	'JVPPDMT_PERSONAL_DATA_REG'				=> 'Votre attention ! Lors de l’enregistrement, les données personnelles doivent être fournies.',
	'JVPPDMT_PERSONAL_DATA_CONFIRM'			=> 'Veuillez sélectionner votre préférence concernant l’utilisation & l’enregistrement de vos données personnelles sur le forum « %s ». Ces dernières ne seront pas transmises à des tiers.',
	'JVPPDMT_NOT_CONFIRM'					=> 'Votre attention ! Vous n’avez pas sélectionner de préférence ci-dessous.',
	'JVPPDMT_APPROVAL'						=> 'J’approuve',
	'JVPPDMT_REJECTION'						=> 'Je refuse',
	'JVPPDMT_ONLY_REGISTER_DATA'			=> 'Pour les données personnelles requises lors de l’enregistrement, j’approuve, mais rien d’autre.<br><em>Information : si vous choisissez cette option, vous ferez partie d’un groupe dont les possibilités sont réduites à la seule lecture du contenu sans pouvoir participer, tel que par exemple pour publier de nouveaux messages. Cependant, il est possible de revenir sur votre décision à n’importe quel moment ultérieur depuis le « Panneau de l’utilisateur », rubrique « Données personnelles », page « Paramètres ».</em>',
	'JVPPDMT_ONLY_ALREADY_EXISTING_DATA'	=> 'Pour les données déjà stockées, j’approuve, mais rien d’autre.<br><em>Information : si vous choisissez cette option, vous ferez partie d’un groupe dont les possibilités sont réduites à la seule lecture du contenu sans pouvoir participer, tel que par exemple pour publier de nouveaux messages. Cependant, il est possible de revenir sur votre décision à n’importe quel moment ultérieur depuis le « Panneau de l’utilisateur », rubrique « Données personnelles », page « Paramètres ».</em>',
	'JVPPDMT_CONFIRM'						=> 'J’ai lu et compris la politique de confidentialité.',
));
