<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'G_JVPPDMT_REGISTERED_VIEWER'		=> 'Regisztrált nézők',
	'JVPPDMT_INFO_NO_USE_COOKIE_GUEST'	=> 'Kedves vendégünk, szeretnénk tájékoztatni arról, hogy a cookie-kat nem tároljuk a vendégek számára. Ha több információt szeretnél, akkor olvasd el az %sAdatvédelmi irányelvet%s.',
	'JVPPDMT_VIEWER_GROUP_INFO'			=> 'Kedves felhasználó, mivel elutasítottad a további személyes adatok mentését, így bekerültél a néző csoportba. A néző csoport csak az oldalak megtekintését teszi lehetővé és nem küldhet be semmilyen űrlapot, mivel az nem lehetséges az adatok mentése nélkül.<br>Ha bármikor módosítani szeretnéd az adatvédelmi adatok tárolására vonatkozó beállításaidat, akkor kattints %sIDE%s.',
	'JVPPDMT_COOKIE_INFO'				=> 'Kedves felhasználó, mivel elutasítottad a cookie-k mentését az eszközödre, így számodra számos funkció nem elérhető.<br>Ha bármikor módosítani szeretnéd az adatvédelmi adatok tárolására vonatkozó beállításaidat, akkor kattints %sIDE%s.',
	'UCP_PROFILE_JVPPDMT_MY_ACC_DELETE'	=> 'Regisztráció törlése',
	'UCP_JVPPDMT_PRIVACY_DATA'			=> 'Adatvédelmi adatok',
	'UCP_JVPPDMT_SETTINGS'				=> 'Beállítások',

	'LOG_JVPPDMT_MY_ACC_DELETE'			=> '<strong>Saját regisztráció törlése</strong><br>» %s',
	'LOG_JVPPDMT_MY_ACC_POST_DELETE'	=> '<strong>Saját regisztráció törlése, hozzászólásokkal együtt.</strong><br>» %s',
));