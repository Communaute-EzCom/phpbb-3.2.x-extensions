<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JVPPDMT_MY_ACC_DELETE_CONFIRM'			=> 'Regisztráció törlésének megerősítése',
	'JVPPDMT_MY_ACC_DELETE_CONFIRM_ERROR'	=> 'A regisztráció törlése nem lett megerősítve!',
	'JVPPDMT_MY_ACC_DELETE_EXPLAIN'			=> 'Saját regisztráció törlése.<br><em>Vedd figyelembe, ha megteszed akkor nincs mód az adataid visszaállítására a későbbiekben!</em>',
	'JVPPDMT_MY_ACC_DELETE_FOUNDER_ERROR'	=> 'Alapító felhasználó nem törölheti a saját regisztrációját! Ezt a műveletet csak egy másik alapító felhasználó végezheti el.',
	'JVPPDMT_MY_ACC_DELETE_SUCCESS'			=> 'A regisztráció törlése sikeres.',
	'JVPPDMT_MY_ACC_POST_DELETE'			=> 'Hozzászólásaim törlése',
	'JVPPDMT_MY_ACC_POST_DELETE_EXPLAIN'	=> 'A fórumból törlésre kerülnek a hozzászólásaid.',
	'JVPPDMT_REGISTRATION_IP'				=> 'Regisztrációs IP cím',
	'JVPPDMT_REGISTRATION_DATE'				=> 'Regisztráció ideje',
	'JVPPDMT_PRIVACY_POLICY_ACCEPT_DATE'	=> 'Utolsó adatvédelmi irányelv elfogadásának időpontja',
	'JVPPDMT_TERM_OF_USE_ACCEPT_DATE'		=> 'Utolsó használati feltételek elfogadásának időpontja',
	'JVPPDMT_COOKIE_SETTING'				=> 'Cookie-k fogadása',
	'JVPPDMT_COOKIE_SETTING_EXPLAIN'		=> 'Itt beállíthatod, hogy a weboldal menthet-e cookie-kat az eszközödre vagy nem. Bővebb információért olvasd el az %sAdatvédelmi Irányelvet%s.<br><em>Vedd figyelembe, hogy ha nem engedélyezed a cookie-kat , akkor számos funkció nem fog működni.</em>',
	'JVPPDMT_PD_SETTING'					=> 'Személyes adatok tárolása',
	'JVPPDMT_PD_SETTING_EXPLAIN'			=> 'Itt beállíthatod, hogy weboldalunk miként járjon el a személyes adataiddal. Természetesen a döntésedet a későbbiekben is bármikor megváltoztathatod.',
	'JVPPDMT_PD_ACCEPT'						=> 'Jóváhagyom a személyes adataim tárolását és használatát',
	'JVPPDMT_PD_PARTIAL_ACCEPT'				=> 'Csak a már tárolt személyes adatok tárolását és használatát hagyom jóvá',
	'JVPPDMT_PD_REJECT'						=> 'Elutasítom a személyes adataim tárolását és használatát',
	'JVPPDMT_YOUR_POST_NUMBER'				=> 'Hozzászólásaim száma',
	'JVPPDMT_SELECT_DOWNLOAD_FORMAT'		=> 'Válassz letöltési formátumot',
	'JVPPDMT_YOUR_PM_NUMBER'				=> 'Privát üzeneteim száma',
	'JVPPDMT_ID'							=> 'Azonosítószám',
	'JVPPDMT_REL_IP'						=> 'Hozzátartozó IP cím',
	'JVPPDMT_CREATE_TIME'					=> 'Létrehozás ideje',
	'JVPPDMT_FORUM_POSTS'					=> 'Fórum hozzászólások',
	'JVPPDMT_DOWNLOAD'						=> 'Letöltés',
	'JVPPDMT_NOT_FOUND_POST'				=> 'Nincs hozzászólásod.',
	'JVPPDMT_NOT_FOUND_PM'					=> 'Nincs privát üzeneted.',
	'JVPPDMT_SENT_PRIVATE_MESSAGES'			=> 'Elküldött privát üzenetek',
));