<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $config, $user, $db, $request, $template, $root_path, $php_ext;

	public function __construct($config, $user, $db, $request, $template, $ppdmt, $root_path, $php_ext)
	{
		$this->config		= $config;
		$this->user			= $user;
		$this->db			= $db;
		$this->request		= $request;
		$this->template		= $template;
		$this->ppdmt		= $ppdmt;
		$this->root_path	= $root_path;
		$this->php_ext		= $php_ext;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'									=> 'user_setup',
			'core.user_setup_after'								=> 'user_setup_after',
			'core.ucp_register_agreement_modify_template_data'	=> 'ucp_register_agreement',
			'core.ucp_register_modify_template_data'			=> 'ucp_register_modify_template_data',
			'core.page_header_after'							=> 'page_header_after',
			'core.user_add_modify_data'							=> 'user_add_data',
			'core.user_add_after'								=> 'user_add_after',
			'core.login_box_redirect'							=> 'login_box_redirect',
			'core.functions.redirect'							=> 'functions_redirect',

			'core.acp_users_display_overview'					=> 'acp_users_display_overview',

			'jv.ppdmt.user_delete'								=> 'user_delete',

			'core.set_cookie'									=> 'phpbb_set_cookie'
		);
	}

	public function user_setup($event)
	{
		$event['lang_set_ext'] = array_merge($event['lang_set_ext'], array(
			array(
				'ext_name' => 'jv/ppdmt',
				'lang_set' => 'common'
			)
		));
	}

	public function user_setup_after()
	{
		if ($this->privacy_policy_enable())
		{
			if ($this->is_registered())
			{
				// user logout if no use cookie add url + param cookie_status=0
				if (defined('IN_LOGIN') && $this->request->variable('mode', 'logout') && $this->request->is_set('sid') && $this->request->variable('sid', '') === $this->user->session_id)
				{
					if (!$this->user->data['user_cookie_status'])
					{
						$this->set_extra_url(0);
					}
				}

				// verify user last accept privacy_policy.
				if ($this->config['jvppdmt_last_privacy_policy'] > $this->user->data['user_accept_pp_date'])
				{
					if ($this->request->is_set_post('jvppdmt_submit') && $this->request->is_set_post('jvppdmt_confirm') && !$this->request->is_set_post('cancel'))
					{
						if (($this->request->is_set_post('personal_data') && !$this->request->variable('personal_data', 0)) || $this->request->is_set_post('user_password'))
						{
							$this->registration_delete();
						}
						else if ($this->request->is_set_post('personal_data') && $this->request->is_set_post('cookie_status'))
						{
							$cookie_status = $this->request->variable('cookie_status', false);
							if (!$cookie_status)
							{
								$this->ppdmt->delete_cookies();
							}

							$sql = 'UPDATE ' . USERS_TABLE . '
								SET user_cookie_status = ' . (($cookie_status) ? 1 : 0) . ', user_accept_pp_date = ' . time() . '
								WHERE user_id = ' . (int) $this->user->data['user_id'];
							$this->db->sql_query($sql);

							if ($this->config['jvppdmt_viewer_group_enable'])
							{
								$this->ppdmt->set_user_viewer_group();
							}

							redirect(append_sid($this->root_path . 'index.' . $this->php_ext));
						}
					}

					$this->display_privacy_policy();
				}
				// verify user last accept term of use.
				if ($this->config['jvppdmt_last_term_of_use'] > $this->user->data['user_accept_tou_date'])
				{
					if (!$this->request->is_set_post('cancel') && ($this->request->is_set_post('agreed') || $this->request->is_set_post('not_agreed')))
					{
						if ($this->request->is_set_post('agreed'))
						{
							$sql = 'UPDATE ' . USERS_TABLE . '
								SET user_accept_tou_date = ' . time() . '
								WHERE user_id = ' . (int) $this->user->data['user_id'];
							$this->db->sql_query($sql);

							redirect(append_sid($this->root_path . 'index.' . $this->php_ext));
						}
						else
						{
							$this->registration_delete('term_of_use');
						}
					}

					$touc = '';
					// verify use JV Custom Language and contain this lang key.
					if (!empty($this->user->lang['TERMS_OF_USE_CONTENT']))
					{
						$touc = $this->user->lang['TERMS_OF_USE_CONTENT'];
					}

					$this->user->add_lang('ucp');

					if ($touc === '')
					{
						$touc = $this->user->lang['TERMS_OF_USE_CONTENT'];
					}

					$this->template->assign_vars(array(
						'U_ACTION'			=> append_sid($this->root_path . 'index.' . $this->php_ext),

						'L_TERMS_OF_USE'	=> sprintf($touc, $this->config['sitename'], generate_board_url()),
					));

					page_header($this->user->lang['TERMS_USE']);

					$this->template->set_filenames(array(
						'body' => '@jv_ppdmt/term_of_use.html')
					);

					page_footer();
				}

				if ($this->config['jvppdmt_viewer_group_info'] && $this->ppdmt->user_viewer_group())
				{
					$this->template->assign_vars(array(
						'S_JVPPDMT_VIEWER_GROUP_INFO'	=> true,

						'JVPPDMT_VIEWER_GROUP_INFO'		=> $this->user->lang('JVPPDMT_VIEWER_GROUP_INFO', '<a href="' . append_sid($this->root_path . 'ucp.' . $this->php_ext, 'i=-jv-ppdmt-ucp-privacy_data_module&amp;mode=settings') . '">', '</a>')
					));
				}

				if ($this->config['jvppdmt_cookie_info'] && !$this->user->data['user_cookie_status'])
				{
					$this->template->assign_vars(array(
						'S_JVPPDMT_COOKIE_INFO'	=> true,

						'JVPPDMT_COOKIE_INFO'	=> $this->user->lang('JVPPDMT_COOKIE_INFO', '<a href="' . append_sid($this->root_path . 'ucp.' . $this->php_ext, 'i=-jv-ppdmt-ucp-privacy_data_module&amp;mode=settings') . '">', '</a>')
					));
				}
			}
			else
			{
				if ($this->use_cookie_guest())
				{
					// verify guest user use cookie
					$cookie_status = $this->cookie_status();

					if ($this->request->is_set_post('jvppdmt_cookie') && !$this->request->is_set_post('jvppdmt_confirm'))
					{
						$cookie_status = null;
					}

					if ($cookie_status === null)
					{
						$this->display_privacy_policy(true, false);
					}
					else if ($this->request->is_set_post('jvppdmt_cookie'))
					{
						$this->redirect_cookie_action($cookie_status);
					}

					if (!$this->is_set_cookie('cookie_status'))
					{
						$this->set_extra_url($cookie_status);
					}
				}
				else
				{
					$cookie_delete = false;
					foreach ($this->ppdmt->cookies() as $cookie_name)
					{
						if ($this->is_set_cookie($cookie_name))
						{
							$cookie_delete = true;
							break;
						}
					}

					if ($cookie_delete)
					{
						$this->ppdmt->delete_cookies();
					}
				}

				// Create guest info close param
				if ($this->request->is_set('gic'))
				{
					$this->set_extra_url(0, false, true);
				}
			}

			$mode = $this->request->variable('mode', '');

			if ($mode === 'privacy' || $mode === 'terms')
			{
				$this->display_privacy_policy(false, false, $mode);
			}

			return;
		}
	}

	public function ucp_register_agreement($event)
	{
		if ($this->privacy_policy_enable() && ($this->request->is_set('coppa') || !$this->config['coppa_enable']))
		{
			if ($this->request->is_set_post('jvppdmt_submit') && $this->request->is_set_post('personal_data') && !$this->request->variable('personal_data', 0))
			{
				$this->redirect_cookie_action();
			}
			else if (!$this->request->is_set_post('cookie_status') || !$this->request->is_set_post('personal_data'))
			{
				if ($this->request->is_set('coppa'))
				{
					$event['s_hidden_fields'] = array_merge($event['s_hidden_fields'], array(
						'coppa' => ($this->request->variable('coppa', false)) ? 1 : 0
					));

					$this->template->assign_var('S_HIDDEN_FIELDS', build_hidden_fields($event['s_hidden_fields']));
				}

				$this->display_privacy_policy(true, true, 'register');
			}
			else
			{
				$cookie_status = ($this->request->variable('cookie_status', false)) ? 1 : 0;

				if ($this->use_cookie_guest())
				{
					$this->redirect_cookie_action($cookie_status, false);
				}

				$event['s_hidden_fields'] = array_merge($event['s_hidden_fields'], array(
					'jvppdmt_submit'	=> 1,
					'cookie_status'		=> $cookie_status,
					'personal_data'		=> (int) $this->request->variable('personal_data', 0)
				));
			}
		}
	}

	public function ucp_register_modify_template_data($event)
	{
		if ($this->privacy_policy_enable())
		{
			$event['s_hidden_fields'] = array_merge($event['s_hidden_fields'], array(
				'cookie_status' => ($this->request->variable('cookie_status', false)) ? 1 : 0,
				'personal_data' => (int) $this->request->variable('personal_data', 0)
			));
		}
	}

	// Disabled default phpBB cookie contents and enable or disable javascript create cookie.
	public function page_header_after()
	{
		if ($this->privacy_policy_enable())
		{
			$this->template->assign_vars(array(
				'S_COOKIE_NOTICE'					=> false,
				'S_JVPPDMT_ACCEPT_COOKIE'			=> $this->cookie_status(),
				'S_JVPPDMT_INFO_GUEST'				=> $this->user->data['user_id'] == ANONYMOUS && !$this->config['jvppdmt_use_cookie_guest'] && !$this->request->is_set('gic'),
				'U_JVPPDMT_INFO_GUEST_CLOSE'		=> ($this->config['jvppdmt_use_cookie_guest']) ? '' : build_url('gic') . '&amp;gic=0',

				'JVPPDMT_INFO_NO_USE_COOKIE_GUEST'	=> $this->user->lang('JVPPDMT_INFO_NO_USE_COOKIE_GUEST', '<a href="' . append_sid($this->root_path . 'ucp.' . $this->php_ext, 'mode=privacy') . '">', '</a>')
			));
		}

		if ($this->config['jvppdmt_enable'])
		{
			$this->template->assign_var('S_JVPPDMT_ENABLE', true);
		}
	}

	// +Reg. data.
	public function user_add_data($event)
	{
		$event['sql_ary'] = array_merge($event['sql_ary'], array(
			'user_cookie_status'	=> ($this->request->variable('cookie_status', false)) ? 1 : 0,
			'user_accept_pp_date'	=> $event['sql_ary']['user_regdate'],
			'user_accept_tou_date'	=> $event['sql_ary']['user_regdate'],
		));
	}

	public function user_add_after($event)
	{
		if ($this->privacy_policy_enable() && $this->config['jvppdmt_viewer_group_enable'] && $this->request->variable('personal_data', 0) == 2)
		{
			$viewer_group_id = $this->ppdmt->viewer_group_id();

			if ($viewer_group_id)
			{
				group_user_add($viewer_group_id, $event['user_id']);
			}
		}
	}

	public function login_box_redirect($event)
	{
		if ($this->privacy_policy_enable() && $this->is_registered() && !$event['admin'])
		{
			if (!$this->user->data['user_cookie_status'] && ($this->cookie_status() !== 0 || $this->is_set_cookie('sid')))
			{
				$this->ppdmt->delete_cookies();
			}

			if ($this->user->data['user_cookie_status'])
			{
				$this->set_extra_url(1, false);
			}
		}
	}

	public function functions_redirect($event)
	{
		if ($this->is_registered() && strpos($event['url'], '?') !== false)
		{
			$query_string = explode("&", explode("?", $event['url'])[1]);

			foreach ($query_string as $k => $v)
			{
				if (strpos($v, 'h_lang=') !== false || strpos($v, 'gic=') !== false)
				{
					$event['url'] = str_replace(array('&' . $v, $v), '', $event['url']);
				}
			}
		}
	}

	public function acp_users_display_overview($event)
	{
		$this->user->add_lang_ext('jv/ppdmt', 'info_ucp_ppdmt');

		$this->template->assign_vars(array(
			'PRIVACY_POLICY_ACCEPT_DATE'	=> ($event['user_row']['user_accept_pp_date']) ? $this->user->format_date($event['user_row']['user_accept_pp_date'], false, true) : '-',
			'TERM_OF_USE_ACCEPT_DATE'		=> ($event['user_row']['user_accept_tou_date']) ? $this->user->format_date($event['user_row']['user_accept_tou_date'], false, true) : '-'
		));
	}

	public function user_delete($event)
	{
		if ($this->privacy_policy_enable() && $event['mode'] == 'ppdmt_remove')
		{
			$this->user->add_lang_ext('jv/ppdmt', 'info_ucp_ppdmt');

			$this->template->assign_vars(array(
				'MESSAGE_TITLE'	=> $this->user->lang['INFORMATION'],
				'MESSAGE_TEXT'	=> $this->user->lang['JVPPDMT_MY_ACC_DELETE_SUCCESS']
			));

			if (!$this->user->data['user_cookie_status'])
			{
				$this->set_extra_url(0);
			}

			meta_refresh(5, append_sid($this->root_path . 'index.' . $this->php_ext));

			page_header($this->user->lang['UCP_PROFILE_JVPPDMT_MY_ACC_DELETE']);

			$this->template->set_filenames(array(
				'body' => 'message_body.html')
			);

			page_footer();
		}
	}

	// Disabled phpBB create cookie.
	public function phpbb_set_cookie($event)
	{
		if ($this->privacy_policy_enable())
		{
			$cookie_status = ($this->is_registered() || $this->use_cookie_guest()) ? $this->cookie_status() : 0;

			if ($cookie_status == 0)
			{
				$event['disable_cookie'] = true;
			}
		}
	}

	private function cookie_status()
	{
		$status = null;

		if ($this->is_registered())
		{
			$status = ($this->config['jvppdmt_last_privacy_policy'] > $this->user->data['user_accept_pp_date']) ? null : $this->user->data['user_cookie_status'];
		}
		else
		{
			if ($this->request->is_set('cookie_status'))
			{
				$status = ($this->request->variable('cookie_status', false)) ? 1 : 0;
			}
			else if ($this->is_set_cookie('cookie_status'))
			{
				$status = ($this->request->variable($this->config['cookie_name'] . "_cookie_status", false, false, \phpbb\request\request_interface::COOKIE)) ? 1 : 0;
			}
		}

		return $status;
	}

	private function privacy_policy_enable()
	{
		return $this->config['jvppdmt_enable'] && empty($this->user->data['is_bot']);
	}

	private function display_privacy_policy($cookie_confirm = true, $personal_data_confirm = true, $mode = '')
	{
		if ($mode === 'privacy' || $mode === 'terms')
		{
			$title = ($mode == 'privacy') ? 'JVPPDMT_PRIVACY_POLICY' : 'TERMS_USE';

			$this->template->assign_vars(array(
				'S_JVPPDMT_PHPBB'		=> true,

				'JVPPDMT_MESSAGE_TEXT'	=> ($mode == 'privacy') ? $this->gen_privacy_policy() : $this->user->lang('TERMS_OF_USE_CONTENT', $this->config['sitename'], generate_board_url()),
				'JVPPDMT_MESSAGE_TITLE'	=> $this->user->lang[$title],
			));
		}
		else
		{
			$title = 'JVPPDMT_PRIVACY_POLICY';

			$this->template->assign_vars(array(
				'S_JVPPDMT_PHPBB'					=> ($mode === 'register'),
				'S_JVPPDMT_COOKIE_CONFIRM'			=> $cookie_confirm,
				'S_JVPPDMT_PERSONAL_DATA_CONFIRM'	=> $personal_data_confirm,
				'S_JVPPDMT_ENABLE_VIEWER_GROUP'		=> $this->config['jvppdmt_viewer_group_enable'],
				'S_JVPPDMT_NOT_CONFIRM'				=> $personal_data_confirm && $this->request->is_set_post('jvppdmt_submit') || !$personal_data_confirm && $this->request->is_set_post('jvppdmt_cookie'),

				'U_JVPPDMT_ACTION'					=> ($mode === 'register') ? append_sid($this->root_path . 'ucp.' . $this->php_ext, "mode=register") : append_sid($this->root_path . 'index.' . $this->php_ext),

				'JVPPDMT_MESSAGE_TEXT'				=> $this->gen_privacy_policy(),
				'JVPPDMT_MESSAGE_TITLE'				=> $this->user->lang[$title],
				'JVPPDMT_COOKIE_CONFIRM'			=> $this->user->lang('JVPPDMT_COOKIE_CONFIRM', $this->config['sitename']),
				'JVPPDMT_PERSONAL_DATA_CONFIRM'		=> $this->user->lang('JVPPDMT_PERSONAL_DATA_CONFIRM', $this->config['sitename'])
			));
		}

		page_header($this->user->lang[$title]);

		$this->template->set_filenames(array(
			'body' => '@jv_ppdmt/privacy_policy.html')
		);

		page_footer();
	}

	private function gen_privacy_policy()
	{
		$this->user->add_lang_ext('jv/ppdmt', 'privacy_policy');

		if ($this->config['jvppdmt_your_pp_file'] !== '')
		{
			$this->user->add_lang_ext('jv/ppdmt', $this->config['jvppdmt_your_pp_file']);
		}

		$guest_info_cookie = ($this->use_cookie_guest()) ? '' : '<br><strong class="error">' . $this->user->lang['JVPPDMT_DISABLED_COOKIE_GUEST_USER'] . '</strong><br>';

		$pp_ary = explode('<h3>', $this->user->lang['JVPPDMT_PRIVACY_POLICY_DESC']);

		$num = 0;
		$pp_text = '';
		foreach ($pp_ary as $step)
		{
			$pp_text .= (!$num) ? $step : '<h3>' . $num . '. '. $step;
			$num++;
		}

		$extra_text = '<span style="display: none;">unintelligible text</span>';
		$contact = $extra_text . str_replace('@', "{$extra_text}@{$extra_text}", $this->config['board_contact']) . $extra_text;
		$phone = $extra_text . str_replace(' ', " {$extra_text}", $this->config['jvppdmt_controller_phone']) . $extra_text;

		return str_replace(array('</h3><br>', '</h3><br />'), '</h3>', nl2br(sprintf($pp_text, $this->config['sitename'], $this->config['jvppdmt_controller_name'], $contact, $phone, sprintf(implode('<br>', $this->user->lang['JVPPDMT_USED_COOKIE']), $this->config['cookie_name']), $guest_info_cookie)));
	}

	private function redirect_cookie_action($cookie_status = null, $redirect = true)
	{
		if ($this->use_cookie_guest())
		{
			if ($cookie_status === null)
			{
				$cookie_status = ($this->request->variable('cookie_status', false)) ? 1 : 0;
			}

			if ($cookie_status && !$this->is_set_cookie('sid'))
			{
				$this->ppdmt->create_cookies();
			}
			else if ($cookie_status)
			{
				$cookie_expire = time() + (($this->config['max_autologin_time']) ? 86400 * (int) $this->config['max_autologin_time'] : 31536000);
				$this->ppdmt->set_cookie('cookie_status', $cookie_status, $cookie_expire);
				unset($cookie_expire);
			}

			$param = (!$cookie_status || (!$this->is_set_cookie('sid'))) ? "cookie_status=$cookie_status" : false;

			if (!$cookie_status)
			{
				$this->ppdmt->delete_cookies();
			}

			if ($param)
			{
				$this->set_extra_url($cookie_status);
			}
		}

		if ($redirect)
		{
			redirect(append_sid('index.' . $this->php_ext));
		}
	}

	private function set_extra_url($cookie_status, $add = true, $guest_info_close = false)
	{
		global $_EXTRA_URL;

		if ($guest_info_close)
		{
			$_EXTRA_URL = array_merge($_EXTRA_URL, array('gic=0'));
		}
		else
		{
			if (count($_EXTRA_URL))
			{
				$keys = array();
				$keys[] = array_search('cookie_status=0', $_EXTRA_URL);
				$keys[] = array_search('cookie_status=1', $_EXTRA_URL);

				foreach ($keys as $key)
				{
					if (is_numeric($key))
					{
						unset($_EXTRA_URL[$key]);
					}
				}
			}

			if ($add)
			{
				$_EXTRA_URL = array_merge($_EXTRA_URL, array('cookie_status=' . $cookie_status));
			}
		}
	}

	private function is_registered()
	{
		return !empty($this->user->data['is_registered']) && $this->user->data['user_id'] != ANONYMOUS;
	}

	private function use_cookie_guest()
	{
		return !$this->is_registered() && $this->config['jvppdmt_use_cookie_guest'];
	}

	private function is_set_cookie($cookie_name)
	{
		return $this->request->is_set($this->config['cookie_name'] . '_' . $cookie_name, \phpbb\request\request_interface::COOKIE);
	}

	private function registration_delete($mode = 'privacy_policy')
	{
		$this->user->add_lang('ucp');
		$this->user->add_lang_ext('jv/ppdmt', 'info_ucp_ppdmt');

		$download_personal_data = new \jv\ppdmt\ucp\privacy_data_module();
		$download_personal_data->main(0, 'personal');

		$delete_my_acc = new \jv\ppdmt\ucp\delete_my_registration_module();
		$delete_my_acc->main(0, 'ppdmt_remove');

		if ($mode == 'privacy_policy')
		{
			$s_hidden_fields = array(
				'jvppdmt_submit'	=> 1,
				'jvppdmt_confirm'	=> 1
			);
		}
		else
		{
			$s_hidden_fields = array(
				'not_agreed'	=> 1
			);
		}

		$this->template->assign_vars(array(
			'S_JVPPDMT_PHPBB'	=> false,
			'S_HIDDEN_FIELDS'	=> build_hidden_fields($s_hidden_fields),
			'S_UCP_ACTION'		=> append_sid($this->root_path . 'index.' . $this->php_ext),
		));

		page_header($this->user->lang[$delete_my_acc->page_title]);

		$this->template->set_filenames(array(
			'body' => $delete_my_acc->tpl_name . '.html')
		);

		page_footer();
	}
}
