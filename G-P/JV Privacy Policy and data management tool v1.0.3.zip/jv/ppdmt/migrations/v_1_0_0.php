<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\migrations;

class v_1_0_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v32x\v322');
	}

	public function update_schema()
	{
		return array(
			'add_columns' => array(
				$this->table_prefix . 'users' => array(
					'user_cookie_status'	=> array('BOOL', 0),
					'user_accept_pp_date'	=> array('TIMESTAMP', 0),
					'user_accept_tou_date'	=> array('TIMESTAMP', 0)
				)
			)
		);
	}

	public function revert_schema()
	{
		return array(
			'drop_columns' => array(
				$this->table_prefix . 'users' => array(
					'user_cookie_status',
					'user_accept_pp_date',
					'user_accept_tou_date'
				)
			)
		);
	}

	public function revert_data()
	{
		return array(
			array('custom', array(array($this, 'delete_group'))),
		);
	}

	public function update_data()
	{
		return array(
			// Add configs
			array('config.add', array('jvppdmt_enable', 0)),
			array('config.add', array('jvppdmt_viewer_group_enable', 0)),
			array('config.add', array('jvppdmt_last_privacy_policy', time())),
			array('config.add', array('jvppdmt_last_term_of_use', time())),
			array('config.add', array('jvppdmt_controller_name', '')),
			array('config.add', array('jvppdmt_controller_phone', '')),
			array('config.add', array('jvppdmt_use_cookie_guest', 0)),
			array('config.add', array('jvppdmt_your_pp_file', '')),
			// Add ucp module
			array('module.add', array(
				'ucp', 'UCP_PROFILE', array(
					'module_basename'	=> '\jv\ppdmt\ucp\delete_my_registration_module',
					'modes'				=> array('my_acc_delete')
				)
			)),
			array('module.add', array('ucp', 0, 'UCP_JVPPDMT_PRIVACY_DATA')),
			array('module.add', array(
				'ucp', 'UCP_JVPPDMT_PRIVACY_DATA', array(
					'module_basename'	=> '\jv\ppdmt\ucp\privacy_data_module',
					'modes'				=> array('personal', 'settings')
				)
			)),
			// Add modules
			array('module.add', array(
				'acp', 'ACP_CAT_DOT_MODS', 'ACP_CAT_JVPPDMT'
			)),
			array('module.add', array(
				'acp', 'ACP_CAT_JVPPDMT', array(
					'module_basename'	=> '\jv\ppdmt\acp\ppdmt_module',
					'modes'				=> array('settings')
				)
			)),
			array('custom', array(array($this, 'add_group'))),
		);
	}

	public function add_group()
	{
		$sql = 'SELECT group_id FROM ' . $this->table_prefix . 'groups
			WHERE group_name = "JVPPDMT_REGISTERED_VIEWER"
			AND group_type = ' . GROUP_SPECIAL;
		$result = $this->db->sql_query($sql);
		$group_id = (int) $this->db->sql_fetchfield('group_id');
		$this->db->sql_freeresult($result);

		if (!$group_id)
		{
			$sql_ary = array(
				'group_type'			=> GROUP_SPECIAL,
				'group_founder_manage'	=> 1,
				'group_name'			=> 'JVPPDMT_REGISTERED_VIEWER',
				'group_desc'			=> ''
			);

			$sql = 'INSERT INTO ' . $this->table_prefix . 'groups ' . $this->db->sql_build_array('INSERT', $sql_ary);
			$this->sql_query($sql);
		}
	}

	public function delete_group()
	{
		$sql = 'SELECT group_id FROM ' . $this->table_prefix . 'groups
			WHERE group_name = "JVPPDMT_REGISTERED_VIEWER"
			AND group_type = ' . GROUP_SPECIAL;
		$result = $this->db->sql_query($sql);
		$group_id = (int) $this->db->sql_fetchfield('group_id');
		$this->db->sql_freeresult($result);

		if ($group_id)
		{
			if (!function_exists('group_delete'))
			{
				include($this->phpbb_root_path . 'includes/functions_user.' . $this->php_ext);
			}

			group_delete($group_id);
		}
	}
}
