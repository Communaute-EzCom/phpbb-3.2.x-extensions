<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\migrations;

class group_permission extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\ppdmt\migrations\v_1_0_0');
	}

	public function update_data()
	{
		return array(
			array('permission.permission_set', array('JVPPDMT_REGISTERED_VIEWER', array('u_download', 'u_sendpm', 'u_savedrafts'), 'group', false)),
		);
	}
}
