<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\controller\acp;

class base
{
	protected $u_action, $tpl_name, $page_title;

	public function set_page_url($u_action)
	{
		$this->u_action = $u_action;
	}

	public function get_tpl_name(&$tpl_name)
	{
		if ($this->tpl_name)
		{
			$tpl_name = $this->tpl_name;
		}
	}

	public function get_page_title(&$page_title)
	{
		if ($this->page_title)
		{
			$page_title = $this->page_title;
		}
	}
}
