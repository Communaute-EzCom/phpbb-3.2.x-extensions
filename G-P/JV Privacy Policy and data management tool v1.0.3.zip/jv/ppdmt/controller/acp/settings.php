<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\controller\acp;

class settings extends base
{
	protected $request, $config, $user, $log, $template;
	protected $u_action;

	public function __construct($request, $config, $user, $log, $template)
	{
		$this->request = $request;
		$this->config = $config;
		$this->user = $user;
		$this->log = $log;
		$this->template = $template;
	}

	public function main()
	{
		$error = array();
		$submit = $this->request->is_set_post('submit');
		$jvppdmt_reset = $this->request->is_set_post('jvppdmt_reset');
		$jvppdmt_term_of_use_reset = $this->request->is_set_post('jvppdmt_term_of_use_reset');

		if ($jvppdmt_reset)
		{
			if (confirm_box(true))
			{
				$this->config->set('jvppdmt_last_privacy_policy', time());

				$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_JVPPDMT_RESET');

				trigger_error($this->user->lang['ACP_JVPPDMT_RESET_SUCCESS'] . adm_back_link($this->u_action), E_USER_NOTICE);
			}
			else
			{
				confirm_box(false, 'ACP_JVPPDMT_RESET', build_hidden_fields(array('jvppdmt_reset' => true)));
			}
		}

		if ($jvppdmt_term_of_use_reset)
		{
			if (confirm_box(true))
			{
				$this->config->set('jvppdmt_last_term_of_use', time());

				$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_JVPPDMT_TERM_OF_USE_RESET');

				trigger_error($this->user->lang['ACP_JVPPDMT_TERM_OF_USE_RESET_SUCCESS'] . adm_back_link($this->u_action), E_USER_NOTICE);
			}
			else
			{
				confirm_box(false, 'ACP_JVPPDMT_TERM_OF_USE_RESET', build_hidden_fields(array('jvppdmt_term_of_use_reset' => true)));
			}
		}

		$this->user->add_lang(array('acp/board', 'posting'));

		$this->page_title	= 'ACP_JVPPDMT_GLOBAL_SETTINGS';
		$this->tpl_name		= 'acp_board';

		$form_key = 'acp_ppdmt_settings';
		add_form_key($form_key);

		$this->new_config = clone $this->config;
		$cfg_array = (isset($_REQUEST['config'])) ? $this->request->variable('config', array('' => ''), true) : $this->new_config;

		$display_vars = array(
			'title'	=> 'ACP_JVPPDMT_GLOBAL_SETTINGS',
			'vars'	=> array(
				'legend1'						=> 'GENERAL_SETTINGS',
				'jvppdmt_enable'				=> array('lang' => 'ACP_JVPPDMT_PRIVACY_POLICY_ENABLE',	'validate' => 'bool',		'type' => 'radio:enabled_disabled',	'explain' => true),
				'jvppdmt_use_cookie_guest'		=> array('lang' => 'ACP_JVPPDMT_USE_COOKIE_GUEST',		'validate' => 'bool',		'type' => 'radio:enabled_disabled',	'explain' => true),
				'jvppdmt_viewer_group_enable'	=> array('lang' => 'ACP_JVPPDMT_VIEWER_GROUP',			'validate' => 'bool',		'type' => 'radio:enabled_disabled',	'explain' => true),
				'jvppdmt_viewer_group_info'		=> array('lang' => 'ACP_JVPPDMT_VIEWER_GROUP_INFO',		'validate' => 'bool',		'type' => 'radio:enabled_disabled',	'explain' => true),
				'jvppdmt_cookie_info'			=> array('lang' => 'ACP_JVPPDMT_COOIKE_INFO',			'validate' => 'bool',		'type' => 'radio:enabled_disabled',	'explain' => true),
				'jvppdmt_controller_name'		=> array('lang' => 'ACP_JVPPDMT_CONTROLLER_NAME',		'validate' => 'string:1',	'type' => 'text:20:255',			'explain' => true),
				'jvppdmt_controller_phone'		=> array('lang' => 'ACP_JVPPDMT_CONTROLLER_PHONE',		'validate' => 'string:1',	'type' => 'text:20:255',			'explain' => true),
				'jvppdmt_your_pp_file'			=> array('lang' => 'ACP_JVPPDMT_YOUR_PP_FILE',			'validate' => 'string',		'type' => 'text:20:255',			'explain' => true),

				'legend2'						=> 'ACP_SUBMIT_CHANGES'
			)
		);

		if (isset($display_vars['lang']))
		{
			$this->user->add_lang($display_vars['lang']);
		}

		validate_config_vars($display_vars['vars'], $cfg_array, $error);

		if ($submit && !check_form_key($form_key))
		{
			$error[] = $this->user->lang['FORM_INVALID'];
		}

		if (count($error))
		{
			$submit = false;
		}

		foreach ($display_vars['vars'] as $config_name => $data)
		{
			if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
			{
				continue;
			}

			$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

			if ($submit)
			{
				$this->config->set($config_name, $config_value);
			}
		}

		if ($submit)
		{
			$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_JVPPDMT_SETTINGS');
			trigger_error($this->user->lang('CONFIG_UPDATED') . adm_back_link($this->u_action), E_USER_NOTICE);
		}

		foreach ($display_vars['vars'] as $config_key => $vars)
		{
			if (!is_array($vars) && strpos($config_key, 'legend') === false)
			{
				continue;
			}

			if (strpos($config_key, 'legend') !== false)
			{
				if ($config_key === 'legend2')
				{
					$this->template->assign_block_vars('options', array(
						'KEY'			=> 'jvppdmt_reset',
						'TITLE'			=> $this->user->lang['ACP_JVPPDMT_RESET'],
						'S_EXPLAIN'		=> true,
						'TITLE_EXPLAIN'	=> $this->user->lang['ACP_JVPPDMT_RESET_EXPLAIN'],
						'CONTENT'		=> '<input class="button1" type="submit" id="jvppdmt_reset" name="jvppdmt_reset" value="' . $this->user->lang['RUN'] . '"><br>' . $this->user->lang('ACP_JVPPDMT_LAST_RESET_DATE', $this->user->format_date($this->config['jvppdmt_last_privacy_policy'], false, true))
					));

					$this->template->assign_block_vars('options', array(
						'KEY'			=> 'jvppdmt_term_of_use_reset',
						'TITLE'			=> $this->user->lang['ACP_JVPPDMT_TERM_OF_USE_RESET'],
						'S_EXPLAIN'		=> true,
						'TITLE_EXPLAIN'	=> $this->user->lang['ACP_JVPPDMT_TERM_OF_USE_RESET_EXPLAIN'],
						'CONTENT'		=> '<input class="button1" type="submit" id="jvppdmt_term_of_use_reset" name="jvppdmt_term_of_use_reset" value="' . $this->user->lang['RUN'] . '"><br>' . $this->user->lang('ACP_JVPPDMT_LAST_RESET_DATE', $this->user->format_date($this->config['jvppdmt_last_term_of_use'], false, true))
					));
				}

				$this->template->assign_block_vars('options', array(
					'S_LEGEND'	=> true,
					'LEGEND'	=> (isset($this->user->lang[$vars])) ? $this->user->lang[$vars] : $vars
				));

				continue;
			}

			$type = explode(':', $vars['type']);

			$l_explain = '';
			if ($vars['explain'] && isset($vars['lang_explain']))
			{
				$l_explain = (isset($this->user->lang[$vars['lang_explain']])) ? $this->user->lang[$vars['lang_explain']] : $vars['lang_explain'];
			}
			else if ($vars['explain'])
			{
				$l_explain = (isset($this->user->lang[$vars['lang'] . '_EXPLAIN'])) ? $this->user->lang[$vars['lang'] . '_EXPLAIN'] : '';
			}

			if (!isset($vars['method']))
			{
				$content = build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars);
			}
			else
			{
				$args = array($this->new_config[$config_key], $config_key);

				$content = call_user_func_array(array($this, $vars['method']), $args);
			}

			if (empty($content))
			{
				continue;
			}

			$this->template->assign_block_vars('options', array(
				'KEY'			=> $config_key,
				'TITLE'			=> (isset($this->user->lang[$vars['lang']])) ? $this->user->lang[$vars['lang']] : $vars['lang'],
				'S_EXPLAIN'		=> $vars['explain'],
				'TITLE_EXPLAIN'	=> $l_explain,
				'CONTENT'		=> $content
			));

			unset($display_vars['vars'][$config_key]);
		}

		$this->template->assign_vars(array(
			'L_TITLE'			=> $this->user->lang[$display_vars['title']],
			'L_TITLE_EXPLAIN'	=> $this->user->lang[$display_vars['title'] . '_EXPLAIN'],

			'S_ERROR'			=> (count($error)) ? true : false,
			'ERROR_MSG'			=> implode('<br>', $error),

			'U_ACTION'			=> $this->u_action
		));
	}
}