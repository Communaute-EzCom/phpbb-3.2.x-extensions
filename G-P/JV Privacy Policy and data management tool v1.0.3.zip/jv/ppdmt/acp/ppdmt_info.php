<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\acp;

class ppdmt_module_info
{
	function module()
	{
		return array(
			'filename'		=> '\jv\ppdmt\acp\ppdmt_module',
			'title'			=> 'ACP_CAT_JVPPDMT',
			'modes'			=> array(
				'settings'	=> array('title' => 'ACP_JVPPDMT_SETTINGS', 'auth' => 'ext_jv/ppdmt && acl_a_server', 'cat' => array('ACP_CAT_JVPPDMT'))
			)
		);
	}
}
