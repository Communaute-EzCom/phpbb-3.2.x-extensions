<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\acp;

class ppdmt_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	public function main($id, $mode)
	{
		if (!in_array($mode, array('settings')))
		{
			trigger_error('NO_MODE', E_USER_ERROR);
		}

		global $phpbb_container;

		$this->tpl_name = "acp_{$mode}";
		$this->page_title = 'ACP_PPDMT_' . strtoupper($mode);
		$admin_controller = $phpbb_container->get("jv.ppdmt.controller.acp.{$mode}");

		$admin_controller->set_page_url($this->u_action);
		$admin_controller->main();
		$admin_controller->get_tpl_name($this->tpl_name);
		$admin_controller->get_page_title($this->page_title);

		unset($admin_controller);
	}
}
