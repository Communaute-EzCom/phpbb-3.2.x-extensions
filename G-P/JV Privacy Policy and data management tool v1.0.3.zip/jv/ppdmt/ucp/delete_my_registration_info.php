<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\ucp;

class delete_my_registration_info
{
	function module()
	{
		return array(
			'filename'	=> '\jv\ppdmt\ucp\delete_my_registration_module',
			'title'		=> 'UCP_PROFILE',
			'modes'		=> array(
				'my_acc_delete' => array('title' => 'UCP_PROFILE_JVPPDMT_MY_ACC_DELETE', 'auth' => 'ext_jv/ppdmt && cfg_jvppdmt_enable', 'cat' => array('UCP_PROFILE'))
			)
		);
	}
}
