<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\ucp;

class delete_my_registration_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	public function main($id, $mode)
	{
		global $db, $user, $auth, $template, $phpbb_root_path, $phpEx;
		global $request, $phpbb_container, $phpbb_log, $phpbb_dispatcher;

		$error = array();
		$submit			= $request->variable('submit', false, false, \phpbb\request\request_interface::POST);
		$delete_acc		= $request->variable('delete_acc', false, false, \phpbb\request\request_interface::POST);
		$delete_post	= ($request->variable('delete_post', false, false, \phpbb\request\request_interface::POST)) ? true : false;
		$user_password	= $request->variable('user_password', '', true, \phpbb\request\request_interface::POST);

		add_form_key('jvppdmt_my_acc_delete');

		if ($submit)
		{
			if (!check_form_key('jvppdmt_my_acc_delete'))
			{
				$error[] = 'FORM_INVALID';
			}

			if (!$delete_acc)
			{
				$error[] = 'JVPPDMT_MY_ACC_DELETE_CONFIRM_ERROR';
			}

			if ($user->data['user_type'] == USER_FOUNDER)
			{
				$error[] = 'JVPPDMT_MY_ACC_DELETE_FOUNDER_ERROR';
			}

			// Instantiate passwords manager
			$passwords_manager = $phpbb_container->get('passwords.manager');

			if (!$passwords_manager->check($user_password, $user->data['user_password']))
			{
				$error[] = 'CUR_PASSWORD_ERROR';
			}

			if (!count($error) && $submit)
			{
				$delete_type = ($delete_post) ? 'remove' : 'retain';
				$log_type = ($delete_post) ? 'LOG_JVPPDMT_MY_ACC_POST_DELETE' : 'LOG_JVPPDMT_MY_ACC_DELETE';

				$additional_data = array(
					'reportee_id'	=> 0,
					$user->data['username']
				);

				if (!function_exists('user_delete'))
				{
					include($phpbb_root_path . 'includes/functions_user.' . $phpEx);
				}

				$phpbb_log->add('user', ANONYMOUS, $user->ip, $log_type, time(), $additional_data);
				user_delete($delete_type, $user->data['user_id'], $user->data['username']);

				$vars = array('mode');
				extract($phpbb_dispatcher->trigger_event('jv.ppdmt.user_delete', compact($vars)));

				meta_refresh(5, append_sid($phpbb_root_path . 'index.' . $phpEx));
				trigger_error('JVPPDMT_MY_ACC_DELETE_SUCCESS');
			}

			// Replace "error" strings with their real, localised form
			$error = array_map(array($user, 'lang'), $error);
		}

		$template->assign_vars(array(
			'S_JVPPDMT_PHPBB'	=> true,
			'S_ERROR'			=> (count($error)) ? true : false,
			'S_UCP_ACTION'		=> $this->u_action,

			'L_TITLE'			=> $user->lang['UCP_PROFILE_JVPPDMT_MY_ACC_DELETE'],

			'ERROR'				=> (count($error)) ? implode('<br>', $error) : '',
			'CONFIRM_CHECKED'	=> ($delete_acc) ? ' checked="checked"' : '',
			'POST_CHECKED'		=> ($delete_post) ? ' checked="checked"' : ''
		));

		// Set desired template
		$this->tpl_name = '@jv_ppdmt/ucp_profile_my_acc_delete';
		$this->page_title = 'UCP_PROFILE_JVPPDMT_MY_ACC_DELETE';
	}
}