<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\ucp;

class privacy_data_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $db, $config, $user, $template, $request, $phpbb_container, $log, $root_path, $php_ext;
	protected $posts_table, $privmsgs_table, $profile_fields_table, $profile_fields_data_table, $profile_fields_language_table;

	public function __construct()
	{
		global $db, $config, $user, $template, $request, $phpbb_container, $phpbb_log, $phpbb_root_path, $phpEx;

		$this->db								= $db;
		$this->config							= $config;
		$this->user								= $user;
		$this->template							= $template;
		$this->request							= $request;
		$this->phpbb_container					= $phpbb_container;
		$this->log								= $phpbb_log;
		$this->root_path						= $phpbb_root_path;
		$this->php_ext							= $phpEx;
	}

	public function main($id, $mode)
	{
		$error = array();

		switch ($mode)
		{
			case 'personal':
				$this->page_title = 'UCP_JVPPDMT_PRIVACY_DATA';
				$this->tpl_name = '@jv_ppdmt/ucp_privacy_data';

				$ext_profile_data = array();
				$type_collection						= $this->phpbb_container->get('profilefields.type_collection');
				$this->posts_table						= $this->phpbb_container->getParameter('tables.posts');
				$this->privmsgs_table					= $this->phpbb_container->getParameter('tables.privmsgs');
				$this->profile_fields_table				= $this->phpbb_container->getParameter('tables.profile_fields');
				$this->profile_fields_data_table		= $this->phpbb_container->getParameter('tables.profile_fields_data');
				$this->profile_fields_language_table	= $this->phpbb_container->getParameter('tables.profile_fields_language');

				$profile_fields = $this->profile_fields_data();

				foreach ($profile_fields as $ident => $ident_ary)
				{
					$profile_field = $type_collection[$ident_ary['data']['field_type']];
					$value = $profile_field->get_profile_value($ident_ary['value'], $ident_ary['data']);
					$value_raw = $profile_field->get_profile_value_raw($ident_ary['value'], $ident_ary['data']);

					$value = (is_numeric($value_raw)) ? $value : $value_raw;

					$this->template->assign_block_vars('profile_fields', array(
						'FIELD_NAME'	=> $this->user->lang($ident_ary['data']['lang_name']),
						'FIELD_VALUE'	=> $value,
					));

					$ext_profile_data[$this->user->lang($ident_ary['data']['lang_name'])] = $value;
				}

				$birthday['bday_year'] = $birthday['bday_month'] = $birthday['bday_day'] = '-';

				if ($this->user->data['user_birthday'])
				{
					list($birthday['bday_day'], $birthday['bday_month'], $birthday['bday_year']) = explode('-', $this->user->data['user_birthday']);
				}

				$sql = 'SELECT COUNT(post_id) AS total_post
					FROM ' . $this->posts_table . '
					WHERE poster_id = ' . (int) $this->user->data['user_id'];
				$result = $this->db->sql_query($sql);
				$total_post = (int) $this->db->sql_fetchfield('total_post');
				$this->db->sql_freeresult($result);

				$sql = 'SELECT COUNT(msg_id) AS total_pm
					FROM ' . $this->privmsgs_table . '
					WHERE author_id = ' . (int) $this->user->data['user_id'];
				$result = $this->db->sql_query($sql);
				$total_pm = (int) $this->db->sql_fetchfield('total_pm');
				$this->db->sql_freeresult($result);

				$user_birthday = ($birthday['bday_year'] !== '-') ? $this->user->lang['YEAR'] . $this->user->lang['COLON'] . ' ' .  $birthday['bday_year'] . $this->user->lang['COMMA_SEPARATOR'] . $this->user->lang['MONTH'] . $this->user->lang['COLON'] . ' ' .  $birthday['bday_month'] . $this->user->lang['COMMA_SEPARATOR'] . $this->user->lang['DAY'] . $this->user->lang['COLON'] . ' ' . $birthday['bday_day'] : '-';
				$user_birthday = str_replace('  ', ' 0', $user_birthday);

				$data_ary = array(
					'USERNAME'						=> $this->user->data['username'],
					'REGISTRATION_DATE'				=> $this->user->format_date($this->user->data['user_regdate'], false, true),
					'PRIVACY_POLICY_ACCEPT_DATE'	=> ($this->user->data['user_accept_pp_date']) ? $this->user->format_date($this->user->data['user_accept_pp_date'], false, true) : '-',
					'TERM_OF_USE_ACCEPT_DATE'		=> ($this->user->data['user_accept_tou_date']) ? $this->user->format_date($this->user->data['user_accept_tou_date'], false, true) : '-',
					'REGISTRATION_IP'				=> $this->user->data['user_ip'],
					'EMAIL_ADDRESS'					=> $this->user->data['user_email'],
					'BIRTHDAY'						=> $user_birthday,
					'UCP_JABBER'					=> $this->user->data['user_jabber'] ? $this->user->data['user_jabber'] : '-',
				);

				$dl_type = $this->request->variable('data_type', '');

				$dowmload_options  = '<option value="personal_data"' . (($dl_type == 'personal_data') ? ' selected="selected"' : '') . '>' . $this->user->lang['UCP_JVPPDMT_PRIVACY_DATA'] . '</option>';
				$dowmload_options .= '<option value="post"' . (($dl_type == 'post') ? ' selected="selected"' : '') . '>' . $this->user->lang['POSTS'] . '</option>';
				$dowmload_options .= '<option value="pm"' . (($dl_type == 'pm') ? ' selected="selected"' : '') . '>' . $this->user->lang['JVPPDMT_SENT_PRIVATE_MESSAGES'] . '</option>';

				$this->template->assign_vars($data_ary + array(
					'S_JVPPDMT_OPTIONS'	=> $dowmload_options,

					'L_TITLE'			=> $this->user->lang[$this->page_title],

					'YOUR_POST_NUMBER'	=> ($total_post > 0) ? '<a href="' . append_sid($this->root_path . 'search.' . $this->php_ext, 'search_id=egosearch') . '" title="' . $this->user->lang['SEARCH_SELF'] . '">' . $total_post . '</a>' : 0,
					'YOUR_PM_NUMBER'	=> ($total_pm > 0) ? '<a href="' . append_sid($this->root_path . 'ucp.' . $this->php_ext, 'i=pm') . '" title="' . $this->user->lang['PRIVATE_MESSAGES'] . '">' . $total_pm . '</a>' : 0
				));

				$data_ary = array_merge($data_ary, $ext_profile_data);
				$data_ary += array('YOUR_POST_NUMBER' => ($total_post >= 0) ? $total_post : 0);
				$data_ary += array('YOUR_PM_NUMBER' => ($total_pm >= 0) ? $total_pm : 0);

				if ($this->request->is_set_post('download_pd'))
				{
					switch ($dl_type)
					{
						case 'post':
							$sql = 'SELECT post_id, poster_ip, post_time, post_subject , post_text, bbcode_uid
								FROM ' . $this->posts_table . '
								WHERE poster_id = ' . (int) $this->user->data['user_id'];
							$result = $this->db->sql_query($sql);
							$data = array();
							while ($row = $this->db->sql_fetchrow($result))
							{
								decode_message($row['post_text'], $row['bbcode_uid']);

								$post  = $this->user->lang['JVPPDMT_ID'] . $this->user->lang['COLON'] . ' ' . $row['post_id'] . "\n";
								$post .= $this->user->lang['JVPPDMT_REL_IP'] . $this->user->lang['COLON'] . ' ' . $row['poster_ip'] . "\n";
								$post .= $this->user->lang['JVPPDMT_CREATE_TIME'] . $this->user->lang['COLON'] . ' ' . $this->user->format_date($row['post_time'], false, true) . "\n";
								$post .= $this->user->lang['SUBJECT'] . $this->user->lang['COLON'] . ' ' . str_replace('Re: ', '', $row['post_subject']) . "\n";
								$post .= $this->user->lang['MESSAGE'] . $this->user->lang['COLON'] . ' ' . $row['post_text'] . "\n";

								$data[] = $post;
							}
							$this->db->sql_freeresult($result);

							if (count($data))
							{
								$this->download_data('post', $data);
							}
							else
							{
								$error[] = $this->user->lang['JVPPDMT_NOT_FOUND_POST'];
							}
						break;

						case 'pm':
							$sql = 'SELECT msg_id, author_ip, message_time, message_subject , message_text, bbcode_uid
								FROM ' . $this->privmsgs_table . '
								WHERE author_id = ' . (int) $this->user->data['user_id'];
							$result = $this->db->sql_query($sql);
							$data = array();
							while ($row = $this->db->sql_fetchrow($result))
							{
								decode_message($row['message_text'], $row['bbcode_uid']);

								$post  = $this->user->lang['JVPPDMT_ID'] . $this->user->lang['COLON'] . ' ' . $row['msg_id'] . "\n";
								$post .= $this->user->lang['JVPPDMT_REL_IP'] . $this->user->lang['COLON'] . ' ' . $row['author_ip'] . "\n";
								$post .= $this->user->lang['JVPPDMT_CREATE_TIME'] . $this->user->lang['COLON'] . ' ' . $this->user->format_date($row['message_time'], false, true) . "\n";
								$post .= $this->user->lang['SUBJECT'] . $this->user->lang['COLON'] . ' ' . str_replace('Re: ', '', $row['message_subject']) . "\n";
								$post .= $this->user->lang['MESSAGE'] . $this->user->lang['COLON'] . ' ' . $row['message_text'] . "\n";

								$data[] = $post;
							}
							$this->db->sql_freeresult($result);

							if (count($data))
							{
								$this->download_data('pm', $data);
							}
							else
							{
								$error[] = $this->user->lang['JVPPDMT_NOT_FOUND_PM'];
							}
						break;

						default:
							$this->download_data('privacy_data', $data_ary);
					}
				}

				if ($mode == 'ppdmt_download_pd')
				{
					return $error;
				}
			break;

			case 'settings':
				$this->page_title = 'UCP_JVPPDMT_SETTINGS';
				$this->tpl_name = '@jv_ppdmt/ucp_privacy_settings';

				$submit = $this->request->is_set_post('submit');
				$ppdmt = $this->phpbb_container->get('jv.ppdmt.class');

				add_form_key('jvppdmt_settings');

				if ($submit)
				{
					if (!check_form_key('jvppdmt_settings'))
					{
						$error[] = $this->user->lang['FORM_INVALID'];
					}

					if (!count($error))
					{
						$cookie_status = ($this->request->variable('cookie_status', false)) ? 1 : 0;
						$personal_data = (int) $this->request->variable('personal_data', 0);

						if (!$personal_data)
						{
							redirect(append_sid($this->root_path . 'ucp.' . $this->php_ext, 'i=-jv-ppdmt-ucp-delete_my_registration_module&amp;mode=my_acc_delete'));
						}
						else
						{
							$ppdmt->set_user_viewer_group();
						}

						if ($cookie_status != $this->user->data['user_cookie_status'])
						{
							if (!$cookie_status)
							{
								$ppdmt->delete_cookies();
							}
							else
							{
								$ppdmt->create_cookies();
							}

							$sql = 'UPDATE ' . USERS_TABLE . '
								SET user_cookie_status = ' . (($cookie_status) ? 1 : 0) . '
								WHERE user_id = ' . (int) $this->user->data['user_id'];
							$this->db->sql_query($sql);

							$this->log->add('user', $this->user->data['user_id'], $this->user->ip, 'LOG_JVPPDMT_PRIVACY_SETTINGS', false, array(
								'reportee_id' => $this->user->data['user_id']
							));
						}

						$back_link = append_sid($this->root_path . 'ucp.' . $this->php_ext, 'i=-jv-ppdmt-ucp-privacy_data_module&amp;mode=settings', true, $this->user->session_id);

						meta_refresh(5, $back_link);
						$message = $this->user->lang['PREFERENCES_UPDATED'] . '<br><br>' . sprintf($this->user->lang['RETURN_PAGE'], '<a href="' . $back_link . '">', '</a>');
						trigger_error($message);
					}
				}

				$this->template->assign_vars(array(
					'S_COOKIE_STATUS'					=> $this->user->data['user_cookie_status'],
					'S_VIEWR_GROUP_ENABLE'				=> $this->config['jvppdmt_viewer_group_enable'],
					'S_PD_ACCEPT'						=> !$ppdmt->user_viewer_group(),

					'L_TITLE'							=> $this->user->lang[$this->page_title],
					'L_JVPPDMT_COOKIE_SETTING_EXPLAIN'	=> $this->user->lang('JVPPDMT_COOKIE_SETTING_EXPLAIN', '<a href="' . append_sid($this->root_path . 'ucp.' . $this->php_ext, 'mode=privacy') . '">', '</a>')
				));
			break;
		}

		$this->template->assign_vars(array(
			'S_UCP_ACTION'	=> $this->u_action,
			'S_PD_ERROR'	=> (count($error)) ? true : false,

			'PD_ERROR'		=> (count($error)) ? implode('<br>', $error) : ''
		));
	}

	private function profile_fields_data()
	{
		$profile_data = array();
		$user_id = (int) $this->user->data['user_id'];

		$sql = 'SELECT l.*, f.*
			FROM ' . $this->profile_fields_language_table . ' l, ' . $this->profile_fields_table . ' f
			WHERE l.lang_id = ' . $this->user->get_iso_lang_id() . '
				AND l.field_id = f.field_id
			ORDER BY f.field_order';
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$profile_data[$row['field_ident']] = $row;
		}
		$this->db->sql_freeresult($result);

		$sql = 'SELECT *
			FROM ' . $this->profile_fields_data_table . '
			WHERE user_id = ' . $user_id;
		$result = $this->db->sql_query($sql);
		$field_data = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		$user_fields = array();

		foreach (array_keys($profile_data) as $used_ident)
		{
			$user_fields[$used_ident]['value'] = ($field_data['pf_' . $used_ident]) ? $field_data['pf_' . $used_ident] : '-';
			$user_fields[$used_ident]['data'] = $profile_data[$used_ident];
		}

		return $user_fields;
	}

	private function download_data($type, $data_ary)
	{
		switch($type)
		{
			case 'post':
				$title = 'JVPPDMT_FORUM_POSTS';
				$filename = 'forum_posts';
				$log_pr = 'POSTS';
			break;

			case 'pm':
				$title = 'PRIVATE_MESSAGES';
				$filename = 'private_messages';
				$log_pr = 'PMS';
			break;

			default:
				$title = 'UCP_JVPPDMT_PRIVACY_DATA';
				$filename = 'privacy_data';
				$log_pr = 'DATA';
		}

		$this->log->add('user', $this->user->data['user_id'], $this->user->ip, 'LOG_JVPPDMT_DOWNLOAD_PRIVACY_' . $log_pr, false, array(
			'reportee_id' => $this->user->data['user_id']
		));

		$filetype = $this->request->variable('filetype', 'txt');
		$mimetype = ($filetype == 'txt') ? 'text/plain' : 'text/csv';

		$data = $this->user->lang[$title] . $this->user->lang['COLON'] . "\n";

		foreach ($data_ary as $lang_key => $value)
		{
			$l = (isset($this->user->lang[$lang_key])) ? $this->user->lang[$lang_key] : ((isset($this->user->lang['JVPPDMT_' . $lang_key])) ? $this->user->lang['JVPPDMT_' . $lang_key] : $lang_key);
			$l = (is_numeric($l)) ? '' : $l . $this->user->lang['COLON'] . ' ';
			$data .= "\n" . $l . $value;
		}

		$len = strlen($data);

		header('Cache-Control: private, no-cache');
		header("Content-Type: {$mimetype}; name=\"{$filename}.{$filetype}\"");
		header("Content-Length: {$len}");
		header("Content-disposition: attachment; filename={$filename}.{$filetype}");

		echo $data;
		exit;
	}
}
