<?php
/**
*
* @package JV Privacy Policy and data management tool
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\ppdmt\core;

class ppdmt
{
	protected $db, $request, $config, $user, $root_path, $php_ext, $groups_table, $user_group_table;

	public function __construct($db, $request, $config, $user, $root_path, $php_ext, $groups_table, $user_group_table)
	{
		$this->db				= $db;
		$this->request			= $request;
		$this->config			= $config;
		$this->user				= $user;
		$this->root_path		= $root_path;
		$this->php_ext			= $php_ext;
		$this->groups_table		= $groups_table;
		$this->user_group_table	= $user_group_table;
	}

	public function user_viewer_group()
	{
		$group_id = 0;
		$viewer_group_id = $this->viewer_group_id();

		if ($viewer_group_id)
		{
			$sql = 'SELECT group_id
				FROM ' . $this->user_group_table . '
				WHERE user_id = ' . (int) $this->user->data['user_id'] . '
				AND group_id = ' . $viewer_group_id;
			$result = $this->db->sql_query($sql);
			$group_id = (int) $this->db->sql_fetchfield('group_id');
			$this->db->sql_freeresult($result);
		}

		return $group_id;
	}

	public function set_user_viewer_group()
	{
		$viewer_group_id = $this->viewer_group_id();

		if ($viewer_group_id)
		{
			$pd = (int) $this->request->variable('personal_data', 0);

			$sql = 'SELECT group_id
				FROM ' . $this->user_group_table . '
				WHERE user_id = ' . (int) $this->user->data['user_id'] . '
				AND group_id = ' . $viewer_group_id;
			$result = $this->db->sql_query($sql);
			$group_id = (int) $this->db->sql_fetchfield('group_id');
			$this->db->sql_freeresult($result);

			if ((($pd === 2 && !$group_id) || ($pd !== 2 && $group_id)))
			{
				if (!function_exists('group_user_add'))
				{
					include($this->root_path . 'includes/functions_user.' . $this->php_ext);
				}

				if ($pd === 2)
				{
					group_user_add($viewer_group_id, $this->user->data['user_id']);
				}
				else
				{
					group_user_del($viewer_group_id, $this->user->data['user_id']);
				}
			}
		}
	}

	public function viewer_group_id()
	{
		$sql = 'SELECT group_id
			FROM ' . $this->groups_table . "
			WHERE group_name = 'JVPPDMT_REGISTERED_VIEWER'
				AND group_type = " . GROUP_SPECIAL;
		$result = $this->db->sql_query($sql);
		$viewer_group_id = (int) $this->db->sql_fetchfield('group_id');
		$this->db->sql_freeresult($result);

		return $viewer_group_id;
	}

	public function delete_cookies()
	{
		$set_time = time() - 31536000;

		foreach ($this->request->variable_names(\phpbb\request\request_interface::COOKIE) as $cookie_name)
		{
			$cookie_name = str_replace($this->config['cookie_name'] . '_', '', $cookie_name);
			$this->set_cookie($cookie_name, '', $set_time, true, true);
		}

		foreach ($this->cookies() as $cookie_name)
		{
			$this->set_cookie($cookie_name, '', $set_time, true, true);
		}

		unset($set_time);
	}

	public function create_cookies()
	{
		$cookie_expire = time() + (($this->config['max_autologin_time']) ? 86400 * (int) $this->config['max_autologin_time'] : 31536000);
		$this->set_cookie('u', $this->user->data['user_id'], $cookie_expire);
		$this->set_cookie('k', '', $cookie_expire);
		$this->set_cookie('sid', $this->user->session_id, $cookie_expire);
		$this->set_cookie('cookie_status', 1, $cookie_expire);
		unset($cookie_expire);
	}

	public function set_cookie($name, $cookiedata, $cookietime = null, $httponly = true, $secure_ignore = false)
	{
		// If headers are already set, we just return
		if (headers_sent())
		{
			return;
		}

		$secure = ($this->config['cookie_secure'] && !$secure_ignore) ? true : false;
		$name_data = rawurlencode($this->config['cookie_name'] . '_' . $name) . '=' . rawurlencode($cookiedata);
		$expire = gmdate('D, d-M-Y H:i:s \\G\\M\\T', $cookietime);
		$domain = (!$this->config['cookie_domain'] || $this->config['cookie_domain'] == '127.0.0.1' || strpos($this->config['cookie_domain'], '.') === false) ? '' : '; domain=' . $this->config['cookie_domain'];

		header('Set-Cookie: ' . $name_data . (($cookietime) ? '; expires=' . $expire : '') . '; path=' . $this->config['cookie_path'] . $domain . (($secure) ? '; secure' : '') . ';' . (($httponly) ? ' HttpOnly' : ''), false);
	}

	public function cookies()
	{
		return array(
			'cookie_status',
			'k',
			'sid',
			'u',
			'track',
			'arcade_sid',
			'arcade_pd',
			'arcade_popup',
			'arcade_lighting',
			'arcade_info_block'
		);
	}
}
