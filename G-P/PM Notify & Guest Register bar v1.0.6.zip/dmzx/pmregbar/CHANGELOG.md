# PM Notify & Guest Register bar Changelog

## 1.0.6 - 2019-12-23
- Code update.
- Twig update.
