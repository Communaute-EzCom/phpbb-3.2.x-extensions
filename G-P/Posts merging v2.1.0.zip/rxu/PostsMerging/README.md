posts_merging
=============

Extension for phpBB 3.1 which allows to merge current post with previous if the former is by same author.
