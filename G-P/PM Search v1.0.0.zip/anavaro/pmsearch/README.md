PM Search
===========

PM search is phpBB 3.2 extension that allows users to search trough the PM archive in the board.

Features
--

  ACP
  
    - Enable PM Indexing
    - GLobaly allow PM search
    - Individual user permissions to allow PM Search
    - Indexing statistics
    - Build/delete Indexing statistics
  
  UCP
  
    - New UCP module for search
	
  Events
  
    - Register every PM for indexing
	- Remove PM removes index
    
    
Travis-ci state:

[![Build Status](https://travis-ci.org/satanasov/pmsearch.svg?branch=master)](https://travis-ci.org/lucifer4o/pmsearch)


##Donate
If you like my code - buy me a beer/coffee/license for PhpStorm :D

- BTC: 12afvCTp1dRrQdHaavzthZ1dNWMoi8eyc8
- ETH: 0x363abc8edf41ac89906b20e90cf7fdc71fe78cd5

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=XQ6USSXCSUM5W)
