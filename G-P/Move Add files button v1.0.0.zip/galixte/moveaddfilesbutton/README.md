# phpbb-ext-moveaddfilesbutton
Extension phpBB 3.1 & 3.2 - Move Add files button

Description : A phpBB extension to move the “Add files” button close (on the left) to the “Save draft”, “Preview” and “Submit” buttons on the posting page.
