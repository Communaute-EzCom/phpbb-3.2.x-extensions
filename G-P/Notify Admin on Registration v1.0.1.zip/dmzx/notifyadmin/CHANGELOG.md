## Changelog

### 1.0.1 - 2017-01-21

- Update code in listener.
- Update composer.json and service.yml.
- Added Changelog file.
- Added language file pt_br.

### 1.0.0 - 2015-05-02

- First release
