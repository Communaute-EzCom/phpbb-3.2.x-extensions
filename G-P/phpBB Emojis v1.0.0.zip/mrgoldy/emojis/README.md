# phpBB Emojis

## Installation

Copy the extension to phpBB/ext/mrgoldy/emojis

Go to "ACP" > "Customise" > "Extensions" and enable the "phpBB Emojis" extension.

## Theme

The theme setting can be found under "Post settings".
You can choose from four theme colours:
- Black
- Blue
- Green
- Red

## Credits

[jEmoji](http://franverona.com/jemoji/) by [Fran Verona](http://franverona.com/)

## License

[GPLv2](license.txt)
