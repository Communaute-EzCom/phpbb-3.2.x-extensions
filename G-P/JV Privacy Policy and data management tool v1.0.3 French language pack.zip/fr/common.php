<?php
/**
 *
 * JV Privacy Policy and data management tool. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 KillBill <https://jv-arcade.com>
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'G_JVPPDMT_REGISTERED_VIEWER'		=> 'Membres spectateurs',
	'JVPPDMT_INFO_NO_USE_COOKIE_GUEST'	=> 'Cher visiteur, il est important de rappeler, que nous n’enregistrons pas les cookies pour les utilisateurs non enregistrés (visiteurs). Pour en savoir davantage, merci de lire notre %sPolitique de vie privée%s.',
	'JVPPDMT_VIEWER_GROUP_INFO'			=> 'Cher membre, vous avez rejeté avec succès  l’enregistrement d’autres données personnelles, vous êtes à présent dans le groupe des « Membres spectateurs ». Ce groupe peut seulement voir les pages, mais ne peut pas participer en publiant de nouveaux messages, puisqu’il n’est pas possible d’effectuer une telle action sans l’enregistrer.<br>À tout moment, vous pouvez modifier vos paramètres d’enregistrement des données personnelles en cliquant sur  %sce lien%s.',
	'JVPPDMT_COOKIE_INFO'				=> 'Cher membre, puisque vous n’avez pas autorisé l’enregistrement des cookies sur votre appareil (PC, tablette, smartphone), plusieurs fonctionnalités du forum ne seront pas disponibles.<br>À tout moment, vous pouvez modifier vos paramètres d’enregistrement des données personnelles en cliquant sur %sce lien%s.',
	'UCP_PROFILE_JVPPDMT_MY_ACC_DELETE'	=> 'Suppression de votre compte',
	'UCP_JVPPDMT_PRIVACY_DATA'			=> 'Données personnelles',
	'UCP_JVPPDMT_SETTINGS'				=> 'Paramètres',

	'LOG_JVPPDMT_MY_ACC_DELETE'			=> '<strong>Compté supprimé</strong><br>» %s',
	'LOG_JVPPDMT_MY_ACC_POST_DELETE'	=> '<strong>Compte supprimé ainsi que ses messages.</strong><br>» %s',
));