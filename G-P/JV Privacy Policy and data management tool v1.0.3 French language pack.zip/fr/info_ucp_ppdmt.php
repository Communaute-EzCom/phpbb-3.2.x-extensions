<?php
/**
 *
 * JV Privacy Policy and data management tool. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 KillBill <https://jv-arcade.com>
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'JVPPDMT_MY_ACC_DELETE_CONFIRM'			=> 'Confirmer la suppression de votre compte',
	'JVPPDMT_MY_ACC_DELETE_CONFIRM_ERROR'	=> 'La suppression du compte n’a pas été confirmée !',
	'JVPPDMT_MY_ACC_DELETE_EXPLAIN'			=> 'Supprimer votre compte<br><em>Information : cette action est irréversible, le compte ne pourra être restauré !</em>',
	'JVPPDMT_MY_ACC_DELETE_FOUNDER_ERROR'	=> 'Les membres fondateurs du forum ne peuvent supprimer leur propre compte ! Cette action n’est possible que depuis le compte d’un autre membre fondateur.',
	'JVPPDMT_MY_ACC_DELETE_SUCCESS'			=> 'Compte supprimé avec succès !',
	'JVPPDMT_MY_ACC_POST_DELETE'			=> 'Supprimer vos messages',
	'JVPPDMT_MY_ACC_POST_DELETE_EXPLAIN'	=> 'Tous les messages publiés avec votre compte seront supprimés du forum',
	'JVPPDMT_REGISTRATION_IP'				=> 'Adresse IP',
	'JVPPDMT_REGISTRATION_DATE'				=> 'Date d’enregistrement sur le forum',
	'JVPPDMT_PRIVACY_POLICY_ACCEPT_DATE'	=> 'Date d’acception de la « Politique de vie privée »',
	'JVPPDMT_TERM_OF_USE_ACCEPT_DATE'		=> 'Date d’acception des « Conditions d’utilisation »',
	'JVPPDMT_COOKIE_SETTING'				=> 'Acceptation des cookies',
	'JVPPDMT_COOKIE_SETTING_EXPLAIN'		=> 'Permet d’accepter l’enregistrement des cookies du forum sur votre appareil. Pour davantage d’informations merci de consulter la « %sPolitique de vie privée%s ».<br><em>Information : si cette option est désactivée plusieurs fonctionnalités du forum ne fonctionneront pas.</em>',
	'JVPPDMT_PD_SETTING'					=> 'Enregistrement de vos données personnelles',
	'JVPPDMT_PD_SETTING_EXPLAIN'			=> 'Permet de définir la marche à suivre par le forum concernant vos données personnelles. Cependant, il est possible de revenir sur votre décision à n’importe quel moment.',
	'JVPPDMT_PD_ACCEPT'						=> 'Accepter l’utilisation et l’enregistrement de vos données personnelles',
	'JVPPDMT_PD_PARTIAL_ACCEPT'				=> 'Utiliser seulement vos données existantes et ne pas enregistrer de données supplémentaires',
	'JVPPDMT_PD_REJECT'						=> 'Refuser l’utilisation & l’enregistrement de vos données personnelles',
	'JVPPDMT_YOUR_POST_NUMBER'				=> 'Nombre de messages',
	'JVPPDMT_SELECT_DOWNLOAD_FORMAT'		=> 'Sélectionner le format d’exportation',
	'JVPPDMT_YOUR_PM_NUMBER'				=> 'Nombre de messages privés',
	'JVPPDMT_ID'							=> 'ID du message',
	'JVPPDMT_REL_IP'						=> 'Adresses IP liée',
	'JVPPDMT_CREATE_TIME'					=> 'Date de création',
	'JVPPDMT_FORUM_POSTS'					=> 'Messages du forum',
	'JVPPDMT_DOWNLOAD'						=> 'Télécharger',
	'JVPPDMT_NOT_FOUND_POST'				=> 'Vous n’avez pas de message.',
	'JVPPDMT_NOT_FOUND_PM'					=> 'Vous n’avez pas de message privé.',
	'JVPPDMT_SENT_PRIVATE_MESSAGES'			=> 'Messages privés envoyés',
));