<?php
/**
 *
 * JV Privacy Policy and data management tool. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 KillBill <https://jv-arcade.com>
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_CAT_JVPPDMT'							=> 'Outils de gestion de données et de la Politique de vie privée',
	'ACP_JVPPDMT_SETTINGS'						=> 'Paramètres',
	'ACP_JVPPDMT_GLOBAL_SETTINGS'				=> 'Paramètres des outils de gestion de données et de la « Politique de vie privée »',
	'ACP_JVPPDMT_GLOBAL_SETTINGS_EXPLAIN'		=> 'Depuis cette page, il est possible de d’autoriser les utilisateurs à consulter & accepter la « Politique de vie privée ». Qui plus est, il est possible d’autoriser les membres à supprimer leur compte.',
	'ACP_JVPPDMT_PRIVACY_POLICY_ENABLE'			=> 'Politique de vie privée',
	'ACP_JVPPDMT_PRIVACY_POLICY_ENABLE_EXPLAIN'	=> 'Permet aux utilisateurs de consulter et d’accepter la « Politique de vie privée ».',
	'ACP_JVPPDMT_CONTROLLER_NAME'				=> 'Nom du responsable de traitement',
	'ACP_JVPPDMT_CONTROLLER_NAME_EXPLAIN'		=> 'Permet de saisir le nom du responsable de traitement.',
	'ACP_JVPPDMT_CONTROLLER_PHONE'				=> 'Numéro de téléphone du responsable de traitement',
	'ACP_JVPPDMT_CONTROLLER_PHONE_EXPLAIN'		=> 'Permet de saisir le numéro de téléphone du responsable de traitement, information requise par le RGPD (GDPR) puisque deux moyens de contact doivent être fournis à l’utilisateur final, l’un est l’adresse e-mail de contact et la seconde le numéro de téléphone pour les contacts urgents.<br><em>Le numéro de téléphone doit être saisi précédé du préfixe du pays, tel que par exemple pour la France : +33…</em>',
	'ACP_JVPPDMT_RESET'							=> 'Réinitialiser l’acceptation de la « Politique de vie privée »',
	'ACP_JVPPDMT_RESET_EXPLAIN'					=> 'Permet de réinitialiser la « Politique de vie privée », cette action a pour conséquence d’obliger à nouveau la lecture et l’acceptation de la « Politique de vie privée » par tous les utilisateurs.',
	'ACP_JVPPDMT_RESET_CONFIRM'					=> 'Confirmer la réinitialisation de « Politique de vie privée ».',
	'ACP_JVPPDMT_RESET_SUCCESS'					=> 'La réinitialisation de « Politique de vie privée » a été effectué avec succès !',
	'ACP_JVPPDMT_TERM_OF_USE_RESET'				=> 'Réinitialiser l’acceptation des « Conditions d’utilisation »',
	'ACP_JVPPDMT_TERM_OF_USE_RESET_EXPLAIN'		=> 'Permet de réinitialiser les « Conditions d’utilisation », cette action a pour conséquence d’obliger à nouveau la lecture et l’acceptation des « Conditions d’utilisation » par tous les utilisateurs.',
	'ACP_JVPPDMT_TERM_OF_USE_RESET_CONFIRM'		=> 'Confirmer la réinitialisation des « Conditions d’utilisation ».',
	'ACP_JVPPDMT_TERM_OF_USE_RESET_SUCCESS'		=> 'La réinitialisation de « Conditions d’utilisation » a été effectué avec succès !',
	'ACP_JVPPDMT_USE_COOKIE_GUEST'				=> 'Utilisation des cookies pour les invités',
	'ACP_JVPPDMT_USE_COOKIE_GUEST_EXPLAIN'		=> 'Permet de bloquer l’utilisation des cookies pour les invités si cette paramètre est défini sur « Désactivé », ainsi l’acceptation de la « Politique de vie privée » ne sera pas requise pour les invités.',
	'ACP_JVPPDMT_VIEWER_GROUP'					=> 'Groupe des « Membres spectateurs »',
	'ACP_JVPPDMT_VIEWER_GROUP_EXPLAIN'			=> 'Permet de créer un nouveau groupe spécial nommé « <strong>Membres spectateurs</strong> ». Ce groupe permet de s’assurer des permissions des utilisateurs qui n’acceptent pas l’enregistrement d’autres données personnelles. Information : le responsable de traitement du forum se doit de prêter une attention toute particulière quant à la configuration des permissions de ce groupe. Notamment sur le fait de créer des rôles spécifiques à ce groupe. Un utilisateur dans ce groupe ne peut pas publier de nouveaux messages n’importe où sur le forum. Si de nouveaux forums sont créés par la suite, il sera nécessaire de mettre à jour les permissions de ce groupe. Dans ce cas-ci, il serait bon de définir les permissions de ce groupe de telle sorte que l’utilisateur ne puisse que consulter le dit forum sans pouvoir effectuer d’autres actions. Aussi, merci de s’assurer de toujours définir sur « <strong>Jamais</strong> » les différentes permissions des autres actions afin d’outrepasser ces dernières définies aux autres groupes. En laissant ce groupe désactivé, les utilisateurs, si ils n’acceptent pas l’enregistrement d’autres données personnelles, seront redirigés pour supprimer leur propre compte.',
	'ACP_JVPPDMT_VIEWER_GROUP_INFO'				=> 'Afficher les informations du groupe des « Membres spectateurs »',
	'ACP_JVPPDMT_VIEWER_GROUP_INFO_EXPLAIN'		=> 'Permet d’activer l’affichage des informations du groupe des « Membres spectateurs ». Ainsi, les membres de ce groupe pourront prendre connaissance de leur adhésion à ce groupe et des restrictions sur la publication de nouveaux messages. Qui plus est, cette information contient un lien qui les conduira aux paramètres de leurs données personnelles.',
	'ACP_JVPPDMT_COOIKE_INFO'					=> 'Afficher les informations des cookies',
	'ACP_JVPPDMT_COOIKE_INFO_EXPLAIN'			=> 'Permet d’activer l’affichage des informations sur les cookies. Ainsi, n’importe qui refusant l’enregistrement des cookies pourra prendre connaissance que plusieurs fonctionnalités du forum ne leurs seront pas disponibles. Qui plus est, cette information contient un lien qui les conduira aux paramètres de leurs données personnelles.',
	'ACP_JVPPDMT_YOUR_PP_FILE'					=> 'Nom du fichier de langue de la « Politique de vie privée » personnalisée',
	'ACP_JVPPDMT_YOUR_PP_FILE_EXPLAIN'			=> 'Permet de saisir le nom de son propre fichier de langue contenant la « Politique de vie privée » personnalisée. Cette démarche est nécessaire si l’on souhaite modifier le texte par défaut sans perdre son contenu original lors de la mise à jour des fichiers de cette extension. Pour ce faire, il est nécessaire d’envoyer son propre fichier dans le répertoire suivant : « ./ext/jv/ppdmt/language/XY/ », où « XY » correspond à votre répertoire de langue souhaitée. Ainsi, par exemple, si le nom du fichier saisi est : « fr », alors il sera nécessaire d’avoir le fichier suivant avec cette arborescence : « ./ext/jv/ppdmt/language/XY/fr.php ». Aussi, il est important de noter que les caractères de type : « %1$s … %5$s » dans le fichier de langue ne doivent pas être supprimés et que les variable de langue doivent demeurer identiques. La démarche la plus simple pour éviter de faire des erreurs consiste à copier le fichier original suivant : « privacy_policy.php », de le renommer, puis de modifier son contenu.',
	'ACP_JVPPDMT_LAST_RESET_DATE'				=> 'Date de la dernière réinitialisation : %s',

	'LOG_JVPPDMT_RESET'							=> '<strong>« Politique de vie privée » réinitialisée</strong>',
	'LOG_JVPPDMT_TERM_OF_USE_RESET'				=> '<strong>« Conditions d’utilisation » réinitialisés</strong>',
	'LOG_JVPPDMT_SETTINGS'						=> '<strong>Modification des paramètres des outils de gestion de données et de la « Politique de vie privée »</strong>',
	'LOG_JVPPDMT_PRIVACY_SETTINGS'				=> '<strong>Modification des paramètres de la « Politique de vie privée »</strong>',
	'LOG_JVPPDMT_DOWNLOAD_PRIVACY_DATA'			=> '<strong>Téléchargement des données personnelles</strong>',
	'LOG_JVPPDMT_DOWNLOAD_PRIVACY_POSTS'		=> '<strong>Téléchargement des messages du membre</strong>',
	'LOG_JVPPDMT_DOWNLOAD_PRIVACY_PMS'			=> '<strong>Téléchargement des messages privés du membre</strong>',
));
