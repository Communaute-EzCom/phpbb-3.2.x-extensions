# Modbreak BBcode

## Installation

* If you have a BBcode that uses '[mod]' -tags, remove it

* Copy the extension to phpBB/ext/ger/modbreak

* Go to "ACP" > "Customise" > "Extensions" and enable the "Modbreak" extension.

Note that there won't be a button created for this BBcode since it's moderator-only.

## Styling
Some default styling is added in the extension. Change or override the definitions for 
'p.bbc_mod_head' and '.bbc_mod_text' if desired.

# Support my development
I'm doing this in my spare time and I'm fueled by coffee. Buy me one through [paypal](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2YBSSF68LXBAN) :)

[GPLv2](license.txt)
