<?php
/**
 *
 * Google Search & Site Verification. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2017 HiFiKabin <https://phpbb.hifikabin.me.uk>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(

	'GOOGLE'							=> 'Google',
	'GOOGLE_SEARCH'						=> 'Recherche Google…',
	'SEARCH_GOOGLE'						=> 'Recherche Google',

	'GOOGLESEARCH_NAVBAR'				=> 'Barre de navigation',
	'GOOGLESEARCH_HEADER'				=> 'Entête',
	'GOOGLESEARCH_INDEX'				=> 'Index du forum',

	'ACP_GOOGLESEARCH_CONFIG'			=> 'Paramètres',
	'ACP_GOOGLESEARCH_CONFIG_EXPLAIN'	=> 'Sur cette page il est possible de configurer l’extension : « Google Search & Site Verification ».',

	'ACP_GOOGLESEARCH_CONFIG_SET'		=> 'Configuration',
	'GOOGLESEARCH_CONFIG_SAVED'			=> 'Les paramètres de la recherche Google ont été sauvegardés.',

	'GOOGLESEARCH_CUSTOM'				=> 'Recherche Google personnalisée',

	'GOOGLESEARCH_NOSCRIPT'				=> 'Le langage JavaScript doit être activé et Google doit être sur liste blanche avant de pouvoir consulter les résultats de la recherche Google personnalisée.',

	'GOOGLESEARCH_POSITION'				=> 'Emplacement de la recherche Google',
	'GOOGLESEARCH_POSITION_EXPLAIN'		=> 'Permet de sélectionner l’emplacement de la recherche Google.',


	'GOOGLESEARCH_CUSTOM_CODE'						=> 'Code personnalisé',
	'GOOGLESEARCH_CUSTOM_CODE_EXPLAIN'				=> 'Permet de remplacer le code par défaut par son propre code personnalisé « Search Engine ID ».',
	'GOOGLESEARCH_CUSTOM_CODE_PLACEHOLDER'			=> 'Code « Search Engine ID »',

	'GOOGLESEARCH_VERIFICATION_CODE'				=> 'Valider la propriété de son site',
	'GOOGLESEARCH_VERIFICATION_CODE_EXPLAIN'		=> 'Permet de saisir le code de la méthode « Balise HTML » pour valider la propriété de son site auprès du service « Google Search Console ».',
	'GOOGLESEARCH_VERIFICATION_CODE_PLACEHOLDER'	=> 'Code « Balise HTML »',

	'GOOGLESEARCH_REQUIRE_3.1.4'					=> 'Cette extension nécessite à minima phpBB 3.1.4 ou une version plus récente et ne fonctionne sous phpBB 3.2.0 ou une version plus récente.',
	'GOOGLESEARCH_REQUIRE_3.2.0'					=> 'Cette extension nécessite à minima phpBB 3.2.0 ou une version plus récente.',
));

