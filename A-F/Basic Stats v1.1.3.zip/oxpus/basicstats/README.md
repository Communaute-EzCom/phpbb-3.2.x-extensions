Basic Statistics
===================

# phpBB 3.1 Basic Statistics

Statistcs for daily, monthly and yearly data
Based on advanced statistics mods module for periodical stats

## Description

Statistcs for daily, monthly and yearly data
Based on advanced statistics mods module for periodical stats

## Installation

Upload the content of the folder "ext" into your forum folder /ext/.
After this enable the extension under "ACP" > "Customise" > "Extensions" > "Basic Stats"

## Collaborate

* For support visit the forum under http://phpbb3.oxpus.net
* To post an issue with this extention please use the bug tracker http://phpbb3.oxpus.net/downloads.php?view=bug_tracker

## License

[GPLv2](license.txt)
