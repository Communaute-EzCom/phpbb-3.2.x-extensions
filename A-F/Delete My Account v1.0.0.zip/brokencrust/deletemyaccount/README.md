# Delete My Account

## Installation

Copy the extension to phpBB/ext/brokencrust/deletemyaccount

Go to "ACP" > "Customise" > "Extensions" and enable the "Delete My Account" extension.

(optional) Set "Can delete posts when deleting account" to Yes for any user or group that you wish to have this option.

## License

[GPLv2](license.txt)
