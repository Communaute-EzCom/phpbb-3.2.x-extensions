<?php
/**
*
* info_acp_chat.php [French [Fr]] translation by Galixte (http://www.galixte.com)
* @package cBB Chat extension for the phpBB Forum Software package.
* @version v1.2.0 02/03/2019
*
* @copyright (c) 2017 CaniDev
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//


$lang = array_merge($lang, array(
	'ACP_CAT_CHAT'			=> 'Tchat',
	
	'ACP_CHAT_CONFIG'		=> 'Configuration principale',
	'ACP_CHAT_PAGES'		=> 'Gestion des pages',
	'ACP_CHAT_ROOMS'		=> 'Gestion des salons',
	'ACP_CHAT_TEXTS'		=> 'Textes et règles statiques',

	'LOG_CHAT_CONFIG'				=> '<strong>cBB Chat :</strong> Configuration principale modifiée',
	'LOG_CHAT_EXCLUSION_ADDED'		=> '<strong>cBB Chat :</strong> Exclusions ajoutées<br />» %s',
 	'LOG_CHAT_EXCLUSION_REMOVED'	=> '<strong>cBB Chat :</strong> Exclusions retirées<br />» %s',
	'LOG_CHAT_MESSAGE_MOVED'		=> '<strong>cBB Chat :</strong> Message déplacé de <em>%1$s</em> vers <em>%2$s</em><br />» %3$s',
	'LOG_CHAT_MESSAGES_MOVED'		=> array(
		1 => '<strong>cBB Chat :</strong> 1 message a été déplacé de <em>%1$s</em> vers <em>%2$s</em>',
		2 => '<strong>cBB Chat :</strong> %3$d messages ont été déplacés de <em>%1$s</em> vers <em>%2$s</em>',
	),
	'LOG_CHAT_MESSAGE_REMOVED'		=> '<strong>cBB Chat :</strong> Message supprimé <br />» <em>%s</em>',
	'LOG_CHAT_MESSAGES_REMOVED'		=> array(
		1 => '<strong>cBB Chat :</strong> 1 message a été supprimé de <em>%1$s</em>',
		2 => '<strong>cBB Chat :</strong> %2$d messages ont été supprimés de <em>%1$s</em>',
	),
	'LOG_CHAT_ROOM_REMOVED'			=> '<strong>cBB Chat :</strong> Salon <em>%s</em> supprimé ainsi que ses messages',
));
