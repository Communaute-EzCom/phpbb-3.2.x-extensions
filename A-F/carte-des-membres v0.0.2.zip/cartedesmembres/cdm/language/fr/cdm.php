<?php
/**
 *
 * Carte des membres. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 Lionel
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'CDM'						=> 'Carte',
	'CDM_URL'					=> 'http://www.carte-des-membres.com',
	'CDM_LINK_NAME'				=> 'Carte des Membres',
	'CDM_YES'					=> 'Paramètres configurés',
	'CDM_NO'					=> 'Paramètres non configurés',
	'CDM_HAVE_TO_LOGIN'			=> 'Pour indiquer sa localisation il est nécessaire de se connecter au forum',
	'CDM_NO_CONFIG'				=> 'La carte des membres n’est pas configurée. Merci de contacter les administrateurs du forum.',
	'ACP_CDM_ID'				=> 'CDM_ID',
	'ACP_CDM_CODE'				=> 'CDM_CODE',
	'ACP_CDM_NOM'				=> 'CDM_NOM',
	'ACP_CDM_TITLE'				=> 'Module carte des membres',
	'ACP_CDM'					=> 'Paramètres',
	'ACP_CDM_SETTING_SAVED'		=> 'Les paramètres ont été sauvegardés !',
	'ACP_CDM_EXPLAIN_CONFIG'	=> 'Se rendre sur la page « <a href="http://www.carte-des-membres.com/w/" target="_blank">Espace Webmaster</a> » du site Web « Carte des Membres » pour obtenir ses codes de configuration.',
	'CDM_LOC'					=> 'Emplacement sur la carte',
	'CDM_NO_LOC'				=> 'Emplacement non renseigné',
	'CDM_LOCA'					=> 'Position sur la carte',
	'CDM_LOCA_CLICK'			=> 'Voir l’emplacement sur la carte',
));
