<?php
/**
*
* cdm extension for the phpBB Forum Software package.
*
* @copyright (c) 2015 Lionel Retif
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace cartedesmembres\cdm\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	/**
	* define our constants
	**/
	const CDM_YES = 1;
	const CDM_NO = 0;

	/** @var \phpbb\request\request */
	protected $request;

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var string phpBB root path */
	protected $phpbb_root_path;

	/** @var string phpEx */
	protected $php_ext;

	/**
	* the path to the images directory
	*
	*@var string
	*/
	protected $cdm_path;

	public function __construct(
	  \phpbb\config\config $config,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user,
		$phpbb_root_path,
		$php_ext,
		$cdm_path)
	{
    $this->config = $config;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $php_ext;
		$this->images_path = $cdm_path;
	}

	/**
	* Assign functions defined in this class to event listeners in the core
	*
	* @return array
	* @static
	* @access public
	*/
	static public function getSubscribedEvents()
	{
		return array(
			'core.page_header'            => 'add_page_header_link',
			'core.viewtopic_cache_user_data'			=> 'viewtopic_cache_user_data',			
			'core.viewtopic_cache_guest_data'			=> 'viewtopic_cache_guest_data',
			'core.viewtopic_modify_post_row'			=> 'viewtopic_modify_post_row',	
            'core.memberlist_view_profile'				=> 'memberlist_view_profile',
		);
	}

   public function add_page_header_link($event)   {
      // language file here
      $this->user->add_lang_ext('cartedesmembres/cdm', 'cdm');

      $this->template->assign_vars(array(
         'CDM_URL'   => $this->user->lang['CDM_URL'].'/'.$this->user->data['user_lang'].'/'.$this->config['cdm_NOM'].'/',

      ));
   }
   
	public function viewtopic_cache_user_data($event)
	{
		$array = $event['user_cache_data'];
		$array['user_cdm'] = $event['row']['user_cdm'];
		$event['user_cache_data'] = $array;
	}   

	public function viewtopic_cache_guest_data($event)
	{
		$array = $event['user_cache_data'];
		$array['user_cdm'] = '';
		$event['user_cache_data'] = $array;
	}

	public function viewtopic_modify_post_row($event)
	{
		$this->user->add_lang_ext('cartedesmembres/cdm', 'cdm');
		$vars = array('user_cache',);
		$user_cache = $event['user_cache'];
		$row = $event['row'];
		$post_row = $event['post_row'];
		$poster_id =  $row['user_id'];
			$post_row = array_merge($post_row, array(
			'U_CDM_LOC'	=> ($user_cache[$poster_id]['user_cdm']) ? $poster_id : '',	
		));
		$event['post_row'] =$post_row;
        $event['U_CDM_LOC'] = true;
        $event['row'] = $row;
	}

public function memberlist_view_profile($event)
	{
		$this->user->add_lang_ext('cartedesmembres/cdm', 'cdm');
		$vars = array('user_cmd',);
		$vars = array('member',);
		$vars = array('data',);
		$row = $event['row'];
		$user_id = $row['user_id'];
		$member = $event['member'];
		$user_id = $member['user_id'];
		$this->template->assign_vars(array(
		'U_CDM_LOC'	=> ($member['user_cdm']) ? $member['user_id'] : '',
		));
		$event['row'] = $row;
	}
}

