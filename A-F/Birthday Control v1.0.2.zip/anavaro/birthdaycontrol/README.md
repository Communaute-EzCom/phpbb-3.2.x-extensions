birthdaycontrol
===============

PhpBB 3.2 Birth Day control extension

This little tool allows to control user registration by age. It allows user age to be shown in profile and topic rows.

![Build Status](https://travis-ci.org/satanasov/birthdaycontrol.svg?branch=master)

##Donate
If you like my code - buy me a beer/coffee/license for PhpStorm :D

- BTC: 12afvCTp1dRrQdHaavzthZ1dNWMoi8eyc8
- ETH: 0x363abc8edf41ac89906b20e90cf7fdc71fe78cd5

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=XQ6USSXCSUM5W)
