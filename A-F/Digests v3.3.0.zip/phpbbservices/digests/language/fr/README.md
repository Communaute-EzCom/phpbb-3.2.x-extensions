# digests-fr
Extension Digests pour phpBB
Traduction française : https://github.com/bonnaphil/digests-fr
Traduction tchèque : https://github.com/petr-hendl/phpBBDigests-cs/
Traduction allemande : https://github.com/Praggle/digests/releases
