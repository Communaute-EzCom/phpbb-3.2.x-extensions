# digests-es
Digests extension for phpBB - Spanish localization

Please check here for the main extension:

https://www.phpbb.com/customise/db/extension/digests_extension/

These files should be added inside this folder

/ext/phpbbservices/digests/language/es
