# etuogsc
Email To User On Group Status Change

Will send an email to users that are either added, removed, promoted or demoted in a user group within the phpBB bulletin board software version 3.2.x

[![Build Status](https://travis-ci.org/rmcgirr83/etuogsc.svg?branch=master)](https://travis-ci.org/rmcgirr83/etuogsc)
## Installation

### 1. clone
Clone (or download and move) the repository into the folder ext/rmcgirr83/etuogsc:

```
cd phpBB3
git clone https://github.com/rmcgirr83/etuogsc.git ext/rmcgirr83/etuogsc/
```

### 2. activate
Go to admin panel -> tab customise -> Manage extensions -> enable Email To User On Group Status Change