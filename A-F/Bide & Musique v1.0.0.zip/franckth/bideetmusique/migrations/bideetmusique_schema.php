<?php
/**
*
* @package phpBB Extension - Bide & Musique Extensions
* @copyright (c) 22016 franckth - http://www.graphogames.fr/Relax/
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\bideetmusique\migrations;

class bideetmusique_schema extends \phpbb\db\migration\migration
{
	public function update_data()
	{
		return array(

			// Add permissions
			array('permission.add', array('u_see_bideetmusique')),
			// Set permissions
			array('permission.permission_set', array('ADMINISTRATORS', 'u_see_bideetmusique', 'group')),
		);
	}

	public function revert_data()
	{
		return array(

			// Remove permissions
			array('permission.remove', array('u_see_bideetmusique')),
			// Unet permissions
			array('permission.permission_unset', array('ADMINISTRATORS', 'u_see_bideetmusique', 'group')),
		);
	}
}
