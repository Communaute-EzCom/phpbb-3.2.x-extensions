<?php
/**
*
* @package phpBB Extension - Bide & Musique Extensions
* @copyright (c) 2018 franckth - http://www.graphogames.fr/Relax/
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace franckth\bideetmusique\migrations;

class bideetmusique_data_ucp extends \phpbb\db\migration\migration
{
	public function update_schema()
	{
		return array(
			'add_columns' => array(
				$this->table_prefix . 'users' => array(
					'user_show_bideetmusique' => array('BOOL', 1),
				),
			),
		);
	}

	public function revert_schema()
	{
		return array(
			'drop_columns' => array(
				$this->table_prefix . 'users' => array(
					'user_show_bideetmusique',
				),
			),
		);
	}
}
