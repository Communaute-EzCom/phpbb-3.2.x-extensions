<?php



/**



*



* @package Board3 Portal v2.1+ - Board3 Discord V1.0.3



* @copyright (c) Board3 Group ( www.board3.de )



* @license http://opensource.org/licenses/gpl-license.php GNU Public License



* @Board3 Discord V1.0.2 by Talonos @ http://pretereo-stormrage.co.uk



*/







namespace talonos\b3pdiscord;



/**



* @package b3pdiscord



*/



class b3pdiscord extends \board3\portal\modules\module_base



{



	/**



	* Allowed columns: Just sum up your options (Exp: left + right = 10)



	* top		1



	* left		2



	* center	4



	* right		8



	* bottom	16



	*/



	public $columns = 10;







	/**



	* Default guildox



	*/



	public $name = 'PORTAL_DISCORD_TITLE';







	/**



	* Default module-image:



	* file must be in "{T_THEME_PATH}/images/portal/"



	*/



	public $image_src = '';







	/**



	* module-language file



	* file must be in "language/{$user->lang}/mods/portal/"



	*/



	    public $language = array(



        'vendor'    => 'talonos/b3pdiscord',



        'file'        => 'b3pdiscord',



    );



	







    /** @var \phpbb\config\config */



    protected $config;







    /** @var \phpbb\template\template */



    protected $template;



	/** @var helper */
	protected $helper;



    /**



     * Constructor for clock module



     *



     * @param \phpbb\config\config $config phpBB config



     * @param \phpbb\template\template $template phpBB template



     */



    public function __construct($config, $template, \phpbb\controller\helper $helper, \phpbb\collapsiblecategories\operator\operator $operator = null)



    {



        $this->config = $config;



        $this->template = $template;
		
		$this->helper = $helper;
		$this->operator = $operator;



    }















	public function get_template_side($module_id)



	{
	if ($this->operator !== null)
{
    $fid = 'discordhide_1'; // can be any unique string to identify your extension's collapsible element
    $this->template->assign_vars(array(
        'S_DISCORD_HIDDEN' => in_array($fid, $this->operator->get_user_categories()),
        'U_DISCORD_COLLAPSE_URL' => $this->helper->route('phpbb_collapsiblecategories_main_controller', array(
            'forum_id' => $fid,
            'hash' => generate_link_hash("collapsible_$fid")))
    ));
}


		$this->template->assign_vars(array(







			'DISCORD_SERVERID'			=> $this->config['board3_discord_serverid_' . $module_id],



			'DISCORD_SERVERUPDATE'			=> $this->config['board3_discord_serverupdate_' . $module_id],



			//display settings



			'S_DISPLAY_DISCORD_JOIN'	=> ($this->config['board3_discord_join_' . $module_id]) ? true : false,



			'S_DISPLAY_DISCORD_ALPHA'	=> ($this->config['board3_discord_alpha_' . $module_id]) ? true : false,



			'S_DISPLAY_DISCORD_SHOWALLUSER'	=> ($this->config['board3_discord_showalluser_' . $module_id]) ? true : false,



			'S_DISPLAY_DISCORD_SHOWGAMES'	=> ($this->config['board3_discord_showgames_' . $module_id]) ? true : false,



			'S_DISPLAY_DISCORD_USERSTATE'	=> ($this->config['board3_discord_userstate_' . $module_id]) ? true : false,



			'S_DISPLAY_DISCORD_SERVERTITLE'	=> ($this->config['board3_discord_servertitle_' . $module_id]) ? true : false,
			
			'DISCORD_HIDECHANNAMES'			=> $this->config['board3_discord_hidechannames_' . $module_id],
			


			'DISCORD_THEME'			=> $this->config['board3_discord_theme_' . $module_id],



			'S_DISCORD_THEME'            => true,







		));







		return '@talonos_b3pdiscord/talonos_b3pdiscord_side.html';



	}







public function get_template_acp($module_id)



   {



      return array(



         'title'   => 'PORTAL_DISCORD_TITLE',



		 'explain' => true,



         'vars'   => array(



            'legend1'                     => 'PORTAL_DISCORD_TITLE',



				'board3_discord_serverid_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_SERVERID',		'validate' => 'string',	'type' => 'text:20:20',	'explain' => true),



				// display settings
				
				'board3_discord_hidechannames_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_HIDECHANNAMES',		'validate' => 'string',	'type' => 'text:20:2000',	'explain' => true),
				


				'board3_discord_serverupdate_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_UPDATE',	'validate' => 'string', 'type' => 'text:2:2',	'explain' => true),



				'board3_discord_join_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_JOIN',	'validate' => 'string', 'type' => 'radio:yes_no',	'explain' => true),



				'board3_discord_servertitle_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_SERVERTITLE',	'validate' => 'string', 'type' => 'radio:yes_no',	'explain' => true),



				'board3_discord_alpha_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_ALPHA',	'validate' => 'string', 'type' => 'radio:yes_no',	'explain' => true),



				'board3_discord_showgames_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_SHOWGAMES',	'validate' => 'string', 'type' => 'radio:yes_no',	'explain' => true),



				'board3_discord_showalluser_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_SHOWALLUSERS',	'validate' => 'string', 'type' => 'radio:yes_no',	'explain' => true),



				'board3_discord_userstate_' . $module_id	=> array('lang' => 'PORTAL_DISCORD_USERSTATE',	'validate' => 'string', 'type' => 'radio:yes_no',	'explain' => true),



				'board3_discord_theme_' . $module_id			=> array('lang' => 'PORTAL_DISCORD_THEME',	'validate' => 'string', 	'type' => 'custom',	'explain' => true,	'method' => 'select_discordtheme', 'submit' => 'store_discordtheme'),



				)



      );



   }



	







	/**



	* API functions



	*/



	public function install($module_id)



	{



		$this->config->set('board3_discord_serverid_' . $module_id, '162300962784935937');



		$this->config->set('board3_discord_join_' . $module_id, 1);



		$this->config->set('board3_discord_alpha_' . $module_id, 1);



		$this->config->set('board3_discord_showalluser_' . $module_id, 1);



		$this->config->set('board3_discord_showgames_' . $module_id, 1);



		$this->config->set('board3_discord_userstate_' . $module_id, 1);



		$this->config->set('board3_discord_theme_' . $module_id, 'light');



		$this->config->set('board3_discord_servertitle_' . $module_id, 1);



		$this->config->set('board3_discord_serverupdate_' . $module_id, '10');
		
		$this->config->set('board3_discord_hidechan_' . $module_id, 0);
		
		$this->config->set('board3_discord_hidechannames_' . $module_id, 'AFK\', \'Raiding2');



		return true;



	}







	public function uninstall($module_id, $db)



	{







		$this->config->delete('board3_discord_serverid_' . $module_id);



		$this->config->delete('board3_discord_join_' . $module_id);



		$this->config->delete('board3_discord_alpha_' . $module_id);



		$this->config->delete('board3_discord_showalluser_' . $module_id);



		$this->config->delete('board3_discord_showgames_' . $module_id);



		$this->config->delete('board3_discord_userstate_' . $module_id);



		$this->config->delete('board3_discord_theme_' . $module_id);



		$this->config->delete('board3_discord_servertitle_' . $module_id);



		$this->config->delete('board3_discord_serverupdate_' . $module_id);
		
		$this->config->delete('board3_discord_hidechan_' . $module_id);
		
		$this->config->delete('board3_discord_hidechannames_' . $module_id);



		return true;



	}



	



	//style selector



	public function select_discordtheme($value, $key, $module_id)



	{



		global $db, $cache;



		



		$ext_options = '<select id="' . $key . '" name="' . $key . '[]">';



		



		if ($value == 'dark') {$ext_options .= '<option value="dark" selected="selected">Dark</option>';}



		else {$ext_options .= '<option value="dark">Dark</option>';}



		if ($value == 'light') {$ext_options .= '<option value="light" selected="selected">Light</option>';}



		else {$ext_options .= '<option value="light">Light</option>';}



		if ($value == 'custom') {$ext_options .= '<option value="custom" selected="selected">Custom</option>';}



		else {$ext_options .= '<option value="custom">Custom</option>';}



		if ($value == 'none') {$ext_options .= '<option value="none" selected="selected">No Style</option>';}



		else {$ext_options .= '<option value="none">No Style</option>';}







		



		$ext_options .= '</select>';



		



		return $ext_options;



	}



	



	public function store_discordtheme($key, $module_id)



	{



		global $db, $cache;



		



		// Get selected extensions



		$values = request_var($key, array(0 => ''));



		$valuess = implode(',', $values);



		set_config($key, $valuess);







	}



}



