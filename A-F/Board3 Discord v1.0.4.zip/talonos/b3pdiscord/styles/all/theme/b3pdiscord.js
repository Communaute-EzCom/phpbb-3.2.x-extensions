var b3pdiscordWidget = b3pdiscordWidget || (function(){
  var _b3pdiscordparams = {};

  return {
    init : function(b3pdiscordparams) {
      b3pdiscordparams.discordserverId = typeof b3pdiscordparams.discordserverId !== 'undefined' ? b3pdiscordparams.discordserverId : false;
      b3pdiscordparams.discordjoin = typeof b3pdiscordparams.discordjoin !== 'undefined' ? b3pdiscordparams.discordjoin : false;
      b3pdiscordparams.discordalphabetical = typeof b3pdiscordparams.discordalphabetical !== 'undefined' ? b3pdiscordparams.discordalphabetical : false;
      b3pdiscordparams.discordhideChannels = typeof b3pdiscordparams.discordhideChannels !== 'undefined' ? b3pdiscordparams.discordhideChannels : false;
      b3pdiscordparams.discordshowAllUsers = typeof b3pdiscordparams.discordshowAllUsers !== 'undefined' ? b3pdiscordparams.discordshowAllUsers : false;
	  b3pdiscordparams.discordshowGames = typeof b3pdiscordparams.discordshowGames !== 'undefined' ? b3pdiscordparams.discordshowGames : false;
      b3pdiscordparams.discordallUsersDefaultState = typeof b3pdiscordparams.discordallUsersDefaultState !== 'undefined' ? b3pdiscordparams.discordallUsersDefaultState : false;
	  b3pdiscordparams.discordshowjoin = typeof b3pdiscordparams.discordshowjoin !== 'undefined' ? b3pdiscordparams.discordshowjoin : false;
	  b3pdiscordparams.discordonline = typeof b3pdiscordparams.discordonline !== 'undefined' ? b3pdiscordparams.discordonline : false;
	  b3pdiscordparams.discordtitle = typeof b3pdiscordparams.discordtitle !== 'undefined' ? b3pdiscordparams.discordtitle : false;
      _b3pdiscordparams.discordserverId = b3pdiscordparams.discordserverId;
      _b3pdiscordparams.discordjoin = b3pdiscordparams.discordjoin;
      _b3pdiscordparams.discordalphabetical = b3pdiscordparams.discordalphabetical;
      _b3pdiscordparams.discordhideChannels = b3pdiscordparams.discordhideChannels;
      _b3pdiscordparams.discordshowAllUsers = b3pdiscordparams.discordshowAllUsers;
	  _b3pdiscordparams.discordshowGames = b3pdiscordparams.discordshowGames;
      _b3pdiscordparams.discordallUsersDefaultState = b3pdiscordparams.discordallUsersDefaultState;
	  _b3pdiscordparams.discordshowjoin = b3pdiscordparams.discordshowjoin;
	  _b3pdiscordparams.discordonline = b3pdiscordparams.discordonline;
	  _b3pdiscordparams.discordtitle = b3pdiscordparams.discordtitle;
    },
    render : function() {
      if (window.jQuery) {
        renderAll();
      } else {
        var s = document.createElement("script");
        s.type = "text/javascript";
        s.src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js";
        document.head.appendChild(s);

        s.onload = function () {
          renderAll();
        }
      }
      function renderAll() {
        var url = 'https://discordapp.com/api/servers/' + _b3pdiscordparams.discordserverId + '/embed.json';

        var xmlhttp = new XMLHttpRequest();

        xmlhttp.onreadystatechange = function() {
          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var data = JSON.parse(xmlhttp.responseText);
            renderWidget(data, _b3pdiscordparams);
            if (!_b3pdiscordparams.discordallUsersDefaultState) {
              $('.discord-allusers').toggle();
              $('.discord-allusers-toggle').html('&#9656; '+ _b3pdiscordparams.discordonline +'');
            }
            $('.discord-allusers-toggle').click(function(){
              $('.discord-allusers').toggle(100, function(){
                if ($('.discord-allusers').is(':visible')) {
                  $('.discord-allusers-toggle').html('&#9656; '+ _b3pdiscordparams.discordonline +'');
                } else {
                  $('.discord-allusers-toggle').html('&#9656; '+ _b3pdiscordparams.discordonline +'');
                }
              });
            });
          } else if (xmlhttp.readyState == 4 && xmlhttp.status == 404) {
            renderWidget('404', _b3pdiscordparams);
          } else if (xmlhttp.readyState == 4) {
            renderWidget(xmlhttp.status, _b3pdiscordparams);
          }
        }
        xmlhttp.open('GET', url, true);
        xmlhttp.send();

        function sortChannels(a, b) {
          if (a.position < b.position)
          return -1;
          if (a.position > b.position)
          return 1;
        }

        function renderChannel(name) {
          return '<li class="discord-channel">' + name + '</li><ul class="discord-userlist">';
        }
        function renderUser(member, channelId) {
          var gameName = '';
          if (member.game)
          gameName = ' - ' + member.game.name;
          if (member.channel_id == channelId) {
			if (member.status != 'online') {
				if (_b3pdiscordparams.discordshowGames ) {
					return '<li class="discord-user"><img src="' + member.avatar_url + '" class="discord-avatar"/><div class="discord-user-status discord-idle"></div>' + member.username + '<span class="gameplaying">' + gameName + '</span></li>';
				} else {
					return '<li class="discord-user"><img src="' + member.avatar_url + '" class="discord-avatar"/><div class="discord-user-status discord-online"></div>' + member.username + '</li>';
				}
			} else {
				if (_b3pdiscordparams.discordshowGames ) {
					return '<li class="discord-user"><img src="' + member.avatar_url + '" class="discord-avatar"/><div class="discord-user-status discord-online"></div>' + member.username + '<span class="gameplaying">' + gameName + '</span></li>';
				} else {
					return '<li class="discord-user"><img src="' + member.avatar_url + '" class="discord-avatar"/><div class="discord-user-status discord-online"></div>' + member.username + '</li>';
				}
			}
          } else {
            return '';
          }
        }

        function renderWidget(d, p) {
          var widgetElement = $('.b3pdiscord')[0];
          var defaultInnerHtml = '<ul class="discord-tree"></ul><p class="discord-users-online"></p><p class="discord-join"></p><div class="discord-fade"></div>';
          var formatted = '';
          var gameName = '';
          var treeElement, usersElement, discordjoinElement;
          var channels, users, hideChannel, hiddenChannels;

          if (_b3pdiscordparams.discordtitle !== false) {
            widgetElement.innerHTML = '<div class="discord-title"><h3>' + d.name + '</h3></div>' + defaultInnerHtml;
            treeElement = $('.discord-tree')[0];
          } else {
            widgetElement.innerHTML = defaultInnerHtml;
            treeElement = $('.discord-tree')[0];
            treeElement.style.marginTop = '0';
          }

          switch (d) {
            case '404': treeElement.innerHTML = '<span class="discord-error">Invalid Server ID</span>';
            break;
            case '522': treeElement.innerHTML = '<span class="discord-error">Discord is having issues.</span>';
            break;
          }

          if (!d) {
            treeElement.innerHTML = d;
            return;
          }

          usersElement = $('.discord-users-online')[0];
          discordjoinElement = $('.discord-join')[0];

          if(typeof(_b3pdiscordparams.discordhideChannels) !== 'boolean' || !_b3pdiscordparams.discordhideChannels) {
            if (!_b3pdiscordparams.discordalphabetical) {
              channels = [];
              hiddenChannels = [];
              for (var i = 0; i < d.channels.length; i++) {
                hideChannel = false;
                for (var j = 0; j < _b3pdiscordparams.discordhideChannels.length; j++) {
                    if (d.channels[i].name.indexOf(_b3pdiscordparams.discordhideChannels[j]) >= 0){
                    hideChannel = true;
                  }
                }
                if (!hideChannel) {
                  channels.push(d.channels[i]);
                } else {
                  hiddenChannels.push(d.channels[i].id);
                }
              }

            for (var i = 0; i < channels.length; i++) {
                formatted += renderChannel(channels[i].name);
                for (var j = 0; j < d.members.length; j++) {
                  formatted += renderUser(d.members[j], channels[i].id);
                }
			formatted += '</ul>';
              }
           } else {
             channels = [];
             hiddenChannels = [];
             for (var i = 0; i < d.channels.length; i++) {
               hideChannel = false;
               for (var j = 0; j < _b3pdiscordparams.discordhideChannels.length; j++) {
                 if (d.channels[i].name.indexOf(_b3pdiscordparams.discordhideChannels[j]) >= 0){
                   hideChannel = true;
                 }
               }
               if (!hideChannel) {
                 channels.push(d.channels[i]);
               } else {
                 hiddenChannels.push(d.channels[i].id);
               }
              }
			channels.sort(sortChannels);

              for (var i = 0; i < channels.length; i++) {
              formatted += renderChannel(channels[i].name);
              //formatted += renderChannel(channels[i].name);
              for (var j = 0; j < d.members.length; j++) {
                formatted += renderUser(d.members[j], channels[i].id);
                //  formatted += renderUser(d.members[j], channels[i].id);
                formatted += '</ul>';
              }
            }
          }

          if (_b3pdiscordparams.discordshowAllUsers) {
            formatted += '<li class="discord-channel discord-allusers-toggle">&#9662; ' + _b3pdiscordparams.discordonline + '</li><ul class="discord-userlist discord-allusers">';
            for (var i = 0; i < d.members.length; i++) {
              if (!d.members[i].channel_id || $.inArray(d.members[i].channel_id, hiddenChannels) >= 0) {
                formatted += renderUser(d.members[i], d.members[i].channel_id);
              }
            }
            formatted += '</ul>';
          }

          var discordjoin = '';
          if (d.instant_invite != 'null')
          discordjoin = '<a href="' + d.instant_invite + '" target="_blank">' + _b3pdiscordparams.discordshowjoin + '</a>';

          treeElement.innerHTML = formatted;
          usersElement.innerHTML = '' + _b3pdiscordparams.discordonline + ': ' + d.members.length;
		  //d.instant_invite = null;
          if (_b3pdiscordparams.discordjoin && d.instant_invite != null) {
            discordjoinElement.innerHTML = discordjoin;
          } else {
            discordjoinElement.style.display = 'none';
          }
        }
      }
    }
  }};
}());