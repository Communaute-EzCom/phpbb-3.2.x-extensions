<?php
/**
 *
 * Delete My Account. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 BrokenCrust <https://brokencrust.com/>
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(

	'DELETE_MY_ACCOUNT' => 'Suppression du compte',
	'DELETE_YOUR_ACCOUNT' => 'Supprimer son compte',
	'DELETE_MY_ACCOUNT_TEXT' => 'Depuis cette page il est possible de supprimer son compte utilisateur. Une fois cette action effectuée, toutes les données personnelles et privées seront supprimées du forum et il ne sera plus possible d’utiliser ce compte pour se connecter.',
	'REALY_DELETE' => 'Confirmation de la suppression de son compte utilisateur.',
	'UNDERSTAND_DELETE' => 'Confirmation d’avoir pris connaissance que cette action irréversible.',
	'DELETE_MY_POSTS' => 'Confirmation de la suppression des messages de son compte utilisateur. Si cette option est décochée les messages seront anonymisés, autrement dit, attribués au compte utilisateur « Invité ».',
	'ENTER_PASSWORD' => 'Saisie du mot de passe du compte utilisateur',
	'ENTER_PASSWORD_HERE' => 'Merci de saisir son mot de passe ici…',
	'DELETED_USER' => 'Membre supprimé %s',
	'DELETE_FINAL' => 'Confirmation finale',
	'DELETE_FINAL_CONFIRM' => '<p>Merci d’avoir été un membre de ce forum. L’équipe du forum regrette votre départ.</p><p>La demande de suppression a été validée. Ceci est la confirmation finale. Confirmer la suppression définitive de son compte utilisateur.</p>',

	'LOG_USER_DELETED' => 'Le membre %s (ayant l’ID %s) a supprimé son propre compte utilisateur. ',
	'LOG_POST_REMOVED' => 'Ses messages ont été supprimés.',
	'LOG_POST_RETAINED' => 'Ses messages ont été conservés.',
	'LOG_NO_POSTS' => 'Il n’avait aucun message.',

	'REALLY_ERROR' => 'Il est nécessaire de cocher la case : « Confirmation de la suppression de son compte utilisateur ».',
	'UNDERSTAND_ERROR' => 'Il est nécessaire de cocher la case : « Confirmation d’avoir pris connaissance que cette action irréversible ».',
	'PASSWORD_ERROR' => 'Le mot de passe saisit est incorrect.',
	'FOUNDER_ERROR' => 'Les membres « Fondateur » ne peuvent pas supprimer leur propre compte utilisateur.',
	'BAD_FORM_KEY_ERROR' => 'La page de ce formulaire n’a pu être validée. Merci de réitérer votre demande.',
	'GOODBYE_ERROR' => 'Le compte utilisateur a été supprimé.'

));
