AddonForThanksForPosts
======================
[![Build Status](https://travis-ci.org/alg5/addonforthanksforposts.svg?branch=dev_3.2.x)](https://travis-ci.org/alg5/addonforthanksforposts)

This extension is add-on for extension: <a href="https://www.phpbb.com/community/viewtopic.php?f=456&t=2259046&p=13714471#p13714471]">Thanks for posts</a> and must be used only if the main extension installed and turned on

Adds ajax functionality to main extension  to update result of set/delete likes without reloading the page

Supported languages:
- Englis
- French
- Russian