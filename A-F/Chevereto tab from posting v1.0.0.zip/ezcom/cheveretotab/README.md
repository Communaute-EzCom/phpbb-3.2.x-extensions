# cheveretotab
This extention add Chevereto service on phpBB 3.1.x, 3.2.x & 3.3.x with a new tab on posting page.

## Quick Install
You can install this on the latest release of phpBB 3.1.3 by following the steps below:

1. [Download the latest release](http://git.ezcom-fr.com).
2. Unzip the downloaded release, and change the name of the folder to`cheveretotab`.
3. In the `ext/` directory of your phpBB board, create a new directory named `fbrcrsi` (if it does not already exist).
4. Copy the `cheveretotab` folder to `ext/ezcom/` directory of your phpBB board.
5. Navigate in the ACP to `Customise -> Manage extensions`.
6. Look for `Chevereto tab from posting` under the Disabled Extensions list, and click its `Enable` link.


Remember to purge cache each time you edit the templates after the installation

## Uninstall

1. Navigate in the ACP to `Customise -> Extension Management -> Extensions`.
2. Look for `Chevereto tab from posting` under the Enabled Extensions list, and click its `Disable` link.
3. To permanently uninstall, click `Delete Data` and then delete the `/ext/ezcom/cheveretotab` directory.

## Version History

- 2020.04.04

 - 1.0.0 : Initial release, stable version.
