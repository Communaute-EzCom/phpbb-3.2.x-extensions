# Best Answer

## Installation

Copy the extension to phpBB/ext/kinerity/bestanswer

Go to "ACP" > "Customise" > "Extensions" and enable the "Best Answer" extension.

## License

[GPLv2](license.txt)
