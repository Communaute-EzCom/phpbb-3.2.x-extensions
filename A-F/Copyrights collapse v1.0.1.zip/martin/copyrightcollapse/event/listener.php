<?php
/**
*
* @package phpBB Extension - Copyrights Collapse
* @copyright (c) 2019 martin - https://www.martins-phpbb.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace martin\copyrightcollapse\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	/** @var \phpbb\config\config */
	protected $config;

	/* @var \phpbb\template\template */
	protected $template;

	/* @var \phpbb\user */
	protected $user;

	/**
	* Constructor
	*
	* @param \phpbb\config\config		$config		Config object
	* @param \phpbb\template			$template	Template object
	* @param \phpbb\user				$user		User object
	*/
	public function __construct(\phpbb\config\config $config, \phpbb\template\template $template, \phpbb\user $user, \phpbb\collapsiblecategories\operator\operator $operator = null)
	{
		$this->config		= $config;
		$this->template		= $template;
		$this->user		= $user;
		$this->operator		= $operator;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'			=> 'load_language_on_setup',
			'core.page_header'			=> 'collapse',
		);
	}

	public function load_language_on_setup($event)
	{	
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'martin/copyrightcollapse',
			'lang_set' => 'common',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}

	public function collapse($event)
	{
		if ($this->operator !== null)
		{
			$fid = 'copyrightcollapse'; // can be any unique string to identify your extension's collapsible element
			$this->template->assign_vars(array(
				'S_COPYRIGHTCOLLAPSE_HIDDEN' => $this->operator->is_collapsed($fid),
				'U_COPYRIGHTCOLLAPSE_COLLAPSE_URL' => $this->operator->get_collapsible_link($fid),
			));
		}
	}
}
