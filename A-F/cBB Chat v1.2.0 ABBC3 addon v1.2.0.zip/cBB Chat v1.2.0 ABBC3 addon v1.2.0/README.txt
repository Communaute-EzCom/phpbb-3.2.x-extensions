# cBB Chat Extension (ABBC3 AddOn)

## Quick Install

1. Upload the content of the 'upload' directory to the 'ext' directory of your forum.
2. With your browser, enter in Administration Panel and clear the cache.

## License
[GNU General Public License v2](https://opensource.org/licenses/GPL-2.0)
