<?php
/*
* @package cBB Chat
* @version v1.2.0 09/04/2019
*
* @copyright (c) 2019 CaniDev
* @license https://opensource.org/licenses/gpl-license.php GNU Public License
*/

namespace canidev\core\compatibility\chat;

// @ignore
if(!defined('IN_PHPBB'))
{
	exit;
}

class abbc3 extends \canidev\core\compatibility\base
{
	const BBVIDEO_DEFAULT = 'youtube';

	public $name = 'vse/abbc3';

	private $abbc3_icon_path = 'ext/vse/abbc3/images/icons/';
	
	protected $cache;
	protected $template;
	protected $textformatter;
	
	public function __construct($container)
	{
		$this->cache			= $container->get('cache.driver');
		$this->container 		= $container;
		$this->template			= $container->get('template');
		$this->textformatter 	= $container->get('text_formatter.s9e.factory');
	}
	
	public function is_runnable()
	{
		return $this->container->get('ext.manager')->is_enabled($this->name);
	}
	
	public function core_events()
	{
		return array(
			'chat.custom_bbcodes_modify_sql'	=> 'on_bbcodes_modify_sql',
			'chat.generate_bbcodes'				=> 'on_generate_bbcodes',
			'chat.after_action_run'				=> 'after_action_run',
		);
	}
	
	public function on_bbcodes_modify_sql($event)
	{
		$sql_ary = $event['sql_ary'];
		$sql_ary['SELECT'] .= ', b.bbcode_group';
		$sql_ary['ORDER_BY'] = 'b.bbcode_order, b.bbcode_id';
		$event['sql_ary'] = $sql_ary;
	}
	
	public function on_generate_bbcodes($event)
	{
		$chat = $this->container->get('canidev.chat.chat');

		if($event['template_key'] == 'chat_custom_tags')
		{
			$item 		= $event['item_ary'];
			$imagename	= $this->abbc3_icon_path . strtolower($event['row']['bbcode_tag']) . '.gif';

			if(file_exists($chat->phpbb_root_path . $imagename))
			{
				$item['S_IMAGE'] = $chat->web_path . $imagename;
				$event['item_ary'] = $item;
			}
			
			$event['template_key'] = 'chat_abbc3_tags';
		}
	}
	
	public function after_action_run($event)
	{
		if($event['action'] != 'abbc3')
		{
			return;
		}

		$bbcode_id = strtolower($this->container->get('request')->variable('bbcode', ''));
			
		if($bbcode_id == 'bbvideo')
		{
			$this->generate_bbvideo_wizard();
		}
		
		$this->template->assign_var('S_ABBC3_BBCODE', $bbcode_id);
		
		$event['template_filename'] = '@canidev_chat/abbc3_wizards.html';
	}
	
	protected function generate_bbvideo_wizard()
	{
		if(($bbvideo_sites = $this->cache->get('bbvideo_sites')) === false)
		{
			$configurator = $this->textformatter->get_configurator();
			foreach ($configurator->MediaEmbed->defaultSites as $siteId => $siteConfig)
			{
				// check that siteID is not already a custom bbcode and that it exists in MediaEmbed
				if (!isset($configurator->BBCodes[$siteId]) && $configurator->tags->exists($siteId))
				{
					$bbvideo_sites[$siteId] = isset($siteConfig['example']) ? current((array) $siteConfig['example']) : '';
				}
			}

			$this->cache->put('bbvideo_sites', $bbvideo_sites);
		}

		$this->template->assign_vars(array(
			'ABBC3_BBVIDEO_SITES'	=> $bbvideo_sites,
			'ABBC3_BBVIDEO_LINK_EX'	=> isset($bbvideo_sites[self::BBVIDEO_DEFAULT]) ? $bbvideo_sites[self::BBVIDEO_DEFAULT] : '',
			'ABBC3_BBVIDEO_DEFAULT'	=> self::BBVIDEO_DEFAULT,
		));
	}

	public function frontend_js_events()
	{
		return array(
			'chat.onInit'		=> "function(service) {
				$('#abbc3-font-select').change(function() {
					var font = $(this).val();
					
					if(font)
					{
						service.insertBBcode('font=' + font, true);
						$(this).children('option').eq(0).prop('selected', true);
					}
				});
			}",

			'chat.beforeEventDispatch'	=> "function(e) {
				if(e.action != 'bbcode')
				{
					return;
				}
				
				var bbcode = $(e.originalEvent.currentTarget).data('bbcode'),
					bbcodeId;
				
				switch(bbcode)
				{
					case 'align':
						bbcodeId = 'align=center';
					break;

					case 'float':
					case 'marq':
						bbcodeId = bbcode + '=left';
					break;

					case 'dir':
						bbcodeId = 'dir=rtl';
					break;

					case 'mod':
						bbcodeId = 'mod=" . $this->container->get('user')->data['username'] . "';
					break;

					case 'highlight':
						bbcodeId = 'highlight=yellow';
					break;

					case 'glow':
						bbcodeId = 'glow=red';
					break;

					case 'shadow':
					case 'dropshadow':
					case 'blur':
						bbcodeId = bbcode + '=blue';
					break;

					case 'BBvideo':
					case 'bbvideo':
					case 'url':
						e.service.send('abbc3', {bbcode: bbcode}, function(response) {
							e.service.dialog({
								content: response.htmlContent,
								width: 500,
								onOpen: function(data) {
									$(this).find('#bbvideo_wizard_sites').change(function() {
										data.ui('#bbvideo_wizard_example').val($(this).val());
									});
								},
								onSubmit: function(xdata) {
									var text = '';

									switch(bbcode)
									{
										case 'url':
											var link 		= xdata.bbcode_wizard_link,
												description = xdata.bbcode_wizard_description;
											
											text = '[' + bbcode + ((description.length) ? '=' + link : '') + ']' + ((description.length) ? description : link) + '[/' + bbcode + ']';
										break;

										case 'BBvideo':
										case 'bbvideo':
											text = '[bbvideo]' + xdata.bbvideo_wizard_link + '[/bbvideo]';
										break;
									}
									
									var msg 	= e.service.dom.find('textarea:first'),
										caret	= msg.cbbCaret();
									
									caret.start += text.length;
									caret.end	= caret.start;
									
									e.service.insertText(msg, text, caret);
								}
							});
						});
						
						e.preventDefault();

					default:
						return;
				}

				e.service.insertBBcode(bbcodeId, true);
				e.preventDefault();
			}"
		);
	}
}