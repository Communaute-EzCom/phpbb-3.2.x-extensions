[![Build Status](https://travis-ci.org/david63/david63-announceonindex.svg?branch=3.2)](https://travis-ci.org/david63/david63-announceonindex)

# david63-announceonindex
Displays announcements on the index page
