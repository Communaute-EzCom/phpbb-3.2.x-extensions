<?php
/**
 *
 * Board3 Discord. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2017 Talonos <http://pretereo-stormrage.co.uk>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'PORTAL_DISCORD_TITLE'				=> 'Bloc Discord',
	'PORTAL_DISCORD_TITLE_EXP'			=> 'Depuis cette page il est possible de modifier les paramètres du bloc Discord. Version : <br>1.0.x par Talonos @ <a target="_blank" href="http://pretereo-stormrage.co.uk/">Pretereo-Stormrage</a>.',

	'PORTAL_DISCORD_SERVERID'			=> 'ID du serveur Discord',
	'PORTAL_DISCORD_SERVERID_EXP'		=> 'Permet de saisir l’ID du serveur pour lequel le bloc va afficher les informations.',

	'PORTAL_DISCORD_JOIN'				=> 'Afficher le bouton rejoindre',
	'PORTAL_DISCORD_JOIN_EXP'			=> 'Permet d’afficher le bouton « Rejoindre le serveur » dans le bloc.',

	'PORTAL_DISCORD_ALPHA'				=> 'Trier les salons alphabétiquement',
	'PORTAL_DISCORD_ALPHA_EXP'			=> 'Permet d’afficher les salons dans l’ordre alphabétique.',

	'PORTAL_DISCORD_SHOWALLUSERS'		=> 'Afficher tous les utilisateurs',
	'PORTAL_DISCORD_SHOWALLUSERS_EXP'	=> 'Permet d’afficher tous les utilisateurs actuellement connectés au serveur Discord. Sur « Non » le bloque masque les utilisateurs qui ne sont pas présents dans un salon.',

	'PORTAL_DISCORD_SHOWGAMES'			=> 'Afficher les jeux en cours d’utilisation par les utilisateurs',
	'PORTAL_DISCORD_SHOWGAMES_EXP'		=> 'Permet d’afficher les jeux en cours d’utilisation par les utilisateurs connectés au serveur Discord. Sur « Oui » le bloc ne devrait pas afficher certaines thématiques de jeux.',

	'PORTAL_DISCORD_USERSTATE'			=> 'Étendre la liste des utilisateurs connectés',
	'PORTAL_DISCORD_USERSTATE_EXP'		=> 'Permet d’afficher la liste complète des utilisateurs connectés au serveur Discord. Fonctionne uniquement si l’option « Afficher tous les utilisateurs » est activée.',

	'PORTAL_DISCORD_THEME'				=> 'Style d’affichage',
	'PORTAL_DISCORD_THEME_EXP'			=> 'Permet de sélectionner le style parmi 4 thématiques. Sur « No style » le bloc hérite du style par défaut du forum.',

	'PORTAL_DISCORD_SERVERTITLE'		=> 'Afficher le nom du serveur',
	'PORTAL_DISCORD_SERVERTITLE_EXP'	=> 'Permet d’afficher le nom du serveur Discord comme titre dans le bloc.',

	'PORTAL_DISCORD_ONLINE'				=> 'Utilisateurs en ligne',
	'PORTAL_DISCORD_JOINSERVER'			=> 'Rejoindre le serveur',

	'PORTAL_DISCORD_UPDATE'				=> 'Fréquence d’actualisation des informations',
	'PORTAL_DISCORD_UPDATE_EXP'			=> 'Permet de saisir la fréquence d’actualisation en minutes des informations du serveur affichées dans le bloc. La valeur doit être comprise entre 1 et 99. Le bloc est mis à jour lors de chaque rechargement de la page.',

	'PORTAL_DISCORD_HIDECHANNAMES'		=> 'Masquer les salons',
	'PORTAL_DISCORD_HIDECHANNAMES_EXP'	=> 'Permet de masquer certains salons.<br>Pour masquer certains salons, saisir de cette manière : <strong>Accueil\', \'Règles\', \'Jeux\', \'Divers</strong>.<br>Pour désactiver cette fonctionnalité, saisir : <strong>false</strong>.<br>Pour masquer tous les salons, laisser ce champ vide.',
));

