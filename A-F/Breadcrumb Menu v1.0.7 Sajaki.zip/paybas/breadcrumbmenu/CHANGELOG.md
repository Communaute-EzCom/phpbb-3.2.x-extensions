### Changelog 

- 1.0.7 (22/01/2017)
  - [FIX] merged with changes from CDB version by david63
  - [FIX] updated jqueryui reference

- 1.0.6 (11/06/2017)
  - [FIX] CDB version by david63
  - [CHG] From version 1.0.6 an event "paybas_breadcumbmenu_append" has been added that will allow other extensions to use this extension and as a consequence the hardcoded extensions for boardrules, pages that were in previous versions were removed.
  
