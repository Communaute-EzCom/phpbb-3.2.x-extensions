# Forum Legend

## Installation

Copy the extension to phpBB/ext/spaceace/forumlegend

Go to "ACP" > "Customise" > "Extensions" and enable the "Forum Legend" extension.

## License

[GPLv2](license.txt)
