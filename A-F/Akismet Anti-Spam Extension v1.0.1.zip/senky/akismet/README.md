# Akismet

This is the repository for the development of the Akismet extension.

[![Build Status](https://travis-ci.org/senky/phpbb-ext-akismet.png)](https://travis-ci.org/senky/phpbb-ext-akismet)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/senky/phpbb-ext-akismet/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/senky/phpbb-ext-akismet/?branch=master)
[![Code Coverage](https://scrutinizer-ci.com/g/senky/phpbb-ext-akismet/badges/coverage.png?b=master)](https://scrutinizer-ci.com/g/senky/phpbb-ext-akismet/?branch=master)

The Akismet extension allows to run phpBB posts through the Akismet anti-spam service.

🐞 [Report bugs](https://github.com/senky/phpbb-ext-akismet/issues) to the Issue Tracker.

## License

[GPLv2](license.txt)
