<?php

/**
 *
 * @package phpBB Extension - Edit Only Your Unanswered Posts
 * @copyright (c) 2016 kasimi - https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\editonlyyourunansweredposts\event;

use phpbb\auth\auth;
use phpbb\request\request_interface;
use phpbb\user;
use Symfony\Component\EventDispatcher\Event;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/* @var user */
	protected $user;

	/** @var auth */
	protected $auth;

	/** @var request_interface */
	protected $request;

	/**
 	 * Constructor
	 *
	 * @param user				$user
	 * @param auth				$auth
	 * @param request_interface	$request
	 */
	public function __construct(
		user $user,
		auth $auth,
		request_interface $request
	)
	{
		$this->user		= $user;
		$this->auth		= $auth;
		$this->request	= $request;
	}

	/**
	 * Register hooks
	 */
	static public function getSubscribedEvents()
	{
		return array(
			'core.viewtopic_modify_post_row'	=> 'modify_post_row',
			'core.modify_posting_auth'			=> 'check_edit_auth',
			'core.permissions'					=> 'acp_permissions',
		);
	}

	/**
	 * Event: core.viewtopic_modify_post_row
	 *
	 * @param Event $event
	 */
	public function modify_post_row($event)
	{
		$post_row = $event['post_row'];
		$is_unanswered_post = empty($post_row['U_NEXT_POST_ID']);
		$forum_id = $event['topic_data']['forum_id'];

		if ($post_row['U_EDIT'] && !$this->can_edit_post($is_unanswered_post, $forum_id))
		{
			$post_row['U_EDIT'] = '';
			$event['post_row'] = $post_row;
		}
	}

	/**
	 * Event: core.modify_posting_auth
	 *
	 * @param Event $event
	 */
	public function check_edit_auth($event)
	{
		if ($event['mode'] == 'edit')
		{
			$is_unanswered_post = $this->request->variable('p', 0) == $event['post_data']['topic_last_post_id'];
			$forum_id = $event['post_data']['forum_id'];

			if (!$this->can_edit_post($is_unanswered_post, $forum_id))
			{
				$this->user->add_lang_ext('kasimi/editonlyyourunansweredposts', 'common');
				trigger_error($this->user->lang('EDIT_ONLY_YOUR_UNANSWERED_POSTS_ERROR'));
			}
		}
	}

	/**
	 * @param bool $is_unanswered_post
	 * @param int $forum_id
	 * @return bool
	 */
	protected function can_edit_post($is_unanswered_post, $forum_id)
	{
		return $is_unanswered_post || $this->auth->acl_get('m_edit', $forum_id) || !$this->auth->acl_get('f_edit_only_your_unanswered_posts', $forum_id);
	}

	/**
	 * Event: core.permissions
	 *
	 * @param Event $event
	 */
	public function acp_permissions($event)
	{
		$event['permissions'] = array_merge($event['permissions'], array(
			'f_edit_only_your_unanswered_posts' => array(
				'lang'	=> 'ACL_F_EDIT_ONLY_YOUR_UNANSWERED_POSTS',
				'cat'	=> 'post',
			),
		));
	}
}
