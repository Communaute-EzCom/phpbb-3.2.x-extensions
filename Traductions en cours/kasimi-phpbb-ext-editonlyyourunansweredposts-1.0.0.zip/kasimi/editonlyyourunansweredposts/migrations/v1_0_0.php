<?php

/**
 *
 * @package phpBB Extension - Edit Only Your Unanswered Posts
 * @copyright (c) 2016 kasimi - https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\editonlyyourunansweredposts\migrations;

use \phpbb\db\migration\migration;

class v1_0_0 extends migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v31x\v3110rc1');
	}

	public function update_data()
	{
		return array(
			array('permission.add', array('f_edit_only_your_unanswered_posts', false, 'f_edit_last_post_only')),
		);
	}
}
