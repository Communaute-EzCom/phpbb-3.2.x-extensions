<?php

/**
*
* @package PMRead
* @copyright (c) 2014 DeaDRoMeO ; phpbbworld.ru
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'PMR'					=> '«PMRead»',
	'PMR_CONFIG'						=> 'Show private messages',
	'MSG_ID'					=> 'Message ID',
	'FROM'					=> 'Sender',
	'TO'					=> 'Receiver',
	'DATETIME'					=> 'Date of sending',
	'SUBJECT'					=> 'Message title',
	'NO_MESSAGES'					=> 'No messages',
	'EXPLAIN'					=> 'Here you can see all the private messages of users',
	'TOTAL_ITEMS'		=> 'Total: <strong>%d</strong>',
));
