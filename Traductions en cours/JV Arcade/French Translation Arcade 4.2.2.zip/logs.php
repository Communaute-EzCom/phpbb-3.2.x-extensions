<?php
/**
*
* @package phpBB Arcade
* @version $Id$
* @author 2011-2017 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2017 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

//Arcade
$lang = array_merge($lang, array(
	'ARCADE_SCORE_ERR_GAME_HACK'					=> 'détection de piratage de jeu',
	'ARCADE_SCORE_ERR_GG'							=> 'code du jeu reçu incorrect',
	'ARCADE_SCORE_ERR_GG_RANDCHAR'					=> 'code du jeu pas reçu',
	'ARCADE_SCORE_ERR_GS'							=> 'code du score reçu incorrect',
	'ARCADE_SCORE_ERR_GS_GG_RANDCHAR'				=> 'code du score et du jeu pas reçu',
	'ARCADE_SCORE_ERR_GS_RANDCHAR'					=> 'code du score pas reçu',
	'ARCADE_SCORE_ERR_MICRO_TIME'					=> 'contrôle de temps dépassé',
	'ARCADE_SCORE_ERR_PCH'							=> 'variable du code de score reçu incorrecte',
	'ARCADE_SCORE_ERR_TIME_HACK'					=> 'Détection d’une possible manipulation sur la durée de jeu',

	'LOG_ACL_ADD_CATEGORY_LOCAL_C_'					=> '<strong>Ajout ou édition de permissions à la catégorie</strong> de %1$s<br />» %2$s',
	'LOG_ACL_ADD_GROUP_LOCAL_C_'					=> '<strong>Ajout ou édition de l’accès groupe à la catégorie</strong> de %1$s<br />» %2$s',
	'LOG_ACL_ADD_USER_LOCAL_C_'						=> '<strong>Ajout ou édition de l’accès utilisateurs à la catégorie</strong> de %1$s<br />» %2$s',
	'LOG_ACL_ARCADE_RESTORE_PERMISSIONS'			=> '<strong>Restauration des permissions arcade personnelles après emprunt des permissions de</strong><br />» %s',
	'LOG_ACL_ARCADE_TRANSFER_PERMISSIONS'			=> '<strong>Transfert des permissions de</strong><br />» %s',
	'LOG_ACL_DEL_CATEGORY_LOCAL_C_'					=> '<strong>Suppression de permissions Utilisateur/Groupe de catégorie</strong> de %1$s<br />» %2$s',
	'LOG_ARCADE_ADD_CAT'							=> '<strong>Création de la nouvelle catégorie</strong><br />» %s',
	'LOG_ARCADE_ADD_GAME'							=> '<strong>Ajout du jeu à la catégorie %s.</strong><br />» %s',
	'LOG_ARCADE_ADD_GAMES'							=> '<strong>Ajout des jeux à la catégorie %s.</strong><br />» %s',
	'LOG_ARCADE_ALL_ANNOUNCE_RESTORE_DEFAULT_DATA'	=> '<strong>Restauration de toutes les données par défaut d’annonce</strong>',
	'LOG_ARCADE_ANNOUNCE_CREATE_DB_DATA'			=> '<strong>“%s” a créé un message dans la base de données</strong><br />» Langue : %s',
	'LOG_ARCADE_ANNOUNCE_GENERAL_SETTINGS'			=> '<strong>Modification des paramètres généraux d’annonce</strong>',
	'LOG_ARCADE_APAGE'								=> '<strong>Modification des paramètres de page</strong>',
	'LOG_ARCADE_ARCADE_PM'							=> '<strong>Modification du message privé de l’arcade</strong><br />» Langue : %s',
	'LOG_ARCADE_ARCADE_SUPER_CHAMPION_PM'			=> '<strong>Modification du message privé de “Perte du titre de super champion”</strong><br />» Langue : %s',
	'LOG_ARCADE_AUTO_RESET_SCORE'					=> '<strong>Réinitialiser automatiquement les scores</strong>',
	'LOG_ARCADE_AUTO_RESET_SCORE_SETTINGS'			=> '<strong>Modification automatique des paramètres de scores</strong>',
	'LOG_ARCADE_BACKUP_CAT'							=> '<strong>Sauvegarde de la catégorie</strong><br />» %s',
	'LOG_ARCADE_BACKUP_CATS'						=> '<strong>Sauvegarde des catégories</strong><br />» %s',
	'LOG_ARCADE_BACKUP_EMPTY'						=> '<strong>Purge du répertoire de sauvegarde</strong>',
	'LOG_ARCADE_CATEGORY_COPIED_PERMISSIONS'		=> '<strong>Copie des permissions de catégorie</strong> de %1$s<br />» %2$s',
	'LOG_ARCADE_CAT_EDIT'							=> '<strong>Edition de la catégorie</strong><br />» %s',
	'LOG_ARCADE_CHALLENGE'							=> '<strong>Modification des paramètres de défis</strong>',
	'LOG_ARCADE_CHALLENGE_ACCEPT_PM'				=> '<strong>Modification du message privé des défis “accept” (accepter)</strong><br />» Langue : %s',
	'LOG_ARCADE_CHALLENGE_FINAL_LOSER_PM'			=> '<strong>Modification du message privé des défis “final/loser” (perdant)</strong><br />» Langue : %s',
	'LOG_ARCADE_CHALLENGE_FINAL_TIE_PM'				=> '<strong>Modification du message privé des défis “final/tie” (égalité)</strong><br />» Langue : %s',
	'LOG_ARCADE_CHALLENGE_FINAL_WINNER_PM'			=> '<strong>Modification du message privé des défis “final/winner” (gagnant)</strong><br />» Langue : %s',
	'LOG_ARCADE_CHALLENGE_PM'						=> '<strong>Modification du message privé des défis</strong><br />» Langue : %s',
	'LOG_ARCADE_CHALLENGE_REJECT_PM'				=> '<strong>Modification du message privé des défis “reject” (refuser)</strong><br />» Langue : %s',
	'LOG_ARCADE_CHALLENGE_REPORT_GAME_PM'			=> '<strong>Modification du message privé des défis “bug game report” (rapport de bug de jeu)</strong><br />» Langue : %s',
	'LOG_ARCADE_CHALLENGE_WITHDRAW_PM'				=> '<strong>Modification du message privé des défis “withdraw” (annulation)</strong><br />» Langue : %s',
	'LOG_ARCADE_CLEAR_ADMIN_LOG'					=> '<strong>Effacement d’un log d’administrateur</strong>',
	'LOG_ARCADE_CLEAR_ALL_USERS_BANNED'				=> '<strong>Annulation de tous les bannissements des utilisateurs</strong>',
	'LOG_ARCADE_CLEAR_CRITICAL_LOG'					=> '<strong>Effacement d’un log d’erreur</strong>',
	'LOG_ARCADE_CLEAR_MOD_LOG'						=> '<strong>Effacement d’un log de modérateur</strong>',
	'LOG_ARCADE_CLEAR_REPORTS'						=> '<strong>Effacement d’un rapport de jeu</strong>',
	'LOG_ARCADE_CLEAR_USERS_BANNED'					=> '<strong>Annulation des bannissement des utilisateurs</strong><br />» %s',
	'LOG_ARCADE_CLEAR_USERS_LOG'					=> '<strong>Effacement d’un log d’utilisateur</strong>',
	'LOG_ARCADE_CLEAR_USER_BANNED'					=> '<strong>Annulation du bannissement du membre</strong><br />» %s',
	'LOG_ARCADE_CPAGE'								=> '<strong>Modification des paramètres de la page des défis</strong>',
	'LOG_ARCADE_CREATE_INSTALL_FILE'				=> '<strong>Création du fichier d’installation pour le jeu</strong><br />» %s',
	'LOG_ARCADE_DELETE_GAME'						=> '<strong>Suppression du jeu</strong><br />» %s',
	'LOG_ARCADE_DELETE_GAMES'						=> '<strong>Suppression des jeux</strong><br />» %s',
	'LOG_ARCADE_DELETE_SCORE'						=> '<strong>Effacement des données de score du jeu pour l’utilisateur : %3$s%1$s%2$s</strong><br />» %4$s',
	'LOG_ARCADE_DELETE_SUPER_CHAMPION_SCORE'		=> '<strong>Effacement du score de super champion pour l’utilisateur : %s</strong><br />» Jeu : %s',
	'LOG_ARCADE_DEL_CAT'							=> '<strong>Suppression de la catégorie</strong><br />» %s',
	'LOG_ARCADE_DEL_CATS'							=> '<strong>Suppression de la catégorie et de ses sous-catégories</strong><br />» %s',
	'LOG_ARCADE_DEL_GAMES'							=> '<strong>Suppression de la catégorie et de ses jeux</strong><br />» %s',
	'LOG_ARCADE_DEL_GAMES_CATS'						=> '<strong>Suppression de la catégorie, de ses jeux et de ses sous-catégories</strong><br />» %s',
	'LOG_ARCADE_DEL_GAMES_MOVE_CATS'				=> '<strong>Suppression de la catégorie et de ses jeux, déplacement de ses sous-catégories</strong> to %1$s<br />» %2$s',
	'LOG_ARCADE_DEL_MOVE_CATS'						=> '<strong>Suppression de la catégorie et déplacement des sous-catégories</strong> to %1$s<br />» %2$s',
	'LOG_ARCADE_DEL_MOVE_GAMES'						=> '<strong>Suppression de la catégorie et déplacement des jeux </strong> to %1$s<br />» %2$s',
	'LOG_ARCADE_DEL_MOVE_GAMES_CATS'				=> '<strong>Suppression de la catégorie et de ses sous-catégories, déplacement des jeux</strong> to %1$s<br />» %2$s',
	'LOG_ARCADE_DEL_MOVE_GAMES_MOVE_CATS'			=> '<strong>Suppression de la catégorie, déplacement des jeux</strong> to %1$s <strong> et des sous-catégories</strong> to %2$s<br />» %3$s',
	'LOG_ARCADE_EDIT_GAME'							=> '<strong>Modification des paramètres du jeu</strong><br />» %s',
	'LOG_ARCADE_EDIT_GAME_RESET_INSTALL_DATE'		=> '<strong>Edition du jeu et réinitialisation de la date d’installation</strong><br />» %s',
	'LOG_ARCADE_EDIT_SCORE'							=> '<strong>Edition des données de score du joueur : %1$s</strong><br />» %2$s',
	'LOG_ARCADE_ERROR_GAME_FILE_MISSING'			=> '<strong>Il manque des fichiers ou des extra files au jeu “%s”</strong><br />» %s',
	'LOG_ARCADE_ERROR_PLAYING_TIME'					=> '<strong>Le score du jeu “%s” a été soumis sans aucun temps de jeu</strong><br />» Score : %s',
	'LOG_ARCADE_EXT_SETTINGS'						=> '<strong>Paramètres d\'extensions modifiées</strong>',
	'LOG_ARCADE_FEATURE'							=> '<strong>Modification des paramètres des options</strong>',
	'LOG_ARCADE_FORM_SCORE_ERROR'					=> '<strong>Le jeu “%s” a envoyé un score incorrect</strong><br />Type : %s<br />Score : %s<br /><strong>Erreur :</strong> (%s)',
	'LOG_ARCADE_FORM_SCORE_ERRORS'					=> '<strong>Le jeu “%s” a envoyé un score incorrect</strong><br />Type : %s<br />Score : %s<br /><strong>Erreurs :</strong> (%s)',
	'LOG_ARCADE_GAME'								=> '<strong>Modification des paramètres de jeu</strong>',
	'LOG_ARCADE_GAME_ANNOUNCE'						=> '<strong>Modification de l’annonce de jeu</strong><br />» Langue : %s',
	'LOG_ARCADE_GAME_ANNOUNCE_SYNC'					=> '<strong>Resynchronisation des annonces de jeu</strong>',
	'LOG_ARCADE_GAME_DATA_EMPTY_ERROR'				=> '<strong>Le jeu “%s” n’a pas envoyé de code arcadegid ou enscore. Le jeu est endommagé.</strong><br />» Score : %s',
	'LOG_ARCADE_GAME_FILE_NOT_FOUND'				=> '<strong>Un fichier du jeu “%s” n’a pas pu être trouvé</strong><br />» Fichier : %s',
	'LOG_ARCADE_GAME_INSTALL_FILE_NOT_FOUND'		=> '<strong>Le fichier d’installation du jeu pour “%s” n’a pas pu être trouvé</strong><br />» Fichier : %s',
	'LOG_ARCADE_GAME_INSTALL_FILE_UNWRITABLE'		=> '<strong>Le fichier d’installation du jeu pour “%s” n’est pas inscriptible</strong><br />» Fichier : %s',
	'LOG_ARCADE_GAME_NOT_DETECT_FILESIZE'			=> '<strong>Impossibilité de déterminer la taille des fichiers de jeu</strong><br />» %s',
	'LOG_ARCADE_GAME_NOT_DETECT_HW'					=> '<strong>Impossibilité de déterminer la largeur et la hauteur du jeu</strong><br />» %s',
	'LOG_ARCADE_GLOBAL_ANNOUNCE'					=> '<strong>Modification de l’annonce globale</strong><br />» Langue : %s',
	'LOG_ARCADE_G_MOVE_DOWN'						=> '<strong>Déplacement du jeu</strong> %s <strong>vers le bas</strong>',
	'LOG_ARCADE_G_MOVE_UP'							=> '<strong>Déplacement du jeu</strong> %s <strong>vers le haut</strong>',
	'LOG_ARCADE_LOAD'								=> '<strong>Chargement des paramètres</strong>',
	'LOG_ARCADE_MENUS_DELETE'						=> '<strong>Suppression du menu et de ses sous-menus</strong><br />» %s',
	'LOG_ARCADE_MENU_ADD'							=> '<strong>Ajout dans le menu</strong><br />» %s',
	'LOG_ARCADE_MENU_DELETE'						=> '<strong>Suppression dans le menu</strong><br />» %s',
	'LOG_ARCADE_MENU_EDIT'							=> '<strong>Edition du menu</strong><br />» %s',
	'LOG_ARCADE_MENU_MOVE_DOWN'						=> '<strong>Déplacement du menu</strong> %1$s <strong>en-dessous de</strong> %2$s',
	'LOG_ARCADE_MENU_MOVE_UP'						=> '<strong>Déplacement du menu</strong> %1$s <strong>au-dessus de</strong> %2$s',
	'LOG_ARCADE_MOVE_DOWN'							=> '<strong>Déplacement de la catégorie</strong> %1$s <strong>en-dessous de</strong> %2$s',
	'LOG_ARCADE_MOVE_GAME'							=> '<strong>Déplacement du jeu de la catégorie %1$s vers la nouvelle catégorie %2$s</strong><br />» %3$s',
	'LOG_ARCADE_MOVE_GAMES'							=> '<strong>Déplacement des jeux de la catégorie %1$s vers la nouvelle catégorie %2$s</strong><br />» %3$s',
	'LOG_ARCADE_MOVE_UP'							=> '<strong>Déplacement de la catégorie</strong> %1$s <strong>en-dessous de</strong> %2$s',
	'LOG_ARCADE_PAAR'								=> '<strong>Modification de phpBB Arcade - Activity rank</strong>',
	'LOG_ARCADE_PATH'								=> '<strong>Modification des paramètres de chemin</strong>',
	'LOG_ARCADE_PURGE_SESSIONS'						=> '<strong>Purge des sessions de jeu</strong>',
	'LOG_ARCADE_RESET_ARCADE'						=> '<strong>Réinitialisation de l’arcade</strong>%s%s',
	'LOG_ARCADE_RESET_CHALLENGE'					=> '<strong>Réinitialisation des défis</strong>',
	'LOG_ARCADE_RESET_COMMENT'						=> '<strong>Réinitialisation des commentaires des jeux</strong>',
	'LOG_ARCADE_RESET_DOWNLOADS'					=> '<strong>Réinitialisation des statistiques de téléchargement</strong>',
	'LOG_ARCADE_RESET_GAME'							=> '<strong>Réinitialisation des données du jeu%s%s%s%s</strong><br />» %s',
	'LOG_ARCADE_RESET_GAMES'						=> '<strong>Réinitialisation des données des jeux%s%s%s%s</strong><br />» %s',
	'LOG_ARCADE_RESET_GAMES_SCORES'					=> '<strong>Effacement des scores des jeux%s%s</strong><br />» %s',
	'LOG_ARCADE_RESET_GAME_SCORES'					=> '<strong>Effacement des scores du jeu%s%s</strong><br />» %s',
	'LOG_ARCADE_RESET_INSTALL_DATE_GAME'			=> '<strong>Réinitialisation de la date d’installation du jeu</strong><br />» %s',
	'LOG_ARCADE_RESET_INSTALL_DATE_GAMES'			=> '<strong>Réinitialisation des dates d’installation des jeux</strong><br />» %s',
	'LOG_ARCADE_RESET_JACKPOT'						=> '<strong>Réinitialisation des données de jackpot</strong>',
	'LOG_ARCADE_RESET_PLAYING_RECORD'				=> '<strong>Réinitialisation du comptage des joueurs qui jouent le plus</strong>',
	'LOG_ARCADE_RESET_POINTS'						=> '<strong>Réinitialisation des données de points</strong>',
	'LOG_ARCADE_RESET_SCORES_ALL'					=> '<strong>Effacement des scores de tous les utilisateurs</strong>',
	'LOG_ARCADE_RESET_SUPER_CHAMPION'				=> '<strong>Réinitialisation du super champion</strong>',
	'LOG_ARCADE_RESET_USERS_DATA'					=> '<strong>Réinitialisation des données de tous les utilisateurs</strong>',
	'LOG_ARCADE_RESET_USERS_SCORE'					=> '<strong>Effacement de tous les scores</strong>',
	'LOG_ARCADE_RESET_USERS_SETTINGS'				=> '<strong>Réinitialisation des paramètres des utilisateurs</strong>',
	'LOG_ARCADE_RESET_USER_ALL'						=> '<strong>Réinitialisation de toutes les données pour l’utilisateur</strong><br />» %s',
	'LOG_ARCADE_RESET_USER_SCORES'					=> '<strong>Effacement des scores%s%s</strong><br />» %s',
	'LOG_ARCADE_RESET_USER_SUPER_RECORDS'			=> '<strong>Réinitialisation des super records de l’utilisateur</strong><br />» %s',
	'LOG_ARCADE_RESTORE_DEFAULT_DATA_ANNOUNCE'		=> '<strong>Restauration des données par défaut de l’annonce</strong><br />» %s',
	'LOG_ARCADE_RESTORE_DEFAULT_DATA_PM'			=> '<strong>Restauration des données par défaut du message privé</strong><br />» %s',
	'LOG_ARCADE_RESYNC_TOTALS_DATA'					=> '<strong>Resynchronisation totale des données</strong>',
	'LOG_ARCADE_RESYNC_USERS_TOTAL_DATA'			=> '<strong>Resynchronisation des données totales des utilisateurs</strong>',
	'LOG_ARCADE_SETTINGS'							=> '<strong>Modification des paramètres généraux</strong>',
	'LOG_ARCADE_SYNC_CAT'							=> '<strong>Resynchronisation de la catégorie</strong><br />» %s',
	'LOG_ARCADE_SYNC_GAME'							=> '<strong>Resynchronisation du jeu</strong><br />» %s',
	'LOG_ARCADE_SYNC_GAMES'							=> '<strong>Resynchronisation des jeux</strong><br />» %s',
	'LOG_ARCADE_TOURNAMENT'							=> '<strong>Modification des paramètres de tournoi</strong>',
	'LOG_ARCADE_TOUR_ANNOUNCE'						=> '<strong>Modification de l’annonce de tournoi</strong><br />» Langue : %s',
	'LOG_ARCADE_TOUR_CREATE'						=> '<strong>Création de tournoi</strong><br />» %s',
	'LOG_ARCADE_TOUR_DELETE'						=> '<strong>Suppression de tournoi</strong><br />» %s',
	'LOG_ARCADE_TOUR_EDIT'							=> '<strong>Edition de tournoi</strong><br />» %s',
	'LOG_ARCADE_TOUR_END_ANNOUNCE'					=> '<strong>Modification de l’annonce de fin de tournoi</strong><br />» Langue : %s',
	'LOG_ARCADE_TPAGE'								=> '<strong>Modification des paramètres de pages de tournoi</strong>',
	'LOG_ARCADE_UNDEFINED_SCORE'					=> '<strong>Le jeu “%s” a envoyé un score indéfini</strong>',
	'LOG_ARCADE_UNPACK_GAME'						=> '<strong>Jeu dépaqueté</strong><br />» %s',
	'LOG_ARCADE_UNPACK_GAMES'						=> '<strong>Jeux dépaquetés</strong><br />» %s',
	'LOG_ARCADE_UPLOAD_UNPACK_GAME'					=> '<strong>Jeu téléchargé et dépaqueté</strong><br />» %s',
	'LOG_ARCADE_USERS_DEFAULT_SETTINGS'				=> '<strong>Changement des paramètres par défaut d’utilisateur</strong>',
	'LOG_ARCADE_USER_BANNED'						=> '<strong>Bannissement de l’utilisateur</strong><br />» %s',
	'LOG_ARCADE_USER_MAIN_SETTINGS'					=> '<strong>Modification des paramètres généraux</strong>',
	'LOG_ARCADE_USER_MANAGE_FAVORITES'				=> '<strong>Gestion des jeux favoris</strong>',
	'LOG_ARCADE_USER_POST_SETTINGS'					=> '<strong>Modification des paramètres de message</strong>',
	'LOG_ARCADE_USER_SET_UPDATE'					=> '<strong>Mise à jour des détails de l’utilisateur</strong><br />» %s',
	'LOG_ARCADE_VERSION_CHECK_DISABLED'				=> '<strong>Vérification automatisée de version désactivée</strong>',
	'LOG_ARCADE_VERSION_CHECK_ENABLED'				=> '<strong>Vérification automatisée de version activée</strong>',
	'LOG_C_ROLE_ADD'								=> '<strong>Ajout d’un modèle de catégorie</strong><br />» %s',
	'LOG_C_ROLE_EDIT'								=> '<strong>Edition d’un modèle de catégorie</strong><br />» %s',
	'LOG_C_ROLE_REMOVED'							=> '<strong>Suppression d’un modèle de catégorie</strong><br />» %s',
));
