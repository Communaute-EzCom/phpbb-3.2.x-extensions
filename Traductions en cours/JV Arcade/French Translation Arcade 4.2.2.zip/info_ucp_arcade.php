<?php
/**
*
* @package phpBB Arcade
* @version $Id$
* @author 2011-2017 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2017 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

//Arcade
$lang = array_merge($lang, array(
	'UCP_ARCADE'							=> 'phpBB Arcade',
	'UCP_ARCADE_CAT_STYLE'					=> 'Style de catégorie',
	'UCP_ARCADE_DELETE_FAVORITE'			=> 'Retirer ce jeu des favoris',
	'UCP_ARCADE_DELETE_FAVORITES'			=> 'Retirer ces jeux des favoris',
	'UCP_ARCADE_DELETE_FAVORITES_CONFIRM'	=> 'Etes-vous sûr de vouloir retirer ces jeux des favoris ?',
	'UCP_ARCADE_DELETE_FAVORITE_CONFIRM'	=> 'Etes-vous sûr de vouloir retirer ce jeu des favoris ?',
	'UCP_ARCADE_DISPLAY_GAME_IMAGE'			=> 'Afficher l’image du jeu',
	'UCP_ARCADE_DISPLAY_POPUP_ICON'			=> 'Afficher l’icone popup',
	'UCP_ARCADE_FAVORITES'					=> 'Gestion des Jeux Favoris',
	'UCP_ARCADE_FAVORITES_DELETED'			=> 'Jeux retirés des favoris avec succès.',
	'UCP_ARCADE_FAVORITES_EXPLAIN'			=> 'Ci-dessous vous pouvez voir, mettre en surbrillance et supprimer vos jeux favoris.',
	'UCP_ARCADE_FAVORITE_DELETED'			=> 'Jeu retiré des favoris avec succès.',
	'UCP_ARCADE_NO_PERM_PM_LOSS_HIGHSCORE'	=> 'Vous n’avez pas les permissions pour recevoir des messages privés concernant les pertes de records.',
	'UCP_ARCADE_POST'						=> 'Régler les paramètres de messages',
	'UCP_ARCADE_POST_EXPLAIN'				=> 'Options pour personnaliser vos messages.<br /><br />',
	'UCP_ARCADE_SELECTED_HIGHLIGHT'			=> 'Activer la surbrillance',
	'UCP_ARCADE_SELECTED_HIGHLIGHT_REMOVE'	=> 'Retirer la surbrillance',
	'UCP_ARCADE_SEND_PM_EXPLAIN'			=> 'Quand vous perdrez un record ou un défi, un message privé vous sera envoyé pour vous le signaler.',
	'UCP_ARCADE_SETTINGS'					=> 'Modifier les paramètres Arcade',
	'UCP_ARCADE_SETTINGS_EXPLAIN'			=> 'Ces paramètres contrôlent divers aspects de l’Arcade.<br /><br />',
	'UCP_CAT_ARCADE'						=> 'Arcade de Jeux',
	'UCP_CHALLENGE_ENABLED'					=> 'Permettre les Défis',
	'UCP_CHALLENGE_ENABLED_EXPLAIN'			=> 'Si activé, on pourra vous défier et vous pourrez lancer des défis dans les jeux.',
));
