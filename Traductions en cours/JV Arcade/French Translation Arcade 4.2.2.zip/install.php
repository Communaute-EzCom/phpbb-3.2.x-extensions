<?php
/**
*
* @package phpBB Arcade
* @version $Id$
* @author 2011-2017 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2017 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” … ≧

$lang = array_merge($lang, array(
	'INSTALL_ARCADE_ALL_FOUND'							=> 'Tout trouvé',
	'INSTALL_ARCADE_BBCODE_HELPLINE'					=> 'Ligne d’aide',
	'INSTALL_ARCADE_BBCODE_REQD'						=> 'Vérification du BBCode',
	'INSTALL_ARCADE_BBCODE_REQD_EXPLAIN'				=> '<strong>Requis</strong> - Ajout de BBCode pour que phpBB Arcade fonctionne correctement.',
	'INSTALL_ARCADE_BBCODE_USAGE'						=> 'Structure du BBCode',
	'INSTALL_ARCADE_DIRS_FILES_REQD'					=> 'Fichiers et Répertoires',
	'INSTALL_ARCADE_DIRS_FILES_REQD_EXPLAIN'			=> '<strong>Requis</strong> - Pour fonctionner correctement, phpBB Arcade doit pouvoir accéder à certains fichiers ou répertoires pour éventuellement écrire dedans. Si vous voyez “Ne peut trouver”, il faut créer le fichier ou répertoire en question. Si vous voyez “Non inscriptible”, il faut donner les permissions en écriture au fichier ou répertoire concerné.',
	'INSTALL_ARCADE_DISPLAY_ON_POSTING'					=> 'Afficher sur la page de rédaction',
	'INSTALL_ARCADE_DONATE_TITLE'						=> 'phpBB Arcade - Donation',
	'INSTALL_ARCADE_FINISH'								=> 'La Vérification de phpBB Arcade s’est totalement déroulée avec succès. Merci d’avoir choisi le logiciel phpBB Arcade.',
	'INSTALL_ARCADE_FOUND'								=> 'Trouvé',
	'INSTALL_ARCADE_HTML_REPLACEMENT'					=> 'Code HTML',
	'INSTALL_ARCADE_MAIN_PAGE'							=> 'Aller à la page principale de l’ACP de phpBB Arcade',
	'INSTALL_ARCADE_NEXT_STEP'							=> 'Passer à l’étape suivante',
	'INSTALL_ARCADE_NOT_FOUND'							=> 'Pas trouvé',
	'INSTALL_ARCADE_PHPBB_REQD'							=> 'Version de phpBB ≧ %s',
	'INSTALL_ARCADE_PHPBB_REQD_EXPLAIN'					=> '<strong>Requis</strong> - Vous devez utiliser au moins la version “%s” de phpBB pour pouvoir utiliser phpBB Arcade.',
	'INSTALL_ARCADE_PHP_CURL_SUPPORT'					=> 'Le paramètre PHP <var>curl</var> est disponible',
	'INSTALL_ARCADE_PHP_CURL_SUPPORT_EXPLAIN'			=> '<strong>Optionnel</strong> - Cette fonction est optionnelle, cependant certains modules phpBB Arcade comme le module ACP de téléchargements ne marcheront pas sans cela.',
	'INSTALL_ARCADE_PHP_GETIMAGESIZE_SUPPORT'			=> 'La fonction PHP getimagesize() est disponible',
	'INSTALL_ARCADE_PHP_GETIMAGESIZE_SUPPORT_EXPLAIN'	=> '<strong>Requis</strong> - Pour que phpBB Arcade fonctionne correctement, il faut que la fonction getimagesize soit active.',
	'INSTALL_ARCADE_PHP_REQD'							=> 'Version de PHP ≧ %s',
	'INSTALL_ARCADE_PHP_REQD_EXPLAIN'					=> '<strong>Requis</strong> - Vous devez faire tourner au moins la version “%s” de PHP pour pouvoir utiliser phpBB Arcade.',
	'INSTALL_ARCADE_PHP_SETTINGS'						=> 'Version PHP et paramètres',
	'INSTALL_ARCADE_PHP_URL_FOPEN_SUPPORT'				=> 'Le paramètre PHP <var>allow_url_fopen</var> est activé',
	'INSTALL_ARCADE_PHP_URL_FOPEN_SUPPORT_EXPLAIN'		=> '<strong>Optionnel</strong> - Ce réglage est optionnel, cependant certaines fonctions de phpBB Arcade comme le module ACP de téléchargements ne marcheront pas correctement sans cela.',
	'INSTALL_ARCADE_REQUIREMENTS'						=> 'Conditions requises pour l’installation de phpBB Arcade.',
	'INSTALL_ARCADE_REQUIREMENTS_EXPLAIN'				=> 'Faire des tests sur le serveur pour vous assurer que vous avez bien installé phpBB Arcade. Veuillez lire les résultats attentivement et ne poursuivez pas tant que tous les tests ne sont pas finis. Si vous souhaitez utiliser des fonctionnalités liées aux tests optionnels, vous devez vous assurer aussi que tous ces tests aient été exécutés.',
	'INSTALL_ARCADE_SOFTWARE_VERSION'					=> 'Version du logiciel',
	'INSTALL_ARCADE_TEST_AGAIN'							=> 'Tester à nouveau',
	'INSTALL_ARCADE_UNWRITABLE'							=> 'Pas inscriptible',
	'INSTALL_ARCADE_VERIFY_DB'							=> 'Vérifier la base de données de phpBB Arcade',
	'INSTALL_ARCADE_VERIFY_DB_ACP_MODULES'				=> 'Vérifier les modules ACP',
	'INSTALL_ARCADE_VERIFY_DB_ARCADE_PERMISSIONS'		=> 'Vérifier les permissions phpBB Arcade',
	'INSTALL_ARCADE_VERIFY_DB_CONFIGS'					=> 'Vérifier les configs',
	'INSTALL_ARCADE_VERIFY_DB_DATA'						=> 'Vérifier la base de données',
	'INSTALL_ARCADE_VERIFY_DB_EXPLAIN'					=> 'Cela vérifiera que toutes les données de la base de données de l’arcade sont bien correctes dans la base de données.',
	'INSTALL_ARCADE_VERIFY_DB_MCP_MODULES'				=> 'Vérifier les modules MCP',
	'INSTALL_ARCADE_VERIFY_DB_PERMISSIONS'				=> 'Vérifier les permissions',
	'INSTALL_ARCADE_VERIFY_DB_PHPBB_PERMISSIONS'		=> 'Vérifier les permissions phpBB',
	'INSTALL_ARCADE_VERIFY_DB_TABLES'					=> 'Vérifier les tables',
	'INSTALL_ARCADE_VERIFY_DB_UCP_MODULES'				=> 'Vérifier les modules UCP',
	'INSTALL_ARCADE_VERIFY_ERROR_DB_VERSION'			=> 'La vérification de phpBB Arcade ne se lance pas car une nouvelle version du logiciel a été détectée. Veuillez lancer %sla mise à jour de phpBB Arcade%s.',
	'INSTALL_ARCADE_VERIFY_FILES'						=> 'Vérifier les fichiers phpBB Arcade',
	'INSTALL_ARCADE_VERIFY_FILES_EXIST'					=> 'Vérifier si les fichiers existent',
	'INSTALL_ARCADE_VERIFY_FILES_EXPLAIN'				=> 'Cela vérifiera que tous les fichiers de phpBB Arcade sont présents sur le serveur.',
	'INSTALL_ARCADE_WRITABLE'							=> 'Inscriptible',
	'INS_ARCADE_ADD_ERROR_LOG'							=> 'Toutes les erreurs relevées ont été enregistrées.',
	'INS_ARCADE_CONVERT_GAME_INSTALL_FILE_END'			=> 'Le processus de conversion est terminé, vous pouvez voir les résultats ci-après.',
	'INS_ARCADE_CONVERT_GAME_INSTALL_FILE_EXPLAIN'		=> 'Ci-dessous on peut voir que le processus est en progrès. SVP, ne fermez pas votre navigateur.',
	'INS_ARCADE_CONVERT_GAME_INSTALL_FILE_PROCESSING'	=> 'Veuillez patienter…<br />%1$s<br />Processus en cours sur les fichiers d’installation de jeux %2$s of %3$s.',
	'INS_ARCADE_CONVERT_GAME_INSTALL_FILE_START'		=> 'Lancer la conversion',
	'INS_ARCADE_CONVERT_TOTAL_GAME_INSTALL_FILES'		=> 'Fichiers convertis',
	'INS_ARCADE_DATA_FILES_CORRECT'						=> 'Fichiers avec des données correctes',
	'INS_ARCADE_DELETE_DUPLICATE_GAME'					=> 'Jeu en double supprimé',
	'INS_ARCADE_DELETE_DUPLICATE_GAMES'					=> 'Jeux en double supprimés',
	'INS_ARCADE_FILE_WRITE_EXPLAIN'						=> '<span style="color: #ff0000;">Attention :</span> La mise à jour des fichiers d’installation de jeux ne réussira que si les fichiers sont inscriptibles, aussi veuillez vous assurer que les permissions sont correctement définies.',
	'INS_ARCADE_GAME_CONVERT_FILE'						=> 'Convertir les fichiers d’installation de jeux',
	'INS_ARCADE_GAME_CONVERT_FILE_EXPLAIN'				=> 'Ici vous avez la possibilité de convertir les fichiers d’installation des jeux existants au format de la dernière version.',
	'INS_ARCADE_GAME_DATA_CORRECT'						=> 'Jeux avec des données correctes',
	'INS_ARCADE_GAME_DATA_UPDATED'						=> 'Jeux mis à jour',
	'INS_ARCADE_GAME_FILES_NOT_FOUND'					=> 'Fichiers de jeu pas trouvés',
	'INS_ARCADE_GAME_INSTALL_FILES_NOT_FOUND'			=> 'Les fichiers d’installation de jeux n’ont pas été trouvés',
	'INS_ARCADE_GAME_INSTALL_FILES_UNWRITABLE'			=> 'Fichiers non inscriptibles',
	'INS_ARCADE_GAME_INSTALL_FILE_UPDATED'				=> 'Fichiers d’installation de jeux mis à jour',
	'INS_ARCADE_UND_GAMES_FILESIZE'						=> 'Taille de fichiers non spécifiée, jeux',
	'INS_ARCADE_UND_GAMES_WIDTH_HEIGHT'					=> 'Hauteur et largeur de jeu non spécifiées, jeux',
	'INS_ARCADE_UPDATE_GAME_DATA'						=> 'Mise à jour des données de jeux',
	'INS_ARCADE_UPDATE_GAME_DATA_END'					=> 'Le processus de mise à jour est terminé, vous pouvez voir les résultats ci-dessous.',
	'INS_ARCADE_UPDATE_GAME_DATA_EXPLAIN'				=> 'Le processus de mise à jour permettra la détermination des tailles correctes des jeux : (Taille de tous les fichiers de jeu, hauteur, largeur). Si elles sont définies avec des données incorrectes dans la base de données et le fichier d’installation, ce sera mis à jour avec les données correctes.<br /><span style="color: #ff0000;">Attention :</span> Veuillez noter que, pendant le processus, certains gros jeux réclament beaucoup de mémoire, il est donc possible que le processus sature et plante. Dans ce cas il est recommandé d’augmenter la limite en mémoire du serveur dans le fichier php ini.',
	'INS_ARCADE_UPDATE_GAME_DATA_PROC_EXPLAIN'			=> 'Ci-dessous vous pouvez voir où en est le processus de mise à jour. S’il vous plait, ne fermez pas votre navigateur tant que cela n’est pas fini.',
));
