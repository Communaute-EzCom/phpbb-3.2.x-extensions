<?php
/**
*
* @package phpBB Arcade
* @version $Id$
* @author 2011-2017 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2017 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'ARCADE_ACP_HELP_FAQ_BLOCK_GENERAL'					=> 'Généralités',
	'ARCADE_ACP_HELP_FAQ_BLOCK_INSTALL'					=> 'Installation/Mise à jour/Désinstallation',
	'ARCADE_ACP_HELP_FAQ_BLOCK_SCORING'					=> 'Scores',
	'ARCADE_ACP_HELP_FAQ_BLOCK_GAMES'					=> 'Jeux',
	'ARCADE_ACP_HELP_FAQ_BLOCK_MODULES'					=> 'Modules de l’Arcade',
	'ARCADE_ACP_HELP_FAQ_BLOCK_DATA'					=> 'Afficher des données arcade en dehors de l’arcade',
// step 1
	'ARCADE_ACP_HELP_FAQ_GENERAL_FEATURES_ANSWER'		=> '<ul>
																<li>Support complet des jeux</li>
																<li>Catégories, sous-catégories et liens en nombre illimité (comme pour les forums phpBB3)</li>
																<li>Modules complets ACP, MCP et UCP</li>
																<li>Permissions administrateur pour les modules ACP</li>
																<li>Permissions modérateur pour les modules MCP</li>
																<li>Permissions globales d’arcade</li>
																<li>Permissions basiques de catégorie</li>
																<li>Catégories protégées par mot de passe</li>
																<li>Catégories protégées par la limite d’âge</li>
																<li>Installation très facile des jeux</li>
																<li>Conversion automatique des fichiers tar des jeux IBPro</li>
																<li>Montrer qui joue et à quel jeu</li>
																<li>Système de jeux favoris</li>
																<li>Système interne de téléchargement de jeux à partir d’un site</li>
																<li>Statistiques détaillées</li>
																<li>Système d’évaluation de jeu</li>
																<li>Système de commentaires de jeu</li>
																<li>Système de rapport de jeu</li>
																<li>Choix entre jouer normalement ou dans une fenêtre pop up</li>
																<li>Système de recherche</li>
																<li>Intégration d’un système de points</li>
																<li>Et plus encore…</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GENERAL_FEATURES_QUESTION'		=> 'Quelles sont les fonctionnalités de phpBB Arcade ?',

	'ARCADE_ACP_HELP_FAQ_GENERAL_STYLES_ANSWER'			=> '<ul>
																<li>Les styles supportés peuvent être téléchargés <b><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_31x_Arcade_Styles.html">ICI</a></b>.</li>
																<li>Si vous avez un nouveau style, veuillez le partager avec nous <b><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_31x_Arcade_User_Styles.html">ICI</a></b>.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GENERAL_STYLES_QUESTION'		=> 'Quels sont les styles supportés ?',

	'ARCADE_ACP_HELP_FAQ_GENERAL_LANGS_ANSWER'			=> '<ul>
																<li>Les langues supportées sont téléchargeables <b><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_31x_Arcade_Languages.html">ICI</a></b>.</li>
																<li>Si vous avez créé un nouveau pack de langue, veuillez le partager avec nous <b><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_31x_Arcade_User_Languages.html">ICI</a></b>.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GENERAL_LANGS_QUESTION'		=> 'Quelles langues sont disponibles ?',

	'ARCADE_ACP_HELP_FAQ_GENERAL_STYLES_IMG_ANSWER'		=> 'Oui. Toutes les images qui se trouvent dans le répertoire par défaut de l’arcade “[ROOT]/styles/all/theme/images/” peuvent être écrasées par des images spécifiques à un style. Il suffit de placer une image avec exactement le même nom que l’image par défaut dans le dossier “[ROOT]/styles/Votre_style/theme/images/”. S’il n’y a pas d’image spécifique définie pour un style, l’image par défaut est utilisée.<br />De même pour les images des catégories. Pendant la création ou édition de la catégorie, il faut déjà avoir défini une image par défaut qui se trouve dans “[ROOT]/styles/all/theme/images/cats/”. Puis, pour utiliser une image de catégorie spécifique à un style en particulier, il suffit d’uploader une image avec exactement le même nom dans le dossier “[ROOT]/styles/Votre_style/theme/images/arcade/cats/”.',
	'ARCADE_ACP_HELP_FAQ_GENERAL_STYLES_IMG_QUESTION'	=> 'Peut-on, dans l’arcade, utiliser des images spécifiques à un style en particulier ?',
// step 2
	'ARCADE_ACP_HELP_FAQ_INSTALL_DB_ANSWER'				=> 'L’arcade devrait fonctionner correctement avec toutes les bases de données qui sont déjà compatibles avec phpBB3.',
	'ARCADE_ACP_HELP_FAQ_INSTALL_DB_QUESTION'			=> 'Quels types de bases de données sont compatibles avec phpBB Arcade ?',

	'ARCADE_ACP_HELP_FAQ_INSTALL_INSTALL_ANSWER'		=> '<ul>
																<li>Téléchargez la dernière version et dépaquetez-la.</li>
																<li>Copiez les fichiers du serveur dans le répertoire “[ROOT]/” du forum.</li>
																<li>Allez dans le Panneau d’Administration et cliquez dans le menu “Personnaliser” sur le lien “Activer” phpBB Arcade, ce qui installera phpBB Arcade.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_INSTALL_INSTALL_QUESTION'		=> 'Comment installer phpBB Arcade ?',

	'ARCADE_ACP_HELP_FAQ_INSTALL_UPDATE_ANSWER'			=> '<ul>
																<li>Téléchargez la dernière version et dépaquetez-la.</li>
																<li>Copiez les fichiers du serveur dans le répertoire “[ROOT]/” du forum.</li>
																<li>Allez dans le Panneau d’Administration et cliquez sur “Désactiver” après le lien “Activer”, ce qui mettra à jour phpBB Arcade.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_INSTALL_UPDATE_QUESTION'		=> 'Comment mettre à jour phpBB Arcade ?',

	'ARCADE_ACP_HELP_FAQ_INSTALL_UNINSTALL_ANSWER'		=> 'Allez dans le Panneau d’Administration et cliquez sur “Désactiver” après le lien “Effacer données”, ce qui supprimera tous les fichiers phpBB Arcade du serveur.',
	'ARCADE_ACP_HELP_FAQ_INSTALL_UNINSTALL_QUESTION'	=> 'Comment désinstaller phpBB Arcade ?',
// step 3
	'ARCADE_ACP_HELP_FAQ_SCORING_SAVE_ANSWER'			=> 'La première chose à vérifier est que le jeu est bien d’un type supporté par l’arcade et que la variable de score est définie correctement. Enfin, il faut vérifier les paramètres du cookie dans l’ACP. Si l’url de votre site est <strong>http://www.exemple.com</strong> alors le domaine du cookie devrait être <strong>exemple.com</strong>. Par ailleurs, la sécurité du cookie doit être désactivée dans l’AVP, sinon la sécurité de cookie n’autorisera que le type de jeu phpBB Arcade.',
	'ARCADE_ACP_HELP_FAQ_SCORING_SAVE_QUESTION'			=> 'Pourquoi mes scores ne sont-ils pas enregistrés ?',

	'ARCADE_ACP_HELP_FAQ_SCORING_GUEST_SAVE_ANSWER'		=> 'Même si vous donnez les bonnes permissions au groupe des Invités, ils ne pourront pas soumettre des scores dans l’arcade. C’est immuable, l’arcade est conçue ainsi.',
	'ARCADE_ACP_HELP_FAQ_SCORING_GUEST_SAVE_QUESTION'	=> 'Pourquoi les Invités ne peuvent-ils pas soumettre des scores, même quand ils en ont la permission ?',

	'ARCADE_ACP_HELP_FAQ_SCORING_TEST_CAT_ANSWER'		=> 'Aller dans le module “Gestion de l’Arcade” de l’ACP. Editer la catégorie concernée et commuter l’option “Mode Test” sur oui.',
	'ARCADE_ACP_HELP_FAQ_SCORING_TEST_CAT_QUESTION'		=> 'Comment activer le “Mode Test” pour une catégorie ?',

	'ARCADE_ACP_HELP_FAQ_SCORING_TEST_ANSWER'			=> 'Quand le “Mode Test” est activé, il est permis de jouer aux jeux d’une catégorie sans en enregistrer les données et les scores. Le but est de tester des jeux et de s’assurer de leur bon fonctionnement. Quand un jeu est terminé, un message d’info s’affiche montrant ce qu’il se serait passé (score). Si vous êtes administrateur et que “DEBUG” est activé, vous aurez accès à plus d’infos détaillées.',
	'ARCADE_ACP_HELP_FAQ_SCORING_TEST_QUESTION'			=> 'A quoi sert le “Mode Test” ?',
// step 4
	'ARCADE_ACP_HELP_FAQ_GAMES_TYPE_ANSWER'				=> 'L’arcade est compatible avec les types de jeux suivants :<br />
															<ul>
																<li>Flash</li>
																<li>Html5</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_TYPE_QUESTION'			=> 'Quels types de jeux sont acceptés ?',

	'ARCADE_ACP_HELP_FAQ_GAMES_SAVE_TYPE_ANSWER'		=> 'L\'arcade prend en charge les types de jeu suivants:<br>
															<ul>
																<li>Activity Mod</li>
																<li>Arcade Room</li>
																<li>V3 Arcade</li>
																<li>IBPro</li>
																<li>ArcadeLib</li>
																<li>IBPro V32</li>
																<li>phpBB Arcade</li>
																<li>Jeux sans score</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_SAVE_TYPE_QUESTION'		=> 'Quels types de jeu sont supportés?',

    'ARCADE_ACP_HELP_FAQ_GAMES_INSTALL_ANSWER'			=> 'Le moyen le plus facile est d’utiliser des jeux qui sont déjà au format phpBB Arcade ou IBPro tar. On peut aussi installer des jeux empaquetés pour Arcade Room s’ils contiennent un fichier xml. L’arcade détectera automatiquement le type du jeu que vous êtes en train d’uploader ou dépaqueter et le convertira au format correct pour être installé.',
	'ARCADE_ACP_HELP_FAQ_GAMES_INSTALL_QUESTION'		=> 'Quel est le moyen le plus simple d’installer des jeux ?',

	'ARCADE_ACP_HELP_FAQ_GAMES_REQ_INSTALL_ANSWER'		=> 'Pour mettre en place des jeux par vous-même, il faut les uploader vers (par défaut) <strong>[ROOT]/arcade/games/</strong> à l’intérieur d’un dossier qui porte le même nom que le fichier swf. Si le fichier flash s’appelle <strong>test.swf</strong>, il devrait y avoir à l’intérieur de <strong>[ROOT]/arcade/games/</strong> un dossier qui s’appelle <strong>test</strong>.<br /><br />Dans ce dossier doivent se trouver les fichiers suivants :<br /><ul><li>test.swf (flash)</li><li>test.gif (50px par 50 px)</li><li>test.php (Fichier d’installation. S’il est absent, le jeu ne sera pas installé)</li><li>index.htm (fichier html vide)</li></ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_REQ_INSTALL_QUESTION'	=> 'Qu’est-il requis pour qu’un jeu soit installé ?',

	'ARCADE_ACP_HELP_FAQ_GAMES_HOW_INSTALL_ANSWER'		=> 'Il y a trois façons d’installer un jeu.<br />
															<ul>
																<li>Si le jeu a été récupéré grâce au système interne de téléchargement de jeux, vous vous retrouvez avec un dossier compressé qu’il vous suffit d’uploader via FTP vers <strong>[ROOT]/arcade/install</strong> puis de l’installer à travers l’ACP (module Upload/Dépaquetage de jeux puis module Ajout de jeux). Notez que, si vous avez beaucoup de jeux à installer, cette méthode est bien plus rapide que la suivante qui se limite à un seul jeu à la fois.</li>
																<li>Si le jeu a été récupéré grâce au système interne de téléchargement de jeux, vous vous retrouvez avec un dossier compressé que vous pouvez uploader grâce au module Upload/Dépaquetage de jeux de l’ACP. Une fois uploadé, le jeu sera automatiquement dépaqueté et vous pourrez l’ajouter à l’arcade à l’aide du module Ajout de jeux.</li>
																<li>Une autre façon de procéder est d’uploader manuellement tous les fichiers au bon endroit sur le serveur puis d’aller dans l’ACP pour installer le jeu.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_HOW_INSTALL_QUESTION'	=> 'Comment installer un jeu ?',

	'ARCADE_ACP_HELP_FAQ_GAMES_ZIP_ANSWER'				=> 'Oui. La procédure est très simple. Il suffit de créer un dossier avec le même nom que le fichier swf et, dans ce dossier, placer les fichiers nomdujeu.swf, nomdujeu.gif, nomdujeu.php et index.htm. Puis il faut compresser (zipper) le dossier en s’assurant que l’archive créée porte bien le même nom que le fichier swf.',
	'ARCADE_ACP_HELP_FAQ_GAMES_ZIP_QUESTION'			=> 'Est-ce que je peux moi-même créer mon propre fichier compressé pour installer un jeu ?',

	'ARCADE_ACP_HELP_FAQ_GAMES_INS_FILE_ANSWER'			=> 'Oui.<br><textarea rows="30" cols="30" readonly="readonly" onclick="this.focus(); this.select();">&lt;?php
/**
*
* @package phpBB Arcade
* @version 5.0.0
* @author 2011-2017 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2017 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
*	Fichier d’Installation de Jeu phpBB Arcade
*
*	On trouve ci-dessous des informations sur les paramètres à définir pour installer
*	un jeu dans l’arcade. Ce fichier est nécessaire pour réussir à installer un jeu
*	par le truchement de l’ACP de phpBB Arcade.
*
*	Les seules choses qu’on doit définir sont le nom, la description, le type,
*	la largeur, la hauteur et le scoretype.
*
*	Utilisez les constantes suivantes pour le type de jeu:
*
*	GAME_TYPE_HTML5
*	GAME_TYPE_FLASH
*
*	L’arcade supporte 8 types de jeux. (Activity Mod, IBPro, Arcadelib,
*	V3Arcade, IBProV32, phpBB Arcade, Arcade room et jeux sans score)
*	Utiliser les constantes suivantes pour le type :
*
*	AMOD_GAME
*	AR_GAME
*	IBPRO_GAME
*	ARCADELIB_GAME
*	V3ARCADE_GAME
*	IBPROV3_GAME
*	PHPBBARCADE_GAME
*	NOSCORE_GAME
*
*	Les contrôles de jeu seront définis avec les constantes suivantes :
*
*	GAME_CONTROL_KEYBOARD_MOUSE
*	GAME_CONTROL_KEYBOARD
*	GAME_CONTROL_MOUSE
*
*	Utiliser la constante GAME_CONTROL_KEYBOARD_MOUSE quand le jeu est contrôlé par la souris et le clavier.
*	Utiliser la constante GAME_CONTROL_KEYBOARD quand le jeu est seulement contrôlé par le clavier.
*	Utiliser la constante GAME_CONTROL_MOUSE quand le jeu est seulement contrôlé par la souris.
*	Pour une description additionnelle ou un contrôle particulier du jeu, écrire dans le champ “game_control_desc”.
*
*	Les constantes suivantes gouvernent le scoretype :
*
*	SCORETYPE_HIGH
*	SCORETYPE_LOW
*
*	SCORETYPE_HIGH est pour les jeux dont le score le plus haut est
*	le meilleur score. SCORETYPE_LOW est pour les jeux dont le score
*	le plus bas est le meilleur score.
*/

// DEVELOPERS PLEASE NOTE modified - (\'game_name\', \'game_desc\', \'game_control_desc\')
//
// All install files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Some characters you may want to copy&amp;paste: ‚ ‘ ’ « » „ “ ” …

if (!defined(\'IN_PHPBB\') || !defined(\'IN_PHPBB_ARCADE\'))
{
	exit;
}

$game_file = basename(__FILE__, \'.\' . substr(strrchr(__FILE__, \'.\'), 1));

$game_data = array(
	\'game_name\'			=> \'Snake 3\',
	\'game_desc\'			=> \'Just another snake clone except this is part 2 lol!\',
	\'game_control\'		=> GAME_CONTROL_KEYBOARD,
	\'game_control_desc\'	=> \'\',
	\'game_image\'			=> $game_file . \'.gif\',
	\'game_swf\'			=> $game_file . \'.swf\',
	\'game_scorevar\'		=> $game_file,
	\'game_type\'			=> GAME_TYPE_HTML5,
	\'game_width\'			=> 320,
	\'game_height\'			=> 320,
	\'game_scoretype\'		=> SCORETYPE_HIGH
	\'game_save_type\'		=> PHPBBARCADE_GAME
);

?&gt;</textarea>',
	'ARCADE_ACP_HELP_FAQ_GAMES_INS_FILE_QUESTION'		=> 'Est-ce qu’il existe un fichier-modèle d’installation ?',

	'ARCADE_ACP_HELP_FAQ_GAMES_OWN_INS_FILE_ANSWER'		=> 'Non, bien que ce soit possible. Pour nous aider dans cette tâche, on dispose de deux outils dans l’ACP de phpBB Arcade.<br />
															<ul>
																<li>Le premier outil sert à créer un nouveau fichier d’installation à partir de rien. Il faut juste entrer les infos demandées et vous pourrez télécharger le fichier d’installation, ou bien l’afficher, ou bien le créer sur le serveur.</li>
																<li>Le second outil permet d’afficher ou de télécharger des fichiers d’installation existants à partir de jeux déjà installés.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_OWN_INS_FILE_QUESTION'	=> 'Doit-on créer le fichier d’installation à la main ?',

	'ARCADE_ACP_HELP_FAQ_GAMES_DELETE_ANSWER'			=> 'Vous pouvez supprimer des jeux à partir de la “Gestion de l’arcade” de l’ACP en passant par le module “Gérer les catégories”. Vous pouvez aussi utiliser le module “Gérer les jeux" et sélectionner un jeu à supprimer. Il est possible aussi de supprimer un jeu à partir de son édition. Dans tous les cas, vous aurez l’option de supprimer ou non les fichiers du serveur quand vous supprimerez un jeu. Pour que cette option soit réalisable, il faut vous assurer que vous avez bien les bonnes permissions pour pouvoir effacer des fichiers sur le serveur. N’utilisez cette option que si vous ne projetez pas de réinstaller le jeu.',
	'ARCADE_ACP_HELP_FAQ_GAMES_DELETE_QUESTION'			=> 'Comment supprimer des jeux ?',
// step 5
	'ARCADE_ACP_HELP_FAQ_MODULES_ANSWER'				=> '<strong><br />L’arcade comprend les modules ACP suivants :<br /></strong>
															<strong>Configuration</strong><br />
															<ul>
																<li><strong>Paramètres Généraux</strong> - Contrôler les paramètres généraux de l’arcade</li>
																<li><strong>Paramètres d'extensions</strong> - Control extensions settings for the arcade.</li>
																<li><strong>Paramètres des Jeux</strong> - Contrôler les paramètres des jeux de l’arcade</li>
																<li><strong>Paramètres des Défis</strong> - Contrôler les paramètres des Défis de l’arcade</li>
																<li><strong>Paramètres des Tournois</strong> - Contrôler les paramètres de tournoi de l’arcade.</li>
																<li><strong>Paramètres des Options</strong> - Contrôler les paramètres des options de l’arcade</li>
																<li><strong>Paramètres des pages Arcade</strong> - Contrôler les paramètres des pages de l’arcade</li>
																<li><strong>Paramètres des pages Défis</strong> - Contrôler les paramètres des pages des Défis</li>
																<li><strong>Paramètres des pages Tournois</strong> - Contrôler les paramètres des pages de tournoi.</li>
																<li><strong>Paramètres des Chemins</strong> - Contrôler les paramètres des chemins de l’arcade (Path)</li>
																<li><strong>Paramètres de Charge</strong> - Gérer les paramètres de charge de l’arcade</li>
															</ul><br />
															<strong>Gestion de l’Arcade</strong><br />
															<ul>
																<li><strong>Gestion du Menu</strong> - Ajouter ou éditer, supprimer des items du menu. On ne peut que déplacer ou renommer les boutons principaux du menu.</li>
																<li><strong>Gestion des Catégories</strong> - Ajouter, éditer, supprimer, déplacer et resynchroniser des catégories et des jeux</li>
																<li><strong>Gestion des Jeux</strong> - Editer, supprimer des jeux</li>
																<li><strong>Gestion des Utilisateurs</strong> - Editer les scores de chaque jeu</li>
																<li><strong>Gestion des Tournois</strong> - Editer, supprimer les tournois.</li>
																<li><strong>Gestion des Annonces</strong> - Paramètrer, éditer les annonces.</li>
																<li><strong>Gestion des Rangs</strong> - Ajouter, éditer et supprimer les rangs.</li>
															</ul><br />
															<strong>Gestion des Jeux</strong><br />
															<ul>
																<li><strong>Ajout de jeux</strong> - Ajouter un jeu à l’arcade. Plusieurs jeux peuvent être ajoutés en même temps à une catégorie.</li>
																<li><strong>Upload et dépaquetage des jeux</strong> - Uploader et dépaqueter des jeux compressés. Après dépaquetage, les jeux sont prêts à être intallés.</li>
																<li><strong>Sauvegarde de jeux</strong> - Sauvegarder tous les jeux des catégories sélectionnées (Backup)</li>
																<li><strong>Téléchargement de jeux</strong> - Télécharger des jeux à partir de sites qui hébergent des jeux compatibles avec l’arcade et qui autorisent leur téléchargement</li>
															</ul><br />
															<strong>Utilitaires</strong><br />
															<ul>
																<li><strong>Rapports de jeu</strong> - Voir les rapports de jeu que les joueurs ont enregistrés</li>
																<li><strong>Utilisateurs bannis</strong> - Voir les utilisateurs bannis. Les débannir.</li>
																<li><strong>Stats des téléchargements</strong> - Voir les statistiques du système de téléchargement</li>
																<li><strong>Fichier d’installation de jeu</strong> - Créer un nouveau fichier d’installation à télécharger/voir/sauvegarder sur le serveur ou bien télécharger/voir les fichiers d’installation de jeux déjà installés</li>
																<li><strong>Guide Utilisateur</strong> - Lire le Guide Utilisateur de l’arcade</li>
															</ul><br />
															<strong>Journaux de l’Arcade (Logs)</strong><br />
															<ul>
																<li><strong>Journal d’administration</strong> - Les actions des administrateurs sont listées ici.</li>
																<li><strong>Journal de modération</strong> - Les actions des modérateurs sont listées ici.</li>
																<li><strong>Journal des utilisateurs</strong> - Les actions des utilisateurs sont listées ici.</li>
																<li><strong>Journal des erreurs</strong> - Toutes sortes d’erreurs sont listées ici.</li>
															</ul><br />
															<strong>Modèles de permission</strong><br />
															<ul>
																<li><strong>Modèles de catégorie</strong> - Gèrer les modèles de permissions de catégorie arcade.</li>
															</ul><br />
															<strong>Permissions basiques de catégorie</strong><br />
															<ul>
																<li><strong>Permissions des catégories</strong> - Gérer les accès des utilisateurs et groupes aux catégories arcade.</li>
																<li><strong>Permissions arcade des utilisateurs</strong> - Assigner les permissions arcade aux utilisateurs.</li>
																<li><strong>Permissions arcade des groupes</strong> - Assigner les permissions arcade aux groupes.</li>
																<li><strong>Copie des permissions de catégories</strong> - Copier les permissions arcade d’une catégorie vers une ou plusieurs autres catégories.</li>
															</ul><br />
															<strong>Masques de permission</strong><br />
															<ul>
																<li><strong>Permissions basées sur les catégories</strong> - Voir les permissions arcade assignées aux utilisateurs/groupes et catégories sélectionnés.</li>
															</ul><br />
															<strong>Fonctions de l’installation</strong><br />
															<ul>
																<li><strong>Vérification de l’installation</strong> - Vérifie que phpBB Arcade est installé correctement.</li>
																<li><strong>Mise à jour des données de jeux</strong> - Détection et mise à jour automatique des tailles des jeux, si les données ne sont pas correctes.</li>
																<li><strong>Conversion des fichiers d’installation des jeux</strong> - Convertit les fichiers d’installation des jeux au dernier format.</li>
															</ul><br />
															<strong>L’arcade comprend les modules MCP suivants :</strong><br />
															<ul>
																<li><strong>Gestion des jeux</strong> - Editer, déplacer et réinitialiser un jeu.</li>
																<li><strong>Gestion de tournoi</strong> - Créer, éditer un tournoi.</li>
															</ul><br />
															<strong>L’arcade comprend les modules UCP suivants :</strong><br />
															<ul>
																<li><strong>Paramètres de gestion</strong> - Ces réglages contrôlent différents aspects de l’arcade.</li>
																<li><strong>Paramètres de messages</strong> - Ces options permettent la personnalisation des messages.</li>
																<li><strong>Gestion des jeux favoris</strong> - Permet de voir, mettre en surbrillance ou supprimer ses jeux favoris.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_MODULES_QUESTION'				=> 'Quels sont les modules ACP de phpBB Arcade ?',

	'ARCADE_ACP_HELP_FAQ_MODULES_AUTH_ANSWER'			=> 'Pour voir tous les modules, il faut avoir le statut de fondateur ou bien avoir les permissions d’administateur correctement définies. Si vous ne pouvez toujours pas voir tous les modules, c’est qu’il y a probablement des doublons dans les auth_option de la table acl_options de la base de données. Veuillez lancer le script-installateur puis cliquez sur l’onglet Vérifier et voyez s’il y a une liste de valeurs dupliquées qui s’affiche.',
	'ARCADE_ACP_HELP_FAQ_MODULES_AUTH_QUESTION'			=> 'Comment se fait-il que je ne peux pas voir tous les modules ACP de l’arcade ?',

	'ARCADE_ACP_HELP_FAQ_MODULES_ADD_AUTH_ANSWER'		=> 'Une fois que l’arcade sera installée, vous aurez besoin de définir les permissions pour son utilisation. L’arcade utilise les permissions basiques de catégorie, qui sont similaires aux permissions basiques des forums utilisées par phpBB3, y compris l’usage de modèles. Vous devrez, de la même façon que pour les forums, paramétrer les permissions globales d’arcade des utilisateurs et des groupes. Et, par ailleurs, vous pourrez aussi vous servir des permissions administrateur pour définir les accès utilisateur/groupe aux modules ACP de phpBB Arcade.',
	'ARCADE_ACP_HELP_FAQ_MODULES_ADD_AUTH_QUESTION'		=> 'Où se trouvent les permissions à paramétrer ? Pourquoi n’ai-je pas l’autorisation de voir et d’utiliser phpBB Arcade ?',

	'ARCADE_ACP_HELP_FAQ_MODULES_NO_GAMES_ANSWER'		=> 'Pour ajouter des jeux, vous devez d’abord vous assurer que vous avez bien créé les catégories pour les ranger. Pour ce faire, utiliser le module ACP <strong>Gestion de l’Arcade</strong>. On crée des catégories dans l’arcade de la même façon qu’on crée des forums avec phpBB3.',
	'ARCADE_ACP_HELP_FAQ_MODULES_NO_GAMES_QUESTION'		=> 'Pourquoi ne puis-je pas ajouter de jeux ?',

	'ARCADE_ACP_HELP_FAQ_MODULES_DOWNLOAD_ANSWER'		=> 'La possibilité de télécharger des jeux est subordonnée aux permissions arcade. Réglez les permissions à votre convenance. En parcourant l’arcade, les personnes (qui ont les droits) verront les liens de téléchargement tout simplement en regardant les jeux dans les catégories.<br />Pour faciliter le téléchargement de jeux, vous avez l’option d’activer la liste de téléchargements dans le paragraphe “Paramètres de téléchargement des jeux” du module “Paramètres généraux” de l’ACP de phpBB Arcade. Cela autorisera les autres à accéder aux jeux partagés de votre site directement à partir de leur site, en utilisant leur propre module ACP “Téléchargement de jeux".',
	'ARCADE_ACP_HELP_FAQ_MODULES_DOWNLOAD_QUESTION'		=> 'Comment permettre aux autres de télécharger sur mon site ?',

	'ARCADE_ACP_HELP_FAQ_MODULES_USE_DOWNLOAD_ANSWER'	=> 'La seule chose que vous ayez à faire est d’entrer l’url de l’endroit du site qui offre des téléchargements de jeux arcade à partir de sa propre installation de phpBB Arcade. Vous verrez alors la liste des jeux disponibles au téléchargement. Si un jeu est en surbrillance verte, c’est que le même jeu a été trouvé sur votre serveur. Veuillez garder à l’esprit que les téléchargements sont toujours contrôlés par les permissions. Et dans ce cas, ils sont contrôlés par celles définies sur le site qui vous propose des téléchargements. Il vous faut donc être logué sur le site et/ou faire partie d’un groupe spécial pour qui le téléchargement de jeux est autorisé. Contactez l’administrateur du site si vous avez des questions.<br /><br /><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/dev/images/acp_download_games.png"><img src="https://jv-arcade.com/dev/images/acp_download_games.png" width="300" alt="ACP Download games" title="ACP Download games" /></a>',
	'ARCADE_ACP_HELP_FAQ_MODULES_USE_DOWNLOAD_QUESTION'	=> 'Comment utiliser le module “Téléchargement de jeux” ?',

	'ARCADE_ACP_HELP_FAQ_MODULES_REQ_DOWNLOAD_ANSWER'	=> 'Pour que ce module fonctionne, il faut que la fonction <strong>“allow_url_fopen”</strong> soit active ou bien que la <strong>cURL library</strong> de PHP soit installée. Vous pouvez le vérifier en consultant le phpinfo() de votre serveur. Si la valeur pour <strong>“allow_url_fopen”</strong> est sur off et que la <strong>cURL library</strong> n’est pas installée alors le module ne marchera pas.',
	'ARCADE_ACP_HELP_FAQ_MODULES_REQ_DOWNLOAD_QUESTION'	=> 'Pourquoi le module “Téléchargement de jeux” ne trouve-t-il aucun jeu ?',

	'ARCADE_ACP_HELP_FAQ_MODULES_NO_FAV_ANSWER'			=> 'Le gadget des Jeux favoris n’est visible que si vous en avez la permission. Seuls les administrateurs peuvent changer les permissions.',
	'ARCADE_ACP_HELP_FAQ_MODULES_NO_FAV_QUESTION'		=> 'Comment se fait-il que je ne vois pas le module de mes Jeux favoris ?',
// step 6
	'ARCADE_ACP_HELP_FAQ_DATA_EXT_ANSWER'				=> 'Oui, il y a des extensions pour le logiciel phpBB Arcade - voir: <a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_Arcade_Extensions.html">Extensions</a>',
	'ARCADE_ACP_HELP_FAQ_DATA_EXT_QUESTION'				=> 'Existe-t-il des extensions ?'
));

