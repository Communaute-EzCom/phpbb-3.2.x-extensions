<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $request, $db, $auth, $user, $config, $shout, $php_ext, $shout_table, $posts_table;

	public function __construct($request, $db, $auth, $user, $config, $shout, $php_ext, $shout_table, $posts_table)
	{
		$this->request = $request;
		$this->db = $db;
		$this->auth = $auth;
		$this->user = $user;
		$this->config = $config;
		$this->shout = $shout;
		$this->php_ext = $php_ext;
		$this->shout_table = $shout_table;
		$this->posts_table = $posts_table;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.common'								=> 'common',
			'core.user_setup'							=> 'user_setup',
			'core.page_header'							=> 'header',
			'core.generate_smilies_after'				=> 'disable_extra_buttons',
			'core.display_custom_bbcodes'				=> 'disable_extra_buttons',
			'core.display_custom_bbcodes_modify_row'	=> 'custom_bbcodes',
			'core.submit_post_end'						=> 'submit_post_end',
			'core.delete_posts_after'					=> 'delete_posts_after',
			'core.delete_forum_content_before_query'	=> 'delete_forum_before',
			'core.permissions'							=> 'permissions_language',
			'core.viewonline_overwrite_location'		=> 'viewonline',
			'core.delete_user_after'					=> 'delete_user',

			'core.modify_posting_auth'					=> 'soft_delete_post',
			'core.mcp_global_f_read_auth_after'			=> 'soft_delete_post',
		);
	}

	public function common()
	{
		include($this->shout->ext_path('jv/shoutbox', true) . 'core/constants.' . $this->php_ext);
	}

	public function user_setup($event)
	{
		if ($this->config['jv_shoutbox_enable'])
		{
			$event['lang_set_ext'] = array_merge($event['lang_set_ext'], array(
				array(
					'ext_name' => 'jv/shoutbox',
					'lang_set' => 'shoutbox'
				)
			));
		}
	}

	public function header()
	{
		if (!$this->request->is_ajax() && $this->shout->enable())
		{
			$this->shout->header();

			if ($this->shout->active_page != 'custom' && $this->config['jv_shoutbox_page'] != JV_SHOUTBOX_DISPLAY_NONE && $this->check_page())
			{
				$this->shout->display();
			}
		}
	}

	public function disable_extra_buttons()
	{
		$this->shout->active_extra_buttons();
	}

	public function custom_bbcodes($event)
	{
		if (!$this->config['jv_shoutbox_custom_bbcode'] || !$this->auth->acl_get('u_jv_shoutbox_bbcode'))
		{
			return;
		}

		static $jvs_bbcode_allowed;

		if (!isset($jvs_bbcode_allowed))
		{
			$jvs_bbcode_allowed = explode("\n", $this->shout->text_config('jv_shoutbox_bbcode_allowed'));
		}

		if (!count($jvs_bbcode_allowed))
		{
			return;
		}

		if (in_array($event['row']['bbcode_tag'], $jvs_bbcode_allowed))
		{
			$this->shout->custom_bbcode = true;
			$event['custom_tags'] += array('S_JV_SHOUTBOX_ALLOW' => true);
		}
	}

	public function submit_post_end($event)
	{
		$post_data = $event['data'];

		if ($this->auth_add_message($event['mode'], $post_data['forum_id']))
		{
			if ($event['mode'] == 'post')
			{
				$lang_key = 'NEW_TOPIC';
			}
			else if ($event['mode'] == 'reply')
			{
				$lang_key = 'NEW_POST';
			}
			else if ($event['mode'] == 'quote')
			{
				$lang_key = 'NEW_POST_QUOTE';
			}
			else if ($event['mode'] == 'edit')
			{
				$lang_key = 'EDITED_POST';
			}

			if (!isset($lang_key))
			{
				return;
			}

			$user_id = $this->user->data['user_id'];
			if ($this->config['jv_shoutbox_user_id'])
			{
				$user_id = (int) $this->shout->author('user_id', $this->config['jv_shoutbox_user_id']);
			}
			else if (!empty($this->config['jv_system_bot_user_id']))
			{
				$user_id = (int) $this->shout->author('user_id', $this->config['jv_system_bot_user_id']);
			}

			if ($user_id)
			{
				$lang = array();
				$options = 0;
				$uid = $bitfield = '';
				$allow_bbcode = $allow_urls = $allow_smilies = true;

				if (empty($this->user->lang) || $this->user->data['user_lang'] != $this->config['default_lang'] && file_exists($this->shout->ext_path('jv/shoutbox', true) . "language/{$this->config['default_lang']}/shoutbox.{$this->php_ext}"))
				{
					include($this->shout->ext_path('jv/shoutbox', true) . "language/{$this->config['default_lang']}/shoutbox.{$this->php_ext}");
				}
				else
				{
					$lang = $this->user->lang;
				}

				$message = $this->prepare_msg($lang['JV_SHOUTBOX_F_' . $lang_key], $post_data);
				unset($lang);

				generate_text_for_storage($message, $uid, $bitfield, $options, $allow_bbcode, $allow_urls, $allow_smilies);

				$sql_ary = array(
					'user_id'			=> $user_id,
					'user_ip'			=> $this->user->ip,
					'message'			=> $message,
					'bbcode_bitfield'	=> $bitfield,
					'bbcode_uid'		=> $uid,
					'message_time'		=> time(),
					'post_id'			=> $post_data['post_id']
				);

				$sql = 'INSERT INTO ' . $this->shout_table . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
				$this->db->sql_query($sql);
			}
		}
	}

	public function delete_posts_after($event)
	{
		if (!isset($event['post_ids']) || !count($event['post_ids']))
		{
			return;
		}

		$sql = 'DELETE FROM ' . $this->shout_table . '
				WHERE ' . $this->db->sql_in_set('post_id', array_map('intval', $event['post_ids']));
		$this->db->sql_query($sql);

		if ($this->db->sql_affectedrows())
		{
			$this->config->set('jv_shoutbox_last_action_time', time(), false);
		}
	}

	public function delete_forum_before($event)
	{
		if (empty($event['forum_id']))
		{
			return;
		}

		$sql = 'SELECT post_id
				FROM ' . $this->posts_table . '
				WHERE forum_id = ' . (int) $event['forum_id'];
		$result = $this->db->sql_query($sql);
		$p = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$p['post_ids'][] = $row['post_id'];
		}
		$this->db->sql_freeresult($result);

		if (!empty($p['post_ids']))
		{
			$this->delete_posts_after($p);
		}
	}

	public function permissions_language($event)
	{
		$event['categories'] = array_merge($event['categories'], array(
			'jv_shoutbox' => 'ACL_CAT_JV_SHOUTBOX',
		));

		$event['permissions'] = array_merge($event['permissions'], array(
			// Admin Permissions
			'a_jv_shoutbox_settings'		=> array('lang' => 'ACL_A_JV_SHOUTBOX_SETTINGS'		, 'cat' => 'settings'),
			// Mod Permissions
			'm_jv_shoutbox_delete'			=> array('lang' => 'ACL_M_JV_SHOUTBOX_DELETE'		, 'cat' => 'jv_shoutbox'),
			'm_jv_shoutbox_edit'			=> array('lang' => 'ACL_M_JV_SHOUTBOX_EDIT'			, 'cat' => 'jv_shoutbox'),
			'm_jv_shoutbox_ip'				=> array('lang' => 'ACL_M_JV_SHOUTBOX_IP'			, 'cat' => 'jv_shoutbox'),
			// User Permissions
			'u_jv_shoutbox_view'			=> array('lang' => 'ACL_U_JV_SHOUTBOX_VIEW'			, 'cat' => 'jv_shoutbox'),
			'u_jv_shoutbox_use'				=> array('lang' => 'ACL_U_JV_SHOUTBOX_USE'			, 'cat' => 'jv_shoutbox'),
			'u_jv_shoutbox_delete'			=> array('lang' => 'ACL_U_JV_SHOUTBOX_DELETE'		, 'cat' => 'jv_shoutbox'),
			'u_jv_shoutbox_edit'			=> array('lang' => 'ACL_U_JV_SHOUTBOX_EDIT'			, 'cat' => 'jv_shoutbox'),
			'u_jv_shoutbox_quote'			=> array('lang' => 'ACL_U_JV_SHOUTBOX_QUOTE'		, 'cat' => 'jv_shoutbox'),
			'u_jv_shoutbox_flood_ignore'	=> array('lang' => 'ACL_U_JV_SHOUTBOX_FLOOD_IGNORE'	, 'cat' => 'jv_shoutbox'),
			'u_jv_shoutbox_bbcode'			=> array('lang' => 'ACL_U_JV_SHOUTBOX_BBCODE'		, 'cat' => 'jv_shoutbox'),
			'u_jv_shoutbox_smilies'			=> array('lang' => 'ACL_U_JV_SHOUTBOX_SMILIES'		, 'cat' => 'jv_shoutbox')
		));
	}

	public function viewonline($event)
	{
		if ($this->shout->enable())
		{
			$this->shout->viewonline($event);
		}
	}

	public function delete_user($event)
	{
		$sql = 'DELETE FROM ' . $this->shout_table . '
				WHERE ' . $this->db->sql_in_set('user_id', array_map('intval', $event['user_ids']));
		$this->db->sql_query($sql);

		$this->config->set('jv_shoutbox_last_action_time', time(), false);
	}

	public function soft_delete_post($event)
	{
		if ($this->request->is_set_post('confirm'))
		{
			$action = $this->request->variable('action', '');
			$forum_id = (int) $this->request->variable('f', 0);
			$soft_delete = (!$this->request->is_set_post('delete_permanent') || !$this->auth->acl_get('m_delete', $forum_id)) ? true : false;

			if (($soft_delete && ($action == 'delete_topic' || $action == 'delete_post')) ||
				(!empty($event['mode']) && $event['mode'] == 'soft_delete' && !empty($event['post_id']) && !count($event['error']))
			)
			{
				$this->config->set('jv_shoutbox_last_action_time', time(), false);
			}
		}
	}

	private function check_page()
	{
		$r = false;
		$page = $this->shout->user_page();
		$params = $this->shout->user_page(false, true);

		if (($page == 'portal' && (($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_PORTAL) || $this->shout->is_enabled_ext('jv/shoutbox_b3portal'))) ||
			($page == 'arcade' && $this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_ARCADE)
		)
		{
			return $r;
		}

		if (($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_ALL_PAGES) ||
			($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_PORTAL && $page != 'portal') ||
			($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_ARCADE && $page != 'arcade') ||
			(!$params && (
			($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_FORUM && $page == 'index') ||
			($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_ARCADE && $page == 'arcade') ||
			($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_ALL_MAIN_PAGES && in_array($page, array('portal', 'index', 'arcade'))))) ||
			($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_PORTAL && $page == 'portal') ||
			($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_FORUM_ALL && !in_array($page, array('portal', 'arcade'))) ||
			($this->config['jv_shoutbox_page'] == JV_SHOUTBOX_DISPLAY_ARCADE_ALL && $page == 'arcade')
		)
		{
			$r = true;
		}

		return $r;
	}

	private function auth_add_message($mode, $forum_id)
	{
		$r = false;

		if ($this->config['jv_shoutbox_enable'] && $this->shout->enable_forum_post())
		{
			if (($mode == 'post' && $this->config['jv_shoutbox_new_topic_post']) ||
				($mode == 'reply' && $this->config['jv_shoutbox_new_reply_post']) ||
				($mode == 'quote' && $this->config['jv_shoutbox_new_reply_quote_post']) ||
				($mode == 'edit' && $this->config['jv_shoutbox_edit_post'])
			)
			{
				$ign_forum_ids = explode(',', $this->shout->text_config('jv_shoutbox_post_ign_forums'));

				if (!in_array($forum_id, $ign_forum_ids))
				{
					$r = true;
				}
			}
		}

		return $r;
	}

	private function prepare_msg($text, $data)
	{
		$bu = $this->shout->board_url();

		$text = utf8_normalize_nfc($text);
		$forum_name = '[url=' . $bu . 'viewforum.' . $this->php_ext . '?f=%7BFORUM_ID%7D]%7BFORUM_NAME%7D[/url]';
		$topic_title = '[url=' . $bu . 'viewtopic.' . $this->php_ext . '?p=' . $data['post_id'] . '#p' . $data['post_id'] . ']%7BTOPIC_TITLE%7D[/url]';
		$username = ($this->user->data['user_colour']) ? '[color=#' . $this->user->data['user_colour'] . ']' . $this->user->data['username'] . '[/color]' : $this->user->data['username'];
		$username = ($this->user->data['user_type'] <> USER_IGNORE) ? '[url=' . $bu . 'memberlist.' . $this->php_ext . '?mode=viewprofile&u=' . $this->user->data['user_id'] . ']' . $username . '[/url]' : $username;

		return sprintf($text, $forum_name, $topic_title, $username);
	}
}
