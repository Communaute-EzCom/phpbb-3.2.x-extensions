<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\migrations;

class v_1_0_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\shoutbox\migrations\v_1_0_0_RC2');
	}

	public function update_schema()
	{
		return array(
			'add_columns'	=> array("{$this->table_prefix}jv_shoutbox" => array(
				'topic_id'	=> array('UINT', 0),
				'hide_msg'	=> array('TINT:1', 0)
			)),
			'add_index'		=> array(
				"{$this->table_prefix}jv_shoutbox" => array(
					'user_id'	=> array('user_id'),
					'forum_id'	=> array('forum_id'),
					'topic_id'	=> array('topic_id'),
					'post_id'	=> array('post_id')
			))
		);
	}

	public function update_data()
	{
		return array(
			// install phpbb config
			array('config.add', array('jv_shoutbox_user_id', '')),
			array('config_text.add', array('jv_shoutbox_post_ign_forums', '')),
		);
	}
}
