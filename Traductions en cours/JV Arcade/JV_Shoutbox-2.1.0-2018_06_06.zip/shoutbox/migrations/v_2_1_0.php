<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\migrations;

class v_2_1_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\shoutbox\migrations\v_1_1_0');
	}

	public function update_data()
	{
		return array(
			// install phpbb config
			array('config.add', array('jv_shoutbox_prune_last_gc', time(), true)),
			array('config.add', array('jv_shoutbox_prune_gc', 604800)),
			array('config.remove', array('jv_shoutbox_prune_time')),
			array('config.remove', array('jv_shoutbox_last_prune_time')),
		);
	}
}
