<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\migrations;

class v_1_0_0_RC1 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v310\extensions');
	}

	public function update_schema()
	{
		return array(
			'add_tables'	=> array(
				$this->table_prefix . 'jv_shoutbox' => array(
					'COLUMNS'	=> array(
						'shout_id'		=> array('UINT', NULL, 'auto_increment'),
						'user_id'			=> array('UINT', 0),
						'user_ip'			=> array('VCHAR:40', ''),
						'message'			=> array('MTEXT_UNI', ''),
						'bbcode_bitfield'	=> array('VCHAR', ''),
						'bbcode_uid'		=> array('VCHAR:8', ''),
						'message_time'		=> array('INT:11', 0),
						'edit_count'		=> array('TINT:3', 0),
						'forum_id'			=> array('UINT', 0),
						'post_id'			=> array('UINT', 0)
					),
					'PRIMARY_KEY'	=> 'shout_id'
				)
			)
		);
	}

	public function revert_schema()
	{
		return array('drop_tables' => array($this->table_prefix . 'jv_shoutbox'));
	}

	public function update_data()
	{
		$sql = 'SELECT role_name
				FROM ' . ACL_ROLES_TABLE;
		$result = $this->sql_query($sql);
		$roles = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$roles[] = $row['role_name'];
		}
		$this->db->sql_freeresult($result);

		return array(
			// install phpbb config
			array('config.add', array('jv_shoutbox_enable', 1)),
			array('config.add', array('jv_shoutbox_custom_page', 1)),
			array('config.add', array('jv_shoutbox_page', 1)),
			array('config.add', array('jv_shoutbox_location', 1)),
			array('config.add', array('jv_shoutbox_height', 250)),
			array('config.add', array('jv_shoutbox_msg_limit', 10)),
			array('config.add', array('jv_shoutbox_refresh', 10)),
			array('config.add', array('jv_shoutbox_msg_position', 1)),
			array('config.add', array('jv_shoutbox_new_topic_post', 0)),
			array('config.add', array('jv_shoutbox_new_reply_post', 0)),
			array('config.add', array('jv_shoutbox_new_reply_quote_post', 0)),
			array('config.add', array('jv_shoutbox_edit_post', 0)),
			array('config.add', array('jv_shoutbox_prune', 0)),
			array('config.add', array('jv_shoutbox_prune_time', 7)),
			array('config.add', array('jv_shoutbox_prune_msg_num', 50)),
			array('config.add', array('jv_shoutbox_flood_time', 3)),
			array('config.add', array('jv_shoutbox_avatar', 1)),
			array('config.add', array('jv_shoutbox_msg_charsmin', 1)),
			array('config.add', array('jv_shoutbox_msg_charsmax', 1000)),
			array('config.add', array('jv_shoutbox_date_format', 'Y.m.d. H:i')),
			array('config.add', array('jv_shoutbox_smilie_enable', 1)),
			array('config.add', array('jv_shoutbox_custom_bbcode', 0)),
			array('config.add', array('jv_shoutbox_last_prune_time', time(), true)),
			array('config.add', array('jv_shoutbox_last_action_time', time(), true)),
			array('config_text.add', array('jv_shoutbox_bbcode_allowed', "b\ni\nu\nurl\ncolor\nquote\nsize\nimg\ncode")),
			// install acp global permissions
			array('permission.add', array('a_jv_shoutbox_settings')),
			// install mcp global permissions
			array('permission.add', array('m_jv_shoutbox_delete')),
			array('permission.add', array('m_jv_shoutbox_edit')),
			array('permission.add', array('m_jv_shoutbox_ip')),
			// install ucp global permissions
			array('permission.add', array('u_jv_shoutbox_view')),
			array('permission.add', array('u_jv_shoutbox_use')),
			array('permission.add', array('u_jv_shoutbox_delete')),
			array('permission.add', array('u_jv_shoutbox_edit')),
			array('permission.add', array('u_jv_shoutbox_quote')),
			array('permission.add', array('u_jv_shoutbox_flood_ignore')),
			array('permission.add', array('u_jv_shoutbox_bbcode')),
			array('permission.add', array('u_jv_shoutbox_smilies')),
			// install admin permissions set
			array('if', array(
				(in_array('ROLE_ADMIN_FULL', $roles)),
				array('permission.permission_set', array('ROLE_ADMIN_FULL', array('a_jv_shoutbox_settings')))
			)),
			array('if', array(
				(in_array('ROLE_ADMIN_STANDARD', $roles)),
				array('permission.permission_set', array('ROLE_ADMIN_STANDARD', array('a_jv_shoutbox_settings')))
			)),
			// install mod permissions set
			array('if', array(
				(in_array('ROLE_MOD_FULL', $roles)),
				array('permission.permission_set', array('ROLE_MOD_FULL', array('m_jv_shoutbox_delete', 'm_jv_shoutbox_edit', 'm_jv_shoutbox_ip')))
			)),
			array('if', array(
				(in_array('ROLE_MOD_STANDARD', $roles)),
				array('permission.permission_set', array('ROLE_MOD_STANDARD', array('m_jv_shoutbox_delete', 'm_jv_shoutbox_edit', 'm_jv_shoutbox_ip')))
			)),
			// install user permissions set
			array('if', array(
				(in_array('ROLE_USER_FULL', $roles)),
				array('permission.permission_set', array('ROLE_USER_FULL', array('u_jv_shoutbox_view', 'u_jv_shoutbox_use', 'u_jv_shoutbox_delete', 'u_jv_shoutbox_edit', 'u_jv_shoutbox_quote', 'u_jv_shoutbox_flood_ignore', 'u_jv_shoutbox_bbcode', 'u_jv_shoutbox_smilies')))
			)),
			array('if', array(
				(in_array('ROLE_USER_STANDARD', $roles)),
				array('permission.permission_set', array('ROLE_USER_STANDARD', array('u_jv_shoutbox_view', 'u_jv_shoutbox_use', 'u_jv_shoutbox_edit', 'u_jv_shoutbox_quote', 'u_jv_shoutbox_bbcode', 'u_jv_shoutbox_smilies')))
			)),
			array('if', array(
				(in_array('ROLE_USER_LIMITED', $roles)),
				array('permission.permission_set', array('ROLE_USER_LIMITED', array('u_jv_shoutbox_view', 'u_jv_shoutbox_use')))
			)),
			array('if', array(
				(in_array('ROLE_USER_NOPM', $roles)),
				array('permission.permission_set', array('ROLE_USER_NOPM', array('u_jv_shoutbox_view', 'u_jv_shoutbox_use', 'u_jv_shoutbox_edit', 'u_jv_shoutbox_quote', 'u_jv_shoutbox_bbcode', 'u_jv_shoutbox_smilies')))
			)),
			array('if', array(
				(in_array('ROLE_USER_NOAVATAR', $roles)),
				array('permission.permission_set', array('ROLE_USER_NOAVATAR', array('u_jv_shoutbox_view', 'u_jv_shoutbox_use', 'u_jv_shoutbox_edit', 'u_jv_shoutbox_quote', 'u_jv_shoutbox_bbcode', 'u_jv_shoutbox_smilies')))
			)),

			array('if', array(
				(in_array('ROLE_USER_NEW_MEMBER', $roles)),
				array('permission.permission_set', array('ROLE_USER_NEW_MEMBER', array('u_jv_shoutbox_view', 'u_jv_shoutbox_use')))
			)),
			// install acp modules
			array('module.add', array(
				'acp', 'ACP_CAT_DOT_MODS', 'ACP_CAT_JV_SHOUTBOX_SETTINGS'
			)),
			array('module.add', array(
				'acp', 'ACP_CAT_JV_SHOUTBOX_SETTINGS', array(
					'module_basename'	=> '\jv\shoutbox\acp\settings_module',
					'modes'				=> array('settings')
				)
			))
		);
	}
}
