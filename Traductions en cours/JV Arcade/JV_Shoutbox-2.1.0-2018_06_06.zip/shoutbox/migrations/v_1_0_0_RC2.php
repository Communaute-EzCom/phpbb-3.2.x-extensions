<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\migrations;

class v_1_0_0_RC2 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\shoutbox\migrations\v_1_0_0_RC1');
	}

	public function update_data()
	{
		return array(
			// install phpbb config
			array('config.add', array('jv_shoutbox_max_msg_limit', 500)),
			array('config.add', array('jv_shoutbox_custom_page_popup', 1)),
			array('config.add', array('jv_shoutbox_custom_page_popup_width', 1000)),
			array('config.add', array('jv_shoutbox_custom_page_popup_height', 600)),
			array('config.add', array('jv_shoutbox_custom_page_onlinelist', 1)),
			array('config.add', array('jv_shoutbox_smilie_scroll_box', 1)),
			array('config.add', array('jv_shoutbox_round_avatar', 0)),
		);
	}
}
