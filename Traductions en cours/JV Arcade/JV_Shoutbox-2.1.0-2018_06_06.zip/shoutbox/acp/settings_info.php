<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\acp;

class settings_info
{
	function module()
	{
		return array(
			'filename'	=> '\jv\shoutbox\acp\settings_module',
			'title'		=> 'ACP_JV_SHOUTBOX',
			'modes'		=> array(
				'settings'	=> array('title'=> 'ACP_JV_SHOUTBOX_SETTINGS', 'auth' => 'ext_jv/shoutbox && acl_a_jv_shoutbox_settings', 'cat' => array('ACP_CAT_JV_SHOUTBOX_SETTINGS'))
			)
		);
	}
}
