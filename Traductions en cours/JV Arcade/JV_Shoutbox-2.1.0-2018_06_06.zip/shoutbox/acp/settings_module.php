<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\acp;

class settings_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $container, $db, $config, $user, $request, $template, $log, $root_path, $php_ext;
	protected $config_text, $shout, $shout_table;

	public function __construct()
	{
		global $phpbb_container, $db, $config, $user, $request, $template, $phpbb_log, $phpbb_root_path, $phpEx;

		$this->container = $phpbb_container;
		$this->db = $db;
		$this->config = $config;
		$this->user = $user;
		$this->request = $request;
		$this->template = $template;
		$this->log = $phpbb_log;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;

		$this->config_text = $this->container->get('config_text');
		$this->shout = $this->container->get('jv.shoutbox');
		$this->shout_table = $this->container->getParameter('jv.shoutbox.table');
	}

	public function main($id, $mode)
	{
		$error = array();
		$submit = $this->request->is_set_post('submit');

		switch ($mode)
		{
			case 'settings':
				if ($this->request->is_set_post('jv_shoutbox_delete_messages'))
				{
					if (confirm_box(true))
					{
						switch ($this->db->get_sql_layer())
						{
							case 'sqlite3':
								$this->db->sql_query('DELETE FROM ' . $this->shout_table);
							break;

							default:
								$this->db->sql_query('TRUNCATE TABLE ' . $this->shout_table);
							break;
						}

						$this->config->set('jv_shoutbox_last_action_time', time(), false);

						$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_JV_SHOUTBOX_DELETE_MESSAGES');
						trigger_error($this->user->lang['ACP_JV_SHOUTBOX_DELETE_MESSAGES_SUCCESS'] . adm_back_link($this->u_action));
					}
					else
					{
						confirm_box(false, 'ACP_JV_SHOUTBOX_DELETE_MESSAGES', build_hidden_fields(array(
							'i'		=> $id,
							'mode'	=> $mode,
							'jv_shoutbox_delete_messages' => true
						)));
					}
				}

				$this->user->add_lang('acp/board');

				$form_key = 'acp_board';
				add_form_key($form_key);

				$this->config['jv_shoutbox_prune_gc'] = $this->config['jv_shoutbox_prune_gc'] / 86400;

				$this->new_config = clone $this->config;
				$cfg_array = (isset($_REQUEST['config'])) ? $this->request->variable('config', array('' => ''), true) : $this->new_config;

				switch ($mode)
				{
					case 'settings':
						$display_vars = array(
							'title'	=> 'ACP_JV_SHOUTBOX_SETTINGS',
							'vars'	=> array(
								'legend1'								=> 'ACP_JV_SHOUTBOX_SETTINGS',
								'jv_shoutbox_enable'					=> array('lang' => 'ACP_JV_SHOUTBOX_ENABLE',					'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_custom_page'				=> array('lang' => 'ACP_JV_SHOUTBOX_CUSTOM_PAGE',				'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_custom_page_onlinelist'	=> array('lang' => 'ACP_JV_SHOUTBOX_CUSTOM_PAGE_ONLINE_LIST',	'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_custom_page_popup'			=> array('lang' => 'ACP_JV_SHOUTBOX_CUSTOM_PAGE_POPUP',			'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_custom_page_popup_width'	=> array('lang' => 'ACP_JV_SHOUTBOX_CUSTOM_PAGE_POPUP_WIDTH',	'validate' => 'int:400',		'type' => 'number:400',		'explain' => true),
								'jv_shoutbox_custom_page_popup_height'	=> array('lang' => 'ACP_JV_SHOUTBOX_CUSTOM_PAGE_POPUP_HEIGHT',	'validate' => 'int:200',		'type' => 'number:200',		'explain' => true),
								'jv_shoutbox_page'						=> array('lang' => 'ACP_JV_SHOUTBOX_PAGE',						'validate' => 'int:0:9',		'type' => 'select',			'explain' => true,	'method' => 'jv_shoutbox_page'),
								'jv_shoutbox_location'					=> array('lang' => 'ACP_JV_SHOUTBOX_LOCATION',					'validate' => 'int:1:2',		'type' => 'custom',			'explain' => true,	'method' => 'jv_shoutbox_position'),
								'jv_shoutbox_height'					=> array('lang' => 'ACP_JV_SHOUTBOX_HEIGHT',					'validate' => 'int:130:500',	'type' => 'number:130:500',	'explain' => true,	'append' => ' ' . $this->user->lang['PIXEL']),
								'jv_shoutbox_msg_limit'					=> array('lang' => 'ACP_JV_SHOUTBOX_MSG_LIMIT',					'validate' => "int:5:100",		'type' => "number:5:100",	'explain' => true),
								'jv_shoutbox_max_msg_limit'				=> array('lang' => 'ACP_JV_SHOUTBOX_MAX_MSG_LIMIT',				'validate' => 'int:0',			'type' => 'number:0',		'explain' => true),
								'jv_shoutbox_refresh'					=> array('lang' => 'ACP_JV_SHOUTBOX_REFRESH',					'validate' => 'int:3:60',		'type' => 'number:3:60',	'explain' => true,	'append' => ' ' . $this->user->lang['SECONDS']),
								'jv_shoutbox_prune'						=> array('lang' => 'ACP_JV_SHOUTBOX_PRUNE',						'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_prune_gc'					=> array('lang' => 'ACP_JV_SHOUTBOX_PRUNE_TIME',				'validate' => 'int:1:31',		'type' => 'number:1:31',	'explain' => true,	'append' => ' ' . $this->user->lang['DAYS']),
								'jv_shoutbox_prune_msg_num'				=> array('lang' => 'ACP_JV_SHOUTBOX_PRUNE_MSG_NUM',				'validate' => 'int:10:500',		'type' => 'number:10:500',	'explain' => true),

								'legend2'								=> 'ACP_JV_SHOUTBOX_MSG_SETTINGS',
								'jv_shoutbox_msg_position'				=> array('lang' => 'ACP_JV_SHOUTBOX_MSG_POSITION',				'validate' => 'int:1:2',		'type' => 'custom',			'explain' => true,	'method' => 'jv_shoutbox_position'),
								'jv_shoutbox_avatar'					=> array('lang' => 'ACP_JV_SHOUTBOX_AVATAR',					'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_round_avatar'				=> array('lang' => 'ACP_JV_SHOUTBOX_ROUND_AVATAR',				'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_msg_charsmin'				=> array('lang' => 'ACP_JV_SHOUTBOX_MSG_MIN_CHARS',				'validate' => 'int:1:999999',	'type' => 'number:1:999999','explain' => true),
								'jv_shoutbox_msg_charsmax'				=> array('lang' => 'ACP_JV_SHOUTBOX_MSG_MAX_CHARS',				'validate' => 'int:0:999999',	'type' => 'number:0:999999','explain' => true),
								'jv_shoutbox_flood_time'				=> array('lang' => 'ACP_JV_SHOUTBOX_FLOOD_TIME',				'validate' => 'int:0:60',		'type' => 'number:0:60',	'explain' => true,	'append' => ' ' . $this->user->lang['SECONDS']),
								'jv_shoutbox_date_format'				=> array('lang' => 'ACP_JV_SHOUTBOX_DATE_FORMAT',				'validate' => 'string:1:30',	'type' => 'text:28:30',		'explain' => true),
								'jv_shoutbox_smilie_enable'				=> array('lang' => 'ACP_JV_SHOUTBOX_SMILIE_ENABLE',				'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_smilie_scroll_box'			=> array('lang' => 'ACP_JV_SHOUTBOX_SMILIE_SCROLL_BOX',			'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_custom_bbcode'				=> array('lang' => 'ACP_JV_SHOUTBOX_CUSTOM_BBCODE',				'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_bbcode_allowed'			=> array('lang' => 'ACP_JV_SHOUTBOX_BBCODE_ALLOWED',											'type' => 'custom',			'explain' => true,	'method' => 'bbcode_allowed'),

								'legend3'								=> 'ACP_JV_SHOUTBOX_FORUM_POST_SETTINGS',
								'jv_shoutbox_user_id'					=> array('lang' => 'ACP_JV_SHOUTBOX_AUTHOR',					'validate' => 'string', 		'type' => 'custom',			'explain' => true,	'method' => 'author_user_id'),
								'jv_shoutbox_new_topic_post'			=> array('lang' => 'ACP_JV_SHOUTBOX_NEW_TOPIC_POST',			'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_new_reply_post'			=> array('lang' => 'ACP_JV_SHOUTBOX_NEW_REPLY_POST',			'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_new_reply_quote_post'		=> array('lang' => 'ACP_JV_SHOUTBOX_NEW_REPLY_QUOTE_POST',		'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_edit_post'					=> array('lang' => 'ACP_JV_SHOUTBOX_EDIT_POST',					'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true),
								'jv_shoutbox_post_ign_forums'			=> array('lang' => 'ACP_JV_SHOUTBOX_POST_IGNORE_FORUMS',										'type' => 'custom',			'explain' => true,	'method' => 'select_exclude_forums'),

								'legend4'								=> 'ACP_JV_SHOUTBOX_DELETE_MESSAGES',
								'jv_shoutbox_delete_messages'			=> array('lang' => 'ACP_JV_SHOUTBOX_DELETE_MESSAGES',											'type' => 'custom',			'explain' => true,	'method' => 'delete_messages'),

								'legend5'								=> 'ACP_SUBMIT_CHANGES',
							)
						);
					break;

					default:
						trigger_error('NO_MODE', E_USER_ERROR);
					break;
				}

				if (isset($display_vars['lang']))
				{
					$this->user->add_lang($display_vars['lang']);
				}

				validate_config_vars($display_vars['vars'], $cfg_array, $error);

				if ($submit && !check_form_key($form_key))
				{
					$error[] = $this->user->lang['FORM_INVALID'];
				}

				$min_msg_limit = round($cfg_array['jv_shoutbox_height']/30);

				if ($cfg_array['jv_shoutbox_msg_limit'] < $min_msg_limit)
				{
					$error[] = $this->user->lang('ACP_JV_SHOUTBOX_HEIGHT_ERROR', $min_msg_limit);
				}

				if ($cfg_array['jv_shoutbox_max_msg_limit'] && $cfg_array['jv_shoutbox_max_msg_limit'] < $cfg_array['jv_shoutbox_msg_limit'])
				{
					$error[] = $this->user->lang('ACP_JV_SHOUTBOX_MIN_MAX_ERROR', $this->user->lang['ACP_JV_SHOUTBOX_MAX_MSG_LIMIT'], $this->user->lang['ACP_JV_SHOUTBOX_MSG_LIMIT']);
				}

				if ($cfg_array['jv_shoutbox_prune_msg_num'] < $cfg_array['jv_shoutbox_msg_limit'])
				{
					$error[] = $this->user->lang('ACP_JV_SHOUTBOX_MIN_MAX_ERROR', $this->user->lang['ACP_JV_SHOUTBOX_PRUNE_MSG_NUM'], $this->user->lang['ACP_JV_SHOUTBOX_MSG_LIMIT']);
				}

				if ($cfg_array['jv_shoutbox_user_id'])
				{
					if (!($cfg_array['jv_shoutbox_user_id'] = $this->shout->author('user_id', (is_numeric($cfg_array['jv_shoutbox_user_id'])) ? $cfg_array['jv_shoutbox_user_id'] : false, (is_numeric($cfg_array['jv_shoutbox_user_id'])) ? false : $cfg_array['jv_shoutbox_user_id'])))
					{
						$error[] = $this->user->lang['NO_USER'];
					}
				}

				if (count($error))
				{
					$submit = false;
				}

				$cfg_array['jv_shoutbox_post_ign_forums'] = '';
				if ($shoutbox_exclude_forums = $this->request->variable('jv_shoutbox_post_ign_forums', array(0)))
				{
					foreach ($shoutbox_exclude_forums as $forum_id)
					{
						$forum_id = (int) $forum_id;

						if (!$forum_id)
						{
							continue;
						}

						$cfg_array['jv_shoutbox_post_ign_forums'] .= (($cfg_array['jv_shoutbox_post_ign_forums'] != '') ? ',' : '') . $forum_id;
					}
				}

				foreach ($display_vars['vars'] as $config_name => $data)
				{
					if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false || $config_name == 'jv_shoutbox_delete_messages')
					{
						continue;
					}

					$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

					if ($submit)
					{
						if ($config_name == 'jv_shoutbox_prune_gc')
						{
							$config_value = intval($config_value * 86400);
						}

						if ($config_name == 'jv_shoutbox_bbcode_allowed')
						{
							$config_value = array_filter(array_unique(explode("\n", $config_value)));
							$this->config_text->set($config_name, implode("\n", str_replace(' ', '', $config_value)));
						}
						else if ($config_name == 'jv_shoutbox_post_ign_forums')
						{
							$this->config_text->set($config_name, $config_value);
						}
						else
						{
							$this->config->set($config_name, $config_value);
						}
					}
				}

				if ($submit)
				{
					$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_JV_SHOUTBOX_CONFIG_' . strtoupper($mode));
					trigger_error($this->user->lang('CONFIG_UPDATED') . adm_back_link($this->u_action), E_USER_NOTICE);
				}

				$this->tpl_name = 'acp_board';
				$this->page_title = $display_vars['title'];

				$this->template->assign_vars(array(
					'L_TITLE'			=> $this->user->lang[$display_vars['title']],
					'L_TITLE_EXPLAIN'	=> $this->user->lang[$display_vars['title'] . '_EXPLAIN'],

					'S_ERROR'			=> (count($error)) ? true : false,
					'ERROR_MSG'			=> implode('<br>', $error),

					'U_ACTION'			=> $this->u_action
				));

				foreach ($display_vars['vars'] as $config_key => $vars)
				{
					if (!is_array($vars) && strpos($config_key, 'legend') === false)
					{
						continue;
					}

					if (strpos($config_key, 'legend') !== false)
					{
						$this->template->assign_block_vars('options', array(
							'S_LEGEND'	=> true,
							'LEGEND'	=> (isset($this->user->lang[$vars])) ? $this->user->lang[$vars] : $vars
						));

						continue;
					}

					$type = explode(':', $vars['type']);

					$l_explain = '';
					if ($vars['explain'] && isset($vars['lang_explain']))
					{
						$l_explain = (isset($this->user->lang[$vars['lang_explain']])) ? $this->user->lang[$vars['lang_explain']] : $vars['lang_explain'];
					}
					else if ($vars['explain'])
					{
						$l_explain = (isset($this->user->lang[$vars['lang'] . '_EXPLAIN'])) ? $this->user->lang[$vars['lang'] . '_EXPLAIN'] : '';
					}

					$content = build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars);

					if (empty($content))
					{
						continue;
					}

					$this->template->assign_block_vars('options', array(
						'KEY'			=> $config_key,
						'TITLE'			=> (isset($this->user->lang[$vars['lang']])) ? $this->user->lang[$vars['lang']] : $vars['lang'],
						'S_EXPLAIN'		=> $vars['explain'],
						'TITLE_EXPLAIN'	=> $l_explain,
						'CONTENT'		=> $content
					));

					unset($display_vars['vars'][$config_key]);
				}
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}
	}

	public function jv_shoutbox_page($value, $key = '')
	{
		$options_ary = array(
			JV_SHOUTBOX_DISPLAY_NONE					=> 'ACP_JV_SHOUTBOX_DISPLAY_NONE',
			JV_SHOUTBOX_DISPLAY_FORUM					=> 'ACP_JV_SHOUTBOX_DISPLAY_FORUM',
			JV_SHOUTBOX_DISPLAY_FORUM_ALL				=> 'ACP_JV_SHOUTBOX_DISPLAY_FORUM_ALL',
			JV_SHOUTBOX_DISPLAY_ARCADE					=> 'ACP_JV_SHOUTBOX_DISPLAY_ARCADE',
			JV_SHOUTBOX_DISPLAY_ARCADE_ALL				=> 'ACP_JV_SHOUTBOX_DISPLAY_ARCADE_ALL',
			JV_SHOUTBOX_DISPLAY_PORTAL					=> 'ACP_JV_SHOUTBOX_DISPLAY_PORTAL',
			JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_PORTAL	=> 'ACP_JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_PORTAL',
			JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_ARCADE	=> 'ACP_JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_ARCADE',
			JV_SHOUTBOX_DISPLAY_ALL_MAIN_PAGES			=> 'ACP_JV_SHOUTBOX_DISPLAY_ALL_MAIN_PAGES',
			JV_SHOUTBOX_DISPLAY_ALL_PAGES				=> 'ACP_JV_SHOUTBOX_DISPLAY_ALL_PAGES'
		);

		$all = 0;
		if ($this->shout->is_enabled_ext('jv/shoutbox_b3portal') || (!$this->shout->is_enabled_ext('board3/portal') && !$this->shout->is_enabled_ext('stoker/portal') && !$this->shout->is_enabled_ext('phpbbireland/portal')))
		{
			$all++;
			unset($options_ary[JV_SHOUTBOX_DISPLAY_PORTAL], $options_ary[JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_PORTAL]);
		}

		if (!$this->shout->is_enabled_ext('jv/arcade'))
		{
			$all++;
			unset($options_ary[JV_SHOUTBOX_DISPLAY_ARCADE], $options_ary[JV_SHOUTBOX_DISPLAY_ARCADE_ALL], $options_ary[JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_ARCADE]);
		}

		if ($all == 2)
		{
			unset($options_ary[JV_SHOUTBOX_DISPLAY_ALL_MAIN_PAGES]);
		}

		return build_select($options_ary, $value);
	}

	public function jv_shoutbox_position($value, $key)
	{
		return h_radio("config[$key]", array(
			1 => 'ACP_JV_SHOUTBOX_POSITION_TOP',
			2 => 'ACP_JV_SHOUTBOX_POSITION_BOTTOM'
		), $value, $key);
	}

	public function select_exclude_forums($value, $key)
	{
		$forum_list = make_forum_select(false, false, true, true, true, false, true);
		$exclude_forum_ids = array_map('intval', array_filter(explode(',', $this->shout->text_config($key))));

		$s_forum_options = '<select id="' . $key . '" name="' . $key . '[]" multiple="multiple" size="10">';
		foreach ($forum_list as $f_id => $f_row)
		{
			$f_row['selected'] = in_array($f_id, $exclude_forum_ids);

			$s_forum_options .= '<option value="' . $f_id . '"' . (($f_row['selected']) ? ' selected="selected"' : '') . (($f_row['disabled']) ? ' disabled="disabled" class="disabled-option"' : '') . '>' . $f_row['padding'] . $f_row['forum_name'] . '</option>';
		}
		$s_forum_options .= '</select>';

		return $s_forum_options;
	}

	public function author_user_id($value, $key)
	{
		if (is_numeric($value))
		{
			$username = $this->shout->author('username', $value);
		}
		else
		{
			$username = $value;
		}

		return '<input type="text" name="config[' . $key . ']" id="' . $key . '" value="' . $username . '" maxlength="100" size="30"> [ <a href="'. append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=searchuser&amp;form=acp_board&amp;field=' . $key . '&amp;select_single=true').'" onclick="find_username(this.href); return false;">'. $this->user->lang['FIND_USERNAME'] .'</a> ]';
	}

	public function bbcode_allowed($value, $key)
	{
		return '<textarea cols="40" rows="5" name="config[' . $key . ']" id="' . $key . '">' . $this->shout->text_config($key) . '</textarea>';
	}

	public function delete_messages($value, $key = '')
	{
		return '<input type="submit" value="' . $this->user->lang['DELETE'] . '" name="jv_shoutbox_delete_messages" id="jv_shoutbox_delete_messages" class="button1">';
	}
}
