<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\controller;

class main
{
	protected $container, $db, $auth, $user, $config, $template, $shout, $root_path, $php_ext, $shout_table;

	public function __construct($container, $db, $auth, $user, $config, $template, $shout, $root_path, $php_ext, $shout_table)
	{
		$this->container = $container;
		$this->db = $db;
		$this->auth = $auth;
		$this->user = $user;
		$this->config = $config;
		$this->template = $template;
		$this->shout = $shout;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->shout_table = $shout_table;
	}

	public function main()
	{
		if (!$this->shout->enable() || !$this->config['jv_shoutbox_custom_page'])
		{
			redirect(append_sid("{$this->root_path}index.{$this->php_ext}"));
		}
		else
		{
			$this->shout->active_page('custom');
			$this->shout->display();
		}
	}

	public function whois($shout_id)
	{
		if ($this->auth->acl_get('m_jv_shoutbox_ip'))
		{
			$sql = 'SELECT user_ip
					FROM ' . $this->shout_table . '
					WHERE shout_id = ' . (int) $shout_id;
			$result = $this->db->sql_query($sql);
			$user_ip = $this->db->sql_fetchfield('user_ip');
			$this->db->sql_freeresult($result);

			if (!$user_ip)
			{
				trigger_error('JV_SHOUTBOX_MSG_NO_USER_IP');
			}

			if (!function_exists('user_ipwhois'))
			{
				include($this->root_path . 'includes/functions_user.' . $this->php_ext);
			}

			$this->template->assign_var('WHOIS', user_ipwhois(phpbb_ip_normalise($user_ip)));


			page_header($this->user->lang['WHOIS']);

			$this->template->set_filenames(array(
				'body' => 'viewonline_whois.html')
			);

			page_footer();
		}

		trigger_error('NOT_AUTHORISED');
	}

	public function bbcode_faq()
	{
		$l_title = $this->container->get('phpbb.help.controller.bbcode')->display();

		// Lets build a page ...
		$this->template->assign_vars(array(
			'L_FAQ_TITLE'				=> $l_title,
			'L_BACK_TO_TOP'				=> $this->user->lang['BACK_TO_TOP'],

			'SWITCH_COLUMN_MANUALLY'	=> true,
			'S_IN_FAQ'					=> true
		));

		page_header($l_title);

		$this->template->set_filenames(array(
			'body' => 'shoutbox_bbcode_faq_body.html'
		));

		page_footer();
	}
}
