<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './../../../../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

$user->session_begin(false);
$auth->acl($user->data);
$user->setup('posting');

if (!$request->is_ajax())
{
	trigger_error('NOT_AUTHORISED');
}

if ($phpbb_container->get('ext.manager')->is_enabled('jv/shoutbox'))
{
	$jv_shoutbox = $phpbb_container->get('jv.shoutbox');

	if (!$jv_shoutbox->enable())
	{
		$jv_shoutbox->error('INFORMATION', 'JV_SHOUTBOX_NO_PERMISSION', 403);
	}

	$shout_mode = ($request->is_set_post('shout_mode')) ? $request->variable('shout_mode', '') : '';

	$shout_id = (int) $request->variable('shout_id', 0);
	$shout_last_id = (int) $request->variable('shout_last_id', 0);
	$message = utf8_normalize_nfc($request->variable('jv_shoutbox_msg', '', true));

	if (!$user->data['is_registered'] && in_array($shout_mode, array('edit', 'delete')))
	{
		$shout_mode = '';
	}

	switch ($shout_mode)
	{
		case 'check':
			$shout_check_ids = $request->variable('shout_check_ids', array(0));

			$jv_shoutbox->check_new_msg($shout_id, $shout_check_ids);
		break;

		case 'old_msg':
			$jv_shoutbox->check_old_msg($shout_id);
		break;

		case 'send':
			$jv_shoutbox->send_msg($message, $shout_last_id);
		break;

		case 'edit':
			$jv_shoutbox->edit_msg($message, $shout_id, $shout_last_id);
		break;

		case 'delete':
			$jv_shoutbox->delete_msg($shout_id, $shout_last_id);
		break;

		default:
			$jv_shoutbox->error('ERROR', 'NO_MODE', 500);
	}
}
else
{
	$json_response = new \phpbb\json_response();
	$json_response->send(array('idling' => true));
}
