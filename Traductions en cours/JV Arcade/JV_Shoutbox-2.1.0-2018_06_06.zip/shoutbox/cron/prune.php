<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\cron;

class prune extends \phpbb\cron\task\base
{
	protected $db, $user, $config, $log, $shout_table;

	public function __construct($db, $user, $config, $log, $shout_table)
	{
		$this->db			= $db;
		$this->user			= $user;
		$this->config		= $config;
		$this->log			= $log;
		$this->shout_table	= $shout_table;
	}

	public function run()
	{
		$sql = 'SELECT COUNT(shout_id) AS total
				FROM ' . $this->shout_table;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		$limit = ($total > (int) $this->config['jv_shoutbox_prune_msg_num']) ? $total - $this->config['jv_shoutbox_prune_msg_num'] : 0;

		if ($limit)
		{
			$sql = 'DELETE FROM ' . $this->shout_table . ' ORDER BY shout_id ASC';
			$this->db->sql_query_limit($sql, $limit);

			$user_id = (int) $this->user->data['user_id'];

			if ($user_id < 2)
			{
				$user_id = ANONYMOUS;
			}

			$this->log->add('admin', $user_id, $this->user->ip, 'LOG_JV_SHOUTBOX_MESSAGES_PRUNING', time(), array($limit));
			$this->config->set('jv_shoutbox_last_action_time', time(), false);
		}

		$this->config->set('jv_shoutbox_prune_last_gc', time(), false);
	}

	public function is_runnable()
	{
		return !empty($this->config['jv_shoutbox_prune_gc']) && $this->config['jv_shoutbox_prune'];
	}

	public function should_run()
	{
		return (int) $this->config['jv_shoutbox_prune_last_gc'] < time() - $this->config['jv_shoutbox_prune_gc'];
	}
}
