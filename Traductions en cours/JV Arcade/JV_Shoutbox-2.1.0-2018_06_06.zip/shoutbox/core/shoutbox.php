<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox\core;

class shoutbox
{
	protected $ext_manager, $controller_helper, $request, $db, $auth, $user, $config, $config_text, $template, $path_helper, $root_path, $php_ext, $users_table, $shout_table, $forums_table, $topics_table, $posts_table;
	private $no_avatar;
	public $active_page = '';
	public $active_extra_buttons = true;
	public $custom_bbcode = false;

	public function __construct($ext_manager, $controller_helper, $request, $db, $auth, $user, $config, $config_text, $template, $path_helper, $root_path, $php_ext, $users_table, $shout_table, $forums_table, $topics_table, $posts_table)
	{
		$this->ext_manager = $ext_manager;
		$this->controller_helper = $controller_helper;
		$this->request = $request;
		$this->db = $db;
		$this->auth = $auth;
		$this->user = $user;
		$this->config = $config;
		$this->config_text = $config_text;
		$this->template = $template;
		$this->path_helper = $path_helper;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->users_table = $users_table;
		$this->shout_table = $shout_table;
		$this->forums_table = $forums_table;
		$this->topics_table = $topics_table;
		$this->posts_table = $posts_table;
	}

	public function text_config($key)
	{
		static $jv_shoutbox_configs;
		$r = '';

		if (!isset($jv_shoutbox_configs))
		{
			$jv_shoutbox_configs = $this->config_text->get_array(array('jv_shoutbox_bbcode_allowed', 'jv_shoutbox_post_ign_forums'));
		}

		switch ($key)
		{
			case 'jv_shoutbox_bbcode_allowed';
			case 'jv_shoutbox_post_ign_forums';
				$r = $jv_shoutbox_configs[$key];
			break;
		}

		return $r;
	}

	public function enable()
	{
		return ($this->config['jv_shoutbox_enable'] && $this->auth->acl_get('u_jv_shoutbox_view')) ? true : false;
	}

	public function active_page($page)
	{
		$this->active_page = $page;
	}

	public function active_extra_buttons()
	{
		$this->active_extra_buttons = false;
	}

	public function header()
	{
		if ($this->enable())
		{
			$this->template->assign_vars(array(
				'S_IN_JV_SHOUTBOX'						=> true,
				'S_USE_JV_SHOUTBOX'						=> !$this->bot($this->user->data) && $this->auth->acl_get('u_jv_shoutbox_use'),
				'S_JV_SHOUTBOX_CUSTOM_PAGE'				=> ($this->config['jv_shoutbox_custom_page']) ? true : false,
				'S_JV_SHOUTBOX_CUSTOM_PAGE_POPUP'		=> ($this->config['jv_shoutbox_custom_page_popup']) ? true : false,

				'U_JV_SHOUTBOX'							=> ($this->config['jv_shoutbox_custom_page']) ? $this->controller_helper->route('jv_shoutbox') : '',

				'JV_SHOUTBOX_CUSTOM_PAGE_POPUP_WIDTH'	=> (int) $this->config['jv_shoutbox_custom_page_popup_width'],
				'JV_SHOUTBOX_CUSTOM_PAGE_POPUP_HEIGHT'	=> (int) $this->config['jv_shoutbox_custom_page_popup_height']
			));
		}
	}

	public function display($portal_modules = false)
	{
		if ($this->enable())
		{
			$this->user->add_lang('posting');

			$root_path_ext = $this->ext_path('jv/shoutbox', true);
			$bbcode_allowed = array_filter(explode("\n", $this->text_config('jv_shoutbox_bbcode_allowed')));
			$s_smilie_allowed = $this->active_extra_buttons && $this->config['jv_shoutbox_smilie_enable'] && $this->auth->acl_get('u_jv_shoutbox_smilies');
			$s_bbcode_allowed = $this->active_extra_buttons && $this->auth->acl_get('u_jv_shoutbox_bbcode') && count($bbcode_allowed);

			if ($this->config['jv_shoutbox_custom_bbcode'] && $s_bbcode_allowed)
			{
				if (!function_exists('display_custom_bbcodes'))
				{
					include($this->root_path . 'includes/functions_display.' . $this->php_ext);
				}

				display_custom_bbcodes();
			}

			$this->template->assign_vars(array(
				'S_DISPLAY_JV_SHOUTBOX'				=> (!$portal_modules && $this->active_page != 'portal') ? true : false,
				'S_JV_SHOUTBOX_MSG_TOP'				=> $this->config['jv_shoutbox_msg_position'] == JV_SHOUTBOX_POSITION_TOP,
				'S_JV_SHOUTBOX_CUTOM_PAGE'			=> $this->active_page == 'custom',
				'S_JV_SHOUTBOX_BOARD_INDEX'			=> $this->user_page('index'),
				'S_JV_SHOUTBOX_PAGE_NAME'			=> $this->user_page(),
				'S_JV_SHOUTBOX_AVATAR'				=> $this->use_avatar(),
				'S_JV_SHOUTBOX_ROUND_AVATAR'		=> $this->config['jv_shoutbox_round_avatar'],
				'S_JV_SHOUTBOX_TOP'					=> $this->config['jv_shoutbox_location'] == JV_SHOUTBOX_POSITION_TOP,
				'S_JV_SHOUTBOX_SMILIES_ALLOWED'		=> $s_smilie_allowed,
				'S_JV_SHOUTBOX_SMILIES_SCROLL_BOX'	=> $this->config['jv_shoutbox_smilie_scroll_box'],
				'S_JV_SHOUTBOX_BBCODE_ALLOWED'		=> $s_bbcode_allowed,
				'S_JV_SHOUTBOX_CUSTOM_BBCODES'		=> $this->custom_bbcode,
				'S_JV_SHOUTBOX_SOUND_OFF'			=> $this->request->variable($this->config['cookie_name'] . '_jv_shout_sound', '', false, \phpbb\request\request_interface::COOKIE),
				'S_JV_SHOUTBOX_CLOSE'				=> $this->request->variable($this->config['cookie_name'] . '_jv_shout_close_' . $this->user_page(), '', false, \phpbb\request\request_interface::COOKIE),

				'T_JV_SHOUTBOX_SOUND_PATH'			=> $this->ext_web_path() . 'sound',

				'U_JV_SHOUTBOX_AJAX_ACTION'			=> append_sid("{$root_path_ext}ajax/ajax.{$this->php_ext}"),
				'U_JV_SHOUTBOX_BBCODE_FAQ'			=> $this->controller_helper->route('jv_shoutbox_bbcode_faq'),

				'JV_SHOUTBOX_NEW_MSG_TITLE'			=> $this->user->lang['JV_SHOUTBOX_NEW_MSG_TITLE'][1],
				'JV_SHOUTBOX_NEW_MSGS_TITLE'		=> $this->user->lang['JV_SHOUTBOX_NEW_MSG_TITLE'][2],

				'JV_SHOUTBOX_COPYRIGHT_SRC'			=> 'https://connect.jv-arcade.com/copyright.php?type=1&amp;soft=shoutbox&amp;web=' . $this->board_url(),
				'JV_SHOUTBOX_COOKIE_SETTINGS'		=> addslashes('; path=' . $this->config['cookie_path'] . ((!$this->config['cookie_domain'] || $this->config['cookie_domain'] == 'localhost' || $this->config['cookie_domain'] == '127.0.0.1') ? '' : '; domain=' . $this->config['cookie_domain']) . ((!$this->config['cookie_secure']) ? '' : '; secure')),
				'JV_SHOUTBOX_COOKIE_NAME'			=> $this->config['cookie_name'],

				'JV_SHOUTBOX_MSG_LIMIT'				=> (int) $this->config['jv_shoutbox_msg_limit'],
				'JV_SHOUTBOX_MAX_MSG_LIMIT'			=> (int) $this->config['jv_shoutbox_max_msg_limit'],
				'JV_SHOUTBOX_LAST_ACTION_TIME'		=> (int) $this->config['jv_shoutbox_last_action_time'],
				'JV_SHOUTBOX_REFRESH_TIME'			=> (int) $this->config['jv_shoutbox_refresh'],
				'JV_SHOUTBOX_HEIGHT'				=> (int) $this->config['jv_shoutbox_height'],

				'MAX_FONT_SIZE'						=> (int) $this->config['max_post_font_size']
			));

			if ($s_bbcode_allowed)
			{
				foreach ($bbcode_allowed as $tag)
				{
					$this->template->assign_var('S_JV_SHOUTBOX_BBCODE_' . strtoupper($tag), true);
				}
			}

			if ($s_smilie_allowed)
			{
				if (!function_exists('generate_smilies'))
				{
					include($this->root_path . 'includes/functions_posting.' . $this->php_ext);
				}

				generate_smilies('inline', 0);
			}

			$this->load_start_msg();

			if ($this->active_page == 'custom')
			{
				$this->template->assign_block_vars('navlinks', array(
					'FORUM_NAME'	=> $this->user->lang['JV_SHOUTBOX'],
					'U_VIEW_FORUM'	=> $this->controller_helper->route('jv_shoutbox')
				));

				page_header($this->user->lang['JV_SHOUTBOX'], $this->config['jv_shoutbox_custom_page_onlinelist']);

				$this->template->set_filenames(array(
					'body' => 'shoutbox_body.html'
				));

				page_footer();
			}
		}
	}

	public function viewonline(&$event)
	{
		if ($this->enable() && $this->config['jv_shoutbox_custom_page'])
		{
			if ($event['on_page'][1] == 'app' && strpos($event['row']['session_page'], 'app.' . $this->php_ext . '/shoutbox') !== false)
			{
				$event['location'] = $this->user->lang['JV_SHOUTBOX_VIEWING'];
				$event['location_url'] = $this->controller_helper->route('jv_shoutbox');
			}
		}
	}

	private function load_start_msg()
	{
		$sql_ary = array(
			'SELECT'	=> 's.*, u.username, u.user_colour, u.user_allow_pm, u.user_type',
			'FROM'		=> array(
				$this->shout_table => 's',
				$this->users_table => 'u'
			),
			'WHERE'		=> 's.user_id = u.user_id',
			'ORDER_BY'	=> 's.shout_id DESC'
		);
		$this->extra_sql($sql_ary, true);

		$sql = $this->db->sql_build_query('SELECT', $sql_ary);
		$result = $this->db->sql_query_limit($sql, (int) $this->config['jv_shoutbox_msg_limit']);

		$this->messages($result);
	}

	public function send_msg($message, $shout_last_id)
	{
		if ($this->bot($this->user->data) || !$this->auth->acl_get('u_jv_shoutbox_use'))
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_PERMISSION_SEND_MSG', 403);
		}

		if (!$message)
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_EMPTY_MSG_ERROR', 403);
		}

		if ($this->config['jv_shoutbox_flood_time'] && (!$this->auth->acl_get('u_jv_shoutbox_flood_ignore') || $this->user->data['user_id'] == ANONYMOUS))
		{
			$flood_time = intval(time() - $this->config['jv_shoutbox_flood_time']);
			$sql = 'SELECT shout_id
					FROM ' . $this->shout_table . '
					WHERE user_id = ' . (int) $this->user->data['user_id'] . "
						AND message_time > $flood_time";
			$result = $this->db->sql_query($sql);
			$shout_id = (int) $this->db->sql_fetchfield('shout_id');
			$this->db->sql_freeresult($result);

			if ($shout_id)
			{
				$this->error('INFORMATION', 'JV_SHOUTBOX_MSG_FLOOD_ERROR', 403);
			}
		}

		$chars_count = utf8_strlen(preg_replace('#\[\/?[a-z\*\+\-]+(=[\S]+)?\]#iUs', '', $message));

		if ($chars_count < $this->config['jv_shoutbox_msg_charsmin'])
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_MSG_MIN_CHARS_ERROR', 403, $this->config['jv_shoutbox_msg_charsmin']);
		}
		else if ($this->config['jv_shoutbox_msg_charsmax'] && $chars_count > $this->config['jv_shoutbox_msg_charsmax'])
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_MSG_MAX_CHARS_ERROR', 403, $this->config['jv_shoutbox_msg_charsmax']);
		}

		$options = 0;
		$uid = $bitfield = '';

		$allow_bbcode = $this->auth->acl_get('u_jv_shoutbox_bbcode');
		$allow_urls = $allow_bbcode;
		$allow_smilies = $this->auth->acl_get('u_jv_shoutbox_smilies');
		$this->allow_bbcode($message);

		generate_text_for_storage($message, $uid, $bitfield, $options, $allow_bbcode, $allow_urls, $allow_smilies);

		$sql_ary = array(
			'user_id'			=> $this->user->data['user_id'],
			'user_ip'			=> $this->user->ip,
			'message'			=> $message,
			'bbcode_bitfield'	=> $bitfield,
			'bbcode_uid'		=> $uid,
			'message_time'		=> time()
		);

		$sql = 'INSERT INTO ' . $this->shout_table . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
		$this->db->sql_query($sql);

		$this->check_new_msg($shout_last_id);
	}

	public function check_new_msg($shout_id, $shout_check_ids = array(), $extra_json = array())
	{
		$delete_ids = $edit_ids = array();

		if ($shout_check_ids !== false && count($shout_check_ids))
		{
			$i = 0;
			$find_ids = array();
			$reverse_smilie_config = $this->override_smilie_config();

			$sql_ary = array(
				'SELECT'	=> 's.shout_id, s.user_id, s.edit_count, s.message, s.bbcode_bitfield, s.bbcode_uid, s.post_id',
				'FROM'		=> array($this->shout_table	=> 's'),
				'WHERE'		=> $this->db->sql_in_set('shout_id', array_map('intval', $shout_check_ids))
			);
			$this->extra_sql($sql_ary);

			$sql = $this->db->sql_build_query('SELECT', $sql_ary);
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$find_ids[] = $row['shout_id'];

				if ($row['edit_count'] > 0)
				{
					$parse_flags = ($row['bbcode_bitfield'] ? OPTION_FLAG_BBCODE : 0) | OPTION_FLAG_SMILIES;
					$row['message'] = ($row['post_id']) ? $this->add_post_data($row) : $row['message'];

					$edit_ids[$i] = array(
						'id'			=> $row['shout_id'],
						'message'		=> generate_text_for_display($row['message'], $row['bbcode_uid'], $row['bbcode_bitfield'], $parse_flags),
						'edit_count'	=> $this->user->lang('JV_SHOUTBOX_MSG_EDITED_TIMES', (int) $row['edit_count'])
					);

					if ($this->auth->acl_get('u_jv_shoutbox_bbcode') && $this->auth->acl_get('u_jv_shoutbox_quote') && in_array('quote', explode("\n", $this->text_config('jv_shoutbox_bbcode_allowed'))))
					{
						$edit_ids[$i]['s_quote'] = true;
					}

					if ($this->auth->acl_get('m_jv_shoutbox_edit') || ($this->auth->acl_get('u_jv_shoutbox_edit') && $row['user_id'] == $this->user->data['user_id']))
					{
						$edit_ids[$i]['s_edit'] = true;
					}

					if (!empty($edit_ids[$i]['s_edit']) || !empty($edit_ids[$i]['s_quote']))
					{
						$message_edit = generate_text_for_edit($row['message'], $row['bbcode_uid'], $parse_flags);
						$edit_ids[$i]['edit_message'] = $message_edit['text'];
					}
				}

				$i++;
			}
			$this->db->sql_freeresult($result);

			if ($reverse_smilie_config)
			{
				$this->override_smilie_config($reverse_smilie_config);
			}

			$delete_ids = array_diff($shout_check_ids, $find_ids);
		}

		$sql_ary = array(
			'SELECT' => 'MAX(s.shout_id) AS shout_last_id',
			'FROM'	 => array($this->shout_table => 's')
		);
		$this->extra_sql($sql_ary, false, true);

		$sql = $this->db->sql_build_query('SELECT', $sql_ary);
		$result = $this->db->sql_query($sql);
		$shout_last_id = (int) $this->db->sql_fetchfield('shout_last_id');
		$this->db->sql_freeresult($result);

		if (!$shout_last_id || $shout_last_id != $shout_id)
		{
			$sql_ary = array(
				'SELECT'	=> 's.*, u.username, u.user_colour, u.user_allow_pm, u.user_type',
				'FROM'		=> array(
					$this->shout_table => 's',
					$this->users_table => 'u'
				),
				'WHERE'		=> 's.user_id = u.user_id
					AND s.shout_id > ' . (int) $shout_id,
				'ORDER_BY'	=> 's.shout_id DESC'
			);
			$this->extra_sql($sql_ary, true);

			$sql = $this->db->sql_build_query('SELECT', $sql_ary);
			$result = $this->db->sql_query($sql);

			$this->messages($result, true, $shout_last_id, $delete_ids, $edit_ids, $extra_json);
		}
		else
		{
			$json_ary = array(
				'success'			=> true,
				'last_action_time'	=> (int) $this->config['jv_shoutbox_last_action_time'],
				'shout_last_id'		=> $shout_last_id
			);

			if (is_array($delete_ids) && count($delete_ids))
			{
				$json_ary['delete_ids'] = $delete_ids;
			}

			if (is_array($edit_ids) && count($edit_ids))
			{
				$json_ary['edit_ids'] = $edit_ids;
			}

			if (count($extra_json))
			{
				$json_ary = array_merge($json_ary, $extra_json);
			}

			$this->json($json_ary);
		}
	}

	public function check_old_msg($shout_id)
	{
		$limit = (int) $this->request->variable('shout_limit', 0);
		$limit = intval(($limit > 0) ? $limit : $this->config['jv_shoutbox_msg_limit']);

		if ($limit)
		{
			$sql_ary = array(
				'SELECT'	=> 's.*, u.username, u.user_colour, u.user_allow_pm, u.user_type',
				'FROM'		=> array(
					$this->shout_table => 's',
					$this->users_table => 'u'
				),
				'WHERE'		=> 's.user_id = u.user_id
					AND s.shout_id < ' . (int) $shout_id,
				'ORDER_BY'	=> 's.shout_id DESC'
			);
			$this->extra_sql($sql_ary, true);

			$sql = $this->db->sql_build_query('SELECT', $sql_ary);
			$result = $this->db->sql_query_limit($sql, $limit);

			$this->messages($result, false);
		}
	}

	private function use_avatar()
	{
		return ($this->config['jv_shoutbox_avatar'] && $this->user->optionget('viewavatars')) ? true : false;
	}

	private function no_avatar()
	{
		if (!isset($this->no_avatar))
		{
			$this->no_avatar = '';
			$no_avatar_user_path = $this->root_path . 'styles/' . rawurlencode($this->user->style['style_path']) . '/theme/images/no_avatar.gif';
			$no_avatar_all_path = $this->root_path . 'styles/all/theme/images/no_avatar.gif';
			$no_avatar_prosilver_path = $this->root_path . 'styles/prosilver/theme/images/no_avatar.gif';

			if (file_exists($no_avatar_user_path))
			{
				$this->no_avatar = $no_avatar_user_path;
			}
			else if ($no_avatar_all_path)
			{
				$this->no_avatar = $no_avatar_all_path;
			}
			else if ($no_avatar_user_path != $no_avatar_prosilver_path && file_exists($no_avatar_prosilver_path))
			{
				$this->no_avatar = $no_avatar_prosilver_path;
			}

			if ($this->no_avatar)
			{
				$this->no_avatar = '<img class="avatar" src="' . str_replace($this->root_path, $this->web_path(), $this->no_avatar) . '" width="30" height="30" alt="">';
			}
		}
	}

	private function messages($result, $reverse = true, $shout_last_id = false, $delete_ids = array(), $edit_ids = array(), $extra_json = array())
	{
		$avatar = false;
		$messages = array();
		$use_avatar = $this->use_avatar();

		$s_perm = !$this->bot($this->user->data) && $this->auth->acl_get('u_jv_shoutbox_use');

		if ($use_avatar && !isset($this->no_avatar))
		{
			$this->no_avatar();
		}

		$reverse_smilie_config = $this->override_smilie_config();

		$i = 0;
		while ($row = $this->db->sql_fetchrow($result))
		{
			$parse_flags = ($row['bbcode_bitfield'] ? OPTION_FLAG_BBCODE : 0) | OPTION_FLAG_SMILIES;

			if ($use_avatar)
			{
				$avatar_data = array(
					'user_avatar'			=> $row['user_avatar'],
					'user_avatar_type'		=> $row['user_avatar_type'],
					'user_avatar_width'		=> 30,
					'user_avatar_height'	=> 30
				);

				$avatar = phpbb_get_user_avatar($avatar_data);

				if (!$avatar)
				{
					$avatar = $this->no_avatar;
				}
			}

			$row['message'] = ($row['post_id']) ? $this->add_post_data($row) : $row['message'];

			$messages[$i] = array(
				'id'			=> $row['shout_id'],
				'bot'			=> $this->bot($row),
				'own_data'		=> $row['user_id'] == $this->user->data['user_id'],
				'username'		=> $row['username'],
				'full_username'	=> get_username_string(($row['user_type'] <> USER_IGNORE) ? 'full' : 'no_profile', $row['user_id'], $row['username'], $row['user_colour']),
				'date'			=> $this->user->format_date($row['message_time'], $this->config['jv_shoutbox_date_format']),
				'message'		=> generate_text_for_display($row['message'], $row['bbcode_uid'], $row['bbcode_bitfield'], $parse_flags)
			);

			if ($avatar)
			{
				$messages[$i]['avatar'] = $avatar;
			}

			if ($row['edit_count'] > 0)
			{
				$messages[$i]['edit_count'] = $this->user->lang('JV_SHOUTBOX_MSG_EDITED_TIMES', (int) $row['edit_count']);
			}

			if ($s_perm)
			{
				if ($this->auth->acl_get('u_jv_shoutbox_bbcode') && $this->auth->acl_get('u_jv_shoutbox_quote') && in_array('quote', explode("\n", $this->text_config('jv_shoutbox_bbcode_allowed'))))
				{
					$messages[$i]['s_quote'] = true;
				}

				if ($this->user->data['is_registered'])
				{
					if (in_array($row['user_type'], array(USER_NORMAL, USER_FOUNDER)) && $row['user_id'] != ANONYMOUS && $this->config['allow_privmsg'] && $this->auth->acl_get('u_sendpm') && $this->user->data['user_id'] != $row['user_id'] && ($row['user_allow_pm'] || $this->auth->acl_gets('a_', 'm_') || $this->auth->acl_getf_global('m_')))
					{
						$messages[$i]['s_pm'] = append_sid("{$this->root_path}ucp.{$this->php_ext}", 'i=pm&amp;mode=compose&amp;u=' . $row['user_id']);
					}

					if (!$this->bot($row) && ($this->auth->acl_get('m_jv_shoutbox_edit') || ($this->auth->acl_get('u_jv_shoutbox_edit') && $row['user_id'] == $this->user->data['user_id'])))
					{
						$messages[$i]['s_edit'] = true;
					}

					if ($this->auth->acl_get('m_jv_shoutbox_delete') || ($this->auth->acl_get('u_jv_shoutbox_delete') && $row['user_id'] == $this->user->data['user_id']))
					{
						$messages[$i]['s_delete'] = true;
					}

					if (!$this->bot($row) && $this->auth->acl_get('m_jv_shoutbox_ip'))
					{
						$messages[$i]['ip'] = $this->controller_helper->route('jv_shoutbox_whois', array('shout_id' => $row['shout_id']));
						$messages[$i]['ip_title'] = sprintf($this->user->lang['JV_SHOUTBOX_IP_BUTTON_TITLE'], $row['user_ip']);
					}
				}

				if (!empty($messages[$i]['s_edit']) || !empty($messages[$i]['s_quote']))
				{
					$message_edit = generate_text_for_edit($row['message'], $row['bbcode_uid'], $parse_flags);
					$messages[$i]['edit_message'] = $message_edit['text'];
				}
			}

			$i++;
		}
		$this->db->sql_freeresult($result);

		if ($reverse_smilie_config)
		{
			$this->override_smilie_config($reverse_smilie_config);
		}

		if ($this->request->is_ajax())
		{
			$json_ary = array(
				'success'			=> true,
				'last_action_time'	=> (int) $this->config['jv_shoutbox_last_action_time']
			);

			if ($shout_last_id !== false)
			{
				$json_ary['shout_last_id'] = $shout_last_id;
			}

			if (count($messages))
			{
				$json_ary['new_msgs'] = ($reverse) ? array_reverse($messages) : $messages;
			}

			if (is_array($delete_ids) && count($delete_ids))
			{
				$json_ary['delete_ids'] = $delete_ids;
			}

			if (is_array($edit_ids) && count($edit_ids))
			{
				$json_ary['edit_ids'] = $edit_ids;
			}

			if (count($extra_json))
			{
				$json_ary = array_merge($json_ary, $extra_json);
			}

			$this->json($json_ary);
		}
		else
		{
			if ($this->config['jv_shoutbox_msg_position'] == JV_SHOUTBOX_POSITION_BOTTOM)
			{
				$messages = array_reverse($messages);
			}

			$i = $first_id = $last_id = 0;
			foreach ($messages as $message)
			{
				if (!$i)
				{
					$last_id = $message['id'];
				}

				$this->template->assign_block_vars('jv_shout', array(
					'ID'			=> $message['id'],
					'BOT'			=> $message['bot'],
					'OWN_DATA'		=> $message['own_data'],
					'AVATAR'		=> (!empty($message['avatar'])) ? $message['avatar'] : false,
					'USERNAME'		=> $message['username'],
					'FULL_USERNAME'	=> $message['full_username'],
					'USERIP'		=> (!empty($message['ip'])) ? $message['ip'] : false,
					'USERIP_TITLE'	=> (!empty($message['ip'])) ? $message['ip_title'] : '',
					'DATE'			=> $message['date'],
					'MSG'			=> $message['message'],
					'EDIT_COUNT'	=> (!empty($message['edit_count'])) ? $message['edit_count'] : false,
					'EDIT_MSG'		=> (!empty($message['s_edit']) || !empty($message['s_quote'])) ? htmlspecialchars(($message['edit_message'])) : false,

					'S_PM'			=> (!empty($message['s_pm'])) ? $message['s_pm'] : false,
					'S_QUOTE'		=> (!empty($message['s_quote'])),
					'S_EDIT'		=> (!empty($message['s_edit'])),
					'S_DELETE'		=> (!empty($message['s_delete']))
				));

				$i++;
				$first_id = $message['id'];
			}

			// reverse
			if ($first_id && $this->config['jv_shoutbox_msg_position'] == JV_SHOUTBOX_POSITION_BOTTOM)
			{
				$i = $first_id;
				$first_id = $last_id;
				$last_id = $i;
			}

			$this->template->assign_vars(array(
				'JV_SHOUTBOX_FIRST_ID'	=> $first_id,
				'JV_SHOUTBOX_LAST_ID'	=> $last_id
			));
		}
	}

	public function edit_msg($message, $shout_id, $shout_last_id)
	{
		if (!$this->user->data['is_registered'] || !$this->auth->acl_get('u_jv_shoutbox_use') || !$this->auth->acl_gets('m_jv_shoutbox_edit', 'u_jv_shoutbox_edit'))
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_PERMISSION_EDIT_MSG', 403);
		}

		if (!$shout_id)
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_MSG_ID', 403);
		}

		if (!$message)
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_EMPTY_MSG_ERROR', 403);
		}

		$sql = 'SELECT shout_id, user_id, edit_count
				FROM ' . $this->shout_table . '
				WHERE shout_id = ' . (int) $shout_id;
		$result = $this->db->sql_query($sql);
		$msg = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$msg)
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_MSG_ID', 403);
		}

		$auth_edit = ($this->auth->acl_get('m_jv_shoutbox_edit') || ($this->auth->acl_get('u_jv_shoutbox_edit') && $msg['user_id'] == $this->user->data['user_id']));

		if (!$auth_edit)
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_PERMISSION_EDIT_MSG', 403);
		}

		$chars_count = utf8_strlen(preg_replace('#\[\/?[a-z\*\+\-]+(=[\S]+)?\]#iUs', '', $message));

		if ($chars_count < $this->config['jv_shoutbox_msg_charsmin'])
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_MSG_MIN_CHARS_ERROR', 403, $this->config['jv_shoutbox_msg_charsmin']);
		}
		else if ($this->config['jv_shoutbox_msg_charsmax'] && $chars_count > $this->config['jv_shoutbox_msg_charsmax'])
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_MSG_MAX_CHARS_ERROR', 403, $this->config['jv_shoutbox_msg_charsmax']);
		}

		$options = 0;
		$uid = $bitfield = $options = '';

		$allow_bbcode = $this->auth->acl_get('u_jv_shoutbox_bbcode');
		$allow_urls = $allow_bbcode;
		$allow_smilies = $this->auth->acl_get('u_jv_shoutbox_smilies');
		$this->allow_bbcode($message);

		generate_text_for_storage($message, $uid, $bitfield, $options, $allow_bbcode, $allow_urls, $allow_smilies);

		$sql_ary = array(
			'message'			=> $message,
			'bbcode_bitfield'	=> $bitfield,
			'bbcode_uid'		=> $uid
		);

		$sql = 'UPDATE ' . $this->shout_table . '
				SET edit_count = edit_count + 1, ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
				WHERE shout_id = ' . (int) $msg['shout_id'];
		$this->db->sql_query($sql);

		$parse_flags = ($bitfield ? OPTION_FLAG_BBCODE : 0) | OPTION_FLAG_SMILIES;
		$message_edit = generate_text_for_edit($message, $uid, $parse_flags);

		$reverse_smilie_config = $this->override_smilie_config();

		$json_ary = array('edit_msg' => array(
			'id'			=> $msg['shout_id'],
			'message'		=> generate_text_for_display($message, $uid, $bitfield, $parse_flags),
			'edit_count'	=> $this->user->lang('JV_SHOUTBOX_MSG_EDITED_TIMES', intval($msg['edit_count'] + 1)),
			'edit_message'	=> $message_edit['text']
		));

		if ($reverse_smilie_config)
		{
			$this->override_smilie_config($reverse_smilie_config);
		}

		$this->config->set('jv_shoutbox_last_action_time', time(), false);
		$this->check_new_msg($shout_last_id, false, $json_ary);
	}

	public function delete_msg($shout_id, $shout_last_id)
	{
		if (!$this->user->data['is_registered'] || !$this->auth->acl_get('u_jv_shoutbox_use') || !$this->auth->acl_gets('m_jv_shoutbox_delete', 'u_jv_shoutbox_delete'))
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_PERMISSION_DELETE_MSG', 403);
		}

		if (!$shout_id)
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_MSG_ID', 403);
		}

		$sql = 'SELECT user_id
				FROM ' . $this->shout_table . '
				WHERE shout_id = ' . (int) $shout_id;
		$result = $this->db->sql_query($sql);
		$user_id = (int) $this->db->sql_fetchfield('user_id');
		$this->db->sql_freeresult($result);

		if (!$user_id)
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_MSG_ID', 403);
		}

		$delete_auth = ($this->auth->acl_get('m_jv_shoutbox_delete') || ($this->auth->acl_get('u_jv_shoutbox_delete') && $user_id == $this->user->data['user_id'])) ? true : false;

		if (!$delete_auth)
		{
			$this->error('INFORMATION', 'JV_SHOUTBOX_NO_PERMISSION_DELETE_MSG', 403);
		}

		$sql = 'DELETE FROM ' . $this->shout_table . '
				WHERE shout_id =  ' . (int) $shout_id;
		$this->db->sql_query($sql);

		$this->config->set('jv_shoutbox_last_action_time', time(), false);

		$json_ary = array('delete_msg_id' => $shout_id);

		$this->check_new_msg($shout_last_id, false, $json_ary);
	}

	public function author($column, $user_id = false, $username = false)
	{
		if ($column != 'user_id' && $column != 'username')
		{
			return;
		}

		$sql = "SELECT $column
				FROM " . $this->users_table . "
				WHERE " . (($username) ? "username_clean = '" . $this->db->sql_escape(utf8_clean_string($username)) . "'" : 'user_id = ' . (int) $user_id);
		$result = $this->db->sql_query($sql);
		$v = $this->db->sql_fetchfield($column);
		$this->db->sql_freeresult($result);

		return $v;
	}

	public function user_page($page_name = true, $query_string = false)
	{
		$p = '';
		$page_array = $this->user->extract_current_page($this->root_path);

		if ($query_string)
		{
			return (!empty($page_array['query_string'])) ? $page_array['query_string'] : '';
		}

		if ($page_name)
		{
			if (!empty($page_array['page_name']))
			{
				$p = basename($page_array['page_name'], '.' . $this->php_ext);
			}
		}

		if (!$p && !empty($page_array['page']))
		{
			$p = basename($page_array['page'], '.' . $this->php_ext);
		}

		$p = strtolower($p);

		if ($p == 'app')
		{
			$p = 'portal';
		}

		if ($page_name !== true && $page_name !== false)
		{
			$p = ($p == $page_name) ? true : false;
		}

		return $p;
	}

	public function is_enabled_ext($ext_name)
	{
		return $this->ext_manager->is_available($ext_name) && $this->ext_manager->is_enabled($ext_name);
	}

	public function board_url()
	{
		return generate_board_url() . '/';
	}

	public function web_path()
	{
		return (defined('PHPBB_USE_BOARD_URL_PATH') && PHPBB_USE_BOARD_URL_PATH) ? $this->board_url() : $this->path_helper->get_web_root_path();
	}

	public function ext_web_path($ext_name = 'jv/shoutbox')
	{
		return $this->web_path() . $this->ext_path();
	}

	public function ext_path($ext_name = 'jv/shoutbox', $phpbb_relative = false)
	{
		return $this->ext_manager->get_extension_path($ext_name, $phpbb_relative);
	}

	public function enable_forum_post()
	{
		return $this->config['jv_shoutbox_new_topic_post'] || $this->config['jv_shoutbox_new_reply_post'] || $this->config['jv_shoutbox_new_reply_quote_post'] || $this->config['jv_shoutbox_edit_post'];
	}

	private function extra_sql(&$sql_ary, $use_avatar = false, $ignore_select = false)
	{
		if ($use_avatar && !$ignore_select && $this->use_avatar())
		{
			$sql_ary['SELECT'] .= ', u.user_avatar, u.user_avatar_type';
		}

		$sql_ary['WHERE'] = (!empty($sql_ary['WHERE'])) ? $sql_ary['WHERE'] . ' AND ' : '';

		if ($this->enable_forum_post())
		{
			if (!$ignore_select)
			{
				$sql_ary['SELECT'] .= ', p.forum_id, t.topic_title, f.forum_name';
			}

			$sql_ary['LEFT_JOIN'] = array(
				array(
					'FROM'	=> array($this->posts_table => 'p'),
					'ON'	=> 's.post_id = p.post_id'
				),
				array(
					'FROM'	=> array($this->topics_table => 't'),
					'ON'	=> 'p.topic_id = t.topic_id'
				),
				array(
					'FROM'	=> array($this->forums_table => 'f'),
					'ON'	=> 'p.forum_id = f.forum_id'
				)
			);

			$sql_ary['WHERE'] .= '(
				s.post_id = 0 OR
				(p.forum_id IS NOT NULL
					AND ' . $this->db->sql_in_set('p.forum_id', $this->permissions('f_read'), false, true) . '
					AND (p.post_visibility = ' . ITEM_APPROVED . ' OR
						' . $this->db->sql_in_set('p.forum_id', $this->permissions('m_approve'), false, true) . '
					)
				)
			)';
		}
		else
		{
			$sql_ary['WHERE'] .= 's.post_id = 0';
		}
	}

	private function override_smilie_config($reverse = false)
	{
		if ($reverse)
		{
			$reverse = false;
			$this->config->offsetSet('allow_smilies', (!$this->config['allow_smilies']) ? 1 : 0);
		}
		else
		{
			$reverse = false;
			if ($this->config['allow_smilies'] && !$this->config['jv_shoutbox_smilie_enable'])
			{
				$reverse = true;
				$this->config->offsetSet('allow_smilies', 0);
			}
			else if (!$this->config['allow_smilies'] && $this->config['jv_shoutbox_smilie_enable'])
			{
				$reverse = true;
				$this->config->offsetSet('allow_smilies', 1);
			}
		}

		return $reverse;
	}

	private function allow_bbcode(&$message)
	{
		$disable_bbcode = '';
		$message = str_replace('][', '] [', $message);
		$allow_bbcodes = ($this->auth->acl_get('u_jv_shoutbox_bbcode')) ? explode("\n", $this->text_config('jv_shoutbox_bbcode_allowed')) : array();
		preg_match_all('#\[/((?:/)?(?:[a-z]+))#i', $message, $tags);

		foreach ($tags[1] as $fb)
		{
			if (!in_array($fb, $allow_bbcodes) || ($fb == 'quote' && !$this->auth->acl_get('u_jv_shoutbox_quote')))
			{
				$disable_bbcode .= (($disable_bbcode) ? '|' : '') . $fb;
			}
		}

		if ($disable_bbcode)
		{
			$message = preg_replace('#\[\/?[' . $disable_bbcode . '\*\+\-]+(=[\S]+)?\]#iUs', '', $message);
		}
	}

	private function add_post_data($data)
	{
		$data['message'] = str_replace(array('{FORUM_ID}', '%7BFORUM_ID%7D'), (int) $data['forum_id'], $data['message']);
		$data['message'] = str_replace(array('{FORUM_NAME}', '%7BFORUM_NAME%7D'), $data['forum_name'], $data['message']);
		$data['message'] = str_replace(array('{TOPIC_TITLE}', '%7BTOPIC_TITLE%7D'), $data['topic_title'], $data['message']);

		return $data['message'];
	}

	private function bot($ud)
	{
		return !empty($ud['is_bot']) || $ud['user_id'] != ANONYMOUS && $ud['user_type'] == USER_IGNORE;
	}

	private function permissions($opts)
	{
		$return = array();

		if (!is_array($opts))
		{
			$opts = array($opts);
		}

		foreach ($opts as $opt)
		{
			$return = array_merge($return, array_keys($this->auth->acl_getf($opt, true)));
		}

		return array_unique($return);
	}

	private function json($data)
	{
		if (!is_array($data))
		{
			$data = array($data);
		}

		$json_response = new \phpbb\json_response();
		$json_response->send($data);
	}

	public function error($title, $message, $status, $extra = '')
	{
		$this->json(array(
			'title'	=> $this->user->lang($title),
			'error'	=> $this->user->lang($message, $extra),
			'status'=> $status
		));
	}
}