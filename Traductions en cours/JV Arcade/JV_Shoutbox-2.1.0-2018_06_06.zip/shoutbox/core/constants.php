<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

define('JV_SHOUTBOX_DISPLAY_NONE', 0);
define('JV_SHOUTBOX_DISPLAY_FORUM', 1);
define('JV_SHOUTBOX_DISPLAY_FORUM_ALL', 2);
define('JV_SHOUTBOX_DISPLAY_ARCADE', 3);
define('JV_SHOUTBOX_DISPLAY_ARCADE_ALL', 4);
define('JV_SHOUTBOX_DISPLAY_PORTAL', 5);
define('JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_PORTAL', 6);
define('JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_ARCADE', 7);
define('JV_SHOUTBOX_DISPLAY_ALL_MAIN_PAGES', 8);
define('JV_SHOUTBOX_DISPLAY_ALL_PAGES', 9);

define('JV_SHOUTBOX_POSITION_TOP', 1);
define('JV_SHOUTBOX_POSITION_BOTTOM', 2);
