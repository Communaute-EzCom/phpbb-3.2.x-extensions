<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JV_SHOUTBOX'							=> 'Shoutbox',
	'JV_SHOUTBOX_AJAX_ERROR'				=> 'Il y a eu une erreur pendant le processus.',
	'JV_SHOUTBOX_AUTO_REFRESH_TIME_TITLE'	=> 'Rafraichissement auto toutes les %d s',
	'JV_SHOUTBOX_BBCODES'					=> 'BBCodes',
	'JV_SHOUTBOX_BBCODES_FAQ'				=> 'FAQ BBCode',
	'JV_SHOUTBOX_CLOSE'						=> 'Fermer la shoutbox',
	'JV_SHOUTBOX_CONFIRM_DELETE_MSG'		=> 'Etes-vous sûr de vouloir supprimer ce message ?',
	'JV_SHOUTBOX_CUSTOM_BBCODES'			=> 'Personnaliser les BBCodes',
	'JV_SHOUTBOX_DELETE_MESSAGE'			=> 'Supprimer le message',
	'JV_SHOUTBOX_EDIT_MESSAGE'				=> 'Editer',
	'JV_SHOUTBOX_EMPTY_MSG_ERROR'			=> 'Vous ne pouvez pas envoyer un message vide.',
	'JV_SHOUTBOX_EXPLAIN'					=> 'Se joindre à la conversation',
	'JV_SHOUTBOX_F_NEW_TOPIC'				=> '%3$s a ouvert un sujet dans le forum %1$s > %2$s.',
	'JV_SHOUTBOX_F_NEW_POST'				=> '%3$s a posté un message dans le sujet %2$s du forum %1$s.',
	'JV_SHOUTBOX_F_NEW_POST_QUOTE'			=> '%3$s a cité un message dans le sujet %2$s du forum %1$s.',
	'JV_SHOUTBOX_F_EDITED_POST'				=> '%3$s a édité un message dans le sujet %2$s du forum %1$s.',
	'JV_SHOUTBOX_IP_BUTTON_TITLE'			=> 'IP de l’utilisateur “%s”',
	'JV_SHOUTBOX_MSG_EDITED_TIMES'			=> array(
		1	=> 'Edité %d fois.',
		2	=> 'Edité %d fois.'
	),
	'JV_SHOUTBOX_MSG_FLOOD_ERROR'			=> 'Vous ne pouvez pas envoyer un nouveau message aussi vite après le dernier posté.',
	'JV_SHOUTBOX_MSG_MAX_CHARS_ERROR'		=> 'Le message doit contenir un maximum de %d caractères.',
	'JV_SHOUTBOX_MSG_MIN_CHARS_ERROR'		=> array(
		1	=> 'Le message doit contenir un minimum de %d caractère.',
		2	=> 'Le message doit contenir un minimum de %d caractères.'
	),
	'JV_SHOUTBOX_MSG_NO_USER_IP'			=> 'Le message n’existe pas ou il n’a pas d’IP assignée.',
	'JV_SHOUTBOX_NEW_MSG_TITLE'				=> array(
		1	=> '(%d) nouveau message a été posté!',
		2	=> '(%d) nouveaux messages ont été postés!'
	),
	'JV_SHOUTBOX_NO_JS'						=> 'Pour utiliser la shoutbox, il faut autoriser l’utilisation de JavaScript!',
	'JV_SHOUTBOX_NO_MSG_ID'					=> 'Le message n’a pu être trouvé.',
	'JV_SHOUTBOX_NO_PERMISSION'				=> 'Vous n’avez pas les permissions pour utiliser la shoutbox.',
	'JV_SHOUTBOX_NO_PERMISSION_EDIT_MSG'	=> 'Vous n’avez pas les permissions pour éditer les messages.',
	'JV_SHOUTBOX_NO_PERMISSION_DELETE_MSG'	=> 'Vous n’avez pas les permissions pour supprimer les messages.',
	'JV_SHOUTBOX_NO_PERMISSION_SEND_MSG'	=> 'Vous n’avez pas les permissions pour envoyer des messages.',
	'JV_SHOUTBOX_OPEN'						=> 'Ouvrir la Shoutbox',
	'JV_SHOUTBOX_PM_BUTTON_TITLE'			=> 'Envoyer un message privé',
	'JV_SHOUTBOX_QUOTE_BUTTON_TITLE'		=> 'Citer',
	'JV_SHOUTBOX_RE_USER'					=> '@%s',
	'JV_SHOUTBOX_RE_USER_TITLE'				=> 'Répondre',
	'JV_SHOUTBOX_SOUND_OFF_TITLE'			=> 'Son off',
	'JV_SHOUTBOX_SOUND_ON_TITLE'			=> 'Son on',
	'JV_SHOUTBOX_SUCCESS_DELETE_MSG'		=> 'Le message a été supprimé avec succès.',
	'JV_SHOUTBOX_VIEWING'					=> 'Voir la shoutbox',
));
