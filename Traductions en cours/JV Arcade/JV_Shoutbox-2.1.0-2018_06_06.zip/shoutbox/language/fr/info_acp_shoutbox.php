<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'ACP_CAT_JV_SHOUTBOX_SETTINGS'						=> 'Shoutbox',
	'ACP_JV_SHOUTBOX'									=> 'JV Shoutbox',
	'ACP_JV_SHOUTBOX_AUTHOR'							=> 'Auteur du message',
	'ACP_JV_SHOUTBOX_AUTHOR_EXPLAIN'					=> 'Ici vous pouvez spécifier l’auteur du message envoyé. Si vous laissez le champ vide et que vous avez installé l’extension “JV Add System Bot” (robot-système), le message sera envoyé sous ce nom. S’il n’y a pas d’utilisateur “robot-système”, alors sera utilisé l’actuel utilisateur pour l’envoi du message.',
	'ACP_JV_SHOUTBOX_AVATAR'							=> 'Afficher les avatars',
	'ACP_JV_SHOUTBOX_AVATAR_EXPLAIN'					=> 'Si oui, les avatars seront affichés.',
	'ACP_JV_SHOUTBOX_BBCODE_ALLOWED'					=> 'Permettre le BBCode',
	'ACP_JV_SHOUTBOX_BBCODE_ALLOWED_EXPLAIN'			=> 'Le BBCode spécifié ne sera utilisé que par la shoutbox. Aller à la ligne pour tout nouveau BBCode.',
	'ACP_JV_SHOUTBOX_CUSTOM_BBCODE'						=> 'Permettre le BBCode personnalisé',
	'ACP_JV_SHOUTBOX_CUSTOM_BBCODE_EXPLAIN'				=> 'Si autorisé, le BBCode personnalisé sera lui aussi affiché.',
	'ACP_JV_SHOUTBOX_CUSTOM_PAGE'						=> 'Permettre la page personnalisée',
	'ACP_JV_SHOUTBOX_CUSTOM_PAGE_EXPLAIN'				=> 'Ici vous pouvez autoriser l’affichage de la shoutbox dans une page personnalisée.',
	'ACP_JV_SHOUTBOX_CUSTOM_PAGE_ONLINE_LIST'			=> 'Afficher les utilisateurs en ligne sur la page personnalisée',
	'ACP_JV_SHOUTBOX_CUSTOM_PAGE_ONLINE_LIST_EXPLAIN'	=> 'Ici vous pouvez permettre l’affichage des utilisateurs qui sont en ligne sur la page personnalisée.',
	'ACP_JV_SHOUTBOX_CUSTOM_PAGE_POPUP'					=> 'Fenêtre pop-up pour la page personnalisée',
	'ACP_JV_SHOUTBOX_CUSTOM_PAGE_POPUP_EXPLAIN'			=> 'Si oui, la page personnalisée ouvrira une fenêtre popup.',
	'ACP_JV_SHOUTBOX_CUSTOM_PAGE_POPUP_HEIGHT'			=> 'Hauteur de la fenêtre pop-up',
	'ACP_JV_SHOUTBOX_CUSTOM_PAGE_POPUP_WIDTH'			=> 'Largeur de la fenêtre pop-up',
	'ACP_JV_SHOUTBOX_DATE_FORMAT'						=> 'Format de la date',
	'ACP_JV_SHOUTBOX_DATE_FORMAT_EXPLAIN'				=> 'La syntaxe utilisée suit les formats du PHP: <a href="http://php.net/manual/en/function.date.php">Documentation Format Date</a>.',
	'ACP_JV_SHOUTBOX_DELETE_MESSAGES'					=> 'Supprimer les messages',
	'ACP_JV_SHOUTBOX_DELETE_MESSAGES_CONFIRM'			=> 'Etes-vous sûr de vouloir supprimer tous les messages ?',
	'ACP_JV_SHOUTBOX_DELETE_MESSAGES_EXPLAIN'			=> 'Ici on peut supprimer tous les messages.',
	'ACP_JV_SHOUTBOX_DELETE_MESSAGES_SUCCESS'			=> 'Tous les messages ont été supprimés avec succès.',
	'ACP_JV_SHOUTBOX_DISPLAY_ALL_MAIN_PAGES'			=> 'Toutes les pages principales',
	'ACP_JV_SHOUTBOX_DISPLAY_ALL_PAGES'					=> 'Toutes les pages',
	'ACP_JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_ARCADE'	=> 'Toutes les pages, sauf l’arcade',
	'ACP_JV_SHOUTBOX_DISPLAY_ALL_PAGES_EXCEPT_PORTAL'	=> 'Toutes les pages, sauf le portail',
	'ACP_JV_SHOUTBOX_DISPLAY_ARCADE'					=> 'La page index de l’arcade',
	'ACP_JV_SHOUTBOX_DISPLAY_ARCADE_ALL'				=> 'Toutes les pages de l’arcade',
	'ACP_JV_SHOUTBOX_DISPLAY_FORUM'						=> 'La page index du forum',
	'ACP_JV_SHOUTBOX_DISPLAY_FORUM_ALL'					=> 'Toutes les pages du forum',
	'ACP_JV_SHOUTBOX_DISPLAY_NONE'						=> 'Ne pas afficher',
	'ACP_JV_SHOUTBOX_DISPLAY_PORTAL'					=> 'Page du portail',
	'ACP_JV_SHOUTBOX_EDIT_POST'							=> 'Signaler les éditions de messages',
	'ACP_JV_SHOUTBOX_EDIT_POST_EXPLAIN'					=> 'Si un utilisateur a édité son message, ce sera affiché dans la shoutbox.',
	'ACP_JV_SHOUTBOX_ENABLE'							=> 'Activer la shoutbox',
	'ACP_JV_SHOUTBOX_ENABLE_EXPLAIN'					=> 'Si oui, la shoutbox sera affichée sur les pages pour lesquelles elle est autorisée.',
	'ACP_JV_SHOUTBOX_FLOOD_TIME'						=> 'Intervalle de flood',
	'ACP_JV_SHOUTBOX_FLOOD_TIME_EXPLAIN'				=> 'Nombre de secondes qu’un utilisateur doit attendre pour poster un nouveau message. Pour permettre aux utilisateurs d’ignorer la limite de flood, il faut changer leurs permissions.',
	'ACP_JV_SHOUTBOX_FORUM_POST_SETTINGS'				=> 'Paramètres de messages forum',
	'ACP_JV_SHOUTBOX_HEIGHT'							=> 'Hauteur de la shoutbox',
	'ACP_JV_SHOUTBOX_HEIGHT_ERROR'						=> 'La valeur donnée pour le réglage de la “hauteur de la Shoutbox” est trop élevée comparé au “Nombre de Messages”. Pour que cela marche, il faut que la hauteur soit assignée à un minimum de “%d” messages.',
	'ACP_JV_SHOUTBOX_HEIGHT_EXPLAIN'					=> 'Régler ici la hauteur de la shoutbox pour l’affichage désiré.',
	'ACP_JV_SHOUTBOX_LOCATION'							=> 'Localisation',
	'ACP_JV_SHOUTBOX_LOCATION_EXPLAIN'					=> 'Ici vous pouvez définir à quel endroit sur le site la shoutbox sera affichée.',
	'ACP_JV_SHOUTBOX_MAX_MSG_LIMIT'						=> 'Nombre maximum de messages',
	'ACP_JV_SHOUTBOX_MAX_MSG_LIMIT_EXPLAIN'				=> 'Ici vous pouvez limiter le nombre maximum de messages qui seront visibles dans la shoutbox. Par exemple, si la valeur définie ici est 100 et que la chargement initial est de 10, alors 90 anciens messages pourront être récupérés. Si la valeur est mise à 0, tous les anciens messages pourront être lus.',
	'ACP_JV_SHOUTBOX_MIN_MAX_ERROR'						=> 'La „%s“ ne peut être plus petite que „%s“.',
	'ACP_JV_SHOUTBOX_MSG_LIMIT'							=> 'Nombre de messages',
	'ACP_JV_SHOUTBOX_MSG_LIMIT_EXPLAIN'					=> 'Ici vous pouvez spécifier un nombre par défaut de messages qui seront chargés dans la shoutbox. Cela concerne aussi le réglage du chargement des anciens messages.',
	'ACP_JV_SHOUTBOX_MSG_MAX_CHARS'						=> 'Maximum de caractères par message',
	'ACP_JV_SHOUTBOX_MSG_MAX_CHARS_EXPLAIN'				=> 'C’est le nombre de caractères autorisés pour un même message. Mettre 0 pour illimité.',
	'ACP_JV_SHOUTBOX_MSG_MIN_CHARS'						=> 'Minimum de caractères par message',
	'ACP_JV_SHOUTBOX_MSG_MIN_CHARS_EXPLAIN'				=> 'C’est le nombre minimum de caractères obligatoires pour qu’un utilisateur puisse créer un message. La valeur minimum théorique est 1.',
	'ACP_JV_SHOUTBOX_MSG_POSITION'						=> 'Position du message',
	'ACP_JV_SHOUTBOX_MSG_POSITION_EXPLAIN'				=> 'Ici vous pouvez définir si un nouveau message sera affiché en haut ou en bas.',
	'ACP_JV_SHOUTBOX_MSG_SETTINGS'						=> 'Paramètres de message',
	'ACP_JV_SHOUTBOX_NEW_REPLY_POST'					=> 'Annoncer un nouveau message',
	'ACP_JV_SHOUTBOX_NEW_REPLY_POST_EXPLAIN'			=> 'Si un nouveau message est posté dans un sujet, ce sera affiché dans la shoutbox.',
	'ACP_JV_SHOUTBOX_NEW_REPLY_QUOTE_POST'				=> 'Annoncer un nouveau message avec citation',
	'ACP_JV_SHOUTBOX_NEW_REPLY_QUOTE_POST_EXPLAIN'		=> 'Si un nouveau message avec une citation est posté dans un sujet, ce sera affiché dans la shoutbox.',
	'ACP_JV_SHOUTBOX_NEW_TOPIC_POST'					=> 'Annoncer un nouveau sujet',
	'ACP_JV_SHOUTBOX_NEW_TOPIC_POST_EXPLAIN'			=> 'Si un nouveau sujet est créé sur le forum, ce sera affiché dans la shoutbox.',
	'ACP_JV_SHOUTBOX_PAGE'								=> 'Affichage de la shoutbox',
	'ACP_JV_SHOUTBOX_PAGE_EXPLAIN'						=> 'Préciser les pages sur lesquelles vous voulez que la shoutbox soit affichée. Notez que d’éventuels smileys et BBCodes présents dans les pages d’affichage ne seront pas disponibles et actifs dans la shoutbox.',
	'ACP_JV_SHOUTBOX_POSITION_BOTTOM'					=> 'Bas',
	'ACP_JV_SHOUTBOX_POSITION_TOP'						=> 'Haut',
	'ACP_JV_SHOUTBOX_POST_IGNORE_FORUMS'				=> 'Forums ignorés',
	'ACP_JV_SHOUTBOX_POST_IGNORE_FORUMS_EXPLAIN'		=> 'Les sujets dans les forums sélectionnés ne généreront pas de messages automatiques. Sélectionner/Dé-sélectionner plusieurs forums en maintenant appuyée la touche CTRL et en cliquant.',
	'ACP_JV_SHOUTBOX_PRUNE'								=> 'Délestage des messages',
	'ACP_JV_SHOUTBOX_PRUNE_EXPLAIN'						=> 'Si activé, ne seront conservés que le nombre maximum de messages défini, pendant la période de délestage.',
	'ACP_JV_SHOUTBOX_PRUNE_MSG_NUM'						=> 'Nombre de messages conservés',
	'ACP_JV_SHOUTBOX_PRUNE_MSG_NUM_EXPLAIN'				=> 'Si le délestage est activé, c’est le nombre max de messages conservés.',
	'ACP_JV_SHOUTBOX_PRUNE_TIME'						=> 'Période de délestage',
	'ACP_JV_SHOUTBOX_PRUNE_TIME_EXPLAIN'				=> 'Entrer l’intervalle pour la période de délestage de messages.',
	'ACP_JV_SHOUTBOX_REFRESH'							=> 'Rafraichir (vérifier) pour la période',
	'ACP_JV_SHOUTBOX_REFRESH_EXPLAIN'					=> 'Les derniers nouveaux messages seront pris en compte pour le délestage.',
	'ACP_JV_SHOUTBOX_ROUND_AVATAR'						=> 'Avatar rond',
	'ACP_JV_SHOUTBOX_ROUND_AVATAR_EXPLAIN'				=> 'Si oui, les avatars seront affichés sous une forme arrondie.',
	'ACP_JV_SHOUTBOX_SETTINGS'							=> 'Paramètres de la shoutbox',
	'ACP_JV_SHOUTBOX_SETTINGS_EXPLAIN'					=> 'Ici vous pouvez personnaliser la shoutbox et régler les paramètres de message.',
	'ACP_JV_SHOUTBOX_SMILIE_ENABLE'						=> 'Autoriser les smileys',
	'ACP_JV_SHOUTBOX_SMILIE_ENABLE_EXPLAIN'				=> 'Ici vous pouvez permettre l’utilisation des smileys.',
	'ACP_JV_SHOUTBOX_SMILIE_SCROLL_BOX'					=> 'Afficher la box déroulante des smileys',
	'ACP_JV_SHOUTBOX_SMILIE_SCROLL_BOX_EXPLAIN'			=> 'S’il y a trop de smileys à afficher, on peut autoriser ici la box déroulante à fermer des smileys.',

	'LOG_JV_SHOUTBOX_CONFIG_SETTINGS'					=> '<strong>Modification des paramètres de shoutbox.</strong>',
	'LOG_JV_SHOUTBOX_DELETE_MESSAGES'					=> '<strong>Supprimer tous les messages de la shoutbox.</strong>',
	'LOG_JV_SHOUTBOX_MESSAGES_PRUNING'					=> '<strong>Délestage des messages de la shoutbox.</strong><br>» %d messages supprimés',
));
