<?php
/**
*
* @package phpBB Arcade - Game Over Animation
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade_gameoveranimation\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $ext_enable = false;
	protected $template, $arcade, $arcade_config;

	public function __construct($template, $ext, $arcade = null, $arcade_config = null)
	{
		if ($arcade && defined('ARCADE_MIN_EXT_VERSION') && phpbb_version_compare($ext->version, ARCADE_MIN_EXT_VERSION, '>='))
		{
			$this->ext_enable = true;
			$this->template = $template;
			$this->arcade = $arcade;
			$this->arcade_config = $arcade_config;
		}
	}

	static public function getSubscribedEvents()
	{
		return array(
			'jv.arcade.game.score.game_over' => 'game_over'
		);
	}

	public function game_over($event)
	{
		if ($this->ext_enable && (($this->arcade_config['ext_game_over_anim_congrat'] && $event['save_highscore']) || ($this->arcade_config['ext_game_over_anim_losing'] && !$event['save_highscore'])))
		{
			$this->template->assign_vars(array(
				'S_ARCADE_EXT_GAME_OVER_' . (($event['save_highscore']) ? 'NEW_RECORD' : 'LOSING') => true,
				'SRC_ARCADE_EXT_GAME_OVER_ANIMATION' => "{$this->arcade->ext_path('jv/arcade_gameoveranimation')}animation/index.html"
			));
		}
	}
}
