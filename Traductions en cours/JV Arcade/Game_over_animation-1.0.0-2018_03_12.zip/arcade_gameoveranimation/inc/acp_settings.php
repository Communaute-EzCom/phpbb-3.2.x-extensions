<?php
/**
*
* @package phpBB Arcade - Game Over Animation
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade_gameoveranimation\inc;

class acp_settings extends \jv\arcade\inc\ext\base
{
	public $version = '1.0.0';
	public $version_explain = true;
	public $name = 'ARCADE_EXT_GAME_OVER_ANIMATION';

	public function get_language()
	{
		return array(
			'vendor'	=> 'jv/arcade_gameoveranimation',
			'file'		=> 'acp_settings'
		);
	}

	public function get_template_acp()
	{
		$explain = (!defined('ARCADE_MIN_EXT_VERSION') || phpbb_version_compare($this->version, ARCADE_MIN_EXT_VERSION, '<')) ? 'ACP_ARCADE_EXT_DISABLED' : false;

		return array(
			'legend1'						=> array('name' => false, 'explain' => $explain),
			'ext_game_over_anim_congrat'	=> array('lang' => 'ARCADE_EXT_GAME_OVER_CONGRATULATION',	'validate' => 'bool', 'type' => 'radio:enabled_disabled', 'explain' => false),
			'ext_game_over_anim_losing'		=> array('lang' => 'ARCADE_EXT_GAME_OVER_LOSING',			'validate' => 'bool', 'type' => 'radio:enabled_disabled', 'explain' => false)
		);
	}
}
