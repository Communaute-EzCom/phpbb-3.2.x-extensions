<?php
/**
*
* @package JV Random No Avatar
* @version $Id$
* @author 2011-2015 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2015 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\randomnoavatar\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $ext_manager, $path_helper, $user;

	public function __construct($ext_manager, $path_helper, $user)
	{
		$this->ext_manager = $ext_manager;
		$this->path_helper = $path_helper;
		$this->user = $user;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.get_avatar_after' => 'random_avatar'
		);
	}

	public function random_avatar($event)
	{
		if (empty($event['html']))
		{
			$root_path_ext = $this->ext_manager->get_extension_path('jv/randomnoavatar', true);

			$random_avatar = 'images/avatars/no_avatar' . mt_rand(1, 17) . '.gif';

			if (file_exists($root_path_ext . $random_avatar))
			{
				$avatar_width	= $event['avatar_data']['width'];
				$avatar_height	= $event['avatar_data']['height'];

				if (!$avatar_width && !$avatar_height)
				{
					if (list($width, $height) = @getimagesize($root_path_ext . $random_avatar))
					{
						$avatar_width  = $width;
						$avatar_height = $height;
					} 
					else
					{
						$avatar_width = $avatar_height = 100;
					}
				}

				$ext_web_path = ((defined('PHPBB_USE_BOARD_URL_PATH') && PHPBB_USE_BOARD_URL_PATH) ? generate_board_url() . '/' : $this->path_helper->get_web_root_path()) . $this->ext_manager->get_extension_path('jv/randomnoavatar');

				$event['html'] = '<img class="avatar" src="' . $ext_web_path . $random_avatar . '"' .
					($avatar_width ? (' width="' . $avatar_width . '"') : '') .
					($avatar_height ? (' height="' . $avatar_height . '"') : '') .
					' alt="' . ((!empty($this->user->lang[$event['alt']])) ? $this->user->lang[$event['alt']] : $event['alt']) . '" />';
			}
		}
	}
}
