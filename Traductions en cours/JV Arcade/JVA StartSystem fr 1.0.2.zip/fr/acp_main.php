<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JVA_START_SYSTEM_ACTIVATION'						=> 'Système de démarrage JVA',
	'JVA_START_SYSTEM_ACTIVATION_BLOCKED'				=> 'Ce site Web est en violation de la licence du logiciel "JVA Start System" et a été bloqué. La cause du blocage de ce script peut se  trouver %içi% en demandant à l\'opérateur de le débloquer.',
	'JVA_START_SYSTEM_ACTIVATION_DATE'					=> 'Date d\'activation',
	'JVA_START_SYSTEM_ACTIVATION_INVALID'				=> 'La tentative d\'activation a échouée!',
	'JVA_START_SYSTEM_ACTIVATION_KEY'					=> 'Clé d\'activation',
	'JVA_START_SYSTEM_ACTIVATION_KEY_ALREADY'			=> 'La clé d\'activation spécifiée est déjà activée!',
	'JVA_START_SYSTEM_ACTIVATION_KEY_EXPLAIN'			=> 'Ici vous pouvez choisir l\'une des trois clés. Si ce site est en ligne, choisissez la clé "Libre", s\'il s\'agit d\'un site de test, choisissez la touche "Test". Cependant, si vous avez une clé privée, vous pouvez l\'utiliser, mais seulement s\'il s\'agit d\'un site web en direct.<br><br>
	<em style="color: #BC2A4D;">Avec l\'activation du "Système de démarrage JVA", vous acceptez de transmettre les données suivantes lors de l\'activation: (Clé d\'activation, version phpBB et arcade, adresse Web, nom d\'utilisateur, adresse e-mail et adresse IP actuelle).<br>
	Si vous n\'êtes pas d\'accord pour envoyer ces données, veuillez ne pas utiliser l\'activation et désinstaller le "Système de démarrage JVA" du serveur.</em><br><br>
	Veuillez lire la <strong>%1$s“Politique de confidentialité”%2$s</strong> aussi.<br><br>
	<strong>Note:</strong> Le %3$s“Système de démarrage JCA”%4$ ne peut être qu\'utilisé par ceux qui sont enregistré sur ce  “%5$s” site.<br>
	S.V.P. assurez-vous  d\'activez ce site pour qu\'il soit enregistré! Si ce n\'est pas enregistré et que vous utilisez le Système de démarrage JVA, ce site sera <strong style="color: #BC2A4D;">banni</strong> automatiquement.<br / >
	<em>Avec la page de  %3$s“téléchargement”%4$s vous trouverez le Sytème de démarrage JVA, et la %6$s“license”%7$s.</em>',
	'JVA_START_SYSTEM_ACTIVATION_KEY_INVALID'			=> '39/5000 La clé d\'activation spécifiée est invalide!',
	'JVA_START_SYSTEM_ACTIVATION_KEY_INVALID_VERSION'	=> 'La clé d\'activation spécifiée n\'appartient pas à cette version de "phpBB Arcade"!',
	'JVA_START_SYSTEM_ACTIVATION_SHOW'					=> 'Afficher le champ d\'activation',
	'JVA_START_SYSTEM_ACTIVATION_SUCCESS'				=> 'La clé d\'activation spécifiée est acceptée, vous pouvez maintenant utiliser l\arcade.',
	'JVA_START_SYSTEM_NEW_KEY'							=> 'Ajouter une nouvelle clé',
	'JVA_START_SYSTEM_NOT_ACTIVATED'					=> 'Le "Système de démarrage JVA" n\'est pas activé! "PhpBB Arcade" ne peut pas être utilisé avant d\'avoir activé "Système de démarrage JVA".',
	'JVA_START_SYSTEM_NOT_ACTIVATED_INFO'				=> 'Le "Système de démarrage JVA" n\'a pas été activé par le concepteur du script. Une fois activé, "l\'arcade" sera disponible pour vous.',
	'JVA_START_SYSTEM_NOT_COMPATIBLE'					=> 'Le "Système de démarrage JVA" installé n\'est pas compatible avec cette version "de l\'arcade". Veuillez mettre à jour le "Système de démarrage JVA".<br>» %sTélécharger le Système de démarrage JVA%s «',
	'JVA_START_SYSTEM_PRIVACY_POLICY'					=> 'Ppolitique de confidentialité',
	'JVA_START_SYSTEM_PRIVACY_POLICY_EXPLAIN'			=> ' Cette politique explique comment le “%1$s” concepteur gèrent les données.<br><br>
Toutes les données sont protégées par les lois sur la confidentialité dans le pays où se “%1$s” trouve le serveur.<br>
Cette information n\'est pas divulguée et ne sera pas vendue ou transmise à des tiers sans votre consentement, mais le “%1$s” concepteur ne peut être tenu responsable d\'une «attaque de pirate informatique» contre laquelle les données pourraient être mises en péril.',
	'JVA_START_SYSTEM_REMOVE_KEY'						=> 'Supprimer la clé',
	'JVA_START_SYSTEM_REMOVE_KEY_SUCCESS'				=> 'La clé d\'activation a été supprimée avec succès.',
	'JVA_START_SYSTEM_SITE_NOT_AVAILABLE'				=> 'La vérification de la connexion au “%1$s” site web a échoué!<br>Si vous croyez que ceçi est une erreur, parce que le fichier qui contient le “<a onclick="window.open(this.href); return false;" href="%1$sac/v/arcade_version.json">Version</a>” est disponible pour vous, alors <a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_Arcade_activation.html">içi</a> est une solution alternative pour l\'activation.',
	'JVA_START_SYSTEM_SITE_NOT_AVAILABLE_ACTIVATE_TEST'	=> 'Si vous ne pouvez vraiment pas accéder au “%1$s” site web,cliquez sur  %2$sHERE%3$s et votre site sera activé avec la clé  “Test”.',
));
