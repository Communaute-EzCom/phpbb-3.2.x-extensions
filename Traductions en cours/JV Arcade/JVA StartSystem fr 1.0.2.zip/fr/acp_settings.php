<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JVA_GAME_INTRO'						=> 'Système de démarrage JVA',
	'JVA_GAME_INTRO_EXPLAIN'				=> 'Avant que le  jeu ne débute, une introduction est chargée, qui comprend une description du jeu, un contrôle et une liste des scores. <br> En outre, lisez la description détaillée %siçi%s.',
	'JVA_GAME_INTRO_GAME_PRELOAD'			=> 'Afficher le chargement du jeu',
	'JVA_GAME_INTRO_GAME_PRELOAD_EXPLAIN'	=> 'Cette option ne s\'applique qu\'aux jeux Flash. <br> Le jeu ne sera chargé que dans le cache du navigateur. S\'il n\'est pas activé pour le cache de votre navigateur, alors le jeu sera chargé deux fois, donc cette méthode ne peut que ralentir le démarrage des jeux. <br> <em> L\'utilisation du cache du navigateur est fortement recommandée! </ Em>',
	'JVA_GAME_INTRO_LOGO'					=> 'Texte logo',
	'JVA_GAME_INTRO_LOGO_COLOR'				=> 'Logo couleur',
	'JVA_GAME_INTRO_LOGO_EXPLAIN'			=> 'Si vous entrez un texte ici, il écrasera le logo original et l\'affichera. Cependant, vous avez la possibilité de créer votre image pour personnaliser votre logo, qui peut être téléchargé sur le serveur dans le répertoire “[root]/arcade/start_system/jva_game_intro/images/logo.png”, et écrasera le logo d\'origine.',
	'JVA_GAME_INTRO_LOGO_SHADOW_COLOR'		=> 'Couleur d\'ombre du logo',
	'JVA_GAME_INTRO_PRIVATE_SETTINGS'		=> 'Ce paramètre n\'est disponible que si le "Système de démarrage JVA" est activé avec une clé privée.',
	'JVA_GAME_INTRO_SCORES'					=> 'Nombre de scores',
	'JVA_GAME_INTRO_SCORES_EXPLAIN'			=> 'La valeur spécifiée sera listée en fonction des résultats obtenus.',
));
