<?php
/**
*
* @package phpBB Arcade
* @version $Id: listener.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $db, $cache, $user, $auth, $request, $config, $template, $arcade_cache, $arcade_config, $arcade_auth, $arcade, $php_ext;

	public function __construct($db, $cache, $user, $auth, $request, $config, $template, $arcade_cache, $arcade_config, $arcade_auth, $arcade, $php_ext)
	{
		$this->db = $db;
		$this->cache = $cache;
		$this->user = $user;
		$this->auth = $auth;
		$this->request = $request;
		$this->config = $config;
		$this->template = $template;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->php_ext = $php_ext;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.common'									=> 'common',

			'core.user_setup'								=> 'setup',
			'core.page_header'								=> 'header',

			'core.viewonline_overwrite_location'			=> 'viewonline',

			'core.memberlist_prepare_profile_data'			=> 'member_profile',
			'core.viewtopic_modify_post_row'				=> 'topic_post_member_info',

			'core.permissions'								=> 'permissions_language',

			'core.user_add_after'							=> 'user_add',
			'core.acp_users_overview_before'				=> 'acp_users_overview',
			'core.update_username'							=> 'update_username',
			'core.user_set_default_group'					=> 'update_users_colour',
			'core.delete_group_after'						=> 'delete_group',
			'core.delete_user_after'						=> 'delete_user',
			'core.validate_config_variable'					=> 'validate_config_variable',

			'core.avatar_driver_upload_move_file_before'	=> 'change_avatar',
			'core.avatar_driver_upload_delete_before'		=> 'change_avatar',

			'core.page_footer_after'						=> 'page_footer_after',

			// added + core
			'core.ucp_switch_permissions'					=> 'add_switch_permissions_msg',
			'core.ucp_restore_permissions'					=> 'add_restore_permissions_msg',
			'core.acl_clear_prefetch_after'					=> 'acl_clear_prefetch_after'
		);
	}

	public function common()
	{
		global $arcade_cache, $arcade_config, $arcade_auth, $arcade;

		$arcade_cache	= $this->arcade_cache;
		$arcade_config	= $this->arcade_config;
		$arcade_auth	= $this->arcade_auth;
		$arcade			= $this->arcade;

		if (!defined('ARCADE_VERSION'))
		{
			$this->arcade->container('constants');
		}

		if ($this->arcade->page() == 'index')
		{
			$arcade_act	= strtolower($this->request->variable('act', ''));
			$arcade_do	= strtolower($this->request->variable('do', ''));
			$scoretype	= ($arcade_act == 'arcade' && $arcade_do == 'newscore') ? IBPRO_GAME : (($arcade_act == 'arcadelib') ? ARCADELIB_GAME : ((strtolower($this->request->variable('autocom', '')) == 'arcade') ? IBPROV3_GAME : ((($arcade_act == 'arcadeoa' && $arcade_do == 'newscore') || strtolower($this->request->variable('action', '')) == 'submit_score') ? OLYMPUS_GAME : false)));

			if ($scoretype !== false)
			{
				$this->user->session_begin(false);
				$this->auth->acl($this->user->data);

				if ($arcade_do == 'verifyscore')
				{
					define('IN_PHPBB_ARCADE', true);
					define('PHPBB_ARCADE_START', true);

					$this->arcade->container('scoretype')->set($scoretype);
				}

				$this->arcade->container('ibp')->game_data();
			}
		}
	}

	public function setup($event)
	{
		$event['lang_set_ext'] = array_merge($event['lang_set_ext'], array(
			array(
				'ext_name' => 'jv/arcade',
				'lang_set' => 'arcade'
			)
		));

		$user_data = $event['user_data'];
		$this->arcade->set_userdata($user_data);
		$this->arcade_auth->acl($user_data);
		$event['user_data'] = $user_data;
	}

	public function header()
	{
		$this->arcade->header($this->arcade->access() ? 'full' : 'default');
	}

	public function viewonline($event)
	{
		if ($this->arcade->access())
		{
			switch ($event['on_page'][1])
			{
				case 'arcade':
					$this->arcade->container('viewonline')->main($event);
				break;

				default:
					if ($event['row']['session_page'] === 'app.' . $this->php_ext . '/help/arcade_faq')
					{
						$event['location'] = $this->user->lang['VIEWING_ARCADE_FAQ'];

						$event['location_url'] = $this->arcade->url('arcade_faq', 'app/help', false, 'faqlinks');
					}
				break;
			}
		}
	}

	public function member_profile($event)
	{
		if ($event['data']['user_id'] <= ANONYMOUS || $event['data']['user_type'] == USER_IGNORE)
		{
			return false;
		}

		if ($this->arcade->access())
		{
			if (($arcade_highscores = $this->arcade->display()->highscores('memberlist', $event['data']['user_id'])) !== false)
			{
				$event['template_data'] = array_merge($event['template_data'], $arcade_highscores);
			}
		}
	}

	public function topic_post_member_info($event)
	{
		if ($event['poster_id'] <= ANONYMOUS || $event['user_poster_data']['user_type'] == USER_IGNORE)
		{
			return false;
		}

		if ($this->arcade->access())
		{
			if (($arcade_highscores = $this->arcade->display()->highscores('viewtopic', $event['poster_id'])) !== false)
			{
				$event['post_row'] = array_merge($event['post_row'], $arcade_highscores);
			}
		}
	}

	public function permissions_language($event)
	{
		$event['categories'] = array_merge($event['categories'], array(
			'arcade' => 'ACL_CAT_ARCADE',
		));

		$event['types'] = array_merge($event['types'], array(
			'c_' => 'ACL_TYPE_C_',
		));

		$event['permissions'] = array_merge($event['permissions'], array(
			// Admin Permissions
			'a_arcade'							=> array('lang' => 'ACL_A_ARCADE'					, 'cat' => 'arcade'),
			'a_arcade_install'					=> array('lang' => 'ACL_A_ARCADE_INSTALL'			, 'cat' => 'arcade'),
			'a_arcade_announce'					=> array('lang' => 'ACL_A_ARCADE_ANNOUNCE'			, 'cat' => 'arcade'),
			'a_arcade_menu'						=> array('lang' => 'ACL_A_ARCADE_MENU'				, 'cat' => 'arcade'),
			'a_arcade_settings'					=> array('lang' => 'ACL_A_ARCADE_SETTINGS'			, 'cat' => 'arcade'),
			'a_arcade_cat'						=> array('lang' => 'ACL_A_ARCADE_CAT'				, 'cat' => 'arcade'),
			'a_arcade_delete_cat'				=> array('lang' => 'ACL_A_ARCADE_DELETE_CAT'		, 'cat' => 'arcade'),
			'a_arcade_backup'					=> array('lang' => 'ACL_A_ARCADE_BACKUP'			, 'cat' => 'arcade'),
			'a_arcade_game'						=> array('lang' => 'ACL_A_ARCADE_GAME'				, 'cat' => 'arcade'),
			'a_arcade_reset_game'				=> array('lang' => 'ACL_A_ARCADE_RESET_GAME'		, 'cat' => 'arcade'),
			'a_arcade_delete_game'				=> array('lang' => 'ACL_A_ARCADE_DELETE_GAME'		, 'cat' => 'arcade'),
			'a_arcade_user'						=> array('lang' => 'ACL_A_ARCADE_USER'				, 'cat' => 'arcade'),
			'a_arcade_tour'						=> array('lang' => 'ACL_A_ARCADE_TOUR'				, 'cat' => 'arcade'),
			'a_arcade_delete_tour'				=> array('lang' => 'ACL_A_ARCADE_DELETE_TOUR'		, 'cat' => 'arcade'),
			'a_arcade_ranks'					=> array('lang' => 'ACL_A_ARCADE_RANKS'				, 'cat' => 'arcade'),
			'a_arcade_utilities'				=> array('lang' => 'ACL_A_ARCADE_UTILITIES'			, 'cat' => 'arcade'),
			'a_arcade_viewlogs'					=> array('lang' => 'ACL_A_ARCADE_VIEWLOGS'			, 'cat' => 'arcade'),
			'a_arcade_clearlogs'				=> array('lang' => 'ACL_A_ARCADE_CLEARLOGS'			, 'cat' => 'arcade'),
			'a_arcade_points_settings'			=> array('lang' => 'ACL_A_ARCADE_POINTS_SETTINGS'	, 'cat' => 'arcade'),
			'a_cauth'							=> array('lang' => 'ACL_A_CAUTH'					, 'cat' => 'arcade'),

			// Mod Permissions
			'm_arcade_game'						=> array('lang' => 'ACL_M_ARCADE_GAME'				, 'cat' => 'arcade'),
			'm_arcade_reset_game'				=> array('lang' => 'ACL_M_ARCADE_RESET_GAME'		, 'cat' => 'arcade'),
			'm_arcade_change_gamename'			=> array('lang' => 'ACL_M_ARCADE_CHANGE_GAMENAME'	, 'cat' => 'arcade'),
			'm_arcade_tour'						=> array('lang' => 'ACL_M_ARCADE_TOUR'				, 'cat' => 'arcade'),
			'm_arcade_tour_reward'				=> array('lang' => 'ACL_M_ARCADE_TOUR_REWARD'		, 'cat' => 'arcade'),

			// User Permissions
			'u_arcade'							=> array('lang' => 'ACL_U_ARCADE'					, 'cat' => 'arcade'),
			'u_arcade_challenge'				=> array('lang' => 'ACL_U_ARCADE_CHALLENGE'			, 'cat' => 'arcade'),
			'u_arcade_tour'						=> array('lang' => 'ACL_U_ARCADE_TOUR'				, 'cat' => 'arcade'),
			'u_arcade_search'					=> array('lang' => 'ACL_U_ARCADE_SEARCH'			, 'cat' => 'arcade'),
			'u_arcade_pm'						=> array('lang' => 'ACL_U_ARCADE_PM'				, 'cat' => 'arcade'),
			'u_arcade_viewstats'				=> array('lang' => 'ACL_U_ARCADE_VIEWSTATS'			, 'cat' => 'arcade'),
			'u_arcade_view_whoisplaying'		=> array('lang' => 'ACL_U_ARCADE_VIEW_WHOISPLAYING'	, 'cat' => 'arcade'),
			'u_arcade_favorites'				=> array('lang' => 'ACL_U_ARCADE_FAVORITES'			, 'cat' => 'arcade'),
			'u_arcade_ignoreflood_search'		=> array('lang' => 'ACL_U_ARCADE_IGNOREFLOOD_SEARCH', 'cat' => 'arcade'),
			'u_arcade_popup'					=> array('lang' => 'ACL_U_ARCADE_POPUP'				, 'cat' => 'arcade'),
			'u_arcade_resolution'				=> array('lang' => 'ACL_U_ARCADE_RESOLUTION'		, 'cat' => 'arcade'),
			'u_arcade_download'					=> array('lang' => 'ACL_U_ARCADE_DOWNLOAD'			, 'cat' => 'arcade'),

			// Category Permissions
			'c_list'							=> array('lang' => 'ACL_C_LIST'						, 'cat' => 'arcade'),
			'c_view'							=> array('lang' => 'ACL_C_VIEW'						, 'cat' => 'arcade'),
			'c_play'							=> array('lang' => 'ACL_C_PLAY'						, 'cat' => 'arcade'),
			'c_playfree'						=> array('lang' => 'ACL_C_PLAYFREE'					, 'cat' => 'arcade'),
			'c_score'							=> array('lang' => 'ACL_C_SCORE'					, 'cat' => 'arcade'),
			'c_comment'							=> array('lang' => 'ACL_C_COMMENT'					, 'cat' => 'arcade'),
			'c_report'							=> array('lang' => 'ACL_C_REPORT'					, 'cat' => 'arcade'),
			'c_rate'							=> array('lang' => 'ACL_C_RATE'						, 'cat' => 'arcade'),
			'c_re_rate'							=> array('lang' => 'ACL_C_RE_RATE'					, 'cat' => 'arcade'),
			'c_download'						=> array('lang' => 'ACL_C_DOWNLOAD'					, 'cat' => 'arcade'),
			'c_downloadfree'					=> array('lang' => 'ACL_C_DOWNLOADFREE'				, 'cat' => 'arcade'),
			'c_ignoreflood_play'				=> array('lang' => 'ACL_C_IGNOREFLOOD_PLAY'			, 'cat' => 'arcade'),
			'c_ignorecontrol'					=> array('lang' => 'ACL_C_IGNORECONTROL'			, 'cat' => 'arcade'),
			'c_ignoreflood_download'			=> array('lang' => 'ACL_C_IGNOREFLOOD_DOWNLOAD'		, 'cat' => 'arcade')
		));
	}

	public function user_add($event)
	{
		$this->arcade->user_add($event['user_id']);
	}

	public function acp_users_overview($event)
	{
		if ($event['submit'] && in_array($event['action'], array('', 'reactivate', 'active', 'delavatar')))
		{
			$this->arcade->cache_purge('user');
		}
	}

	public function update_username($event)
	{
		$update_ary = array(
			ARCADE_CATS_TABLE			=> 'cat_last_play_username',
			ARCADE_ANNOUNCE_DATA_TABLE	=> 'username'
		);

		foreach ($update_ary as $table => $field)
		{
			$sql = "UPDATE $table
					SET $field = '" . $this->db->sql_escape($event['new_name']) . "'
					WHERE $field = '" . $this->db->sql_escape($event['old_name']) . "'";
			$this->db->sql_query($sql);
		}

		if ($this->arcade_config['announce_author'] == $event['old_name'])
		{
			$this->arcade_config->set('announce_author', $event['new_name']);
		}

		$this->arcade->cache_purge('profile');
		$this->cache->destroy('sql', ARCADE_CHALLENGE_CHAMP_TABLE);
	}

	public function update_users_colour($event)
	{
		if (isset($event['sql_ary']['user_colour']))
		{
			$sql = 'UPDATE ' . ARCADE_CATS_TABLE . " SET cat_last_play_user_colour = '" . $this->db->sql_escape($event['sql_ary']['user_colour']) . "'
					WHERE " . $this->db->sql_in_set('cat_last_play_user_id', $event['user_id_ary']);
			$this->db->sql_query($sql);

			$sql = 'UPDATE ' . ARCADE_ANNOUNCE_DATA_TABLE . " SET user_colour = '" . $this->db->sql_escape($event['sql_ary']['user_colour']) . "'
					WHERE " . $this->db->sql_in_set('user_id', $event['user_id_ary']);
			$this->db->sql_query($sql);

			$this->arcade->cache_purge('profile');
		}
	}

	public function delete_group($event)
	{
		$sql = 'DELETE FROM ' . ACL_ARCADE_GROUPS_TABLE . '
				WHERE group_id = ' . (int) $event['group_id'];
		$this->db->sql_query($sql);
	}

	public function delete_user($event)
	{
		if (!defined('USE_ARCADE_ADMIN'))
		{
			define('USE_ARCADE_ADMIN', true);
		}

		$this->arcade->get_driver()->delete_user($event['user_ids']);
	}

	public function page_footer_after($event)
	{
		$mode = $this->request->variable('mode', '');
		$action = $this->request->variable('action', '');
		$game_rid = (int) $this->request->variable('rid', 0);

		if (!$action && $mode == 'compose' && $game_rid)
		{
			$sql = 'SELECT r.game_id, r.report_desc, r.report_desc_uid AS bbcode_uid, g.game_name, u.username AS quote_username, u.user_lang
					FROM ' . ARCADE_REPORTS_TABLE . ' r, ' . ARCADE_GAMES_TABLE . ' g, ' . USERS_TABLE . " u
					WHERE r.report_id = $game_rid
						AND r.game_id = g.game_id
						AND r.user_id = u.user_id";
					$result = $this->db->sql_query($sql);
			$game_report = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			if ($game_report)
			{
				$reported_game = $this->arcade->message_language($game_report['user_lang'], 'ARCADE_REPORTED_GAME');

				if ($this->config['allow_post_links'])
				{
					$game_link = "[url=" . generate_board_url() . "/arcade.{$this->php_ext}?mode=play&amp;g={$game_report['game_id']}" . $this->arcade->gametop . "]{$reported_game}: {$game_report['game_name']}[/url]\n";
				}
				else
				{
					$game_link = $reported_game . ': ' . $game_report['game_name'] . " (" . generate_board_url() . "/arcade.{$this->php_ext}?mode=play&amp;g={$game_report['game_id']}" . $this->arcade->gametop . ")\n";
				}

				decode_message($game_report['report_desc'], $game_report['bbcode_uid']);

				$this->template->assign_vars(array(
					'SUBJECT' => 'Re: ' . $reported_game . '-' . $game_report['game_name'],
					'MESSAGE' => $game_link . (($game_report['report_desc']) ? "\n[quote=&quot;{$game_report['quote_username']}&quot;]" . censor_text(trim($game_report['report_desc'])) . "[/quote]\n" : '')
				));
			}
		}
	}

	public function change_avatar($event)
	{
		if (!count($event['error']))
		{
			$this->arcade->cache_purge('profile');
		}
	}

	public function add_switch_permissions_msg($event)
	{
		$massage = 'ARCADE_SWITCH_' . (($this->arcade->container('auth_admin')->ghost_permissions($event['user_id'], $this->user->data['user_id'])) ? 'PERMISSION' : 'NO_PERMISSION');

		if (!empty($this->user->lang[$massage]))
		{
			$event['message'] = sprintf($this->user->lang[$massage], $event['user_row']['username']) . '<br><br>' . $event['message'];
		}
	}

	public function add_restore_permissions_msg()
	{
		if (!$this->user->data['user_arcade_perm_from'])
		{
			return;
		}

		$this->arcade_auth->acl_cache($this->user->data);
	}

	public function acl_clear_prefetch_after($event)
	{
		$this->arcade_auth->acl_clear_prefetch($event['user_id']);
	}

	public function validate_config_variable($event)
	{
		$type	= 0;
		$min	= 1;
		$max	= 2;

		$validator = explode(':', $event['config_definition']['validate']);

		switch ($validator[$type])
		{
			case 'jva_float':
				$cfga = $event['cfg_array'];
				$cfga[$event['config_name']] = (float) $cfga[$event['config_name']];
				$event['cfg_array'] = $cfga;

				if (isset($validator[$min]) && $event['cfg_array'][$event['config_name']] < $validator[$min])
				{
					$event['error'] = array_merge($event['error'], array(sprintf($this->user->lang['SETTING_TOO_LOW'], $this->user->lang[$event['config_definition']['lang']], $validator[$min])));
				}
				else if (isset($validator[$max]) && $event['cfg_array'][$event['config_name']] > $validator[$max])
				{
					$event['error'] = array_merge($event['error'], array(sprintf($this->user->lang['SETTING_TOO_BIG'], $this->user->lang[$event['config_definition']['lang']], $validator[$max])));
				}
				else if (strpos($event['config_name'], '_max') !== false)
				{
					$min_name = str_replace('_max', '_min', $event['config_name']);

					if (isset($event['cfg_array'][$min_name]) && is_numeric($event['cfg_array'][$min_name]) && $event['cfg_array'][$event['config_name']] < $event['cfg_array'][$min_name])
					{
						$event['error'] = array_merge($event['error'], array(sprintf($this->user->lang['SETTING_TOO_LOW'], $this->user->lang[$event['config_definition']['lang']], (float) $event['cfg_array'][$min_name])));
					}
				}
			break;
		}
	}
}
