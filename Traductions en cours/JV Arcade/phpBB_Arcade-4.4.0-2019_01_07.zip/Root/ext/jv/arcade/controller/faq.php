<?php
/**
*
* @package phpBB Arcade
* @version $Id: faq.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\controller;

class faq
{
	protected $container, $user, $template;

	public function __construct($container, $user, $template)
	{
		$this->container = $container;
		$this->user = $user;
		$this->template = $template;
	}

	public function faq()
	{
		$l_title = $this->container->get('jv.arcade.faq')->display();

		$this->template->assign_vars(array(
			'L_FAQ_TITLE'				=> $l_title,
			'L_BACK_TO_TOP'				=> $this->user->lang['BACK_TO_TOP'],

			'S_IN_FAQ'					=> true
		));

		page_header($l_title);

		$this->template->set_filenames(array(
			'body' => 'faq_body.html'
		));

		page_footer();
	}

	public function developer_faq()
	{
		$l_title = $this->container->get('jv.arcade.soft_faq')->display();

		$this->template->assign_vars(array(
			'L_FAQ_TITLE'				=> $l_title,
			'L_BACK_TO_TOP'				=> $this->user->lang['BACK_TO_TOP'],

			'S_IN_FAQ'					=> true
		));

		page_header($l_title);

		$this->template->set_filenames(array(
			'body' => 'faq_body.html'
		));

		page_footer();
	}
}
