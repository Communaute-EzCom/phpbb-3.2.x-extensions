<?php
/**
*
* @package phpBB Arcade
* @version $Id: score.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\controller;

class score
{
	protected $arcade;

	public function __construct($arcade)
	{
		$this->arcade = $arcade;
	}

	public function amod_game()
	{
		$this->arcade->container('scoretype')->set(AMOD_GAME);
	}

	public function ar_game()
	{
		$this->arcade->container('scoretype')->set(AR_GAME);
	}

	public function ra_game()
	{
		$this->arcade->container('scoretype')->set(PHPBB_RA_GAME);
	}
}
