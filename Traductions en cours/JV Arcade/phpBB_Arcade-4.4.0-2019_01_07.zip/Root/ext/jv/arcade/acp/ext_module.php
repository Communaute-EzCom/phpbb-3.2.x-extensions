<?php
/**
*
* @package phpBB Arcade
* @version $Id: ext_module.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class ext_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	private $new_config = array();

	protected $admin_path;
	protected $request, $user, $template, $php_ext;
	protected $arcade_config, $arcade, $ext_class;

	public function __construct()
	{
		global $phpbb_admin_path;
		global $request, $user, $template, $phpEx;
		global $arcade_config, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->admin_path = $phpbb_admin_path;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->php_ext = $phpEx;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	public function main($id, $mode)
	{
		$this->tpl_name = 'arcade/acp_ext';

		$form_key = 'acp_arcade_ext';
		add_form_key($form_key);

		$submit_config = false;
		$submit = $this->arcade->is_post_empty('submit');
		$ext_name = $this->request->variable('ext_name', '');
		$action = $this->request->variable('action', '');
		$versioncheck_force = $this->request->variable('versioncheck_force', false);

		if ($action == 'version_check')
		{
			$mode = 'version_check';
		}

		switch ($mode)
		{
			case 'settings':
				$this->page_title = 'ACP_ARCADE_SETTINGS_EXT';

				$l = 0;
				$display_vars = array();
				$ext_list = $this->arcade->ext()->get_all_ext();

				if (count($ext_list) > 1 && !empty($ext_list['\jv\arcade_startsystem\inc\acp_settings']))
				{
					$ext_list = array_merge(array('\jv\arcade_startsystem\inc\acp_settings' => $ext_list['\jv\arcade_startsystem\inc\acp_settings']), $ext_list);
				}

				foreach ($ext_list as $ext_class => $ext)
				{
					$this->ext_class[$ext_class] = $ext;
					$language_file = $this->ext_class[$ext_class]->get_language();

					if (!empty($language_file['vendor']))
					{
						$this->user->add_lang_ext($language_file['vendor'], $language_file['file']);
					}

					$first = true;
					foreach ($this->ext_class[$ext_class]->get_template_acp() as $k => $v)
					{
						if (strpos($k, 'legend') !== false)
						{
							// Only one legend is allowed.
							if (!$first)
							{
								continue;
							}

							$l++;

							$name = (!$v || (is_array($v) && !$v['name'])) ? sprintf($this->user->lang['ACP_ARCADE_EXT_NAME_OPTIONS'], $this->user->lang[$this->ext_class[$ext_class]->name]) : ((is_array($v)) ? $v['name'] : $v);
							$explain = (!empty($v['explain'])) ? $v['explain'] : false;

							$display_vars += array('legend' . $l => array('name' => $name, 'explain' => $explain));

							if ($first)
							{
								$first = false;
								$ext_name = $this->arcade->ext()->get_class_name($ext_class);

								if ($ext_name)
								{
									$display_vars += array('version' . $l => array(
										'explain' => (!empty($this->ext_class[$ext_class]->version_explain)) ? $this->ext_class[$ext_class]->name . '_EXPLAIN' : false,
										'content' => '<b>' . $this->ext_class[$ext_class]->version . '</b>' . (($ext_name != 'jv/arcade_startsystem') ? ' <a href="' . $this->u_action . '&amp;action=version_check&amp;ext_name=' . $ext_name . '&amp;versioncheck_force=1">[ ' . $this->user->lang['VERSION_CHECK'] . ' ]</a>' : '')
									));
								}
							}
						}
						else
						{
							$submit_config = true;

							if ($v !== false)
							{
								$v += array('_ext_class' => $ext_class);
							}

							$display_vars += array($k => $v);
						}
					}
				}

				if ($submit_config)
				{
					$l++;
					$display_vars += array('legend' . $l => array('name' => 'ACP_SUBMIT_CHANGES', 'explain' => false));
				}
			break;

			case 'version_check':
				$this->page_title = 'ACP_VERSION_CHECK';
				$this->tpl_name = 'arcade/version_check';

				$this->arcade->container('version_check')->main($ext_name, $this->u_action, $versioncheck_force);

				$this->template->assign_vars(array(
					'L_ARCADE_TITLE' => $this->user->lang['ACP_ARCADE_EXT_VERSION_CHECK']
				));
				return;
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		$this->new_config = clone $this->arcade_config;
		$cfg_array = (isset($_REQUEST['config'])) ? $this->request->variable('config', array('' => ''), true) : $this->new_config;
		$error = array();

		// We validate the complete config if whished
		validate_config_vars($display_vars, $cfg_array, $error);

		if ($submit && !check_form_key($form_key))
		{
			$error[] = $this->user->lang['FORM_INVALID'];
		}

		// Do not write values if there is an error
		if (count($error))
		{
			$submit = false;
		}

		// We go through the display_vars to make sure no one is trying to set variables he/she is not allowed to...
		foreach ($display_vars as $config_name => $null)
		{
			if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false || strpos($config_name, 'version') !== false)
			{
				continue;
			}

			$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

			if ($submit)
			{
				$this->arcade_config->set($config_name, $config_value);
			}
		}

		if ($submit)
		{
			$this->arcade->add_log('admin', 'LOG_ARCADE_EXT_SETTINGS');
			trigger_error($this->user->lang['CONFIG_UPDATED'] . adm_back_link($this->u_action));
		}

		$this->template->assign_vars(array(
			'L_TITLE'				=> $this->user->lang[$this->page_title],
			'L_TITLE_EXPLAIN'		=> $this->user->lang[$this->page_title . '_EXPLAIN'],

			'VERSIONCHECK_FORCE'	=> '<a onclick="window.open(this.href); return false;" href="' . append_sid("{$this->admin_path}index.{$this->php_ext}", 'i=acp_extensions&amp;mode=main&amp;action=list&amp;versioncheck_force=1') . '">' . $this->user->lang['ACP_ARCADE_ALL_VERSION_CHECK'] . '</a>',

			'S_SUBMIT_CONFIG'		=> $submit_config,
			'S_ERROR'				=> (count($error)) ? true : false,
			'ERROR_MSG'				=> implode('<br>', $error),

			'U_ACTION'				=> $this->u_action
		));

		// Output relevant page
		foreach ($display_vars as $config_key => $vars)
		{
			if (!is_array($vars) && strpos($config_key, 'legend') === false && strpos($config_key, 'version') === false)
			{
				continue;
			}

			if (strpos($config_key, 'legend') !== false)
			{
				$this->template->assign_block_vars('options', array(
					'S_LEGEND'			=> true,
					'LEGEND'			=> $this->arcade->lang_value($vars['name']),
					'LEGEND_EXPLAIN'	=> ($vars['explain']) ? $this->arcade->lang_value($vars['explain']) : false,
				));

				continue;
			}

			if (strpos($config_key, 'version') !== false)
			{
				$this->template->assign_block_vars('options', array(
					'S_EXT_VERSION'	=> true,
					'TITLE'			=> $this->user->lang['ACP_ARCADE_EXT_VERSION'],
					'S_EXPLAIN'		=> ($vars['explain']) ? true : false,
					'TITLE_EXPLAIN'	=> ($vars['explain']) ? $this->user->lang[$vars['explain']] : false,
					'CONTENT'		=> $vars['content']
					
				));

				continue;
			}

			$type = explode(':', $vars['type']);

			$l_explain = '';
			if ($vars['explain'] && isset($vars['lang_explain']))
			{
				$l_explain = $this->arcade->lang_value($vars['lang_explain']);
			}
			else if ($vars['explain'])
			{
				$l_explain = $this->arcade->lang_value($vars['lang'] . '_EXPLAIN', true);
			}

			if ($vars['type'] != 'custom' || empty($vars['_ext_class']))
			{
				$content = build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars);
			}
			else
			{
				$args = array($this->new_config[$config_key], $config_key);

				if (isset($vars['function']))
				{
					$func = $vars['function'];
				}
				else
				{
					$func = array($this->ext_class[$vars['_ext_class']], $vars['method']);
				}

				$content = call_user_func_array($func, $args);
			}

			if (empty($content))
			{
				continue;
			}

			$this->template->assign_block_vars('options', array(
				'KEY'			=> $config_key,
				'TITLE'			=> $this->user->lang[$vars['lang']],
				'S_EXPLAIN'		=> $vars['explain'],
				'TITLE_EXPLAIN'	=> $l_explain,
				'CONTENT'		=> $content
			));

			unset($display_vars[$config_key]);
		}
	}
}
