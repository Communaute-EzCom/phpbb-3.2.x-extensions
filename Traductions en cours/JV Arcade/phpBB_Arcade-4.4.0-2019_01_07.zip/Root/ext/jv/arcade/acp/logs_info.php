<?php
/**
*
* @package phpBB Arcade
* @version $Id: logs_info.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class logs_info
{
	function module()
	{
		return array(
			'filename'			=> '\jv\arcade\acp\logs_module',
			'title'				=> 'ACP_ARCADE_LOGS',
			'modes'				=> array(
				'admin'			=> array('title' => 'ACP_ARCADE_LOGS_ADMIN'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_viewlogs', 'cat' => array('ACP_CAT_ARCADE_LOGS')),
				'mod'			=> array('title' => 'ACP_ARCADE_LOGS_MOD'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_viewlogs', 'cat' => array('ACP_CAT_ARCADE_LOGS')),
				'users'			=> array('title' => 'ACP_ARCADE_LOGS_USERS'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_viewlogs', 'cat' => array('ACP_CAT_ARCADE_LOGS')),
				'critical'		=> array('title' => 'ACP_ARCADE_LOGS_CRITICAL'	, 'auth' => 'ext_jv/arcade && acl_a_arcade_viewlogs', 'cat' => array('ACP_CAT_ARCADE_LOGS')),
			)
		);
	}
}
