<?php
/**
*
* @package phpBB Arcade
* @version $Id: utilities_module.php 2136 2019-01-05 19:42:24Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class utilities_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $admin_path;
	protected $db, $cache, $auth, $request, $user, $template, $root_path, $php_ext;
	protected $arcade_config, $arcade, $file_functions;

	public function __construct()
	{
		global $phpbb_admin_path;
		global $db, $cache, $auth, $request, $user, $template, $phpbb_root_path, $phpEx;
		global $arcade_config, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->admin_path = $phpbb_admin_path;
		$this->db = $db;
		$this->cache = $cache;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
		$this->file_functions = $this->arcade->container('functions_file');
	}

	public function main($id, $mode)
	{
		$ip		= $this->request->variable('ip', 'ip');
		$start	= $this->request->variable('start', 0);
		$action	= $this->request->variable('action', '');
		$marked	= $this->request->variable('mark', array(0));

		// Sort keys
		$sort_days	= $this->request->variable('st', 0);
		$sort_key	= $this->request->variable('sk', 'd');
		$sort_dir	= $this->request->variable('sd', 'd');

		if ($action == 'whois')
		{
			$this->whois();
			return;
		}

		$this->arcade->valid_start($start);

		$errors = array();
		$this->tpl_name = 'arcade/acp_utilities';
		$this->page_title = $this->user->lang['ACP_ARCADE_UTILITIES_' . strtoupper($mode)];
		$pagination = $this->arcade->container('phpbb_pagination');

		switch ($mode)
		{
			case 'reports':
				$deletemark = $this->arcade->is_post_empty('delmarked');
				$deleteall	= $this->arcade->is_post_empty('delall');

				$this->template->assign_var('S_IN_ARCADE_REPORTS', true);

				switch ($action)
				{
					case 'open':
					case 'close':
						$report_id = $this->request->variable('report_id', 0);
						if ($report_id)
						{
							$this->arcade->report_toggle($action, $report_id);
						}
					break;
				}

				// Delete entries if requested and able
				if ($deletemark || $deleteall)
				{
					if ($deletemark && !count($marked))
					{
						trigger_error($this->user->lang['ARCADE_SELECT_EMPTY'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					if (confirm_box(true))
					{
						$where_sql = '';

						if ($deletemark && count($marked))
						{
							$sql_in = array();
							foreach ($marked as $mark)
							{
								$sql_in[] = $mark;
							}
							$where_sql = $this->db->sql_in_set('report_id', $sql_in);
							unset($sql_in);
						}

						if ($where_sql || $deleteall)
						{
							if ($where_sql)
							{
								$sql = 'SELECT COUNT(report_id) AS total_open FROM ' . ARCADE_REPORTS_TABLE . "
										WHERE {$where_sql}
										AND report_closed = 0";
								$result = $this->db->sql_query($sql);
								$total_open = (int) $this->db->sql_fetchfield('total_open');
								$this->db->sql_freeresult($result);

								$this->db->sql_query('DELETE FROM ' . ARCADE_REPORTS_TABLE . " WHERE {$where_sql}");
								$this->arcade_config->increment('reports_open', "-{$total_open}");
							}
							else
							{
								$this->arcade->delete_table_data(ARCADE_REPORTS_TABLE);
								$this->arcade_config->set('reports_open', 0);
							}

							$this->arcade->add_log('admin', 'LOG_ARCADE_CLEAR_' . strtoupper($mode));
						}
					}
					else
					{
						confirm_box(false, $this->user->lang['CONFIRM_OPERATION'], build_hidden_fields(array(
							'start'		=> $start,
							'delmarked'	=> $deletemark,
							'delall'	=> $deleteall,
							'mark'		=> $marked
						)));
					}
				}

				if ($report_count = $this->arcade->get->total('game', 'reports', $sort_days))
				{
					// Sorting
					$limit_days = array(0 => $this->user->lang['ALL_ENTRIES'], 1 => $this->user->lang['1_DAY'], 7 => $this->user->lang['7_DAYS'], 14 => $this->user->lang['2_WEEKS'], 30 => $this->user->lang['1_MONTH'], 90 => $this->user->lang['3_MONTHS'], 180 => $this->user->lang['6_MONTHS'], 365 => $this->user->lang['1_YEAR']);
					$sort_by_text = array('u' => $this->user->lang['SORT_USERNAME'], 'i' => $this->user->lang['SORT_IP'], 'g' => $this->user->lang['ARCADE_GAME_NAME'], 't' => $this->user->lang['ARCADE_ERROR_TYPE'], 'd' => $this->user->lang['SORT_DATE']);
					$sort_by_sql = array('u' => 'u.username_clean', 'i' => 'r.report_ip', 'g' => 'g.game_name_clean', 't' => 'r.report_type', 'd' => 'r.report_time');

					$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
					gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

					// Define where and sort sql for use in displaying logs
					$sql_where = ($sort_days) ? (time() - ($sort_days * 86400)) : 0;
					$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

					$sql_array = array(
						'SELECT'	=> 'r.*, u.username, u.user_colour, g.game_name, g.game_image, g.game_type, g.game_save_type, g.cat_id',
						'FROM'		=> array(
							ARCADE_REPORTS_TABLE	=> 'r',
						),
						'LEFT_JOIN'	=> array(
							array(
								'FROM'	=> array(USERS_TABLE => 'u'),
								'ON'	=> 'r.user_id = u.user_id'
							),
							array(
								'FROM'	=> array(ARCADE_GAMES_TABLE => 'g'),
								'ON'	=> 'r.game_id = g.game_id'
							),
						),
						'ORDER_BY'	=> $sql_sort,
					);

					if ($sql_where)
					{
						$sql_array['WHERE'] = 'r.report_time >= ' . $sql_where;
					}

					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);
					while ($row = $this->db->sql_fetchrow($result))
					{
						$game_types = $this->user->lang['ARCADE_GAME_TYPE'] . $this->user->lang['COLON'] . ' ' . $this->arcade->game()->type($row['game_type'], true) . ', ' . $this->user->lang['ARCADE_GAME_SAVE_TYPE'] . $this->user->lang['COLON'] . ' ' . $this->arcade->game()->save_type($row['game_save_type'], true) . '.' . (($row['report_desc']) ? '<br><br>' : '');

						$this->template->assign_block_vars('reports', array(
							'S_REPORT_CLOSED'	=> $row['report_closed'],
							'S_TOPIC'			=> ($this->arcade_config['report_game_announce_forum'] && !empty($row['post_id']) && $this->auth->acl_get('f_read', $this->arcade_config['report_game_announce_forum'])) ? true : false,

							'U_TOPIC'			=> $this->arcade->url("p={$row['post_id']}", 'viewtopic') . "#p{$row['post_id']}",
							'U_GAME'			=> append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('manage') . "&amp;mode=games&amp;action=edit&amp;g={$row['game_id']}"),
							'U_OPEN'			=> "{$this->u_action}&amp;action=open&amp;report_id={$row['report_id']}",
							'U_CLOSE'			=> "{$this->u_action}&amp;action=close&amp;report_id={$row['report_id']}",
							'U_REPORT_IP'		=> $this->u_action . "&amp;ip=" . (($ip == 'ip') ? 'hostname' : 'ip'),
							'U_WHOIS'			=> $this->u_action . "&amp;action=whois&amp;whois_ip={$row['report_ip']}",

							'GAME_NAME'			=> $this->arcade->get->game_name($row['game_name']),
							'GAME_IMAGE'		=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get->game_image($row['game_image'], 50, 50, 'x', 'play', $row['cat_id'], $row['game_id'], false, true) : false,
							'REPORT_ID'			=> $row['report_id'],
							'REPORT_IP'			=> ($ip == 'hostname') ? gethostbyaddr($row['report_ip']) : $row['report_ip'],
							'REPORT_DESC'		=> $game_types . generate_text_for_display($row['report_desc'], $row['report_desc_uid'], $row['report_desc_bitfield'], $row['report_desc_options']),
							'REPORT_TIME'		=> $this->user->format_date($row['report_time']),
							'REPORT_TYPE'		=> $this->arcade->display_report_type($row['report_type']),
							'USERNAME'			=> $this->arcade->get->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'pm_quotereport', 'x', false, $row['report_id'])
						));
					}
					$this->db->sql_freeresult($result);

					$pagination->generate_template_pagination($this->u_action . "&amp;st=$sort_days&amp;sk=$sort_key&amp;sd=$sort_dir", 'pagination', 'start', $report_count, $this->arcade_config['acp_items_per_page'], $start);

					$this->template->assign_vars(array(
						'S_GAME_EDIT'			=> ($this->auth->acl_get('a_arcade_game')) ? true : false,
						'S_DISPLAY_GAME_IMAGES'	=> ($this->arcade_config['display_game_image'] && $this->arcade->optionget('view_game_image')) ? true : false,

						'S_LIMIT_DAYS'			=> $s_limit_days,
						'S_SORT_KEY'			=> $s_sort_key,
						'S_SORT_DIR'			=> $s_sort_dir,

						'U_ACTION'				=> $this->u_action
					));
				}
			break;

			case 'deleted_games':
				$marked	= $this->request->variable('mark', array(''));
				$deletemark = $this->arcade->is_post_empty('delmarked');
				$deleteall	= $this->arcade->is_post_empty('delall');

				$this->template->assign_var('S_IN_DELETED_GAMES', true);

				if ($deletemark || $deleteall)
				{
					if ($deletemark && !count($marked))
					{
						trigger_error($this->user->lang['ARCADE_SELECT_EMPTY'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					if (confirm_box(true))
					{
						$where_sql = '';

						if ($deletemark && count($marked))
						{
							$sql_in = array();
							foreach ($marked as $mark)
							{
								$sql_in[] = $mark;
							}
							$where_sql = $this->db->sql_in_set('game_swf', $sql_in);
							unset($sql_in);
						}

						if ($where_sql || $deleteall)
						{
							if ($where_sql)
							{
								$msg = 'ACP_ARCADE_DELETE_SELECTED_DATA' . ((count($marked) > 1) ? 'S' : '') . '_SUCCESS';
								$this->db->sql_query('DELETE FROM ' . ARCADE_DELETE_GAMES_TABLE . " WHERE $where_sql");
							}
							else
							{
								$msg = 'ACP_ARCADE_DELETE_ALL_DATA_SUCCESS';
								$this->arcade->delete_table_data(ARCADE_DELETE_GAMES_TABLE);
							}

							$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_DELETED_GAMES');
							trigger_error($this->user->lang[$msg] . adm_back_link($this->u_action));
						}
					}
					else
					{
						confirm_box(false, $this->user->lang['CONFIRM_OPERATION'], build_hidden_fields(array(
							'start'		=> $start,
							'delmarked'	=> $deletemark,
							'delall'	=> $deleteall,
							'mark'		=> $marked
						)));
					}
				}

				if ($row_count = $this->arcade->get->total('game', 'deleted_games', $sort_days))
				{
					// Sorting
					$limit_days = array(0 => $this->user->lang['ALL_ENTRIES'], 1 => $this->user->lang['1_DAY'], 7 => $this->user->lang['7_DAYS'], 14 => $this->user->lang['2_WEEKS'], 30 => $this->user->lang['1_MONTH'], 90 => $this->user->lang['3_MONTHS'], 180 => $this->user->lang['6_MONTHS'], 365 => $this->user->lang['1_YEAR']);
					$sort_by_text = array('f' => $this->user->lang['FILENAME'], 'r' => $this->user->lang['ACP_ARCADE_REASON_DELETE'], 'd' => $this->user->lang['ARCADE_DELETE_DATE']);
					$sort_by_sql = array('f' => 'd.game_swf', 'r' => 'd.reason', 'd' => 'd.uninstalldate');

					$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
					gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

					// Define where and sort sql for use in displaying logs
					$sql_where = ($sort_days) ? (time() - ($sort_days * 86400)) : 0;
					$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

					$sql_array = array(
						'SELECT'	=> '*',
						'FROM'		=> array(
							ARCADE_DELETE_GAMES_TABLE	=> 'd',
						),
						'ORDER_BY'	=> $sql_sort,
					);

					if ($sql_where)
					{
						$sql_array['WHERE'] = 'd.uninstalldate >= ' . $sql_where;
					}

					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);
					while ($row = $this->db->sql_fetchrow($result))
					{
						$this->template->assign_block_vars('games', array(
							'FILENAME'	=> $row['game_swf'],
							'REASON'	=> $row['reason'],
							'DATE'		=> ($row['uninstalldate']) ? $this->user->format_date($row['uninstalldate']) : $this->user->lang['NA']
						));
					}
					$this->db->sql_freeresult($result);

					$pagination->generate_template_pagination($this->u_action . "&amp;st=$sort_days&amp;sk=$sort_key&amp;sd=$sort_dir", 'pagination', 'start', $row_count, $this->arcade_config['acp_items_per_page'], $start);

					$this->template->assign_vars(array(
						'S_LIMIT_DAYS'	=> $s_limit_days,
						'S_SORT_KEY'	=> $s_sort_key,
						'S_SORT_DIR'	=> $s_sort_dir,
						'U_ACTION'		=> $this->u_action
					));
				}
			break;

			case 'users_banned':
				if (!$this->auth->acl_get('a_arcade_user'))
				{
					send_status_line(403, 'Forbidden');
					trigger_error($this->user->lang['NOT_AUTHORISED'] . adm_back_link($this->u_action), E_USER_WARNING);
				}

				$deletemark	= $this->arcade->is_post_empty('delmarked');
				$deleteall	= $this->arcade->is_post_empty('delall');

				$this->template->assign_var('S_IN_ARCADE_BANNED', true);

				if ($deletemark || $deleteall)
				{
					if ($deletemark && !count($marked))
					{
						trigger_error($this->user->lang['ARCADE_SELECT_EMPTY'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					if (confirm_box(true))
					{
						$where_sql = '';

						if ($deletemark && count($marked))
						{
							$sql_in = array();
							foreach ($marked as $mark)
							{
								$sql_in[] = $mark;
							}
							$where_sql = $this->db->sql_in_set('user_id', $sql_in);
							unset($sql_in);
						}

						if ($where_sql || $deleteall)
						{
							if ($where_sql)
							{
								$this->db->sql_query('DELETE FROM ' . ARCADE_USERS_BANNED_TABLE . " WHERE $where_sql");

								$sql = 'SELECT username
										FROM ' . USERS_TABLE . "
										WHERE $where_sql";
								$result = $this->db->sql_query($sql);
								$usernames = array();
								while ($row = $this->db->sql_fetchrow($result))
								{
									$usernames[] = $row['username'];
								}
								$this->db->sql_freeresult($result);

								$usernames = implode(', ', $usernames);
								$log_msg = 'LOG_ARCADE_CLEAR_' . ((count($marked) > 1) ? 'USERS' : 'USER') . '_BANNED';
								$this->arcade->add_log('admin', $log_msg, $usernames);
								$message = sprintf($this->user->lang['ARCADE_BANNED_EXCLUDE_MARKED_SUCCESS_' . ((count($marked) > 1) ? 'USERS' : 'USER')], $usernames);
							}
							else
							{
								$this->arcade->delete_table_data(ARCADE_USERS_BANNED_TABLE);
								$this->arcade->add_log('admin', 'LOG_ARCADE_CLEAR_ALL_USERS_BANNED');
								$message = $this->user->lang['ARCADE_BANNED_EXCLUDE_ALL_SUCCESS'];
							}

							$this->cache->destroy('_arcade_ban_users');
							trigger_error($message . adm_back_link($this->u_action));
						}
					}
					else
					{
						confirm_box(false, $this->user->lang['CONFIRM_OPERATION'], build_hidden_fields(array(
							'start'		=> $start,
							'delmarked'	=> $deletemark,
							'delall'	=> $deleteall,
							'mark'		=> $marked
						)));
					}
				}

				if ($banned_count = $this->arcade->get->total('user', 'banned', $sort_days))
				{
					$limit_days = array(0 => $this->user->lang['ALL_ENTRIES'], 1 => $this->user->lang['1_DAY'], 7 => $this->user->lang['7_DAYS'], 14 => $this->user->lang['2_WEEKS'], 30 => $this->user->lang['1_MONTH'], 90 => $this->user->lang['3_MONTHS'], 180 => $this->user->lang['6_MONTHS'], 365 => $this->user->lang['1_YEAR']);
					$sort_by_text = array('u' => $this->user->lang['SORT_USERNAME'], 'i' => $this->user->lang['SORT_IP'], 'd' => $this->user->lang['SORT_DATE']);
					$sort_by_sql = array('u' => 'u.username_clean', 'i' => 'b.banned_ip', 'd' => 'b.banned_date');

					$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
					gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

					$sql_where = ($sort_days) ? (time() - ($sort_days * 86400)) : 0;
					$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

					$sql_array = array(
						'SELECT'	=> 'b.*, u.user_id, u.username, u.user_colour, u.username_clean, u.user_avatar, u.user_avatar_type, g.game_name, g.game_save_type, g.cat_id',
						'FROM'		=> array(
							ARCADE_USERS_BANNED_TABLE	=> 'b',
						),
						'LEFT_JOIN'	=> array(
							array(
								'FROM'	=> array(USERS_TABLE => 'u'),
								'ON'	=> 'b.user_id = u.user_id'
							),
							array(
								'FROM'	=> array(ARCADE_GAMES_TABLE => 'g'),
								'ON'	=> 'b.game_id = g.game_id'
							),
						),

						'ORDER_BY'	=> $sql_sort,
					);

					if ($sql_where)
					{
						$sql_array['WHERE'] = 'b.banned_date >= ' . $sql_where;
					}

					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);
					while ($row = $this->db->sql_fetchrow($result))
					{
						$banned_type	= '<strong>' . $this->display_banned_type($row['banned_type']) . '</strong>';
						$game_info		= '';

						if (!in_array($row['banned_type'], array(ARCADE_BANNED_UNKNOWN, ARCADE_BANNED_ADMIN)))
						{
							if ($row['banned_type'] != ARCADE_BANNED_TIME_HACK)
							{
								$banned_type .= '<br><br>' . $this->user->lang['ARCADE_FORM_TIME'] . ': ' . (($row['formtime'] == 0) ? '<strong>(-)</strong> ' : '<strong>' . $row['formtime'] . '</strong> ' . $this->user->lang['SECONDS'] . ' - ');

								if ($row['formtime'] > 0 && $row['formtime'] <= $this->arcade_config['score_form_token_lifetime'])
								{
									$banned_type .= '<strong style="color: #228822;">' . $this->user->lang['CORRECT'] . '</strong>';
								}
								else
								{
									$banned_type .= '<strong style="color: #BC2A4D;">' . $this->user->lang['INCORRECT'] . '</strong>';
								}

								switch ($row['banned_type'])
								{
									case ARCADE_BANNED_INVALID_FORM1:
										$banned_type .= '<br><em>' . $this->user->lang['ARCADE_INVALID_FORM1_EXPLAIN'] . '</em>';
									break;

									case ARCADE_BANNED_INVALID_FORM2:

										$banned_type .= '<br><em>' . $this->user->lang['ARCADE_INVALID_FORM2_' . (($row['formtime'] == 0) ? 'NO' : '') . 'TIME_EXPLAIN'] . '</em>';
									break;

									case ARCADE_BANNED_INVALID_FORM3:
										$banned_type .= '<br><em>' . $this->user->lang['ARCADE_INVALID_FORM3_EXPLAIN'] . '</em>';
									break;
								}
							}

							if (!empty($row['game_id']))
							{
								$game_info =	'<strong>' . $this->user->lang['ARCADE_GAME_NAME'] . ':</strong> ' . $this->arcade->get->game_name($row['game_name'], true, 'play', $row['cat_id'], $row['game_id'], 'x') . '<br>' .
												'<strong>' . $this->user->lang['ARCADE_GAME_SAVE_TYPE'] . ':</strong> ' . $this->arcade->game->save_type($row['game_save_type'], true) . '<br>' .
												'<strong>' . $this->user->lang['ARCADE_SCORE'] . ':</strong> ' . $this->arcade->number_format($row['score']) . '<br>';
							}
						}

						$this->template->assign_block_vars('banned', array(
							'USER_ID'		=> $row['user_id'],
							'AVATAR'		=> ($this->arcade->optionget('view_avatars')) ? $this->arcade->get->user_avatar($row['user_avatar'], $row['user_avatar_type'], 40, 40, 'x', 'profile', $row['user_id']) : '',
							'USERNAME'		=> $this->arcade->adm_username($row['user_id'], $row['username'], $row['user_colour']),
							'BANNED_TYPE'	=> $banned_type,
							'BANNED_DATE'	=> $this->user->format_date($row['banned_date']),
							'BANNED_IP'		=> ($ip == 'hostname') ? gethostbyaddr($row['banned_ip']) : $row['banned_ip'],
							'GAME_INFO'		=> $game_info,
							'U_BANNED_IP'	=> $this->u_action . "&amp;ip=" . (($ip == 'ip') ? 'hostname' : 'ip'),
							'U_WHOIS'		=> $this->u_action . "&amp;action=whois&amp;whois_ip={$row['banned_ip']}",
						));
					}
					$this->db->sql_freeresult($result);

					$pagination->generate_template_pagination($this->u_action . "&amp;st=$sort_days&amp;sk=$sort_key&amp;sd=$sort_dir", 'pagination', 'start', $banned_count, $this->arcade_config['acp_items_per_page'], $start);

					$this->template->assign_vars(array(
						'S_LIMIT_DAYS'	=> $s_limit_days,
						'S_SORT_KEY'	=> $s_sort_key,
						'S_SORT_DIR'	=> $s_sort_dir,
						'U_ACTION'		=> $this->u_action
					));
				}
			break;

			case 'download_stats':
				$this->template->assign_var('S_IN_DOWNLOAD_STATS', true);

				switch ($action)
				{
					case 'view':
						$user_id = $this->request->variable('u', 0);

						$this->template->assign_var('S_IN_DOWNLOAD_STATS_VIEW', true);

						if (!($row_count = $this->arcade->get->total('game', 'downloads', $user_id, $sort_days)))
						{
							trigger_error($this->user->lang['NO_ARCADE_DOWNLOAD_STATS_USER'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						// Sorting
						$limit_days = array(0 => $this->user->lang['ALL_ENTRIES'], 1 => $this->user->lang['1_DAY'], 7 => $this->user->lang['7_DAYS'], 14 => $this->user->lang['2_WEEKS'], 30 => $this->user->lang['1_MONTH'], 90 => $this->user->lang['3_MONTHS'], 180 => $this->user->lang['6_MONTHS'], 365 => $this->user->lang['1_YEAR']);
						$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 't' => $this->user->lang['ARCADE_STATS_TOTAL_DOWNLOADS'], 'd' => $this->user->lang['ARCADE_DOWNLOAD_DATE']);
						$sort_by_sql = array('g' => 'g.game_name_clean', 't' => 'total', 'd' => 'download_time');

						$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
						gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

						// Define where and sort sql for use in displaying logs
						$sql_where = ($sort_days) ? (time() - ($sort_days * 86400)) : 0;
						$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

						$sql_array = array(
							'SELECT'	=> 'd.total, d.game_id, d.download_time, g.game_name, g.game_name_clean, g.game_image, g.cat_id',
							'FROM'		=> array(
								ARCADE_DOWNLOAD_TABLE	=> 'd',
							),
							'LEFT_JOIN'	=> array(
								array(
									'FROM'	=> array(ARCADE_GAMES_TABLE => 'g'),
									'ON'	=> 'd.game_id = g.game_id'
								),
							),
							'WHERE'		=> 'd.game_id = g.game_id AND d.user_id = ' . (int) $user_id,
							'ORDER_BY'	=> $sql_sort,
						);

						if ($sql_where)
						{
							$sql_array['WHERE'] = 'd.download_time >= ' . $sql_where;
						}

						$sql = $this->db->sql_build_query('SELECT', $sql_array);
						$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$this->template->assign_block_vars('games', array(
								'DATE'			=> ($row['download_time']) ? $this->user->format_date($row['download_time']) : $this->user->lang['NA'],
								'GAME_IMAGE'	=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get->game_image($row['game_image'], 30, 30, 'x', 'play', $row['cat_id'], $row['game_id'], false, true) : false,
								'U_GAME'		=> append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('manage') . "&amp;mode=games&amp;action=edit&amp;g={$row['game_id']}"),
								'GAME_NAME'		=> $this->arcade->get->game_name($row['game_name'], false),
								'TOTAL'			=> $this->arcade->number_format($row['total'])
							));
						}
						$this->db->sql_freeresult($result);

						$user_data = $this->arcade->userdata('full_username', $user_id);
						$pagination->generate_template_pagination($this->u_action . "&amp;st=$sort_days&amp;action=view&amp;u=$user_id&amp;sk=$sort_key&amp;sd=$sort_dir", 'pagination', 'start', $row_count, $this->arcade_config['acp_items_per_page'], $start);

						$this->template->assign_vars(array(
							'S_GAME_EDIT'			=> ($this->auth->acl_get('a_arcade_game')) ? true : false,
							'S_DISPLAY_GAME_IMAGES'	=> ($this->arcade_config['display_game_image'] && $this->arcade->optionget('view_game_image')) ? true : false,
							'S_LIMIT_DAYS'			=> $s_limit_days,
							'S_SORT_KEY'			=> $s_sort_key,
							'S_SORT_DIR'			=> $s_sort_dir,

							'U_ACTION'				=> $this->u_action . "&amp;action=$action&amp;u=$user_id",

							'DOWNLOAD_STATS_USER'	=> sprintf($this->user->lang['ARCADE_DOWNLOAD_USER_STATS'], $this->arcade->adm_username($user_data['user_id'], $user_data['username'], $user_data['user_colour']))
						));
					break;

					default:
						if ($row_count = $this->arcade->get->total('user', 'downloads', false, $sort_days))
						{
							// Sorting
							$limit_days = array(0 => $this->user->lang['ALL_ENTRIES'], 1 => $this->user->lang['1_DAY'], 7 => $this->user->lang['7_DAYS'], 14 => $this->user->lang['2_WEEKS'], 30 => $this->user->lang['1_MONTH'], 90 => $this->user->lang['3_MONTHS'], 180 => $this->user->lang['6_MONTHS'], 365 => $this->user->lang['1_YEAR']);
							$sort_by_text = array('u' => $this->user->lang['SORT_USERNAME'], 't' => $this->user->lang['ARCADE_STATS_TOTAL_DOWNLOADS'], 'd' => $this->user->lang['ARCADE_LAST_DOWNLOAD']);
							$sort_by_sql = array('u' => 'u.username_clean', 't' => 'total', 'd' => 'last_download');

							$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
							gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

							// Define where and sort sql for use in displaying logs
							$sql_where = ($sort_days) ? (time() - ($sort_days * 86400)) : 0;
							$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

							$sql_array = array(
								'SELECT'	=> 'SUM(d.total) AS total, MAX(d.download_time) AS last_download, u.user_id, u.username, u.username_clean, u.user_colour',
								'FROM'		=> array(
									ARCADE_DOWNLOAD_TABLE	=> 'd',
								),
								'LEFT_JOIN'	=> array(
									array(
										'FROM'	=> array(USERS_TABLE => 'u'),
										'ON'	=> 'd.user_id = u.user_id'
									),
								),
								'WHERE'		=> 'd.user_id = u.user_id',
								'GROUP_BY'	=> 'u.user_id, u.username, u.username_clean, u.user_colour',
								'ORDER_BY'	=> $sql_sort,
							);

							if ($sql_where)
							{
								$sql_array['WHERE'] = 'd.download_time >= ' . $sql_where;
							}

							$sql = $this->db->sql_build_query('SELECT', $sql_array);
							$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);
							while ($row = $this->db->sql_fetchrow($result))
							{
								$this->template->assign_block_vars('users', array(
									'USERNAME'	=> $this->arcade->get->username_string('full', $row['user_id'], $row['username'], $row['user_colour'], false, "{$this->u_action}&amp;action=view"),
									'TOTAL'		=> $this->arcade->number_format($row['total']),
									'DATE'		=> $this->user->format_date($row['last_download'])
								));
							}
							$this->db->sql_freeresult($result);

							$pagination->generate_template_pagination($this->u_action . "&amp;st=$sort_days&amp;sk=$sort_key&amp;sd=$sort_dir", 'pagination', 'start', $row_count, $this->arcade_config['acp_items_per_page'], $start);

							$this->template->assign_vars(array(
								'U_ACTION'		=> $this->u_action,
								'S_LIMIT_DAYS'	=> $s_limit_days,
								'S_SORT_KEY'	=> $s_sort_key,
								'S_SORT_DIR'	=> $s_sort_dir
							));
						}
					break;
				}
			break;

			case 'create_install':
				$form_key = 'acp_arcade_utilities';
				add_form_key($form_key);

				$cfg_array = (isset($_REQUEST['config'])) ? $this->request->variable('config', array('' => ''), true) : array();

				$downloadnew = $this->arcade->is_post_empty('downloadnew');
				$view		 = $this->arcade->is_post_empty('view');
				$viewnew	 = $this->arcade->is_post_empty('viewnew');
				$create		 = $this->arcade->is_post_empty('create');

				$game_id	 = (int) $this->request->variable('g', 0);
				$download	 = $this->arcade->is_post_empty('download');
				$update		 = $this->arcade->is_post_empty('update');

				$methods = $this->arcade->compress_methods();

				$cfg_array['game_name'] = (isset($cfg_array['game_name'])) ? $cfg_array['game_name'] : '';
				$cfg_array['game_desc'] = (isset($cfg_array['game_desc'])) ? $cfg_array['game_desc'] : '';
				$cfg_array['game_control'] = (isset($cfg_array['game_control'])) ? $cfg_array['game_control'] : 1;
				$cfg_array['game_control_desc'] = (isset($cfg_array['game_control_desc'])) ? $cfg_array['game_control_desc'] : '';
				$cfg_array['game_image'] = (isset($cfg_array['game_image'])) ? $cfg_array['game_image'] : '';
				$cfg_array['game_folder_name'] = (isset($cfg_array['game_folder_name'])) ? $cfg_array['game_folder_name'] : '';
				$cfg_array['game_scorevar'] = (isset($cfg_array['game_scorevar'])) ? $cfg_array['game_scorevar'] : '';
				$cfg_array['game_width'] = (isset($cfg_array['game_width'])) ? $cfg_array['game_width'] : 0;
				$cfg_array['game_height'] = (isset($cfg_array['game_height'])) ? $cfg_array['game_height'] : 0;
				$cfg_array['game_type'] = (isset($cfg_array['game_type'])) ? $cfg_array['game_type'] : GAME_TYPE_HTML5;
				$cfg_array['game_save_type'] = (isset($cfg_array['game_save_type'])) ? $cfg_array['game_save_type'] : PHPBBARCADE_GAME;
				$cfg_array['game_scoretype'] = (isset($cfg_array['game_scoretype'])) ? $cfg_array['game_scoretype'] : 0;
				$cfg_array['use_method'] = (isset($cfg_array['use_method'])) ? $cfg_array['use_method'] : '.tar';
				$cfg_array['use_method_new'] = (isset($cfg_array['use_method_new'])) ? $cfg_array['use_method_new'] : '.tar';
				$cfg_array['privacy_desc'] = (isset($cfg_array['privacy_desc'])) ? $cfg_array['privacy_desc'] : '';
				$cfg_array['privacy_link'] = (isset($cfg_array['privacy_link'])) ? $cfg_array['privacy_link'] : '';

				$new_install_file_content = $this->arcade->game->install_file->create($cfg_array, true);

				$this->template->assign_vars(array(
					'S_IN_CREATE_INSTALL'		=> true,
					'GAME_NAME'					=> $cfg_array['game_name'],
					'GAME_DESC'					=> $cfg_array['game_desc'],
					'GAME_CONTROL_SELECT'		=> $this->arcade->game_control_select($cfg_array['game_control']),
					'GAME_CONTROL_DESC'			=> $cfg_array['game_control_desc'],
					'GAME_IMAGE'				=> $cfg_array['game_image'],
					'GAME_FOLDER_NAME'			=> $cfg_array['game_folder_name'],
					'GAME_SCOREVAR'				=> $cfg_array['game_scorevar'],
					'GAME_WIDTH'				=> $cfg_array['game_width'],
					'GAME_HEIGHT'				=> $cfg_array['game_height'],
					'GAME_TYPE_SELECT'			=> $this->arcade->game_type_select($cfg_array['game_type']),
					'GAME_SAVE_TYPE_SELECT'		=> $this->arcade->game_save_type_select($cfg_array['game_save_type']),
					'GAME_SCORETYPE_SELECT'		=> $this->arcade->game_scoretype_select($cfg_array['game_scoretype']),
					'GAME_PRIVACY_DESC'			=> $cfg_array['privacy_desc'],
					'GAME_PRIVACY_LINK'			=> $cfg_array['privacy_link']
				));

				if ($create || $downloadnew)
				{
					if (!check_form_key($form_key))
					{
						$errors[] = $this->user->lang['FORM_INVALID'];
					}

					if ($v = $this->arcade->validate_data('string', 'ARCADE_GAME_NAME', $cfg_array['game_name'], 3, 65))
					{
						$errors[] = $v;
					}

					if ($v = $this->arcade->validate_data('int', 'ARCADE_GAME_WIDTH', $cfg_array['game_width'], ARCADE_MIN_GAME_WIDTH, 9999))
					{
						$errors[] = $v;
					}

					if ($v = $this->arcade->validate_data('int', 'ARCADE_GAME_HEIGHT', $cfg_array['game_height'], ARCADE_MIN_GAME_HEIGHT, 9999))
					{
						$errors[] = $v;
					}

					if ($v = $this->arcade->validate_data('string', 'ARCADE_GAME_FOLDER_NAME', $cfg_array['game_folder_name'], 3, 65))
					{
						$errors[] = $v;
					}
				}

				if ($create && !count($errors))
				{
					if ($this->create_game_install_folder($new_install_file_content, $cfg_array['game_folder_name']))
					{
						trigger_error($this->user->lang['ARCADE_CREATE_INSTALL_FOLDER_FILE'] . adm_back_link($this->u_action));
					}
					else
					{
						$errors[] = $this->user->lang['ARCADE_CREATE_INSTALL_FOLDER_FILE_ERROR'];
					}
				}

				if ($downloadnew && !empty($cfg_array['use_method_new']))
				{
					if (!count($errors))
					{
						$this->arcade->download_install_file($new_install_file_content, $this->file_functions->remove_extension($cfg_array['game_folder_name']), $cfg_array['use_method_new'], $methods);
						garbage_collection();
						exit_handler();
					}
				}

				if ($viewnew)
				{
					$this->template->assign_vars(array(
						'S_VIEW_NEW_FILE'	=> true,
						'INSTALL_NEW_FILE'	=> $new_install_file_content,
					));
				}

				// Quick jump of all the games in the arcade...
				$sql = 'SELECT game_id, game_name, game_name_clean
						FROM ' . ARCADE_GAMES_TABLE . "
						ORDER BY game_name_clean ASC";
				$result = $this->db->sql_query($sql);

				$first_gid = true;
				while ($row = $this->db->sql_fetchrow($result))
				{
					$this->template->assign_block_vars('games', array(
						'GAME_ID'	=> $row['game_id'],
						'GAME_NAME'	=> $row['game_name'],
						'SELECTED'	=> ($row['game_id'] == $game_id) ? ' selected="selected"' : ''
					));
				}
				$this->db->sql_freeresult($result);
				// Quick jump of all the games in the arcade...

				if ($game_id && ($download || $update || $view))
				{

					if ($update)
					{
						if ($this->arcade->game->install_file->row_update($game_id))
						{
							trigger_error($this->user->lang['ARCADE_GAME_INSTALL_FILE_UPDATED'] . adm_back_link($this->u_action));
						}
						else
						{
							trigger_error($this->user->lang['ARCADE_GAME_INSTALL_FILE_UPDATED_ERROR'] . adm_back_link($this->u_action), E_USER_WARNING);
						}
					}

					if (($game_info = $this->arcade->get->game_data($game_id)) !== false)
					{
						$install_file_content = $this->arcade->game->install_file->create($game_info, true);

						if ($download && !empty($cfg_array['use_method']))
						{
							if (!check_form_key($form_key))
							{
								trigger_error($this->user->lang['FORM_INVALID'] . adm_back_link($this->u_action), E_USER_WARNING);
							}

							$this->arcade->download_install_file($install_file_content, $this->file_functions->remove_extension($game_info['game_swf']), $cfg_array['use_method'], $methods);
							garbage_collection();
							exit_handler();
						}

						if ($view)
						{
							$this->template->assign_vars(array(
								'S_VIEW_FILE'	=> true,
								'INSTALL_FILE'	=> $install_file_content,
							));
						}

						$install_file = $this->arcade->set_path($game_info['game_swf'], 'install');

						$game_data = array();
						if (!$this->arcade->game->install_file->data_check($install_file, $game_data, $game_info))
						{
							$this->template->assign_var('S_ERROR_GAME', true);
						}
					}
				}

				$radio_buttons = $radio_buttons_new = '';
				foreach ($methods as $method)
				{
					$checked = ($method == $cfg_array['use_method']) ? ' checked="checked"' : '';
					$checked_new = ($method == $cfg_array['use_method_new']) ? ' checked="checked"' : '';
					$radio_buttons .= '<input type="radio"' . ((!$radio_buttons) ? ' id="use_method"' : '') . ' class="radio" value="' . $method . '" name="config[use_method]"' . $checked . '>&nbsp;' . $method . '&nbsp;';
					$radio_buttons_new .= '<input type="radio"' . ((!$radio_buttons_new) ? ' id="use_method_new"' : '') . ' class="radio" value="' . $method . '" name="config[use_method_new]"' . $checked_new . '>&nbsp;' . $method . '&nbsp;';
				}

				$view_action = ($view) ? '&amp;view=true' : '';
				$view_action .= ($viewnew) ? '&amp;viewnew=true' : '';
				$this->template->assign_vars(array(
					'U_ACTION'			=> $this->u_action . $view_action,

					'RADIO_BUTTONS'		=> $radio_buttons,
					'RADIO_BUTTONS_NEW'	=> $radio_buttons_new,
				));
			break;

			case 'user_guide':
				$l_title = $this->arcade->container('soft_faq')->display();

				$this->template->assign_vars(array(
					'S_IN_ARCADE_USERGUIDE'	=> true,
					'L_BACK_TO_TOP'			=> $this->user->lang['BACK_TO_TOP'],
					'ICON_BACK_TO_TOP'		=> '<img src="' . $this->admin_path . 'images/icon_up.gif" style="vertical-align: middle;" alt="' . $this->user->lang['BACK_TO_TOP'] . '" title="' . $this->user->lang['BACK_TO_TOP'] . '">',
				));
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		$this->template->assign_vars(array(
			'L_TITLE'	=> $this->page_title,
			'L_EXPLAIN'	=> $this->user->lang['ACP_ARCADE_UTILITIES_' . strtoupper($mode) . '_EXPLAIN'],
		));

		if (count($errors))
		{
			$this->template->assign_vars(array(
				'S_ERROR'	=> true,
				'ERROR_MSG'	=> implode('<br>', $errors)
			));
		}
	}

	private function whois()
	{
		$this->user->add_lang('acp/users');

		$this->page_title	= 'WHOIS';
		$this->tpl_name		= 'simple_body';

		if (!function_exists('user_ipwhois'))
		{
			include($this->root_path . 'includes/functions_user.' . $this->php_ext);
		}

		$whois_ip = phpbb_ip_normalise($this->request->variable('whois_ip', ''));
		$domain = gethostbyaddr($whois_ip);
		$ipwhois = user_ipwhois($whois_ip);

		$this->template->assign_vars(array(
			'MESSAGE_TITLE'		=> sprintf($this->user->lang['IP_WHOIS_FOR'], $domain),
			'MESSAGE_TEXT'		=> nl2br($ipwhois)
		));
	}

	private function display_banned_type($banned_type)
	{
		switch ($banned_type)
		{
			case ARCADE_BANNED_ADMIN:
				$key = 'BANNED_TYPE_ADMIN';
			break;

			case ARCADE_BANNED_INVALID_FORM1:
			case ARCADE_BANNED_INVALID_FORM2:
			case ARCADE_BANNED_INVALID_FORM3:
				$key = 'BANNED_TYPE_INVALID_FORM';
			break;

			case ARCADE_BANNED_TIME_HACK:
				$key = 'BANNED_TYPE_TIME_HACK';
			break;

			case ARCADE_BANNED_UNKNOWN:
			default:
				$key = 'UNKNOWN';
			break;
		}

		return $this->arcade->lang_value('ARCADE_' . $key);
	}

	/*
	* Creates game folder, writes game install file
	* and writes blank index.htm file
	*/
	private function create_game_install_folder($install_file_content, $game_filename)
	{
		$success = true;

		$folder_path	= $this->arcade->set_path($game_filename, 'path');
		$file_path		= $this->arcade->set_path($game_filename, 'install');

		if (file_exists($file_path))
		{
			trigger_error($this->user->lang['ARCADE_CREATE_INSTALL_FILE_EXISTS'] . adm_back_link($this->u_action), E_USER_WARNING);
		}

		if (!file_exists($folder_path))
		{
			// Create directory
			if (!@mkdir($folder_path, 0777))
			{
				$success = false;
			}
		}

		// Write game install file
		if (!$success || !$this->file_functions->write_file($file_path, $install_file_content))
		{
			$success = false;
		}

		// Write empty index.htm file
		if (!$success || !$this->file_functions->write_file($folder_path . 'index.htm', '', false))
		{
			$success = false;
		}

		return $success;
	}
}
