<?php
/**
*
* @package phpBB Arcade
* @version $Id: logs_module.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class logs_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	private $log_type;

	protected $admin_path;
	protected $db, $auth, $request, $user, $template, $php_ext;
	protected $arcade_config, $arcade;

	public function __construct()
	{
		global $phpbb_admin_path;
		global $db, $auth, $request, $user, $template, $phpEx;
		global $arcade_config, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->admin_path = $phpbb_admin_path;
		$this->db = $db;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->php_ext = $phpEx;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	public function main($id, $mode)
	{
		$this->user->add_lang_ext('jv/arcade', array('logs', 'info_mcp_arcade'));

		// Set up general vars
		$ip			= $this->request->variable('ip', 'ip');
		$action		= $this->request->variable('action', '');
		$cat_id		= (int) $this->request->variable('c', 0);
		$start		= (int) $this->request->variable('start', 0);
		$marked		= $this->request->variable('mark', array(0));

		$deletemark = $this->arcade->is_post_empty('delmarked');
		$deleteall	= $this->arcade->is_post_empty('delall');
		$this->arcade->valid_start($start);

		// Sort keys
		$sort_days	= (int) $this->request->variable('st', 0);
		$sort_key	= $this->request->variable('sk', 't');
		$sort_dir	= $this->request->variable('sd', 'd');

		$this->tpl_name = 'arcade/acp_logs';
		$this->log_type = constant('ARCADE_LOG_' . strtoupper($mode));

		// Delete entries if requested and able
		if (($deletemark || $deleteall) && $this->auth->acl_get('a_arcade_clearlogs'))
		{
			if ($deletemark && !count($marked))
			{
				trigger_error($this->user->lang['ARCADE_SELECT_EMPTY'] . adm_back_link($this->u_action), E_USER_WARNING);
			}

			if (confirm_box(true))
			{
				$where_sql = '';

				if ($deletemark && count($marked))
				{
					$sql_in = array();
					foreach ($marked as $mark)
					{
						$sql_in[] = $mark;
					}
					$where_sql = ' AND ' . $this->db->sql_in_set('log_id', $sql_in);
					unset($sql_in);
				}

				if ($where_sql || $deleteall)
				{
					$sql = 'DELETE FROM ' . ARCADE_LOGS_TABLE . "
							WHERE log_type = {$this->log_type}
							$where_sql";
					$this->db->sql_query($sql);

					$this->arcade->add_log('admin', 'LOG_CLEAR_' . strtoupper($mode));
				}
			}
			else
			{
				confirm_box(false, $this->user->lang['CONFIRM_OPERATION'], build_hidden_fields(array(
					'c'			=> $cat_id,
					'start'		=> $start,
					'delmarked'	=> $deletemark,
					'delall'	=> $deleteall,
					'mark'		=> $marked,
					'st'		=> $sort_days,
					'sk'		=> $sort_key,
					'sd'		=> $sort_dir,
					'i'			=> $id,
					'mode'		=> $mode,
					'action'	=> $action))
				);
			}
		}

		// Sorting
		$limit_days = array(0 => $this->user->lang['ALL_ENTRIES'], 1 => $this->user->lang['1_DAY'], 7 => $this->user->lang['7_DAYS'], 14 => $this->user->lang['2_WEEKS'], 30 => $this->user->lang['1_MONTH'], 90 => $this->user->lang['3_MONTHS'], 180 => $this->user->lang['6_MONTHS'], 365 => $this->user->lang['1_YEAR']);
		$sort_by_text = array('u' => $this->user->lang['SORT_USERNAME'], 't' => $this->user->lang['SORT_DATE'], 'i' => $this->user->lang['SORT_IP'], 'o' => $this->user->lang['SORT_ACTION']);
		$sort_by_sql = array('u' => 'u.username_clean', 't' => 'l.log_time', 'i' => 'l.log_ip', 'o' => 'l.log_operation');

		$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
		gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);
		$extra_sort = ($sort_key == 'o') ? ', l.log_data ' . (($sort_dir == 'd') ? 'DESC' : 'ASC') : '';

		// Define where and sort sql for use in displaying logs
		$sql_where = ($sort_days) ? (time() - ($sort_days * 86400)) : 0;
		$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC') . $extra_sort;

		$keywords = $this->request->variable('keywords', '', true);
		$keywords_param = !empty($keywords) ? '&amp;keywords=' . urlencode(htmlspecialchars_decode($keywords)) : '';

		$l_title = $this->user->lang['ACP_ARCADE_LOGS_' . strtoupper($mode)];
		$l_title_explain = $this->user->lang['ACP_ARCADE_LOGS_' . strtoupper($mode) . '_EXPLAIN'];

		$this->page_title = $l_title;

		// Define category list if we're looking @ mod logs
		if ($mode == 'mod')
		{
			$cat_box = '<option value="0">' . $this->user->lang['ALL_CATS'] . '</option>' . $this->arcade->make_cat_select($cat_id, false, false, true);

			$this->template->assign_vars(array(
				'S_SHOW_CATS'	=> true,
				'S_CAT_BOX'		=> $cat_box
			));
		}

		// Grab log data
		$log_data = array();
		$log_count = 0;
		$start = $this->arcade->view_log($mode, $log_data, $log_count, $this->arcade_config['acp_items_per_page'], $start, $cat_id, 0, $sql_where, $sql_sort, $keywords);

		$this->arcade->container('phpbb_pagination')->generate_template_pagination($this->u_action . "&amp;$u_sort_param$keywords_param", 'pagination', 'start', $log_count, $this->arcade_config['acp_items_per_page'], $start);

		$this->template->assign_vars(array(
			'L_TITLE'		=> $l_title,
			'L_EXPLAIN'		=> $l_title_explain,
			'U_ACTION'		=> $this->u_action . "&amp;$u_sort_param$keywords_param&amp;start=$start",

			'S_LIMIT_DAYS'	=> $s_limit_days,
			'S_SORT_KEY'	=> $s_sort_key,
			'S_SORT_DIR'	=> $s_sort_dir,
			'S_CLEARLOGS'	=> $this->auth->acl_get('a_arcade_clearlogs'),
			'S_KEYWORDS'	=> $keywords,
		));

		foreach ($log_data as $row)
		{
			$data = array();
			$checks = array('viewlogs', 'viewcat', 'viewgame', 'editgame');

			foreach ($checks as $check)
			{
				if (!empty($row[$check]))
				{
					$data[] = '<a onclick="window.open(this.href); return false;" href="' . $row[$check] . '">' . $this->user->lang['ARCADE_LOGVIEW_' . strtoupper($check)] . '</a>';
				}
			}

			$this->template->assign_block_vars('log', array(
				'U_IP'		=> $this->u_action . "&amp;ip=" . (($ip == 'ip') ? 'hostname' : 'ip'),
				'U_WHOIS'	=> append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('utilities') . "&amp;action=whois&amp;whois_ip={$row['ip']}"),

				'USERNAME'	=> $row['username_full'],
				'IP'		=> ($ip == 'hostname') ? gethostbyaddr($row['ip']) : $row['ip'],
				'DATE'		=> $this->user->format_date($row['time']),
				'ACTION'	=> $row['action'],
				'DATA'		=> (count($data)) ? implode(' | ', $data) : '',
				'ID'		=> $row['id'],
			));
		}
	}
}
