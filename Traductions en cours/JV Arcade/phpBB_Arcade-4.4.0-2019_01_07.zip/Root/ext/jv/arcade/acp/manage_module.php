<?php
/**
*
* @package phpBB Arcade
* @version $Id: manage_module.php 2136 2019-01-05 19:42:24Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class manage_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;
	private $parent_id = 0;
	private $delete_reason = '';
	private $new_game_data = array();

	protected $admin_path;
	protected $db, $config, $cache, $auth, $request, $user, $template, $root_path, $php_ext;
	protected $arcade_config, $arcade_auth, $arcade, $file_functions;

	public function __construct()
	{
		global $phpbb_admin_path;
		global $db, $config, $cache, $auth, $request, $user, $template, $phpbb_root_path, $phpEx;
		global $arcade_config, $arcade_auth, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->admin_path = $phpbb_admin_path;
		$this->db = $db;
		$this->config = $config;
		$this->cache = $cache;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->file_functions = $this->arcade->container('functions_file');
	}

	public function main($id, $mode)
	{
		$time				= time();
		$errors				= array();
		$total_games		= 0;
		$this->tpl_name		= 'arcade/acp_manage';
		$action				= $this->request->variable('action', '');
		$this->parent_id	= (int) $this->request->variable('parent_id', 0);
		$sort				= $this->arcade->is_post_empty('sort');
		$submit				= $this->arcade->is_post_empty('submit');
		$update				= ($this->request->variable('update', false)) ? true : false;
		$start				= (int) $this->request->variable('start', 0);
		$search_game		= ($this->request->variable('search_game', false)) ? true : false;
		$delete_reason		= $this->request->variable('delete_reason', '', true);
		$delete_reason_text	= $this->request->variable('delete_reason_text', '', true);
		$keywords			= $this->request->variable('keywords', '', true);
		$this->arcade->valid_start($start);

		$page_title = 'ACP_ARCADE_MANAGE';
		$this->page_title = $page_title;
		$return = false;

		$this->user->add_lang('posting');
		$group_helper = $this->arcade->container('phpbb_group_helper');
		$pagination = $this->arcade->container('phpbb_pagination');
		$action = ($mode == 'games' && $search_game) ? 'search_game' : $action;
		$this->delete_reason = ($delete_reason_text) ? $delete_reason_text : $delete_reason;

		switch ($mode)
		{
			case 'category':
				$cat_data	= array();
				$cat_id		= (int) $this->request->variable('c', 0);
				$game_id	= (int) $this->request->variable('g', 0);
				$game_ids	= $this->request->variable('game_ids', array(0));

				$page_title = 'ACP_ARCADE_MANAGE_CATEGORIES';
				$this->page_title = $page_title;
				$form_key = 'acp_arcade_category';
				add_form_key($form_key);

				$this->template->assign_var('S_MANAGE_CAT', true);
				$confirm_action = array('delete_marked', 'g_delete', 'reset_marked', 'reset_scores_marked', 'move_marked', 'reset_install_date_marked');

				if ($update)
				{
					if (!check_form_key($form_key) && !in_array($action, $confirm_action))
					{
						$action = $update = false;
						$errors[] = $this->user->lang['FORM_INVALID'];
					}

					switch ($action)
					{
						case 'sync_marked':
						case 'move_marked':
						case 'reset_marked':
						case 'delete_marked':
						case 'reset_scores_marked':
						case 'reset_install_date_marked':
							if (empty($game_ids))
							{
								$action = $update = false;
								$errors[] = $this->user->lang['NO_GAME_IDS'];
							}
						break;
					}
				}
				else if ($action == 'sync_marked')
				{
					$action = false;
				}

				// Check additional permissions
				switch ($action)
				{
					case 'progress_bar':
						$this->arcade->display_progress_bar();
					break;

					case 'delete':
						if (!$this->auth->acl_get('a_arcade_delete_cat'))
						{
							send_status_line(403, 'Forbidden');
							trigger_error($this->user->lang['NO_PERMISSION_CAT_DELETE'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}
					break;

					case 'delete_marked':
					case 'g_delete':
						if (!$this->auth->acl_get('a_arcade_delete_game'))
						{
							send_status_line(403, 'Forbidden');
							trigger_error($this->user->lang['NO_PERMISSION_GAME_DELETE'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}
					break;

					case 'reset_marked':
						$auth_check = ($this->auth->acl_get('a_arcade_game')) ? true : false;
					case 'reset_scores_marked':
						if ($action == 'reset_scores_marked')
						{
							$auth_check = true;
						}

						$auth_check = ($auth_check && $this->auth->acl_get('a_arcade_user')) ? true : false;

						if (!$auth_check)
						{
							send_status_line(403, 'Forbidden');
							trigger_error($this->user->lang['NO_PERMISSION_GAME_' . (($action == 'reset_marked') ? 'RESET' : 'SCORE_RESET')] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}
					break;

					case 'add':
						if (!$this->auth->acl_get('a_arcade_cat'))
						{
							send_status_line(403, 'Forbidden');
							trigger_error($this->user->lang['NO_PERMISSION_CAT_ADD'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}
					break;

					case 'reset_install_date_marked':
						if (!$this->auth->acl_get('a_arcade_reset_game') || !$this->auth->acl_get('a_arcade_game'))
						{
							send_status_line(403, 'Forbidden');
							trigger_error($this->user->lang['NO_PERMISSION_GAME_INSTALL_DATE_RESET'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}
					break;
				}

				// Major routines
				if (!count($errors) && $update)
				{
					switch ($action)
					{
						case 'delete':
							$action_subcats	= $this->request->variable('action_subcats', '');
							$subcats_to_id	= (int) $this->request->variable('subcats_to_id', 0);
							$action_games	= $this->request->variable('action_games', '');
							$games_to_id	= (int) $this->request->variable('games_to_id', 0);

							$errors = $this->delete_cat($cat_id, $action_games, $action_subcats, $games_to_id, $subcats_to_id);

							if (count($errors))
							{
								break;
							}

							$this->arcade_auth->acl_clear_prefetch();
							$this->arcade->cache_purge();
							trigger_error($this->user->lang['CAT_DELETED'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id));
						break;

						case 'g_delete':
							if (confirm_box(true))
							{
								$game_data = $this->arcade->delete_game($game_id, $errors, $this->delete_reason);

								if (count($errors))
								{
									break;
								}

								$game_data = array_shift($game_data);
								$this->arcade->add_log('admin', 'LOG_ARCADE_DELETE_GAME', $game_data['game_name']);
								trigger_error(sprintf($this->user->lang['GAME_DELETED'], $game_data['game_name']) . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id . (($start) ? "&amp;start=$start" : '')));
							}
						break;

						case 'move_marked':
							if (confirm_box(true))
							{
								$game_data = $this->arcade->get->game_data($game_ids);
								$game_data_array = array();
								foreach ($game_data as $key => $value)
								{
									$game_data_array[] = $game_data[$key]['game_name'];
								}
								$game_name_list = implode(', ', $game_data_array);

								$to_cat_id = (int) $this->request->variable('to_cat_id', 0);

								$errors = $this->arcade->move_game($game_ids, $this->parent_id, $to_cat_id);
								if (count($errors))
								{
									break;
								}

								$s = (count($game_data_array) > 1) ? 'S' : '';
								$old_cat_name = $this->arcade->get->cat_field($this->parent_id, 'cat_name');
								$new_cat_name = $this->arcade->get->cat_field($to_cat_id, 'cat_name');

								$this->arcade->cache_purge();
								$message = sprintf($this->user->lang["GAME{$s}_MOVED"], $game_name_list, $new_cat_name);
								$this->arcade->add_log('admin', "LOG_ARCADE_MOVE_GAME{$s}", $old_cat_name, $new_cat_name, $game_name_list);

								trigger_error($message . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id));
							}
						break;

						case 'reset_install_date_marked':
							if (confirm_box(true))
							{
								$game_data = $this->arcade->get->game_data($game_ids);
								$game_data_array = array();

								foreach ($game_data as $key => $value)
								{
									$game_data_array[] = $game_data[$key]['game_name'];
								}

								unset($game_data);
								$errors = $this->arcade->reset_game($action, $game_ids, $this->parent_id);

								if (count($errors))
								{
									break;
								}

								$this->arcade->cache_purge();

								$s = (count($game_data_array) > 1) ? 'S' : '';
								$game_name_list = implode(', ', $game_data_array);
								$this->arcade->add_log('admin', "LOG_ARCADE_RESET_INSTALL_DATE_GAME{$s}", $game_name_list);
								trigger_error(sprintf($this->user->lang["RESET_INSTALL_DATE_GAME{$s}_SUCCESS"], $game_name_list) . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id));
							}
						break;

						case 'sync_marked':
							$this->arcade->sync('game', $game_ids);
							$this->arcade->sync('rating', $game_ids);
							$game_data = $this->arcade->get->game_data($game_ids);

							$game_data_array = array();
							foreach ($game_data as $game)
							{
								$this->arcade->update_highscore($game);
								$game_data_array[] = $game['game_name'];
							}

							unset($game_data);
							$s = (count($game_data_array) > 1) ? 'S' : '';
							$game_name_list = implode(', ', $game_data_array);

							$message = sprintf($this->user->lang["GAME{$s}_RESYNCED"], $game_name_list);
							$this->arcade->add_log('admin', "LOG_ARCADE_SYNC_GAME{$s}", $game_name_list);

							$this->arcade->cache_purge();

							$this->template->assign_var('L_CAT_RESYNCED', $message);
						break;

						case 'reset_marked':
						case 'reset_scores_marked':
							if (confirm_box(true))
							{
								$game_data = $this->arcade->get->game_data($game_ids);
								$game_data_array = array();

								foreach ($game_data as $key => $value)
								{
									$game_data_array[] = $game_data[$key]['game_name'];
								}

								$s = (count($game_data_array) > 1) ? 'S' : '';
								$game_name_list = implode(', ', $game_data_array);

								$message = sprintf($this->user->lang["GAME{$s}_" . (($action == 'reset_marked') ? 'RESET' : 'SCORES_RESET')], $game_name_list);

								$errors = $this->arcade->reset_game($action, $game_ids, $this->parent_id);

								if (count($errors))
								{
									$action = '';
									break;
								}

								$this->arcade->sync('total_data', 'all');
								$this->arcade->cache_purge();

								$reset_log  = "LOG_ARCADE_RESET_GAME{$s}" . (($action == 'reset_scores_marked') ? '_SCORES' : '');

								if ($action == 'reset_marked')
								{
									$this->arcade->add_rvlog($reset_log, true, $game_name_list);
								}
								else
								{
									$this->arcade->add_rvlog($reset_log, 'retain_plays', $game_name_list);
								}

								trigger_error($message . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id . (($start) ? "&amp;start=$start" : '')));
							}
						break;

						case 'delete_marked':
							if (confirm_box(true))
							{
								$game_data = $this->arcade->delete_game($game_ids, $errors, $this->delete_reason);

								if (count($errors))
								{
									break;
								}

								$game_name_ary = array();
								foreach ($game_data as $key => $value)
								{
									$game_name_ary[] = $game_data[$key]['game_name'];
								}

								$s = (count($game_name_ary) > 1) ? 'S' : '';
								$game_name_list = implode(', ', $game_name_ary);

								$message = sprintf($this->user->lang["GAME{$s}_DELETED"], $game_name_list);
								$this->arcade->add_log('admin', "LOG_ARCADE_DELETE_GAME{$s}", $game_name_list);

								trigger_error($message . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id . (($start) ? "&amp;start=$start" : '')));
							}
						break;

						case 'edit':
							$cat_data = array('cat_id' => $cat_id);
						case 'add':
							$cat_data += array(
								'parent_id'				=> (int) $this->request->variable('cat_parent_id', $this->parent_id),
								'cat_type'				=> $this->request->variable('cat_type', ARCADE_CAT_GAMES),
								'cat_test'				=> $this->request->variable('cat_test', false),
								'type_action'			=> $this->request->variable('type_action', ''),
								'cat_status'			=> $this->request->variable('cat_status', ITEM_UNLOCKED),
								'cat_parents'			=> '',
								'cat_name'				=> $this->request->variable('cat_name', '', true),
								'cat_link'				=> $this->request->variable('cat_link', ''),
								'cat_link_track'		=> $this->request->variable('cat_link_track', false),
								'cat_desc'				=> $this->request->variable('cat_desc', '', true),
								'cat_age'				=> (int) $this->request->variable('cat_age', 0),
								'cat_desc_uid'			=> '',
								'cat_desc_options'		=> 7,
								'cat_desc_bitfield'		=> '',
								'cat_rules'				=> $this->request->variable('cat_rules', '', true),
								'cat_rules_uid'			=> '',
								'cat_rules_options'		=> 7,
								'cat_rules_bitfield'	=> '',
								'cat_rules_link'		=> $this->request->variable('cat_rules_link', ''),
								'cat_image'				=> $this->request->variable('cat_image', ''),
								'cat_display'			=> (int) $this->request->variable('cat_display', 0),
								'cat_style'				=> (int) $this->request->variable('cat_style', 0),
								'cat_games_per_page'	=> (int) $this->request->variable('cat_games_per_page', 0),
								'cat_download'			=> $this->request->variable('cat_download', true),
								'cat_use_jackpot'		=> $this->request->variable('cat_use_jackpot', false),
								'cat_download_cost'		=> (float) $this->request->variable('cat_download_cost', 0.00),
								'cat_cost'				=> (float) $this->request->variable('cat_cost', 0.00),
								'cat_reward'			=> (float) $this->request->variable('cat_reward', 0.00),
								'cat_password'			=> $this->request->variable('cat_password', ''),
								'cat_password_confirm'	=> $this->request->variable('cat_password_confirm', ''),
								'cat_password_unset'	=> $this->request->variable('cat_password_unset', false),
								'display_subcat_list'	=> $this->request->variable('display_subcat_list', false),
								'display_on_index'		=> $this->request->variable('display_on_index', false),
							);

							// Use link_display_on_index setting if category type is link
							if ($cat_data['cat_type'] == ARCADE_LINK)
							{
								$cat_data['display_on_index'] = $this->request->variable('link_display_on_index', false);
							}

							// Linked categories and categories are not able to be locked...
							if ($cat_data['cat_type'] == ARCADE_LINK || $cat_data['cat_type'] == ARCADE_CAT)
							{
								// Linked categories are not able to be locked...
								$cat_data['cat_status'] = ITEM_UNLOCKED;
							}

							// Get data for category rules if specified...
							if ($cat_data['cat_rules'])
							{
								generate_text_for_storage($cat_data['cat_rules'], $cat_data['cat_rules_uid'], $cat_data['cat_rules_bitfield'], $cat_data['cat_rules_options'], $this->request->variable('rules_parse_bbcode', false), $this->request->variable('rules_parse_urls', false), $this->request->variable('rules_parse_smilies', false));
							}

							// Get data for category description if specified
							if ($cat_data['cat_desc'])
							{
								generate_text_for_storage($cat_data['cat_desc'], $cat_data['cat_desc_uid'], $cat_data['cat_desc_bitfield'], $cat_data['cat_desc_options'], $this->request->variable('desc_parse_bbcode', false), $this->request->variable('desc_parse_urls', false), $this->request->variable('desc_parse_smilies', false));
							}

							$errors = $this->update_cat_data($cat_data);

							if (!count($errors))
							{
								$cat_perm_from = (int) $this->request->variable('cat_perm_from', 0);

								$this->arcade->cache_purge();

								$copied_permissions = false;
								// Copy permissions?
								if ($cat_perm_from && $cat_perm_from != $cat_data['cat_id'] &&
									($action != 'edit' || empty($cat_id) || ($this->auth->acl_get('a_cauth') && $this->auth->acl_get('a_authusers') && $this->auth->acl_get('a_authgroups') && $this->auth->acl_get('a_mauth'))))
								{
									$this->arcade->copy_category_permissions($cat_perm_from, $cat_data['cat_id'], ($action == 'edit') ? true : false);
									$copied_permissions = true;
								}

								$this->arcade_auth->acl_clear_prefetch();

								$acl_url = '&amp;mode=setting_category_local&amp;cat_id[]=' . $cat_data['cat_id'];

								$message = ($action == 'add') ? $this->user->lang['CAT_CREATED'] : $this->user->lang['CAT_UPDATED'];

								// redirect directly to permission settings screen if authed
								if ($action == 'add' && !$copied_permissions && $this->auth->acl_get('a_cauth'))
								{
									$message .= '<br><br>' . sprintf($this->user->lang['REDIRECT_ACL'], '<a href="' . append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('permissions') . $acl_url) . '">', '</a>');

									meta_refresh(4, append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('permissions') . $acl_url));
								}

								trigger_error($message . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id));
							}
						break;
					}
				}

				switch ($action)
				{
					case 'move_up':
					case 'move_down':
						if (!check_link_hash($this->request->variable('hash', ''), 'acp_category'))
						{
							trigger_error($this->user->lang['FORM_INVALID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}
						else if (!$cat_id)
						{
							trigger_error($this->user->lang['NO_CAT_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						$sql = 'SELECT *
								FROM ' . ARCADE_CATS_TABLE . '
								WHERE cat_id = ' . (int) $cat_id;
						$result = $this->db->sql_query($sql);
						$row = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);

						if (!$row)
						{
							trigger_error($this->user->lang['NO_CAT_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						$move_cat_name = $this->move_cat_by($row, $action);

						if ($move_cat_name !== false)
						{
							$this->cache->destroy('sql', ARCADE_CATS_TABLE);
							$this->arcade->add_log('admin', 'LOG_ARCADE_' . strtoupper($action), $row['cat_name'], $move_cat_name);
						}
					break;

					case 'g_move_up':
					case 'g_move_down':
						if (!check_link_hash($this->request->variable('hash', ''), 'acp_game'))
						{
							trigger_error($this->user->lang['FORM_INVALID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}
						else if (!$game_id)
						{
							trigger_error($this->user->lang['NO_GAME_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						$sql = 'SELECT game_name
								FROM ' . ARCADE_GAMES_TABLE . '
								WHERE game_id = ' . (int) $game_id;
						$result = $this->db->sql_query($sql);
						$row = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);

						if (!$row)
						{
							trigger_error($this->user->lang['NO_GAME_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						//
						// Change order of games in the DB
						//
						$this->arcade->move_game_by($game_id, $this->parent_id, $action);
						$this->arcade->add_log('admin', 'LOG_ARCADE_' . strtoupper($action), $row['game_name']);
					break;

					case 'g_delete':
						$s_hidden_fields = array(
							'start'		=> $start,
							'g'			=> $game_id,
							'update'	=> true
						);

						$this->arcade->confirm_box('delete_files', 'DELETE_SELECTED_GAME', $s_hidden_fields);
					break;


					case 'delete_marked':
						$s_hidden_fields = array(
							'start'		=> $start,
							'action'	=> 'delete_marked',
							'update'	=> true,
							'game_ids'	=> $game_ids
						);

						$this->arcade->confirm_box('delete_files', 'DELETE_SELECTED_GAMES', $s_hidden_fields);
					break;

					case 'move_marked':
						$s_hidden_fields = array(
							'action'	=> 'move_marked',
							'update'	=> true,
							'game_ids'	=> $game_ids,
						);

						$this->template->assign_var('S_CATEGORY_SELECT', $this->arcade->make_cat_select($this->parent_id, $this->parent_id, true, true));

						confirm_box(false, 'MOVE_SELECTED_GAMES', build_hidden_fields($s_hidden_fields), 'arcade/confirm_move_games.html');
					break;

					case 'reset_install_date_marked':
						$s_hidden_fields = array(
							'action'			=> $action,
							'update'			=> true,
							'game_ids'			=> $game_ids
						);

						$confirm = 'RESET_INSTALL_DATE_SELECTED_GAME' . ((count($game_ids) > 1) ? 'S' : '');

						confirm_box(false, $confirm, build_hidden_fields($s_hidden_fields));
					break;

					case 'reset_marked':
					case 'reset_scores_marked':
						$s_hidden_fields = array(
							'start'				=> $start,
							'action'			=> $action,
							'update'			=> true,
							'game_ids'			=> $game_ids
						);

						$confirm = 'RESET_SELECTED_GAME' . ((count($game_ids) > 1) ? 'S' : '');

						$this->arcade->confirm_box((($action == 'reset_marked') ? 'reset_marked' : 'retain_plays'), $confirm . (($action == 'reset_marked') ? '' : '_SCORES'), $s_hidden_fields);
					break;

					case 'sync':
						if ($cat_id || $game_id)
						{
							if (!$cat_id && !$game_id)
							{
								trigger_error($this->user->lang['NO_CAT_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
							}

							@set_time_limit(0);

							if ($cat_id)
							{
								$cat_name = $this->arcade->get->cat_field($cat_id, 'cat_name');

								$this->arcade->set_last_play($cat_id);
								$this->arcade->sync('category', $cat_id);
								$this->cache->destroy('sql', ARCADE_CATS_TABLE);

								$this->arcade->add_log('admin', 'LOG_ARCADE_SYNC_CAT', $cat_name);
								$this->template->assign_var('L_CAT_RESYNCED', sprintf($this->user->lang['CAT_RESYNCED'], $cat_name));
							}
							else if ($game_id)
							{
								$sql = 'SELECT game_name
										FROM ' . ARCADE_GAMES_TABLE . '
										WHERE game_id = ' . (int) $game_id;
								$result = $this->db->sql_query($sql);
								$row = $this->db->sql_fetchrow($result);
								$this->db->sql_freeresult($result);

								if (!$row)
								{
									trigger_error($this->user->lang['NO_GAME_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
								}

								$this->arcade->sync('game', $game_id);

								$this->arcade->add_log('admin', 'LOG_ARCADE_SYNC_GAME', $row['game_name']);
								$this->template->assign_var('L_CAT_RESYNCED', sprintf($this->user->lang['GAME_RESYNCED'], $row['game_name']));
							}
						}
						else
						{
							trigger_error($this->user->lang['NO_CAT_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}
					break;

					case 'add':
					case 'edit':
						if ($update)
						{
							$cat_data['cat_flags'] = 0;
							$cat_data['cat_flags'] += ($this->request->variable('cat_link_track', false)) ? ARCADE_FLAG_LINK_TRACK : 0;
						}

						// Show form to create/modify a category
						if ($action == 'edit')
						{
							$page_title = 'EDIT_CAT';
							$this->page_title = $page_title;
							$row = $this->arcade->get_cat_info($cat_id);
							$old_cat_type = $row['cat_type'];

							if (!$update)
							{
								$cat_data = $row;
							}
							else
							{
								$cat_data['left_id'] = $row['left_id'];
								$cat_data['right_id'] = $row['right_id'];
							}

							// Make sure no direct child categories are able to be selected as parents.
							$childs = $this->arcade->get_cat_branch($cat_id, 'children');

							$exclude_cat = array();
							foreach ($childs as $row)
							{
								$exclude_cat[] = $row['cat_id'];
							}

							$parents_list = $this->arcade->make_cat_select($cat_data['parent_id'], $exclude_cat, true, false, false);
							$cat_data['cat_password_confirm'] = $cat_data['cat_password'];
						}
						else
						{
							$page_title = 'CREATE_CAT';
							$this->page_title = $page_title;

							$cat_id = $this->parent_id;
							$parents_list = $this->arcade->make_cat_select($this->parent_id, false, true, false, false);

							// Fill category data with default values
							if (!$update)
							{
								$cat_data = array(
									'parent_id'				=> $this->parent_id,
									'cat_type'				=> ARCADE_CAT_GAMES,
									'cat_test'				=> false,
									'cat_status'			=> ITEM_UNLOCKED,
									'cat_name'				=> $this->request->variable('cat_name', '', true),
									'cat_age'				=> 0,
									'cat_link'				=> '',
									'cat_link_track'		=> false,
									'cat_desc'				=> '',
									'cat_rules'				=> '',
									'cat_rules_link'		=> '',
									'cat_image'				=> '',
									'cat_display'			=> 0,
									'cat_style'				=> 0,
									'cat_games_per_page'	=> 0,
									'cat_download'			=> true,
									'cat_use_jackpot'		=> false,
									'cat_download_cost'		=> 0,
									'cat_cost'				=> 0,
									'cat_reward'			=> 0,
									'cat_flags'				=> 0,
									'cat_password'			=> '',
									'cat_password_confirm'	=> '',
									'display_subcat_list'	=> true,
									'display_on_index'		=> true,
								);
							}
						}

						$cat_rules_data = array(
							'text'			=> $cat_data['cat_rules'],
							'allow_bbcode'	=> true,
							'allow_smilies'	=> true,
							'allow_urls'	=> true
						);

						$cat_desc_data = array(
							'text'			=> $cat_data['cat_desc'],
							'allow_bbcode'	=> true,
							'allow_smilies'	=> true,
							'allow_urls'	=> true
						);

						$cat_rules_preview = '';

						// Parse rules if specified
						if ($cat_data['cat_rules'])
						{
							if (!isset($cat_data['cat_rules_uid']))
							{
								// Before we are able to display the preview and plane text, we need to parse our $this->request->variable()'d value...
								$cat_data['cat_rules_uid'] = '';
								$cat_data['cat_rules_bitfield'] = '';
								$cat_data['cat_rules_options'] = 0;

								generate_text_for_storage($cat_data['cat_rules'], $cat_data['cat_rules_uid'], $cat_data['cat_rules_bitfield'], $cat_data['cat_rules_options'], $this->request->variable('rules_allow_bbcode', false), $this->request->variable('rules_allow_urls', false), $this->request->variable('rules_allow_smiliess', false));
							}

							// Generate preview content
							$cat_rules_preview = generate_text_for_display($cat_data['cat_rules'], $cat_data['cat_rules_uid'], $cat_data['cat_rules_bitfield'], $cat_data['cat_rules_options']);

							// decode...
							$cat_rules_data = generate_text_for_edit($cat_data['cat_rules'], $cat_data['cat_rules_uid'], $cat_data['cat_rules_options']);
						}

						// Parse desciption if specified
						if ($cat_data['cat_desc'])
						{
							if (!isset($cat_data['cat_desc_uid']))
							{
								// Before we are able to display the preview and plane text, we need to parse our $this->request->variable()'d value...
								$cat_data['cat_desc_uid'] = '';
								$cat_data['cat_desc_bitfield'] = '';
								$cat_data['cat_desc_options'] = 0;

								generate_text_for_storage($cat_data['cat_desc'], $cat_data['cat_desc_uid'], $cat_data['cat_desc_bitfield'], $cat_data['cat_desc_options'], $this->request->variable('desc_allow_bbcode', false), $this->request->variable('desc_allow_urls', false), $this->request->variable('desc_allow_smiliess', false));
							}

							// decode...
							$cat_desc_data = generate_text_for_edit($cat_data['cat_desc'], $cat_data['cat_desc_uid'], $cat_data['cat_desc_options']);
						}

						$sql = 'SELECT cat_id
								FROM ' . ARCADE_CATS_TABLE . '
								WHERE cat_type = ' . ARCADE_CAT_GAMES . '
								AND cat_id <> ' . (int) $cat_id;
						$result = $this->db->sql_query_limit($sql, 1);

						$arcade_cat_games_exists = false;
						if ($this->db->sql_fetchrow($result))
						{
							$arcade_cat_games_exists = true;
						}
						$this->db->sql_freeresult($result);

						// Subcategory move options
						if ($action == 'edit' && $cat_data['cat_type'] == ARCADE_CAT)
						{
							$subcat_id = array();
							$subcat = $this->arcade->get_cat_branch($cat_id, 'children');

							foreach ($subcat as $row)
							{
								$subcat_id[] = $row['cat_id'];
							}

							$cat_list = $this->arcade->make_cat_select($cat_data['parent_id'], $subcat_id, true);

							if ($arcade_cat_games_exists)
							{
								$this->template->assign_var('S_MOVE_CAT_OPTIONS', $this->arcade->make_cat_select($cat_data['parent_id'], $subcat_id, true));
							}

							$this->template->assign_vars(array(
								'S_HAS_SUBCATS'	=> ($cat_data['right_id'] - $cat_data['left_id'] > 1) ? true : false,
								'S_CATS_LIST'	=> $cat_list
							));
						}
						else if ($arcade_cat_games_exists)
						{
							$this->template->assign_var('S_MOVE_CAT_OPTIONS', $this->arcade->make_cat_select($cat_data['parent_id'], $cat_id, true, true, false));
						}

						$s_show_display_on_index = false;

						if ($cat_data['parent_id'] > 0)
						{
							// if this category is a subcategory put the "display on index" checkbox
							if ($parent_info = $this->arcade->get_cat_info($cat_data['parent_id']))
							{
								if ($parent_info['parent_id'] > 0 || $parent_info['cat_type'] == ARCADE_CAT)
								{
									$s_show_display_on_index = true;
								}
							}
						}

						$l_title = $this->user->lang[$page_title];
						$filename_list = $this->arcade->generate_cat_images($cat_data['cat_image']);

						$cat_type_options = $this->arcade->build_select(
							array(
								ARCADE_CAT			=> 'TYPE_CAT',
								ARCADE_CAT_GAMES	=> 'TYPE_CAT_GAMES',
								ARCADE_LINK			=> 'TYPE_LINK'
							), $cat_data['cat_type']
						);

						$statuslist = $this->arcade->build_select(
							array(
								ITEM_UNLOCKED	=> 'UNLOCKED',
								ITEM_LOCKED		=> 'LOCKED'
							), $cat_data['cat_status']
						);

						$this->template->assign_vars(array(
							'S_EDIT_CAT'					=> true,
							'S_PARENT_ID'					=> $this->parent_id,
							'S_CAT_PARENT_ID'				=> $cat_data['parent_id'],
							'S_ADD_ACTION'					=> ($action == 'add') ? true : false,

							'U_EDIT_ACTION'					=> $this->u_action . "&amp;parent_id={$this->parent_id}&amp;action=$action&amp;c=$cat_id",

							'L_COPY_PERMISSIONS_EXPLAIN'	=> $this->user->lang['COPY_PERMISSIONS_' . strtoupper($action) . '_EXPLAIN'],

							'CAT_NAME'						=> $cat_data['cat_name'],
							'CAT_DATA_LINK'					=> $cat_data['cat_link'],
							'CAT_IMAGE_SRC'					=> ($cat_data['cat_image']) ? $this->arcade->get()->image('src', 'cat', $cat_data['cat_image']) : $this->root_path . 'images/spacer.gif',
							'ARCADE_LINK'					=> ARCADE_LINK,
							'ARCADE_CAT'					=> ARCADE_CAT,
							'ARCADE_CAT_GAMES'				=> ARCADE_CAT_GAMES,
							'CAT_AGE'						=> $cat_data['cat_age'],
							'CAT_GAMES_PER_PAGE'			=> $cat_data['cat_games_per_page'],
							'CAT_DOWNLOAD'					=> $cat_data['cat_download'],
							'CAT_PASSWORD'					=> $cat_data['cat_password'],
							'CAT_PASSWORD_CONFIRM'			=> $cat_data['cat_password_confirm'],
							'CAT_RULES_LINK'				=> $cat_data['cat_rules_link'],
							'CAT_RULES'						=> $cat_data['cat_rules'],
							'CAT_RULES_PREVIEW'				=> $cat_rules_preview,
							'CAT_RULES_PLAIN'				=> $cat_rules_data['text'],
							'CAT_DOWNLOAD_COST'				=> $cat_data['cat_download_cost'],
							'CAT_COST'						=> $cat_data['cat_cost'],
							'CAT_REWARD'					=> $cat_data['cat_reward'],
							'CAT_USE_JACKPOT'				=> $cat_data['cat_use_jackpot'],
							'CAT_DESC'						=> $cat_desc_data['text'],

							'S_FILENAME_OPTIONS'			=> $filename_list,
							'S_IMAGE_BASEDIR'				=> $this->arcade->set_image_path('cat'),
							'S_BBCODE_CHECKED'				=> ($cat_rules_data['allow_bbcode']) ? true : false,
							'S_SMILIES_CHECKED'				=> ($cat_rules_data['allow_smilies']) ? true : false,
							'S_URLS_CHECKED'				=> ($cat_rules_data['allow_urls']) ? true : false,
							'S_CAT_PASSWORD_SET'			=> (empty($cat_data['cat_password'])) ? false : true,

							'S_DESC_BBCODE_CHECKED'			=> ($cat_desc_data['allow_bbcode']) ? true : false,
							'S_DESC_SMILIES_CHECKED'		=> ($cat_desc_data['allow_smilies']) ? true : false,
							'S_DESC_URLS_CHECKED'			=> ($cat_desc_data['allow_urls']) ? true : false,

							'S_SHOW_POINTS'					=> ($this->arcade->points->data['installed'] && $this->auth->acl_get('a_arcade_points_settings')) ? true : false,
							'S_CAT_TYPE_OPTIONS'			=> $cat_type_options,
							'S_STATUS_OPTIONS'				=> $statuslist,
							'S_PARENT_OPTIONS'				=> $parents_list,
							'S_STYLES_OPTIONS'				=> style_select($cat_data['cat_style'], true),
							'S_CAT_DISPLAY_OPTIONS'			=> $this->cat_display_select($cat_data['cat_display']),
							'S_CAT_OPTIONS'					=> $this->arcade->make_cat_select(($action == 'add') ? $cat_data['parent_id'] : false, ($action == 'edit') ? $cat_data['cat_id'] : false, true, false, false),
							'S_SHOW_DISPLAY_ON_INDEX'		=> $s_show_display_on_index,
							'S_DISPLAY_SUBCAT_LIST'			=> ($cat_data['display_subcat_list']) ? true : false,
							'S_DISPLAY_ON_INDEX'			=> ($cat_data['display_on_index']) ? true : false,
							'S_ARCADE_CAT'					=> ($cat_data['cat_type'] == ARCADE_CAT) ? true : false,
							'S_ARCADE_CAT_TEST'				=> ($cat_data['cat_test']) ? true : false,
							'S_CAT_ORIG_CAT_GAMES'			=> (isset($old_cat_type) && $old_cat_type == ARCADE_CAT_GAMES) ? true : false,
							'S_CAT_ORIG_CAT'				=> (isset($old_cat_type) && $old_cat_type == ARCADE_CAT) ? true : false,
							'S_CAT_ORIG_LINK'				=> (isset($old_cat_type) && $old_cat_type == ARCADE_LINK) ? true : false,
							'S_ARCADE_LINK'					=> ($cat_data['cat_type'] == ARCADE_LINK) ? true : false,
							'S_ARCADE_CAT_GAMES'			=> ($cat_data['cat_type'] == ARCADE_CAT_GAMES) ? true : false,
							'S_ARCADE_LINK_TRACK'			=> ($cat_data['cat_flags'] & ARCADE_FLAG_LINK_TRACK) ? true : false,
							'S_CAN_COPY_PERMISSIONS'		=> ($action != 'edit' || empty($cat_id) || ($this->auth->acl_get('a_cauth') && $this->auth->acl_get('a_authusers') && $this->auth->acl_get('a_authgroups'))) ? true : false,
						));

						$return = true;
					break;

					case 'delete':
						if (!$cat_id)
						{
							trigger_error($this->user->lang['NO_CAT_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						$cat_data = $this->arcade->get_cat_info($cat_id);

						$subcat_id = array();
						$subcat = $this->arcade->get_cat_branch($cat_id, 'children');

						foreach ($subcat as $row)
						{
							$subcat_id[] = $row['cat_id'];
						}

						$cat_list = $this->arcade->make_cat_select($cat_data['parent_id'], $subcat_id, true);

						$sql = 'SELECT cat_id
								FROM ' . ARCADE_CATS_TABLE . '
								WHERE cat_type = ' . ARCADE_CAT_GAMES . "
								AND cat_id <> $cat_id";
						$result = $this->db->sql_query($sql);

						if ($this->db->sql_fetchrow($result))
						{
							$this->template->assign_var('S_MOVE_CAT_OPTIONS', $this->arcade->make_cat_select($cat_data['parent_id'], $subcat_id, true, true));
						}
						$this->db->sql_freeresult($result);

						$parent_id = ($this->parent_id == $cat_id) ? 0 : $this->parent_id;

						$this->template->assign_vars(array(
							'S_DELETE_CAT'			=> true,
							'U_ACTION'				=> $this->u_action . "&amp;parent_id={$parent_id}&amp;action=delete&amp;c=$cat_id",

							'CAT_NAME'				=> $cat_data['cat_name'],
							'S_ARCADE_CAT_GAMES'	=> ($cat_data['cat_type'] == ARCADE_CAT_GAMES) ? true : false,
							'S_ARCADE_LINK'			=> ($cat_data['cat_type'] == ARCADE_LINK) ? true : false,
							'S_HAS_SUBCATS'			=> ($cat_data['right_id'] - $cat_data['left_id'] > 1) ? true : false,
							'S_CATS_LIST'			=> $cat_list
						));

						$return = true;
					break;
				}

				if (!$return)
				{
					// Default management page
					$parent_cat_type = '';
					if (!$this->parent_id)
					{
						$navigation = $this->user->lang['ARCADE_INDEX'];
					}
					else
					{
						$navigation = '<a href="' . $this->u_action . '">' . $this->user->lang['ARCADE_INDEX'] . '</a>';
						$cat_nav = $this->arcade->get_cat_branch($this->parent_id, 'parents');
						foreach ($cat_nav as $row)
						{
							if ($row['cat_id'] == $this->parent_id)
							{
								$parent_cat_type = $row['cat_type'];
								$navigation .= ' -&gt; ' . $row['cat_name'];
							}
							else
							{
								$navigation .= ' -&gt; <a href="' . $this->u_action . '&amp;parent_id=' . $row['cat_id'] . '">' . $row['cat_name'] . '</a>';
							}
						}
					}

					// Jumpbox
					$cat_box = $this->arcade->make_cat_select($this->parent_id, false, true, false, false);
					if (($action == 'sync' || $action == 'sync_marked') && !count($errors))
					{
						$this->template->assign_var('S_RESYNCED', true);
					}

					$sql = 'SELECT *
							FROM ' . ARCADE_CATS_TABLE . "
							WHERE parent_id = $this->parent_id
							ORDER BY left_id";
					$result = $this->db->sql_query($sql);

					if ($row = $this->db->sql_fetchrow($result))
					{
						do
						{
							$cat_type = $row['cat_type'];

							if ($row['cat_status'] == ITEM_LOCKED)
							{
								$folder_image = '<img src="' . $this->admin_path . 'images/icon_folder_lock.gif" alt="' . $this->user->lang['LOCKED'] . '" title="' . $this->user->lang['LOCKED'] . '">';
							}
							else
							{
								switch ($cat_type)
								{
									case ARCADE_LINK:
										$folder_image = '<img src="' . $this->admin_path . 'images/icon_folder_link.gif" alt="' . $this->user->lang['TYPE_LINK'] . '" title="' . $this->user->lang['TYPE_LINK'] . '">';
									break;

									default:
										$folder_image = ($row['left_id'] + 1 != $row['right_id']) ? '<img src="' . $this->admin_path . 'images/icon_subfolder.gif" alt="' . $this->user->lang['ARCADE_SUBCAT'] . '" title="' . $this->user->lang['ARCADE_SUBCAT'] . '">' : '<img src="' . $this->admin_path . 'images/icon_folder.gif" alt="' . $this->user->lang['ARCADE_CATEGORY'] . '" title="' . $this->user->lang['ARCADE_CATEGORY'] . '">';
									break;
								}
							}

							$url = $this->u_action . "&amp;parent_id=$this->parent_id&amp;c={$row['cat_id']}" . (($start) ? "&amp;start=$start" : '');

							$this->template->assign_block_vars('cats', array(
								'FOLDER_IMAGE'			=> $folder_image,
								'CAT_IMAGE'				=> ($row['cat_image']) ? $this->arcade->get()->image('full', 'cat', $row['cat_image']) : '',
								'CAT_IMAGE_SRC'			=> ($row['cat_image']) ? $this->arcade->get()->image('src', 'cat', $row['cat_image']) : '',
								'CAT_NAME'				=> $row['cat_name'],
								'CAT_DESCRIPTION'		=> generate_text_for_display($row['cat_desc'], $row['cat_desc_uid'], $row['cat_desc_bitfield'], $row['cat_desc_options']),
								'CAT_GAMES'				=> $row['cat_games'],
								'CAT_PLAYS'				=> $row['cat_plays'],

								'S_ARCADE_LINK'			=> ($cat_type == ARCADE_LINK) ? true : false,
								'S_ARCADE_CAT_GAMES'	=> ($cat_type == ARCADE_CAT_GAMES) ? true : false,

								'U_CAT'					=> $this->u_action . '&amp;parent_id=' . $row['cat_id'],
								'U_MOVE_UP'				=> $url . '&amp;action=move_up&amp;hash=' . generate_link_hash('acp_category'),
								'U_MOVE_DOWN'			=> $url . '&amp;action=move_down&amp;hash=' . generate_link_hash('acp_category'),
								'U_EDIT'				=> $url . '&amp;action=edit',
								'U_DELETE'				=> $url . '&amp;action=delete',
								'U_SYNC'				=> $url . '&amp;action=sync'
							));
						}
						while ($row = $this->db->sql_fetchrow($result));
					}
					else if ($this->parent_id)
					{
						$row = $this->arcade->get_cat_info($this->parent_id);

						if ($row)
						{
							$url = $this->u_action . '&amp;parent_id=' . $this->parent_id . '&amp;c=' . $row['cat_id'] . (($start) ? "&amp;start=$start" : '');

							$this->template->assign_vars(array(
								'S_NO_CATS'	=> true,

								'U_EDIT'	=> $url . '&amp;action=edit',
								'U_DELETE'	=> $url . '&amp;action=delete',
								'U_SYNC'	=> $url . '&amp;action=sync'
							));
						}
					}
					$this->db->sql_freeresult($result);

					$sql_search = '';
					if ($search_game)
					{
						if (!$this->parent_id || ($cat_name = $this->arcade->get->cat_field($this->parent_id, 'cat_name', false)) === false)
						{
							trigger_error($this->user->lang['NO_CAT_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						$searchterm = '*' . strtolower($keywords) . '*';
						$searchterm = str_replace('*', $this->db->get_any_char() , $searchterm);
						$searchterm = str_replace('?', $this->db->get_one_char() , $searchterm);

						$total_games = $this->arcade->get->total('game', 'games_search', $searchterm, false, false, false, false, $this->parent_id);
						$sql_search = ' AND game_name_clean ' . $this->db->sql_like_expression($searchterm);
					}
					else
					{
						$total_games = $this->arcade->get->total('game', 'games', $this->parent_id);
					}

					if ($start >= $total_games)
					{
						$start = $start - $this->arcade_config['acp_items_per_page'];
						$this->arcade->valid_start($start);
					}

					$ex_search = ($search_game) ? "&amp;search_game=$search_game" : '';
					$ex_sort = (($start) ? "&amp;start=$start" : '') . $ex_search;

					if ($total_games && $this->parent_id)
					{
						$sort_key	= $this->request->variable('sk', 'f');
						$sort_dir	= $this->request->variable('sd', 'd');
						$sort_fixed	= (!$search_game && $sort_key == 'f' && $sort_dir == 'd') ? true : false;

						$sort_by_text = array('f' => $this->user->lang['ARCADE_GAMES_SORT_FIXED'], 'n' => $this->user->lang['ARCADE_GAME_NAME'], 'p' => $this->user->lang['ARCADE_PLAYS'], 'i' => $this->user->lang['ARCADE_GAME_SIZE'], 't' => $this->user->lang['ARCADE_GAME_TYPE'], 's' => $this->user->lang['ARCADE_GAME_SAVE_TYPE']);
						$sort_by_sql = array('f' => 'game_order', 'n' => 'game_name_clean', 'p' => 'game_plays', 'i' => 'game_filesize', 't' => 'game_type', 's' => 'game_save_type');
						$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

						$sort_days = 0;
						$limit_days = array();
						$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
						gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

						$sql = 'SELECT game_id, game_name, game_image, game_type, game_save_type, game_desc, game_plays, game_filesize, cat_id
								FROM ' . ARCADE_GAMES_TABLE . "
								WHERE cat_id = $this->parent_id
								{$sql_search}
								ORDER BY $sql_sort";

						if ($game_id)
						{
							$result = $this->db->sql_query($sql);
							$row = $this->db->sql_fetchrowset($result);
							$this->db->sql_freeresult($result);

							$total_games = count($row);

							$prev_games = 0;
							$found_game = false;
							foreach ($row as $game)
							{
								if ($game['game_id'] == $game_id)
								{
									$found_game = true;
									break;
								}
								$prev_games++;
							}

							if ($found_game)
							{
								$start = floor(($prev_games) / $this->arcade_config['acp_items_per_page']) * $this->arcade_config['acp_items_per_page'];
							}
						}

						$this->arcade->valid_start($start, $total_games);

						$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);

						if ($row = $this->db->sql_fetchrow($result))
						{
							do
							{
								$url = $this->u_action . '&amp;parent_id=' . $this->parent_id . '&amp;g=' . $row['game_id'] . $ex_sort;

								$this->template->assign_block_vars('games', array(
									'GAME_ID'			=> $row['game_id'],
									'GAME_NAME'			=> $this->arcade->get->game_name($row['game_name'], false, 'play', $row['cat_id'], $row['game_id'], 'x', false, false, false, true),
									'GAME_TYPE'			=> $this->arcade->game->type($row['game_type'], true),
									'GAME_SAVE_TYPE'	=> $this->arcade->game->save_type($row['game_save_type'], true),
									'GAME_DESC'			=> nl2br($row['game_desc']),
									'GAME_PLAYS'		=> $row['game_plays'],
									'GAME_IMAGE'		=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get->game_image($row['game_image'], 30, 30, 'x', 'play', $row['cat_id'], $row['game_id'], false, true) : false,
									'GAME_FILESIZE'		=> get_formatted_filesize($row['game_filesize']),

									'U_MOVE_UP'			=> $url . '&amp;action=g_move_up&amp;hash=' . generate_link_hash('acp_game'),
									'U_MOVE_DOWN'		=> $url . '&amp;action=g_move_down&amp;hash=' . generate_link_hash('acp_game'),
									'U_EDIT'			=> append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('manage') . "&amp;mode=games&amp;action=edit&amp;g={$row['game_id']}"),
									'U_DELETE'			=> $url . '&amp;action=g_delete',
									'U_SYNC'			=> $url . "&amp;action=sync&amp;sk=$sort_key&amp;sd={$sort_dir}" . (($search_game) ? '&amp;keywords=' . urlencode(htmlspecialchars_decode($keywords)) : '')
								));
							}
							while ($row = $this->db->sql_fetchrow($result));
						}
						$this->db->sql_freeresult($result);

						$mark_options = array('sync_marked', 'reset_scores_marked', 'reset_marked', 'move_marked', 'delete_marked', 'reset_install_date_marked');

						$s_mark_options = '';
						foreach ($mark_options as $mark_option)
						{
							if (($mark_option == 'delete_marked' && !$this->auth->acl_get('a_arcade_delete_game')) ||
								(($mark_option == 'reset_marked' || $mark_option == 'reset_install_date_marked') && (!$this->auth->acl_get('a_arcade_reset_game') || !$this->auth->acl_get('a_arcade_game'))) ||
								($mark_option == 'reset_scores_marked' && !$this->auth->acl_get('a_arcade_user')))
							{
								continue;
							}

							$s_mark_options .= '<option' . (($action == $mark_option) ? ' selected="selected"' : '') . ' value="' . $mark_option . '">' . $this->user->lang['ARCADE_' . strtoupper($mark_option)] . '</option>';
						}

						unset($mark_options);
						$pagination->generate_template_pagination($this->u_action . '&amp;parent_id=' . $this->parent_id . "&amp;sk=$sort_key&amp;sd={$sort_dir}{$ex_search}", 'pagination', 'start', $total_games, $this->arcade_config['acp_items_per_page'], $start);

						$this->template->assign_vars(array(
							'S_GAME_MOVE'		=> $sort_fixed,
							'S_SORT_KEY'		=> $s_sort_key,
							'S_SORT_DIR'		=> $s_sort_dir,

							'S_MARK_OPTIONS'	=> $s_mark_options
						));
					}

					$s_hidden_fields = array('parent_id' => $this->parent_id);

					$this->template->assign_vars(array(
						'S_CAT_DELETE'			=> ($this->auth->acl_get('a_arcade_delete_cat')) ? true : false,
						'S_ARCADE_CAT_GAMES'	=> ($parent_cat_type == ARCADE_CAT_GAMES) ? true : false,
						'S_HIDDEN_FIELDS'		=> build_hidden_fields($s_hidden_fields),
						'S_PROGRESS_BAR'		=> true,

						'GAME_SEARCH'			=> $keywords,
						'ERROR_MSG'				=> (count($errors)) ? implode('<br>', $errors) : '',
						'NAVIGATION'			=> $navigation,
						'CAT_BOX'				=> $cat_box,

						'U_SEL_ACTION'			=> $this->u_action,
						'U_ACTION'				=> $this->u_action . '&amp;parent_id=' . $this->parent_id . $ex_sort,
						'U_PROGRESS_BAR'		=> $this->u_action . '&amp;action=progress_bar',
						'UA_PROGRESS_BAR'		=> str_replace('&amp;', '&', $this->u_action) . '&action=progress_bar'
					));
				}
			break;

			case 'games':
				$form_key = 'acp_arcade_games';
				add_form_key($form_key);
				$page_title = 'ACP_ARCADE_MANAGE_GAMES';
				$this->page_title = $page_title;

				$game_id				= (int) $this->request->variable('g', 0);
				$cat_id					= (int) $this->request->variable('c', 0);
				$game_type				= (int) $this->request->variable('gt', 0);
				$game_save_type			= (int) $this->request->variable('gst', 0);
				$gametypev3				= (bool) $this->request->variable('gametypev3', false);
				$gametypev32			= (bool) $this->request->variable('gametypev32', false);
				$delete_game			= $this->arcade->is_post_empty('delete');
				$reset_game_ins_date	= ($this->arcade->is_post_empty('reset_game_install_date') && $this->auth->acl_get('a_arcade_user') && $this->auth->acl_get('a_arcade_game')) ? true : false;
				$edit_game				= $this->arcade->is_post_empty('edit');
				$cat_games_delete		= $this->arcade->is_post_empty('cat_games_delete');
				$type_games_delete		= $this->arcade->is_post_empty('type_games_delete');
				$save_type_games_delete	= $this->arcade->is_post_empty('save_type_games_delete');

				$this->template->assign_var('S_MANAGE_GAMES', true);

				if ($action == '')
				{
					if ($edit_game)
					{
						$action = 'edit';
					}
					else if ($delete_game || $cat_games_delete || $type_games_delete || $save_type_games_delete)
					{
						$action = 'delete';
					}
				}
				else if ($delete_game)
				{
					$action = 'delete';
				}

				switch ($action)
				{
					case 'edit':
						$old_cat_id = (int) $this->request->variable('old_cat_id', 0);
						$old_game_scoretype = (int) $this->request->variable('old_game_scoretype', 0);

						$display_vars = array(
							'title'					=> 'ARCADE_EDIT_GAME',
							'title_explain'			=> 'ARCADE_EDIT_GAME_EXPLAIN',
							'vars'	=> array(
								'legend1'			=> 'ARCADE_GAME_SETTINGS',
								'game_name'			=> array('lang' => 'ARCADE_GAME_NAME',			'validate' => 'string:1:255',	'type' => 'text:30:255',	'explain' => true),
								'game_desc'			=> array('lang' => 'ARCADE_GAME_DESC',											'type' => 'textarea:5:25',	'explain' => true),
								'game_control'		=> array('lang' => 'ARCADE_GAME_CONTROL',		'validate' => 'int',			'type' => 'custom',			'explain' => true,	'method' => 'game_control'),
								'game_control_desc'	=> false,
								'game_image'		=> array('lang' => 'ARCADE_GAME_IMAGE',			'validate' => 'string:1:255',	'type' => 'text:30:255',	'explain' => true),
								'game_swf'			=> array('lang' => 'ARCADE_GAME_FOLDER_NAME',	'validate' => 'string:1:255',	'type' => 'custom',			'explain' => true,	'method' => 'game_swf'),
								'game_width'		=> array('lang' => 'ARCADE_GAME_WIDTH',			'validate' => 'int:' . ARCADE_MIN_GAME_WIDTH . ':9999',	'type' => 'number:' . ARCADE_MIN_GAME_WIDTH . ':9999',	'explain' => true,	'append' => ' ' . $this->user->lang['PIXEL']),
								'game_height'		=> array('lang' => 'ARCADE_GAME_HEIGHT',		'validate' => 'int:' . ARCADE_MIN_GAME_HEIGHT . ':9999','type' => 'number:' . ARCADE_MIN_GAME_HEIGHT . ':9999',	'explain' => true,	'append' => ' ' . $this->user->lang['PIXEL']),
								'game_installdate'	=> array('lang' => 'ARCADE_GAME_INSTALLDATE',	'validate' => 'int',			'type' => 'custom',			'explain' => true,	'method' => 'game_installdate'),
								'game_filesize'		=> array('lang' => 'ARCADE_GAME_FILESIZE',		'validate' => 'int',			'type' => 'custom',			'explain' => true,	'method' => 'game_filesize'),
								'game_type'			=> array('lang' => 'ARCADE_GAME_TYPE',			'validate' => 'int',			'type' => 'select',			'explain' => true,	'method' => 'game_type_select'),
								'cat_id'			=> array('lang' => 'ARCADE_GAME_CATEGORY',		'validate' => 'int',			'type' => 'select',			'explain' => true,	'method' => 'game_cat_select'),
								'game_download'		=> array('lang' => 'ARCADE_GAME_DOWNLOAD',		'validate' => 'bool',			'type' => 'radio:yes_no',	'explain' => true)
							)
						);

						if ($this->arcade_config['game_pp_enable'])
						{
							$display_vars['vars'] += array(
								'privacy_desc'		=> array('lang' => 'ARCADE_GAME_PRIVACY_DESC',									'type' => 'textarea:5:25',	'explain' => true),
								'privacy_link'		=> array('lang' => 'ARCADE_GAME_PRIVACY_LINK',									'type' => 'textarea:5:25',	'explain' => true)
							);
						}

							$display_vars['vars'] += array(
								'legend2'			=> 'ARCADE_SCORE_SETTINGS',
								'game_scorevar'		=> array('lang' => 'ARCADE_GAME_SCOREVAR',		'validate' => 'string:1:255',	'type' => 'text:30:255',	'explain' => true),
								'game_save_type'	=> array('lang' => 'ARCADE_GAME_SAVE_TYPE',		'validate' => 'int',			'type' => 'select',			'explain' => true,	'method' => 'game_save_type_select'),
								'game_scoretype'	=> array('lang' => 'ARCADE_GAME_SCORETYPE',		'validate' => 'int',			'type' => 'select',			'explain' => true,	'method' => 'game_scoretype_select')
							);

						if ($this->arcade->points->data['installed'] && $this->auth->acl_get('a_arcade_points_settings'))
						{
							$display_vars['vars'] += array(
								'legend3'			=> 'ARCADE_GAME_POINTS_SETTINGS',
								'game_download_cost'=> array('lang' => 'ARCADE_GAME_DOWNLOAD_COST',	'validate' => 'jva_float:-1',	'type' => 'text:10:11',			'explain' => true,	'append' => ' ' . $this->arcade->points->data['name']),
								'game_cost'			=> array('lang' => 'ARCADE_GAME_COST',			'validate' => 'jva_float:-1',	'type' => 'text:10:11',			'explain' => true,	'append' => ' ' . $this->arcade->points->data['name']),
								'game_reward'		=> array('lang' => 'ARCADE_GAME_REWARD',		'validate' => 'jva_float:-1',	'type' => 'text:10:11',			'explain' => true,	'append' => ' ' . $this->arcade->points->data['name']),
								'game_use_jackpot'	=> array('lang' => 'ARCADE_GAME_USE_JACKPOT',	'validate' => 'bool',			'type' => 'radio:yes_no',		'explain' => true),
								'game_jackpot'		=> array('lang' => 'ARCADE_GAME_JACKPOT',		'validate' => 'jva_float:0',	'type' => 'text:10:11',			'explain' => true,	'append' => ' ' . $this->arcade->points->data['name']),
							);
						}

						$this->new_game_data = $this->arcade->get->game_cat_data($game_id);
						if (!$this->new_game_data)
						{
							trigger_error($this->user->lang['NO_GAME_ID'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						$cfg_array = (isset($_REQUEST['config'])) ? $this->request->variable('config', array('' => ''), true) : $this->new_game_data;

						// We validate the complete config if whished
						validate_config_vars($display_vars['vars'], $cfg_array, $errors);

						if ($update && !check_form_key($form_key))
						{
							$errors[] = $this->user->lang['FORM_INVALID'];
						}

						$cat_data = $this->arcade->get_cat_info($cfg_array['cat_id']);

						if ($update && $cfg_array['game_name'] != $this->new_game_data['game_name'])
						{
							$sql = 'SELECT game_id
									FROM ' . ARCADE_GAMES_TABLE . "
									WHERE game_name = '" . $this->db->sql_escape($cfg_array['game_name']) . "'";
							$result = $this->db->sql_query($sql);
							$g_id = $this->db->sql_fetchfield('game_id');
							$this->db->sql_freeresult($result);

							if ($g_id)
							{
								$errors[] = $this->user->lang['ARCADE_DUPLICATE_GAMENAME_ERROR'];
							}
						}

						if ($cat_data['cat_type'] != ARCADE_CAT_GAMES)
						{
							$errors[] = $this->user->lang['WRONG_CAT_TYPE'];
						}

						if ($update && $reset_game_ins_date && !count($errors))
						{
							$errors = $this->arcade->reset_game('reset_game_install_date', $game_id, $old_cat_id);
						}

						// Do not write values if there is an error
						if (count($errors))
						{
							$update = false;
						}

						// We go through the display_vars to make sure no one is trying to set variables he/she is not allowed to...
						foreach ($display_vars['vars'] as $config_name => $null)
						{
							if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
							{
								continue;
							}

							$config_value = $cfg_array[$config_name];
							$this->new_game_data[$config_name] = $config_value;

							if ($update)
							{
								// We have to check if the cat_id has changed, if it does we need to send the
								// new and old ids
								if ($config_name == 'cat_id')
								{
									$this->arcade->set_game_data($game_id, $config_name, $config_value, $this->new_game_data[$config_name], $old_cat_id);
									$this->new_game_data['cat_name'] = $this->arcade->get->cat_field($this->new_game_data[$config_name], 'cat_name');
								}
								else if ($config_name == 'game_scoretype')
								{
									$this->arcade->set_game_data($game_id, $config_name, $config_value, false, false, $old_game_scoretype);
								}
								else
								{
									$this->arcade->set_game_data($game_id, $config_name, $config_value);
								}
							}
						}

						if ($update)
						{
							$log_key = 'LOG_ARCADE_EDIT_GAME' . (($reset_game_ins_date) ? '_RESET_INSTALL_DATE' : '');
							$this->arcade->add_log('admin_gid', $game_id, $log_key, $this->new_game_data['game_name']);

							$msg_key	 = ($reset_game_ins_date) ? '<br><br>' . sprintf($this->user->lang['RESET_INSTALL_DATE_GAME_SUCCESS'], $this->new_game_data['game_name']) : '';
							$back_links  = adm_back_link($this->u_action . "&amp;action=edit&amp;g=$game_id");
							$back_links .= sprintf($this->user->lang['ACP_ARCADE_JUMP_MANAGE_GAMES'], '<br><br><a href="' . $this->u_action . '">', '</a>');
							$back_links .= sprintf($this->user->lang['ACP_ARCADE_JUMP_MANAGE_GAME_CAT'], '&nbsp;&bull;&nbsp;<a href="' . append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('manage') . "&amp;mode=category&amp;parent_id={$this->new_game_data['cat_id']}&amp;g=$game_id") . "#g$game_id" . '">', '</a>');
							$back_links .= sprintf($this->user->lang['ARCADE_JUMP_GAME'], '<br><br><a href="' . $this->arcade->url("mode=play&amp;g={$game_id}") . '">', '</a>');
							$back_links .= sprintf($this->user->lang['ARCADE_JUMP_CAT'], '&nbsp;&bull;&nbsp;<a href="' . $this->arcade->url("mode=cat&amp;c={$this->new_game_data['cat_id']}&amp;g=$game_id") . "#g$game_id" . '">', '</a>');
							$back_links .= sprintf($this->user->lang['ARCADE_JUMP_ARCADE_MAIN_PAGE'], '<br><br><a href="' . $this->arcade->url() . '">', '</a>');

							if ($this->arcade_config['game_announce'])
							{
								$this->arcade->phpbb()->create_game_announcement(array($this->new_game_data));
							}

							$this->arcade->cache_purge();

							if ($this->arcade->game->install_file->row_update($game_id))
							{
								trigger_error($this->user->lang['ARCADE_GAME_UPDATED'] . $msg_key . $back_links);
							}
							else
							{
								trigger_error($this->user->lang['ARCADE_GAME_UPDATED_ERROR'] . $msg_key . $back_links, E_USER_WARNING);
							}
						}

						// Output relevant page
						foreach ($display_vars['vars'] as $config_key => $vars)
						{
							if (!is_array($vars) && strpos($config_key, 'legend') === false)
							{
								continue;
							}

							if (strpos($config_key, 'legend') !== false)
							{
								$this->template->assign_block_vars('options', array(
									'S_LEGEND'	=> true,
									'LEGEND'	=> $this->user->lang[$vars])
								);

								continue;
							}

							$type = explode(':', $vars['type']);

							if (in_array($config_key, array('game_download_cost', 'game_cost', 'game_reward', 'game_jackpot')))
							{
								$this->new_game_data[$config_key] = $this->arcade->number_format($this->new_game_data[$config_key], true);
							}

							$this->template->assign_block_vars('options', array(
								'ACTIVE'		=> ($config_key == 'game_desc') ? true : false,
								'KEY'			=> (in_array($config_key, array('game_swf', 'game_installdate', 'game_filesize'))) ? false : $config_key,
								'TITLE'			=> $this->user->lang[$vars['lang']],
								'S_EXPLAIN'		=> $vars['explain'],
								'TITLE_EXPLAIN'	=> ($vars['explain']) ? $this->user->lang[$vars['lang'] . '_EXPLAIN'] : '',
								'CONTENT'		=> build_cfg_template($type, $config_key, $this->new_game_data, $config_key, $vars),
							));

							unset($display_vars['vars'][$config_key]);
						}

						if (isset($display_vars['lang']))
						{
							$this->user->add_lang_ext('jv/arcade', $display_vars['lang']);
						}

						$page_title			= $display_vars['title'];
						$this->page_title	= $page_title;
						$l_title			= $this->user->lang[$display_vars['title']];
						$l_title_explain	= $this->user->lang[$display_vars['title_explain']];

						$s_hidden_fields = array(
							'old_cat_id'			=> $this->new_game_data['cat_id'],
							'old_game_scoretype'	=> $this->new_game_data['game_scoretype']
						);

						$this->template->assign_vars(array(
							'S_EDIT_GAME'				=> true,
							'S_RESET_GAME_INSTALL_DATE'	=> ($this->auth->acl_get('a_arcade_reset_game') && $this->auth->acl_get('a_arcade_game')) ? true : false,
							'S_HIDDEN_FIELDS'			=> build_hidden_fields($s_hidden_fields),

							'U_ACTION'					=> $this->u_action . '&amp;action=edit&amp;g=' . $game_id . (($start) ? '&amp;start=' . $start : '')
						));

						$return = true;
					break;

					case 'delete':
						if (confirm_box(true))
						{
							if ($cat_games_delete || $type_games_delete || $save_type_games_delete)
							{
								if ($save_type_games_delete && $game_save_type == IBPROV3_GAME && !$gametypev3 && !$gametypev32)
								{
									$errors[] = $this->user->lang['ARCADE_SELECT_EMPTY'];
									break;
								}
								else
								{
									$type	= ($cat_games_delete) ? 'cat' : (($type_games_delete) ? 'type' : 'save_type');
									$id		= ($cat_id) ? $cat_id : (($type_games_delete) ? $game_type : $game_save_type);

									if (($game_ids = $this->get_type_game_ids($type, $id, $gametypev3, $gametypev32)) !== false)
									{
										$game_data = $this->arcade->delete_game($game_ids, $errors, $this->delete_reason);
									}
									else
									{
										$errors[] = $this->user->lang['NOT_FOUND_GAME'];
									}
								}
							}
							else
							{
								$game_data = $this->arcade->delete_game($game_id, $errors, $this->delete_reason);
							}

							if (count($errors))
							{
								break;
							}

							$game_name_ary = array();
							foreach ($game_data as $key => $value)
							{
								$game_name_ary[] = $game_data[$key]['game_name'];
							}

							$s = (count($game_name_ary) > 1) ? 'S' : '';
							$game_name_list = implode(', ', $game_name_ary);

							$this->arcade->add_log('admin', "LOG_ARCADE_DELETE_GAME{$s}", $game_name_list);
							trigger_error(sprintf($this->user->lang['GAME' . $s . '_DELETED'], $game_name_list) . adm_back_link($this->u_action));
						}
						else
						{
							if (!$this->auth->acl_get('a_arcade_delete_game'))
							{
								send_status_line(403, 'Forbidden');
								trigger_error($this->user->lang['NO_PERMISSION_GAME_DELETE'] . adm_back_link($this->u_action), E_USER_WARNING);
							}

							if ($cat_games_delete)
							{
								$confirm_lang = 'DELETE_SELECTED_CAT_ALL_GAMES';
								$s_hidden_fields = array(
									'c'					=> $cat_id,
									'cat_games_delete'	=> true
								);
							}
							else if ($type_games_delete)
							{
								$confirm_lang = 'DELETE_SELECTED_GAMETYPE';
								$s_hidden_fields = array(
									'gt'				=> $game_type,
									'type_games_delete'	=> true
								);
							}
							else if ($save_type_games_delete)
							{
								$confirm_lang = 'DELETE_SELECTED_GAME_SAVE_TYPE';
								$s_hidden_fields = array(
									'gst'						=> $game_save_type,
									'save_type_games_delete'	=> true,
									'gametypev3'				=> $gametypev3,
									'gametypev32'				=> $gametypev32
								);
							}
							else
							{
								$confirm_lang = 'DELETE_SELECTED_GAME';
								$s_hidden_fields = array('g' => $game_id);
							}

							$s_hidden_fields = array_merge($s_hidden_fields, array('action' => 'delete'));

							$this->arcade->confirm_box('delete_files', $confirm_lang, $s_hidden_fields);
						}
					break;

					case 'search_game':
						$this->page_title = $this->user->lang['SEARCH'] . ' :: ' . $keywords;
						$this->arcade->search_game($keywords, $total_games, $start, $this->u_action, $errors);

						if (!count($errors))
						{
							$this->user->add_lang('search');

							$l_title			= $this->user->lang('FOUND_SEARCH_MATCHES', $total_games);
							$l_title_explain	= $this->user->lang['SEARCHED_FOR'] . $this->user->lang['COLON'] . ' <strong>' . $keywords . '</strong>';

							$pagination->generate_template_pagination($this->u_action . '&amp;action=search_game&amp;keywords=' . urlencode(htmlspecialchars_decode($keywords)), 'pagination', 'start', $total_games, $this->arcade_config['acp_items_per_page'], $start);
							$this->template->assign_var('S_SEARCH_GAME', true);

							$return = true;
						}
					break;
				}

				if (!$return)
				{
					// Default Arcade Games Page
					// Quick jump of all the games in the arcade...
					$sql = 'SELECT game_id, game_name, game_name_clean
							FROM ' . ARCADE_GAMES_TABLE . "
							ORDER BY game_name_clean ASC";
					$result = $this->db->sql_query($sql);

					while ($row = $this->db->sql_fetchrow($result))
					{
						$this->template->assign_block_vars('quick_jump', array(
							'GAME_ID'	=> $row['game_id'],
							'GAME_NAME'	=> $row['game_name']
						));
					}
					$this->db->sql_freeresult($result);
					// Quick jump of all the games in the arcade...

					$l_title = $this->user->lang['ACP_ARCADE_MANAGE_GAMES'];
					$l_title_explain = $this->user->lang['ACP_ARCADE_MANAGE_GAMES_EXPLAIN'];

					$this->template->assign_vars(array(
						'S_DEFAULT_EDIT_GAME'		=> true,
						'S_CATEGORY_OPTIONS'		=> $this->arcade->make_cat_select(false, false, true, true, true),
						'S_GAMETYPE_OPTIONS'		=> $this->arcade->game_type_select(),
						'S_GAME_SAVE_TYPE_OPTIONS'	=> $this->arcade->game_save_type_select(),
						'S_IBPROV3_GAME'			=> IBPROV3_GAME,

						'U_ACTION'					=> $this->u_action
					));
				}
			break;

			case 'users':
				$form_key = 'acp_arcade_users';
				add_form_key($form_key);
				$this->template->assign_var('S_MANAGE_USERS', true);
				$page_title = 'ACP_ARCADE_MANAGE_USERS';
				$this->page_title = $page_title;

				$username	= $this->request->variable('username', '', true);
				$user_id	= (int) $this->request->variable('u', 0);
				$game_id	= (int) $this->request->variable('g', 0);

				$action = ($this->arcade->is_post_empty('submituser')) ? 'prefs' : $action;
				$action = ($this->arcade->is_post_empty('reset_user_scores')) ? 'reset_user_scores' : $action;
				$action = ($this->arcade->is_post_empty('reset_user_super_records')) ? 'reset_user_super_records' : $action;
				$action = ($this->arcade->is_post_empty('reset_user_all')) ? 'reset_user_all' : $action;
				$action = ($this->arcade->is_post_empty('user_banned')) ? 'user_banned' : $action;

				switch ($action)
				{
					case 'prefs':
						$this->user->add_lang(array('ucp', 'acp/users'));
						$this->user->add_lang_ext('jv/arcade', 'info_ucp_arcade');
						$user_row = $this->arcade->userdata('user_info', $user_id, $username);

						if (!$user_row)
						{
							trigger_error($this->user->lang['NO_USER'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						$page_title = 'USER_ADMIN';
						$this->page_title = $page_title;
						$l_title_explain = $this->user->lang['USER_ADMIN_EXPLAIN'];
						$restore_settings = $this->arcade->is_post_empty('restore_settings');

						$cdata = array(
							'view_avatars'				=> (bool) $this->request->variable('avatars'				, $this->arcade->optionget('view_avatars', $user_row['user_arcade_options'], true)),
							'view_game_image'			=> (bool) $this->request->variable('game_image'				, $this->arcade->optionget('view_game_image', $user_row['user_arcade_options'], true)),
							'view_popup_icon'			=> (bool) $this->request->variable('popup_icon'				, $this->arcade->optionget('view_popup_icon', $user_row['user_arcade_options'], true)),
							'game_over_random_games'	=> (bool) $this->request->variable('random_games'			, $this->arcade->optionget('game_over_random_games', $user_row['user_arcade_options'], true)),
							'game_over_sound'			=> (bool) $this->request->variable('game_over_sound'		, $this->arcade->optionget('game_over_sound', $user_row['user_arcade_options'], true)),
							'game_over_animation'		=> (bool) $this->request->variable('game_over_animation'	, $this->arcade->optionget('game_over_animation', $user_row['user_arcade_options'], true)),
							'game_over_animation_sound'	=> (bool) $this->request->variable('animation_sound'		, $this->arcade->optionget('game_over_animation_sound', $user_row['user_arcade_options'], true))
						);

						if ($user_row['user_id'] != ANONYMOUS)
						{
							$cdata = array_merge($cdata, array(
								'challenge'			=> (bool) $this->request->variable('challenge', $this->arcade->optionget('challenge', $user_row['user_arcade_options'], true)),
								'arcade_pm'			=> (bool) $this->request->variable('arcade_pm', $this->arcade->optionget('arcade_pm', $user_row['user_arcade_options'], true)),

								'bbcode'			=> (bool) $this->request->variable('bbcode', $this->arcade->optionget('bbcode', $user_row['user_arcade_options'], true)),
								'smilies'			=> (bool) $this->request->variable('smilies', $this->arcade->optionget('smilies', $user_row['user_arcade_options'], true))
							));
						}

						$data = array(
							'arcade_cat_style'			=> $this->request->variable('arcade_cat_style', $user_row['arcade_cat_style']),
							'arcade_cat_games_style'	=> $this->request->variable('arcade_cat_games_style', $user_row['arcade_cat_games_style']),
							'games_sort_order'			=> $this->request->variable('games_sort_order', $user_row['games_sort_order']),
							'games_sort_dir'			=> $this->request->variable('games_sort_dir', $user_row['games_sort_dir']),
							'user_arcade_rank'			=> (int) $this->request->variable('ranks_sort_dir', $user_row['user_arcade_rank'])
						);

						if ($update || $restore_settings)
						{
							if (!$restore_settings)
							{
								if (!function_exists('validate_data'))
								{
									include($this->root_path . 'includes/functions_user.' . $this->php_ext);
								}

								$validate_array = array(
									'games_sort_order'	=> array('string', false, 1, 1),
									'games_sort_dir'	=> array('string', false, 1, 1),
									'user_arcade_rank'	=> array('num', false, 0),
								);

								$errors = validate_data($data, $validate_array);
							}

							if (!check_form_key($form_key))
							{
								$errors[] = 'FORM_INVALID';
							}

							if (!count($errors))
							{
								if ($restore_settings)
								{
									$data = $this->arcade->user_default_settings($user_row['user_id']);
								}
								else
								{
									$this->arcade->rev_optionset($user_row, 'view_avatars', $cdata['view_avatars']);
									$this->arcade->rev_optionset($user_row, 'view_game_image', $cdata['view_game_image']);
									$this->arcade->rev_optionset($user_row, 'view_popup_icon', $cdata['view_popup_icon']);
									$this->arcade->rev_optionset($user_row, 'game_over_random_games', $cdata['game_over_random_games']);
									$this->arcade->rev_optionset($user_row, 'game_over_sound', $cdata['game_over_sound']);
									$this->arcade->rev_optionset($user_row, 'game_over_animation', $cdata['game_over_animation']);
									$this->arcade->rev_optionset($user_row, 'game_over_animation_sound', $cdata['game_over_animation_sound']);

									if ($user_row['user_id'] != ANONYMOUS)
									{
										$this->arcade->rev_optionset($user_row, 'arcade_pm', $cdata['arcade_pm']);
										$this->arcade->rev_optionset($user_row, 'challenge', $cdata['challenge']);

										$this->arcade->rev_optionset($user_row, 'bbcode', $cdata['bbcode']);
										$this->arcade->rev_optionset($user_row, 'smilies', $cdata['smilies']);
									}

									$data['user_arcade_options'] = $user_row['user_arcade_options'];
								}

								$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
										SET ' . $this->db->sql_build_array('UPDATE', $data) . '
										WHERE user_id = ' . (int) $user_row['user_id'];
								$this->db->sql_query($sql);

								$this->cache->destroy('sql', ARCADE_CHALLENGE_CHAMP_TABLE);

								$this->arcade->add_log('admin', 'LOG_ARCADE_USER_SET_UPDATE', $user_row['username']);
								trigger_error($this->user->lang['USER_OVERVIEW_UPDATED'] . adm_back_link($this->u_action . '&amp;action=prefs&amp;u=' . $user_row['user_id']));
							}

							$error = array_map(array($this->user, 'lang'), $error);
						}

						$s_hidden_fields = array(
							'u' => $user_row['user_id']
						);

						$sql = 'SELECT *
								FROM ' . ARCADE_RANKS_TABLE . '
								WHERE rank_special = 1
								ORDER BY rank_title';
						$result = $this->db->sql_query($sql);

						$s_rank_options = '<option value="0"' . ((!$user_row['user_arcade_rank']) ? ' selected="selected"' : '') . '>' . $this->user->lang['NO_SPECIAL_RANK'] . '</option>';

						while ($row = $this->db->sql_fetchrow($result))
						{
							$selected = ($user_row['user_arcade_rank'] && $row['rank_id'] == $user_row['user_arcade_rank']) ? ' selected="selected"' : '';
							$s_rank_options .= '<option value="' . $row['rank_id'] . '"' . $selected . '>' . $row['rank_title'] . '</option>';
						}
						$this->db->sql_freeresult($result);

						$this->template->assign_vars(array(
							'S_USER_PREFS'				=> true,
							'S_ANONYMOUS'				=> ($user_row['user_id'] == ANONYMOUS) ? true : false,
							'S_HIDDEN_FIELDS'			=> build_hidden_fields($s_hidden_fields),
							'S_ARCADE_BANNED'			=> ($user_row['user_type'] != USER_FOUNDER && !in_array($user_row['user_id'], array($this->user->data['user_id'], ANONYMOUS)) && !in_array($user_row['user_id'], array_keys($this->arcade->ban_users()))) ? true : false,

							'S_AVATARS_ENABLE'			=> $cdata['view_avatars'],
							'S_GAME_IMAGE_ENABLED'		=> $cdata['view_game_image'],
							'S_POPUP_ICON_ENABLED'		=> $cdata['view_popup_icon'],
							'S_GO_RANDOM_GAMES'			=> $cdata['game_over_random_games'],
							'S_GO_SOUND'				=> $cdata['game_over_sound'],
							'S_GO_ANIMATION'			=> $cdata['game_over_animation'],
							'S_GO_ANIMATION_SOUND'		=> $cdata['game_over_animation_sound'],
							'U_ACTION'					=> $this->u_action . '&amp;action=prefs',

							'MANAGE_USERNAME'			=> $user_row['username'],
							'ARCADE_CAT_STYLES'			=> $this->arcade->select_cat_styles($data['arcade_cat_style'], true),
							'ARCADE_CAT_GAMES_STYLES'	=> $this->arcade->select_cat_styles($data['arcade_cat_games_style']),
							'GAMES_SORT_ORDER'			=> $this->arcade->select_games_sort_order($data['games_sort_order']),
							'GAMES_SORT_DIR'			=> $this->arcade->select_games_sort_dir($data['games_sort_dir']),
							'RANKS_SORT_DIR'			=> $s_rank_options
						));

						if ($user_row['user_id'] != ANONYMOUS)
						{
							$this->template->assign_vars(array(
								'S_ARCADE_PM_ENABLED'		=> $cdata['arcade_pm'],
								'S_CHALLENGE_ENABLED'		=> $cdata['challenge'],

								'S_BBCODE_ENABLED'			=> $cdata['bbcode'],
								'S_SMILIES_ENABLED'			=> $cdata['smilies'],

								'ARCADE_SUPER_HIGSCORES'	=> $this->arcade->number_format($user_row['arcade_total_super_scores']),
								'ARCADE_HIGHSCORES'			=> $this->arcade->number_format($user_row['arcade_total_wins']),
								'ARCADE_CHALLENGE_WINS'		=> $this->arcade->number_format($this->arcade->display->highscores('', $user_row['user_id'], 'challenge')),
								'ARCADE_TOUR_WINS'			=> $this->arcade->number_format($this->arcade->display->highscores('', $user_row['user_id'], 'tour'))
							));
						}

						$return = true;
					break;

					case 'reset_auto_score':
						if ($this->arcade->is_post_empty('reset_auto_users_score'))
						{
							$reset_score_gc = (int) $this->request->variable('auto_reset_score_days', 1);
							$reset_score_gc = ($reset_score_gc > 0) ? $reset_score_gc : 1;
							$reset_score_gc = $reset_score_gc * 86400;

							$hour = $min = 0;
							$reset_hour = $this->arcade->hour_min($this->request->variable('auto_reset_score_hour', ''), $hour, $min);
							$reset_type = (int) $this->request->variable('auto_reset_score_type', 0);

							$reset_time = $this->arcade->gen_auto_reset_score_days($reset_type, $reset_score_gc, $reset_hour);

							$this->arcade_config->set('auto_reset_score_time', $reset_time, false);

							// Update current time
							$this->arcade_config->set('auto_reset_score_last_gc', $time, false);

							$this->arcade_config->set('auto_reset_score_top', (int) $this->request->variable('auto_reset_score_top_number', 10));
							$this->arcade_config->set('auto_reset_score', (bool) $this->request->variable('auto_reset_score', false));
							$this->arcade_config->set('auto_reset_score_plays', (bool) $this->request->variable('auto_reset_score_plays', false));
							$this->arcade_config->set('auto_reset_score_gc', $reset_score_gc);
							$this->arcade_config->set('auto_reset_score_hour', $reset_hour);
							$this->arcade_config->set('auto_reset_score_type', $reset_type);

							$this->arcade->add_log('admin', 'LOG_ARCADE_AUTO_RESET_SCORE_SETTINGS');
							trigger_error($this->user->lang['CONFIG_UPDATED'] . adm_back_link($this->u_action));
						}
					break;

					case 'reset_user_scores':
						if (!confirm_box(true))
						{
							$s_hidden_fields = array(
								'u'					=> $user_id,
								'reset_user_scores'	=> true
							);

							$this->arcade->confirm_box('retain_plays', 'RESET_USER_SCORES', $s_hidden_fields);
						}
						else
						{
							$this->arcade->reset('user_scores', $user_id);
							$username = $this->arcade->userdata('username', $user_id);

							$this->arcade->sync('total_data', 'plays');
							$this->arcade->cache_purge();

							$this->arcade->add_rvlog('LOG_ARCADE_RESET_USER_SCORES', 'retain_plays', $username);
							trigger_error(sprintf($this->user->lang['ARCADE_RESET_USER_SCORES_DONE'], $username) . adm_back_link($this->u_action));
						}
					break;

					case 'reset_user_super_records':
						if (!confirm_box(true))
						{
							$s_hidden_fields = array(
								'u'						=> $user_id,
								'reset_super_record'	=> true
							);

							$this->arcade->confirm_box(false, 'RESET_USER_SUPER_RECORDS', $s_hidden_fields);
						}
						else
						{
							$this->arcade->reset('super_record', $user_id);
							$username = $this->arcade->userdata('username', $user_id);

							$this->cache->destroy('_arcade_super_champion_all');

							$this->arcade->add_log('admin', 'LOG_ARCADE_RESET_USER_SUPER_RECORDS', $username);
							trigger_error(sprintf($this->user->lang['RESET_USER_SUPER_RECORDS_DONE'], $username) . adm_back_link($this->u_action));
						}
					break;

					case 'reset_user_all':
						if (confirm_box(true))
						{
							$this->arcade->reset('user', $user_id);
							$username = $this->arcade->userdata('username', $user_id);

							$this->arcade->sync('total_data', 'plays');
							$this->arcade->cache_purge();

							$this->arcade->add_log('admin', 'LOG_ARCADE_RESET_USER_ALL', $username);
							trigger_error(sprintf($this->user->lang['ARCADE_RESET_USER_ALL_DONE'], $username) . adm_back_link($this->u_action));
						}
						else
						{
							$s_hidden_fields = array(
								'u'					=> $user_id,
								'reset_user_all'	=> true,
							);
							confirm_box(false, 'RESET_USER_ALL', build_hidden_fields($s_hidden_fields));
						}
					break;

					case 'user_banned':
						if (!$user_id || $user_id == ANONYMOUS)
						{
							break;
						}

						if (confirm_box(true))
						{
							$user_data = $this->arcade->userdata('set_auth', $user_id);
							$this->arcade->banned(ARCADE_BANNED_ADMIN, $user_id, $user_data['user_ip']);

							$this->arcade->add_log('admin', 'LOG_ARCADE_USER_BANNED', $user_data['username']);
							trigger_error(sprintf($this->user->lang['ARCADE_USER_BANNED_DONE'], $user_data['username']) . adm_back_link($this->u_action));
						}
						else
						{
							$this->user->add_lang('acp/users');

							if ($this->user->data['user_id'] == $user_id)
							{
								trigger_error($this->user->lang['CANNOT_BAN_YOURSELF'] . adm_back_link($this->u_action), E_USER_WARNING);
							}

							if ($this->arcade->userdata('user_type', $user_id) == USER_FOUNDER)
							{
								trigger_error($this->user->lang['CANNOT_BAN_FOUNDER'] . adm_back_link($this->u_action), E_USER_WARNING);
							}

							$s_hidden_fields = array(
								'u'				=> $user_id,
								'user_banned'	=> true,
							);
							confirm_box(false, 'ARCADE_USER_BANNED', build_hidden_fields($s_hidden_fields));
						}
					break;

					case 'delete':
						if (!$game_id || !$user_id)
						{
							trigger_error($this->user->lang['NO_USERS_OR_GAMES'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						if (confirm_box(true))
						{
							$game_data = $this->arcade->get->game_data($game_id);
							$this->arcade->delete_score($game_data, $user_id);
							$username = $this->arcade->userdata('username', $user_id);

							$this->arcade->sync('users_total_data');
							$this->arcade->cache_purge();

							$this->arcade->add_rvlog('LOG_ARCADE_DELETE_SCORE', 'retain_plays', $username, $game_data['game_name']);
							trigger_error(sprintf($this->user->lang['ARCADE_SCORE_DELETED'], $username, $game_data['game_name']) . adm_back_link($this->u_action . "&amp;g=$game_id&amp;action=show_scores"));
						}
						else
						{
							$this->arcade->confirm_box('retain_plays', 'DELETE_SELECTED_SCORE');
						}
					break;

					case 'edit':
						if (!$game_id || !$user_id)
						{
							trigger_error($this->user->lang['NO_USERS_OR_GAMES'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						if ($update)
						{
							if (!check_form_key($form_key))
							{
								trigger_error('FORM_INVALID', E_USER_WARNING);
							}

							$score_data = array(
								'score'				=> (float) $this->request->variable('score', 0.00),
								'score_date'		=> ((bool) $this->request->variable('date_now', false)) ? $time: (int) $this->request->variable('score_date', 0),
								'comment_text'		=> $this->request->variable('comment', '', true),
								'comment_bitfield'	=> '',
								'comment_options'	=> 0,
								'comment_uid'		=> ''
							);

							$enable_bbcode	= ($this->arcade_config['parse_bbcode']) ? (((bool) $this->request->variable('parse_bbcode', false)) ? true : false) : false;
							$enable_smilies	= ($this->arcade_config['parse_smilies']) ? (((bool) $this->request->variable('parse_smilies', false)) ? true : false) : false;
							$enable_urls	= ($this->arcade_config['parse_links']) ? (((bool) $this->request->variable('parse_links', false)) ? true : false) : false;

							generate_text_for_storage($score_data['comment_text'], $score_data['comment_uid'], $score_data['comment_bitfield'], $score_data['comment_options'], $enable_bbcode, $enable_urls, $enable_smilies);

							$game_data = $this->arcade->get->game_data($game_id);
							$this->arcade->update_score($score_data, $user_id, $game_id);
							$username = $this->arcade->userdata('username', $user_id);

							$this->arcade->sync('users_total_data');
							$this->arcade->cache_purge();

							$this->arcade->add_log('admin', 'LOG_ARCADE_EDIT_SCORE', $username, $game_data['game_name']);
							trigger_error(sprintf($this->user->lang['ARCADE_SCORE_UPDATED'], $username, $game_data['game_name']) . adm_back_link($this->u_action . "&amp;g=$game_id&amp;action=show_scores"));
						}

						$sql_array = array(
							'SELECT'	=> 'g.game_name, p.total_time, p.total_plays, u.user_id, u.username, u.user_colour, ' . (($this->arcade_config['game_comment']) ? 's.*' : 's.score, s.score_date'),
							'FROM'		=> array(
								ARCADE_SCORES_TABLE	=> 's',
							),
							'LEFT_JOIN'	=> array(
								array(
									'FROM'	=> array(ARCADE_GAMES_TABLE => 'g'),
									'ON'	=> 's.game_id = g.game_id'
								),
								array(
									'FROM'	=> array(ARCADE_PLAYS_TABLE => 'p'),
									'ON'	=> 's.game_id = p.game_id AND s.user_id = p.user_id'
								),
								array(
									'FROM'	=> array(USERS_TABLE => 'u'),
									'ON'	=> 's.user_id = u.user_id'
								),
							),
							'WHERE'		=> 's.user_id = u.user_id AND s.user_id = ' . (int) $user_id . ' AND g.game_id = ' . (int) $game_id,
						);

						$sql = $this->db->sql_build_query('SELECT', $sql_array);
						$result = $this->db->sql_query($sql);
						$row = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);

						if (!$row)
						{
							trigger_error($this->user->lang['NO_USERS_OR_GAMES'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						$l_title_explain = $this->user->lang['ACP_ARCADE_EDIT_SCORES_EDIT_EXPLAIN'];

						$comment_data = array(
							'text'			=> '',
							'allow_bbcode'	=> true,
							'allow_smilies'	=> true,
							'allow_urls'	=> true
						);

						if ($this->arcade_config['game_comment'])
						{
							$comment_data = generate_text_for_edit($row['comment_text'], $row['comment_uid'], $row['comment_options']);
						}

						$this->template->assign_vars(array(
							'S_EDIT_SCORES'			=> true,
							'S_GAME_COMMENT'		=> ($this->arcade_config['game_comment']) ? true : false,
							'S_BBCODE_CHECKED'		=> ($comment_data['allow_bbcode']) ? ' checked="checked"' : '',
							'S_SMILIES_CHECKED'		=> ($comment_data['allow_smilies']) ? ' checked="checked"' : '',
							'S_MAGIC_URL_CHECKED'	=> ($comment_data['allow_urls']) ? ' checked="checked"' : '',

							'U_EDIT_ACTION'			=> $this->u_action . "&amp;g=$game_id&amp;u=$user_id&amp;action=$action",

							'SCORE_USERNAME'		=> $this->arcade->adm_username($row['user_id'], $row['username'], $row['user_colour'], $this->u_action),
							'GAME_NAME'				=> $row['game_name'],
							'SCORE'					=> $row['score'],
							'COMMENT'				=> ($this->arcade_config['game_comment']) ? $comment_data['text'] : '',
							'DATE_RAW'				=> $row['score_date'],
							'DATE'					=> $this->user->format_date($row['score_date']),
							'TOTAL_PLAYS'			=> $row['total_plays'],
							'TOTAL_TIME'			=> $this->arcade->time_format($row['total_time'], true),
							'AVG_TIME'				=> $this->arcade->time_format($row['total_time']/$row['total_plays'], true)
						));

						$return = true;
					break;

					case 'show_scores':
						$game_data	 = $this->arcade->get->game_data($game_id);
						$score_order = ($game_data['game_scoretype'] == SCORETYPE_HIGH) ? 'DESC' : 'ASC';

						if ($super_champion = $this->arcade->game->super_champion($game_data['game_id']))
						{
							$url = $this->u_action . '&amp;g=' . $game_data['game_id'] . '&amp;u=' . $super_champion['user_id'];

							$this->template->assign_block_vars('scorerow', array(
								'S_NOT_DELETE'	=> ($super_champion['score'] == $game_data['game_highscore']) ? true : false,
								'RANK'			=> '<strong>' . $this->user->lang['ARCADE_SUPER_CHAMPION'] . '</strong>',
								'USERNAME'		=> $this->arcade->adm_username($super_champion['user_id'], $super_champion['username'], $super_champion['user_colour'], $this->u_action),
								'SCORE'			=> $this->arcade->number_format($super_champion['score']),
								'COMMENT'		=> '',
								'DATE'			=> $this->user->format_date($super_champion['score_date']),
								'U_DELETE'		=> $url . '&amp;action=champ_delete'
							));
						}

						if ($total_scores = $this->arcade->get->total('user', 'scores', $game_data['game_id']))
						{
							$sql_array = array(
								'SELECT'	=> 'u.user_id, u.user_colour, u.username, ' . (($this->arcade_config['game_comment']) ? 's.*' : 's.score, s.score_date'),
								'FROM'		=> array(USERS_TABLE	=> 'u'),
								'LEFT_JOIN'	=> array(
									array(
										'FROM' => array(ARCADE_SCORES_TABLE => 's'), 'ON' => 'u.user_id = s.user_id'
									),
								),
								'WHERE'		=> 'u.user_id = s.user_id AND s.game_id = ' . (int) $game_data['game_id'],
								'ORDER_BY'	=> 's.score ' . $score_order . ', s.score_date ASC',
							);

							$sql = $this->db->sql_build_query('SELECT', $sql_array);
							$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);

							$actual_rank = $start;
							$last_value = $rank = 0;

							while ($row = $this->db->sql_fetchrow($result))
							{
								$this->arcade->get->actual_rank($actual_rank, $rank, $row['score'], $last_value);
								$url = $this->u_action . '&amp;g=' . $game_data['game_id'] . '&amp;u=' . $row['user_id'];

								$this->template->assign_block_vars('scorerow', array(
									'RANK'			=> $rank,
									'USERNAME'		=> $this->arcade->adm_username($row['user_id'], $row['username'], $row['user_colour'], $this->u_action),
									'SCORE'			=> $this->arcade->number_format($row['score']),
									'COMMENT'		=> ($this->arcade_config['game_comment']) ? generate_text_for_display($row['comment_text'], $row['comment_uid'], $row['comment_bitfield'], $row['comment_options']) : '',
									'DATE'			=> $this->user->format_date($row['score_date']),
									'U_EDIT'		=> $url . '&amp;action=edit',
									'U_DELETE'		=> $url . '&amp;action=delete',
								));
							}
							$this->db->sql_freeresult($result);
						}

						$l_title_explain = $this->user->lang['ACP_ARCADE_EDIT_SCORES_LIST_EXPLAIN'];
						$pagination->generate_template_pagination($this->u_action . '&amp;action=show_scores&amp;g=' . $game_data['game_id'], 'pagination', 'start', $total_scores, $this->arcade_config['acp_items_per_page'], $start);

						$this->template->assign_vars(array(
							'S_GAME_SCORES'		=> true,
							'S_GAME_COMMENT'	=> ($this->arcade_config['game_comment']) ? true : false,

							'GAME_TITLE'		=> sprintf($this->user->lang['ARCADE_GAME_SCORES'], $game_data['game_name'])
						));

						$return = true;
					break;

					case 'champ_delete':
						if (!$game_id || !$user_id)
						{
							trigger_error($this->user->lang['NO_USERS_OR_GAMES'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						if (confirm_box(true))
						{
							$game_data = $this->arcade->get->game_data($game_id);

							$sql = 'DELETE FROM ' . ARCADE_SUPER_SCORES_TABLE . '
									WHERE game_id = ' . (int) $game_data['game_id'];
							$this->db->sql_query($sql);

							$this->arcade->sync('super_champ', $game_data['game_id']);
							$this->arcade->sync('users_total_data');
							$this->arcade->cache_purge('score');
							$username = $this->arcade->userdata('username', $user_id);

							$this->arcade->add_log('admin', 'LOG_ARCADE_DELETE_SUPER_CHAMPION_SCORE', $username, $game_data['game_name']);
							trigger_error(sprintf($this->user->lang['ARCADE_SUPER_CHAMPION_SCORE_DELETED'], $username, $game_data['game_name']) . adm_back_link($this->u_action . "&amp;g=$game_id&amp;action=show_scores"));
						}
						else
						{
							confirm_box(false, 'DELETE_SELECTED_SUPER_CHAMPION_SCORE');
						}
					break;
				}

				if (!$return)
				{
					$sql_array = array(
						'SELECT'	=> 'g.game_id , g.game_name, g.game_name_clean',
						'FROM'		=> array(
							ARCADE_GAMES_TABLE	=> 'g',
						),
						'LEFT_JOIN'	=> array(
							array(
								'FROM'	=> array(ARCADE_SCORES_TABLE => 's'),
								'ON'	=> 'g.game_id = s.game_id'
							),
							array(
								'FROM'	=> array(ARCADE_SUPER_SCORES_TABLE => 'sc'),
								'ON'	=> 'g.game_id = sc.game_id'
							),
						),
						'WHERE'		=> 'g.game_id = s.game_id OR g.game_id = sc.game_id',
						'ORDER_BY'	=> 'g.game_name_clean ASC',
					);

					$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
					$result = $this->db->sql_query($sql);
					while ($row = $this->db->sql_fetchrow($result))
					{
						$this->template->assign_block_vars('quick_jump', array(
							'GAME_ID'	=> $row['game_id'],
							'GAME_NAME'	=> $row['game_name']
						));
					}
					$this->db->sql_freeresult($result);

					$s_hidden_fields = array('action' => 'show_scores');

					$last_date_user = $next_date_user = '';
					if ($this->config['board_timezone'] != $this->user->data['user_timezone'])
					{
						$last_date_user = $this->user->format_date($this->arcade->gen_board_datetime('board_time', $this->arcade_config['auto_reset_score_last_gc']), false, true);
						$next_date_user = $this->user->format_date($this->arcade->gen_board_datetime('board_time', $this->arcade_config['auto_reset_score_time']), false, true);
					}

					$this->template->assign_vars(array(
						'S_USERS_OPTIONS'				=> true,
						'S_HIDDEN_FIELDS'				=> build_hidden_fields($s_hidden_fields),
						'S_SHOW_POINTS'					=> ($this->arcade->points->data['installed'] && $this->auth->acl_get('a_arcade_points_settings')),
						'S_AUTO_RESET_SCORE'			=> (bool) $this->arcade_config['auto_reset_score'],
						'S_AUTO_RESET_SCORE_PLAYS'		=> ($this->arcade_config['auto_reset_score_plays']) ? ' checked="checked"' : '',

						'U_ACTION'						=> $this->u_action,
						'U_FIND_USERNAME'				=> append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=searchuser&amp;form=select_user&amp;field=username&amp;select_single=true'),

						'ANONYMOUS_USER_ID'				=> ANONYMOUS,
						'AUTO_RESET_SCORE_TOP_NUMBER'	=> (int) $this->arcade_config['auto_reset_score_top'],
						'AUTO_RESET_SCORE_DAYS'			=> (int) $this->arcade_config['auto_reset_score_gc'] / 86400,
						'AUTO_RESET_SCORE_HOUR'			=> $this->arcade_config['auto_reset_score_hour'],
						'AUTO_RESET_SCORE_TYPE_OPTIONS'	=> $this->auto_reset_score_type($this->arcade_config['auto_reset_score_type']),
						'AUTO_RESET_LAST_DATE_BOARD'	=> $this->arcade->gen_board_datetime('board_time', $this->arcade_config['auto_reset_score_last_gc'], true),
						'AUTO_RESET_NEXT_DATE_BOARD'	=> ($this->arcade_config['auto_reset_score']) ? $this->arcade->gen_board_datetime('board_time', $this->arcade_config['auto_reset_score_time'], true) : '-',
						'AUTO_RESET_LAST_DATE_USER'		=> $last_date_user ? $this->user->lang('ACP_ARCADE_USER_TIMEZONE_DATE', $last_date_user) : false,
						'AUTO_RESET_NEXT_DATE_USER'		=> $next_date_user ? (($this->arcade_config['auto_reset_score']) ? $this->user->lang('ACP_ARCADE_USER_TIMEZONE_DATE', $next_date_user) : '-') : false
					));

					// This next bit of code is used to grab all the users that have some type of arcade data stored
					$user_ids = array();
					// These tables could all possibly contain user related arcade data
					$tables = array(ARCADE_FAVS_TABLE, ARCADE_PLAYS_TABLE, ARCADE_RATING_TABLE, ARCADE_SCORES_TABLE, ARCADE_SUPER_SCORES_TABLE);
					foreach ($tables as $table)
					{
						$sql_array = array(
							'SELECT'	=> 'u.user_id',
							'FROM'		=> array($table => 'u'),
							'ORDER_BY'	=> 'u.user_id ASC',
						);

						$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
						$result = $this->db->sql_query($sql);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$user_ids[] = $row['user_id'];
						}
						$this->db->sql_freeresult($result);
					}

					// Order and remove the duplicated user ids
					$user_ids = array_unique($user_ids);
					$l_title_explain = $this->user->lang['ACP_ARCADE_MANAGE_USERS_EXPLAIN'];

					if (count($user_ids))
					{
						// Now lets get the usernames for all the users
						$sql = 'SELECT user_id, username, username_clean
								FROM ' . USERS_TABLE . '
								WHERE ' . $this->db->sql_in_set('user_id', $user_ids) . '
								ORDER BY username_clean ASC';
						$result = $this->db->sql_query($sql);

						while ($row = $this->db->sql_fetchrow($result))
						{
							$this->template->assign_block_vars('user_jump', array(
								'USER_ID'	=> $row['user_id'],
								'USERNAME'	=> $row['username']
							));
						}
						$this->db->sql_freeresult($result);
					}
				}
			break;

			case 'tournament':
				$this->arcade->container('tournament', true);
				$tour_id  = (int) $this->request->variable('tour_id', 0);
				$end_tour = (bool) $this->request->variable('end_tour', false);

				if (($action == 'create' && ($this->request->variable('active_tour', false) || $end_tour)) || ($action == 'delete' && !$this->auth->acl_get('a_arcade_delete_tour')))
				{
					$action = '';
				}

				$def_title = true;
				$tour_data = array();
				$form_key = 'acp_arcade_tournament';
				add_form_key($form_key);
				$this->template->assign_var('S_MANAGE_TOURNAMENT', true);

				switch ($action)
				{
					case 'create':
					case 'rand_create':
						$page_title = 'CREATE_TOUR';
						$this->page_title = $page_title;
						$l_title			= $this->user->lang[$page_title];
						$l_title_explain	= $this->user->lang['ARCADE_TOUR_EDIT_EXPLAIN'];
						$def_title = false;
					break;

					default:
						$page_title = 'ACP_ARCADE_MANAGE_TOUR';
						$this->page_title = $page_title;
					break;
				}

				if ($def_title)
				{
					$l_title			= $this->user->lang[$page_title];
					$l_title_explain	= $this->user->lang[$page_title . '_EXPLAIN'];
				}

				$td = array(
					'tour_name'			=> '',
					'tour_games'		=> array(),
					'tour_groups'		=> array(),
					'play_max'			=> 0,
					'reward_1'			=> 0.00,
					'reward_2'			=> 0.00,
					'reward_3'			=> 0.00,
					'post_id'			=> 0,
					'tour_starttime'	=> '',
					'tour_endtime'		=> ''
				);

				switch ($action)
				{
					case 'edit':
						if (!$tour_id)
						{
							$action = '';
							break;
						}

						$sql = 'SELECT *
								FROM ' . ARCADE_TOUR_TABLE . '
								WHERE tour_status <> ' . ARCADE_END_TOUR . "
								AND tour_id = $tour_id";
						$result = $this->db->sql_query($sql);
						$td = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);

						if (!$td)
						{
							$action = '';
							break;
						}

						$td['tour_games']		= array_map('intval', explode(',', $td['tour_games']));
						$td['tour_groups']		= array_map('intval', explode(',', $td['tour_groups']));
						$td['tour_starttime']	= $this->user->format_date($td['tour_starttime'], 'Y-m-d H:i', true);
						$td['tour_endtime']		= $this->user->format_date($td['tour_endtime'], 'Y-m-d H:i', true);

						$tour_data = array(
							'tour_id' => $tour_id
						);
					case 'create':
					case 'rand_create':
						$avg_games_num		= intval($this->arcade_config['tour_max_games'] / 2);
						$tour_started		= (!empty($td['tour_id']) && $td['tour_status'] == ARCADE_START_TOUR) ? true : false;
						$tour_games			= $this->request->variable('tour_games', array(0));
						$tour_cats			= $this->request->variable('tour_cats', array(0));
						$tour_groups		= $this->request->variable('tour_groups', array(0));
						$num_games			= (int) $this->request->variable('num_games', $avg_games_num);
						$tour_not_played	= $this->request->variable('tour_not_played', false);

						if ($submit && $action == 'rand_create')
						{
							$num_games = ($num_games < $this->arcade_config['tour_min_games'] || $num_games > $this->arcade_config['tour_max_games']) ? $avg_games_num : $num_games;
							$num_games = ($num_games < $this->arcade_config['tour_min_games']) ? $this->arcade_config['tour_min_games'] : $num_games;
							$tour_games = $this->arcade->get->random_game($num_games, $tour_cats, false, true, $tour_not_played);
						}

						$tour_data += array(
							'tour_name'			=> $this->request->variable('tour_name', $td['tour_name'], true),
							'tour_games'		=> (!$tour_started && !empty($tour_games)) ? $tour_games : $td['tour_games'],
							'tour_groups'		=> (!$tour_started && !empty($tour_groups)) ? $tour_groups : $td['tour_groups'],
							'play_max'			=> (!$tour_started) ? (int) $this->request->variable('play_max', $td['play_max']) : $td['play_max'],
							'tour_starttime'	=> (!$tour_started) ? $this->request->variable('tour_starttime', $td['tour_starttime']) : $td['tour_starttime'],
							'tour_endtime'		=> $this->request->variable('tour_endtime', $td['tour_endtime'])
						);

						if ($this->arcade_config['tour_reward_enable'] && $this->arcade->points->data['show'])
						{
							$tour_data += array(
								'reward_1' => (float) $this->request->variable('tour_reward_1', $td['reward_1']),
								'reward_2' => (float) $this->request->variable('tour_reward_2', $td['reward_2']),
								'reward_3' => (float) $this->request->variable('tour_reward_3', $td['reward_3'])
							);
						}
						else
						{
							$tour_data += array(
								'reward_1' => $td['reward_1'],
								'reward_2' => $td['reward_2'],
								'reward_3' => $td['reward_3']
							);
						}

						if ($submit)
						{
							if (!check_form_key($form_key))
							{
								$errors[] = $this->user->lang['FORM_INVALID'];
							}

							if ($v = $this->arcade->validate_data('string', 'ARCADE_TOUR_NAME', $tour_data['tour_name'], 3, 255))
							{
								$errors[] = $v;
							}

							if ($action == 'rand_create' && empty($tour_cats))
							{
								$errors[] = $this->user->lang['ARCADE_NO_SELECT_CATS'];
							}
							else
							{
								if (empty($tour_data['tour_games']))
								{
									foreach ($tour_data['tour_games'] as $game_id)
									{
										if (!$this->arcade->get->game_field($game_id, 'cat_id', false))
										{
											unset($tour_data['tour_games'][$game_id]);
										}
									}

									$tour_data['tour_games'] = array_map('intval', $tour_data['tour_games']);
								}

								if (empty($tour_data['tour_games']))
								{
									$errors[] = $this->user->lang['ARCADE_NO_SELECT_GAMES'];
								}
								else if (count($tour_data['tour_games']) < $this->arcade_config['tour_min_games'])
								{
									if ($action == 'rand_create')
									{
										$errors[] = sprintf($this->user->lang['ARCADE_TOUR_MIN_GAMES_CAT_ERROR'], $this->arcade->number_format($this->arcade_config['tour_min_games']));
									}
									else
									{
										$errors[] = sprintf($this->user->lang['ARCADE_TOUR_MIN_GAMES_ERROR'], count($tour_data['tour_games']), $this->arcade->number_format($this->arcade_config['tour_min_games']));
									}
								}
								else if (count($tour_data['tour_games']) > $this->arcade_config['tour_max_games'])
								{
									$errors[] = sprintf($this->user->lang['ARCADE_TOUR_MAX_GAMES_ERROR'], count($tour_data['tour_games']), $this->arcade->number_format($this->arcade_config['tour_max_games']));
								}
							}

							if (empty($tour_data['tour_groups']))
							{
								$errors[] = $this->user->lang['ARCADE_NO_SELECT_GROUPS'];
							}

							$tour_data['play_max'] = ($tour_data['play_max'] < 0 || $tour_data['play_max'] > 99) ? 0 : $tour_data['play_max'];

							if ($this->arcade_config['tour_reward_enable'] && $this->arcade->points->data['show'])
							{
								if ($v = $this->arcade->validate_data('float', 'ARCADE_TOUR_REWARD_1', $tour_data['reward_1'], $this->arcade_config['tour_reward_min'], $this->arcade_config['tour_reward_max']))
								{
									$errors[] = $v;
								}

								if ($v = $this->arcade->validate_data('float', 'ARCADE_TOUR_REWARD_2', $tour_data['reward_2'], $this->arcade_config['tour_reward_min'], $this->arcade_config['tour_reward_max']))
								{
									$errors[] = $v;
								}

								if ($v = $this->arcade->validate_data('float', 'ARCADE_TOUR_REWARD_3', $tour_data['reward_3'], $this->arcade_config['tour_reward_min'], $this->arcade_config['tour_reward_max']))
								{
									$errors[] = $v;
								}

								if ($tour_data['reward_1'] < $tour_data['reward_2'])
								{
									$errors[] = sprintf($this->user->lang['ARCADE_MIN_MAX_ERROR'], $this->user->lang['ARCADE_TOUR_REWARD_2'], $this->user->lang['ARCADE_TOUR_REWARD_1']);
								}

								if ($tour_data['reward_2'] < $tour_data['reward_3'])
								{
									$errors[] = sprintf($this->user->lang['ARCADE_MIN_MAX_ERROR'], $this->user->lang['ARCADE_TOUR_REWARD_3'], $this->user->lang['ARCADE_TOUR_REWARD_2']);
								}
							}

							$start_ary = $end_ary = array();
							$tour_st_ary = explode(' ', $tour_data['tour_starttime']);
							if (count($tour_st_ary) < 2)
							{
								$errors[] = sprintf($this->user->lang['ARCADE_TOUR_START_TIME_ERROR'], $tour_data['tour_starttime']);
							}
							else
							{
								list($tour_start_date, $tour_start_time) = $tour_st_ary;
								$start_ary = $this->arcade->validate_date($tour_start_date, $tour_start_time);

								if (!count($start_ary))
								{
									$errors[] = sprintf($this->user->lang['ARCADE_TOUR_START_TIME_ERROR'], $tour_data['tour_starttime']);
								}
							}

							$tour_et_ary = explode(' ', $tour_data['tour_endtime']);
							if (count($tour_et_ary) < 2)
							{
								$errors[] = sprintf($this->user->lang['ARCADE_TOUR_END_TIME_ERROR'], $tour_data['tour_endtime']);
							}
							else
							{
								list($tour_end_date, $tour_end_time) = $tour_et_ary;
								$end_ary = $this->arcade->validate_date($tour_end_date, $tour_end_time);

								if (!count($end_ary))
								{
									$errors[] = sprintf($this->user->lang['ARCADE_TOUR_END_TIME_ERROR'], $tour_data['tour_endtime']);
								}
							}

							if (count($start_ary) && count($end_ary))
							{
								$start_time	= $this->arcade->time_stamp($start_ary['year'], $start_ary['mon'], $start_ary['day'], $start_ary['hour'], $start_ary['min']);
								$end_time	= $this->arcade->time_stamp($end_ary['year'], $end_ary['mon'], $end_ary['day'], $end_ary['hour'], $end_ary['min']);

								if (!$tour_started && $start_time <= $time)
								{
									$errors[] = $this->user->lang['ARCADE_TOUR_START_CUR_TIME_ERROR'];
								}

								if ($start_time >= $end_time)
								{
									$errors[] = $this->user->lang['ARCADE_TOUR_START_END_TIME_ERROR'];
								}
								else if ($end_time <= $time)
								{
									$errors[] = $this->user->lang['ARCADE_TOUR_END_CUR_TIME_ERROR'];
								}
							}

							if (!count($errors))
							{
								$sql_ary = array(
									'tour_name'			=> $tour_data['tour_name'],
									'tour_games'		=> implode(',', $tour_data['tour_games']),
									'tour_groups'		=> implode(',', array_map('intval', $tour_data['tour_groups'])),
									'play_max'			=> $tour_data['play_max'],
									'tour_starttime'	=> $start_time,
									'tour_endtime'		=> $end_time
								);

								$sql_ary += array(
									'reward_1' => $tour_data['reward_1'],
									'reward_2' => $tour_data['reward_2'],
									'reward_3' => $tour_data['reward_3']
								);

								if ($tour_id)
								{
									$sql = 'UPDATE ' . ARCADE_TOUR_TABLE . '
											SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . "
											WHERE tour_id = $tour_id";
									$this->db->sql_query($sql);
								}
								else
								{
									$sql_ary['tour_time'] = $time;
									$this->db->sql_query('INSERT INTO ' . ARCADE_TOUR_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
									$tour_id = (int) $this->db->sql_nextid();
								}

								$main_action = ($action == 'rand_create') ? 'create' : $action;

								if ($this->arcade_config['tour_announce'])
								{
									$tour_ary[$tour_id] = array(
										'tour_name'			=> $tour_data['tour_name'],
										'game_data'			=> $this->arcade->get->game_cat_data($tour_data['tour_games']),
										'tour_groups'		=> $this->arcade->get->group_data($tour_data['tour_groups']),
										'plays_max'			=> $tour_data['play_max'],
										'tour_starttime'	=> $start_time,
										'tour_endtime'		=> $end_time
									);

									$tour_ary[$tour_id] += array(
										'reward_1' => $tour_data['reward_1'],
										'reward_2' => $tour_data['reward_2'],
										'reward_3' => $tour_data['reward_3']
									);

									$this->arcade->phpbb()->create_tour_announcement('tour_announce', $main_action, $tour_ary, $td['post_id']);
								}

								$this->cache->destroy('_arcade_tours');
								$this->cache->destroy('_arcade_tour_check');
								$this->arcade->add_log('admin', 'LOG_ARCADE_TOUR_' . strtoupper($main_action), $tour_data['tour_name']);
								trigger_error($this->user->lang['ARCADE_TOUR_' . strtoupper($main_action) . '_SUCCESS'] . adm_back_link($this->u_action));
							}
						}

						$s_cat_options = $s_game_options = $old_cat = $s_group_options = '';
						$cats_count = $games_count = $groups_count = 0;

						if ($action == 'rand_create')
						{
							$sql = 'SELECT cat_id
									FROM ' . ARCADE_CATS_TABLE . '
									WHERE cat_status = ' . ITEM_LOCKED . ' OR cat_test = ' . ARCADE_CAT_TEST;
							$result = $this->db->sql_query($sql);
							$cat_ignore_ids = array();
							while ($row = $this->db->sql_fetchrow($result))
							{
								$cat_ignore_ids[] = (int) $row['cat_id'];
							}
							$this->db->sql_freeresult($result);

							if ($s_cat_options = $this->arcade->make_cat_select($tour_cats, $cat_ignore_ids, true, true))
							{
								$cats_count = count(explode('</option>', $s_cat_options)) - 1;
							}
						}
						else
						{
							$sql = 'SELECT g.game_id, g.game_name, g.game_name_clean, c.cat_id, c.cat_name
									FROM ' . ARCADE_GAMES_TABLE . ' g, ' . ARCADE_CATS_TABLE . ' c
									WHERE g.cat_id = c.cat_id
									AND c.cat_status = ' . ITEM_UNLOCKED . '
									AND c.cat_test <> ' . ARCADE_CAT_TEST . '
									AND g.game_save_type <> ' . NOSCORE_GAME . '
									ORDER BY c.cat_name ASC, g.game_name_clean ASC';
							$result = $this->db->sql_query($sql);
							while ($row = $this->db->sql_fetchrow($result))
							{
								if ($old_cat != $row['cat_name'])
								{
									$s_game_options .= (($old_cat) ? "</optgroup>\n" : '') . '<optgroup label="' . $row['cat_name'] . '">' . "\n";
									$cats_count++;
								}

								$s_game_options .= '<option' . ((in_array($row['game_id'], $tour_data['tour_games'])) ? ' selected="selected"' : '') . ' value="' . $row['game_id'] . '">&nbsp;&nbsp;&nbsp;&nbsp;' . $row['game_name'] . "</option>\n";

								$old_cat = $row['cat_name'];
								$games_count++;
							}
							$this->db->sql_freeresult($result);

							$s_game_options .= ($s_game_options) ? "</optgroup>\n" : '';
						}

						$sql = 'SELECT group_id, group_name, group_type
								FROM ' . GROUPS_TABLE . "
								WHERE group_name NOT IN ('BOTS', 'GUESTS')
								ORDER BY group_type DESC, group_name ASC";
						$result = $this->db->sql_query($sql);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$s_group_options .= '<option' . (($row['group_type'] == GROUP_SPECIAL) ? ' class="sep"' : '') . ' value="' . $row['group_id'] . '"' . ((in_array($row['group_id'], $tour_data['tour_groups'])) ? ' selected="selected"' : '') . '>' . $group_helper->get_name($row['group_name']) . "</option>\n";
							$groups_count++;
						}
						$this->db->sql_freeresult($result);

						$s_hidden_fields = array(
							'action'	=> $action,
							'tour_id'	=> $tour_id
						);

						$this->template->assign_vars(array(
							'S_TOUR_CREATE'			=> true,
							'S_TOUR_EDIT'			=> ($action == 'edit') ? true : false,
							'S_RAND_CREATE'			=> ($action == 'rand_create') ? true : false,
							'S_TOUR_STARTED'		=> $tour_started,
							'S_CAT_OPTIONS'			=> ($s_cat_options) ? $s_cat_options : '',
							'S_GAME_OPTIONS'		=> $s_game_options,
							'S_GROUPS_OPTIONS'		=> $s_group_options,
							'S_MIN_GAMES'			=> ($this->arcade_config['tour_min_games']) ? sprintf($this->user->lang['ARCADE_MIN_GAMES_SELECTED_EXPLAIN'], $this->arcade->number_format($this->arcade_config['tour_min_games'])) : '',
							'S_MAX_GAMES'			=> ($this->arcade_config['tour_max_games']) ? sprintf($this->user->lang['ARCADE_MAX_GAMES_SELECTED_EXPLAIN'], $this->arcade->number_format($this->arcade_config['tour_max_games'])) : '',
							'S_HIDDEN_FIELDS'		=> build_hidden_fields($s_hidden_fields),
							'S_TOUR_NOT_PLAYED'		=> ($tour_not_played) ? ' checked="checked"' : '',

							'U_CREATE_TOUR'			=> $this->u_action . '&amp;action=' . (($action == 'create') ? 'rand_' : '') . 'create' . (($tour_data['tour_name']) ? '&amp;tour_name=' . $tour_data['tour_name'] : ''),

							'TOUR_MIN_GAMES'		=> intval($this->arcade_config['tour_min_games']),
							'TOUR_MAX_GAMES'		=> intval($this->arcade_config['tour_max_games']),
							'NUM_GAMES'				=> $num_games,
							'NUM_RANDOM_GAMES_EXP'	=> sprintf($this->user->lang['ARCADE_NUM_RANDOM_GAMES_EXPLAIN'], intval($this->arcade_config['tour_min_games']), intval($this->arcade_config['tour_max_games'])),
							'OPTIONS_COUNT'			=> $cats_count + $games_count,
							'CATS_COUNT'			=> $cats_count,
							'GAMES_COUNT'			=> $games_count,
							'GROUPS_COUNT'			=> $groups_count,
							'TOUR_NAME'				=> $tour_data['tour_name'],
							'PLAY_MAX'				=> $tour_data['play_max'],
							'TOUR_STARTTIME'		=> $tour_data['tour_starttime'],
							'TOUR_ENDTIME'			=> $tour_data['tour_endtime']
						));

						if ($this->arcade_config['tour_reward_enable'] && $this->arcade->points->data['show'])
						{
							$this->template->assign_vars(array(
								'S_TOUR_REWARD'	=> true,
								'S_MIN_REWARD'	=> ($this->arcade_config['tour_reward_min'] > 0) ? sprintf($this->user->lang['ARCADE_MIN_REWARD_EXPLAIN'], $this->arcade->number_format($this->arcade_config['tour_reward_min']), $this->arcade->points->data['name']) : '',
								'S_MAX_REWARD'	=> ($this->arcade_config['tour_reward_max'] > 0) ? sprintf($this->user->lang['ARCADE_MAX_REWARD_EXPLAIN'], $this->arcade->number_format($this->arcade_config['tour_reward_max']), $this->arcade->points->data['name']) : '',

								'TOUR_REWARD_1'	=> $this->arcade->number_format($tour_data['reward_1'], true),
								'TOUR_REWARD_2'	=> $this->arcade->number_format($tour_data['reward_2'], true),
								'TOUR_REWARD_3'	=> $this->arcade->number_format($tour_data['reward_3'], true)
							));
						}
					break;

					case 'delete':
						if (!$tour_id)
						{
							$action = '';
							break;
						}

						if (confirm_box(true))
						{
							$sql = 'SELECT *
									FROM ' . ARCADE_TOUR_TABLE . "
									WHERE tour_id = $tour_id";
							$result = $this->db->sql_query($sql);
							$tour_data = $this->db->sql_fetchrow($result);
							$this->db->sql_freeresult($result);

							if (!$tour_data)
							{
								$action = '';
								break;
							}

							$this->arcade->delete_tour_data($tour_id, $tour_data['topic_id']);
							$this->arcade->sync('total_data', 'tour');
							$this->arcade->cache_purge();

							$this->arcade->add_log('admin', 'LOG_ARCADE_TOUR_DELETE', $tour_data['tour_name']);
							trigger_error($this->user->lang['ARCADE_TOUR_DELETE_SUCCESS'] . adm_back_link($this->u_action . (($end_tour) ? '&amp;end_tour=true' : '')));
						}
						else
						{
							$s_hidden_fields = array(
								'action'	=> $action,
								'tour_id'	=> $tour_id
							);

							confirm_box(false, 'ARCADE_TOUR_DELETE', build_hidden_fields($s_hidden_fields));
						}

						$action = '';
					break;
				}

				if (!$action)
				{
					if ($total_tours = $this->arcade->get->total('game', 'total_tours', $end_tour))
					{
						$sql = 'SELECT *
								FROM ' . ARCADE_TOUR_TABLE . '
								WHERE tour_status ' . (($end_tour) ? '=' : '<>') . ' ' . ARCADE_END_TOUR . '
								ORDER BY tour_time DESC, tour_id DESC';
						$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$url = $this->u_action . "&amp;tour_id={$row['tour_id']}";

							$this->template->assign_block_vars('tours', array(
								'NAME'				=> $row['tour_name'],
								'CREATE_TIME'		=> $this->user->format_date($row['tour_time'], false, true),

								'L_STATUS'			=> $this->user->lang['ARCADE_' . (($row['tour_status'] == ARCADE_WAIT_TOUR) ? 'WAIT' : 'ONGOING')],

								'U_EDIT'			=> $url . '&amp;action=edit',
								'U_DELETE'			=> $url . '&amp;action=delete' . (($end_tour) ? '&amp;end_tour=true' : '')
							));
						}
						$this->db->sql_freeresult($result);

						$pagination->generate_template_pagination($this->u_action . (($end_tour) ? '&amp;end_tour=true' : ''), 'pagination', 'start', $total_tours, $this->arcade_config['acp_items_per_page'], $start);
					}
				}

				$this->template->assign_vars(array(
					'S_TOUR_DELETE'		=> ($this->auth->acl_get('a_arcade_delete_tour')) ? true : false,
					'S_ARCADE_EX_TOUR'	=> (count($this->arcade->tours) > 0) ? true : false,
					'S_FINISHED_TOUR'	=> $end_tour,

					'U_ACTION'			=> $this->u_action,

					'FOLDER_IMAGE'		=> '<img src="' . $this->admin_path . 'images/icon_folder.gif" alt="' . $this->user->lang['TOURNAMENT'] . '" title="' . $this->user->lang['TOURNAMENT'] . '">'
				));
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		if (count($errors))
		{
			$this->template->assign_vars(array(
				'S_ERROR'	=> true,
				'ERROR_MSG'	=> implode('<br>', $errors)
			));
		}

		$this->template->assign_vars(array(
			'S_GAME_DELETE'			=> ($this->auth->acl_get('a_arcade_delete_game')) ? true : false,
			'S_GAME_EDIT'			=> ($this->auth->acl_get('a_arcade_game')) ? true : false,
			'S_DISPLAY_GAME_IMAGES'	=> ($this->arcade_config['display_game_image'] && $this->arcade->optionget('view_game_image')) ? true : false,

			'L_TITLE'				=> (!empty($l_title)) ? $l_title : '',
			'L_TITLE_EXPLAIN'		=> (!empty($l_title_explain)) ? $l_title_explain : ''
		));
	}

	public function cat_display_select($value = 0)
	{
		$option_ary = array(
			ARCADE_CAT_DISPLAY_BOTH	 => 'ARCADE_CAT_DISPLAY_BOTH',
			ARCADE_CAT_DISPLAY_NAME	 => 'ARCADE_CAT_DISPLAY_NAME',
			ARCADE_CAT_DISPLAY_IMAGE => 'ARCADE_CAT_DISPLAY_IMAGE'
		);

		return $this->arcade->build_select($option_ary, $value);
	}

	public function auto_reset_score_type($value = 0)
	{
		$option_ary = array(
			0 => '----------------',
			1 => 'ARCADE_RESET_DATE_MONTH',
			2 => 'ARCADE_RESET_DATE_QUARTER_YEAR',
			3 => 'ARCADE_RESET_DATE_HALF_YEAR',
			4 => 'ARCADE_RESET_DATE_YEAR'
		);

		return $this->arcade->build_select($option_ary, $value);
	}

	/**
	* Update category data
	*/
	public function update_cat_data(&$cat_data)
	{
		$errors = array();

		if ($v = $this->arcade->validate_data('string', 'CAT_NAME', $cat_data['cat_name'], 3, 255))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('string', 'ARCADE_CAT_DESC', $cat_data['cat_desc'], 0, 4000))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('string', 'CAT_RULES', $cat_data['cat_rules'], 0, 4000))
		{
			$errors[] = $v;
		}

		if ($cat_data['cat_password'] || $cat_data['cat_password_confirm'])
		{
			if ($cat_data['cat_password'] != $cat_data['cat_password_confirm'])
			{
				$cat_data['cat_password'] = $cat_data['cat_password_confirm'] = '';
				$errors[] = $this->user->lang['CAT_PASSWORD_MISMATCH'];
			}
		}

		if ($v = $this->arcade->validate_data('int', 'CAT_AGE', $cat_data['cat_age'], 0, 100))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('int', 'CAT_GAMES_PAGE', $cat_data['cat_games_per_page'], 0, 100))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('float', 'CAT_DOWNLOAD_COST', $cat_data['cat_download_cost'], -1))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('float', 'CAT_COST', $cat_data['cat_cost'], -1))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('float', 'CAT_REWARD', $cat_data['cat_reward'], -1))
		{
			$errors[] = $v;
		}

		// Set category flags
		// 1 = link tracking
		$cat_data['cat_flags'] = 0;
		$cat_data['cat_flags'] += ($cat_data['cat_link_track']) ? ARCADE_FLAG_LINK_TRACK : 0;

		// Unset data that are not database fields
		$cat_data_sql = $cat_data;

		unset($cat_data_sql['cat_link_track']);
		unset($cat_data_sql['cat_password_confirm']);

		// What are we going to do tonight Brain? The same thing we do every night,
		// try to take over the world ... or decide whether to continue update
		// and if so, whether it's a new category/cat/link or an existing one
		if (count($errors))
		{
			return $errors;
		}

		// As we don't know the old password, it's kinda tricky to detect changes
		if ($cat_data_sql['cat_password_unset'])
		{
			$cat_data_sql['cat_password'] = '';
		}
		else if (empty($cat_data_sql['cat_password']))
		{
			unset($cat_data_sql['cat_password']);
		}
		else
		{
			$cat_data_sql['cat_password'] = phpbb_hash($cat_data_sql['cat_password']);
		}
		unset($cat_data_sql['cat_password_unset']);

		if (!isset($cat_data_sql['cat_id']))
		{
			// no cat_id means we're creating a new category
			unset($cat_data_sql['type_action']);

			if ($cat_data_sql['parent_id'])
			{
				$sql = 'SELECT left_id, right_id, cat_type
						FROM ' . ARCADE_CATS_TABLE . '
						WHERE cat_id = ' . $cat_data_sql['parent_id'];
				$result = $this->db->sql_query($sql);
				$row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				if (!$row)
				{
					trigger_error($this->user->lang['ARCADE_PARENT_NOT_EXIST'] . adm_back_link($this->u_action . '&amp;' . $this->parent_id), E_USER_WARNING);
				}

				if ($row['cat_type'] == ARCADE_LINK)
				{
					$errors[] = $this->user->lang['PARENT_IS_LINK_ARCADE'];
					return $errors;
				}

				$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
						SET left_id = left_id + 2, right_id = right_id + 2
						WHERE left_id > ' . $row['right_id'];
				$this->db->sql_query($sql);

				$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
						SET right_id = right_id + 2
						WHERE ' . $row['left_id'] . ' BETWEEN left_id AND right_id';
				$this->db->sql_query($sql);

				$cat_data_sql['left_id'] = $row['right_id'];
				$cat_data_sql['right_id'] = $row['right_id'] + 1;
			}
			else
			{
				$sql = 'SELECT MAX(right_id) AS right_id
						FROM ' . ARCADE_CATS_TABLE;
				$result = $this->db->sql_query($sql);
				$row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				$cat_data_sql['left_id'] = $row['right_id'] + 1;
				$cat_data_sql['right_id'] = $row['right_id'] + 2;
			}

			$this->db->sql_query('INSERT INTO ' . ARCADE_CATS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $cat_data_sql));

			$cat_data['cat_id'] = $this->db->sql_nextid();

			$this->arcade->add_log('admin', 'LOG_ARCADE_ADD_CAT', $cat_data['cat_name']);
		}
		else
		{
			$row = $this->arcade->get_cat_info($cat_data_sql['cat_id']);

			if ($row['cat_type'] == ARCADE_CAT_GAMES && $row['cat_type'] != $cat_data_sql['cat_type'])
			{
				// Has subcategories and want to change into a link?
				if ($row['right_id'] - $row['left_id'] > 1 && $cat_data_sql['cat_type'] == ARCADE_LINK)
				{
					$errors[] = $this->user->lang['CAT_WITH_SUBCATS_NOT_TO_LINK'];
					return $errors;
				}

				// we're turning a postable category into a non-postable category
				if ($cat_data_sql['type_action'] == 'move')
				{
					$to_cat_id = (int) $this->request->variable('to_cat_id', 0);

					if ($to_cat_id)
					{
						$errors = $this->move_cat_content($cat_data_sql['cat_id'], $to_cat_id);
					}
					else
					{
						return array($this->user->lang['NO_DESTINATION_CAT']);
					}
				}
				else if ($cat_data_sql['type_action'] == 'delete')
				{
					$errors = $this->delete_cat_content($cat_data_sql['cat_id']);
				}
				else
				{
					return array($this->user->lang['NO_CAT_ACTION']);
				}

				$cat_data_sql['cat_games'] = $cat_data_sql['cat_plays'] = $cat_data_sql['cat_last_play_game_id'] = $cat_data_sql['cat_last_game_installdate'] = $cat_data_sql['cat_last_play_user_id'] = $cat_data_sql['cat_last_play_score'] = $cat_data_sql['cat_last_play_time'] = 0;
				$cat_data_sql['cat_last_play_game_name'] = $cat_data_sql['cat_last_play_username'] = $cat_data_sql['cat_last_play_user_colour'] = '';
			}
			else if ($row['cat_type'] == ARCADE_CAT && $cat_data_sql['cat_type'] == ARCADE_LINK)
			{
				// Has subcategories?
				if ($row['right_id'] - $row['left_id'] > 1)
				{
					// We are turning a category into a link - but need to decide what to do with the subcategories.
					$action_subcats = $this->request->variable('action_subcats', '');
					$subcats_to_id = (int) $this->request->variable('subcats_to_id', 0);

					if ($action_subcats == 'delete')
					{
						$rows = $this->arcade->get_cat_branch($row['cat_id'], 'children', 'descending', false);

						foreach ($rows as $_row)
						{
							// Do not remove the category id we are about to change. ;)
							if ($_row['cat_id'] == $row['cat_id'])
							{
								continue;
							}

							$cat_ids[] = $_row['cat_id'];
							$errors = array_merge($errors, $this->delete_cat_content($_row['cat_id']));
						}

						if (count($errors))
						{
							return $errors;
						}

						if (count($cat_ids))
						{
							$sql = 'DELETE FROM ' . ARCADE_CATS_TABLE . '
									WHERE ' . $this->db->sql_in_set('cat_id', $cat_ids);
							$this->db->sql_query($sql);

							$sql = 'DELETE FROM ' . ACL_ARCADE_GROUPS_TABLE . '
									WHERE ' . $this->db->sql_in_set('cat_id', $cat_ids);
							$this->db->sql_query($sql);

							$sql = 'DELETE FROM ' . ACL_ARCADE_USERS_TABLE . '
									WHERE ' . $this->db->sql_in_set('cat_id', $cat_ids);
							$this->db->sql_query($sql);
						}
					}
					else if ($action_subcats == 'move')
					{
						if (!$subcats_to_id)
						{
							return array($this->user->lang['NO_DESTINATION_CAT']);
						}

						$sql = 'SELECT cat_name
								FROM ' . ARCADE_CATS_TABLE . '
								WHERE cat_id = ' . $subcats_to_id;
						$result = $this->db->sql_query($sql);
						$_row = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);

						if (!$_row)
						{
							return array($this->user->lang['NO_CAT_ID']);
						}

						$subcats_to_name = $_row['cat_name'];

						$sql = 'SELECT cat_id
								FROM ' . ARCADE_CATS_TABLE . "
								WHERE parent_id = {$row['cat_id']}";
						$result = $this->db->sql_query($sql);

						while ($_row = $this->db->sql_fetchrow($result))
						{
							$this->move_cat($_row['cat_id'], $subcats_to_id);
						}
						$this->db->sql_freeresult($result);

						$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
								SET parent_id = $subcats_to_id
								WHERE parent_id = {$row['cat_id']}";
						$this->db->sql_query($sql);
					}

					// Adjust the left/right id
					$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
							SET right_id = left_id + 1
							WHERE cat_id = ' . $row['cat_id'];
					$this->db->sql_query($sql);
				}
			}
			else if ($row['cat_type'] == ARCADE_CAT && $cat_data_sql['cat_type'] == ARCADE_CAT_GAMES)
			{
				// Changing a category to a category? Reset the data (you can't post directly in a cat, you must use a category)
				$cat_data_sql['cat_games'] = 0;
				$cat_data_sql['cat_plays'] = 0;
				$cat_data_sql['cat_last_play_game_id'] = 0;
				$cat_data_sql['cat_last_play_game_name'] = '';
				$cat_data_sql['cat_last_game_installdate'] = 0;
				$cat_data_sql['cat_last_play_user_id'] = 0;
				$cat_data_sql['cat_last_play_score'] = 0;
				$cat_data_sql['cat_last_play_time'] = 0;
				$cat_data_sql['cat_last_play_username'] = '';
				$cat_data_sql['cat_last_play_user_colour'] = '';
			}

			if (count($errors))
			{
				return $errors;
			}

			if ($row['parent_id'] != $cat_data_sql['parent_id'])
			{
				if ($row['cat_id'] != $cat_data_sql['parent_id'])
				{
					$errors = $this->move_cat($cat_data_sql['cat_id'], $cat_data_sql['parent_id']);
				}
				else
				{
					$cat_data_sql['parent_id'] = $row['parent_id'];
				}
			}

			if (count($errors))
			{
				return $errors;
			}

			unset($cat_data_sql['type_action']);

			if ($row['cat_name'] != $cat_data_sql['cat_name'])
			{
				// the category name has changed, clear the parents list of all categories (for safety)
				$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
						SET cat_parents = ''";
				$this->db->sql_query($sql);
			}

			// Setting the category id to the category id is not really received well by some dbs. ;)
			$cat_id = $cat_data_sql['cat_id'];
			unset($cat_data_sql['cat_id']);

			$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
					SET ' . $this->db->sql_build_array('UPDATE', $cat_data_sql) . '
					WHERE cat_id = ' . (int) $cat_id;
			$this->db->sql_query($sql);

			// Add it back
			$cat_data['cat_id'] = (int) $cat_id;

			$this->arcade->add_log('admin', 'LOG_ARCADE_CAT_EDIT', $cat_data['cat_name']);
		}

		return $errors;
	}

	/**
	* Move category
	*/
	public function move_cat($from_id, $to_id)
	{
		$to_data = $moved_ids = $errors = array();

		// Check if we want to move to a parent with link type
		if ($to_id > 0)
		{
			$to_data = $this->arcade->get_cat_info($to_id);

			if ($to_data['cat_type'] == ARCADE_LINK)
			{
				$errors[] = $this->user->lang['PARENT_IS_LINK_ARCADE'];
				return $errors;
			}
		}

		$moved_categories = $this->arcade->get_cat_branch($from_id, 'children');
		$from_data = $moved_categories[0];
		$diff = count($moved_categories) * 2;

		for ($i = 0; $i < count($moved_categories); ++$i)
		{
			$moved_ids[] = (int) $moved_categories[$i]['cat_id'];
		}

		// Resync parents
		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
				SET right_id = right_id - $diff, cat_parents = ''
				WHERE left_id < " . (int) $from_data['right_id'] . "
				AND right_id > " . (int) $from_data['right_id'];
		$this->db->sql_query($sql);

		// Resync righthand side of tree
		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
				SET left_id = left_id - $diff, right_id = right_id - $diff, cat_parents = ''
				WHERE left_id > " . (int) $from_data['right_id'];
		$this->db->sql_query($sql);

		if ($to_id > 0)
		{
			// Retrieve $to_data again, it may have been changed...
			$to_data = $this->arcade->get_cat_info($to_id);

			// Resync new parents
			$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
					SET right_id = right_id + $diff, cat_parents = ''
					WHERE " . $to_data['right_id'] . ' BETWEEN left_id AND right_id
					AND ' . $this->db->sql_in_set('cat_id', $moved_ids, true);
			$this->db->sql_query($sql);

			// Resync the righthand side of the tree
			$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
					SET left_id = left_id + $diff, right_id = right_id + $diff, cat_parents = ''
					WHERE left_id > " . $to_data['right_id'] . '
					AND ' . $this->db->sql_in_set('cat_id', $moved_ids, true);
			$this->db->sql_query($sql);

			// Resync moved branch
			$to_data['right_id'] += $diff;

			if ($to_data['right_id'] > $from_data['right_id'])
			{
				$diff = '+ ' . ($to_data['right_id'] - $from_data['right_id'] - 1);
			}
			else
			{
				$diff = '- ' . abs($to_data['right_id'] - $from_data['right_id'] - 1);
			}
		}
		else
		{
			$sql = 'SELECT MAX(right_id) AS right_id
					FROM ' . ARCADE_CATS_TABLE . '
					WHERE ' . $this->db->sql_in_set('cat_id', $moved_ids, true);
			$result = $this->db->sql_query($sql);
			$row = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			$diff = '+ ' . ($row['right_id'] - $from_data['left_id'] + 1);
		}

		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
				SET left_id = left_id $diff, right_id = right_id $diff, cat_parents = ''
				WHERE " . $this->db->sql_in_set('cat_id', $moved_ids);
		$this->db->sql_query($sql);

		return $errors;
	}

	/**
	* Move category content from one to another category
	*/
	public function move_cat_content($from_id, $to_id, $sync = true)
	{
		$table_ary = array(ARCADE_GAMES_TABLE);

		foreach ($table_ary as $table)
		{
			$sql = "UPDATE $table
					SET cat_id = $to_id
					WHERE cat_id = $from_id";
			$this->db->sql_query($sql);
		}
		unset($table_ary);

		if ($sync)
		{
			// Sync total games and plays for the categories...
			$this->arcade->sync('category');
		}
		return array();
	}

	/**
	* Remove complete category
	*/
	public function delete_cat($cat_id, $action_games = 'delete', $action_subcats = 'delete', $games_to_id = 0, $subcats_to_id = 0)
	{
		$cat_data = $this->arcade->get_cat_info($cat_id);

		$errors = array();
		$log_action_games = $log_action_cats = $games_to_name = $subcats_to_name = '';
		$cat_ids = array($cat_id);

		if ($action_games == 'delete')
		{
			$log_action_games = 'GAMES';
			$errors = array_merge($errors, $this->delete_cat_content($cat_id));
		}
		else if ($action_games == 'move')
		{
			if (!$games_to_id)
			{
				$errors[] = $this->user->lang['NO_DESTINATION_CAT'];
			}
			else
			{
				$log_action_games = 'MOVE_GAMES';

				$sql = 'SELECT cat_name
						FROM ' . ARCADE_CATS_TABLE . '
						WHERE cat_id = ' . $games_to_id;
				$result = $this->db->sql_query($sql);
				$row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				if (!$row)
				{
					$errors[] = $this->user->lang['NO_CAT_ID'];
				}
				else
				{
					$posts_to_name = $row['cat_name'];
					$errors = array_merge($errors, $this->move_cat_content($cat_id, $games_to_id));
				}
			}
		}

		if (count($errors))
		{
			return $errors;
		}

		if ($action_subcats == 'delete')
		{
			$log_action_cats = 'CATS';
			$rows = $this->arcade->get_cat_branch($cat_id, 'children', 'descending', false);

			foreach ($rows as $row)
			{
				$cat_ids[] = $row['cat_id'];
				$errors = array_merge($errors, $this->delete_cat_content($row['cat_id']));
			}

			if (count($errors))
			{
				return $errors;
			}

			$diff = count($cat_ids) * 2;

			$sql = 'DELETE FROM ' . ARCADE_CATS_TABLE . '
					WHERE ' . $this->db->sql_in_set('cat_id', $cat_ids);
			$this->db->sql_query($sql);

			$sql = 'DELETE FROM ' . ACL_ARCADE_GROUPS_TABLE . '
					WHERE ' . $this->db->sql_in_set('cat_id', $cat_ids);
			$this->db->sql_query($sql);

			$sql = 'DELETE FROM ' . ACL_ARCADE_USERS_TABLE . '
					WHERE ' . $this->db->sql_in_set('cat_id', $cat_ids);
			$this->db->sql_query($sql);
		}
		else if ($action_subcats == 'move')
		{
			if (!$subcats_to_id)
			{
				$errors[] = $this->user->lang['NO_DESTINATION_CAT'];
			}
			else
			{
				$log_action_cats = 'MOVE_CATS';

				$sql = 'SELECT cat_name
						FROM ' . ARCADE_CATS_TABLE . '
						WHERE cat_id = ' . $subcats_to_id;
				$result = $this->db->sql_query($sql);
				$row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				if (!$row)
				{
					$errors[] = $this->user->lang['NO_CAT_ID'];
				}
				else
				{
					$subcats_to_name = $row['cat_name'];

					$sql = 'SELECT cat_id
							FROM ' . ARCADE_CATS_TABLE . "
							WHERE parent_id = $cat_id";
					$result = $this->db->sql_query($sql);

					while ($row = $this->db->sql_fetchrow($result))
					{
						$this->move_cat($row['cat_id'], $subcats_to_id);
					}
					$this->db->sql_freeresult($result);

					// Grab new category data for correct tree updating later
					$cat_data = $this->arcade->get_cat_info($cat_id);

					$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
							SET parent_id = $subcats_to_id
							WHERE parent_id = $cat_id";
					$this->db->sql_query($sql);

					$diff = 2;
					$sql = 'DELETE FROM ' . ARCADE_CATS_TABLE . "
							WHERE cat_id = $cat_id";
					$this->db->sql_query($sql);

					$sql = 'DELETE FROM ' . ACL_ARCADE_GROUPS_TABLE . "
							WHERE cat_id = $cat_id";
					$this->db->sql_query($sql);

					$sql = 'DELETE FROM ' . ACL_ARCADE_USERS_TABLE . "
							WHERE cat_id = $cat_id";
					$this->db->sql_query($sql);
				}
			}

			if (count($errors))
			{
				return $errors;
			}
		}
		else
		{
			$diff = 2;
			$sql = 'DELETE FROM ' . ARCADE_CATS_TABLE . "
					WHERE cat_id = $cat_id";
			$this->db->sql_query($sql);

			$sql = 'DELETE FROM ' . ACL_ARCADE_GROUPS_TABLE . "
					WHERE cat_id = $cat_id";
			$this->db->sql_query($sql);

			$sql = 'DELETE FROM ' . ACL_ARCADE_USERS_TABLE . "
					WHERE cat_id = $cat_id";
			$this->db->sql_query($sql);
		}

		// Resync tree
		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
				SET right_id = right_id - $diff
				WHERE left_id < {$cat_data['right_id']} AND right_id > {$cat_data['right_id']}";
		$this->db->sql_query($sql);

		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
				SET left_id = left_id - $diff, right_id = right_id - $diff
				WHERE left_id > {$cat_data['right_id']}";
		$this->db->sql_query($sql);

		$log_action = implode('_', array($log_action_games, $log_action_cats));

		switch ($log_action)
		{
			case 'MOVE_GAMES_MOVE_CATS':
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_MOVE_GAMES_MOVE_CATS', $posts_to_name, $subcats_to_name, $cat_data['cat_name']);
			break;

			case 'MOVE_GAMES_CATS':
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_MOVE_GAMES_CATS', $posts_to_name, $cat_data['cat_name']);
			break;

			case 'GAMES_MOVE_CATS':
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_GAMES_MOVE_CATS', $subcats_to_name, $cat_data['cat_name']);
			break;

			case '_MOVE_CATS':
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_MOVE_CATS', $subcats_to_name, $cat_data['cat_name']);
			break;

			case 'MOVE_GAMES_':
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_MOVE_GAMES', $posts_to_name, $cat_data['cat_name']);
			break;

			case 'GAMES_CATS':
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_GAMES_CATS', $cat_data['cat_name']);
			break;

			case '_CATS':
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_CATS', $cat_data['cat_name']);
			break;

			case 'GAMES_':
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_GAMES', $cat_data['cat_name']);
			break;

			default:
				$this->arcade->add_log('admin', 'LOG_ARCADE_DEL_CAT', $cat_data['cat_name']);
			break;
		}

		return $errors;
	}

	/**
	* Delete category content
	*/
	public function delete_cat_content($cat_id)
	{
		$errors = $game_ids = array();

		if (!$cat_id)
		{
			$errors[] = $this->user->lang['NO_CAT_ID'];
		}

		if (count($errors))
		{
			return $errors;
		}

		$sql = 'SELECT game_id
				FROM ' . ARCADE_GAMES_TABLE . '
				WHERE cat_id = ' . (int) $cat_id;
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$game_ids[] = (int) $row['game_id'];
		}
		$this->db->sql_freeresult($result);

		if (count($game_ids))
		{
			$game_data = $this->arcade->delete_game($game_ids, $errors, $this->delete_reason);
		}

		return $errors;
	}

	/**
	* Move category position by $steps up/down
	*/
	public function move_cat_by($cat_row, $action = 'move_up', $steps = 1)
	{
		/**
		* Fetch all the siblings between the module's current spot
		* and where we want to move it to. If there are less than $steps
		* siblings between the current spot and the target then the
		* module will move as far as possible
		*/
		$sql = 'SELECT cat_id, cat_name, left_id, right_id
				FROM ' . ARCADE_CATS_TABLE . "
				WHERE parent_id = {$cat_row['parent_id']}
				AND " . (($action == 'move_up') ? "right_id < {$cat_row['right_id']} ORDER BY right_id DESC" : "left_id > {$cat_row['left_id']} ORDER BY left_id ASC");
		$result = $this->db->sql_query_limit($sql, $steps);

		$target = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$target = $row;
		}
		$this->db->sql_freeresult($result);

		if (!count($target))
		{
			// The category is already on top or bottom
			return false;
		}

		/**
		* $left_id and $right_id define the scope of the nodes that are affected by the move.
		* $diff_up and $diff_down are the values to substract or add to each node's left_id
		* and right_id in order to move them up or down.
		* $move_up_left and $move_up_right define the scope of the nodes that are moving
		* up. Other nodes in the scope of ($left_id, $right_id) are considered to move down.
		*/
		if ($action == 'move_up')
		{
			$left_id = $target['left_id'];
			$right_id = $cat_row['right_id'];

			$diff_up = $cat_row['left_id'] - $target['left_id'];
			$diff_down = $cat_row['right_id'] + 1 - $cat_row['left_id'];

			$move_up_left = $cat_row['left_id'];
			$move_up_right = $cat_row['right_id'];
		}
		else
		{
			$left_id = $cat_row['left_id'];
			$right_id = $target['right_id'];

			$diff_up = $cat_row['right_id'] + 1 - $cat_row['left_id'];
			$diff_down = $target['right_id'] - $cat_row['right_id'];

			$move_up_left = $cat_row['right_id'] + 1;
			$move_up_right = $target['right_id'];
		}

		// Now do the dirty job
		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
				SET left_id = left_id + CASE
				WHEN left_id BETWEEN {$move_up_left} AND {$move_up_right} THEN -{$diff_up}
				ELSE {$diff_down}
				END,
				right_id = right_id + CASE
				WHEN right_id BETWEEN {$move_up_left} AND {$move_up_right} THEN -{$diff_up}
				ELSE {$diff_down}
				END,
				cat_parents = ''
				WHERE
				left_id BETWEEN {$left_id} AND {$right_id}
				AND right_id BETWEEN {$left_id} AND {$right_id}";
		$this->db->sql_query($sql);

		return $target['cat_name'];
	}

	public function get_type_game_ids($type, $id, $gametypev3 = false, $gametypev32 = false)
	{
		$sql_in_set = false;
		$gsv = $game_datas = array();

		switch ($type)
		{
			case 'type':
				$sql_in_set = $this->db->sql_in_set('g.game_type', $id);
			break;

			case 'save_type':
				if ($id == IBPROV3_GAME && (($gametypev3 && !$gametypev32) || (!$gametypev3 && $gametypev32)))
				{
					if ($gamedata = scandir($this->root_path . 'arcade/gamedata/'))
					{
						foreach ($gamedata as $game_folder)
						{
							$dir = $this->root_path . 'arcade/gamedata/' . $game_folder;
							if (is_file($dir) || in_array($game_folder, array('.', '..')))
							{
								continue;
							}
							else if (file_exists($dir . '/') && $game = scandir($dir . '/'))
							{
								foreach ($game as $file)
								{
									if (!is_file($dir . '/' . $file) || in_array($file, array('.', '..')))
									{
										continue;
									}
									else if (($gametypev3 && $file == 'v3game.txt') || ($gametypev32 && $file == 'v32game.txt'))
									{
										$gsv[] = $game_folder;
									}
								}
							}
						}

						$gsv = array_unique($gsv);
					}

					if (count($gsv))
					{
						$sql_in_set = $this->db->sql_in_set('g.game_scorevar', $gsv);
					}
				}
				else
				{
					$sql_in_set = $this->db->sql_in_set('g.game_save_type', $id);
				}
			break;

			case 'cat':
				$sql_in_set = $this->db->sql_in_set('g.cat_id', $id);
			break;
		}

		if ($sql_in_set == false)
		{
			return false;
		}

		$sql_array = array(
			'SELECT'	=> 'g.game_id',
			'FROM'		=> array(ARCADE_GAMES_TABLE	=> 'g'),
			'WHERE'		=> $sql_in_set
		);
		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$game_ids = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$game_ids[] = (int) $row['game_id'];
		}
		$this->db->sql_freeresult($result);

		return (count($game_ids)) ? $game_ids : false;
	}

	public function game_control($value, $key = '')
	{
		return '<select id="' . $key . '" name="config[' . $key . ']">' . $this->arcade->game_control_select($value) . '</select>
				<textarea id="game_control_desc" name="config[game_control_desc]" rows="5" cols="25">' . $this->new_game_data['game_control_desc'] . '</textarea>';
	}

	public function game_swf($value)
	{
		return $this->file_functions->remove_extension($value);
	}

	public function game_installdate($value)
	{
		return $this->user->format_date($value);
	}

	public function game_filesize($value)
	{
		return get_formatted_filesize($value);
	}

	public function game_type_select($value)
	{
		return $this->arcade->game_type_select($value);
	}

	public function game_save_type_select($value)
	{
		return $this->arcade->game_save_type_select($value);
	}

	public function game_scoretype_select($value)
	{
		return $this->arcade->game_scoretype_select($value);
	}

	public function game_cat_select($value)
	{
		return $this->arcade->make_cat_select($value, false, true, true);
	}
}
