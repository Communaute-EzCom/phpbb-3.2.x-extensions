<?php
/**
*
* @package phpBB Arcade
* @version $Id: settings_info.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class settings_info
{
	function module()
	{
		return array(
			'filename'			=> '\jv\arcade\acp\settings_module',
			'title'				=> 'ACP_ARCADE_SETTINGS',
			'modes'				=> array(
				'settings'		=> array('title' => 'ACP_ARCADE_SETTINGS_GENERAL'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'game'			=> array('title' => 'ACP_ARCADE_SETTINGS_GAME'			, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'challenge'		=> array('title' => 'ACP_ARCADE_SETTINGS_CHALLENGE'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'tournament'	=> array('title' => 'ACP_ARCADE_SETTINGS_TOUR'			, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'feature'		=> array('title' => 'ACP_ARCADE_SETTINGS_FEATURE'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'page'			=> array('title' => 'ACP_ARCADE_SETTINGS_PAGE'			, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS'), 'after' => 'ACP_ARCADE_SETTINGS_FEATURE'),
				'path'			=> array('title' => 'ACP_ARCADE_SETTINGS_PATH'			, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'load'			=> array('title' => 'ACP_ARCADE_SETTINGS_LOAD'			, 'auth' => 'ext_jv/arcade && acl_a_arcade && acl_a_arcade_settings', 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'paar'			=> array('title' => 'ACP_ARCADE_SETTINGS_PAAR'			, 'auth' => 'ext_jv/arcade && acl_a_arcade && acl_a_arcade_settings', 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
			)
		);
	}
}
