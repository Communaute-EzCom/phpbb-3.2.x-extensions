<?php
/**
*
* @package phpBB Arcade
* @version $Id: settings_module.php 2132 2019-01-03 16:09:12Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class settings_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	private $new_config = array();

	protected $admin_path;
	protected $db, $config, $auth, $request, $user, $template, $root_path, $php_ext;
	protected $arcade_config, $arcade;

	public function __construct()
	{
		global $phpbb_admin_path;
		global $db, $config, $auth, $request, $user, $template, $phpbb_root_path, $phpEx;
		global $arcade_config, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->admin_path = $phpbb_admin_path;
		$this->db = $db;
		$this->config = $config;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	public function main($id, $mode)
	{
		$form_key = 'acp_arcade';
		add_form_key($form_key);

		$purge_cache = false;
		$this->user->add_lang('acp/board');
		$submit = $this->arcade->is_post_empty('submit');

		switch ($mode)
		{
			case 'settings':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_GENERAL',
						'vars'	=> array(
							'legend1'							=> 'ACP_ARCADE_SETTINGS_GENERAL',
							'arcade_disable'					=> array('lang' => 'DISABLE_ARCADE',						'validate' => 'bool',			'type' => 'custom',					'explain'	=> true,	'method' => 'arcade_disable'),
							'arcade_disable_msg'				=> false,
							'auto_disable'						=> array('lang' => 'ARCADE_AUTO_DISABLE',					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'auto_disable_start'				=> array('lang' => 'ARCADE_AUTO_DISABLE_START',				'validate' => 'string',			'type' => 'text:6:5',				'explain'	=> true),
							'auto_disable_end'					=> array('lang' => 'ARCADE_AUTO_DISABLE_END',				'validate' => 'string',			'type' => 'text:6:5',				'explain'	=> true),
							'default_style'						=> array('lang' => 'ARCADE_DEFAULT_STYLE',					'validate' => 'int',			'type' => 'select',					'explain'	=> true,	'method' => 'arcade_default_style'),
							'display_header'					=> array('lang' => 'ARCADE_DISPLAY_HEADER',					'validate' => 'int:1',			'type' => 'select',					'explain'	=> true,	'method' => 'display_page'),

							'legend2'							=> 'GENERAL_SETTINGS',
							'arcade_rank'						=> array('lang' => 'ACP_ARCADE_DISPLAY_ARCADE_RANK',		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'forum_rank'						=> array('lang' => 'ACP_ARCADE_DISPLAY_FORUM_RANK',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'display_game_image'				=> array('lang' => 'ARCADE_DISPLAY_GAME_IMAGE',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'enable_image_link'					=> array('lang' => 'ARCADE_ENABLE_IMAGE_LINK',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'watermark_game_img'				=> array('lang' => 'ARCADE_WATERMARK_GAME_IMAGE_ENABLE',	'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'watermark_min_size'				=> array('lang' => 'ARCADE_WATERMARK_MIN_GAME_IMAGE_SIZE',	'validate' => 'int:45',			'type' => 'number:45:500',			'explain'	=> true,	'append' => ' ' . $this->user->lang['PIXEL']),
							'display_game_popup_icon'			=> array('lang' => 'ARCADE_DISPLAY_GAME_POPUP_ICON',		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'game_popup_icon_size'				=> array('lang' => 'ARCADE_GAME_POPUP_ICON_SIZE',			'validate' => 'int:15:20',		'type' => 'number:15:20',			'explain'	=> true,	'append' => ' ' . $this->user->lang['PIXEL']),
							'display_user_avatar'				=> array('lang' => 'ARCADE_DISPLAY_USER_AVATAR',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'enable_user_avatar_link'			=> array('lang' => 'ARCADE_ENABLE_USER_AVATAR_LINK',		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'gamename_maxchars'					=> array('lang' => 'ARCADE_GAMENAME_MAXCHARS',				'validate' => 'int:0:50',		'type' => 'number:0:50',			'explain'	=> true),
							'smilies_popup_width'				=> array('lang' => 'ARCADE_SMILIES_POPUP_WIDTH',			'validate' => 'int:200:1000',	'type' => 'number:200:1000',		'explain'	=> false,	'append' => ' ' . $this->user->lang['PIXEL']),
							'smilies_popup_height'				=> array('lang' => 'ARCADE_SMILIES_POPUP_HEIGHT',			'validate' => 'int:200:1000',	'type' => 'number:200:1000',		'explain'	=> false,	'append' => ' ' . $this->user->lang['PIXEL']),
							'ban_user_ip'						=> array('lang' => 'ARCADE_BANNED_USER_IP_CHECK', 			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'random_games'						=> array('lang' => 'ARCADE_RANDOM_ENABLE', 					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'random_challenge'					=> array('lang' => 'ARCADE_CHALLANGE_RANDOM_ENABLE', 		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'game_comment'						=> array('lang' => 'ARCADE_GAME_COMMENT_ENABLED', 			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'parse_bbcode'						=> array('lang' => 'ARCADE_COMMENTS_BBCODE', 				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'parse_smilies'						=> array('lang' => 'ARCADE_COMMENTS_SMILIES', 				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'parse_links'						=> array('lang' => 'ARCADE_COMMENTS_LINKS', 				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),

							'legend3'							=> 'ACP_ARCADE_DOWNLOADS_GAMES_SETTINGS',
							'download_system'					=> array('lang' => 'ARCADE_DOWNLOAD_SYSTEM', 				'validate' => 'bool',			'type' => 'radio:enabled_disabled',	'explain'	=> true),
							'download_list'						=> array('lang' => 'ARCADE_DOWNLOAD_LIST', 					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'download_list_message'				=> array('lang' => 'ARCADE_DOWNLOAD_LIST_MESSAGE',			'validate' => 'string:0:255',	'type' => 'textarea:3:40',			'explain'	=> true),
							'download_file_type'				=> array('lang' => 'ARCADE_DOWNLOAD_FILE_TYPE', 			'validate' => 'string',			'type' => 'select',					'explain'	=> false,	'method' => 'download_file_type_select'),

							'legend4'							=> 'ACP_ARCADE_SETTINGS_FLOOD',
							'play_anonymous_interval'			=> array('lang' => 'ARCADE_PLAY_INTERVAL_GUEST',			'validate' => 'int:0:3600',		'type' => 'number:0:3600',			'explain'	=> true,	'append' => ' ' . $this->user->lang['SECONDS']),
							'play_interval'						=> array('lang' => 'ARCADE_PLAY_INTERVAL',					'validate' => 'int:0:3600',		'type' => 'number:0:3600',			'explain'	=> true,	'append' => ' ' . $this->user->lang['SECONDS']),
							'search_anonymous_interval'			=> array('lang' => 'ARCADE_SEARCH_INTERVAL_GUEST',			'validate' => 'int:0:3600',		'type' => 'number:0:3600',			'explain'	=> true,	'append' => ' ' . $this->user->lang['SECONDS']),
							'search_interval'					=> array('lang' => 'ARCADE_SEARCH_INTERVAL',				'validate' => 'int:0:3600',		'type' => 'number:0:3600',			'explain' 	=> true,	'append' => ' ' . $this->user->lang['SECONDS']),
							'download_anonymous_interval'		=> array('lang' => 'ARCADE_DOWNLOAD_INTERVAL_GUEST',		'validate' => 'int:0:3600',		'type' => 'number:0:3600',			'explain'	=> true,	'append' => ' ' . $this->user->lang['SECONDS']),
							'download_interval'					=> array('lang' => 'ARCADE_DOWNLOAD_INTERVAL',				'validate' => 'int:0:3600',		'type' => 'number:0:3600',			'explain'	=> true,	'append' => ' ' . $this->user->lang['SECONDS']),
							'download_per_day'					=> array('lang' => 'ARCADE_DOWNLOAD_PER_DAY',				'validate' => 'int:0:9999',		'type' => 'number:0:9999',			'explain'	=> true),
							'download_per_day_groups'			=> array('lang' => 'ARCADE_DOWNLOAD_PER_DAY_GROUPS',		'validate' => 'string',			'type' => 'custom',					'explain'	=> true,	'method' => 'download_per_day_groups'),
						));

				if ($this->user->data['user_type'] == USER_FOUNDER)
				{
						$display_vars['vars'] += array(
							'legend5'							=> 'ACP_ARCADE_SETTINGS_FOUNDER',
							'founder_exempt'					=> array('lang' => 'ARCADE_FOUNDER_EXEMPT',					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain' 	=> true),
							'search_filter_age'					=> array('lang' => 'ARCADE_SEARCH_FILTER_AGE',				'validate' => 'int',			'type' => 'select',					'explain'	=> true,	'method' => 'search_check_select'),
							'search_filter_password'			=> array('lang' => 'ARCADE_SEARCH_FILTER_PASSWORD',			'validate' => 'int',			'type' => 'select',					'explain'	=> true,	'method' => 'search_check_select'),
						);
				}

				if ($this->arcade->points->data['installed'] && $this->auth->acl_get('a_arcade_points_settings'))
				{
						$display_vars['vars'] += array(
							'legend6'							=> 'ACP_ARCADE_POINTS',
							'use_points'						=> array('lang' => 'ARCADE_USE_POINTS',						'validate' => 'bool', 			'type' => 'custom',					'explain'	=> true,	'method' => 'points_detect'),
							'game_download_cost'				=> array('lang' => 'ARCADE_GLOBAL_GAME_DOWNLOAD_COST',		'validate' => 'jva_float:-1',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
							'game_cost'							=> array('lang' => 'ARCADE_GLOBAL_GAME_COST', 				'validate' => 'jva_float:-1',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
							'game_reward'						=> array('lang' => 'ARCADE_GLOBAL_GAME_REWARD',				'validate' => 'jva_float:-1',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
							'super_record_reward'				=> array('lang' => 'ARCADE_SUPER_CHAMPION_REWARD',			'validate' => 'jva_float:0',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
							'use_jackpot'						=> array('lang' => 'ARCADE_GLOBAL_USE_JACKPOT',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'jackpot_minimum'					=> array('lang' => 'ARCADE_JACKPOT_MINIMUM',				'validate' => 'jva_float:0',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
							'jackpot_maximum'					=> array('lang' => 'ARCADE_JACKPOT_MAXIMUM',				'validate' => 'jva_float:0',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
							'first_score_reward'				=> array('lang' => 'ARCADE_FIRST_SCORE_REWARD',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'playfree_reward'					=> array('lang' => 'ARCADE_PLAYFREE_REWARD',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
						);
				}

				if ($this->arcade->shout->data['installed'])
				{
						$display_vars['vars'] += array(
							'legend7'							=> 'ACP_ARCADE_SHOUT_SETTINGS',
							'use_shout'							=> array('lang' => 'ARCADE_USE_SHOUT',						'validate' => 'bool', 			'type' => 'custom',					'explain'	=> true,	'method' => 'shout_detect'),
							'shout_user_id'						=> array('lang' => 'ARCADE_SHOUT_AUTHOR',					'validate' => 'string', 		'type' => 'custom',					'explain'	=> true,	'method' => 'shout_user_id'),
							'shout_score_type'					=> array('lang' => 'ARCADE_SHOUT_SCORE_TYPE',				'validate' => 'int', 			'type' => 'select',					'explain'	=> true,	'method' => 'shout_score_type'),
							'shout_ignore_cats'					=> array('lang' => 'ARCADE_SHOUT_IGNORE_CATS',				'validate' => 'string',			'type' => 'custom',					'explain'	=> true,	'method' => 'ignore_cat'),
						);
				}

					$display_vars['vars'] += array(
							'legend8'							=> 'ACP_SUBMIT_CHANGES'
					);
			break;

			case 'game':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_GAME',
						'vars'	=> array(
							'legend1'							=> 'ACP_ARCADE_SETTINGS_GAME',
							'game_pp_enable'					=> array('lang' => 'ARCADE_GAME_PP_ENABLE',					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'game_autosize'						=> array('lang' => 'ARCADE_GLOBAL_GAME_AUTOSIZE',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'game_width'						=> array('lang' => 'ARCADE_GLOBAL_GAME_WIDTH',				'validate' => 'int:0:9999',		'type' => 'number:0:9999',			'explain'	=> true,	'append' => ' ' . $this->user->lang['PIXEL']),
							'game_height'						=> array('lang' => 'ARCADE_GLOBAL_GAME_HEIGHT',				'validate' => 'int:0:9999',		'type' => 'number:0:9999',			'explain'	=> true,	'append' => ' ' . $this->user->lang['PIXEL']),
							'flash_version'						=> array('lang' => 'ARCADE_ACP_FLASH_VERSION',				'validate' => 'string:7:15',	'type' => 'text:16:15',				'explain'	=> true),

							'legend3'							=> 'GENERAL_SETTINGS',
							'play_info_box'						=> array('lang' => 'ARCADE_PLAY_INFO_BOX',					'validate' => 'string:1:1',		'type' => 'select',					'explain'	=> true,	'method' => 'left_right'),
							'game_scores'						=> array('lang' => 'ARCADE_TOTAL_GAME_SCORES',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'username_maxchars'					=> array('lang' => 'ARCADE_USERNAME_MAXCHARS',				'validate' => 'int:0:50',		'type' => 'number:0:50',			'explain'	=> true),
							'display_desc'						=> array('lang' => 'ARCADE_DISPLAY_GAME_DESC',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'game_desc_translate'				=> array('lang' => 'ARCADE_GAME_DESC_TRANSLATE',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'game_desc_lang'					=> array('lang' => 'ARCADE_GAME_DESC_LANG',					'validate' => 'string',			'type' => 'select',					'explain'	=> true,	'method' => 'select_lang'),
							'display_game_control'				=> array('lang' => 'ARCADE_DISPLAY_GAME_CONTROL',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'display_game_type'					=> array('lang' => 'ARCADE_DISPLAY_GAME_TYPE',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'display_game_save_type'			=> array('lang' => 'ARCADE_DISPLAY_GAME_SCORE_TYPE',		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'resolution_select'					=> array('lang' => 'ARCADE_RESOLUTION_SELECT',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'super_champion'					=> array('lang' => 'ARCADE_DISPLAY_SUPER_CHAMPION', 		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'super_champion_avatar'				=> array('lang' => 'ARCADE_DISPLAY_SUPER_CHAMPION_AVATAR',	'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'super_champion_avatar_width'		=> array('lang' => 'ARCADE_SUPER_CHAMPION_AVATAR_WIDTH',	'validate' => 'int:15:200',		'type' => 'number:15:200',			'explain'	=> false,	'append' => ' ' . $this->user->lang['PIXEL']),
							'super_champion_avatar_height'		=> array('lang' => 'ARCADE_SUPER_CHAMPION_AVATAR_HEIGHT',	'validate' => 'int:15:200',		'type' => 'number:15:200',			'explain'	=> false,	'append' => ' ' . $this->user->lang['PIXEL']),

							'legend4'							=> 'ARCADE_GAME_TIME_SECURITY',
							'game_time_hack_banned'				=> array('lang' => 'ARCADE_GAME_TIME_SECURITY_AUTO_BANNED',	'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'game_time_check_time'				=> array('lang' => 'ARCADE_GAME_TIME_SECURITY_RECHECK_TIME','validate' => 'int:1:10',		'type' => 'number:1:10',			'explain'	=> true,	'append' => ' ' . $this->user->lang['TIME_SECOND']),
							'game_time_tolerance_percent'		=> array('lang' => 'ARCADE_GAME_TIME_SECURITY_TOLERANCE',	'validate' => 'int:10:50',		'type' => 'number:10:50',			'explain'	=> true,	'append' => ' %'),

							'legend5'							=> 'ARCADE_SCORE_SECURITY',
							'corrupt_score_banned'				=> array('lang' => 'ARCADE_CORRUPT_SCORE_BANNED',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'score_security_level'				=> array('lang' => 'ARCADE_SCORE_SECURITY_LEVEL',			'validate' => 'int',			'type' => 'select',					'explain'	=> true,	'method' => 'score_security_level'),
							'score_form_token_lifetime'			=> array('lang' => 'ARCADE_SCORE_FORM_TOKEN_LIFETIME',		'validate' => 'int:1:99',		'type' => 'number:1:99',			'explain'	=> true,	'append' => ' ' . $this->user->lang['TIME_SECOND']),

							'legend6'							=> 'ACP_ARCADE_GAME_OVER',
							'game_over_sound'					=> array('lang' => 'ARCADE_GAME_OVER_SOUND_ENABLE',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'anim_game_over_winner'				=> array('lang' => 'ARCADE_GAME_OVER_WINNER_ANIMATION',		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'anim_game_over_losing'				=> array('lang' => 'ARCADE_GAME_OVER_LOSING_ANIMATION',		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'random_games_game_over_enable'		=> array('lang' => 'ARCADE_RANDOM_GAMES_GAME_OVER_ENABLE',	'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'random_games_game_over'			=> array('lang' => 'ARCADE_RANDOM_GAMES_GAME_OVER',			'validate' => 'int:1:10',		'type' => 'number:1:10',			'explain'	=> true),

							'legend7'							=> 'ACP_SUBMIT_CHANGES'
					));
			break;

			case 'challenge':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_CHALLENGE',
						'vars'	=> array(
							'legend1'							=> 'ACP_ARCADE_SETTINGS_CHALLENGE',
							'challenge_disable'					=> array('lang' => 'DISABLE_CHALLENGE',						'validate' => 'bool',			'type' => 'custom',					'explain'	=> true,	'method' => 'arcade_disable'),
							'challenge_disable_msg'				=> false,
							'challenge_users_select'			=> array('lang' => 'ACP_CHALLENGE_USER_SELECT_TYPE',		'validate' => 'bool',			'type' => 'custom',					'explain'	=> true,	'method' => 'challenge_users_select'),
							'challenge_acc_exp_date'			=> array('lang' => 'CHALLENGE_ACC_EXP_DATE',				'validate' => 'int:0',			'type' => 'select',					'explain'	=> true,	'method' => 'challenge_exp_date_select'),
							'challenge_ong_exp_date'			=> array('lang' => 'CHALLENGE_ONG_EXP_DATE',				'validate' => 'int:0',			'type' => 'select',					'explain'	=> true,	'method' => 'challenge_exp_date_select'),
						));

				if ($this->arcade->points->data['installed'] && $this->auth->acl_get('a_arcade_points_settings'))
				{
					$display_vars['vars'] += array(
						'legend2'								=> 'ACP_ARCADE_POINTS',
						'challenge_bet_minimum'					=> array('lang' => 'CHALLENGE_BET_MIN',						'validate' => 'jva_float:0',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
						'challenge_bet_maximum'					=> array('lang' => 'CHALLENGE_BET_MAX',						'validate' => 'jva_float:0',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
						'challenge_bet_fix'						=> array('lang' => 'CHALLENGE_BET_FIX',						'validate' => 'jva_float:0',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
					);
				}

					$display_vars['vars'] += array(
							'legend3'							=> 'ACP_SUBMIT_CHANGES'
					);
			break;

			case 'tournament':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_TOUR',
						'vars'	=> array(
							'legend1'							=> 'ACP_ARCADE_SETTINGS_TOUR',
							'tour_disable'						=> array('lang' => 'DISABLE_ARCADE_TOUR',					'validate' => 'bool',			'type' => 'custom',					'explain'	=> true,	'method'	=> 'arcade_disable'),
							'tour_disable_msg'					=> false,
							'tour_min_games'					=> array('lang' => 'ARCADE_TOUR_MIN_GAMES',					'validate' => 'int:3:30',		'type' => 'number:3:30',			'explain'	=> true),
							'tour_max_games'					=> array('lang' => 'ARCADE_TOUR_MAX_GAMES',					'validate' => 'int:3:200',		'type' => 'number:3:200',			'explain'	=> true),
						));


				if ($this->arcade->points->data['installed'] && $this->auth->acl_get('a_arcade_points_settings'))
				{
					$display_vars['vars'] += array(
						'legend2'								=> 'ACP_ARCADE_POINTS',
						'tour_reward_enable'					=> array('lang' => 'ARCADE_TOUR_REWARD_ENABLE',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
						'tour_reward_min'						=> array('lang' => 'ARCADE_TOUR_REWARD_MIN',				'validate' => 'jva_float:0',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
						'tour_reward_max'						=> array('lang' => 'ARCADE_TOUR_REWARD_MAX',				'validate' => 'jva_float:0',	'type' => 'text:12:11',				'explain'	=> true,	'append' => ' ' . $this->arcade->points->data['name']),
					);
				}

					$display_vars['vars'] += array(
							'legend3'							=> 'ACP_ARCADE_TOUR_NEWS_SETTINGS',
							'tour_display_news'					=> array('lang' => 'ARCADE_TOUR_DISPLAY_NEWS',				'validate' => 'int:0',			'type' => 'select',					'explain'	=> true,	'method' => 'display_page'),
							'tour_news_max_display_day'			=> array('lang' => 'ARCADE_TOUR_NEWS_MAX_DISPLAY_DAY',		'validate' => 'int:1:90',		'type' => 'number:1:90',			'explain'	=> true,	'append' => ' ' . $this->user->lang['DAYS']),
							'tour_news_count_start'				=> array('lang' => 'ARCADE_TOUR_NEWS_COUNT_START',			'validate' => 'int:0:50',		'type' => 'number:0:50',			'explain'	=> true),
							'tour_news_count_end'				=> array('lang' => 'ARCADE_TOUR_NEWS_COUNT_END',			'validate' => 'int:0:50',		'type' => 'number:0:50',			'explain'	=> true),
							'tour_display_news_icons'			=> array('lang' => 'ARCADE_DISPLAY_GAME_ICONS',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'tour_news_icons_count'				=> array('lang' => 'ARCADE_ICONS_COUNT',					'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'tour_news_icons_size'				=> array('lang' => 'ARCADE_ICONS_SIZE',						'validate' => 'int:5:50',		'type' => 'number:5:50',			'explain'	=> true,	'append' => ' ' . $this->user->lang['PIXEL']),
							'legend4'							=> 'ACP_SUBMIT_CHANGES'
					);
			break;

			case 'feature':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_FEATURE',
						'vars'	=> array(
							'legend1'							=> 'GENERAL_SETTINGS',
							'display_viewtopic'					=> array('lang' => 'ARCADE_DISPLAY_VIEWTOPIC',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'display_memberlist'				=> array('lang' => 'ARCADE_DISPLAY_MEMBERLIST',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),

							'legend2'							=> 'ACP_ARCADE_SETTINGS_PLAY',
							'limit_play'						=> array('lang' => 'ARCADE_LIMIT_PLAY',						'validate' => 'int:0',			'type' => 'select',					'explain'	=> true,	'method'	=> 'arcade_limit_play_select'),
							'limit_play_total_posts'			=> array('lang' => 'ARCADE_LIMIT_PLAY_TOTAL_POSTS',			'validate' => 'int:0:1000',		'type' => 'number:0:1000',			'explain'	=> true),
							'limit_play_posts'					=> array('lang' => 'ARCADE_LIMIT_PLAY_POSTS',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'limit_play_days'					=> array('lang' => 'ARCADE_LIMIT_PLAY_DAYS',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),

							'legend3'							=> 'ACP_SUBMIT_CHANGES'
						));
			break;

			case 'page':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_PAGE',
						'vars'	=> array(
							'legend1'							=> 'ACP_ARCADE_SETTINGS_PAGE_MAIN',
							'welcome_index'						=> array('lang' => 'ARCADE_DISPLAY_WELCOME_BOX',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'search_index'						=> array('lang' => 'ARCADE_DISPLAY_SEARCH_BOX',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'newest_games'						=> array('lang' => 'ARCADE_NEWEST_TOP_GAMES_HEADER',		'validate' => 'int:3:50',		'type' => 'number:3:100',			'explain'	=> true),
							'newest_games_tooltip'				=> array('lang' => 'ARCADE_NEWEST_GAMES_TOOLTIP',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'newest_games_img'					=> array('lang' => 'ARCADE_DISPLAY_GAME_IMAGE',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'newest_games_img_size'				=> array('lang' => 'ARCADE_GAME_IMAGE_SIZE',				'validate' => 'int:20:60',		'type' => 'number:20:60',			'explain'	=> false,	'append' => ' ' . $this->user->lang['PIXEL'], 'hr' => true),
							'leaders'							=> array('lang' => 'LEADERS_HEADER',						'validate' => 'int:3:18',		'type' => 'number:3:100',			'explain'	=> true),
							'leaders_avatar'					=> array('lang' => 'ARCADE_DISPLAY_USER_AVATAR',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'leaders_avatar_size'				=> array('lang' => 'ARCADE_USER_AVATAR_SIZE',				'validate' => 'int:30:60',		'type' => 'number:20:60',			'explain'	=> false,	'append' => ' ' . $this->user->lang['PIXEL'], 'hr' => true),
							'latest_highscores'					=> array('lang' => 'ARCADE_LATEST_HIGHSCORES_WINNERS',		'validate' => 'int:3:30',		'type' => 'number:3:100',			'explain'	=> true),
							'latest_highscores_avatar'			=> array('lang' => 'ARCADE_DISPLAY_USER_AVATAR',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'latest_highscores_avatar_size'		=> array('lang' => 'ARCADE_USER_AVATAR_SIZE',				'validate' => 'int:20:60',		'type' => 'number:20:60',			'explain'	=> false,	'append' => ' ' . $this->user->lang['PIXEL']),

							'legend2'							=> 'ACP_ARCADE_SETTINGS_PAGE_RANK',
							'ranks_page'						=> array('lang' => 'ARCADE_RANKING',						'validate' => 'bool',			'type' => 'radio:enabled_disabled',	'explain'	=> false),
							'welcome_ranks'						=> array('lang' => 'ARCADE_DISPLAY_WELCOME_BOX',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'search_ranks'						=> array('lang' => 'ARCADE_DISPLAY_SEARCH_BOX',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),

							'legend3'							=> 'ACP_ARCADE_SETTINGS_PAGE_SEARCH',
							'welcome_search'					=> array('lang' => 'ARCADE_DISPLAY_WELCOME_BOX',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),

							'legend4'							=> 'ACP_ARCADE_SETTINGS_PAGE_DOWNLOAD',
							'welcome_download'					=> array('lang' => 'ARCADE_DISPLAY_WELCOME_BOX',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'search_download'					=> array('lang' => 'ARCADE_DISPLAY_SEARCH_BOX', 			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),

							'legend5'							=> 'ACP_ARCADE_SETTINGS_PAGE_STATS',
							'welcome_stats'						=> array('lang' => 'ARCADE_DISPLAY_WELCOME_BOX', 			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'search_stats'						=> array('lang' => 'ARCADE_DISPLAY_SEARCH_BOX', 			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'stats_icon'						=> array('lang' => 'ARCADE_ICONS_DISPLAY',					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'stats_icon_size'					=> array('lang' => 'ARCADE_ICONS_SIZE',						'validate' => 'int:20:60',		'type' => 'number:20:60',			'explain'	=> true,	'append' => ' ' . $this->user->lang['PIXEL']),
							'leaders_stats'						=> array('lang' => 'LEADERS',								'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'super_champions'					=> array('lang' => 'ARCADE_SUPER_CHAMPIONS',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'longest_held_scores'				=> array('lang' => 'ARCADE_LONGEST_HELD_SCORES',			'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'most_popular'						=> array('lang' => 'ARCADE_MOST_POPULAR',					'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'least_popular'						=> array('lang' => 'ARCADE_LEAST_POPULAR',					'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'most_played_users'					=> array('lang' => 'ARCADE_MOST_PLAYED_USERS',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'least_played_users'				=> array('lang' => 'ARCADE_LEAST_PLAYED_USERS',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'most_downloaded'					=> array('lang' => 'ARCADE_MOST_DOWNLOADED',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'least_downloaded'					=> array('lang' => 'ARCADE_LEAST_DOWNLOADED',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),

							'legend6'							=> 'ACP_ARCADE_SETTINGS_PAGE_DETAILED_STATS',
							'welcome_detailed_stats'			=> array('lang' => 'ARCADE_DISPLAY_WELCOME_BOX', 			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'search_detailed_stats'				=> array('lang' => 'ARCADE_DISPLAY_SEARCH_BOX', 			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'detailed_stats_icon'				=> array('lang' => 'ARCADE_ICONS_DISPLAY',					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'detailed_stats_icon_size'			=> array('lang' => 'ARCADE_ICONS_SIZE',						'validate' => 'int:20:60',		'type' => 'number:20:60',			'explain'	=> true,	'append' => ' ' . $this->user->lang['PIXEL']),

							'legend7'							=> 'ACP_ARCADE_SETTINGS_PAGE_CAT_GAMES',
							'welcome_cats'						=> array('lang' => 'ARCADE_DISPLAY_WELCOME_BOX',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'search_cats'						=> array('lang' => 'ARCADE_DISPLAY_SEARCH_BOX',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'cat_super_record'					=> array('lang' => 'ARCADE_DISPLAY_SUPER_RECORD',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),

							'legend8'							=> 'ACP_ARCADE_SETTINGS_PAGE_CAT_GAMES_STATS',
							'welcome_cat_stats'					=> array('lang' => 'ARCADE_DISPLAY_WELCOME_BOX',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'search_cat_stats'					=> array('lang' => 'ARCADE_DISPLAY_SEARCH_BOX',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),
							'display_cat_games_stats'			=> array('lang' => 'DISPLAY_CAT_GAMES_STATS',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'cat_leaders'						=> array('lang' => 'LEADERS',								'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'cat_super_champions'				=> array('lang' => 'ARCADE_SUPER_CHAMPIONS',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'cat_longest_held_scores'			=> array('lang' => 'ARCADE_LONGEST_HELD_SCORES',			'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'cat_most_popular'					=> array('lang' => 'ARCADE_MOST_POPULAR',					'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'cat_least_popular'					=> array('lang' => 'ARCADE_LEAST_POPULAR',					'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'cat_most_played_users'				=> array('lang' => 'ARCADE_MOST_PLAYED_USERS',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'cat_least_played_users'			=> array('lang' => 'ARCADE_LEAST_PLAYED_USERS',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'cat_most_downloaded'				=> array('lang' => 'ARCADE_MOST_DOWNLOADED',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),
							'cat_least_downloaded'				=> array('lang' => 'ARCADE_LEAST_DOWNLOADED',				'validate' => 'int:0:100',		'type' => 'number:0:100',			'explain'	=> true),

							'legend9'							=> 'ACP_SUBMIT_CHANGES'
						));
			break;

			case 'path':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_PATH',
						'vars'	=> array(
							'legend1'							=> 'ACP_ARCADE_SETTINGS_PROTECT',
							'protect_game_img'					=> array('lang' => 'ARCADE_PROTECT_GAME_IMAGE',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'protect_phpbbarcade'				=> array('lang' => 'ARCADE_PROTECT_PHPBBARCADE',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'protect_amod'						=> array('lang' => 'ARCADE_PROTECT_AMOD',					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'protect_v3arcade'					=> array('lang' => 'ARCADE_PROTECT_V3ARCADE',				'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),

							'legend2'							=> 'ACP_ARCADE_SETTINGS_PATH',
							'game_path'							=> array('lang' => 'ARCADE_GAME_PATH',						'validate' => 'wpath',			'type' => 'text:30:65',				'explain'	=> true),
							'cat_backup_path'					=> array('lang' => 'ARCADE_CAT_BACKUP_PATH',				'validate' => 'wpath',			'type' => 'text:30:65',				'explain'	=> true),
							'unpack_game_path'					=> array('lang' => 'ARCADE_UNPACK_GAME_PATH',				'validate' => 'wpath',			'type' => 'text:30:65',				'explain'	=> true),

							'legend3'							=> 'ACP_SUBMIT_CHANGES'
						));
			break;

			case 'load':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_LOAD',
						'vars'	=> array(
							'legend1'							=> 'GENERAL_SETTINGS',
							'session_length'					=> array('lang' => 'ARCADE_GAMES_SESSION_LENGTH',			'validate' => 'int:3600:999999','type' => 'number:3600:999999',		'explain'	=> true, 'append' => ' ' . $this->user->lang['SECONDS']),
							'online_time'						=> array('lang' => 'ARCADE_ONLINE_TIME',					'validate' => 'int:0:60',		'type' => 'number:0:60',			'explain'	=> true, 'append' => ' ' . $this->user->lang['MINUTES']),
							'cache_time'						=> array('lang' => 'ARCADE_CACHE_TIME',						'validate' => 'int:1:999',		'type' => 'number:1:999',			'explain'	=> true, 'append' => ' ' . $this->user->lang['HOURS']),

							'legend2'							=> 'GENERAL_SETTINGS',
							'unpack_games_limit'				=> array('lang' => 'ARCADE_UNPACK_GAMES_LIMIT',				'validate' => 'int:5:300',		'type' => 'number:5:300',			'explain'	=> true),
							'install_games_limit'				=> array('lang' => 'ARCADE_INSTALL_GAMES_LIMIT',			'validate' => 'int:5:150',		'type' => 'number:5:150',			'explain'	=> true),

							'legend3'							=> 'GENERAL_SETTINGS',
							'games_per_page'					=> array('lang' => 'ARCADE_GAMES_PER_PAGE',					'validate' => 'int:1:999',		'type' => 'number:1:999',			'explain'	=> true),
							'stat_items_per_page'				=> array('lang' => 'ARCADE_STAT_ITEMS_PER_PAGE',			'validate' => 'int:1:999',		'type' => 'number:1:999',			'explain'	=> true),

							'legend4'							=> 'GENERAL_SETTINGS',
							'backup_limit'						=> array('lang' => 'ARCADE_GAMES_BACKUP_LIMIT',				'validate' => 'int:5:300',		'type' => 'number:5:300',			'explain'	=> true),
							'download_on_demand'				=> array('lang' => 'ARCADE_GAMES_DOWNLOAD_ON_DEMAND',		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),

							'legend5'							=> 'GENERAL_SETTINGS',
							'acp_items_per_page'				=> array('lang' => 'ARCADE_ACP_ITEMS_PER_PAGE',				'validate' => 'int:5:9999',		'type' => 'number:5:9999',			'explain'	=> true),
							'download_list_per_page'			=> array('lang' => 'ARCADE_DOWNLOAD_LIST_PER_PAGE',			'validate' => 'int:10:250',		'type' => 'select',					'explain'	=> true, 'method' => 'download_list_per_page_select'),

							'legend6'							=> 'GENERAL_SETTINGS',
							'load_list'							=> array('lang' => 'ARCADE_LOAD_LIST_LOADING',				'validate' => 'bool', 			'type' => 'custom',					'explain'	=> true, 'method' => 'load_list'),
							'game_zero_negative_score'			=> array('lang' => 'ARCADE_GAME_ZERO_NEGATIVE_SCORE',		'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
							'new_games_delay'					=> array('lang' => 'ARCADE_NEW_GAMES_DELAY',				'validate' => 'int:1:99',		'type' => 'number:1:99',			'explain'	=> true, 'append' => ' ' . $this->user->lang['DAYS']),
							'new_games_style'					=> array('lang' => 'ARCADE_NEW_GAMES_STYLE',				'validate' => 'int:0:1',		'type' => 'select',					'explain'	=> true, 'method' => 'new_games_style'),
							'played_colour'						=> array('lang' => 'ARCADE_PLAYED_GAMES_COLOUR',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),

							'legend7'							=> 'GENERAL_SETTINGS',
							'load_jumpbox'						=> array('lang' => 'ARCADE_YES_JUMPBOX', 					'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> false),

							'legend8'							=> 'ACP_SUBMIT_CHANGES'
						));
			break;

			case 'paar':
					$display_vars = array(
						'title'									=> 'ACP_ARCADE_SETTINGS_PAAR_TITLE',
						'vars'	=> array(
							'legend1'							=> 'GENERAL_SETTINGS',
							'paar'								=> array('lang' => 'ARCADE_PAAR',							'validate' => 'int:-1:2',		'type' => 'custom',					'explain'	=> true, 'method' => 'paar'),

							'legend2'							=> 'ACP_SUBMIT_CHANGES'
						));
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		$this->new_config = clone $this->arcade_config;
		$cfg_array = (isset($_REQUEST['config'])) ? $this->request->variable('config', array('' => ''), true) : $this->new_config;
		$error = array();

		// We validate the complete config if whished
		validate_config_vars($display_vars['vars'], $cfg_array, $error);
		$this->validate_configs($display_vars['vars'], $cfg_array, $error, $submit);

		if ($submit && !check_form_key($form_key))
		{
			$error[] = $this->user->lang['FORM_INVALID'];
		}

		// Do not write values if there is an error
		if (count($error))
		{
			$submit = false;
		}

		$file_functions = $this->arcade->container('functions_file');

		// We go through the display_vars to make sure no one is trying to set variables he/she is not allowed to...
		foreach ($display_vars['vars'] as $config_name => $null)
		{
			if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
			{
				continue;
			}

			$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

			if ($submit)
			{
				if (strpos($config_name, 'leaders') !== false || $config_name == 'cache_time')
				{
					$purge_cache = true;
				}

				if ($config_name == 'download_list_per_page' && !in_array($config_value, array(10, 20, 50, 100, 250)))
				{
					$config_value = 50;
				}

				if (in_array($config_name, array('game_path', 'unpack_game_path', 'cat_backup_path')))
				{
					$file_functions->append_slash($config_value);
				}

				$this->arcade_config->set($config_name, $config_value);

				if ($config_name == 'jackpot_minimum')
				{
					$this->arcade->reset('jackpot_min_max');
				}
			}
		}

		if ($submit)
		{
			if ($purge_cache)
			{
				$this->arcade->cache_purge();
			}

			$this->arcade->add_log('admin', 'LOG_ARCADE_' . strtoupper($mode));
			trigger_error($this->user->lang['CONFIG_UPDATED'] . adm_back_link($this->u_action));
		}

		$this->tpl_name = 'arcade/acp_setting';
		$this->page_title = $display_vars['title'];

		$this->template->assign_vars(array(
			'L_TITLE'				=> $this->user->lang[$display_vars['title']],
			'L_TITLE_EXPLAIN'		=> $this->user->lang[$display_vars['title'] . '_EXPLAIN'],

			'S_ERROR'				=> (count($error)) ? true : false,
			'ERROR_MSG'				=> implode('<br>', $error),

			'U_ACTION'				=> $this->u_action
		));

		// Output relevant page
		foreach ($display_vars['vars'] as $config_key => $vars)
		{
			if (!is_array($vars) && strpos($config_key, 'legend') === false)
			{
				continue;
			}

			if (strpos($config_key, 'legend') !== false)
			{
				$this->template->assign_block_vars('options', array(
					'S_LEGEND'			=> true,
					'LEGEND'			=> $this->arcade->lang_value($vars)
				));

				continue;
			}

			$type = explode(':', $vars['type']);

			$l_explain = '';
			if ($vars['explain'] && isset($vars['lang_explain']))
			{
				$l_explain = $this->arcade->lang_value($vars['lang_explain']);
			}
			else if ($vars['explain'])
			{
				$l_explain = $this->arcade->lang_value($vars['lang'] . '_EXPLAIN', true);
			}

			if (in_array($config_key, array('game_download_cost', 'game_cost', 'game_reward', 'jackpot_minimum', 'jackpot_maximum', 'challenge_bet_minimum', 'challenge_bet_maximum', 'challenge_bet_fix', 'super_record_reward', 'tour_reward_min', 'tour_reward_max')))
			{
				$this->new_config[$config_key] = $this->arcade->number_format($this->new_config[$config_key], true);
			}

			$content = build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars);

			if (empty($content))
			{
				continue;
			}

			$this->template->assign_block_vars('options', array(
				'KEY'			=> $config_key,
				'TITLE'			=> $this->arcade->lang_value($vars['lang']),
				'S_EXPLAIN'		=> $vars['explain'],
				'S_HR'			=> !empty($vars['hr']),
				'TITLE_EXPLAIN'	=> $l_explain,
				'CONTENT'		=> $content
			));

			unset($display_vars['vars'][$config_key]);
		}
	}

	public function arcade_limit_play_select($value)
	{
		$option_ary = array(
			LIMIT_PLAY_TYPE_NONE	=> 'ARCADE_NONE',
			LIMIT_PLAY_TYPE_POSTS	=> 'ARCADE_LIMIT_PLAY_TOTAL_POSTS',
			LIMIT_PLAY_TYPE_DAYS	=> 'ARCADE_LIMIT_PLAY_POSTS',
			LIMIT_PLAY_TYPE_BOTH	=> 'ARCADE_LIMIT_PLAY_BOTH'
		);

		return $this->arcade->build_select($option_ary, $value);
	}

	public function games_sort_order_select($value)
	{
		$option_ary = array(
			ARCADE_ORDER_FIXED			=> 'ARCADE_GAMES_SORT_FIXED',
			ARCADE_ORDER_INSTALLDATE	=> 'ARCADE_GAMES_SORT_INSTALLDATE',
			ARCADE_ORDER_NAME			=> 'ARCADE_GAMES_SORT_NAME',
			ARCADE_ORDER_PLAYS			=> 'ARCADE_GAMES_SORT_PLAYS',
			ARCADE_ORDER_RATING			=> 'ARCADE_GAMES_SORT_RATING'
		);

		return $this->arcade->build_select($option_ary, $value);
	}

	public function games_sort_dir_select($value)
	{
		$option_ary = array(
			ARCADE_ORDER_ASC	=> 'ASCENDING',
			ARCADE_ORDER_DESC	=> 'DESCENDING'
		);

		return $this->arcade->build_select($option_ary, $value);
	}

	public function download_list_per_page_select($value)
	{
		return '<option value="10"'  . (($value ==  10) ? ' selected="selected"' : '') .  '>10</option>
				<option value="20"'  . (($value ==  20) ? ' selected="selected"' : '') .  '>20</option>
				<option value="50"'  . (($value ==  50) ? ' selected="selected"' : '') .  '>50</option>
				<option value="100"' . (($value == 100) ? ' selected="selected"' : '') . '>100</option>
				<option value="250"' . (($value == 250) ? ' selected="selected"' : '') . '>250</option>';
	}

	public function new_games_style($value)
	{
		return '<option value="1"'  . (($value ==  1) ? ' selected="selected"' : '') .  '>' . $this->user->lang['ARCADE_STYLE_FORUM'] . '</option>
				<option value="0"'  . (($value ==  0) ? ' selected="selected"' : '') .  '>' . $this->user->lang['ARCADE_STYLE_ARCADE'] . '</option>';
	}

	public function points_detect($value, $key)
	{
		$point_status = ($this->arcade->points->data['enabled']) ? 'ENABLED': 'DISABLED';
		$ext_name = '';
		switch($this->arcade->points->data['type'])
		{
			case ARCADE_JV_POINTS_SYSTEM:
				$ext_name = 'JV_POINTS_SYSTEM';
			break;

			case ARCADE_ULTIMATE_POINTS_SYSTEM:
				$ext_name = 'ULTIMATE_POINTS_SYSTEM';
			break;
		}

		$radio_ary = array(1 => 'YES', 0 => 'NO');
		$ext_name = ($ext_name) ? sprintf($this->user->lang['ARCADE_INSTALL_EXT_DETECT_' . $point_status], $this->user->lang['ARCADE_EXT_NAME_' . $ext_name]) . '<br>' : '';

		return $ext_name . h_radio("config[$key]", $radio_ary, $value, $key);
	}

	public function shout_detect($value, $key)
	{
		$shout_status = ($this->arcade->shout->data['enabled']) ? 'ENABLED': 'DISABLED';
		$ext_name = '';
		switch($this->arcade->shout->data['type'])
		{
			case ARCADE_MCHAT:
				$ext_name = 'MCHAT';
			break;

			case ARCADE_AJAX_CHAT:
				$ext_name = 'AJAX_CHAT';
			break;

			case ARCADE_AJAX_SHOUTBOX:
				$ext_name = 'AJAX_SHOUTBOX';
			break;

			case ARCADE_JV_SHOUTBOX:
				$ext_name = 'JV_SHOUTBOX';
			break;
		}

		$radio_ary = array(1 => 'YES', 0 => 'NO');
		$ext_name = ($ext_name) ? sprintf($this->user->lang['ARCADE_INSTALL_EXT_DETECT_' . $shout_status], $this->user->lang['ARCADE_EXT_NAME_' . $ext_name]) . '<br>' : '';

		return $ext_name . h_radio('config[' . $key . ']', $radio_ary, $value, $key);
	}

	public function shout_user_id($value, $key)
	{
		if (is_numeric($value))
		{
			$username = $this->arcade->userdata('username', $value);
		}
		else
		{
			$username = $value;
		}

		return '<input type="text" name="config[' . $key . ']" id="' . $key . '" value="' . $username . '" maxlength="100" size="30"> [ <a href="'. append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=searchuser&amp;form=acp_arcade&amp;field=' . $key . '&amp;select_single=true').'" onclick="find_username(this.href); return false;">'. $this->user->lang['FIND_USERNAME'] .'</a> ]';
	}

	public function shout_score_type($value, $key)
	{
		$option_ary = array();
		for ($i=1; $i<=count($this->user->lang['ARCADE_SHOUT_SCORE_TYPES']);$i++)
		{
			$option_ary += array($i => $this->user->lang['ARCADE_SHOUT_SCORE_TYPES'][$i]);
		}

		return $this->arcade->build_select($option_ary, $value);
	}

	public function ignore_cat($value, $key)
	{
		$ignore_cat_ids = array_map('intval', explode(',', $value));
		return '<select multiple="multiple" size="10" name="' . $key . '[]" id="' . $key . '">
					<option value="0">' . $this->user->lang['ARCADE_SELECT_CAT'] . '</option>
					' . $this->arcade->make_cat_select($ignore_cat_ids, false, true, true) . '
				</select>';
	}

	/**
	* Arcade disable option and message
	*/
	public function arcade_disable($value, $key)
	{
		$radio_ary = array(1 => 'YES', 0 => 'NO');

		return h_radio("config[{$key}]", $radio_ary, $value) . '<br><br><input id="' . $key . '" type="text" name="config[' . $key . '_msg]" maxlength="255" size="50" value="' . $this->new_config["{$key}_msg"] . '">';
	}

	public function arcade_default_style($value, $key)
	{
		return '<option value="0">' . $this->user->lang['DEFAULT_STYLE'] . '</option>' . style_select($value, true);
	}

	public function display_page($value, $key)
	{
		$option_ary = array();
		if ($key == 'tour_display_news')
		{
			$option_ary += array(ARCADE_NO_DISPLAY => 'ARCADE_NO_DISPLAY');
		}

		$option_ary += array(ARCADE_DISPLAY_ARCADE => 'ARCADE_PAGES');

		$option_ary += array(ARCADE_DISPLAY_EVERY => 'ARCADE_EVERY_PAGE');

		if ($this->arcade->portal->data['show'])
		{
			$option_ary += array(ARCADE_DISPLAY_EVERY_EXCEPT_PORTAL => 'ARCADE_EVERY_PAGE_EXCEPT_PORTAL');
		}

		return $this->arcade->build_select($option_ary, $value);
	}

	public function load_list($value, $key)
	{
		$radio_ary = array(1 => 'ARCADE_LOAD_LIST_ALWAYS', 0 => 'ARCADE_LOAD_LIST_ONCLICK');
		return h_radio("config[$key]", $radio_ary, $value, $key);
	}

	public function paar($value, $key)
	{
		return '<label><input type="radio" class="radio" ' . (($value == -1) ? 'checked="checked" id="' . $key . '" ' : '') . 'value="-1" name="config[' . $key . ']"> ' . $this->user->lang['ARCADE_NO_DISPLAY'] . '<br><br></label>
				<label><input type="radio" class="radio" ' . (($value ==  0) ? 'checked="checked" id="' . $key . '" ' : '') . 'value="0"  name="config[' . $key . ']"> <img src="' . $this->arcade_config['connect_domain'] . 'activity_rank.php?url=' . $this->arcade_config['support_domain'] . '" alt=""><br><br></label>
				<label><input type="radio" class="radio" ' . (($value ==  1) ? 'checked="checked" id="' . $key . '" ' : '') . 'value="1"  name="config[' . $key . ']"> <img src="' . $this->arcade_config['connect_domain'] . 'activity_rank.php?url=' . $this->arcade_config['support_domain'] . '&amp;type=1" alt=""><br><br></label>
				<label><input type="radio" class="radio" ' . (($value ==  2) ? 'checked="checked" id="' . $key . '" ' : '') . 'value="2"  name="config[' . $key . ']"> <img src="' . $this->arcade_config['connect_domain'] . 'activity_rank.php?url=' . $this->arcade_config['support_domain'] . '&amp;type=2" alt=""></label>';
	}

	public function left_right($value)
	{
		$option_ary = array(
			'l'	=> 'ARCADE_LEFT',
			'r'	=> 'ARCADE_RIGHT'
		);

		return $this->arcade->build_select($option_ary, $value);
	}

	public function select_lang($value)
	{
		return '<option value="">' . $this->user->lang['ARCADE_MIXED_LANG'] . '</option>' . language_select($value);
	}

	public function score_security_level($value)
	{
		$option_ary = array(
			SCORE_SECURITY_LOW		=> 'LOW',
			SCORE_SECURITY_MEDIUM	=> 'MEDIUM',
			SCORE_SECURITY_HIGH		=> 'HIGH'
		);

		return $this->arcade->build_select($option_ary, $value);
	}

	public function download_file_type_select($value)
	{
		$return = '<option value=""' . (($value == '') ? ' selected="selected"' : '') . '>' . $this->user->lang['FREELY_OPTIONAL'] . '</option>';

		foreach ($this->arcade->compress_methods() as $method)
		{
			$return .= '<option value="' . $method . '"' . (($value == $method)	? ' selected="selected"' : '') . '>' . $method . '</option>';
		}

		return $return;
	}

	public function download_per_day_groups($value, $key)
	{
		$return = '';
		$groups = array();
		$group_helper = $this->arcade->container('phpbb_group_helper');

		$sql = 'SELECT group_id, group_name, group_type
				FROM ' . GROUPS_TABLE . "
				WHERE group_name NOT IN ('BOTS')
				ORDER BY group_type DESC, group_name ASC";
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$groups[$row['group_id']] = array(
				'group_name' => $row['group_name'],
				'group_type' => $row['group_type']
			);
		}
		$this->db->sql_freeresult($result);

		if (count($groups))
		{
			$groups_days = $this->arcade->download_groups_days(array_keys($groups), $value);

			foreach ($groups as $group_id => $data)
			{
				$days = (!empty($groups_days[$group_id])) ? (int) $groups_days[$group_id] : 0;
				$return .= (($return != '') ? '<br>' : '') . '<input type="number" id="' . $key . '_' . $group_id . '" name="config[' . $key . '_' . $group_id . ']" min="0" max="9999" maxlength="4" value="' . $days . '"> <span' . (($data['group_type'] == GROUP_SPECIAL) ? ' class="sep"' : '') . '>' . $group_helper->get_name($data['group_name']) . '</span>';
			}

			$return .= '<input type="hidden" id="' . $key . '" name="config[' . $key . ']" value="1">';
		}

		return $return;
	}

	public function search_check_select($value)
	{
		$option_ary = array(
			ARCADE_CHECK_EVERYONE		=> 'ACP_ARCADE_CHECK_EVERYONE',
			ARCADE_CHECK_USER_NORMAL	=> 'ACP_ARCADE_CHECK_USER_NORMAL',
			ARCADE_CHECK_DISABLED		=> 'ACP_ARCADE_CHECK_DISABLED'
		);

		return $this->arcade->build_select($option_ary, $value);
	}

	public function validate_configs($config_vars, &$cfg_array, &$error, $submit)
	{
		$validate_configs = array();
		foreach ($config_vars as $config_name => $config_definition)
		{
			if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
			{
				continue;
			}

			$validate_configs[$config_name] = true;
		}

		if (isset($validate_configs['session_length']))
		{
			$arcade_session_length = (int) $cfg_array['session_length'];

			if ($this->config['session_length'] < $arcade_session_length)
			{
				$error[] = $this->user->lang['ARCADE_PHPBB_SESSION_LENGTH_NOTICE'];

				if ($this->auth->acl_get('a_server'))
				{
					$error[] = '<br>' . sprintf($this->user->lang['ARCADE_PHPBB_SESSION_LENGTH_LINK'], '<a href="' . append_sid("{$this->admin_path}index.{$this->php_ext}", 'i=board&amp;mode=load') . '">', '</a>');
				}
			}
		}

		if (isset($validate_configs['flash_version']))
		{
			$cfg_array['flash_version'] = $this->delete_last_chars($cfg_array['flash_version'], '.');
			$min_flash_version = '28.0.0.0';
			if (phpbb_version_compare($cfg_array['flash_version'], $min_flash_version, '<'))
			{
				$error[] = sprintf($this->user->lang['ACP_ARCADE_FLASH_PLAYER_VERSION_EXPLAIN'], $min_flash_version);
			}
		}

		if (isset($validate_configs['download_per_day_groups']))
		{
			$v = '';
			foreach ($cfg_array as $cn => $cv)
			{
				$cv = (int) $cv;
				if (strpos($cn, 'download_per_day_groups_') !== false && $cv > 0)
				{
					$group_id = intval(str_replace('download_per_day_groups_', '', $cn));
					$v .= (($v != '') ? ',' : '') . "$group_id:$cv";
				}
			}

			if ($v)
			{
				$this->arcade->max_chars($v);
				$cfg_array['download_per_day_groups'] = $v;
			}
		}

		if ($submit && $this->arcade->shout->data['installed'])
		{
			if (isset($validate_configs['shout_user_id']) && $cfg_array['shout_user_id'])
			{
				if (!($cfg_array['shout_user_id'] = $this->arcade->userdata('user_id', (is_numeric($cfg_array['shout_user_id'])) ? $cfg_array['shout_user_id'] : false, (is_numeric($cfg_array['shout_user_id'])) ? false : $cfg_array['shout_user_id'])))
				{
					$error[] = $this->user->lang['NO_USER'];
				}
			}

			$cfg_array['shout_ignore_cats'] = '';
			if ($ignore_cats = $this->request->variable('shout_ignore_cats', array(0)))
			{
				$v = '';
				foreach ($ignore_cats as $cat_id)
				{
					if (!$cat_id)
					{
						continue;
					}

					$v .= (($v != '') ? ',' : '') . (int) $cat_id;
				}

				if ($v)
				{
					$this->arcade->max_chars($v);
					$cfg_array['shout_ignore_cats'] = $v;
				}
			}
		}

		if (isset($validate_configs['auto_disable']) && isset($validate_configs['auto_disable_start']) && isset($validate_configs['auto_disable_end']))
		{
			if ($cfg_array['auto_disable_start'] == '' && $cfg_array['auto_disable_end'] == '')
			{
				$cfg_array['auto_disable'] = 0;
				return;
			}

			if (!count($start_ary = $this->arcade->validate_time($cfg_array['auto_disable_start'])))
			{
				$error[] = sprintf($this->user->lang['ARCADE_AUTO_DISABLE_START_ERROR'], $cfg_array['auto_disable_start']);
			}

			if (!count($end_ary = $this->arcade->validate_time($cfg_array['auto_disable_end'])))
			{
				$error[] = sprintf($this->user->lang['ARCADE_AUTO_DISABLE_END_ERROR'], $cfg_array['auto_disable_end']);
			}

			if (count($start_ary) && count($end_ary))
			{
				if (($start_ary['hour'] > $end_ary['hour']) || ($start_ary['hour'] == $end_ary['hour'] && $start_ary['min'] >= $end_ary['min']))
				{
					$error[] = $this->user->lang['ARCADE_AUTO_DISABLE_START_END_ERROR'];
				}
			}
		}
	}

	public function delete_last_chars($text, $chars)
	{
		if ($text != '')
		{
			$lenght = strlen($text);

			for ($i=0; $i < $lenght; $i++)
			{
				if ($text[strlen($text) - 1] === $chars)
				{
					$text = substr($text, 0, -1);
				}
				else
				{
					break;
				}
			}
		}

		return $text;
	}

	public function challenge_users_select($value, $key)
	{
		$radio_ary = array(0 => 'ACP_ARCADE_TEXT', 1 => 'ACP_ARCADE_SELECT');
		return h_radio("config[$key]", $radio_ary, $value, $key);
	}

	public function challenge_exp_date_select($value)
	{
		return '<option value="86400"	' . (($value == 86400)		? ' selected="selected"' : '') . '>1	' . $this->user->lang['DAY'] . '</option>
				<option value="172800"	' . (($value == 172800)		? ' selected="selected"' : '') . '>2	' . $this->user->lang['DAYS'] . '</option>
				<option value="604800"	' . (($value == 604800)		? ' selected="selected"' : '') . '>7	' . $this->user->lang['DAYS'] . '</option>
				<option value="1209600"	' . (($value == 1209600)	? ' selected="selected"' : '') . '>14	' . $this->user->lang['DAYS'] . '</option>
				<option value="2592000"	' . (($value == 2592000)	? ' selected="selected"' : '') . '>30	' . $this->user->lang['DAYS'] . '</option>';
	}
}
