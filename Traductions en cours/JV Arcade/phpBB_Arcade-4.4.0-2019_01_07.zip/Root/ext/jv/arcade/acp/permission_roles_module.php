<?php
/**
*
* @package phpBB Arcade
* @version $Id: permission_roles_module.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class permission_roles_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $auth_admin;
	protected $permissions;

	protected $db, $request, $user, $template, $root_path, $php_ext;
	protected $arcade;

	public function __construct()
	{
		global $db, $request, $user, $template, $phpbb_root_path, $phpEx;
		global $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->auth_admin = $arcade->container('auth_admin');
		$this->permissions = $arcade->container('phpbb_acl.permissions');

		$this->db = $db;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
		$this->arcade = $arcade;
	}

	public function main($id, $mode)
	{
		if (!function_exists('user_add'))
		{
			include($this->root_path . 'includes/functions_user.' . $this->php_ext);
		}

		$this->user->add_lang('acp/permissions');
		add_permission_language();

		$this->tpl_name = 'arcade/acp_permission_roles';

		$submit = $this->arcade->is_post_empty('submit');
		$role_id = $this->request->variable('role_id', 0);
		$action = $this->request->variable('action', '');
		$action = ($this->arcade->is_post_empty('add')) ? 'add' : $action;

		$form_name = 'acp_permissions';
		add_form_key($form_name);

		if (!$role_id && in_array($action, array('remove', 'edit', 'move_up', 'move_down')))
		{
			trigger_error($this->user->lang['NO_ROLE_SELECTED'] . adm_back_link($this->u_action), E_USER_WARNING);
		}

		switch ($mode)
		{
			case 'cat_roles':
				$permission_type = 'c_';
				$this->page_title = 'ACP_ARCADE_CAT_ROLES';
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		$this->template->assign_vars(array(
			'U_ACTION'	=> $this->u_action,
			'L_TITLE'	=> $this->user->lang[$this->page_title],
			'L_EXPLAIN'	=> $this->user->lang[$this->page_title . '_EXPLAIN']
		));

		// Take action... admin submitted something
		if ($submit || $action == 'remove')
		{
			switch ($action)
			{
				case 'remove':
					$sql = 'SELECT *
							FROM ' . ACL_ARCADE_ROLES_TABLE . '
							WHERE role_id = ' . $role_id;
					$result = $this->db->sql_query($sql);
					$role_row = $this->db->sql_fetchrow($result);
					$this->db->sql_freeresult($result);

					if (!$role_row)
					{
						trigger_error($this->user->lang['NO_ROLE_SELECTED'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					if (confirm_box(true))
					{
						$this->remove_role($role_id, $permission_type);

						$role_name = (!empty($this->user->lang[$role_row['role_name']])) ? $this->user->lang[$role_row['role_name']] : $role_row['role_name'];
						$this->arcade->add_log('admin', 'LOG_' . strtoupper($permission_type) . 'ROLE_REMOVED', $role_name);
						trigger_error($this->user->lang['ROLE_DELETED'] . adm_back_link($this->u_action));
					}
					else
					{
						confirm_box(false, 'DELETE_ROLE', build_hidden_fields(array(
							'i'			=> $id,
							'mode'		=> $mode,
							'role_id'	=> $role_id,
							'action'	=> $action,
						)));
					}
				break;

				case 'edit':
					// Get role we edit
					$sql = 'SELECT *
							FROM ' . ACL_ARCADE_ROLES_TABLE . '
							WHERE role_id = ' . $role_id;
					$result = $this->db->sql_query($sql);
					$role_row = $this->db->sql_fetchrow($result);
					$this->db->sql_freeresult($result);

					if (!$role_row)
					{
						trigger_error($this->user->lang['NO_ROLE_SELECTED'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

				// no break;

				case 'add':
					if (!check_form_key($form_name))
					{
						trigger_error($this->user->lang['FORM_INVALID']. adm_back_link($this->u_action), E_USER_WARNING);
					}

					$role_name = $this->request->variable('role_name', '', true);
					$role_description = $this->request->variable('role_description', '', true);
					$auth_settings = $this->request->variable('setting', array('' => 0));

					if (!$role_name)
					{
						trigger_error($this->user->lang['NO_ROLE_NAME_SPECIFIED'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					if (utf8_strlen($role_description) > 4000)
					{
						trigger_error($this->user->lang['ROLE_DESCRIPTION_LONG'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					// if we add/edit a role we check the name to be unique among the settings...
					$sql = 'SELECT role_id
							FROM ' . ACL_ARCADE_ROLES_TABLE . "
							WHERE role_type = '" . $this->db->sql_escape($permission_type) . "'
							AND role_name = '" . $this->db->sql_escape($role_name) . "'";
					$result = $this->db->sql_query($sql);
					$row = $this->db->sql_fetchrow($result);
					$this->db->sql_freeresult($result);

					// Make sure we only print out the error if we add the role or change it's name
					if ($row && ($mode == 'add' || ($mode == 'edit' && $role_row['role_name'] != $role_name)))
					{
						trigger_error(sprintf($this->user->lang['ROLE_NAME_ALREADY_EXIST'], $role_name) . adm_back_link($this->u_action), E_USER_WARNING);
					}

					$sql_ary = array(
						'role_name'			=> (string) $role_name,
						'role_description'	=> (string) $role_description,
						'role_type'			=> (string) $permission_type,
					);

					if ($action == 'edit')
					{
						$sql = 'UPDATE ' . ACL_ARCADE_ROLES_TABLE . '
								SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
								WHERE role_id = ' . $role_id;
						$this->db->sql_query($sql);
					}
					else
					{
						// Get maximum role order for inserting a new role...
						$sql = 'SELECT MAX(role_order) as max_order
								FROM ' . ACL_ARCADE_ROLES_TABLE . "
								WHERE role_type = '" . $this->db->sql_escape($permission_type) . "'";
						$result = $this->db->sql_query($sql);
						$max_order = (int) $this->db->sql_fetchfield('max_order');
						$this->db->sql_freeresult($result);

						$sql_ary['role_order'] = $max_order + 1;

						$sql = 'INSERT INTO ' . ACL_ARCADE_ROLES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
						$this->db->sql_query($sql);

						$role_id = $this->db->sql_nextid();
					}

					// Now add the auth settings
					$this->auth_admin->acl_set_role($role_id, $auth_settings);

					$role_name = (!empty($this->user->lang[$role_name])) ? $this->user->lang[$role_name] : $role_name;
					$this->arcade->add_log('admin', 'LOG_' . strtoupper($permission_type) . 'ROLE_' . strtoupper($action), $role_name);

					trigger_error($this->user->lang['ROLE_' . strtoupper($action) . '_SUCCESS'] . adm_back_link($this->u_action));
				break;
			}
		}

		// Display screens
		switch ($action)
		{
			case 'add':
				$options_from = $this->request->variable('options_from', 0);

				$role_row = array(
					'role_name'			=> $this->request->variable('role_name', '', true),
					'role_description'	=> $this->request->variable('role_description', '', true),
					'role_type'			=> $permission_type,
				);

				if ($options_from)
				{
					$sql = 'SELECT p.auth_option_id, p.auth_setting, o.auth_option
							FROM ' . ACL_ARCADE_ROLES_DATA_TABLE . ' p, ' . ACL_ARCADE_OPTIONS_TABLE . ' o
							WHERE o.auth_option_id = p.auth_option_id
							AND p.role_id = ' . $options_from . '
							ORDER BY p.auth_option_id';
					$result = $this->db->sql_query($sql);

					$auth_options = array();
					while ($row = $this->db->sql_fetchrow($result))
					{
						$auth_options[$row['auth_option']] = $row['auth_setting'];
					}
					$this->db->sql_freeresult($result);
				}
				else
				{
					$sql = 'SELECT auth_option_id, auth_option
							FROM ' . ACL_ARCADE_OPTIONS_TABLE . "
							WHERE auth_option " . $this->db->sql_like_expression($permission_type . $this->db->get_any_char()) . "
							AND auth_option <> '{$permission_type}'
							ORDER BY auth_option_id";
					$result = $this->db->sql_query($sql);

					$auth_options = array();
					while ($row = $this->db->sql_fetchrow($result))
					{
						$auth_options[$row['auth_option']] = ACL_NO;
					}
					$this->db->sql_freeresult($result);
				}

			// no break;

			case 'edit':
				if ($action == 'edit')
				{
					$sql = 'SELECT *
							FROM ' . ACL_ARCADE_ROLES_TABLE . '
							WHERE role_id = ' . $role_id;
					$result = $this->db->sql_query($sql);
					$role_row = $this->db->sql_fetchrow($result);
					$this->db->sql_freeresult($result);

					$sql = 'SELECT p.auth_option_id, p.auth_setting, o.auth_option
							FROM ' . ACL_ARCADE_ROLES_DATA_TABLE . ' p, ' . ACL_ARCADE_OPTIONS_TABLE . ' o
							WHERE o.auth_option_id = p.auth_option_id
							AND p.role_id = ' . $role_id . '
							ORDER BY p.auth_option_id';
					$result = $this->db->sql_query($sql);

					$auth_options = array();
					while ($row = $this->db->sql_fetchrow($result))
					{
						$auth_options[$row['auth_option']] = $row['auth_setting'];
					}
					$this->db->sql_freeresult($result);
				}

				if (!$role_row)
				{
					trigger_error($this->user->lang['NO_ROLE_SELECTED'] . adm_back_link($this->u_action), E_USER_WARNING);
				}

				$this->template->assign_vars(array(
					'S_EDIT'			=> true,

					'U_ACTION'			=> $this->u_action . "&amp;action={$action}&amp;role_id={$role_id}",
					'U_BACK'			=> $this->u_action,

					'ROLE_NAME'			=> $role_row['role_name'],
					'ROLE_DESCRIPTION'	=> $role_row['role_description'],
					'L_ACL_TYPE'		=> $this->permissions->get_type_lang($permission_type),
				));

				// We need to fill the auth options array with ACL_NO options ;)
				$sql = 'SELECT auth_option_id, auth_option
						FROM ' . ACL_ARCADE_OPTIONS_TABLE . "
						WHERE auth_option " . $this->db->sql_like_expression($permission_type . $this->db->get_any_char()) . "
						AND auth_option <> '{$permission_type}'
						ORDER BY auth_option_id";
				$result = $this->db->sql_query($sql);

				while ($row = $this->db->sql_fetchrow($result))
				{
					if (!isset($auth_options[$row['auth_option']]))
					{
						$auth_options[$row['auth_option']] = ACL_NO;
					}
				}
				$this->db->sql_freeresult($result);

				// Unset global permission option
				unset($auth_options[$permission_type]);

				// Display auth options
				$this->display_auth_options($auth_options);

				// Get users/groups/categories using this preset...
				if ($action == 'edit')
				{
					$hold_ary = $this->auth_admin->get_role_mask($role_id);

					if (count($hold_ary))
					{
						$role_name = (!empty($this->user->lang[$role_row['role_name']])) ? $this->user->lang[$role_row['role_name']] : $role_row['role_name'];

						$this->template->assign_vars(array(
							'S_DISPLAY_ROLE_MASK'	=> true,
							'L_ROLE_ASSIGNED_TO'	=> sprintf($this->user->lang['ROLE_ASSIGNED_TO'], $role_name))
						);

						$this->auth_admin->display_role_mask($hold_ary);
					}
				}

				return;
			break;

			case 'move_up':
			case 'move_down':
				$sql = 'SELECT role_order
					FROM ' . ACL_ROLES_TABLE . "
					WHERE role_id = $role_id";
				$result = $this->db->sql_query($sql);
				$order = $this->db->sql_fetchfield('role_order');
				$this->db->sql_freeresult($result);

				if ($order === false || ($order == 0 && $action == 'move_up'))
				{
					break;
				}
				$order = (int) $order;
				$order_total = $order * 2 + (($action == 'move_up') ? -1 : 1);

				$sql = 'UPDATE ' . ACL_ARCADE_ROLES_TABLE . '
						SET role_order = ' . $order_total . " - role_order
						WHERE role_type = '" . $this->db->sql_escape($permission_type) . "'
						AND role_order IN ($order, " . (($action == 'move_up') ? $order - 1 : $order + 1) . ')';
				$this->db->sql_query($sql);

				if ($this->request->is_ajax())
				{
					$json_response = new \phpbb\json_response;
					$json_response->send(array(
						'success' => (bool) $this->db->sql_affectedrows(),
					));
				}
			break;
		}

		// By default, check that role_order is valid and fix it if necessary
		$sql = 'SELECT role_id, role_order
				FROM ' . ACL_ARCADE_ROLES_TABLE . "
				WHERE role_type = '" . $this->db->sql_escape($permission_type) . "'
				ORDER BY role_order ASC";
		$result = $this->db->sql_query($sql);

		if ($row = $this->db->sql_fetchrow($result))
		{
			$order = 0;
			do
			{
				$order++;
				if ($row['role_order'] != $order)
				{
					$this->db->sql_query('UPDATE ' . ACL_ARCADE_ROLES_TABLE . " SET role_order = $order WHERE role_id = {$row['role_id']}");
				}
			}
			while ($row = $this->db->sql_fetchrow($result));
		}
		$this->db->sql_freeresult($result);

		// Display assigned items?
		$display_item = $this->request->variable('display_item', 0);

		// Select existing roles
		$sql = 'SELECT *
				FROM ' . ACL_ARCADE_ROLES_TABLE . "
				WHERE role_type = '" . $this->db->sql_escape($permission_type) . "'
				ORDER BY role_order ASC";
		$result = $this->db->sql_query($sql);

		$s_role_options = '';
		while ($row = $this->db->sql_fetchrow($result))
		{
			$role_name = (!empty($this->user->lang[$row['role_name']])) ? $this->user->lang[$row['role_name']] : $row['role_name'];

			$this->template->assign_block_vars('roles', array(
				'ROLE_NAME'			=> $role_name,
				'ROLE_DESCRIPTION'	=> (!empty($this->user->lang[$row['role_description']])) ? $this->user->lang[$row['role_description']] : nl2br($row['role_description']),

				'U_EDIT'			=> $this->u_action . '&amp;action=edit&amp;role_id=' . $row['role_id'],
				'U_REMOVE'			=> $this->u_action . '&amp;action=remove&amp;role_id=' . $row['role_id'],
				'U_MOVE_UP'			=> $this->u_action . '&amp;action=move_up&amp;role_id=' . $row['role_id'],
				'U_MOVE_DOWN'		=> $this->u_action . '&amp;action=move_down&amp;role_id=' . $row['role_id'],
				'U_DISPLAY_ITEMS'	=> ($row['role_id'] == $display_item) ? '' : $this->u_action . '&amp;display_item=' . $row['role_id'] . '#assigned_to'
			));

			$s_role_options .= '<option value="' . $row['role_id'] . '">' . $role_name . '</option>';

			if ($display_item == $row['role_id'])
			{
				$this->template->assign_var('L_ROLE_ASSIGNED_TO', sprintf($this->user->lang['ROLE_ASSIGNED_TO'], $role_name));
			}
		}
		$this->db->sql_freeresult($result);

		$this->template->assign_var('S_ROLE_OPTIONS', $s_role_options);

		if ($display_item)
		{
			$this->template->assign_var('S_DISPLAY_ROLE_MASK', true);

			$hold_ary = $this->auth_admin->get_role_mask($display_item);
			$this->auth_admin->display_role_mask($hold_ary);
		}
	}

	/**
	* Display permission settings able to be set
	*/
	public function display_auth_options($auth_options)
	{
		$content_array = $categories = array();
		$key_sort_array = array(0);
		$auth_options = array(0 => $auth_options);

		// Making use of auth_admin method here (we do not really want to change two similar code fragments)
		$this->auth_admin->build_permission_array($auth_options, $content_array, $categories, $key_sort_array);

		$content_array = $content_array[0];

		$this->template->assign_var('S_NUM_PERM_COLS', count($categories));

		// Assign to template
		foreach ($content_array as $cat => $cat_array)
		{
			$this->template->assign_block_vars('auth', array(
				'CAT_NAME'	=> $this->permissions->get_category_lang($cat),

				'S_YES'		=> ($cat_array['S_YES'] && !$cat_array['S_NEVER'] && !$cat_array['S_NO']) ? true : false,
				'S_NEVER'	=> ($cat_array['S_NEVER'] && !$cat_array['S_YES'] && !$cat_array['S_NO']) ? true : false,
				'S_NO'		=> ($cat_array['S_NO'] && !$cat_array['S_NEVER'] && !$cat_array['S_YES']) ? true : false)
			);

			foreach ($cat_array['permissions'] as $permission => $allowed)
			{
				$this->template->assign_block_vars('auth.mask', array(
					'S_YES'			=> ($allowed == ACL_YES) ? true : false,
					'S_NEVER'		=> ($allowed == ACL_NEVER) ? true : false,
					'S_NO'			=> ($allowed == ACL_NO) ? true : false,

					'FIELD_NAME'	=> $permission,
					'PERMISSION'	=> $this->permissions->get_permission_lang($permission)
				));
			}
		}
	}

	/**
	* Remove role
	*/
	public function remove_role($role_id, $permission_type)
	{
		// Get complete auth array
		$sql = 'SELECT auth_option, auth_option_id
				FROM ' . ACL_ARCADE_OPTIONS_TABLE . "
				WHERE auth_option " . $this->db->sql_like_expression($permission_type . $this->db->get_any_char());
		$result = $this->db->sql_query($sql);

		$auth_settings = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$auth_settings[$row['auth_option']] = ACL_NO;
		}
		$this->db->sql_freeresult($result);

		// Get the role auth settings we need to re-set...
		$sql = 'SELECT o.auth_option, r.auth_setting
				FROM ' . ACL_ARCADE_ROLES_DATA_TABLE . ' r, ' . ACL_ARCADE_OPTIONS_TABLE . ' o
				WHERE o.auth_option_id = r.auth_option_id
				AND r.role_id = ' . $role_id;
		$result = $this->db->sql_query($sql);

		while ($row = $this->db->sql_fetchrow($result))
		{
			$auth_settings[$row['auth_option']] = $row['auth_setting'];
		}
		$this->db->sql_freeresult($result);

		// Get role assignments
		$hold_ary = $this->auth_admin->get_role_mask($role_id);

		// Re-assign permissions
		foreach ($hold_ary as $cat_id => $cat_ary)
		{
			if (isset($cat_ary['users']))
			{
				$this->auth_admin->acl_set('user', $cat_id, $cat_ary['users'], $auth_settings, 0, false);
			}

			if (isset($cat_ary['groups']))
			{
				$this->auth_admin->acl_set('group', $cat_id, $cat_ary['groups'], $auth_settings, 0, false);
			}
		}

		// Remove role from users and groups just to be sure (happens through acl_set)
		$sql = 'DELETE FROM ' . ACL_ARCADE_USERS_TABLE . '
				WHERE auth_role_id = ' . $role_id;
		$this->db->sql_query($sql);

		$sql = 'DELETE FROM ' . ACL_ARCADE_GROUPS_TABLE . '
				WHERE auth_role_id = ' . $role_id;
		$this->db->sql_query($sql);

		// Remove role data and role
		$sql = 'DELETE FROM ' . ACL_ARCADE_ROLES_DATA_TABLE . '
				WHERE role_id = ' . $role_id;
		$this->db->sql_query($sql);

		$sql = 'DELETE FROM ' . ACL_ARCADE_ROLES_TABLE . '
				WHERE role_id = ' . $role_id;
		$this->db->sql_query($sql);

		$this->auth_admin->acl_clear_prefetch();
	}
}
