<?php
/**
*
* @package phpBB Arcade
* @version $Id: games_module.php 2139 2019-01-07 11:57:04Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class games_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	private $parent_id = 0;

	protected $db, $cache, $request, $user, $template, $root_path, $php_ext;
	protected $arcade_cache, $arcade_config, $arcade, $file_functions;

	public function __construct()
	{
		global $db, $cache, $request, $user, $template, $phpbb_root_path, $phpEx;
		global $arcade_cache, $arcade_config, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->db = $db;
		$this->cache = $cache;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
		$this->file_functions = $this->arcade->container('functions_file');
	}

	public function main($id, $mode)
	{
		$this->tpl_name = 'arcade/acp_games';
		$this->page_title = $this->user->lang['ACP_ARCADE_' . strtoupper($mode)];

		$error = array();
		$start = (int) $this->request->variable('start', 0);
		$this->arcade->valid_start($start);

		switch ($mode)
		{
			case 'add_games':
				$form_key = 'acp_arcade_games';
				add_form_key($form_key);

				$game_array = $this->request->variable('games', array(''));

				if ($this->arcade->is_post_empty('update'))
				{
					if (!check_form_key($form_key))
					{
						trigger_error($this->user->lang['FORM_INVALID'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					// Get game to add and make sure it is not blank
					if (empty($game_array))
					{
						trigger_error($this->user->lang['NO_GAME_ID'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					// Get category to add game to and make sure it is valid
					$cat_data = $this->arcade->get_cat_info($this->request->variable('cat_id', 0));
					if ($cat_data['cat_type'] != ARCADE_CAT_GAMES)
					{
						trigger_error($this->user->lang['WRONG_CAT_TYPE'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					// Add game to database
					$announce_games = $game_names = $swf_games = array();
					foreach ($game_array as $game)
					{
						if (!($game_data = $this->arcade->add_game($game, $cat_data['cat_id'])))
						{
							continue;
						}

						if ($this->arcade_config['game_announce'])
						{
							$game_data['cat_name'] = $cat_data['cat_name'];
							$announce_games[] = $game_data;
						}

						$game_names[] = $game_data['game_name'];
						$swf_games[] = $game;
					}

					if (count($announce_games))
					{
						$this->arcade->phpbb()->create_game_announcement($announce_games);
					}

					if (!count($game_names))
					{
						trigger_error($this->user->lang['NO_GAME_ID'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					$this->arcade->old_delete_games('delete', $swf_games);
					$this->arcade_config->increment('install_games', count($game_names));

					$this->arcade->cache_purge();

					$s = (count($game_names) > 1) ? 'S' : '';
					$game_names = implode(', ', $game_names);
					$this->arcade->add_log('admin', "LOG_ARCADE_ADD_GAME{$s}", $cat_data['cat_name'], $game_names);
					trigger_error(sprintf($this->user->lang["ARCADE_ADD_GAME{$s}" . '_SUCCESS'], $game_names, $cat_data['cat_name']) . adm_back_link($this->u_action));
				}

				if ($this->arcade->is_post_empty('delete_files'))
				{
					if (!check_form_key($form_key))
					{
						trigger_error($this->user->lang['FORM_INVALID'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					// Get game to add and make s sure it is not blank
					if (empty($game_array))
					{
						trigger_error($this->user->lang['NO_GAME_ID'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					$game_data = array();
					foreach ($game_array as $game)
					{
						$game_data[] = array('game_swf' => "{$game}.swf");
					}

					if (count($game_data))
					{
						$error = $this->arcade->delete_files($game_data);
					}

					// Since there are permission errors we don't delete files or db entries.
					// We will display message to user. They can either fix the permission errors
					// or not check off the option to remove the files.
					if (count($error))
					{
						array_unshift($error, $this->user->lang['ARCADE_DELETE_FILES_ERROR_GAME']);
					}
					else
					{
						trigger_error($this->user->lang['ARCADE_GAME' . ((count($game_data) > 1) ? 'S' : '') . '_REMOVE_FILES_SUCCESS'] . adm_back_link($this->u_action));
					}
				}

				// Default Games ACP page
				$this->template->assign_var('S_ARCADE_GAMES', true);
				$parents_list = $this->arcade->make_cat_select($this->parent_id, false, true, true);
				if (!$parents_list)
				{
					trigger_error('NO_CAT', E_USER_WARNING);
				}

				$dir = $this->root_path . $this->arcade_config['game_path'];

				if (!file_exists($dir))
				{
					trigger_error($this->user->lang['NO_GAME_DIRECTORY'] . adm_back_link($this->u_action));
				}

				$games = $find_games = $games_name = array();
				$sql = 'SELECT game_swf, game_name from ' . ARCADE_GAMES_TABLE . '
						ORDER BY game_swf';
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$games[$this->file_functions->remove_extension($row['game_swf'])] = 1;
					$games_name[$row['game_name']] = 1;
				}
				$this->db->sql_freeresult($result);

				$s_game_options = '';
				$dup_games_ary = array(
					'add'		=> array(),
					'install'	=> array()
				);

				if ($files = scandir($dir))
				{
					foreach ($files as $file)
					{
						if (in_array($file, array('.', '..', '.svn')) || !empty($games[$file]) || !is_dir($dir . $file))
						{
							continue;
						}

						$install_file = $dir . $file . '/'. $file . '.' . $this->php_ext;

						if (($game_data = $this->arcade->game->install_file->data($dir, $file, $install_file)) !== false)
						{
							// We have the same duplicate gamename
							$game_name = $game_data['game_name'];
							unset($game_data);

							if (isset($games_name[$game_name]) || isset($find_games[$game_name]))
							{
								$duplicate_games = 0;
								$temp_name = $game_name;

								while (isset($games_name[$game_name]) || isset($find_games[$game_name]))
								{
									$duplicate_games++;
									$key = (isset($games_name[$game_name])) ? 'install' : 'add';
									$game_name = $temp_name . ' (' . $duplicate_games . ')';
									$dup_games_ary[$key][$game_name] = 1;
								}
							}

							$find_games[$game_name] = $file;

							if (count($find_games) >= $this->arcade_config['install_games_limit'])
							{
								break;
							}
						}
						else
						{
							$error[] = $this->arcade->root_key($install_file);
						}
					}
					unset($games_name);
				}
				unset($games);

				$total_games = count($find_games);

				if (!$total_games && !count($error))
				{
					trigger_error('NO_ADD_GAMES');
				}

				$old_games_count = $dup_games_add_count = $dup_games_ins_count = 0;
				ksort($find_games);

				$old_data = array();
				if ($total_games)
				{
					$old_data = $this->arcade->old_delete_games('load', array_values($find_games));
				}

				$add_games = $new_games = array();

				$dup_games_ins_count = $this->arcade->hunt_ary($add_games, $find_games, $dup_games_ary['install']);
				$dup_games_add_count = $this->arcade->hunt_ary($add_games, $find_games, $dup_games_ary['add']);
				$old_games_count	 = $this->arcade->hunt_ary($add_games, $find_games, $old_data, 'value');
				$new_games_count	 = $this->arcade->hunt_ary($new_games, $find_games, $find_games);
				$add_games = array_merge($new_games, $add_games);

				unset($new_games);

				foreach ($add_games as $key => $value)
				{
					if (!empty($dup_games_ary['install'][$key]))
					{
						$s_game_options .= '<option title="' . $this->user->lang['ARCADE_DUPLICATE_GAMENAME_INSTALL_GAMES'] . '" style="background-color: #AFFF76;" value="' . $value . '">' . $key . "</option>\n";
					}
					else if (!empty($dup_games_ary['add'][$key]))
					{
						$s_game_options .= '<option title="' . $this->user->lang['ARCADE_DUPLICATE_GAMENAME_ADD_GAMES'] . '" style="background-color: #FFFF4B;" value="' . $value . '">' . $key . "</option>\n";
					}
					else if (!empty($old_data[$value]))
					{
						$reason = ($old_data[$value]['reason']) ? $old_data[$value]['reason'] : $this->user->lang['ARCADE_NONE'];
						$s_game_options .= '<option title="' . sprintf($this->user->lang['ARCADE_OLD_GAME_UNINSTALL_DATE'], $this->user->format_date($old_data[$value]['date'], 'Y.m.d', true), $reason) . '" style="background-color: #FFB3B4;" value="' . $value . '">' . $key . "</option>\n";
					}
					else
					{
						$s_game_options .= '<option value="' . $value . '">' . $key . "</option>\n";
					}
				}
				unset($add_games);

				$this->template->assign_vars(array(
					'S_CAT_LIST'			=> $parents_list,
					'S_TOTAL_GAMES'			=> $total_games,
					'S_GAME_OPTIONS'		=> $s_game_options,

					'U_ACTION'				=> $this->u_action
				));

				if ($old_games_count || $dup_games_ins_count || $dup_games_add_count)
				{
					$games_msg  = ($old_games_count) ? $this->user->lang['ARCADE_OLD_GAME' . (($old_games_count > 1) ? 'S' : '') . '_UNINSTALL'] : '';
					$games_msg .= ($dup_games_ins_count) ? (($old_games_count) ? '<br>' : '') . $this->user->lang['ARCADE_DUPLICATE_INSTALL_GAMENAME' . (($dup_games_ins_count > 1) ? 'S' : '')] : '';
					$games_msg .= ($dup_games_add_count) ? (($old_games_count || $dup_games_ins_count) ? '<br>' : '') . $this->user->lang['ARCADE_DUPLICATE_ADD_GAMENAME' . (($dup_games_add_count > 1) ? 'S' : '')] : '';
					$games_msg .= '<br><br>' . $this->user->lang['ARCADE_DELETE_FILES_BUTTON'] . '<br>' . $this->user->lang['ARCADE_DELETE_FILES_WARNING'];

					$this->template->assign_vars(array(
						'S_ARCADE_DELETE_FILES'	=> true,
						'ARCADE_GAMES_MSG'		=> $games_msg,
					));
				}

				if (count($error))
				{
					$this->template->assign_vars(array(
						'S_ERROR'	=> true,
						'ERROR_MSG'	=> sprintf($this->user->lang['ARCADE_BAD_INSTALL_FILE' . ((count($error) > 1) ? 'S' : '')], implode('<br>', $error)),
					));
				}
			break;

			case 'unpack_games':
				$form_key = 'acp_arcade_games';
				add_form_key($form_key);

				$update = ($this->request->is_set_post('update')) ? true : false;
				$upload_file = ($this->request->is_set_post('add_file')) ? true : false;
				$re_unpack_games = ($this->request->is_set_post('re_unpack_games')) ? true : false;

				if (($upload_file || $update) && !check_form_key($form_key))
				{
					trigger_error($this->user->lang['FORM_INVALID'] . adm_back_link($this->u_action), E_USER_WARNING);
				}

				if ($upload_file)
				{
					$game_array = $this->upload_game($error);
					if (count($error))
					{
						trigger_error(implode('<br>', $error) . adm_back_link($this->u_action), E_USER_WARNING);
					}

					$update = true;
					$game_array = array($game_array);
				}

				$methods = $this->arcade->compress_methods();
				$unpack_game_path = $this->root_path . $this->arcade_config['unpack_game_path'];

				if ($update)
				{
					$errors = array();

					// Check permissions dirs writable
					$check_dirs = array('store/', 'games/', 'arcade/gamedata/', $this->arcade_config['game_path'], $this->arcade_config['unpack_game_path']);

					foreach ($check_dirs as $dir)
					{
						$path = $this->root_path . $dir;

						if (!file_exists($path))
						{
							$errors[] = sprintf($this->user->lang['NO_DIRECTORY'], $dir);
						}

						if (file_exists($path) && !phpbb_is_writable($path))
						{
							$errors[] = sprintf($this->user->lang['ARCADE_ERROR_DIR_WRITABLE'], $dir);
						}
					}

					if (count($errors))
					{
						trigger_error(implode('<br>', $errors) . adm_back_link($this->u_action), E_USER_WARNING);
					}

					include($this->root_path . 'includes/functions_compress.' . $this->php_ext);
					// Get game to add and makes sure it is not blank
					if (!$upload_file)
					{
						$game_array = $this->request->variable('games', array(''));
					}

					if (empty($game_array))
					{
						trigger_error($this->user->lang['NO_GAME_ID'] . adm_back_link($this->u_action));
					}

					// Add game to database
					$file_names = $bad_game = $bad_perm_game = $bad_game_install_file = array();

					foreach ($game_array as $key => $game)
					{
						$use_method = strrchr($game, '.');

						if ($use_method == '.zip')
						{
							$compress = new \compress_zip('r', $unpack_game_path . $game);
						}
						else
						{
							$compress = new \compress_tar('r', $unpack_game_path . $game);
						}

						// First we extract the compressed file to a temporary
						// directory in the store folder
						$tmp_path = $this->root_path . 'store/' . md5(unique_id()) . '/';

						$compress->extract($tmp_path);
						$compress->close();

						if (!file_exists($tmp_path) && class_exists('PharData'))
						{
							$phar = new \PharData($unpack_game_path . $game);
							$phar->extractTo($tmp_path, null, true);
							unset($phar);
						}

						if (!file_exists($tmp_path))
						{
							$bad_game[] = $game;
							unset($game_array[$key]);

							// We do not need the compressed file any more so lets get rid of it
							$this->file_functions->delete_file($unpack_game_path . $game);
							continue;
						}

						// Test for games that uses the games/ folder that needs to be at
						// the phpBB forum root
						if (file_exists($tmp_path . 'games/'))
						{
							$games_dir = $this->root_path . 'games/';

							if ((file_exists($games_dir) && !phpbb_is_writable($games_dir)) || (!file_exists($games_dir) && !phpbb_is_writable($this->root_path)))
							{
								$bad_perm_game[] = $game;
								unset($game_array[$key]);
								$this->file_functions->delete_dir($tmp_path);
								continue;
							}
						}

						if (!($game_filename = $this->arcade->game->install_file->convert($tmp_path, $this->file_functions->remove_extension($game), true)))
						{
							$bad_game_install_file[] = $game;
							unset($game_array[$key]);
							$this->file_functions->delete_dir($tmp_path);

							// We do not need the compressed file any more so lets get rid of it
							$this->file_functions->delete_file($unpack_game_path . $game);
							continue;
						}

						// We do not need the compressed file any more so lets get rid of it
						$this->file_functions->delete_file($unpack_game_path . $game);

						// If the gamedata folder exists move it to the correct location
						if (file_exists($tmp_path . 'gamedata'))
						{
							//Copy and delete
							$this->file_functions->copy_dir($tmp_path . 'gamedata', $this->root_path . 'arcade/gamedata');
							$this->file_functions->delete_dir($tmp_path . 'gamedata');
						}

						// If the games folder exists move it to the correct location
						if (file_exists($tmp_path . 'games'))
						{
							if (file_exists($tmp_path . 'games/' . $game_filename . '.swf'))
							{
								// no use games folder
								$this->file_functions->move_file($tmp_path . 'games/' . $game_filename . '.swf', $tmp_path . $game_filename . '.swf');
							}

							$this->file_functions->copy_dir($tmp_path . 'games', $this->root_path . 'games');

							$this->file_functions->delete_dir($tmp_path . 'games');
						}

						$file_names[] = $game;
						$this->file_functions->copy_dir($tmp_path, $this->root_path . $this->arcade_config['game_path'] . $game_filename);
						$this->file_functions->delete_dir($tmp_path);
					}

					$s_bad_game = count($bad_game);
					$s_bad_perm_game = count($bad_perm_game);
					$s_bad_game_install_file = count($bad_game_install_file);
					$s_game_array = count($game_array);

					$message = ($s_game_array && $upload_file) ? $this->user->lang['ARCADE_UPLOAD_COMPLETE'] : '';

					if ($s_bad_game)
					{
						$key = 'ARCADE_UNPACK_GAME' . (($s_bad_game > 1) ? 'S' : '') . '_ERROR';
						$message .= (($message) ? '<br><br>' : '') . '<strong>' . sprintf($this->user->lang[$key], '<span style="font-weight: normal;">' . implode(', ', $bad_game) . '</span>') . '</strong>';
					}

					if ($s_bad_perm_game)
					{
						$key = 'ARCADE_UNPACK_GAME' . (($s_bad_perm_game > 1) ? 'S' : '') . '_PERM_ERROR';
						$message .= (($message) ? '<br><br>' : '') . '<strong>' . sprintf($this->user->lang[$key], '<span style="font-weight: normal;">' . implode(', ', $bad_perm_game) . '</span>') . '</strong>';
					}

					if ($s_bad_game_install_file)
					{
						$key = 'GAME' . (($s_bad_game_install_file > 1) ? 'S' : '') . '_INSTALL_FILE_NOT_FOUND';
						$message .= (($message) ? '<br><br>' : '') . '<strong>' . sprintf($this->user->lang[$key], '<span style="font-weight: normal;">' . implode(', ', $bad_game_install_file) . '</span>') . '</strong>';
					}

					if ($s_game_array)
					{
						$key = 'ARCADE_UNPACK_GAME' . (($s_game_array > 1) ? 'S' : '') . '_SUCCESS';
						$message .= (($message) ? '<br><br>' : '') . sprintf($this->user->lang[$key], implode(', ', $game_array));
					}

					if (count($file_names))
					{
						$log_key = ($upload_file) ? 'LOG_ARCADE_UPLOAD_UNPACK_GAME' : 'LOG_ARCADE_UNPACK_GAME' . ((count($file_names) > 1) ? 'S' : '');
						$this->arcade->add_log('admin', $log_key, implode(', ', $file_names));
					}

					if ($s_bad_game || $s_bad_perm_game || $s_bad_game_install_file)
					{
						trigger_error($message . adm_back_link($this->u_action), E_USER_WARNING);
					}
					else
					{
						trigger_error($message . adm_back_link($this->u_action));
					}
				}

				// Default Unpack Games ACP page
				$this->template->assign_var('S_UNPACK_ARCADE_GAMES', true);

				if (!file_exists($unpack_game_path))
				{
					trigger_error($this->user->lang['NO_UNPACK_GAME_DIRECTORY'] . adm_back_link($this->u_action));
				}

				$total_games = $total_install_games = $found_games = 0;
				$s_game_options = '';

				$sql = 'SELECT game_swf
						FROM '. ARCADE_GAMES_TABLE;
				$result = $this->db->sql_query($sql);
				$games_swf = array();
				$existing_games = 0;
				while ($row = $this->db->sql_fetchrow($result))
				{
					$games_swf[] = $this->file_functions->remove_extension($row['game_swf']);
				}
				$this->db->sql_freeresult($result);

				if ($files = scandir($unpack_game_path))
				{
					foreach ($files as $file)
					{
						if (in_array($file, array('.', '..', '.svn', 'index.html', 'index.htm')))
						{
							continue;
						}

						$found = false;
						foreach ($methods as $type)
						{
							$ext = substr($file, -strlen($type));
							if ($ext == $type)
							{
								$found = true;
								break;
							}
						}

						if ($found)
						{
							$game_exists = false;
							$filename = str_replace($ext, '', $file);

							if (substr($filename, 0, 5) == 'game_')
							{
								$ipb_filename = substr($filename, 5);

								if (in_array($ipb_filename, $games_swf))
								{
									$game_exists = true;
									$existing_games++;
								}
							}

							if (!$game_exists)
							{
								if (in_array($filename, $games_swf))
								{
									$game_exists = true;
									$existing_games++;
								}

								$c_file = $file;
							}
							else
							{
								$c_file = substr($file, 5);
							}

							$not_found_game_install_files = ($game_exists && !file_exists($this->arcade->set_path($c_file, 'install'))) ? true : false;


							if (!$game_exists || $not_found_game_install_files || ($re_unpack_games && $game_exists))
							{
								if ($total_games < $this->arcade_config['unpack_games_limit'])
								{
									$s_game_options .= '<option' . (($not_found_game_install_files || ($re_unpack_games && $game_exists)) ? ' style="font-weight: bold;' . (($not_found_game_install_files) ? ' color: #ff0000;' : '') . '"' : '') . ' value="' . $file . '">' . $filename . ' (' . $ext . ')</option>';

									$total_games++;

									if ($not_found_game_install_files)
									{
										$total_install_games++;
									}
								}

								$found_games++;
							}
						}
					}
				}

				$found_reunpack_games = $existing_games - $total_install_games;
				$can_upload = (file_exists($unpack_game_path) && @is_writable($unpack_game_path) && (@ini_get('file_uploads') || strtolower(@ini_get('file_uploads')) == 'on')) ? true : false;
				$extra_ext = ($total_install_games) ? '<br><br><strong>' . $this->user->lang['ARCADE_UNPACK_INSTALL_GAME' . (($found_reunpack_games > 1) ? 'S' : '')] . '</strong>' : '';
				$extra_ext .= ($re_unpack_games && $game_exists) ? '<br><br><strong>' . $this->user->lang['ARCADE_HIGHLIGHTED_GAME' . (($found_games - $total_install_games > 1) ? 'S' : '') . '_ALREADY_INSTALLED'] . '</strong>' : '';

				$this->template->assign_vars(array(
					'S_GAMES_EXISTING'					=> $found_reunpack_games && !$re_unpack_games,
					'S_FORM_ENCTYPE'					=> ($can_upload) ? ' enctype="multipart/form-data"' : '',
					'S_CAN_UPLOAD'						=> $can_upload,
					'S_TOTAL_GAMES'						=> $total_games,
					'S_GAME_OPTIONS'					=> $s_game_options,

					'GAMES_EXISTING'					=> $this->user->lang('ARCADE_UNPACK_GAMES_EXISTING', $found_reunpack_games),
					'DISPLAY_GAMES_EXISTING'			=> $this->user->lang('ARCADE_UNPACK_DISPLAY_GAMES_EXISTING', $found_reunpack_games),
					'ARCADE_UNPACK_INSTALL_GAME_EXP'	=> $extra_ext,
					'ARCADE_UNPACK_GAMES_FOUND_EXP'		=> ($found_games > $total_games) ? sprintf($this->user->lang['ARCADE_UNPACK_GAMES_FOUND_READ'], $this->arcade->number_format($found_games), $this->arcade->number_format($total_games)) : sprintf($this->user->lang['ARCADE_UNPACK_GAMES_FOUND_READ_ALL'], $this->arcade->number_format($found_games)),

					'U_ACTION'							=> $this->u_action
				));
			break;

			case 'backup_games':
				$limit			= $this->arcade_config['backup_limit'];
				$backup			= $this->request->variable('backup', false);
				$cat_ids		= $this->request->variable('cat_ids', array(0));
				$use_method		= $this->request->variable('use_method', '.tar');
				$methods		= $this->arcade->compress_methods();

				if ($backup && $use_method && !empty($cat_ids))
				{
					$game_ids = array();
					foreach ($this->arcade->games as $game_id => $row)
					{
						if (in_array($row['cat_id'], $cat_ids))
						{
							$game_ids[] = $game_id;
						}
					}

					$total_games = count($game_ids);

					if ($total_games)
					{
						$game_data = $this->arcade->get->game_data($game_ids, 'g.game_id ASC', $limit, $start);

						if ($game_data !== false && count($game_data))
						{
							$download_game = $this->arcade->container('download_game');

							foreach ($game_data as $game)
							{
								$download_game->download($game, $use_method, $methods, false, false, false);
							}
						}

						$start += $limit;

						if ($start < $total_games && $limit < $total_games)
						{
							$get_cat_ids = '';
							foreach ($cat_ids as $value)
							{
								$get_cat_ids .= '&amp;cat_ids[]=' . (int) $value;
							}

							$redirect = $this->u_action . "&amp;backup=true&amp;use_method=$use_method&amp;start=$start$get_cat_ids";
							$redirect = meta_refresh(3, $redirect);

							$this->template->assign_vars(array(
								'S_IN_BACKUP_PROCESSING'	=> true,

								'L_TITLE'					=> $this->user->lang['ACP_ARCADE_BACKUP_GAMES'],

								'ARCADE_BACKUP_PROCESSING'	=> sprintf($this->user->lang['ARCADE_GAME_PROCESSING'], $this->arcade->get->image('full', 'img', 'loading2.gif', 'ARCADE_BACKUP', true), $start, $total_games)
							));

							return;
						}

						$cat_ary = array();

						foreach ($cat_ids as $cat_id)
						{
							$cat_ary[] = $this->arcade->get->cat_field($cat_id, 'cat_name');
						}

						$cat_names = implode(', ', $cat_ary);

						$this->arcade->add_log('admin', 'LOG_ARCADE_BACKUP_CAT' . ((count($cat_ids) > 1) ? 'S' : ''), $cat_names);
						trigger_error($this->user->lang['ARCADE_BACKUP' . ((count($cat_ids) > 1) ? 'S' : '') . '_SUCCESS'] . adm_back_link($this->u_action));
					}
					else
					{
						trigger_error($this->user->lang['ARCADE_BACKUP_NO_GAMES'] . adm_back_link($this->u_action), E_USER_WARNING);
					}
				}

				$backup_path = $this->root_path . $this->arcade_config['cat_backup_path'];

				if ($this->request->is_set_post('delete'))
				{
					if (confirm_box(true))
					{
						if (file_exists($backup_path) && phpbb_is_writable($backup_path))
						{
							if ($this->file_functions->delete_dir($backup_path, true, 'htaccess', true))
							{
								$this->arcade->add_log('admin', 'LOG_ARCADE_BACKUP_EMPTY');
								trigger_error(sprintf($this->user->lang['ARCADE_BACKUP_EMPTY_SUCCESS'], $this->arcade_config['cat_backup_path']) . adm_back_link($this->u_action) );
							}
						}

						trigger_error(sprintf($this->user->lang['ARCADE_BACKUP_EMPTY_ERROR'], $this->arcade_config['cat_backup_path']) . adm_back_link($this->u_action), E_USER_WARNING);
					}
					else
					{
						confirm_box(false, 'ARCADE_BACKUP_EMPTY', build_hidden_fields(array('delete' => true)));
					}
				}

				$radio_buttons = '';
				foreach ($methods as $method)
				{
					$checked = ($method == $use_method) ? ' checked="checked"' : '';
					$radio_buttons .= '<input type="radio"' . ((!$radio_buttons) ? ' id="use_method"' : '') . ' class="radio" value="' . $method . '" name="use_method"' . $checked . '>&nbsp;' . $method . '&nbsp;';
				}

				$filesize = $this->file_functions->filesize($backup_path);
				$this->template->assign_vars(array(
					'S_CAT_OPTIONS' 				=> $this->arcade->make_cat_select(false, false, true, true),
					'S_IN_BACKUP'					=> true,

					'U_ACTION'						=> $this->u_action,

					'ARCADE_BACKUP_DIR_FILESIZE'	=> ($filesize) ? sprintf($this->user->lang['ARCADE_BACKUP_DIR_FILESIZE'], $this->arcade_config['cat_backup_path'], get_formatted_filesize($filesize)) : '',
					'RADIO_BUTTONS'					=> $radio_buttons,
				));
			break;

			case 'downloads_games':
				$download_url		= $this->request->variable('dl_url', '');
				$sort_cat			= (int) $this->request->variable('sc', 0);
				$sort_gtype			= (int) $this->request->variable('gt', 0);
				$sort_gstype		= (int) $this->request->variable('gst', 0);
				$sort_time			= (int) $this->request->variable('st', 0);
				$sort_key			= $this->request->variable('sk', 'd');
				$sort_dir			= $this->request->variable('sd', 'd');
				$game_desc_enable	= $this->request->variable('gd', 'n');
				$hide_found			= $this->request->variable('hide', 'y');
				$hide_removed_found	= $this->request->variable('hide_removed', 'y');
				$ts					= $this->request->variable('ts', '');

				if ($this->arcade->is_post_empty('purge_dl_cache'))
				{
					$download_url = '';
					$this->arcade->purge_download_cache();
				}

				if ($download_url != '')
				{
					if (strpos($download_url, 'http://') === false && strpos($download_url, 'https://') === false)
					{
						$download_url = "http://{$download_url}";
					}

					$download_url = rtrim($download_url, '/');
				}

				$this->template->assign_vars(array(
					'S_IN_ARCADE_DOWNLOADS'	=> true,

					'U_ACTION'				=> $this->u_action,

					'DOWNLOAD_URL'			=> $download_url,
				));

				if ($download_url != '')
				{
					$error = '';
					$arcade_params = 'arcade.php?mode=download';
					$download_data = $this->arcade->get_remote_data("{$download_url}/{$arcade_params}&type=data" . (($ts) ? "&ts={$ts}" : ''));

					if (is_array($download_data) && count($download_data) && !isset($download_data['error']))
					{
						$download_enable = (!empty($download_data['list_enable'])) ? true : false;

						if (!$this->arcade->game->download_auth('acp_dl_version', $download_data))
						{
							$error = sprintf($this->user->lang['ACP_ARCADE_OLD_VERSION_GAMES_DOWNLOAD'], $download_data['sitename']);
						}
						else if (phpbb_version_compare($download_data['req_min'], $this->arcade_config['version'], '>'))
						{
							$error = sprintf($this->user->lang['ACP_ARCADE_NEW_VERSION_GAMES_DOWNLOAD'], $download_data['sitename'], $download_data['sitename'], $download_data['req_min']);
						}

						if (!$error)
						{
							if ($download_enable)
							{
								$download_list = $this->arcade->get_remote_data("{$download_url}/{$arcade_params}&type=list&c=$sort_cat&start=$start&gt=$sort_gtype&gst=$sort_gstype&sk=$sort_key&st=$sort_time&sd=$sort_dir&per_page={$this->arcade_config['download_list_per_page']}&gd={$game_desc_enable}" . (($ts) ? "&ts={$ts}" : ''));

								if (empty($download_list['found']))
								{
									$error = sprintf($this->user->lang['ACP_ARCADE_DOWNLOADS_NOT_FOUND'], $download_data['sitename']);
								}
							}
							else
							{
								$error = sprintf($this->user->lang['ACP_ARCADE_DOWNLOADS_DISABLE'], $download_data['sitename']);
							}

							if (!$error)
							{
								$recent_sites = $this->arcade_cache->obtain_arcade_recent_sites($download_url);

								$this->template->assign_vars(array(
									'S_DOWNLOAD_ENABLE'	=> true,

									'DOWNLOAD_SITENAME'	=> sprintf($this->user->lang['ARCADE_DOWNLOADS_FROM'], $download_data['sitename']),
									'DOWNLOAD_MESSAGE'	=> (isset($download_data['message'])) ? $download_data['message'] : ''
								));

								$tar = $targz = $tarbz2 = $zip = false;
								$available_methods = array_intersect($this->arcade->compress_methods(), $download_data['methods']);
								foreach ($available_methods as $method)
								{
									switch ($method)
									{
										case '.zip':
											$zip = true;
										break;

										case '.tar':
											$tar = true;
										break;

										case '.tar.gz':
											$targz = true;
										break;

										case '.tar.bz2':
											$tarbz2 = true;
										break;

										default:
										break;
									}
								}

								$this->template->assign_vars(array(
									'S_FILE_TYPE'	=> $download_data['filetype'],
									'S_ZIP'			=> $zip,
									'S_TAR'			=> $tar,
									'S_TARGZ'		=> $targz,
									'S_TARBZ2'		=> $tarbz2,
								));

								$s_download_cost = false;
								$total_games = $total_games_real = $total_found = $total_removed_found = 0;

								if (is_array($download_list) && count($download_list) && !empty($download_list['games']))
								{
									$removed_games = $this->arcade->old_delete_games('load');

									foreach ($download_list['games'] as $game_id => $row)
									{
										$total_games_real++;
										$game_found = $game_removed_found = false;
										$game_filename = $this->file_functions->remove_extension($row['game_swf']);

										if (file_exists($this->arcade->set_path($row['game_swf'], 'install')))
										{
											$total_found++;
											$game_found = true;
											if ($hide_found == 'y')
											{
												continue;
											}
										}
										else if (in_array($game_filename, array_keys($removed_games)))
										{
											$total_removed_found++;
											$game_removed_found = true;
											$reason = ($removed_games[$game_filename]['reason']) ? $removed_games[$game_filename]['reason'] : $this->user->lang['ARCADE_NONE'];
											$game_name_title = sprintf($this->user->lang['ARCADE_OLD_GAME_UNINSTALL_DATE'], $this->user->format_date($removed_games[$game_filename]['date'], 'Y.m.d', true), $reason);

											if ($hide_removed_found == 'y')
											{
												continue;
											}
										}

										if (!empty($download_list['points_show']) && $row['download_cost'] > 0)
										{
											$s_download_cost = true;
										}

										$this->template->assign_block_vars('games', array(
											'S_GAME_FOUND'			=> $game_found,
											'S_REMOVED_GAME_FOUND'	=> $game_removed_found,
											'U_DOWNLOAD'			=> "{$download_url}/{$arcade_params}&amp;type=acp&amp;g=$game_id" . (($ts) ? "&ts={$ts}" : ''),
											'GAME_NAME'				=> $row['game_name'],
											'GAME_NAME_TITLE'		=> ($game_removed_found) ? $game_name_title : false,
											'GAME_DESC'				=> ($game_desc_enable == 'y') ? $row['game_desc'] : '',
											'DOWNLOAD_COST'			=> ($s_download_cost) ? $this->arcade->number_format($row['download_cost']) . ' ' . $download_list['points_name'] : 0,
											'GAME_FILESIZE'			=> get_formatted_filesize($row['game_filesize']),
											'GAME_INSTALLDATE'		=> $this->user->format_date($row['game_installdate']),
											'GAME_TYPE'				=> $this->arcade->game->type($row['game_type'], true),
											'GAME_SAVE_TYPE'		=> $this->arcade->game->save_type($row['game_save_type'], true)
										));
									}
								}

								$l_total_games = $this->user->lang['ARCADE_DOWNLOAD_TOTAL_GAMES'];
								$found_category  = (!empty($download_data['categories'][$sort_cat])) ? true : false;

								if ($found_category && $sort_gtype)
								{
									$l_total_games = sprintf($this->user->lang['ARCADE_DOWNLOAD_TOTAL_GAMES_CAT_GAME_TYPE'], $download_data['categories'][$sort_cat], $this->arcade->game->save_type($sort_gtype, true));
								}
								else if ($found_category && $sort_gstype)
								{
									$l_total_games = sprintf($this->user->lang['ARCADE_DOWNLOAD_TOTAL_GAMES_CAT_SAVE_TYPE'], $download_data['categories'][$sort_cat], $this->arcade->game->save_type($sort_gstype, true));
								}
								else if ($found_category)
								{
									$l_total_games = sprintf($this->user->lang['ARCADE_DOWNLOAD_TOTAL_GAMES_CAT'], $download_data['categories'][$sort_cat]);
								}
								else if ($sort_gtype)
								{
									$l_total_games = sprintf($this->user->lang['ARCADE_DOWNLOAD_TOTAL_GAMES_GAME_TYPE'], $this->arcade->game->type($sort_gtype, true));
								}
								else if ($sort_gstype)
								{
									$l_total_games = sprintf($this->user->lang['ARCADE_DOWNLOAD_TOTAL_GAMES_SAVE_TYPE'], $this->arcade->game->save_type($sort_gstype, true));
								}

								$download_total = (!empty($download_list['total'])) ? $download_list['total'] : 0;
								$per_page = (!empty($download_list['per_page'])) ? $download_list['per_page'] : $this->arcade_config['download_list_per_page'];

								$this->arcade->container('phpbb_pagination')->generate_template_pagination($this->u_action . '&amp;dl_url=' . urlencode(str_replace('&amp;', '&', $download_url)) . "&amp;sc=$sort_cat&amp;st=$sort_time&amp;sk=$sort_key&amp;sd=$sort_dir&amp;gt=$sort_gtype&amp;gst=$sort_gstype&amp;gd=$game_desc_enable&amp;hide=$hide_found&amp;hide_removed=$hide_removed_found" . (($ts) ? "&ts={$ts}" : ''), 'pagination', 'start', $download_total, $per_page, $start);

								$this->template->assign_vars(array(
									'S_GAMES_FOUND'					=> ($total_games_real > 0) ? true : false,
									'S_SHOW_POINTS_DOWNLOAD'		=> (!empty($download_list['points_show']) && $s_download_cost) ? true : false,
									'S_SHOW_NOTE'					=> ($hide_found == 'n') ? true : false,
									'S_SHOW_REMOVED_NOTE'			=> ($hide_removed_found == 'n') ? true : false,
									'S_GAME_DESC'					=> ($game_desc_enable == 'y') ? true : false,

									'L_ARCADE_DOWNLOAD_TOTAL_GAMES'	=> $l_total_games,

									'TOTAL_GAMES'					=> $this->arcade->number_format($download_total),
									'GAMES_FOUND'					=> $total_found,
									'GAMES_REMOVED_FOUND'			=> $total_removed_found,
									'GAMES_NOT_FOUND'				=> $total_games_real - $total_found - $total_removed_found,
									'SORT_CAT_SELECT'				=> $this->sort_cat_select($sort_cat, $download_data['categories']),
									'SORT_GAME_TYPE_SELECT'			=> $this->arcade->game_type_select($sort_gtype, 'ARCADE_ALL_GAME_TYPES'),
									'SORT_SAVE_TYPE_SELECT'			=> $this->arcade->game_save_type_select($sort_gstype, 'ARCADE_ALL_SAVE_TYPES'),
									'SORT_TIME_SELECT'				=> $this->sort_time_select($sort_time),
									'SORT_KEY_SELECT'				=> $this->sort_key_select($sort_key),
									'SORT_DIR_SELECT'				=> $this->sort_dir_select($sort_dir),
									'GAME_DESC_SELECT'				=> $this->hide_found_select($game_desc_enable),
									'HIDE_FOUND_SELECT'				=> $this->hide_found_select($hide_found),
									'HIDE_REMOVED_FOUND_SELECT'		=> $this->hide_found_select($hide_removed_found)
								));

								if (empty($download_list['total']))
								{
									$error = $this->user->lang['ACP_ARCADE_DOWNLOADS_SPECIFIED_NOT_FOUND'];
								}
							}
						}
					}
					else
					{
						$error = (empty($download_data['error'])) ? $this->user->lang['ARCADE_DOWNLOADS_URL_NOT_FOUND'] : $download_data['error'];
					}

					if ($error)
					{
						if (!empty($download_data['md5_url']))
						{
							// remove empty cache data
							$this->cache->remove_file($this->cache->get_driver()->cache_dir . "data_arcade_dl_{$download_data['md5_url']}.{$this->php_ext}");
						}

						$this->template->assign_var('S_ERROR_MSG', $error);
					}
				}

				$this->template->assign_var('S_HIDDEN_FIELDS', build_hidden_fields(array('ts' => $ts)));

				if (!isset($recent_sites))
				{
					$recent_sites = $this->arcade_cache->obtain_arcade_recent_sites();
				}

				if (count($recent_sites))
				{
					$this->template->assign_var('S_RECENT_SITES', true);

					foreach ($recent_sites as $site)
					{
						$this->template->assign_block_vars('recent_sites', array(
							'SITE' => $site
						));
					}
				}
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		$this->template->assign_vars(array(
			'L_TITLE'			=> $this->user->lang['ACP_ARCADE_' . strtoupper($mode)],
			'L_TITLE_EXPLAIN'	=> $this->user->lang['ACP_ARCADE_' . strtoupper($mode) . '_EXPLAIN'],
		));
	}

	/**
	* Upload Game - filedata is generated here
	*/
	public function upload_game(&$error)
	{
		$this->user->add_lang('posting');

		$upload = $this->arcade->container('phpbb_files.upload');
		$upload->set_disallowed_content(array());
		$upload->set_allowed_extensions($this->arcade->compress_methods(true));

		if ($this->request->file('fileupload'))
		{
			$file = $upload->handle_upload('files.types.form', 'fileupload');
		}
		else
		{
			$error[] = $this->user->lang['NO_UPLOAD_FORM_FOUND'];
			return;
		}

		// Move file and overwrite any existing game
		$file->move_file($this->arcade_config['unpack_game_path'], true, true);

		if (count($file->error))
		{
			$file->remove();
			$error = array_merge($error, $file->error);
		}

		return $file->get('realname');
	}

	public function sort_time_select($value)
	{
		$limit_time = array(0 => $this->user->lang['ARCADE_ALL_GAMES'], 1 => $this->user->lang['1_DAY'], 7 => $this->user->lang['7_DAYS'], 14 => $this->user->lang['2_WEEKS'], 30 => $this->user->lang['1_MONTH'], 90 => $this->user->lang['3_MONTHS'], 180 => $this->user->lang['6_MONTHS'], 365 => $this->user->lang['1_YEAR']);

		$s_limit_time = '';
		foreach ($limit_time as $time => $text)
		{
			$selected = ($value == $time) ? ' selected="selected"' : '';
			$s_limit_time .= '<option value="' . $time . '"' . $selected . '>' . $text . '</option>';
		}
		return $s_limit_time;
	}

	public function sort_cat_select($selected, $data)
	{
		$options = '<option value="0"' . ((!$selected) ? ' selected="selected"' : '') . '>' . $this->user->lang['ARCADE_ALL_CATEGORIES'] . '</option>';
		foreach ($data as $cat_id => $cat_name)
		{
			$options .= '<option value="' . $cat_id . '"' . (($cat_id == $selected) ? ' selected="selected"' : '') . '>' . $cat_name . '</option>';
		}
		return $options;
	}

	public function sort_key_select($value)
	{
		return '<option value="n"'. (($value == 'n') ? ' selected="selected"' : '') . '>' . $this->user->lang['ARCADE_GAME_NAME'] . '</option>
		<option value="s"' . (($value == 's') ? ' selected="selected"' : '') . '>' . $this->user->lang['FILESIZE'] . '</option>
		<option value="t"' . (($value == 't') ? ' selected="selected"' : '') . '>' . $this->user->lang['ARCADE_GAME_TYPE'] . '</option>
		<option value="r"' . (($value == 'r') ? ' selected="selected"' : '') . '>' . $this->user->lang['ARCADE_GAME_SAVE_TYPE'] . '</option>
		<option value="d"' . (($value == 'd') ? ' selected="selected"' : '') . '>' . $this->user->lang['ARCADE_GAMES_SORT_INSTALLDATE'] . '</option>';
	}

	public function sort_dir_select($value)
	{
		return '<option value="a"'. (($value == 'a') ? ' selected="selected"' : '') . '>' . $this->user->lang['ASCENDING'] . '</option><option value="d"' . (($value == 'd') ? ' selected="selected"' : '') . '>' . $this->user->lang['DESCENDING'] . '</option>';
	}

	public function hide_found_select($value)
	{
		return '<option value="y"'. (($value == 'y') ? ' selected="selected"' : '') . '>' . $this->user->lang['YES'] . '</option><option value="n"' . (($value == 'n') ? ' selected="selected"' : '') . '>' . $this->user->lang['NO'] . '</option>';
	}
}
