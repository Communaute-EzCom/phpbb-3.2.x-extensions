<?php
/**
*
* @package phpBB Arcade
* @version $Id: manage_info.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\ucp;

class manage_info
{
	function module()
	{
		return array(
			'filename'	=> '\jv\arcade\ucp\manage_module',
			'title'		=> 'UCP_ARCADE',
			'modes'		=> array(
				'settings'	=> array('title' => 'UCP_ARCADE_SETTINGS'	, 'auth' => 'ext_jv/arcade && acl_u_arcade', 'cat'							 => array('UCP_CAT_ARCADE')),
				'post'		=> array('title' => 'UCP_ARCADE_POST'		, 'auth' => 'ext_jv/arcade && acl_u_arcade', 'cat'							 => array('UCP_CAT_ARCADE')),
				'favorites'	=> array('title' => 'UCP_ARCADE_FAVORITES'	, 'auth' => 'ext_jv/arcade && acl_u_arcade && acl_u_arcade_favorites', 'cat' => array('UCP_CAT_ARCADE'))
			)
		);
	}
}
