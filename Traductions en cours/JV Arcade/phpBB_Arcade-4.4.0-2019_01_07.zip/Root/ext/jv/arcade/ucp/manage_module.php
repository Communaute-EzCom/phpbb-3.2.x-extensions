<?php
/**
*
* @package phpBB Arcade
* @version $Id: manage_module.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\ucp;

class manage_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $db, $cache, $auth, $request, $user, $template;
	protected $arcade_config, $arcade;

	public function __construct()
	{
		global $db, $cache, $auth, $request, $user, $template;
		global $arcade_config, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade->auth_check('ucp');
		$arcade = $arcade->container('arcade', true);

		$this->db = $db;
		$this->cache = $cache;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	function main($id, $mode)
	{
		$submit = $this->request->is_set_post('submit');
		$error = $data = array();

		switch ($mode)
		{
			case 'settings':
				add_form_key('ucp_arcade_settings');
				$restore_settings = $this->request->is_set_post('restore_settings');

				$cdata = array(
					'arcade_pm'					=> (bool) $this->request->variable('arcade_pm'				, $this->arcade->optionget('arcade_pm')),
					'challenge'					=> (bool) $this->request->variable('challenge'				, $this->arcade->optionget('challenge')),
					'view_avatars'				=> (bool) $this->request->variable('avatars'				, $this->arcade->optionget('view_avatars')),
					'view_game_image'			=> (bool) $this->request->variable('game_image'				, $this->arcade->optionget('view_game_image')),
					'view_popup_icon'			=> (bool) $this->request->variable('popup_icon'				, $this->arcade->optionget('view_popup_icon')),
					'game_over_random_games'	=> (bool) $this->request->variable('random_games'			, $this->arcade->optionget('game_over_random_games')),
					'game_over_sound'			=> (bool) $this->request->variable('game_over_sound'		, $this->arcade->optionget('game_over_sound')),
					'game_over_animation'		=> (bool) $this->request->variable('game_over_animation'	, $this->arcade->optionget('game_over_animation')),
					'game_over_animation_sound'	=> (bool) $this->request->variable('animation_sound'		, $this->arcade->optionget('game_over_animation_sound'))
				);

				$data = array(
					'arcade_cat_style'			=> $this->request->variable('arcade_cat_style', $this->user->data['arcade_cat_style']),
					'arcade_cat_games_style'	=> $this->request->variable('arcade_cat_games_style', $this->user->data['arcade_cat_games_style']),
					'games_sort_order'			=> $this->request->variable('games_sort_order', $this->user->data['games_sort_order']),
					'games_sort_dir'			=> $this->request->variable('games_sort_dir', $this->user->data['games_sort_dir'])
				);

				if ($submit || $restore_settings)
				{
					if (!$restore_settings)
					{
						$validate_array = array(
							'games_sort_order'	=> array('string', false, 1, 1),
							'games_sort_dir'	=> array('string', false, 1, 1)
						);

						if (validate_data($data, $validate_array))
						{
							$restore_settings = true;
						}
					}

					if (!check_form_key('ucp_arcade_settings'))
					{
						$error[] = 'FORM_INVALID';
					}

					if (!count($error))
					{
						if ($restore_settings)
						{
							$data = $this->arcade->user_default_settings();
						}
						else
						{
							$this->arcade->optionset('arcade_pm'					, $cdata['arcade_pm']);
							$this->arcade->optionset('challenge'					, $cdata['challenge']);
							$this->arcade->optionset('view_avatars'					, $cdata['view_avatars']);
							$this->arcade->optionset('view_game_image'				, $cdata['view_game_image']);
							$this->arcade->optionset('view_popup_icon'				, $cdata['view_popup_icon']);
							$this->arcade->optionset('game_over_random_games'		, $cdata['game_over_random_games']);
							$this->arcade->optionset('game_over_sound'				, $cdata['game_over_sound']);
							$this->arcade->optionset('game_over_animation'			, $cdata['game_over_animation']);
							$this->arcade->optionset('game_over_animation_sound'	, $cdata['game_over_animation_sound']);

							$data['user_arcade_options'] = $this->user->data['user_arcade_options'];
						}

						$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
								SET ' . $this->db->sql_build_array('UPDATE', $data) . '
								WHERE user_id = ' . (int) $this->user->data['user_id'];
						$this->db->sql_query($sql);

						$this->cache->destroy('sql', ARCADE_CHALLENGE_CHAMP_TABLE);
						$this->arcade->add_log('user', 'LOG_ARCADE_USER_MAIN_SETTINGS');
						meta_refresh(5, $this->u_action);
						$message = $this->user->lang['PREFERENCES_UPDATED'] . '<br><br>' . sprintf($this->user->lang['RETURN_PAGE'], '<a href="' . $this->u_action . '">', '</a>');
						trigger_error($message);
					}

					$error = array_map(array($this->user, 'lang'), $error);
				}

				if (!$this->auth->acl_get('u_arcade_pm'))
				{
					$error[] = $this->user->lang['UCP_ARCADE_NO_PERM_PM_LOSS_HIGHSCORE'];
				}

				$this->template->assign_vars(array(
					'S_SHOW_ARCADE_PM'			=> $this->arcade_config['arcade_pm'],
					'S_SHOW_AVATAR'				=> $this->arcade_config['display_user_avatar'],
					'S_SHOW_GAME_IMAGE'			=> $this->arcade_config['display_game_image'],
					'S_SHOW_POPUP_ICON'			=> $this->arcade_config['display_game_popup_icon'] && $this->auth->acl_get('u_arcade_popup'),
					'S_SHOW_CHALLENGE'			=> $this->arcade->access('challenge'),
					'S_SHOW_CAT_STYLE'			=> !$this->arcade_config['override_user_cat_style'],
					'S_GAME_OVER_RANDOM_GAMES'	=> $this->arcade_config['random_games_game_over_enable'] && $this->arcade_config['random_games_game_over'] > 0,
					'S_GAME_OVER_SOUND'			=> $this->arcade_config['game_over_sound'],
					'S_GAME_OVER_ANIMATION'		=> $this->arcade_config['anim_game_over_winner'] || $this->arcade_config['anim_game_over_losing'],

					'S_ARCADE_PM_ENABLED'		=> $cdata['arcade_pm'],
					'S_CHALLENGE_ENABLED'		=> $cdata['challenge'],
					'S_AVATARS_ENABLE'			=> $cdata['view_avatars'],
					'S_GAME_IMAGE_ENABLED'		=> $cdata['view_game_image'],
					'S_POPUP_ICON_ENABLED'		=> $cdata['view_popup_icon'],
					'S_GO_RANDOM_GAMES'			=> $cdata['game_over_random_games'],
					'S_GO_SOUND'				=> $cdata['game_over_sound'],
					'S_GO_ANIMATION'			=> $cdata['game_over_animation'],
					'S_GO_ANIMATION_SOUND'		=> $cdata['game_over_animation_sound'],

					'S_ERROR'					=> (count($error)) ? true : false,
					'ERROR'						=> (count($error)) ? implode('<br>', $error) : '',

					'ARCADE_CAT_STYLES'			=> $this->arcade->select_cat_styles($data['arcade_cat_style'], true),
					'ARCADE_CAT_GAMES_STYLES'	=> $this->arcade->select_cat_styles($data['arcade_cat_games_style']),
					'GAMES_SORT_ORDER'			=> $this->arcade->select_games_sort_order($data['games_sort_order']),
					'GAMES_SORT_DIR'			=> $this->arcade->select_games_sort_dir($data['games_sort_dir'])
				));
			break;

			case 'favorites':
				$start		= (int) $this->request->variable('start', 0);
				$sort_key	= $this->request->variable('sk', ARCADE_ORDER_NAME);
				$sort_dir	= $this->request->variable('sd', ARCADE_ORDER_ASC);
				$action		= $this->request->variable('action', '');
				$game_ids	= array_keys($this->request->variable('games', array(0)));
				$confirm	= $this->request->is_set_post('confirm');

				$error = array();

				if ($submit)
				{
					if (!count($game_ids))
					{
						$error[] = $this->user->lang['NO_GAME_ID'];
					}

					if (!count($error))
					{
						if ($action == 'highlight' || $action == 'highlight_remove')
						{
							$highlighted = ($action == 'highlight') ? 1 : 0;

							$sql = 'UPDATE ' . ARCADE_FAVS_TABLE . '
									SET highlighted = ' . $highlighted . '
									WHERE ' . $this->db->sql_in_set('game_id', $game_ids) . '
									AND user_id = ' . (int) $this->user->data['user_id'];
							$this->db->sql_query($sql);
						}
						else if ($action == 'delete')
						{
							if (confirm_box(true))
							{
								$sql = 'DELETE FROM ' . ARCADE_FAVS_TABLE . '
										WHERE ' . $this->db->sql_in_set('game_id', $game_ids) . '
											AND user_id = ' . (int) $this->user->data['user_id'];
								$this->db->sql_query($sql);

								$this->arcade->add_log('user', 'LOG_ARCADE_USER_MANAGE_FAVORITES');
								meta_refresh(5, $this->u_action);
								$message = $this->user->lang['UCP_ARCADE_FAVORITE' . ((count($game_ids) > 1) ? 'S' : '') . '_DELETED'] . '<br><br>' . sprintf($this->user->lang['RETURN_PAGE'], '<a href="' . $this->u_action . '">', '</a>');
								trigger_error($message);
							}
							else
							{
								$s_hidden_fields = array(
									'submit' => true,
									'action' => 'delete'
								);

								foreach ($game_ids as $game_id)
								{
									$s_hidden_fields['games'][$game_id] = 1;
								}

								confirm_box(false, (count($game_ids) == 1) ? 'UCP_ARCADE_DELETE_FAVORITE' : 'UCP_ARCADE_DELETE_FAVORITES', build_hidden_fields($s_hidden_fields));
							}
						}
					}
				}

				// Select box eventually
				$sort_key_sql = array(
					ARCADE_ORDER_FIXED			=> 'g.game_order',
					ARCADE_ORDER_INSTALLDATE	=> 'g.game_installdate',
					ARCADE_ORDER_NAME			=> 'g.game_name_clean',
					ARCADE_ORDER_PLAYS			=> 'g.game_plays',
					ARCADE_ORDER_CAT			=> 'c.cat_name',
					ARCADE_ORDER_HIGHLIGHTED	=> 'f.highlighted'
				);

				$sort_opt_ary = array(
					ARCADE_ORDER_FIXED			=> 'ARCADE_GAMES_SORT_FIXED',
					ARCADE_ORDER_INSTALLDATE	=> 'ARCADE_GAMES_SORT_INSTALLDATE',
					ARCADE_ORDER_NAME			=> 'ARCADE_GAME_NAME',
					ARCADE_ORDER_PLAYS			=> 'ARCADE_GAMES_SORT_PLAYS',
					ARCADE_ORDER_CAT			=> 'ARCADE_CATEGORY',
					ARCADE_ORDER_HIGHLIGHTED	=> 'ARCADE_HIGHLIGHTED_GAME'
				);

				if (!isset($sort_opt_ary[$sort_key]))
				{
					$sort_key = ARCADE_ORDER_NAME;
				}

				$sd_opt_ary = array(
					ARCADE_ORDER_ASC	=> 'ASCENDING',
					ARCADE_ORDER_DESC	=> 'DESCENDING'
				);

				$order_by = $sort_key_sql[$sort_key] . ' ' . (($sort_dir == ARCADE_ORDER_ASC) ? 'ASC' : 'DESC');

				if ($num_favs = $this->arcade->get->total('game', 'favorites', $this->user->data['user_id']))
				{
					$this->arcade->valid_start($start, $num_favs);
					$this->template->assign_var('S_GAME_ROWS', $this->arcade->display->stats_data('game', 'favorites', 20, 'least', $start, $this->arcade_config['games_per_page'], true, 'fav', $order_by, $this->user->data['user_id']));
				}

				$this->arcade->container('phpbb_pagination')->generate_template_pagination($this->u_action . "&amp;sk=$sort_key&amp;sd=$sort_dir", 'pagination', 'start', $num_favs, $this->arcade_config['games_per_page'], $start);

				$act_opt_ary = array(
					'delete'			=> 'DELETE_MARKED',
					'highlight'			=> 'UCP_ARCADE_SELECTED_HIGHLIGHT',
					'highlight_remove'	=> 'UCP_ARCADE_SELECTED_HIGHLIGHT_REMOVE'
				);

				$this->template->assign_vars(array(
					'TOTAL_DATA'			=> ($num_favs) ? $this->user->lang['ARCADE_STATS_TOTAL_GAMES'] . ' (' . $num_favs . ')' : false,

					'U_SORT_GAME_NAME'		=> $this->u_action . "&amp;sk=n&amp;sd=" . (($sort_key == ARCADE_ORDER_NAME && $sort_dir == ARCADE_ORDER_ASC) ? ARCADE_ORDER_DESC : ARCADE_ORDER_ASC) . '#tabs',
					'U_SORT_CATEGORY_NAME'	=> $this->u_action . "&amp;sk=c&amp;sd=" . (($sort_key == ARCADE_ORDER_CAT && $sort_dir == ARCADE_ORDER_ASC) ? ARCADE_ORDER_DESC : ARCADE_ORDER_ASC) . '#tabs',

					'S_HIDDEN_FIELDS'		=> build_hidden_fields(array('start' => $start)),
					'S_DISPLAY_MARK_ALL'	=> ($num_favs) ? true : false,
					'S_DISPLAY_PAGINATION'	=> ($num_favs) ? true : false,
					'S_SORT_OPTIONS' 		=> $this->arcade->build_select($sort_opt_ary, $sort_key),
					'S_ORDER_SELECT'		=> $this->arcade->build_select($sd_opt_ary, $sort_dir),
					'S_FAV_ACTION_OPTIONS'	=> $this->arcade->build_select($act_opt_ary, $action),

					'S_ERROR'				=> (count($error)) ? true : false,
					'ERROR'					=> (count($error)) ? implode('<br>', $error) : ''
				));
			break;

			case 'post':
				$data = array(
					'bbcode'	=> (bool) $this->request->variable('bbcode', $this->arcade->optionget('bbcode')),
					'smilies'	=> (bool) $this->request->variable('smilies', $this->arcade->optionget('smilies'))
				);

				add_form_key('ucp_arcade_post');

				if ($submit)
				{
					if (check_form_key('ucp_arcade_post'))
					{
						$this->arcade->optionset('bbcode', $data['bbcode']);
						$this->arcade->optionset('smilies', $data['smilies']);

						$sql_ary = array('user_arcade_options' => $this->user->data['user_arcade_options']);

						$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
								SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
								WHERE user_id = ' . (int) $this->user->data['user_id'];
						$this->db->sql_query($sql);

						$msg = $this->user->lang['PREFERENCES_UPDATED'];
					}
					else
					{
						$msg = $this->user->lang['FORM_INVALID'];
					}

					$this->arcade->add_log('user', 'LOG_ARCADE_USER_POST_SETTINGS');
					meta_refresh(5, $this->u_action);
					$message = $msg . '<br><br>' . sprintf($this->user->lang['RETURN_PAGE'], '<a href="' . $this->u_action . '">', '</a>');
					trigger_error($message);
				}

				$this->template->assign_vars(array(
					'S_BBCODE_ENABLED'	=> $data['bbcode'],
					'S_SMILIES_ENABLED'	=> $data['smilies']
				));
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		$this->template->assign_vars(array(
			'L_TITLE'			=> $this->user->lang['UCP_ARCADE_' . strtoupper($mode)],
			'L_TITLE_EXPLAIN'	=> $this->user->lang['UCP_ARCADE_' . strtoupper($mode) . '_EXPLAIN'],
			'S_UCP_ACTION'		=> $this->u_action
		));

		$this->tpl_name = 'arcade/ucp_' . $mode;
		$this->page_title = 'UCP_ARCADE_' . strtoupper($mode);
	}
}
