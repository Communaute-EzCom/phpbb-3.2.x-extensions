<?php
/**
*
* @package phpBB Arcade
* @version $Id: main.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class main
{
	public $gametop = '#gametop';

	protected $phpbb_dispatcher, $container, $path_helper, $ext_manager, $db, $cache, $config, $auth, $request, $user, $template, $arcade_cache, $arcade_config, $arcade_auth, $file_functions, $root_path, $php_ext, $admin_path;

	public function __construct($phpbb_dispatcher, $container, $path_helper, $ext_manager, $db, $cache, $config, $auth, $request, $user, $template, $arcade_cache, $arcade_config, $arcade_auth, $file_functions, $root_path, $php_ext, $adm_relative_path)
	{
		$this->phpbb_dispatcher = $phpbb_dispatcher;
		$this->container = $container;
		$this->path_helper = $path_helper;
		$this->ext_manager = $ext_manager;
		$this->db = $db;
		$this->cache = $cache;
		$this->config = $config;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->file_functions = $file_functions;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->admin_path = $root_path . $adm_relative_path;
	}

	public function setup($lang_set = false, $style_id = false, $arcade_main = false)
	{
		include($this->ext_path() . 'inc/functions.' . $this->php_ext);
		set_error_handler(defined('PHPBB_MSG_HANDLER') ? PHPBB_MSG_HANDLER : 'arcade_msg_handler');
		$this->user->setup($lang_set, $style_id);

		if ($arcade_main)
		{
			$this->main();
		}
	}

	public function get_driver($type = null)
	{
		$type = (in_array($type, array('challenge', 'tournament', 'full'))) ? $type : null;

		return $this->container((defined('IN_ADMIN') || defined('USE_ARCADE_ADMIN')) ? 'admin' : 'arcade', true, false, $type);
	}

	public function header($mode)
	{
		if (!$this->start_system_check())
		{
			return;
		}

		$arcade_row = array(
			'S_IN_PHPBB_ARCADE'				=> true,
			'S_ARCADE_INSTALLED_GAMES'		=> $this->number_format(intval($this->arcade_config['install_games'])),
			'S_POINTS_NAME'					=> $this->points()->data['name'],
			'S_DISPLAY_ARCADE_AR'			=> $this->arcade_config['paar'] != -1,
			'S_DISPLAY_ARCADE_AR_TYPE'		=> ($this->arcade_config['paar'] > 0) ? $this->arcade_config['paar'] : false,

			'T_ARCADE_PATH'					=> "{$this->web_path()}arcade/",
			'T_ARCADE_START_SYSTEM_PATH'	=> "{$this->web_path()}arcade/start_system",

			'PHPEX'							=> $this->php_ext,
			'PHPBB_ARCADE_VERSION'			=> $this->arcade_config['version'],
			'PHPBB_ARCADE_COPYRIGHT'		=> $this->arcade_config['copyright'],
			'ARCADE_SUPPORT_URL'			=> $this->arcade_config['support_domain'],
			'ARCADE_CONNECT_URL'			=> $this->arcade_config['connect_domain'],
			'ARCADE_BOARD_URL'				=> generate_board_url(),
			'BOARD_COOKIE_NAME'				=> $this->config['cookie_name']
		);

		if ($mode != 'path' && !defined('ADMIN_START'))
		{
			$this->container('menu', true);

			if (!$this->user->data['is_bot'] && $this->arcade_config['global_announce'] && $this->page_enable($this->arcade_config['display_global_announce']) && ($this->arcade_config['display_global_announce_guest'] || $this->user->data['is_registered']))
			{
				if ($this->page() != 'arcade' || $this->page() == 'arcade' && $this->access())
				{
					$this->display()->global_announce();
				}
			}
		}

		switch ($mode)
		{
			case 'full':
				if (!$this->user->data['is_bot'] && $this->page_enable($this->arcade_config['display_header']))
				{
					$this->display()->header_information();
				}

				if ($this->page_enable($this->arcade_config['tour_display_news']) && $this->access('tour') && ($this->arcade_config['tour_news_count_start'] || $this->arcade_config['tour_news_count_end']))
				{
					$this->display()->tour_news();
				}

				$arcade_row = array_merge($arcade_row, array(
					'S_DISPLAY_ARCADE'				=> true,
					'S_DISPLAY_ARCADE_CHALLENGE'	=> $this->access('challenge'),
					'S_DISPLAY_ARCADE_TOURNAMENT'	=> $this->access('tour'),
					'S_ARCADE_STATISTICS'			=> ($this->auth->acl_get('u_arcade_viewstats')) ? true : false,
					'S_ARCADE_FAVORITE'				=> ($this->auth->acl_get('u_arcade_favorites')) ? true : false,
					'S_ARCADE_DOWNLOAD'				=> $this->game()->download_auth('user'),

					'U_ARCADE'						=> $this->url(),
					'ARCADE_ROOT_PATH'				=> $this->root_path,
					'U_ARCADE_CHALLENGE'			=> ($this->access('challenge')) ? $this->url('mode=challenge') : '',
					'U_ARCADE_TOURNAMENT'			=> ($this->access('tour')) ? $this->url('mode=tournament') : '',
					'U_ARCADE_AJAX'					=> append_sid("{$this->ext_path()}ajax/ajax.{$this->php_ext}"),

					'GAMETOP'						=> str_replace('#', '', $this->gametop),
					'ARCADE_COOKIE_SETTINGS'		=> addslashes('; path=' . $this->config['cookie_path'] . ((!$this->config['cookie_domain'] || $this->config['cookie_domain'] == 'localhost' || $this->config['cookie_domain'] == '127.0.0.1') ? '' : '; domain=' . $this->config['cookie_domain']) . ((!$this->config['cookie_secure']) ? '' : '; secure'))
				));
			break;
		}

		$vars = array('mode', 'arcade_row');
		extract($this->phpbb_dispatcher()->trigger_event('jv.arcade.header_tpl', compact($vars)));

		$this->template->assign_vars($arcade_row);
	}

	public function access($type = '', $admin = true)
	{
		$admin			= ($admin && !empty($this->user->data['is_registered']) && $this->auth->acl_get('a_')) ? true : false;
		$acl_admin		= ($admin && (defined('IN_ADMIN') || defined('USE_ARCADE_ADMIN'))) ? true : false;

		$arcade_access	= ($this->start_system_check() && ($acl_admin || ($this->auth->acl_get('u_arcade') && !$this->ban_check(true) && (!$this->arcade_config['arcade_disable'] || $admin)))) ? true : false;

		switch ($type)
		{
			case 'challenge':
				$arcade_access = ($arcade_access && ($acl_admin || ($this->auth->acl_get('u_arcade_challenge') && (!$this->arcade_config['challenge_disable'] || $admin)))) ? true : false;
			break;

			case 'tour':
			case 'tournament':
				$arcade_access = ($arcade_access && ($acl_admin || ($this->auth->acl_get('u_arcade_tour') && (!$this->arcade_config['tour_disable'] || $admin)))) ? true : false;
			break;
		}

		return $arcade_access;
	}

	public function phpbb_dispatcher()
	{
		return $this->phpbb_dispatcher;
	}

	public function container($name, $load_main = false, $return_main = false, $fisrt_var = null)
	{
		if (!$name)
		{
			return;
		}

		$name = (substr($name, 0, 6) == 'phpbb_') ? substr($name, 6) : "jv.arcade.$name";

		$class = $this->container->get($name);

		if ($load_main)
		{
			$main = ($fisrt_var !== null) ? $class->main($fisrt_var) : $class->main();

			if ($return_main)
			{
				return $main;
			}
		}

		return $class;
	}

	public function path_helper()
	{
		return $this->path_helper;
	}

	public function valid_start(&$start, $total = 0)
	{
		if ($start < 0 || $total && $total <= $start)
		{
			$start = 0;
		}
	}

	public function page($page_name = true, $query_string = false)
	{
		$p = '';
		$page_array = $this->user->extract_current_page($this->root_path);

		if ($query_string)
		{
			return (!empty($page_array['query_string'])) ? $page_array['query_string'] : '';
		}

		if ($page_name)
		{
			if (!empty($page_array['page_name']))
			{
				$p = basename($page_array['page_name'], '.' . $this->php_ext);
			}
		}

		if (!$p && !empty($page_array['page']))
		{
			$p = basename($page_array['page'], '.' . $this->php_ext);
		}

		$p = strtolower($p);

		if ($p == 'app')
		{
			$p = 'portal';
		}

		return $p;
	}

	public function version_check()
	{
		return (!empty($this->arcade_config['version']) && defined('ARCADE_MIN_VERSION') && phpbb_version_compare($this->arcade_config['version'], ARCADE_MIN_VERSION, '>=') && phpbb_version_compare($this->arcade_config['version'], ARCADE_VERSION, '=')) ? true : false;
	}

	public function start_system_check()
	{
		return ($this->version_check() && ($this->arcade_config['activation_key'] || $this->localhost()) && defined('ARCADE_MIN_JVA_START_SYSTEM') && phpbb_version_compare($this->ext()->get_version('startsystem', false), ARCADE_MIN_JVA_START_SYSTEM, '>=')) ? true : false;
	}

	public function privat()
	{
		// Attention! The modification is not worth anything! This plays only a secondary role.
		return (!in_array($this->arcade_config['activation_key'], array('test', 'free', 'Localhost'))) ? true : false;
	}

	public function ban_check($return = false)
	{
		if ($this->user->data['is_registered'] && $this->user->data['user_type'] == USER_FOUNDER)
		{
			return false;
		}

		static $_arcade_user_ban_cache;

		if (!isset($_arcade_user_ban_cache))
		{
			$_arcade_user_ban_cache = false;

			if ($this->arcade_config['ban_user_ip'])
			{
				foreach ($this->ban_users() as $user_id => $user_ip)
				{
					if ($this->user->data['user_id'] == $user_id || $user_ip == $this->user->ip)
					{
						$_arcade_user_ban_cache = true;
						break;
					}
				}
			}
			else
			{
				$_arcade_user_ban_cache = (in_array($this->user->data['user_id'], array_keys($this->ban_users()))) ? true : false;
			}
		}

		if ($_arcade_user_ban_cache)
		{
			if ($return)
			{
				return true;
			}

			meta_refresh(5, $this->url(false, 'index'));
			send_status_line(403, 'Forbidden');
			trigger_error('ARCADE_BANNED');
		}

		return false;
	}

	public function ban_users()
	{
		return $this->arcade_cache->obtain_arcade_ban_users();
	}
/*
	public function file_path($path, $file = '', $ext = 'php', $phpbb_relative = true)
	{
		return (($phpbb_relative) ? $this->root_path : '') . "arcade/{$path}/" . (($file != '') ? $file . '.' . (($ext == $this->php_ext) ? $this->php_ext : $ext) : '');
	}
*/
	public function url($params = false, $page = 'arcade', $sid = false, $pos = '', $relative_root_path = false)
	{
		if (substr($page, 0, 4) == 'app/')
		{
			$page = str_replace('app/', "app.{$this->php_ext}/", $page);
		}

		$ext = substr(strrchr($page, '.'), 1);

		if (!$ext && $page[strlen($page) - 1] != '/')
		{
			$page .= ".{$this->php_ext}";
		}
		else if ($page[strlen($page) - 1] == '/')
		{
			$page = substr($page, 0, -1);
		}

		if ($params)
		{
			if ((strpos($params, 'img=') !== false) || (strpos($params, 'swf=') !== false))
			{
				return "{$this->web_path()}{$page}?{$params}";
			}

			if (strpos($params, '=') === false)
			{
				$page = $page . '/' . $params;
				$params = '';
			}
		}

		$pos = ($pos) ? '#' . (($pos !== true) ? $pos : 'arcade_top') : '';

		$url = append_sid($this->root_path . $page, $params, true, $sid) . (($params && (strpos($params, 'mode=play') !== false || strpos($params, 'mode=random') !== false)) ? $this->gametop : $pos);

		if ($this->config['enable_mod_rewrite'] && strpos($page, "app.{$this->php_ext}") !== false)
		{
			$url = str_replace("app.{$this->php_ext}/", '', $url);
		}

		if ($relative_root_path)
		{
			$url = str_replace($this->root_path, $relative_root_path, $url);
		}

		return $url;
	}

	public function module_url($module, $type = 'a')
	{
		return "i=-jv-arcade-{$type}cp-{$module}_module";
	}

	public function adm_url($module, $params = '')
	{
		if ($this->auth->acl_get('a_'))
		{
			return append_sid("{$this->admin_path}index.{$this->php_ext}", $this->module_url($module) . $params, true, $this->user->session_id);
		}
	}

	public function back_link($params = false, $lang = 'arcade', $br2 = true)
	{
		$s_content_flow_begin = ($this->user->lang['DIRECTION'] == 'ltr') ? 'left' : 'right';
		return (($br2) ? '<br><br>' : '<br>') . '<a class="'. $s_content_flow_begin .'" href="' . $this->url($params) . '">' . $this->user->lang['ARCADE_BACK_TO_' . strtoupper($lang)] . '</a>';
	}

	public function close_win($br = true)
	{
		return (($br) ? '<br><br>' : '') . $this->gen_popup_link();
	}

	public function refresh_close_win($game_data, $br = true)
	{
		return (($br) ? '<br><br>' : '') . $this->gen_popup_link($this->url("mode=cat&amp;c={$game_data['cat_id']}&amp;g={$game_data['game_id']}#g{$game_data['game_id']}"));
	}

	public function ext_enable($name, $only_is_available = false)
	{
		if ($only_is_available)
		{
			return ($this->ext_manager->is_available($name)) ? true : false;
		}

		return ($this->ext_manager->is_available($name) && $this->ext_manager->is_enabled($name)) ? true : false;
	}

	public function test_system()
	{
		return phpbb_check_hash($this->request->variable('ts', ''), '$2y$10$FZUsnCwGDJbFRnl.EtPLd.nfmsP1cofc2S6Cf1bM.YfNKinbDVCDS');
	}

	public function web_path()
	{
		$corrected_path = $this->path_helper->get_web_root_path();
		return (defined('PHPBB_USE_BOARD_URL_PATH') && PHPBB_USE_BOARD_URL_PATH) ? generate_board_url() . '/' : $corrected_path;
	}

	public function ext_path($ext_name = 'jv/arcade', $phpbb_relative = true)
	{
		return $this->ext_manager->get_extension_path($ext_name, $phpbb_relative);
	}

	public function set_image_path($type = false, $user_style = false)
	{
		$image_path = $this->ext_path() . 'styles/' . (($user_style) ? rawurlencode($this->user->style['style_path']) : 'all') . '/theme/images/';

		switch ($type)
		{
			case 'cat':
				$image_path .= 'cats/';
			break;

			case 'rank':
				$image_path .= 'ranks/';
			break;
		}

		return $image_path;
	}

	public function is_post_empty($name)
	{
		return $this->request->is_set_post($name) && $this->request->variable($name, false);
	}

	public function is_set_get($name)
	{
		return $this->request->is_set($name, \phpbb\request\request_interface::GET);
	}

	public function user_default_settings($user_id = false)
	{
		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
		}

		$user_options  = ($user_id == ANONYMOUS) ? 2044 : 2047;

		return array(
			'user_arcade_options'		=> $user_options,
			'games_sort_dir'			=> $this->arcade_config['default_games_sort_dir'],
			'games_sort_order'			=> $this->arcade_config['default_games_sort_order'],
			'arcade_cat_style'			=> $this->arcade_config['default_cat_style'],
			'arcade_cat_games_style'	=> $this->arcade_config['default_cat_games_style']
		);
	}

	public function lang_value($key, $empty_value = false)
	{
		return (!empty($this->user->lang[$key])) ? $this->user->lang[$key] : (($empty_value) ? '' : $key);
	}

	public function position($value)
	{
		$r = 'left';

		switch ($value)
		{
			case ARCADE_POSITION_CENTER:
				$r = 'center';
			break;

			case ARCADE_POSITION_RIGHT:
				$r = 'right';
			break;
		}

		return $r;
	}

	public function auth_check($arcade_page = '', $mode = '', $type = '')
	{
		if (defined('IN_ADMIN'))
		{
			if (!$this->version_check())
			{
				trigger_error('ACP_ARCADE_UPDATE_NOT_AUTHORISED', E_USER_WARNING);
			}
			else if (!$this->ext()->verify_install('startsystem', false))
			{
				$msg = ($this->user->data['user_type'] == USER_FOUNDER) ? $this->user->lang('ACP_ARCADE_NOT_FOUND_JVA_START_SYSTEM', '<a onclick="window.open(this.href); return false;" href="' . $this->arcade_config['support_domain'] . 'Downloads.html">', '</a>'): 'ACP_ARCADE_NOT_FOUND_JVA_START_SYSTEM_INFO';
				trigger_error($msg, E_USER_WARNING);
			}
		}
		else
		{
			$this->ban_check();

			if (!$this->version_check() || !$this->ext()->verify_install('startsystem', false) || (!$this->arcade_config['activation_key'] && !$this->localhost()))
			{
				trigger_error('NOT_AUTHORISED');
			}
		}

		$vars = array('arcade_page', 'mode', 'type');
		extract($this->phpbb_dispatcher()->trigger_event('jv.arcade.auth_check', compact($vars)));

		if (!defined('IN_ADMIN'))
		{
			$this->room_auth($arcade_page, $mode, $type);
		}
	}

	private function room_auth($arcade_page, $mode, $type)
	{
		$err = false;
		// Is arcade or challenge disabled and user not an admin?
		$user_admin = ($this->user->data['is_registered'] && $this->auth->acl_get('a_')) ? true : false;
		$acp_download_list_connection = ($mode == 'download' && $this->user->data['user_id'] == ANONYMOUS && ($type == 'data' || $type == 'list')) ? true : false;

		if (!$acp_download_list_connection && !$user_admin && ($this->arcade_config['arcade_disable'] || ($arcade_page == 'challenge' && $this->arcade_config['challenge_disable']) || ($arcade_page == 'tour' && $this->arcade_config['tour_disable'])))
		{
			if ($this->user->data['is_bot'])
			{
				send_status_line(503, 'Service Unavailable');
			}

			if ($this->arcade_config['arcade_disable'])
			{
				$err = (!empty($this->arcade_config['arcade_disable_msg'])) ? $this->arcade_config['arcade_disable_msg'] : $this->user->lang['ARCADE_DISABLE'];
			}
			else
			{
				$msg_key = (($arcade_page == 'arcade') ? '' : 'ARCADE_') . strtoupper($arcade_page) . '_DISABLE';
				$err = (!empty($this->arcade_config["{$arcade_page}_disable_msg"])) ? $this->arcade_config["{$arcade_page}_disable_msg"] : $this->user->lang[$msg_key];
			}
		}

		if (!$err)
		{
			if (!$acp_download_list_connection && !$this->access($arcade_page))
			{
				$msg_key = (($arcade_page == 'arcade') ? '' : 'ARCADE_') . strtoupper($arcade_page) . '_NO_PERMISSION';
				$err = $this->user->lang[$msg_key];
			}
		}

		if ($err && !$this->test_system())
		{
			trigger_error($err . (($this->request->variable('gp', false) || strtolower($this->request->variable('mode', '')) == 'popup') ? $this->close_win() : ''));
		}

		switch ($mode)
		{
			case 'download':
				if (!$acp_download_list_connection && !$this->game()->download_auth('user'))
				{
					$err = 'NO_PERMISSION_ARCADE_DOWNLOAD';
				}
			break;

			case 'stats':
				if (!$this->auth->acl_get('u_arcade_viewstats'))
				{
					$params = ($arcade_page == 'tour') ? 'tournament' : (($arcade_page == 'challenge') ? $arcade_page : '');
					$params = ($params) ? "mode=$params" : '';

					$err = 'STATS';
				}
			case 'fav':
				if ($mode == 'fav' && !$this->auth->acl_get('u_arcade_favorites'))
				{
					$err = 'FAV';
				}
			case 'search':
				if ($mode == 'search' && !$this->auth->acl_get('u_arcade_search'))
				{
					$err = 'SEARCH';
				}

				if ($err)
				{
					$err = 'ARCADE_NO_PERMISSION_' . $err;
				}
			break;
		}

		if ($err && !$this->test_system())
		{
			send_status_line(403, 'Forbidden');
			trigger_error($this->user->lang[$err] . $this->back_link());
		}
	}

	public function localhost()
	{
		return (!substr(strrchr($this->user->host, '.'), 1) || substr($this->user->host, 0, 4) == '127.' || in_array($this->user->host, array('localhost', '::1')) || substr($this->user->host, 0, 8) == '192.168.') ? true : false;
	}

	public function set_userdata(&$userdata)
	{
		$userdata['user_id'] = (int) $userdata['user_id'];

		if (!$userdata['user_id'])
		{
			return;
		}

		// Add arcade user data to $this->user->data
		$sql = 'SELECT *
				FROM ' . ARCADE_USERS_TABLE . '
				WHERE user_id = ' . $userdata['user_id'];
		$result = $this->db->sql_query($sql);
		$arcade_data = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$arcade_data)
		{
			$arcade_data = $this->user_add($userdata['user_id'], false);
		}

		$userdata = array_merge($userdata, $arcade_data);
	}

	public function user_add($user_id, $new_user = true)
	{
		$sql_ary = array_merge(array(
			'user_id'						=> (int) $user_id,
			'user_arcade_permissions'		=> '',
			'user_arcade_perm_from'			=> 0,
			'user_arcade_last_download'		=> 0,
			'user_arcade_last_play'			=> 0,
			'user_arcade_rank'				=> 0,
			'games_last_search'				=> 0,
			'games_last_search_term'		=> ''
		), $this->user_default_settings($user_id));

		$this->db->sql_query('INSERT INTO ' . ARCADE_USERS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));

		if ($new_user)
		{
			$this->cache->destroy('sql', ARCADE_CHALLENGE_CHAMP_TABLE);
			return;
		}

		return $sql_ary;
	}

	public function root_key($file)
	{
		return str_replace($this->root_path, '[ROOT]/', $file);
	}

	private function gen_popup_link($url = false)
	{
		$out = '';
		if ($url && $this->game()->session->game_popup)
		{
			$out = '<a href="' . $url . '" data-jvarcade="page_refresh" rel="nofollow">' . $this->user->lang['CLOSE_WINDOW'] . '</a>';
		}
		else if ($this->game()->session->game_popup)
		{
			$out = '<a href="#" data-jvarcade="close_window" rel="nofollow">' . $this->user->lang['CLOSE_WINDOW'] . '</a>';
		}
		else
		{
			$out = sprintf($this->user->lang['ARCADE_JUMP_ARCADE_MAIN_PAGE'], '<a href="#" data-jvarcade="arcade_index" rel="nofollow">', '</a>');
		}

		return $out;
	}

	private function page_enable($page)
	{
		$portal_page = ($this->page() == 'portal' && $this->portal()->data['show']) ? true : false;

		if (($page == ARCADE_NO_DISPLAY) || ($page == ARCADE_DISPLAY_EVERY_EXCEPT_PORTAL && $portal_page))
		{
			return false;
		}

		if (($page == ARCADE_DISPLAY_EVERY) || (!$portal_page && $page == ARCADE_DISPLAY_EVERY_EXCEPT_PORTAL))
		{
			return true;
		}

		switch ($page)
		{
			case ARCADE_DISPLAY_ARCADE:
				return (defined('PHPBB_ARCADE_START')) ? true : false;
			break;

			case ARCADE_DISPLAY_FORUM:
				return (!$portal_page && !defined('PHPBB_ARCADE_START')) ? true : false;
			break;

			case ARCADE_DISPLAY_PORTAL:
				return ($portal_page) ? true : false;
			break;
		}
	}

	public function error($title, $message, $status, $extra = '')
	{
		$this->json(array(
			'title'	=> $this->user->lang($title),
			'error'	=> $this->user->lang($message, $extra),
			'status'=> $status
		));
	}

	public function json($data)
	{
		if (!is_array($data))
		{
			$data = array($data);
		}

		$json_response = new \phpbb\json_response();
		$json_response->send($data);
	}
}
