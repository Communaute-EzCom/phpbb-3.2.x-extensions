<?php
/**
*
* @package phpBB Arcade
* @version $Id: ext_interface.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\ext;

interface ext_interface
{
	public function get_version();

	public function get_name();

	public function get_language();

	public function get_template_acp();
}
