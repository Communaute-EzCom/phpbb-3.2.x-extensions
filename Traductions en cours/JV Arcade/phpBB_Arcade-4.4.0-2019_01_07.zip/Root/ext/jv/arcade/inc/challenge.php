<?php
/**
*
* @package phpBB Arcade
* @version $Id: challenge.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class challenge
{
	protected $db, $cache, $auth, $request, $user, $template, $arcade_cache, $arcade_config, $arcade_auth, $arcade;

	public function __construct($db, $cache, $auth, $request, $user, $template, $arcade_cache, $arcade_config, $arcade_auth, $arcade)
	{
		$this->db = $db;
		$this->cache = $cache;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
	}

	public function main($in_chall = false)
	{
		if ($in_chall)
		{
			$this->template->assign_var('S_IN_ARCADE_CHALLENGE', true);
		}
	}

	public function display(&$mode, $game_id, $user_id, $detailed_stats)
	{
		if ((!$this->user->data['is_registered'] && !$detailed_stats) || !$this->arcade->access('challenge', false))
		{
			$mode = '';
		}

		$error1 = $error2 = array();
		$arrived_id		= $this->request->variable('arrived_id', array(0));
		$sent_id		= $this->request->variable('sent_id' , array(0));
		$bet			= $this->request->variable('bet', 0.00);
		$username		= $this->request->variable('username', '', true);
		$submit			= ($this->request->is_set_post('submit')) ? true : false;
		$accept			= ($this->request->is_set_post('accept')) ? true : false;
		$reject			= ($this->request->is_set_post('reject')) ? true : false;
		$withdraw		= ($this->request->is_set_post('withdraw')) ? true : false;
		$action			= ($accept) ? 'accept' : (($reject) ? 'reject' : (($withdraw) ? 'withdraw' : ''));
		$act_ids		= (count($arrived_id)) ? $arrived_id : ((count($sent_id)) ? $sent_id : array());

		switch ($mode)
		{
			case 'champion_challenge':
				$user_id = ($user_id == ANONYMOUS)? 0 : $user_id;
				$this->create('champion', $game_id, $user_id, $username, $bet, $error1);
			break;

			case 'rand_challenge':
				if ($this->arcade_config['random_challenge'])
				{
					$this->arcade->add_navlink('add', "mode=$mode", 'CHALLENGE_RANDOM');
					$this->random();
				}
			break;

			default:
				if (!$detailed_stats)
				{
					if ($this->user->data['is_registered'] && $this->arcade->access('challenge', false))
					{
						if ($submit)
						{
							if (!check_form_key('challenge'))
							{
								$error1[] = $this->user->lang['FORM_INVALID'];
							}

							$user_id = ($user_id == ANONYMOUS)? 0 : $user_id;
							$this->create('default', $game_id, $user_id, $username, $bet, $error1);
						}

						if ($action)
						{
							$this->user_action($action, $act_ids, $error2);
						}

						if ($this->arcade->optionget('challenge'))
						{
							$this->display_challenge($game_id, $user_id, $username, $bet, $error1, $error2);
						}
						else
						{
							$this->template->assign_var('S_CHALLENGE_USER_DISABLE', sprintf($this->user->lang['CHALLENGE_USER_DISABLE'], '<a href="' . $this->arcade->url($this->arcade->module_url('manage', 'u') .  '&amp;mode=settings', 'ucp', $this->user->session_id) . '#tabs">', '</a>'));
						}

						$this->template->assign_var('S_HAS_ARCADE_CHALLENGE', true);
					}

					$this->arcade->display()->main_box('challenge', $this->arcade_config['welcome_index']);
				}
			break;
		}
	}

	public function play_games()
	{
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.game_name, g.game_name_clean, c.cat_id,
							r.report_id,
							f.user_id, f.highlighted',
			'FROM'		=> array(ARCADE_GAMES_TABLE => 'g'),
			'LEFT_JOIN'	=> array(
				array('FROM' => array(ARCADE_CATS_TABLE				=> 'c'),  'ON' => 'g.cat_id = c.cat_id'),
				array('FROM' => array(ARCADE_REPORTS_TABLE			=> 'r'),  'ON' => 'g.game_id = r.game_id'),
				array('FROM' => array(ARCADE_FAVS_TABLE				=> 'f'),  'ON' => 'g.game_id = f.game_id AND f.user_id = ' . (int) $this->user->data['user_id']),
			),
			'WHERE'		=> $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions('c_play'), false, true) . '
				AND c.cat_test <> ' . ARCADE_CAT_TEST . '
				AND c.cat_status = ' . ITEM_UNLOCKED . '
				AND g.game_save_type <> ' . NOSCORE_GAME,
			'ORDER_BY'	=> 'g.game_name_clean ASC'
		);

		$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
		$result = $this->db->sql_query($sql);
		$games = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (!empty($row['report_id']))
			{
				continue;
			}

			$games[$row['game_id']] = array(
				'cat_id'		=> $row['cat_id'],
				'game_name'		=> $row['game_name'],
				'game_fav'		=> (!empty($row['user_id'])) ? true : false,
				'highlighted'	=> (!empty($row['highlighted'])) ? true : false
			);
		}
		$this->db->sql_freeresult($result);

		return $games;
	}

	public function friends($user_id = false)
	{
		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
		}

		$sql = 'SELECT zebra_id
				FROM ' . ZEBRA_TABLE . '
				WHERE user_id = ' . (int) $user_id . '
				AND ' . $this->db->sql_in_set('zebra_id', array_map('intval', array_keys($this->arcade->ban_users())), true, true) . '
				AND friend = 1';
		$result = $this->db->sql_query($sql);
		$friends = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$friends[$row['zebra_id']] = $row['zebra_id'];
		}
		$this->db->sql_freeresult($result);

		return $friends;
	}

	public function display_challenge($game_id, $user_id, $username, $bet, $error1, $error2)
	{
		$load_list = (count($error1)) ? true : false;

		if ($load_list)
		{
			$this->games_list(true);
		}

		$this->users_list(true);

		add_form_key('challenge');

		if ($this->arcade->points()->data['show'])
		{
			$this->template->assign_vars(array(
				'S_CHALLENGE_BET_FIX'	=> ($this->arcade_config['challenge_bet_fix']) ? true : false,

				'CHALLENGE_BET_MIN'		=> ($this->arcade_config['challenge_bet_minimum']) ? $this->arcade->number_format($this->arcade_config['challenge_bet_minimum']) . ' ' . $this->arcade->points()->data['name'] : false,
				'CHALLENGE_BET_MAX'		=> ($this->arcade_config['challenge_bet_maximum']) ? $this->arcade->number_format($this->arcade_config['challenge_bet_maximum']) . ' ' . $this->arcade->points()->data['name'] : false,
				'CHALLENGE_BET'			=> $this->arcade->number_format((($this->arcade_config['challenge_bet_fix']) ? $this->arcade_config['challenge_bet_fix'] : (($bet) ? $bet : $this->arcade_config['challenge_bet_minimum'])), true)
			));
		}

		$s_hidden_fields = array('mode' => 'challenge');

		$this->template->assign_vars(array(
			'U_ACTION'			=> $this->arcade->url() . '#challenge',
			'U_FIND_USERNAME'	=> $this->arcade->url('mode=searchuser&amp;form=challenge&amp;field=username&amp;select_single=true', 'memberlist'),

			'S_HIDDEN_FIELDS'	=> build_hidden_fields($s_hidden_fields),

			'S_ERROR1'			=> (count($error1)) ? true : false,
			'ERROR_MSG1'		=> implode('<br>', $error1),

			'S_ERROR2'			=> (count($error2)) ? true : false,
			'ERROR_MSG2'		=> implode('<br>', $error2),

			'OPPONENT_GAME_ID'	=> $game_id,
			'OPPONENT_USER_ID'	=> $user_id,
			'OPPONENT_USERNAME'	=> $username
		));

		if (!$load_list)
		{
			$sql_array = array(
				'SELECT'	=> 'c.challenge_id, c.challenge_time, c.challenge_points, c.challenger_id, c.opponent_id,
								cc.champ_challenger_score, cc.champ_opponent_score, cc.champ_challenger_time, cc.champ_opponent_time,
								g.game_id, g.game_name, g.game_image, g.game_width, g.game_height, g.cat_id,
								u1.user_id, u1.username, u1.user_colour,
								u2.user_id AS user_id2, u2.username AS username2, u2.user_colour AS user_colour2',
				'FROM'		=> array(
					ARCADE_CHALLENGE_TABLE	=> 'c',
				),
				'LEFT_JOIN'	=> array(
					array(
						'FROM'	=> array(ARCADE_CHALLENGE_CHAMP_TABLE => 'cc'),
						'ON'	=> 'c.game_id = cc.game_id AND c.challenger_id = cc.champ_challenger_id AND c.opponent_id = cc.champ_opponent_id'
					),
					array(
						'FROM'	=> array(USERS_TABLE => 'u1'),
						'ON'	=> 'c.challenger_id = u1.user_id'
					),
					array(
						'FROM'	=> array(USERS_TABLE => 'u2'),
						'ON'	=> 'c.opponent_id = u2.user_id'
					),
					array(
						'FROM'	=> array(ARCADE_GAMES_TABLE => 'g'),
						'ON'	=> 'c.game_id = g.game_id'
					),
					array(
						'FROM'	=> array(ARCADE_CATS_TABLE => 'ac'),
						'ON'	=> 'g.cat_id = ac.cat_id'
					),
				),
				'WHERE'		=> 'u1.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
					AND u2.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
					AND ac.cat_test <> ' . ARCADE_CAT_TEST . '
					AND ac.cat_status = ' . ITEM_UNLOCKED . '
					AND c.challenge_accept = ' . CHALLENGE_ACCEPTED . '
					AND cc.champ_close <> ' . CHALLENGE_CLOSE . '
					AND ' . $this->db->sql_in_set('ac.cat_id', $this->arcade->get()->permissions('c_play'), false, true) . '
					AND (c.challenger_id = ' . (int) $this->user->data['user_id'] . ' AND ' . $this->db->sql_in_set('c.opponent_id', array_map('intval', array_keys($this->arcade->ban_users())), true, true) . '
						OR
						c.opponent_id = ' . (int) $this->user->data['user_id'] . ' AND ' . $this->db->sql_in_set('c.challenger_id', array_map('intval', array_keys($this->arcade->ban_users())), true, true) . ')',
				'ORDER_BY'	=> 'c.challenge_time, c.game_id ASC'
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);

			$ong_count = 0;
			$s_report = false;
			while ($ongoing = $this->db->sql_fetchrow($result))
			{
				if (time() >= $ongoing['challenge_time'])
				{
					continue;
				}

				$ong_count++;
				$opp_uid			= ($this->user->data['user_id'] == $ongoing['user_id']) ? $ongoing['user_id2'] : $ongoing['user_id'];
				$opp_uname			= ($this->user->data['user_id'] == $ongoing['user_id']) ? $ongoing['username2'] : $ongoing['username'];
				$opp_ucolour		= ($this->user->data['user_id'] == $ongoing['user_id']) ? $ongoing['user_colour2'] : $ongoing['user_colour'];
				$opp_username		= $this->arcade->get()->user_name('full', $opp_uid, $opp_uname, $opp_ucolour, 'challenge', 'x');
				$opp_score			= ($this->user->data['user_id'] == $ongoing['challenger_id']) ? $ongoing['champ_opponent_score'] : $ongoing['champ_challenger_score'];
				$opp_time			= ($this->user->data['user_id'] == $ongoing['challenger_id']) ? $ongoing['champ_opponent_time'] : $ongoing['champ_challenger_time'];

				$own_score			= ($this->user->data['user_id'] == $ongoing['challenger_id']) ? $ongoing['champ_challenger_score'] : $ongoing['champ_opponent_score'];
				$own_time			= ($this->user->data['user_id'] == $ongoing['challenger_id']) ? $ongoing['champ_challenger_time'] : $ongoing['champ_opponent_time'];

				$game_report		= ($this->arcade_auth->acl_get('c_report', $ongoing['cat_id'])) ? true : false;
				$own_played			= ($own_score == 0 && !$own_time) ? false : true;
				$opponent_played	= ($opp_score == 0 && !$opp_time) ? false : true;
				$title				= ($own_played) ? '' : $this->user->lang['ARCADE_PLAY_LINK'];
				$game_image			= ($this->arcade->optionget('view_game_image')) ? (($own_played) ? $this->arcade->get()->game_image($ongoing['game_image'], 30, 30) : $this->arcade->get()->game_image($ongoing['game_image'], 30, 30, 'x', 'play', $ongoing['cat_id'], $ongoing['game_id'])) : false;
				$popup_icon			= ($this->arcade->optionget('view_popup_icon')) ? $this->arcade->get()->game_popup('icon', $ongoing['cat_id'], $ongoing['game_id'], $ongoing['game_width'], $ongoing['game_height'], 'x', 13) . ' ' : '';
				$game_name			= ($own_played) ? $ongoing['game_name'] : $popup_icon . $this->arcade->get()->game_name($ongoing['game_name'], true, 'play', $ongoing['cat_id'], $ongoing['game_id'], 'x');

				$bet				= ($this->arcade->points()->data['installed'] && $ongoing['challenge_points'] > 0) ? ' ' . sprintf($this->user->lang['CHALLENGE_TOURNAMENT_BET'], $this->arcade->number_format($ongoing['challenge_points']) . ' ' . $this->arcade->points()->data['name']) : '';
				$ongoing_info		= sprintf($this->user->lang['CHALLENGE_ONGOING_INFO'], sprintf($this->user->lang['ARCADE_GAME_PLAY' . (($own_played) ? 'ED' : '')], $game_name), $opp_username, $this->user->lang['ARCADE_C_' . (($opponent_played) ? 'ALREADY' : 'NOT') . '_PLAYED'] . $bet);

				if ($game_report)
				{
					$s_report = true;
				}

				$this->template->assign_block_vars('ongoing', array(
					'S_REPORT_GAME'	=> $game_report,

					'GAME_IMAGE'	=> $game_image,
					'CHALLENGE'		=> $ongoing_info,
					'EXP_DATE'		=> $this->user->format_date($ongoing['challenge_time'], false, true),
					'GAME_REPORT'	=> ($game_report) ? '<a href="' . $this->arcade->url('mode=report&amp;type=challenge&amp;g=' . $ongoing['game_id'] . '&amp;cid=' . $ongoing['challenge_id']) . '#report_game">' . $this->user->lang['ARCADE_REPORT_GAME'] . '</a>' : ''
				));
			}
			$this->db->sql_freeresult($result);

			$arriveds	= $this->user_challenges('arrived');
			$sents		= $this->user_challenges('sent');

			$this->template->assign_vars(array(
				'S_REPORT_GAME'			=> $s_report,
				'S_CURRENT_CHALLENGES'	=> true,

				'ONGOING_CHALLENGE'		=> $this->user->lang['CHALLENGE_ONGOING_CHALLENGE' . (($ong_count > 1) ? 'S' : '')],
				'ARRIVED_CHALLENGE'		=> $this->user->lang['CHALLENGE_ARRIVED_CHALLENGE' . (($arriveds > 1) ? 'S' : '')],
				'SENT_CHALLENGE'		=> $this->user->lang['CHALLENGE_SENT_CHALLENGE' . (($sents > 1) ? 'S' : '')],
			));
		}
	}

	public function user_challenges($type)
	{
		$sql_array = array(
			'SELECT'		=> 'c.challenge_id, c.challenge_points, c.challenge_time, g.game_id, g.game_name, g.game_image, g.game_width, g.game_height, g.cat_id, u.user_id, u.username, u.username_clean, u.user_colour',
			'FROM'			=> array(
				ARCADE_CHALLENGE_TABLE => 'c',
			),
			'LEFT_JOIN'		=> array(
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'c.' . (($type == 'arrived') ? 'challenger_id' : 'opponent_id') . ' = u.user_id'
				),
				array(
					'FROM'	=> array(ARCADE_GAMES_TABLE => 'g'),
					'ON'	=> 'c.game_id = g.game_id'
				),
				array(
					'FROM'	=> array(ARCADE_CATS_TABLE => 'ac'),
					'ON'	=> 'g.cat_id = ac.cat_id'
				),
			),
			'WHERE'			=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
				AND ' . $this->db->sql_in_set('u.user_id', array_map('intval', array_keys($this->arcade->ban_users())), true, true) . '
				AND ac.cat_test <> ' . ARCADE_CAT_TEST . '
				AND ac.cat_status = ' . ITEM_UNLOCKED . '
				AND ' . $this->db->sql_in_set('ac.cat_id', $this->arcade->get()->permissions('c_play'), false, true) . '
				AND c.' . (($type == 'arrived') ? 'opponent_id' : 'challenger_id') . ' = ' . (int) $this->user->data['user_id'] . ' AND c.challenge_accept = ' . CHALLENGE_UNACCEPTED,
			'ORDER_BY'		=> 'c.challenge_time, u.username_clean, c.game_id ASC'
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$count = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			if(time() >= $row['challenge_time'])
			{
				continue;
			}

			$count[]	= $row['challenge_id'];
			$popup_icon	= ($this->arcade->optionget('view_popup_icon')) ? $this->arcade->get()->game_popup('icon', $row['cat_id'], $row['game_id'], $row['game_width'], $row['game_height'], 'x', 13) . ' ' : '';
			$game_name	= $popup_icon . $this->arcade->get()->game_name($row['game_name'], true, 'play', $row['cat_id'], $row['game_id'], 'x');
			$username	= $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'challenge', 'x');
			$bet		= ($this->arcade->points()->data['installed'] && $row['challenge_points'] > 0) ? ' ' . sprintf($this->user->lang['CHALLENGE_' . strtoupper($type) . '_BET'], $this->arcade->number_format($row['challenge_points']) . ' ' . $this->arcade->points()->data['name']) : '';
			$info		= sprintf($this->user->lang['CHALLENGE_' . strtoupper($type) . '_INFO'], $username, $game_name) . $bet;

			$this->template->assign_block_vars($type, array(
				'GAME_IMAGE'	=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($row['game_image'], 30, 30, 'x', 'play', $row['cat_id'], $row['game_id']) : false,
				'CHALLENGE'		=> $info,
				'EXP_DATE'		=> $this->user->format_date($row['challenge_time'], false, true),
				'ID'			=> $row['challenge_id']
			));
		}
		$this->db->sql_freeresult($result);

		return count($count);
	}

	public function games_list($load = false)
	{
		$user_fav = $play_games = false;

		if ($load && $this->user->data['is_registered'] && $this->arcade_config['played_colour'])
		{
			// Quick jump of all the games in the arcade challenge...
			$played_games = $this->get_played_games();
			$this->template->assign_var('PLAYED_GAME_TITLE', ' title="' . $this->user->lang['CHALLENGE_PLAYED_GAMES_HIGHLIGHT'] . '"');
		}

		$user_age = $this->arcade->get()->user_age();
		$founder_exemption = ($this->arcade_config['founder_exempt'] && $this->user->data['user_type'] == USER_FOUNDER) ? true : false;

		foreach ((($load) ? $this->play_games() : $this->get_played_games(false, true)) as $gid => $game)
		{
			$cat_age = $this->arcade->get()->cat_field($game['cat_id'], 'cat_age');

			if ($load && $cat_age && !$founder_exemption && (!$user_age || ($user_age < $cat_age)))
			{
				continue;
			}

			$play_games = true;

			if (!$load && !$this->arcade_config['load_list'])
			{
				break;
			}

			if ($this->arcade_config['load_list'] || $load)
			{
				$this->template->assign_block_vars((($load) ? 'quick_jump' : 'game_jump'), array(
					'S_PLAYED_GAME'	=> (!empty($played_games[$gid])) ? true : false,
					'GAME_ID'		=> $gid,
					'GAME_NAME'		=> $game['game_name'],
				));
			}

			if ($load && $game['game_fav'] && $this->auth->acl_get('u_arcade_favorites'))
			{
				$user_fav = true;
				$this->template->assign_block_vars('quick_fav',array(
					'S_GAME_HIGHLIGHTED'	=> $game['highlighted'],

					'GAME_ID'				=> $gid,
					'GAME_NAME'				=> $game['game_name']
				));
			}
		}

		if ($load && !$user_fav)
		{
			$this->template->assign_var('S_FAV_DISABLED_RADIO', true);
		}

		if (!$load && !$this->arcade_config['load_list'])
		{
			$this->template->assign_var('STATS_GAMES_LIST_LOADING', (($play_games) ? '<a href="#" data-jvarcade="ajax" data-mode="games_list" data-type="challenge" data-action="played" rel="nofollow"><b>' . $this->user->lang['ARCADE_GAMES_LIST_LOAD'] . '</b></a>' : $this->user->lang['ARCADE_NO_GAMES']));
		}
	}

	public function obtain_all_users($no_cache = false, $stat_page = false)
	{
		$sql_array = array(
			'SELECT'		=> 'u.user_id, u.username, u.username_clean, au.user_arcade_options, c.champ_id',
			'FROM'			=> array(USERS_TABLE	=> 'u',),
			'LEFT_JOIN'		=> array(
				array('FROM'	=> array(ARCADE_CHALLENGE_CHAMP_TABLE	=> 'c'),  'ON' => 'c.champ_close = ' . CHALLENGE_CLOSE . ' AND (c.champ_challenger_id = u.user_id OR c.champ_opponent_id = u.user_id)'),
				array('FROM'	=> array(ARCADE_USERS_TABLE				=> 'au'), 'ON' => 'u.user_id = au.user_id')
			),
			'WHERE'			=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')',
			'ORDER_BY'		=> 'u.username_clean ASC',
		);

		if (!$stat_page)
		{
			$sql_array['LEFT_JOIN'][] = array('FROM' => array(BANLIST_TABLE => 'b'), 'ON' => 'u.user_id = b.ban_userid');
			$sql_array['WHERE'] .= ' AND (b.ban_id IS NULL OR b.ban_exclude = 1)';
		}

		if ($no_cache)
		{
			$sql_array['SELECT'] .= ', u.user_type, u.user_permissions, au.user_arcade_permissions';
			$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
			$result = $this->db->sql_query($sql);
		}
		else
		{
			$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
			$result = $this->db->sql_query($sql, $this->arcade->hour($this->arcade_config['cache_time']));
		}

		$challenge_users = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (!$stat_page && in_array($row['user_id'], array_keys($this->arcade->ban_users())))
			{
				continue;
			}

			if (!isset($row['user_arcade_options']))
			{
				$this->arcade->set_userdata($row);
			}

			if (!$this->arcade->optionget('challenge', $row['user_arcade_options'], true))
			{
				continue;
			}

			$challenge_users[$row['user_id']] = array(
				'user_id'	=> $row['user_id'],
				'username'	=> $row['username'],
				'user_play'	=> (!empty($row['champ_id'])) ? true : false
			);

			if ($no_cache)
			{
				$challenge_users[$row['user_id']]['user_type']					= $row['user_type'];
				$challenge_users[$row['user_id']]['user_permissions']			= $row['user_permissions'];
				$challenge_users[$row['user_id']]['user_arcade_permissions']	= $row['user_arcade_permissions'];
			}
		}
		$this->db->sql_freeresult($result);

		return $challenge_users;
	}

	public function users_list($load = false, $stat_page = false)
	{
		$user_friends = $challenge_users = false;

		// Quick jump of all the users in the challenge...
		if ($load)
		{
			$friend = $this->friends();

			if ($this->arcade_config['played_colour'] && $this->user->data['is_registered'] && $this->arcade_config['challenge_users_select'])
			{
				$played_users = $this->get_played_users();
				$this->template->assign_var('PLAYED_USER_TITLE', ' title="' . $this->user->lang['CHALLENGE_PLAYED_USERS_HIGHLIGHT'] . '"');
			}
		}

		foreach ($this->obtain_all_users(false, $stat_page) as $uid => $_user)
		{
			if (($load && ($uid == $this->user->data['user_id'])) || (!$load && !$_user['user_play']))
			{
				continue;
			}

			$challenge_users = true;

			if (!$this->arcade_config['challenge_users_select'] && !$load)
			{
				break;
			}

			if ($load && !empty($friend[$uid]) && $uid == $friend[$uid])
			{
				$user_friends = true;
				$this->template->assign_block_vars('friends', array(
					'USER_ID'	=> $uid,
					'USERNAME'	=> $_user['username'],
				));
			}

			if ($this->arcade_config['challenge_users_select'] && ($this->arcade_config['load_list'] || $load))
			{
				$this->template->assign_block_vars((($load) ? 'user_jump' : 'stat_user_jump'), array(
					'S_PLAYED_USER'	=> (!empty($played_users[$uid])) ? true : false,
					'USER_ID'		=> $uid,
					'USERNAME'		=> $_user['username'],
				));
			}
		}

		if ($load && !$user_friends)
		{
			$this->template->assign_var('S_FRIEND_DISABLED_RADIO', true);
		}

		if ($this->arcade_config['challenge_users_select'] && $load)
		{
			$this->template->assign_var('S_USER_SELECT', true);
		}
		else if (!$this->arcade_config['load_list'] && !$load)
		{
			$this->template->assign_var('USERS_LIST_LOADING', (($challenge_users) ? '<a href="#" data-jvarcade="ajax" data-mode="users_list" data-type="challenge" data-action="played" rel="nofollow"><b>' . $this->user->lang['ARCADE_USERS_LIST_LOAD'] .'</b></a>' : $this->user->lang['CHALLENGE_NO_USERS']));
		}
		else if($load)
		{
			$this->template->assign_var('S_USER_TEXT', ($challenge_users) ? true : false);
		}
	}

	/**
	* Return an array contain all the game ids and names
	* of the games the user has challenge played, if no user id is
	* passed it defaults to viewing user
	* $all = true, all users challenge played
	*/
	public function get_played_games($user_id = false, $all = false)
	{
		if ($all)
		{
			$sql_array = array(
				'SELECT'	=> 'g.game_id, g.game_name, g.game_name_clean, g.cat_id',
				'FROM'		=> array(ARCADE_CHALLENGE_CHAMP_TABLE => 'c'),
				'LEFT_JOIN'	=> array(
					array('FROM' => array(ARCADE_GAMES_TABLE => 'g'), 'ON' => 'c.game_id = g.game_id')
				),
				'WHERE'		=> 'c.champ_close = ' . CHALLENGE_CLOSE . '
					AND c.game_id = g.game_id',
				'ORDER_BY'	=> 'g.game_name_clean ASC'
			);
		}
		else
		{
			if (!$this->user->data['is_registered'] || !$this->arcade_config['played_colour'])
			{
				return array();
			}

			if (!$user_id)
			{
				$user_id = $this->user->data['user_id'];
			}

			$sql_array = array(
				'SELECT'	=> 'g.game_id',
				'FROM'		=> array(ARCADE_CHALLENGE_CHAMP_TABLE => 'c'),
				'LEFT_JOIN'	=> array(
					array('FROM' => array(ARCADE_GAMES_TABLE => 'g'), 'ON' => 'c.game_id = g.game_id')
				),
				'WHERE'		=> 'c.champ_close = ' . CHALLENGE_CLOSE . '
					AND (c.champ_challenger_id = ' . (int) $user_id . ' OR c.champ_opponent_id = ' . (int) $user_id . ')',
			);
		}

		$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
		$result = $this->db->sql_query($sql);
		$played = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			if ($all)
			{
				$played[$row['game_id']] = array(
					'cat_id'	=> $row['cat_id'],
					'game_name'	=> $row['game_name']
				);
			}
			else
			{
				$played[$row['game_id']] = 1;
			}
		}
		$this->db->sql_freeresult($result);

		return $played;
	}

	public function get_played_users($user_id = false)
	{
		if (!$this->user->data['is_registered'] || !$this->arcade_config['played_colour'])
		{
			return array();
		}

		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
		}

		$sql_array = array(
			'SELECT'	=> 'u.user_id',
			'FROM'		=> array(
				USERS_TABLE => 'u',
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(ARCADE_CHALLENGE_CHAMP_TABLE => 'c'),
					'ON'	=> '(u.user_id = c.champ_challenger_id OR u.user_id = c.champ_opponent_id)'
				),
			),
			'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
				AND c.champ_close = ' . CHALLENGE_CLOSE . '
				AND (c.champ_challenger_id = ' . (int) $user_id . ' OR c.champ_opponent_id = ' . (int) $user_id . ')',
		);

		$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
		$result = $this->db->sql_query($sql);

		$played = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$played[$row['user_id']] = true;
		}
		$this->db->sql_freeresult($result);

		return $played;
	}

	public function create($mode, $game_id, $user_id, &$username, $bet, &$error)
	{
		$game_opponent_data = $this->arcade->get()->game_cat_data($game_id);

		if ($game_opponent_data)
		{
			$game_opponent_data = array_merge($game_opponent_data, $this->arcade->userdata('set_auth', $user_id, $username));
		}

		if (!isset($game_opponent_data['game_id']) || !$game_opponent_data['game_id'])
		{
			$error[] = $this->user->lang['NO_GAME_ID'];
		}

		if (!isset($game_opponent_data['user_id']) || !$game_opponent_data['user_id'])
		{
			$error[] = $this->user->lang['NO_USER_ID'];
		}

		if (!empty($game_opponent_data['user_id']) && ($game_opponent_data['user_id'] == $this->user->data['user_id']))
		{
			$error[] = $this->user->lang['CHALLENGE_OPPONENT_MYSELF_ERROR'];
		}

		if (!count($error))
		{
			if (!$this->arcade->optionget('challenge', $game_opponent_data['user_arcade_options'], true))
			{
				$error[] = sprintf($this->user->lang['CHALLENGE_OPPONENT_USER_DISADLED_ERROR'], $game_opponent_data['username']);
			}
		}

		if (!count($error))
		{
			$auth2	= new \phpbb\auth\auth();
			$auth2->acl($game_opponent_data);

			$arcade_auth2 = new auth\auth();
			$arcade_auth2->acl($game_opponent_data);

			$username = $game_opponent_data['username'];

			if (!$auth2->acl_get('u_arcade') || !in_array($game_opponent_data['user_type'], array(USER_NORMAL, USER_FOUNDER)) || in_array($game_opponent_data['user_id'], array_keys($this->arcade->ban_users())))
			{
				$error[] = sprintf($this->user->lang['ARCADE_OPPONENT_USER_NO_PERMISSION'], $game_opponent_data['username']);
			}

			if (!$auth2->acl_get('u_arcade_challenge'))
			{
				$error[] = sprintf($this->user->lang['CHALLENGE_OPPONENT_USER_NO_PERMISSION'], $game_opponent_data['username']);
			}

			if (!$arcade_auth2->acl_get('c_play', $game_opponent_data['cat_id']))
			{
				$error[] = sprintf($this->user->lang['CHALLENGE_NO_PERMISSION_ARCADE_PLAY'], $game_opponent_data['username'], $game_opponent_data['game_name']);
			}

			if ($this->user_game_opponent('def', $game_opponent_data['game_id'], $game_opponent_data['user_id']))
			{
				$error[] = sprintf($this->user->lang['CHALLENGE_DUPLICATION'], $game_opponent_data['username'], $game_opponent_data['game_name']);
			}

			$challenger_free_play = $opponent_free_play = true;
			$challenger_game_cost = $opponent_game_cost = $challenger_total_cost = $opponent_total_cost = 0;

			if (!count($error) && $this->arcade->points()->data['show'])
			{
				if ($this->arcade_config['challenge_bet_fix'] > 0)
				{
					$bet = $this->arcade_config['challenge_bet_fix'];
				}
				else
				{
					$bet = ($bet > 0) ? $bet : 0;
				}

				$challenger_points		= $this->arcade->points()->data['total'];
				$opponent_points		= $this->arcade->points()->user($game_opponent_data['user_id']);
				$game_cost				= $this->arcade->points()->game_cost($game_opponent_data);
				$game_cost				= ($game_cost > 0) ? $game_cost : 0;
				$challenger_free_play	= (!$game_cost || $this->arcade_auth->acl_get('c_playfree', $game_opponent_data['cat_id'])) ? true : false;
				$opponent_free_play		= (!$game_cost || $arcade_auth2->acl_get('c_playfree', $game_opponent_data['cat_id'])) ? true : false;
				$challenger_total_cost	= ($challenger_free_play) ? $bet : ($bet + $game_cost);
				$opponent_total_cost	= ($opponent_free_play) ? $bet : ($bet + $game_cost);
				$challenger_game_cost	= ($challenger_free_play) ? 0 : $game_cost;
				$opponent_game_cost		= ($opponent_free_play) ? 0 : $game_cost;

				if ($this->arcade_config['challenge_bet_fix'] == 0 && $this->arcade_config['challenge_bet_minimum'] > 0 && ($this->arcade_config['challenge_bet_minimum'] > $bet))
				{
					$error[] = $this->user->lang['CHALLENGE_BET_TOO_SMALL'];
				}
				else if ($this->arcade_config['challenge_bet_fix'] == 0 && $this->arcade_config['challenge_bet_maximum'] > 0 && ($this->arcade_config['challenge_bet_maximum'] < $bet))
				{
					$error[] = $this->user->lang['CHALLENGE_BET_TOO_LARGE'];
				}
				else
				{
					if (!$challenger_free_play && $game_cost > 0 && $challenger_points < $game_cost)
					{
						$error[] = sprintf($this->user->lang['CHALLENGE_CHALLENGER_USER_NO_POINTS'], $this->arcade->points()->data['name'], $this->arcade->number_format($game_cost) . ' ' . $this->arcade->points()->data['name'], $arcade>number_format($challenger_points) . ' ' . $this->arcade->points()->data['name']);
					}
					else
					{
						if (!$challenger_free_play && $challenger_total_cost > 0 && $challenger_points < $challenger_total_cost)
						{
							$error[] = sprintf($this->user->lang['CHALLENGE_CHALLENGER_BET_COST_NO_POINTS'], $this->arcade->number_format($challenger_total_cost) . ' ' . $this->arcade->points()->data['name'], $this->arcade->number_format($challenger_points) . ' ' . $this->arcade->points()->data['name']);
						}
						else if ($bet > 0 && $challenger_points < $bet)
						{
							$error[] = sprintf($this->user->lang['CHALLENGE_CHALLENGER_BET_NO_POINTS'], $this->arcade->number_format($challenger_points) . ' ' . $this->arcade->points()->data['name']);
						}
					}

					if (!$opponent_free_play && $game_cost > 0 && $opponent_points < $game_cost)
					{
						$error[] = sprintf($this->user->lang['CHALLENGE_OPPONENT_USER_NO_POINTS'], $game_opponent_data['username'], $this->arcade->points()->data['name'], $this->arcade->number_format($game_cost) . ' ' . $this->arcade->points()->data['name'], $game_opponent_data['username'], $this->arcade->number_format($opponent_points) . ' ' . $this->arcade->points()->data['name']);
					}
					else
					{
						if (!$opponent_free_play && $opponent_total_cost > 0 && $opponent_points < $opponent_total_cost)
						{
							$error[] = sprintf($this->user->lang['CHALLENGE_OPPONENT_BET_COST_NO_POINTS'], $this->arcade->number_format($opponent_total_cost) . ' ' . $this->arcade->points()->data['name'], $game_opponent_data['username'], $this->arcade->number_format($opponent_points) . ' ' . $this->arcade->points()->data['name']);
						}
						else if ($bet > 0 && $opponent_points < $bet)
						{
							$error[] = sprintf($this->user->lang['CHALLENGE_OPPONENT_BET_NO_POINTS'], $game_opponent_data['username'], $this->arcade->number_format($opponent_points) . ' ' . $this->arcade->points()->data['name']);
						}
					}
				}

				if (!count($error))
				{
					if ($challenger_total_cost > 0)
					{
						$this->arcade->points()->set('subtract', $this->user->data['user_id'], $challenger_total_cost);
					}

					if ($opponent_total_cost > 0)
					{
						$this->arcade->points()->set('subtract', $game_opponent_data['user_id'], $opponent_total_cost);
					}
				}
			}
			else
			{
				$bet = 0;
			}
		}

		unset($auth2);
		unset($arcade_auth2);

		if (!count($error))
		{
			$data = array(
				'challenge_points'		=> (float) $bet,
				'challenger_id'			=> (int) $this->user->data['user_id'],
				'opponent_id'			=> (int) $game_opponent_data['user_id'],
				'game_id'				=> (int) $game_opponent_data['game_id'],
				'challenger_game_cost'	=> (float) $challenger_game_cost,
				'opponent_game_cost'	=> (float) $opponent_game_cost,
				'challenge_time'		=> intval(time() + $this->arcade_config['challenge_acc_exp_date'])
			);

			$this->db->sql_query('INSERT INTO ' . ARCADE_CHALLENGE_TABLE . ' ' . $this->db->sql_build_array('INSERT', $data));

			//$challenge_id = $this->db->sql_nextid();

			$send_user_pm = ($this->arcade->optionget('arcade_pm', $game_opponent_data['user_arcade_options'], true)) ? true : false;

			if ($this->arcade_config['challenge_pm'] && $send_user_pm)
			{
				$challenge_data = array(
					'cat_id'					=> $game_opponent_data['cat_id'],
					'game_id'					=> $game_opponent_data['game_id'],
					'game_name'					=> $game_opponent_data['game_name'],
					'game_image'				=> $game_opponent_data['game_image'],
					'game_width'				=> $game_opponent_data['game_width'],
					'game_height'				=> $game_opponent_data['game_height'],
					'bet'						=> $bet,
					'free_play'					=> $opponent_free_play,
					'total_cost'				=> $opponent_total_cost,

					'other_user_id'				=> $game_opponent_data['user_id'],
					'other_username'			=> $game_opponent_data['username'],
					'other_user_colour'			=> $game_opponent_data['user_colour'],
					'other_user_lang'			=> $game_opponent_data['user_lang'],
					'other_user_arcade_options'	=> $game_opponent_data['user_arcade_options']
				);

				$this->arcade->phpbb()->send_pm('challenge', $challenge_data);
			}

			$deduction	= ($challenger_total_cost > 0) ? '<br>' . sprintf($this->user->lang['CHALLENGE_MSG_DEDUCTION_' . (($bet > 0) ? (($challenger_free_play) ? 'BET' : 'BET_COST') : 'COST')], $this->arcade->number_format($challenger_total_cost) . ' ' . $this->arcade->points()->data['name']) : '';
			$pm_ed		= ($this->arcade_config['challenge_pm']) ? ' ' . sprintf($this->user->lang['CHALLENGE_OTHER_USER_PM_' . (($send_user_pm) ? 'ENABLED' : 'DISABLED')], $game_opponent_data['username']) : '';
			$message	= $this->user->lang['CHALLENGE_SUCCESSFUL'] . '<br>' . $deduction . $pm_ed . (($mode == 'default') ? $this->arcade->back_link('mode=challenge', 'challenge') : '');
		}

		switch ($mode)
		{
			case 'champion':
				$lang_ary = array(
					'PAGE_TITLE'	=> $this->user->lang['ARCADE_CHALLENGE'] . ' ' . $this->user->lang['INFORMATION'],
					'MESSAGE_TITLE'	=> $this->user->lang['INFORMATION'],
					'MESSAGE_TEXT'	=> ((!count($error)) ? $message : implode('<br>', $error)) . $this->arcade->close_win()
				);

				$this->arcade->confirm($lang_ary);
			break;

			case 'random':
				if (count($error))
				{
					trigger_error(implode('<br>', $error));
				}

				$challenge_again = '<a class="' . (($this->user->lang['DIRECTION'] == 'ltr') ? 'left' : 'right') . '" href="' . $this->arcade->url('mode=rand_challenge') . '">' . $this->user->lang['CHALLENGE_RANDOM_AGAIN'] . '</a>';
				$message .= '<br><br>' . $challenge_again . $this->arcade->back_link('mode=challenge', 'challenge', false);
			default:
				if (!count($error))
				{
					trigger_error($message);
				}
			break;
		}
	}

	public function report($challenge_id)
	{
		$error = array();
		$msg = $this->user_action('report', $challenge_id, $error);

		if (count($error))
		{
			trigger_error(implode('<br>', $error) . $this->arcade->back_link('mode=challenge', 'challenge'));
		}

		return $msg;
	}

	public function user_action($action, $ids, &$error)
	{
		if (!$ids)
		{
			$error[] = $this->user->lang['NO_CHALLENGE_ID'];
		}
		else
		{
			$sql_arry = array(
				'SELECT'		=> 'c.challenger_id, c.opponent_id , c.challenge_points, c.challenger_game_cost, c.opponent_game_cost,
									g.game_id, g.game_name, g.cat_id,
									u.user_id , u.username, u.user_colour, u.user_lang,
									au.user_arcade_options',
				'FROM'			=> array(
					ARCADE_CHALLENGE_TABLE => 'c',
				),
				'LEFT_JOIN'		=> array(
					array(
						'FROM'	=> array(USERS_TABLE => 'u'),
						'ON'	=> ($action == 'report') ? '(c.opponent_id = ' . (int) $this->user->data['user_id'] . ' AND c.challenger_id = u.user_id) OR (c.challenger_id = ' . (int) $this->user->data['user_id'] . ' AND c.opponent_id = u.user_id)' : 'c.' . (($action == 'withdraw') ? 'opponent_id' : 'challenger_id') . ' = u.user_id AND c.' . (($action == 'withdraw') ? 'challenger_id' : 'opponent_id') . ' = ' . (int) $this->user->data['user_id']
					),
					array(
						'FROM'	=> array(ARCADE_USERS_TABLE => 'au'),
						'ON'	=> 'u.user_id = au.user_id'
					),
					array(
						'FROM'	=> array(ARCADE_GAMES_TABLE => 'g'),
						'ON'	=> 'c.game_id = g.game_id'
					),
				),
				'WHERE'			=> $this->db->sql_in_set('c.challenge_id', $ids) . '
					AND ' . $this->db->sql_in_set('g.cat_id', $this->arcade->get()->permissions('c_play'), false, true) . '
					AND c.challenge_accept = ' . (($action == 'report') ? CHALLENGE_ACCEPTED : CHALLENGE_UNACCEPTED)
			);

			if ($action == 'report')
			{
				$sql_arry['SELECT'] .= ', cc.champ_id';
				$sql_arry['LEFT_JOIN'][] = array('FROM' => array(ARCADE_CHALLENGE_CHAMP_TABLE => 'cc'), 'ON' => 'cc.champ_close <> ' . CHALLENGE_CLOSE . ' AND c.game_id = cc.game_id AND c.challenger_id = cc.champ_challenger_id AND c.opponent_id = cc.champ_opponent_id');
			}

			$sql = $this->db->sql_build_query('SELECT', $sql_arry);
			$result = $this->db->sql_query($sql);

			$more_chall = false;
			$datas = $champ_ids = $message = array();

			while ($row = $this->db->sql_fetchrow($result))
			{
				if ($action == 'report')
				{
					$champ_ids[] = $row['champ_id'];
				}

				if (!isset($datas[$row['user_id']]))
				{
					$datas[$row['user_id']] = array(
						'cat_id'					=> $row['cat_id'],
						'game_id'					=> $row['game_id'],
						'games_name'				=> array($row['game_name']),
						'username'					=> $row['username'],
						'user_colour'				=> $row['user_colour'],

						'user_lang'					=> $row['user_lang'],
						'user_arcade_options'		=> $row['user_arcade_options']
					);
				}
				else
				{
					$datas[$row['user_id']]['games_name'][] = $row['game_name'];
				}

				switch ($action)
				{
					case 'accept':
						$sql_array = array(
							'champ_challenger_id'	=> (int) $row['challenger_id'],
							'champ_opponent_id'		=> (int) $row['opponent_id'],
							'game_id'				=> (int) $row['game_id'],
							'champ_winner'			=> 0
						);

						$this->db->sql_query('INSERT INTO ' . ARCADE_CHALLENGE_CHAMP_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_array));
					break;

					case 'reject':
					case 'withdraw':
					case 'report':
						$challenger_cost = $opponent_cost = 0;
						if ($this->arcade->points()->data['installed'])
						{
							$challenger_cost	= floatval($row['challenge_points'] + $row['challenger_game_cost']);
							$opponent_cost		= floatval($row['challenge_points'] + $row['opponent_game_cost']);
						}

						$datas[$row['user_id']]['own_key'][$row['game_id']] = ($action == 'report') ? (($this->user->data['user_id'] == $row['challenger_id']) ? 'withdraw' : 'reject') : false;
						$datas[$row['user_id']]['ctc_count'] = (!isset($datas[$row['user_id']]['ctc_count'])) ? (($challenger_cost > 0) ? 1 : 0) : ($datas[$row['user_id']]['ctc_count'] + (($challenger_cost > 0) ? 1 : 0));
						$datas[$row['user_id']]['otc_count'] = (!isset($datas[$row['user_id']]['otc_count'])) ? (($opponent_cost > 0) ? 1 : 0) : ($datas[$row['user_id']]['otc_count'] + (($opponent_cost > 0) ? 1 : 0));

						$datas[$row['user_id']]['challenger_total_cost'] = (!isset($datas[$row['user_id']]['challenger_total_cost'])) ? $challenger_cost : ($datas[$row['user_id']]['challenger_total_cost'] + $challenger_cost);
						$datas[$row['user_id']]['opponent_total_cost'] = (!isset($datas[$row['user_id']]['opponent_total_cost'])) ? $opponent_cost : ($datas[$row['user_id']]['opponent_total_cost'] + $opponent_cost);
					break;
				}
			}
			$this->db->sql_freeresult($result);

			foreach ($datas as $user_id => $row)
			{
				$type = (!empty($row['own_key'][$row['game_id']])) ? $row['own_key'][$row['game_id']] : $action;

				$data = array(
					'games_name'				=> implode(', ', $row['games_name']),
					'total_cost'				=> ($type == 'reject') ? $row['challenger_total_cost'] : (($type == 'withdraw') ? $row['opponent_total_cost'] : 0),
					'tc_num'					=> ($type == 'reject') ? $row['ctc_count'] : (($type == 'withdraw') ? $row['otc_count'] : 0),

					'cat_id'					=> $row['cat_id'],
					'other_user_id'				=> $user_id,
					'other_username'			=> $row['username'],
					'other_user_colour'			=> $row['user_colour'],
					'other_user_lang'			=> $row['user_lang'],
					'other_user_arcade_options'	=> $row['user_arcade_options']
				);

				$total_cost		= ($type == 'reject') ? $row['opponent_total_cost'] : (($type == 'withdraw') ? $row['challenger_total_cost'] : 0);
				$tc_num			= ($type == 'reject') ? $row['otc_count'] : (($type == 'withdraw') ? $row['ctc_count'] : 0);
				$games_name		= sprintf($this->user->lang['CHALLENGE_GAME' . ((count($row['games_name']) > 1) ? 'S' : '')], $data['games_name']);
				$refund			= ($type != 'accept' && $total_cost > 0) ? ' ' . sprintf($this->user->lang['CHALLENGE_MSG_REFUND' . (($tc_num > 1) ? 'S' : '')], $this->arcade->number_format((float) $total_cost) . ' ' . $this->arcade->points()->data['name']) : '';
				$send_user_pm	= ($this->arcade->optionget('arcade_pm', $row['user_arcade_options'], true)) ? true : false;
				$pm_ed			= ($this->arcade_config['challenge_pm']) ? ' ' . sprintf($this->user->lang['CHALLENGE_OTHER_USER_PM_' . (($send_user_pm) ? 'ENABLED' : 'DISABLED')], $row['username']) : '';

				if ($type != 'accept')
				{
					$cid = ($type == 'reject') ? $user_id : $this->user->data['user_id'];
					$oid = ($type == 'reject') ? $this->user->data['user_id'] : $user_id;

					if ($row['challenger_total_cost'] > 0)
					{
						$this->arcade->points()->set('add', $cid, $row['challenger_total_cost']);
					}

					if ($row['opponent_total_cost'] > 0)
					{
						$this->arcade->points()->set('add', $oid, $row['opponent_total_cost']);
					}
				}

				if (count($row['games_name']) > 1)
				{
					$more_chall = true;
				}

				$message[] = $games_name . $refund . $pm_ed;

				if ($this->arcade_config['challenge_pm'] && $send_user_pm)
				{
					$method = "challenge_{$action}" . (($action == 'report') ? '_game' : '');
					$this->arcade->phpbb()->send_pm($method, $data);
				}
			}

			unset($datas);

			if (!count($message))
			{
				$error[] = $this->user->lang['NO_CHALLENGE'];
				return;
			}

			switch ($action)
			{
				case 'accept':
					$sql = 'UPDATE ' . ARCADE_CHALLENGE_TABLE . '
							SET challenge_accept = ' . CHALLENGE_ACCEPTED . ', challenge_time = ' . intval(time() + $this->arcade_config['challenge_ong_exp_date']) . '
							WHERE ' . $this->db->sql_in_set('challenge_id', $ids);
					$this->db->sql_query($sql);
				break;

				case 'report':
					$sql = 'DELETE FROM ' . ARCADE_CHALLENGE_CHAMP_TABLE . '
							WHERE ' . $this->db->sql_in_set('champ_id', $champ_ids);
					$this->db->sql_query($sql);
				case 'reject':
				case 'withdraw':
					$sql = 'DELETE FROM ' . ARCADE_CHALLENGE_TABLE . '
							WHERE ' . $this->db->sql_in_set('challenge_id', $ids);
					$this->db->sql_query($sql);
				break;
			}

			if (!in_array($action, array('reject', 'withdraw')))
			{
				$this->cache->destroy('_arcade_hidden_scores');
			}

			if ($action != 'report')
			{
				$success_msg = $this->user->lang['CHALLENGE' . (($more_chall || count($message) > 1) ? 'S' : '') . '_' . strtoupper($action) . '_SUCCESSFUL'] . '<br>';
				trigger_error($success_msg . implode('<br>', $message) . $this->arcade->back_link('mode=challenge', 'challenge'));
			}

			return $message;
		}
	}

	public function user_game_opponent($mode, $game_id, $user_id = false)
	{
		switch ($mode)
		{
			case 'all':
				if (!$user_id)
				{
					$user_id = $this->user->data['user_id'];
				}

				$user_ids = array();

				$sql = 'SELECT challenger_id, opponent_id
						FROM ' . ARCADE_CHALLENGE_TABLE . '
						WHERE game_id = ' . (int) $game_id . '
						AND (
							 (challenger_id	= ' . (int) $user_id . ') OR
							 (opponent_id	= ' . (int) $user_id . ')
							)';
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$user_ids[] = ($user_id == $row['challenger_id']) ? $row['opponent_id'] : $row['challenger_id'];
				}
				$this->db->sql_freeresult($result);

				return $user_ids;
			break;

			default:
				if (!$user_id)
				{
					return false;
				}

				$sql = 'SELECT challenge_id
						FROM ' . ARCADE_CHALLENGE_TABLE . '
						WHERE game_id = ' . (int) $game_id . '
						AND ((challenger_id = ' . (int) $user_id . ' AND opponent_id = ' . (int) $this->user->data['user_id'] . ') OR
							(challenger_id = ' . (int) $this->user->data['user_id'] . ' AND opponent_id = ' . (int) $user_id . '))';
				$result = $this->db->sql_query_limit($sql, 1);
				$challenge_id = (int) $this->db->sql_fetchfield('challenge_id');
				$this->db->sql_freeresult($result);

				return $challenge_id;
			break;
		}

		return $challenge_id;
	}

	public function random()
	{
		$stop_rand	= false;
		$error		= $game_data = $user_data = array();
		$random		= array(
			'bet' => ($this->arcade->points()->data['show']) ? (($this->arcade_config['challenge_bet_fix'] > 0) ? $this->arcade_config['challenge_bet_fix'] : (($this->arcade_config['challenge_bet_minimum'] > 0) ? $this->arcade_config['challenge_bet_minimum'] : 0)) : 0
		);

		if ($random['bet'] > 0 && $this->arcade->points()->data['total'] < $random['bet'])
		{
			$stop_rand = true;
		}

		if (!$stop_rand)
		{
			$rgid = array();
			$sql = 'SELECT game_id FROM ' . ARCADE_REPORTS_TABLE;
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$rgid[] = $row['game_id'];
			}
			$this->db->sql_freeresult($result);

			$game_ids = array_map('intval', array_unique(array_merge($rgid, $this->arcade->points()->get_games_big_cost($random['bet']))));

			$sql = 'SELECT g.game_id, g.game_cost, c.cat_cost, c.cat_id
					FROM ' . ARCADE_GAMES_TABLE . ' g
					LEFT JOIN ' . ARCADE_CATS_TABLE . ' c	 ON g.cat_id = c.cat_id
					WHERE	' . $this->db->sql_in_set('g.game_id', $game_ids, true, true) . '
					AND c.cat_status = ' . ITEM_UNLOCKED . '
					AND c.cat_test <> ' . ARCADE_CAT_TEST . '
					AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions('c_play'), false, true) . '
					AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->game_search_protection(), true, true) . '
					ORDER BY c.cat_id ASC';
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$game_data[] = array(
					'game_id'	=> $row['game_id'],
					'game_cost'	=> $row['game_cost'],
					'cat_cost'	=> $row['cat_cost'],
					'cat_id'	=> $row['cat_id']
				);
			}
			$this->db->sql_freeresult($result);

			if (count($game_data))
			{
				$random = array_merge($random, $game_data[mt_rand(0, count($game_data) - 1)]);
			}
			else
			{
				$stop_rand = true;
			}

			unset($game_data);

			if (!$stop_rand)
			{
				$no_auth_count	= 0;
				$auth2			= new \phpbb\auth\auth();
				$arcade_auth2	= new auth\auth();
				$dup_users		= $this->user_game_opponent('all', $random['game_id']);

				foreach ($this->obtain_all_users(true) as $user_id => $cuser)
				{
					if ($user_id == $this->user->data['user_id'] || in_array($user_id, $dup_users))
					{
						continue;
					}

					if (!$cuser['user_arcade_permissions'])
					{
						$no_auth_count++;
					}

					$auth2->acl($cuser);
					$arcade_auth2->acl($cuser);

					if ($auth2->acl_get('u_arcade') && $auth2->acl_get('u_arcade_challenge') && $arcade_auth2->acl_get('c_play', $random['cat_id']))
					{
						$points_action = false;
						if ($this->arcade->points()->data['show'])
						{
							$cost = $this->arcade->points()->game_cost($random);

							if ($cost > 0 || $random['bet'] > 0)
							{
								$points_action = true;
								$user_points = $this->arcade->points()->user($user_id);
							}
						}

						if ((!$points_action) || ($arcade_auth2->acl_get('c_playfree', $random['cat_id']) && ($random['bet'] <= $user_points)) || (($cost + $random['bet']) <= $user_points))
						{
							$user_data[] = array(
								'user_id'	=> $user_id,
								'username'	=> $cuser['username']
							);
						}
					}

					if ($no_auth_count >= 50)
					{
						break;
					}
				}

				unset($auth2);
				unset($arcade_auth2);

				if (count($user_data))
				{
					$random = array_merge($random, $user_data[mt_rand(0, count($user_data) - 1)]);
					$this->create('random', $random['game_id'], $random['user_id'], $random['username'], $random['bet'], $error);
				}
			}
		}

		$challenge_again = '<br><br><a class="' . (($this->user->lang['DIRECTION'] == 'ltr') ? 'left' : 'right') . '" href="' . $this->arcade->url('mode=rand_challenge') . '">' . $this->user->lang['CHALLENGE_RANDOM_AGAIN'] . '</a>';
		trigger_error($this->user->lang['CHALLENGE_NO_RANDOM'] . $challenge_again . $this->arcade->back_link('mode=challenge', 'challenge', false));
	}

	/**
	* Get all the categories the user has played games in
	* Follows the permissions systems so only categories
	* the viewing user can see are returned
	*/
	public function get_user_categories($user_id = false, $winner = false)
	{
		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
		}

		$sql_array = array(
			'SELECT'		 => 'c.cat_id, c.cat_name',
			'FROM'			 => array(ARCADE_GAMES_TABLE => 'g'),
			'LEFT_JOIN'		 => array(
				array('FROM' => array(ARCADE_CHALLENGE_CHAMP_TABLE => 'cc'),'ON' => 'g.game_id = cc.game_id'),
				array('FROM' => array(ARCADE_CATS_TABLE => 'c'),			'ON' => 'g.cat_id = c.cat_id'),
			),
			'WHERE'			 => 'cc.champ_challenger_id = ' . (int) $user_id . ' OR cc.champ_opponent_id = ' . (int) $user_id . '
				AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions(array('c_view', 'c_play')), false, true),
			'ORDER_BY'		 => 'c.cat_name ASC',
		);

		if ($winner)
		{
			$sql_array['WHERE'] .= ' AND cc.champ_winner = ' . (int) $user_id;
		}

		$cats = array($this->user->lang['ARCADE_ALL_CATEGORIES']);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$cats[$row['cat_id']] = $row['cat_name'];
		}
		$this->db->sql_freeresult($result);

		if (count($cats) == 1)
		{
			$cats = array();
		}

		return $cats;
	}

	public function game_challenge($game_id)
	{
		$sql = 'SELECT c.challenge_id, c.challenger_id, c.opponent_id, c.challenge_points, c.challenger_game_cost, c.opponent_game_cost, cc.champ_id, cc.champ_challenger_score, cc.champ_challenger_time, cc.champ_opponent_score, cc.champ_opponent_time
				FROM ' . ARCADE_CHALLENGE_TABLE . ' c
				LEFT JOIN ' . ARCADE_CHALLENGE_CHAMP_TABLE . ' cc ON cc.champ_close <> ' . CHALLENGE_CLOSE . ' AND c.game_id = cc.game_id AND c.challenger_id = cc.champ_challenger_id AND c.opponent_id = cc.champ_opponent_id
				WHERE c.game_id = ' . (int) $game_id . '
				AND c.challenge_accept = ' . CHALLENGE_ACCEPTED . '
				AND ((cc.champ_challenger_id = '. (int) $this->user->data['user_id'] .' AND cc.champ_challenger_score = 0 AND cc.champ_challenger_time = 0) OR
					(cc.champ_opponent_id = '. (int) $this->user->data['user_id'] .' AND cc.champ_opponent_score = 0 AND cc.champ_opponent_time = 0))';
		$result = $this->db->sql_query($sql);
		$champs = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$champs[$row['champ_id']] = array(
				'challenge_id'			=> $row['challenge_id'],
				'challenger_id'			=> $row['challenger_id'],
				'opponent_id'			=> $row['opponent_id'],
				'challenge_bet'			=> $row['challenge_points'],
				'challenger_score'		=> $row['champ_challenger_score'],
				'challenger_time'		=> $row['champ_challenger_time'],
				'opponent_score'		=> $row['champ_opponent_score'],
				'opponent_time'			=> $row['champ_opponent_time'],
				'challenger_game_cost'	=> $row['challenger_game_cost'],
				'opponent_game_cost'	=> $row['opponent_game_cost']
			);
		}
		$this->db->sql_freeresult($result);

		return $champs;
	}

	public function check($data, $score = 0)
	{
		if (empty($data))
		{
			return false;
		}

		$champs = $this->game_challenge($data['game_id']);

		if (!count($champs))
		{
			return false;
		}

		$return = false;
		$delete_challenges = array();
		$total_plays = $total_times = 0;
		$high_score_type = ($data['game_scoretype'] == SCORETYPE_HIGH) ? true : false;

		foreach ($champs as $champ_id => $champ)
		{
			$own_col = ($champ['challenger_id'] == $this->user->data['user_id']) ? 'challenger' : (($champ['opponent_id'] == $this->user->data['user_id']) ? 'opponent' : false);

			if (!$own_col)
			{
				continue;
			}

			$return = true;

			if ($score <= 0)
			{
				break;
			}

			$champ["{$own_col}_score"]	= (float) $score;
			$champ["{$own_col}_time"]	= (int) $data['total_time'];

			if (($champ['opponent_score'] > 0 && $champ['challenger_score'] > 0) || ($champ['challenger_time'] && $champ['opponent_time']))
			{
				$winner = $c_refund = $o_refund = 0;
				$total_plays++;
				$total_times += intval($champ['challenger_time'] + $champ['opponent_time']);

				$finres = ($champ['challenger_score'] == $champ['opponent_score']) ? 'tie' : ((($high_score_type && $champ['challenger_score'] > $champ['opponent_score']) || (!$high_score_type && $champ['challenger_score'] < $champ['opponent_score'])) ? 'challenger' : 'opponent');

				if ($finres == 'tie')
				{
					if ($this->arcade->points()->data['installed'] && $champ['challenge_bet'] > 0)
					{
						$prize	   = true;
						$c_refund += $champ['challenge_bet'];
						$o_refund += $champ['challenge_bet'];
					}

					$winner_score = $loser_score = $score;
				}
				else
				{
					$winner = $champ[(($finres == 'challenger') ? 'challenger' : 'opponent') . '_id'];
					$challenger_win = (($high_score_type && $champ['challenger_score'] > $champ['opponent_score']) || (!$high_score_type && $champ['challenger_score'] < $champ['opponent_score'])) ? true : false;

					$winner_score	= ($challenger_win) ? $champ['challenger_score'] : $champ['opponent_score'];
					$loser_score	= ($challenger_win) ? $champ['opponent_score'] : $champ['challenger_score'];

					if ($this->arcade->points()->data['installed'] && $champ['challenge_bet'] > 0)
					{
						$prize	   = ($champ['challenge_bet'] * 2);
						$c_refund += ($finres == 'challenger') ? $prize : 0;
						$o_refund += ($finres == 'opponent') ? $prize : 0;
					}
				}

				if ($this->arcade->points()->data['installed'])
				{
					$c_refund += ($champ['challenger_game_cost'] > 0) ? $champ['challenger_game_cost'] : 0;
					$o_refund += ($champ['opponent_game_cost'] > 0) ? $champ['opponent_game_cost'] : 0;

					if ($c_refund > 0)
					{
						$this->arcade->points()->set('add', $champ['challenger_id'], $c_refund);
					}

					if ($o_refund > 0)
					{
						$this->arcade->points()->set('add', $champ['opponent_id'], $o_refund);
					}
				}

				if ($this->arcade_config['challenge_pm'])
				{
					$other_id = $champ[(($own_col == 'challenger') ? 'opponent' : 'challenger') . '_id'];
					$other_user = $this->arcade->userdata('set_auth', $other_id);

					$pm_data = array(
						'cat_id'			=> $data['cat_id'],
						'game_id'			=> $data['game_id'],
						'game_name'			=> $data['game_name'],
						'game_image'		=> $data['game_image'],
						'game_width'		=> $data['game_width'],
						'game_height'		=> $data['game_height'],
						'winner_score'		=> $winner_score,
						'loser_score'		=> $loser_score,
						'winner'			=> $winner,
						'prize'				=> (!empty($prize)) ? $champ['challenge_bet'] : false
					);

					$this->final_pm('challenger', $champ, $other_user, $pm_data, $finres, $own_col);
					$this->final_pm('opponent', $champ, $other_user, $pm_data, $finres, $own_col);
				}

				$sql_ary = array(
					"champ_{$own_col}_time"		=> (int) $data['total_time'],
					"champ_{$own_col}_score"	=> (float) $score,
					'champ_winner'				=> (int) $winner,
					'champ_end_time'			=> time(),
					'champ_close'				=> CHALLENGE_CLOSE
				);

				$delete_challenges[] = $champ['challenge_id'];
			}
			else
			{
				$sql_ary = array(
					"champ_{$own_col}_time"		=> (int) $data['total_time'],
					"champ_{$own_col}_score"	=> (float) $score
				);
			}

			$sql = 'UPDATE ' . ARCADE_CHALLENGE_CHAMP_TABLE . '
					SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
					WHERE champ_id = ' . (int) $champ_id;
			$this->db->sql_query($sql);
		}

		if (count($delete_challenges))
		{
			$sql = 'DELETE FROM ' . ARCADE_CHALLENGE_TABLE . '
					WHERE ' . $this->db->sql_in_set('challenge_id', $delete_challenges);
			$this->db->sql_query($sql);

			$this->arcade_config->increment('challenge_total_plays', $total_plays, true);
			$this->arcade_config->increment('challenge_total_plays_time', $total_times, true);

			$this->cache->destroy('sql', ARCADE_CHALLENGE_CHAMP_TABLE);
			$this->cache->destroy('_arcade_hidden_scores');
			$this->cache->destroy('_arcade_challenge_leaders');
			$this->cache->destroy('_arcade_challenge_leaders_all');

			$this->arcade->hidden_users(true);
		}

		return $return;
	}

	public function final_pm($mode, $champ_data, $other_data, $pm_def_data, $finres, $own_col)
	{
		$my			= ($mode == $own_col) ? true : false;
		$pm_access	= ($my) ? $this->arcade->optionget('arcade_pm') : $this->arcade->optionget('arcade_pm', $other_data['user_arcade_options'], true);

		if ($pm_access)
		{
			$game_cost = ($mode == 'challenger') ? $champ_data['challenger_game_cost'] : $champ_data['opponent_game_cost'];
			$pm_prefix = ($finres == 'tie') ? 'tie' : (($mode == $finres) ? 'winner' : 'loser');

			$pm_ext_data = array(
				'bet_msg'					=> ($this->arcade->points()->data['installed'] && ($champ_data['challenge_bet'] > 0)) ? 'CHALLENGE_MSG_FINAL_BET_' . strtoupper($pm_prefix) : false,
				'user_id'					=> ($my) ? $other_data['user_id'] : $this->user->data['user_id'],
				'username'					=> ($my) ? $other_data['username'] : $this->user->data['username'],
				'user_colour'				=> ($my) ? $other_data['user_colour'] : $this->user->data['user_colour'],
				'user_ip'					=> ($my) ? $other_data['user_ip'] : $this->user->ip,
				'refund_game_cost'			=> ($this->arcade->points()->data['installed'] && ($game_cost > 0)) ? $game_cost : false,

				'other_user_id'				=> ($my) ? $this->user->data['user_id'] : $other_data['user_id'],
				'other_username'			=> ($my) ? $this->user->data['username'] : $other_data['username'],
				'other_user_colour'			=> ($my) ? $this->user->data['user_colour'] : $other_data['user_colour'],
				'other_user_lang'			=> ($my) ? $this->user->data['user_lang'] : $other_data['user_lang'],
				'other_user_arcade_options'	=> ($my) ? $this->user->data['user_arcade_options'] : $other_data['user_arcade_options']
			);

			$this->arcade->phpbb()->send_pm("challenge_final_{$pm_prefix}", array_merge($pm_def_data, $pm_ext_data), ((!$my) ? true : false));
		}
	}

	public function game_check($gdata, &$game_cost_active)
	{
		$return = false;

		$sql = 'SELECT c.challenge_id, c.challenger_id, c.challenger_game_cost, c.opponent_game_cost
				FROM ' . ARCADE_CHALLENGE_TABLE . ' c
				LEFT JOIN ' . ARCADE_CHALLENGE_CHAMP_TABLE . ' cc ON c.game_id = cc.game_id
																		AND c.challenger_id = cc.champ_challenger_id
																		AND c.opponent_id = cc.champ_opponent_id

				LEFT JOIN ' . USERS_TABLE . '					u ON ((u.user_id = c.challenger_id AND c.opponent_id = ' . (int) $this->user->data['user_id'] . ')
																	OR
																	(u.user_id = c.opponent_id AND c.challenger_id = ' . (int) $this->user->data['user_id'] . '))
				WHERE u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
				AND c.challenge_accept = ' . CHALLENGE_ACCEPTED . '
				AND cc.champ_close <> ' . CHALLENGE_CLOSE . '
				AND c.game_id = ' . (int) $gdata['game_id'] . '
				AND ((cc.champ_challenger_id = ' . (int) $this->user->data['user_id'] . ' AND cc.champ_challenger_score = 0 AND cc.champ_challenger_time = 0
						AND ' . $this->db->sql_in_set('cc.champ_opponent_id', array_map('intval', array_keys($this->arcade->ban_users())), true, true) . ')
					OR
					(cc.champ_opponent_id = ' . (int) $this->user->data['user_id'] . ' AND cc.champ_opponent_score = 0 AND cc.champ_opponent_time = 0
						AND ' . $this->db->sql_in_set('cc.champ_challenger_id', array_map('intval', array_keys($this->arcade->ban_users())), true, true) . '))
				GROUP BY c.challenge_id, c.challenger_id, c.challenger_game_cost, c.opponent_game_cost';
		$result = $this->db->sql_query_limit($sql, 1);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if ($row)
		{
			$column = ($this->user->data['user_id'] == $row['challenger_id']) ? 'challenger' : 'opponent';

			$game_cost_active = false;
			if ($this->arcade->points()->data['show'] && $row[$column . '_game_cost'] > 0)
			{
				$game_cost_active = true;

				$game_cost = $this->arcade->points()->game_cost($gdata);

				if ($game_cost > $row[$column . '_game_cost'])
				{
					$row[$column . '_game_cost'] = $game_cost;
				}
			}

			if ($game_cost_active)
			{
				$sql = 'UPDATE ' . ARCADE_CHALLENGE_TABLE . "
						SET {$column}_game_cost = 0
						WHERE challenge_id = " . (int) $row['challenge_id'];
				$this->db->sql_query($sql);

				$this->arcade->points()->set('add', $this->user->data['user_id'], $row[$column . '_game_cost'], false);
			}

			$return = true;
		}

		return $return;
	}
}
