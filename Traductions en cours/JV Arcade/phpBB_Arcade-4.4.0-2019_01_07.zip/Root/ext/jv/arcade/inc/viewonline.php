<?php
/**
*
* @package phpBB Arcade
* @version $Id: viewonline.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class viewonline
{
	protected $auth, $user, $arcade_config, $arcade_auth, $arcade;

	public function __construct($auth, $user, $arcade_config, $arcade_auth, $arcade)
	{
		$this->auth = $auth;
		$this->user = $user;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
	}

	public function main(&$event)
	{
		switch ($event['on_page'][1])
		{
			case 'arcade':
				// Grab some common modules
				$url_params = array(
					'mode=play'						=> 'PLAYING_GAME',
					'mode=popup'					=> 'PLAYING_GAME',
					'mode=cat'						=> 'VIEWING_ARCADE_CAT',
					'mode=download'					=> 'DOWNLOADING_GAME',
					'mode=search'					=> 'VIEWING_ARCADE_SEARCH',
					'mode=fav'						=> 'VIEWING_ARCADE_FAVORITES',
					'mode=stats'					=> 'VIEWING_ARCADE_STATS',
					'mode=challenge'				=> 'VIEWING_ARCADE_CHALLENGE',
					'mode=rand_challenge'			=> 'VIEWING_ARCADE_CHALLENGE',
					'mode=tournament'				=> 'VIEWING_ARCADE_TOURS',
					'mode=ranking'					=> 'VIEWING_ARCADE_RANKING'
				);

				// default values
				$event['location']		= $this->user->lang['VIEWING_ARCADE'];
				$event['location_url']	= $this->arcade->url();

				foreach ($url_params as $param => $lang)
				{
					if (strpos($event['row']['session_page'], $param) !== false)
					{
						if ($param == 'mode=cat')
						{
							preg_match('#c=([0-9]+)#', $event['row']['session_page'], $cat_id);
							$cat_id = (count($cat_id)) ? (int) $cat_id[1] : 0;

							if (!$cat_id || ($cat_name = $this->arcade->get()->cat_field($cat_id, 'cat_name', false)) === false || !$this->arcade_auth->acl_get('c_view', $cat_id))
							{
								break;
							}

							$event['location'] = sprintf($this->user->lang[$lang], $cat_name);
							$event['location_url'] = $this->arcade->url("$param&amp;c=$cat_id");
						}
						else if ($param == 'mode=download' && $this->arcade->game()->download_stat_auth())
						{
							preg_match('#g=([0-9]+)#', $event['row']['session_page'], $game_id);
							$game_id = (count($game_id)) ? (int) $game_id[1] : 0;

							if (!$game_id || ($game_name = $this->arcade->get()->game_field($game_id, 'game_name', false)) === false || ($cat_id = $this->arcade->get()->game_field($game_id, 'cat_id', false)) === false || !$this->arcade_auth->acl_get('c_download', $cat_id))
							{
								break;
							}

							$event['location'] = sprintf($this->user->lang[$lang], $game_name);
							$event['location_url'] = $this->arcade->url('mode=download&amp;g=' . $game_id);
						}
						else if (($param == 'mode=play' || $param == 'mode=popup') && $this->auth->acl_get('u_arcade_view_whoisplaying'))
						{
							preg_match('#g=([0-9]+)#', $event['row']['session_page'], $game_id);
							$game_id = (count($game_id)) ? (int) $game_id[1] : 0;

							if (!$game_id || ($game_name = $this->arcade->get()->game_field($game_id, 'game_name', false)) === false || ($cat_id = $this->arcade->get()->game_field($game_id, 'cat_id', false)) === false || !$this->arcade_auth->acl_get('c_play', $cat_id))
							{
								break;
							}

							$event['location'] = sprintf($this->user->lang[$lang], $game_name);
							$event['location_url'] = $this->arcade->url('mode=play&amp;g=' . $game_id);
						}
						else if ($param == 'mode=stats' && $this->auth->acl_get('u_arcade_viewstats'))
						{
							preg_match('#type=([a-z_]+)#', $event['row']['session_page'], $page_type);
							$page_type = (!empty($page_type[1])) ? $page_type[1] : false;

							preg_match('#ds=([a-z_]+)#', $event['row']['session_page'], $detailed_stats);
							$detailed_stats = (!empty($detailed_stats[1])) ? $detailed_stats[1] : false;

							if ((($page_type == 'challenge' || strpos($detailed_stats, 'challenge') !== false) && !$this->arcade->access('challenge')) ||
							(($page_type == 'tournament' || strpos($detailed_stats, 'tour') !== false) && !$this->arcade->access('tour')))
							{
								break;
							}

							$default_title = ($page_type) ? true : false;
							$top_key = true;

							if ($detailed_stats && !$this->arcade->get()->detailed_stats($detailed_stats, $lang, true))
							{
								$default_title = true;
								$top_key = '';
							}

							if ($default_title)
							{
								if ($page_type)
								{
									switch($page_type)
									{
										case 'challenge':
											$lang = 'VIEWING_ARCADE_CHALLENGE_STATS';
										break;

										case 'tournament':
											$lang = 'VIEWING_ARCADE_TOURS_STATS';
										break;

										default:
											$page_type = false;
										break;
									}
								}
							}

							preg_match('#c=([0-9]+)#', $event['row']['session_page'], $cat_id);
							$cat_id = (count($cat_id)) ? (int) $cat_id[1] : 0;

							preg_match('#g=([0-9]+)#', $event['row']['session_page'], $game_id);
							$game_id = (count($game_id)) ? (int) $game_id[1] : 0;

							preg_match('#u=([0-9]+)#', $event['row']['session_page'], $user_id);
							$user_id = (count($user_id)) ? (int) $user_id[1] : 0;

							preg_match('#tour_id=([0-9]+)#', $event['row']['session_page'], $tour_id);
							$tour_id = (count($tour_id)) ? (int) $tour_id[1] : 0;

							if ($cat_id)
							{
								if (($cat_name = $this->arcade->get()->cat_field($cat_id, 'cat_name', false)) === false)
								{
									break;
								}
							}

							if ($game_id)
							{
								if (($game_name = $this->arcade->get()->game_field($game_id, 'game_name', false)) === false)
								{
									break;
								}
							}

							if ($user_id)
							{
								if (!($username = $this->arcade->userdata('username', $user_id)))
								{
									break;
								}
							}

							if ($tour_id)
							{
								if (($tour_name = $this->arcade->get()->tour_field($tour_id, 'tour_name', false)) === false)
								{
									break;
								}

								$lang = 'VIEWING_ARCADE_TOUR_STATS';
							}

							if ($game_id && $user_id)
							{
								if (!$detailed_stats)
								{
									$top_key = 'userbox';
								}

								$lang .= '_GAME_USER';
								if ($tour_id)
								{
									$event['location'] = sprintf($this->user->lang[$lang], $tour_name, $game_name, $username);
								}
								else
								{
									$event['location'] = sprintf($this->user->lang[$lang], $game_name, $username);
								}

								$event['location_url'] = $this->arcade->url($param . (($page_type) ? "&amp;type=$page_type" : '') . (($tour_id) ? "&amp;tour_id=$tour_id" : '') . (($detailed_stats) ? "&amp;ds=$detailed_stats" : '') . "&amp;g={$game_id}&amp;u={$user_id}", 'arcade', false, $top_key);
							}
							else if ($game_id)
							{
								$lang .= '_GAME';
								if ($tour_id)
								{
									$event['location'] = sprintf($this->user->lang[$lang], $tour_name, $game_name);
								}
								else
								{
									$event['location'] = sprintf($this->user->lang[$lang], $game_name);
								}

								$event['location_url'] = $this->arcade->url($param . (($page_type) ? "&amp;type=$page_type" : '') . (($tour_id) ? "&amp;tour_id=$tour_id" : '') . (($detailed_stats) ? "&amp;ds=$detailed_stats" : '') . "&amp;g={$game_id}") . '#gamebox';
							}
							else if ($user_id)
							{
								if (!$detailed_stats)
								{
									$top_key = 'userbox';
								}

								$lang .= '_USER';
								if ($tour_id)
								{
									$event['location'] = sprintf($this->user->lang[$lang], $tour_name, $username);
								}
								else
								{
									$event['location'] = sprintf($this->user->lang[$lang], $username);
								}

								$event['location_url'] = $this->arcade->url($param . (($page_type) ? "&amp;type=$page_type" : '') . (($tour_id) ? "&amp;tour_id=$tour_id" : '') . (($detailed_stats) ? "&amp;ds=$detailed_stats" : '') . "&amp;u={$user_id}", 'arcade', false, $top_key);
							}
							else if ($cat_id)
							{
								$event['location'] = sprintf($this->user->lang[$lang . '_CAT'], $cat_name);
								$event['location_url'] = $this->arcade->url($param . "&amp;c=$cat_id") . '#stats_top';
							}
							else
							{
								if ($tour_id)
								{
									$event['location'] = sprintf($this->user->lang[$lang], $tour_name);
								}
								else
								{
									$event['location'] = $this->user->lang[$lang];
								}

								$event['location_url'] = $this->arcade->url($param . (($page_type) ? "&amp;type=$page_type" : '') . (($tour_id) ? "&amp;tour_id=$tour_id" : '') . (($detailed_stats) ? "&amp;ds=$detailed_stats" : ''), 'arcade', false, $top_key);
							}
						}
						else if (in_array($param, array('mode=search', 'mode=fav', 'mode=ranking')))
						{
							if (($param == 'mode=search' && !$this->auth->acl_get('u_arcade_search')) || ($param == 'mode=fav' && !$this->auth->acl_get('u_arcade_favorites')) || (!$this->arcade_config['ranks_page'] && $param == 'mode=ranking'))
							{
								break;
							}

							if ($param == 'mode=search' || $param == 'mode=fav')
							{
								$param = '';
							}

							$event['location'] = $this->user->lang[$lang];
							$event['location_url'] = $this->arcade->url($param);
						}
						else if (in_array($param, array('mode=challenge', 'mode=rand_challenge')) && $this->arcade->access('challenge'))
						{
							$event['location'] = $this->user->lang[$lang];
							$event['location_url'] = $this->arcade->url('mode=challenge');
						}
						else if ($param == 'mode=tournament' && $this->arcade->access('tour'))
						{
							preg_match('#type=([a-z_]+)#', $event['row']['session_page'], $page_type);
							$page_type = (!empty($page_type[1])) ? $page_type[1] : false;

							preg_match('#tour_id=([0-9]+)#', $event['row']['session_page'], $tour_id);
							$tour_id = (count($tour_id)) ? (int) $tour_id[1] : 0;

							if (!$tour_id && $page_type == 'final')
							{
								$param .= "&amp;type=$page_type";
								$lang = 'VIEWING_ARCADE_FINISHED_TOURS';
							}
							else if ($tour_id)
							{
								$tour_name = $this->arcade->get()->tour_field($tour_id, 'tour_name', false);
							}

							$event['location'] = $this->user->lang[$lang];

							if ($tour_id && $tour_name)
							{
								$event['location'] = sprintf($this->user->lang['VIEWING_ARCADE_TOUR_NAME'], $tour_name);

								switch ($page_type)
								{
									case 'rank':
									case 'final':
										$param .= "&amp;type=$page_type";
										$key = ($page_type == 'final') ? 'FINAL' : 'ACTUAL';
										$event['location'] = sprintf($this->user->lang["VIEWING_ARCADE_TOUR_USERS_{$key}_RANK"], $tour_name);
									break;
								}

								$param .= "&amp;tour_id=$tour_id";
							}

							$event['location_url'] = $this->arcade->url($param) . '#tour_top';
						}

						break;
					}
				}

			break;
		}
	}
}
