<?php
/**
*
* @package phpBB Arcade
* @version $Id: helper.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\ext;

class helper
{
	protected $ext;

	public function __construct($ext)
	{
		$this->register_modules($ext);
	}

	protected function register_modules($ext)
	{
		foreach ($ext as $current_ext)
		{
			$class_name = '\\' . get_class($current_ext);
			if (!isset($this->ext[$class_name]))
			{
				$this->ext[$class_name] = $current_ext;
			}
		}
	}

	public function get_ext($ext_name)
	{
		if (isset($this->ext[$ext_name]))
		{
			return $this->ext[$ext_name];
		}
		else
		{
			return false;
		}
	}

	public function get_all_ext()
	{
		return $this->ext;
	}

	public function verify_install($ext, $full_class_name = true)
	{
		$ext = ($full_class_name) ? $ext : '\jv\\arcade_' . $ext . '\inc\acp_settings';
		return ($this->get_ext($ext) !== false) ? true : false;
	}

	public function get_version($ext, $full_class_name = true)
	{
		$ext = ($full_class_name) ? $ext : '\jv\\arcade_' . $ext . '\inc\acp_settings';
		$ext = $this->get_ext($ext);

		return ($ext !== false) ? $ext->version : 0;
	}

	public function get_class_name($class)
	{
		if ($this->get_ext($class) !== false)
		{
			list($null, $key, $name) = explode('\\', $class);
			return $key . '/' . $name;
		}

		return '';
	}
}
