<?php
/**
*
* @package phpBB Arcade
* @version $Id: play.php 2136 2019-01-05 19:42:24Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class play
{
	protected $db, $user, $auth, $request, $template, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext;

	public function __construct($db, $user, $auth, $request, $template, $arcade_config, $arcade_auth, $arcade, $phpbb_root_path, $php_ext)
	{
		$this->db = $db;
		$this->user = $user;
		$this->auth = $auth;
		$this->request = $request;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $php_ext;
	}

	public function start($mode, $game_id)
	{
		if (!$game_id || !in_array($mode, array('play', 'popup')))
		{
			return;
		}

		if ($mode == 'popup' && !$this->auth->acl_get('u_arcade_popup'))
		{
			send_status_line(403, 'Forbidden');
			trigger_error($this->user->lang['NO_PERMISSION_ARCADE_PLAY_POPUP'] . $this->arcade->close_win());
		}

		if (!$this->arcade->allow_bots() && !$this->user->data['is_registered'] && !$this->arcade_auth->acl_getc_global('c_play'))
		{
			if ($this->user->data['is_bot'])
			{
				redirect($this->arcade->url());
			}

			$message = sprintf($this->user->lang['ARCADE_REGISTER_MESSAGE_PLAY'], intval($this->arcade_config['install_games']));

			if ($this->arcade->game()->session->game_popup)
			{
				$message .= $this->arcade->close_win();
			}
			else
			{
				$message .= '<br>' . sprintf($this->user->lang['ARCADE_REGISTER_LOGIN_MESSAGE'], '<a href="' . $this->arcade->url('mode=register', 'ucp') . '">', '</a>', '<a href="' . $this->arcade->url('mode=login&amp;redirect=' . urlencode("arcade.{$this->php_ext}?mode=play&g=$game_id"), 'ucp') . '">', '</a>');
			}

			trigger_error($message);
		}

		// Grab the data for game and navlinks
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.game_name, g.game_desc, g.game_control, g.game_control_desc, g.game_image, g.game_swf, g.game_width, g.game_height, g.game_plays,
							g.game_scorevar, g.game_scoretype, g.game_type, g.game_save_type, g.game_download, g.game_filesize, g.game_votetotal, g.game_votesum, g.game_cost,
							g.game_reward, g.game_jackpot, g.game_use_jackpot, g.game_download_cost, g.game_highuser, g.game_highdate, g.post_id,
							r.game_rating,
							c.*',
			'FROM'		=> array(ARCADE_GAMES_TABLE	=> 'g'),
			'LEFT_JOIN'	=> array(
				array('FROM' => array(ARCADE_RATING_TABLE	=> 'r'), 'ON' => 'g.game_id = r.game_id AND r.user_id = ' . (int) $this->user->data['user_id']),
				array('FROM' => array(ARCADE_CATS_TABLE		=> 'c'), 'ON' => 'g.cat_id = c.cat_id'),
			),
			'WHERE'		=> 'g.game_id = ' . (int) $game_id,
		);

		if ($this->arcade_config['game_pp_enable'])
		{
			$sql_array['SELECT'] .= ', g.privacy_desc, g.privacy_link';
		}

		// This is only needed if we are playing in a popup
		if ($this->arcade->game()->session->game_popup)
		{
			$sql_array['SELECT'] .= ', g.game_highuser, g.game_highscore, u.username';
			$sql_array['LEFT_JOIN'][] = array('FROM' => array(USERS_TABLE => 'u'), 'ON' => 'g.game_highuser = u.user_id');
		}

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$game_data = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$game_data)
		{
			trigger_error($this->user->lang['NO_GAME_ID'] . $this->arcade->gbl());
		}

		if ($game_data['game_type'] == UNKNOWN_GAME)
		{
			trigger_error(sprintf($this->user->lang['ARCADE_GAME_TYPE_ERROR'], $game_data['game_name']) . $this->arcade->gbl());
		}

		if ($game_data['game_save_type'] == UNKNOWN_GAME)
		{
			trigger_error(sprintf($this->user->lang['ARCADE_GAME_SAVE_TYPE_ERROR'], $game_data['game_name']) . $this->arcade->gbl());
		}

		$file_functions = $this->arcade->container('functions_file');

		$game_width = $game_height = 0;
		$this->arcade->set_game_size($game_width, $game_height, $game_data['game_width'], $game_data['game_height'], $game_data['game_swf'], $game_data['game_type']);
		$game_file = $file_functions->remove_extension($game_data['game_swf']);
		$game_path = $this->arcade->set_path($game_data['game_swf'], '', true, $game_data['game_type'], $game_data['game_save_type']);

		$game_swf = ($game_data['game_type'] == GAME_TYPE_FLASH && $this->arcade->game()->get_protection($game_data['game_save_type'])) ? $this->arcade->url("swf=$game_file") : $game_path;

		if (!file_exists($game_path))
		{
			$this->arcade->add_log('critical', $game_data['game_id'], 'LOG_ARCADE_GAME_FILE_NOT_FOUND', $game_data['game_name'], $this->arcade->root_key($game_path));
			trigger_error(sprintf($this->user->lang['ARCADE_GAME_FILE_NOT_FOUND'], $game_data['game_name']) . $this->arcade->gbl());
		}

		$cat_test		= ($game_data['cat_test'] == ARCADE_CAT_TEST) ? true : false;
		$s_use_points	= (!$this->user->data['is_bot'] && !$cat_test && $this->arcade->points()->data['show']) ? true : false;

		// The check is ignored 1-2 Bots.
		if (!$this->arcade->allow_bots())
		{
			if (!$this->arcade_auth->acl_get('c_play', $game_data['cat_id']))
			{
				send_status_line(403, 'Forbidden');
				trigger_error($this->user->lang['NO_PERMISSION_ARCADE_PLAY'] . $this->arcade->gbl());
			}

			if ($this->arcade->get()->cat_locked($game_data['cat_id']))
			{
				trigger_error($this->user->lang['ARCADE_CAT_LOCKED_ERROR'] . $this->arcade->gbl());
			}

			// age limit verify
			if ($game_data['cat_age'])
			{
				$this->arcade->verify_age('play', $game_data['cat_age'], $this->arcade->gbl());
			}

			// Category is passworded ... check whether access has been granted to this
			// user this session, if not show login box before playing the game
			if ($game_data['cat_password'])
			{
				$this->arcade->display()->cat_login_box($game_data);
			}
		}

		$this->template->assign_var('GAME_ID', $game_data["game_id"]);

		$challenge_enabled = $tour_enabled = false;
		if ($game_data['game_save_type'] != NOSCORE_GAME)
		{
			$challenge_enabled	= ($this->user->data['is_registered'] && !$cat_test && $this->arcade->access('challenge', false)) ? true : false;
			$tour_enabled		= ($this->user->data['is_registered'] && !$cat_test && $this->arcade->access('tour', false)) ? true : false;

			if ($challenge_enabled && !$this->request->is_set_post('challenge_game'))
			{
				$game_cost_active = false;
				if ($this->arcade->container('challenge')->game_check($game_data, $game_cost_active))
				{
					$lang_ary = array(
						'MESSAGE_TITLE'		=> $this->user->lang['ARCADE_CHALLENGE'],
						'MESSAGE_TEXT'		=> $this->user->lang['ARCADE_CHALLENGE_PLAYING_GAME'] . (($game_cost_active) ? '<br>' . $this->user->lang['ARCADE_CHALLENGE_PLAYING_GAME_COST'] : ''),
						'PAGE_TITLE'		=> $this->user->lang['ARCADE_CHALLENGE'] . ' ' . $this->user->lang['INFORMATION'],
						'CONFIRM_BUTTON1'	=> $this->user->lang['ARCADE_PLAY_LINK'],
						'TYPE'				=> 'challenge'
					);

					$this->arcade->confirm($lang_ary, $game_data['game_id']);
				}
			}

			if ($tour_enabled && !$this->request->is_set_post('tournament_game') && $this->arcade->container('tournament')->check($game_data['game_id']))
			{
				if (!$this->request->is_set_post('challenge_game'))
				{
					$lang_ary = array(
						'MESSAGE_TITLE'		=> $this->user->lang['ARCADE_TOURNAMENT'],
						'MESSAGE_TEXT'		=> $this->user->lang['ARCADE_TOURNAMENT_PLAYING_GAME'],
						'PAGE_TITLE'		=> $this->user->lang['ARCADE_TOURNAMENT'] . ' ' . $this->user->lang['INFORMATION'],
						'CONFIRM_BUTTON1'	=> $this->user->lang['ARCADE_PLAY_LINK'],
						'TYPE'				=> 'tournament'
					);

					$this->arcade->confirm($lang_ary, $game_data['game_id']);
				}
			}
		}

		// We will set this cookie to let the arcade know that the user is playing the game
		$gidencoded = $this->arcade->game()->session->begin($game_data['game_id']);

		if ($gidencoded == ARCADE_GAME_RESTART)
		{
			$lang_ary = array(
				'MESSAGE_TITLE'		=> $this->user->lang['CONFIRM'],
				'MESSAGE_TEXT'		=> sprintf($this->user->lang['ARCADE_RESTART_GAME_EXPLAIN'], $game_data['game_name']),
				'CONFIRM_BUTTON1'	=> sprintf($this->user->lang['ARCADE_RESTART_GAME'], $game_data['game_name']),
				'PAGE_TITLE'		=> sprintf($this->user->lang['ARCADE_RESTART_GAME'], $game_data['game_name'])
			);

			$this->arcade->confirm($lang_ary, $game_data['game_id']);
		}

		// The check is ignored 1-2 Bots.
		if (!$cat_test && !$this->arcade->allow_bots())
		{
			// Check flood control
			$interval = ($this->user->data['user_id'] == ANONYMOUS) ? $this->arcade_config['play_anonymous_interval'] : $this->arcade_config['play_interval'];

			if ($interval && !$this->arcade_auth->acl_get('c_ignoreflood_play', $game_data['cat_id']))
			{
				$time = time() - $interval;
				if ($this->user->data['user_arcade_last_play'] > $time)
				{
					trigger_error(sprintf($this->user->lang['ARCADE_NO_PLAY_TIME'], $this->arcade->time_format($interval, true), $this->arcade->time_format($this->user->data['user_arcade_last_play'] - $time, true)) . $this->arcade->gbl());
				}
			}

			if (!$this->arcade_auth->acl_get('c_ignorecontrol', $game_data['cat_id']))
			{
				$this->arcade->limit_play($this->arcade->gbl());
			}
		}
/*
		if (GAME_TYPE_HTML5 != $game_data['game_type'] && $game_data['game_save_type'] == IBPROV3_GAME)
		{
			$v3_file = $this->arcade->set_path($game_data['game_swf'], 'gamedata') . $game_file . '.txt';

			if (!file_exists($v3_file))
			{
				$this->arcade->add_log('critical', $game_data['game_id'], 'LOG_ARCADE_GAME_FILE_NOT_FOUND', $game_data['game_name'], $this->arcade->root_key($v3_file));
			}
		}
*/
		unset($game_path);

		$this->arcade->page_title = $this->user->lang['ARCADE'] . ' - ' . $game_data['cat_name'] . ' - ' . $game_data['game_name'];

		if ($cat_test)
		{
			$this->template->assign_var('S_ARCADE_CAT_TEST_MODE', true);
		}

		// Handle points if needed and if we are not in a test category
		if ($s_use_points)
		{
			$game_cost			= $this->arcade->points()->game_cost($game_data);
			$game_reward		= $this->arcade->points()->game_reward($game_data);
			$game_download_cost	= $this->arcade->points()->game_download_cost($game_data);

			if ($game_cost != ARCADE_FREE && $game_cost > 0 && !$this->arcade_auth->acl_get('c_playfree', $game_data['cat_id']))
			{
				if (!$this->arcade->points()->set('subtract', $this->user->data['user_id'], $game_cost))
				{
					trigger_error(sprintf($this->user->lang['ARCADE_NO_POINTS'], $this->arcade->points()->data['name']) . $this->arcade->gbl());
				}

				// The jackpot is only increased if the user actually contributed something to play
				if ($this->arcade->points()->use_game_jackpot($game_data))
				{
					$game_reward = $this->arcade->points()->set_game_jackpot('add', $game_data);
				}
			}
		}

		$use_super_champion	= false;
		$super_champion = array();
		$game_control		= $this->arcade->game()->control($game_data['game_control']);
		$game_desc			= str_replace("\n", '', censor_text(nl2br($game_data['game_desc'])));
		$game_control_desc	= str_replace("\n", '', censor_text(nl2br($game_data['game_control_desc'])));

		if ($game_data['game_save_type'] == NOSCORE_GAME)
		{
			// Increase play count for games that do not submit scores
			// only if we are not in a test category, we are basically
			if (!$cat_test)
			{
				$this->arcade->game()->update_plays($game_data['game_id'], $game_data['cat_id'], null);
			}
		}
		else
		{
			$high_score_type = ($game_data['game_scoretype'] == SCORETYPE_HIGH) ? true : false;

			if ($super_champion = $this->arcade->game()->super_champion($game_data['game_id']))
			{
				$use_super_champion = true;

				if ($this->arcade_config['super_champion'])
				{
					$avatar_width	= (int) $this->arcade_config['super_champion_avatar_width'];
					$avatar_height	= (int) $this->arcade_config['super_champion_avatar_height'];

					if (!$avatar_width || !$avatar_height)
					{
						$avatar_width	= $super_champion['user_avatar_width'];
						$avatar_height	= $super_champion['user_avatar_height'];
					}

					$superchampion_name  = $this->arcade->get()->user_name('full', $super_champion['user_id'], $super_champion['username'], $super_champion['user_colour'], 'profile', 'x');
					$super_champion['f_score'] = (!$this->arcade->hidden_score($game_data['game_id'], $super_champion['user_id'])) ? $this->arcade->number_format($super_champion['score']) : $this->user->lang['HIDDEN'];

					if ($mode == 'play')
					{
						$this->template->assign_vars(array(
							'SUPER_CHAMPION_USER_NAME'	=> $superchampion_name,
							'SUPER_CHAMPION_AVATAR'		=> ($this->arcade_config['super_champion_avatar'] && $this->arcade->optionget('view_avatars')) ? $this->arcade->get->user_avatar($super_champion['user_avatar'], $super_champion['user_avatar_type'], $avatar_width, $avatar_height, 'x', 'arcade', $super_champion['user_id']) : false,
							'SUPER_CHAMPION_SCORE'		=> $super_champion['f_score'],
							'SUPER_CHAMPION_SCORE_DATE'	=> sprintf($this->user->lang['ARCADE_BEST_DATE_EXPLAIN'], $this->user->format_date($super_champion['score_date']))
						));
					}
				}
			}

			$scores_limit = intval($this->arcade_config['game_scores']);
			if ((!$this->arcade->privat() || $this->arcade_config['jva_gi_enable']) || ($scores_limit && $mode == 'play'))
			{
				if (!$scores_limit)
				{
					$scores_limit = intval($this->arcade_config['jva_gi_highscores']);
					$this->template->assign_var('S_SCORE_DISABLED', true);
				}

				$lastscore			= '';
				$highscores			= array();
				$position			= $actual_position = $i = 0;
				$score_columns		= 's.score, s.score_date' . (($this->arcade_config['game_comment']) ? ', s.comment_text, s.comment_bitfield, s.comment_options, s.comment_uid' : '');

				$sql_array = array(
					'SELECT'	=> $score_columns . ', p.total_time, p.total_plays, u.user_type, u.username, u.user_id, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height, a.user_arcade_options',
					'FROM'		=> array(
						ARCADE_SCORES_TABLE	=> 's',
					),
					'LEFT_JOIN'	=> array(
						array(
							'FROM'	=> array(ARCADE_PLAYS_TABLE => 'p'),
							'ON'	=> 's.game_id = p.game_id AND s.user_id = p.user_id'
						),
						array(
							'FROM'	=> array(USERS_TABLE => 'u'),
							'ON'	=> 's.user_id = u.user_id'
						),
						array(
							'FROM'	=> array(ARCADE_USERS_TABLE => 'a'),
							'ON'	=> 's.user_id = a.user_id'
						),
					),
					'WHERE'		=> 's.game_id = ' . (int) $game_data['game_id'] . '
						AND s.user_id = u.user_id',
					'ORDER_BY'	=> 's.score ' . (($high_score_type) ? 'DESC' : 'ASC') . ', s.score_date ASC',
				);

				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				while ($score_data = $this->db->sql_fetchrow($result))
				{
					$actual_position++;

					if ($this->user->data['user_id'] != $score_data['user_id'] && $actual_position > $scores_limit)
					{
						continue;
					}

					// Handle the game champion
					if ($actual_position == 1)
					{
						if (!empty($super_champion['score']) && (($high_score_type && $super_champion['score'] <= $score_data['score']) || (!$high_score_type && $super_champion['score'] >= $score_data['score'])))
						{
							$use_super_champion = false;
						}

						$this->template->assign_vars(array(
							'S_GAME_CHAMPION'			=> true,
							'S_CHALLENGE_CHAMPION'		=> ($challenge_enabled && $this->user->data['user_id'] != $score_data['user_id'] && $this->arcade->optionget('challenge', $score_data['user_arcade_options'], true) && in_array($score_data['user_type'], array(USER_NORMAL, USER_FOUNDER)) && !in_array($score_data['user_id'], array_keys($this->arcade->ban_users()))) ? true : false,

							'U_CHALLENGE_CHAMPION'		=> $this->arcade->url('mode=champion_challenge&amp;g=' . $game_data['game_id'] . '&amp;u=' . $score_data['user_id']),

							'BEST_USER_NAME'			=> $this->arcade->get()->user_name('full', $score_data['user_id'], $score_data['username'], $score_data['user_colour'], 'arcade', 'x'),
							'BEST_COMMENT'				=> ($this->arcade_config['game_comment'] && $score_data['comment_text'] !== '') ? generate_text_for_display($score_data['comment_text'], $score_data['comment_uid'], $score_data['comment_bitfield'], $score_data['comment_options']) : '',
							'BEST_PLAYED'				=> $this->arcade->number_format($score_data['total_plays']),
							'BEST_TIME'					=> $this->arcade->time_format($score_data['total_time']),
							'BEST_SCORE'				=> (!$this->arcade->hidden_score($game_data['game_id'], $score_data['user_id'])) ? $this->arcade->number_format($score_data['score']) : $this->user->lang['HIDDEN'],
							'BEST_DATE_EXPLAIN'			=> sprintf($this->user->lang['ARCADE_BEST_DATE_EXPLAIN'], $this->user->format_date($score_data['score_date'])),
							'FIRST_AVATAR'				=> ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($score_data['user_avatar'], $score_data['user_avatar_type'], $score_data['user_avatar_width'], $score_data['user_avatar_height'], 'x', 'arcade', $score_data['user_id']) : false,

							'L_ARCADE_GAME_CHAMPION'	=> ((!empty($super_champion['user_id']) && !$this->arcade->game()->session->game_popup && !$use_super_champion && $super_champion['user_id'] == $score_data['user_id']) ? $this->user->lang['ARCADE_SUPER_CHAMPION'] . ', ' : '') . $this->user->lang['ARCADE_GAME_CHAMPION']
						));

						if ($challenge_enabled && $this->arcade->points()->data['show'])
						{
							$this->template->assign_vars(array(
								'S_CHALLENGE_BET_FIX'	=> ($this->arcade_config['challenge_bet_fix']) ? true : false,

								'CHALLENGE_BET_MIN'		=> ($this->arcade_config['challenge_bet_minimum']) ? $this->arcade->number_format($this->arcade_config['challenge_bet_minimum']) . ' ' . $this->arcade->points()->data['name'] : false,
								'CHALLENGE_BET_MAX'		=> ($this->arcade_config['challenge_bet_maximum']) ? $this->arcade->number_format($this->arcade_config['challenge_bet_maximum']) . ' ' . $this->arcade->points()->data['name'] : false,
								'CHALLENGE_BET'			=> $this->arcade->number_format((($this->arcade_config['challenge_bet_fix']) ? $this->arcade_config['challenge_bet_fix'] : $this->arcade_config['challenge_bet_minimum']), true)
							));
						}
					}

					if ($lastscore != $score_data['score'])
					{
						$position = $actual_position;
					}

					$lastscore = $score_data['score'];

					if ($actual_position > $scores_limit)
					{
						$i--;
					}

					$highscores[$i] = array(
						'pos'	=> $position,
						'uid'	=> $score_data['user_id'],
						'uname'	=> $this->arcade->get()->user_name('full', $score_data['user_id'], $score_data['username'], $score_data['user_colour'], 'arcade', 'x', false, false, true),
						'sname'	=> $score_data['username'],
						'score'	=> (!$this->arcade->hidden_score($game_data['game_id'], $score_data['user_id'])) ? $this->arcade->number_format($score_data['score']) : $this->user->lang['HIDDEN']
					);

					// We break here because we no longer need to loop through the data, we have what we need
					if ($actual_position > $scores_limit)
					{
						break;
					}

					$i++;
				}
				$this->db->sql_freeresult($result);

				foreach ($highscores as $line => $row)
				{
					$this->template->assign_block_vars('scorerow', array(
						'LINE'			=> $line,
						'POS'			=> $row['pos'],
						'USER_ID'		=> $row['uid'],
						'FULL_USERNAME'	=> $row['uname'],
						'USERNAME'		=> $row['sname'],
						'SCORE'			=> $row['score']
					));
				}
			}

			if ($use_super_champion)
			{
				$this->template->assign_var('S_GAME_SUPER_CHAMPION', true);
			}
		}

		$this->arcade->game()->update_last_play_time();

		// Get the favorite games data for the current user...
		$game_fav_data = $this->arcade->get()->fav_data($this->user->data['user_id'], $game_data["game_id"]);

			$this->template->assign_block_vars('game_cf', array(
				'FILENAME' => $game_swf
			));

		if (GAME_TYPE_HTML5 == $game_data['game_type'])
		{
			preg_match_all('/\< *[script][^\>]*[src] *= *["]?([^"]*.js)/i', preg_replace('/<!--(.|\s)*?-->/', '', file_get_contents($game_swf)), $game_files);

			if (!empty($game_files[1]))
			{
				foreach ($game_files[1] as $gf)
				{
					$this->template->assign_block_vars('game_cf', array(
						'FILENAME' => (strpos($gf, '//') !== false) ? $gf : $this->arcade->set_path($game_data['game_swf'], ((strpos($game_swf, 'arcade/gamedata') !== false) ? 'gamedata' : 'path')) . $gf
					));
				}
			}
		}

		$tpl = array(
			'S_ARCADE_GAME_PLAY'			=> true,
			'S_ARCADE_GAME_GUEST'			=> true,
			'S_USER_ID'						=> $this->user->data['user_id'],
			'S_GAME_POPUP'					=> ($this->arcade->game()->session->game_popup),
			'S_RESOLUTION_SELECT'			=> ($this->arcade_config['resolution_select'] && $this->auth->acl_get('u_arcade_resolution')) ? true : false,
			'S_USE_HIGHSCORES'				=> ($game_data['game_save_type'] == NOSCORE_GAME) ? false : true,
			'S_ARCADE_POSITION_RIGHT'		=> ($this->arcade_config['play_info_box'] == ARCADE_POSITION_RIGHT) ? true : false,
			'S_ARCADE_POSITION_LEFT'		=> ($this->arcade_config['play_info_box'] == ARCADE_POSITION_LEFT) ? true : false,
			'S_USER_LANG_NAME'				=> $this->user->data['user_lang'],
			'S_BOARD_FOUNDER'				=> ($this->user->data['user_type'] == USER_FOUNDER) ? true : false,
			'S_ARCADE_HTML5_GAME'			=> (GAME_TYPE_HTML5 == $game_data['game_type']) ? true : false,
			'S_CAN_REPORT'					=> ($this->arcade_auth->acl_get('c_report', $game_data['cat_id'])) ? true : false,

			'L_RESTART_GAME'				=> sprintf($this->user->lang['ARCADE_RESTART_GAME'], $game_data['game_name']),
			'L_ARCADE_FLASH_TITLE'			=> sprintf($this->user->lang['ARCADE_FLASH_VERSION'], $this->arcade_config['flash_version']),

			'T_ARCADE_FLASH_UPDATE'			=> (file_exists($this->root_path . 'arcade/swf/FlashPlayerUpdate.swf')) ? $this->arcade->url("swf=FlashPlayerUpdate&amp;p=1") : false,

			'USER_SESSION_ID'				=> $this->user->session_id,
			'SRC_FLASH_PLAYER'				=> $this->arcade->get()->image('src', 'img', 'get_flash_player.png'),
			'ARCADE_FLASH_VERSION'			=> $this->arcade_config['flash_version'],
			'ARCADE_GAME_SESSION_ID'		=> $this->arcade->game()->session->game_sid,
			'GAME_GID'						=> $gidencoded,
			'GAME_SCOREVAR'					=> phpbb_hash($game_data["game_scorevar"]),
			'GAME_NAME'						=> $game_data['game_name'],
			'GAME_WIDTH'					=> $game_width,
			'GAME_HEIGHT'					=> $game_height,
			'GAME_RATING_IMG'				=> $this->arcade->set_rating_image($game_data, '', $this->arcade->game()->session->game_popup || $this->arcade->game()->session->lighting),
			'GAME_FAV_IMG'					=> (is_array($game_fav_data)) ? $this->arcade->set_fav_image($game_fav_data, $game_data['game_id'], '', $this->arcade->game()->session->game_popup || $this->arcade->game()->session->lighting) : '',
			'GAME_CONTROL_IMG'				=> (preg_match('/src=(["\'])(.*?)\1/', $game_control, $match) != false) ? $match[2] : '',
			'FULL_SCREEN_IMAGE'				=> $this->arcade->get()->image('src', 'img', 'full_screen.png'),
			'NORMAL_SCREEN_IMAGE'			=> $this->arcade->get()->image('src', 'img', 'normal_screen.png'),

			'FLASH_GAME_CHECK_TIME'			=> (int) ($this->arcade_config['game_time_check_time'] * 1000),
			'FLASH_GAME_TIME_TOLERANCE'		=> (float) ($this->arcade_config['game_time_tolerance_percent'] / 100),
			'FLASH_ARCADE_TIME_SWF'			=> $this->arcade->url("swf=JVA_Time_Hack_Detect"),
			'FLASH_ARCADE_SCORE_SWF'		=> urlencode($this->arcade->url('swf=JVA_Game_Score')),

			'U_GAME_REPORT'					=> $this->arcade->url("mode=report&amp;g={$game_data['game_id']}") . '#report_game'
		);

		$vars = array('tpl', 'game_data', 'game_desc', 'game_control_desc', 'use_super_champion', 'super_champion');
		extract($this->arcade->phpbb_dispatcher()->trigger_event('jv.arcade.play_game_tpl_before', compact($vars)));

		$this->template->assign_vars($tpl);

		switch($mode)
		{
			case 'play':
				$this->arcade->add_navlink('cat_game', 'mode=play', '', $game_data);

				$u_edit_game = false;
				if (!empty($this->user->data['is_registered']))
				{
					if ($this->auth->acl_get('a_arcade_game'))
					{
						$u_edit_game = append_sid("{$this->root_path}adm/index.{$this->php_ext}", $this->arcade->module_url('manage') . "&amp;mode=games&amp;action=edit&amp;g={$game_data['game_id']}", true, $this->user->session_id);
					}
					else if ($this->auth->acl_get('m_arcade_game'))
					{
						$u_edit_game = append_sid("{$this->root_path}mcp.{$this->php_ext}", $this->arcade->module_url('manage', 'm') . "&amp;mode=games&amp;action=edit&amp;g={$game_data['game_id']}", true, $this->user->session_id);
					}
				}

				$vars = array('game_data');
				extract($this->arcade->phpbb_dispatcher()->trigger_event('jv.arcade.play_game', compact($vars)));

				$this->template->assign_vars(array(
					'S_CHALLENGE_ENABLE'		=> $challenge_enabled,
					'S_GAME_DESC_TRANSLATE'		=> (($this->arcade_config['game_desc_translate'] && $this->arcade_config['display_desc'] && $game_desc) && (!$this->arcade_config['game_desc_lang'] || $this->user->data['user_lang'] != $this->arcade_config['game_desc_lang'])),
					'S_CAN_DOWNLOAD'			=> $this->arcade->game()->download_auth('user_cat', $game_data['cat_id'], $game_data['cat_download'], $game_data['game_download']),
					'S_DISPLAY_DESC'			=> ($this->arcade_config['display_desc']) ? true : false,
					'S_DISPLAY_GAME_CONTROL'	=> ($this->arcade_config['display_game_control'] && ($game_data['game_control'] || $game_control_desc)) ? true : false,
					'S_DISPLAY_GAME_TYPE'		=> ($this->arcade_config['display_game_type']) ? true : false,
					'S_DISPLAY_GAME_SAVE_TYPE'	=> ($this->arcade_config['display_game_save_type']) ? true : false,
					'S_GAME_TOPIC'				=> ($this->arcade_config['game_announce_forum'] && !empty($game_data['post_id']) && $this->auth->acl_get('f_read', $this->arcade_config['game_announce_forum'])) ? true : false,

					'U_ACTION'					=> $this->arcade->url("mode=play&amp;g={$game_data['game_id']}"),
					'U_GAME_DOWNLOAD'			=> $this->arcade->url("mode=download&amp;g={$game_data['game_id']}"),
					'U_GAME_TOPIC'				=> $this->arcade->url("p={$game_data['post_id']}", 'viewtopic') . "#p{$game_data['post_id']}",
					'U_GAME_EDIT'				=> $u_edit_game,
					'U_SCORE_EDIT'				=> ($this->auth->acl_get('a_arcade_user') && !empty($this->user->data['is_registered']) && (!empty($score_data['score_date']) || !empty($super_champion['score_date']))) ? append_sid("{$this->root_path}adm/index.{$this->php_ext}", $this->arcade->module_url('manage') . "&amp;mode=users&amp;action=show_scores&amp;g={$game_data['game_id']}", true, $this->user->session_id) : '',
					'U_FIND_USERNAME'			=> $this->arcade->url('mode=searchuser&amp;form=challenge_user&amp;field=username&amp;select_single=true', 'memberlist'),
					'U_CHALLENGE_USER'			=> $this->arcade->url('mode=champion_challenge&amp;g=' . $game_data['game_id']),

					'GAME_DESC'					=> $game_desc,
					'GAME_CONTROL'				=> $game_control,
					'GAME_CONTROL_DESC'			=> $game_control_desc,
					'GAME_TYPE'					=> $this->arcade->game()->type($game_data['game_type'], true),
					'GAME_SAVE_TYPE'			=> $this->arcade->game()->save_type($game_data['game_save_type'], true),
					'GAME_PLAYS'				=> ($game_data['game_plays'] > 0) ? sprintf($this->user->lang['ARCADE_TIMES_PLAYED'], $this->arcade->number_format($game_data['game_plays'])) : false,
					'GAME_FILESIZE'				=> ($game_data['game_filesize'] > 0 ) ? sprintf($this->user->lang['ARCADE_GAMES_FILESIZE'], get_formatted_filesize($game_data['game_filesize'])) : sprintf($this->user->lang['ARCADE_GAMES_FILESIZE'], get_formatted_filesize($this->arcade->set_filesize($game_data['game_id']))),
					'SMALL_IMAGE'				=> $this->arcade->get()->image('src', 'img', 'small.png'),
					'BIG_IMAGE'					=> $this->arcade->get()->image('src', 'img', 'big.png'),
					'AUTO_IMAGE'				=> $this->arcade->get()->image('src', 'img', 'automatic.png'),
					'ORIGINAL_IMAGE'			=> $this->arcade->get()->image('src', 'img', 'original.png'),
					'OPEN_CLOSE_IMAGE'			=> $this->arcade->get()->image('src', 'img', 'open_close.png'),
					'DISPLAY_INFO_BLOCK'		=> ($this->arcade->game()->session->info_block) ? 'none' : 'block',
					'GAME_WINDOW_WIDTH'			=> ($this->arcade->game()->session->info_block) ? '100' : '75',
					'ARCADE_TURNOFF'			=> ($this->arcade->game()->session->lighting) ? 'visible' : 'hidden',
					'GAME_NAME_STYLE'			=> ($this->arcade->game()->session->lighting) ? ' style="color: #fff;"' : '',
					'LIGHTBULB_IMAGE'			=> $this->arcade->get()->image('src', 'img', 'lightbulb_' . (($this->arcade->game()->session->lighting) ? 'off' : 'on') . '.png'),
					'L_ARCADE_BACKLIGHT'		=> $this->user->lang['ARCADE_BACKLIGHT_' . (($this->arcade->game()->session->lighting) ? 'ON' : 'OFF')],
					'L_GAME_PLAY_INFO_BLOCK'	=> $this->user->lang['ARCADE_GAME_PLAY_INFO_BLOCK_' . (($this->arcade->game()->session->info_block) ? 'OPEN' : 'CLOSE')]
				));

				if ($s_use_points)
				{
					$super_reward		= (float) $this->arcade_config['super_record_reward'];
					$no_score			= ($game_data['game_highuser'] == 0 && $game_data['game_highdate'] == 0) ? true : false;
					$add_points			= (!$no_score || $this->arcade_config['first_score_reward']) ? true : false;
					$add_points			= ($add_points && (!$this->arcade_auth->acl_get('c_playfree', $game_data['cat_id']) || $this->arcade_config['playfree_reward'])) ? true : false;

					$this->template->assign_vars(array(
						'S_SHOW_POINTS'				=> true,
						'S_USE_JACKPOT'				=> ($this->arcade->points()->use_game_jackpot($game_data)) ? true : false,
						'S_SUPER_CHAMPION_REWARD'	=> ($super_reward > 0 && !empty($super_champion['user_id'])) ? true : false,

						'SUPER_CHAMPION_REWARD'		=> (!$super_reward) ? $this->user->lang['ARCADE_NONE'] : $this->arcade->number_format($super_reward) . ' ' . $this->arcade->points()->data['name'],
						'AUSER_POINTS'				=> $this->arcade->number_format($this->arcade->points()->data['total']) . ' ' . $this->arcade->points()->data['name'],
						'GAME_COST'					=> (!$game_cost || $game_cost == ARCADE_FREE || $this->arcade_auth->acl_get('c_playfree', $game_data['cat_id'])) ? $this->user->lang['ARCADE_NONE'] : $this->arcade->number_format($game_cost) . ' ' . $this->arcade->points()->data['name'],
						'GAME_REWARD'				=> (!$add_points || !$game_reward || $game_reward == ARCADE_FREE) ? $this->user->lang['ARCADE_NONE'] : $this->arcade->number_format($game_reward) . ' ' . $this->arcade->points()->data['name'],
						'DOWNLOAD_COST'				=> (!$game_download_cost || $game_download_cost == ARCADE_FREE || $this->arcade_auth->acl_get('c_downloadfree', $game_data['cat_id'])) ? $this->user->lang['ARCADE_FREE'] : $this->arcade->number_format($game_download_cost) . ' ' . $this->arcade->points()->data['name']
					));
				}

				$this->arcade->display()->online_playing(true);
			break;

			case 'popup':
				$highscore = (!empty($game_data['username']) && !$this->arcade->hidden_score($game_data['game_id'], $game_data['game_highuser'])) ? $this->arcade->number_format($game_data['game_highscore']) : $this->user->lang['HIDDEN'];
				$popup_title = (!empty($game_data['username'])) ? sprintf($this->user->lang['ARCADE_POPUP_HIGHUSER'], $game_data['game_name'], $game_data['username'], $highscore) : sprintf($this->user->lang['ARCADE_POP_NO_HIGHSCORE'], $game_data['game_name']);

				$this->template->assign_vars(array(
					'U_ACTION'		=> $this->arcade->url("mode=popup&amp;g={$game_data['game_id']}"),
					'POPUP_TITLE'	=> $popup_title
				));
			break;
		}

		$this->arcade->display()->page($this->arcade->page_title, 'arcade/' . (($mode == 'play') ? 'play_body' : 'popup_body') . '.html');
	}
}
