<?php
/**
*
* @package phpBB Arcade
* @version $Id: version_check.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

use phpbb\exception\exception_interface;
use phpbb\exception\version_check_exception;

class version_check
{
	protected $ext_manager, $user, $template;

	public function __construct($ext_manager, $user, $template)
	{
		$this->ext_manager = $ext_manager;
		$this->user = $user;
		$this->template = $template;
	}

	public function main($ext_name, $u_action, $versioncheck_force = false, $version_info = false, $force_cache = false)
	{
		$up_to_date = false;

		if ($ext_name && $u_action)
		{
			$this->user->add_lang('acp/extensions');
			$md_manager = $this->ext_manager->create_extension_metadata_manager($ext_name);

			try
			{
				$md_manager->get_metadata('all');
			}
			catch (exception_interface $e)
			{
				$message = call_user_func_array(array($this->user, 'lang'), array_merge(array($e->getMessage()), $e->get_parameters()));

				if ($version_info)
				{
					return false;
				}
				else
				{
					trigger_error($message . adm_back_link($u_action), E_USER_WARNING);
				}
			}

			$meta = $md_manager->get_metadata('all');

			if (!$version_info)
			{
				$this->output_metadata_to_template($meta);
			}

			if (isset($meta['extra']['version-check']))
			{
				try
				{
					$updates_available = $this->ext_manager->version_check($md_manager, $versioncheck_force, $force_cache, 'unstable');
					$up_to_date = (empty($updates_available)) ? true : false;

					$this->template->assign_vars(array(
						'S_UP_TO_DATE' => $up_to_date,
						'UP_TO_DATE_MSG' => $this->user->lang($up_to_date ? 'UP_TO_DATE' : 'NOT_UP_TO_DATE', $md_manager->get_metadata('display-name')),
					));

					if (!$version_info)
					{
						$this->template->assign_block_vars('updates_available', $updates_available);
					}
				}
				catch (exception_interface $e)
				{
					$message = call_user_func_array(array($this->user, 'lang'), array_merge(array($e->getMessage()), $e->get_parameters()));

					$this->template->assign_vars(array(
						'S_VERSIONCHECK_FAIL' => true,
						'VERSIONCHECK_FAIL_REASON' => ($e->getMessage() !== 'VERSIONCHECK_FAIL') ? $message : '',
					));
				}

				$s_version_check = ($version_info && $up_to_date) ? false : true;
				$this->template->assign_var('S_VERSIONCHECK', $s_version_check);
			}
			else
			{
				$this->template->assign_var('S_VERSIONCHECK', false);
			}

			if (!$version_info)
			{
				$this->template->assign_vars(array(
					'U_BACK'				=> $u_action,
					'U_VERSIONCHECK_FORCE'	=> $u_action . '&amp;action=version_check&amp;versioncheck_force=1&amp;ext_name=' . urlencode($md_manager->get_metadata('name')),
				));
			}
		}

		if ($version_info)
		{
			return $up_to_date;
		}
	}

	public function output_metadata_to_template($metadata)
	{
		$this->template->assign_vars(array(
			'META_NAME'			=> $metadata['name'],
			'META_TYPE'			=> $metadata['type'],
			'META_DESCRIPTION'	=> (isset($metadata['description'])) ? $metadata['description'] : '',
			'META_HOMEPAGE'		=> (isset($metadata['homepage'])) ? $metadata['homepage'] : '',
			'META_VERSION'		=> $metadata['version'],
			'META_TIME'			=> (isset($metadata['time'])) ? $metadata['time'] : '',
			'META_LICENSE'		=> $metadata['license'],

			'META_REQUIRE_PHP'		=> (isset($metadata['require']['php'])) ? $metadata['require']['php'] : '',
			'META_REQUIRE_PHP_FAIL'	=> (isset($metadata['require']['php'])) ? false : true,

			'META_REQUIRE_PHPBB'		=> (isset($metadata['extra']['soft-require']['phpbb/phpbb'])) ? $metadata['extra']['soft-require']['phpbb/phpbb'] : '',
			'META_REQUIRE_PHPBB_FAIL'	=> (isset($metadata['extra']['soft-require']['phpbb/phpbb'])) ? false : true,

			'META_DISPLAY_NAME'	=> (isset($metadata['extra']['display-name'])) ? $metadata['extra']['display-name'] : '',
		));

		foreach ($metadata['authors'] as $author)
		{
			$this->template->assign_block_vars('meta_authors', array(
				'AUTHOR_NAME'		=> $author['name'],
				'AUTHOR_EMAIL'		=> (isset($author['email'])) ? $author['email'] : '',
				'AUTHOR_HOMEPAGE'	=> (isset($author['homepage'])) ? $author['homepage'] : '',
				'AUTHOR_ROLE'		=> (isset($author['role'])) ? $author['role'] : '',
			));
		}
	}
}
