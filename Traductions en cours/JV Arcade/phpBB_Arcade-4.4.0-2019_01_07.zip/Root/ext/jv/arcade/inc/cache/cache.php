<?php
/**
*
* @package phpBB Arcade
* @version $Id: cache.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\cache;

class cache
{
	protected $db, $cache;

	public function __construct($db, $cache)
	{
		$this->db = $db;
		$this->cache = $cache;
	}

	/**
	* Obtain arcade games
	*/
	function obtain_arcade_games()
	{
		if (($games = $this->cache->get('_arcade_games')) === false)
		{
			$sql = 'SELECT game_id, game_name, game_name_clean, game_image, game_width, game_height, game_type, cat_id
					FROM ' . ARCADE_GAMES_TABLE . '
					ORDER BY game_name_clean ASC';
			$result = $this->db->sql_query($sql);

			$games = array();

			while ($row = $this->db->sql_fetchrow($result))
			{
				$games[$row['game_id']] = array(
					'game_name'		=> $row['game_name'],
					'game_image'	=> $row['game_image'],
					'game_width'	=> $row['game_width'],
					'game_height'	=> $row['game_height'],
					'game_type'		=> $row['game_type'],
					'cat_id'		=> $row['cat_id']
				);
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_games', $games);
		}

		return $games;
	}

	/**
	* Obtain arcade categories
	*/
	function obtain_arcade_cats()
	{
		if (($cats = $this->cache->get('_arcade_cats')) === false)
		{
			$sql = 'SELECT cat_id, cat_name, cat_style, cat_status, cat_link, cat_type, cat_test, cat_age, cat_download, cat_password,
							cat_rules, cat_rules_link, parent_id, cat_parents, left_id, right_id, cat_desc, cat_desc_options, cat_desc_uid,
							cat_desc_bitfield, cat_rules_options, cat_rules_uid, cat_rules_bitfield, cat_games_per_page, cat_use_jackpot, cat_flags
					FROM ' . ARCADE_CATS_TABLE . '
					ORDER BY cat_id ASC';
			$result = $this->db->sql_query($sql);

			$cats = array();
			while ($row = $this->db->sql_fetchrow($result))
			{
				$cats[$row['cat_id']] = array(
					'cat_id'				=> $row['cat_id'],
					'cat_name'				=> $row['cat_name'],
					'cat_style'				=> $row['cat_style'],
					'cat_status'			=> $row['cat_status'],
					'cat_link'				=> $row['cat_link'],
					'cat_type'				=> $row['cat_type'],
					'cat_test'				=> $row['cat_test'],
					'cat_age'				=> $row['cat_age'],
					'cat_download'			=> $row['cat_download'],
					'cat_password'			=> $row['cat_password'],
					'cat_rules'				=> $row['cat_rules'],
					'cat_rules_link'		=> $row['cat_rules_link'],
					'cat_rules_options'		=> $row['cat_rules_options'],
					'cat_rules_uid'			=> $row['cat_rules_uid'],
					'cat_rules_bitfield'	=> $row['cat_rules_bitfield'],
					'parent_id'				=> $row['parent_id'],
					'cat_parents'			=> $row['cat_parents'],
					'left_id'				=> $row['left_id'],
					'right_id'				=> $row['right_id'],
					'cat_desc'				=> $row['cat_desc'],
					'cat_desc_options'		=> $row['cat_desc_options'],
					'cat_desc_uid'			=> $row['cat_desc_uid'],
					'cat_desc_bitfield'		=> $row['cat_desc_bitfield'],
					'cat_games_per_page'	=> $row['cat_games_per_page'],
					'cat_use_jackpot'		=> $row['cat_use_jackpot'],
					'cat_flags'				=> $row['cat_flags']
				);
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_cats', $cats);
		}

		return $cats;
	}

	function obtain_arcade_leaders($limit)
	{
		if (($row = $this->cache->get('_arcade_leaders')) === false)
		{
			$sql = 'SELECT au.arcade_total_wins AS total_wins, u.user_id, u.username, u.user_colour, u.user_avatar, u.user_avatar_type
					FROM ' . ARCADE_USERS_TABLE . ' au, ' . USERS_TABLE . ' u
					WHERE u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
						AND au.user_id = u.user_id
						AND au.arcade_total_wins > 0
					ORDER BY total_wins DESC';
			$result = $this->db->sql_query_limit($sql, $limit);
			$row = $this->db->sql_fetchrowset($result);
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_leaders', $row);
		}

		return $row;
	}

	function obtain_challenge_leaders($limit)
	{
		if (($row = $this->cache->get('_arcade_challenge_leaders')) === false)
		{
			$sql_array = array(
				'SELECT'	=> 'COUNT(c.champ_winner) AS total_wins, MIN(c.champ_end_time) AS oldest_time, u.user_id, u.username, u.user_colour, u.user_avatar, u.user_avatar_type',
				'FROM'		=> array(ARCADE_CHALLENGE_CHAMP_TABLE => 'c'),
				'LEFT_JOIN'	=> array(array('FROM' => array(USERS_TABLE => 'u'), 'ON' => 'c.champ_winner = u.user_id')),
				'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
					AND c.champ_winner = u.user_id
					AND c.champ_close = ' . CHALLENGE_CLOSE,
				'GROUP_BY'	=> 'u.user_id, u.username, u.user_colour, u.user_avatar, u.user_avatar_type',
				'ORDER_BY'	=> 'total_wins DESC, oldest_time ASC'
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, $limit);
			$row = $this->db->sql_fetchrowset($result);
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_challenge_leaders', $row);
		}

		return $row;
	}

	function obtain_tour_leaders($limit)
	{
		if (($row = $this->cache->get('_arcade_tour_leaders')) === false)
		{
			$sql_array = array(
				'SELECT'	=> 'COUNT(t.tour_wins) AS total_wins, MIN(t.tour_endtime) AS oldest_time, u.user_id, u.username, u.user_colour, u.user_avatar, u.user_avatar_type',
				'FROM'		=> array(ARCADE_TOUR_TABLE => 't'),
				'LEFT_JOIN'	=> array(array('FROM' => array(USERS_TABLE => 'u'), 'ON' => 't.tour_wins = u.user_id')),
				'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
					AND t.tour_status = ' . ARCADE_END_TOUR . '
					AND t.tour_wins = u.user_id
					AND t.tour_wins > ' . ANONYMOUS,
				'GROUP_BY'	=> 'u.user_id, u.username, u.user_colour, u.user_avatar, u.user_avatar_type',
				'ORDER_BY'	=> 'total_wins DESC, oldest_time ASC'
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, $limit);
			$row = $this->db->sql_fetchrowset($result);
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_tour_leaders', $row);
		}

		return $row;
	}

	function obtain_arcade_super_champion_all()
	{
		if (($super_champion = $this->cache->get('_arcade_super_champion_all')) === false)
		{
			$super_champion = array();
			$sql = 'SELECT au.user_id, au.arcade_total_super_scores
					FROM ' . ARCADE_USERS_TABLE . ' au, ' . USERS_TABLE . ' u
					WHERE u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
						AND au.user_id = u.user_id
						AND au.arcade_total_super_scores > 0';
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$super_champion[$row['user_id']] = $row['arcade_total_super_scores'];
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_super_champion_all', $super_champion);
		}

		return $super_champion;
	}

	function obtain_arcade_leaders_all()
	{
		if (($highscore_data = $this->cache->get('_arcade_leaders_all')) === false)
		{
			$highscore_data = array();
			$sql = 'SELECT au.user_id, au.arcade_total_wins
					FROM ' . ARCADE_USERS_TABLE . ' au, ' . USERS_TABLE . ' u
					WHERE u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
						AND au.user_id = u.user_id
						AND au.arcade_total_wins > 0';
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$highscore_data[$row['user_id']] = $row['arcade_total_wins'];
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_leaders_all', $highscore_data);
		}

		return $highscore_data;
	}

	function obtain_challenge_leaders_all()
	{
		if (($all_leaders = $this->cache->get('_arcade_challenge_leaders_all')) === false)
		{
			$all_leaders = array();
			$sql_array = array(
				'SELECT'	=> 'COUNT(c.champ_winner) AS total_wins, MIN(c.champ_end_time) AS oldest_time, u.user_id',
				'FROM'		=> array(ARCADE_CHALLENGE_CHAMP_TABLE => 'c',),
				'LEFT_JOIN'	=> array(array('FROM' => array(USERS_TABLE => 'u'), 'ON' => 'c.champ_winner = u.user_id')),
				'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
					AND c.champ_close = ' . CHALLENGE_CLOSE . '
					AND c.champ_winner = u.user_id
					AND c.champ_winner <> ' . CHALLENGE_TIE,
				'GROUP_BY'	=> 'u.user_id',
				'ORDER_BY'	=> 'total_wins DESC, oldest_time ASC'
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$all_leaders[$row['user_id']] = $row['total_wins'];
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_challenge_leaders_all', $all_leaders);
		}

		return $all_leaders;
	}

	function obtain_tour_leaders_all()
	{
		if (($all_leaders = $this->cache->get('_arcade_tour_leaders_all')) === false)
		{
			$all_leaders = array();
			$sql_array = array(
				'SELECT'	=> 'COUNT(t.tour_wins) AS total_wins, MIN(t.tour_endtime) AS oldest_time, u.user_id',
				'FROM'		=> array(ARCADE_TOUR_TABLE => 't',),
				'LEFT_JOIN'	=> array(array('FROM' => array(USERS_TABLE => 'u'), 'ON' => 't.tour_wins = u.user_id')),
				'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
					AND t.tour_status = ' . ARCADE_END_TOUR . '
					AND t.tour_wins = u.user_id
					AND t.tour_wins > ' . ANONYMOUS,
				'GROUP_BY'	=> 'u.user_id',
				'ORDER_BY'	=> 'total_wins DESC, oldest_time ASC'
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$all_leaders[$row['user_id']] = $row['total_wins'];
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_tour_leaders_all', $all_leaders);
		}

		return $all_leaders;
	}

	function obtain_arcade_games_filesize()
	{
		if (($games_filesize = $this->cache->get('_arcade_games_filesize')) === false)
		{
			$sql = 'SELECT SUM(game_filesize) AS games_filesize
					FROM ' . ARCADE_GAMES_TABLE;
			$result = $this->db->sql_query($sql);
			$games_filesize = (int) $this->db->sql_fetchfield('games_filesize');
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_games_filesize', $games_filesize);
		}

		return $games_filesize;
	}

	function obtain_arcade_recent_sites($download_url = '')
	{
		if (($sites = $this->cache->get('_arcade_recent_sites')) === false)
		{
			$sites = array();

			if ($download_url !== '')
			{
				$sites[] = $download_url;
			}

			$this->cache->put('_arcade_recent_sites', $sites);
		}

		$add_site = ($download_url !== '' && !in_array($download_url, $sites)) ? true : false;

		if ($add_site)
		{
			$sites[] = $download_url;
			$this->cache->put('_arcade_recent_sites', $sites);
		}

		return $sites;
	}

	function obtain_arcade_ban_users()
	{
		if (($all_ban_users = $this->cache->get('_arcade_ban_users')) === false)
		{
			$all_ban_users = array();

			$sql = 'SELECT user_id, banned_ip
					FROM ' . ARCADE_USERS_BANNED_TABLE;
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$all_ban_users[$row['user_id']] = $row['banned_ip'];
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_ban_users', $all_ban_users);
		}

		return $all_ban_users;
	}

	function obtain_arcade_announcement()
	{
		if (($announce = $this->cache->get('_arcade_announcement')) === false)
		{
			$sql = 'SELECT * FROM ' . ARCADE_ANNOUNCE_TABLE . ' a1, ' . ARCADE_ANNOUNCE_DATA_TABLE . ' a2
					WHERE a1.announce_id = a2.announce_id
					ORDER BY a1.announce_id ASC';
			$result = $this->db->sql_query($sql);
			$announce = array();
			while ($row = $this->db->sql_fetchrow($result))
			{
				$announce[$row['lang_dir']][$row['announce_name']] = array(
					'announce_id'	=> $row['announce_id'],
					'user_id'		=> $row['user_id'],
					'username'		=> $row['username'],
					'user_colour'	=> $row['user_colour'],
					'subject'		=> $row['subject'],
					'message'		=> $row['message'],
					'bitfield'		=> $row['bitfield'],
					'options'		=> $row['options'],
					'uid'			=> $row['uid'],
					'announce_date'	=> $row['announce_date']
				);
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_announcement', $announce);
		}

		return $announce;
	}

	function obtain_arcade_hidden_scores()
	{
		if (($hidden_scores = $this->cache->get('_arcade_hidden_scores')) === false)
		{
			$sql = 'SELECT game_id, challenger_id, opponent_id
					FROM ' . ARCADE_CHALLENGE_TABLE . '
					WHERE challenge_accept = ' . CHALLENGE_ACCEPTED;
			$result = $this->db->sql_query($sql);
			$hidden_scores = array();
			while ($row = $this->db->sql_fetchrow($result))
			{
				$hidden_scores[$row['game_id']][$row['challenger_id']] = 1;
				$hidden_scores[$row['game_id']][$row['opponent_id']] = 1;
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_hidden_scores', $hidden_scores);
		}

		return $hidden_scores;
	}

	/**
	* Obtain arcade tournaments
	*/
	function obtain_arcade_tours()
	{
		if (($tours = $this->cache->get('_arcade_tours')) === false)
		{
			$tours = array();
			$sql = 'SELECT tour_id, tour_name, tour_status
					FROM ' . ARCADE_TOUR_TABLE . '
					ORDER BY tour_id ASC';
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$tours[$row['tour_id']] = array(
					'tour_name'		=> $row['tour_name'],
					'tour_status'	=> $row['tour_status']
				);
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_tours', $tours);
		}

		return $tours;
	}

	/**
	* Obtain ranks
	*/
	function obtain_arcade_ranks()
	{
		if (($ranks = $this->cache->get('_arcade_ranks')) === false)
		{
			$sql = 'SELECT *
					FROM ' . ARCADE_RANKS_TABLE . '
					ORDER BY rank_min DESC';
			$result = $this->db->sql_query($sql);

			$ranks = array();
			while ($row = $this->db->sql_fetchrow($result))
			{
				if ($row['rank_special'])
				{
					$ranks['special'][$row['rank_id']] = array(
						'rank_title' => $row['rank_title'],
						'rank_image' => $row['rank_image']
					);
				}
				else
				{
					$ranks['normal'][] = array(
						'rank_title' => $row['rank_title'],
						'rank_min'	 => $row['rank_min'],
						'rank_image' => $row['rank_image']
					);
				}
			}
			$this->db->sql_freeresult($result);

			$this->cache->put('_arcade_ranks', $ranks);
		}

		return $ranks;
	}
}
