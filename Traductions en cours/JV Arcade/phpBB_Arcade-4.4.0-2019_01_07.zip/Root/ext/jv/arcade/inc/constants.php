<?php
/**
*
* @package phpBB Arcade
* @version $Id: constants.php 2139 2019-01-07 11:57:04Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class constants
{
	public function __construct($table_prefix)
	{
		 /*
		* If you delete the // in the next line, so your installation is checked. If an error is found in the database, it will be corrected automatically.
		* With the exception of the modules!
		*/
		//define('PHPBB_ARCADE_AUTO_INSTALL_REPAIR', true);

		define('ARCADE_VERSION', '4.4.0');

		define('ARCADE_TEST_SYSTEM', false);

		// Version compatibility
		define('ARCADE_MIN_VERSION', '4.4.0');
		define('ARCADE_ACP_DL_SYSTEM_VERSION', '4.4.0');
		define('ARCADE_MIN_B3PORTAL_VERSION', '6.2.0');
		define('ARCADE_MIN_EXT_VERSION', '1.1.0');
		define('ARCADE_MIN_JVA_START_SYSTEM', '2.2.0');

		define('ARCADE_DISABLED', 0);

		// max limit
		define('INS_ARCADE_UPDATE_DATA_LIMIT', 100);
		define('INS_ARCADE_CONVERT_GAME_INSTALL_FILE_LIMIT', 300);

		// cookie info close time - 31 days :: 60*60*24*31
		define('ARCADE_COOKIE_INFO_CLOSE_TIME', 2678400);

		define('ARCADE_GAME_RESTART', -1);

		define('ARCADE_SET_DISABLED', 0);
		define('ARCADE_SET_ENABLED', 1);

		define('ARCADE_CAT_STYLE_BASIC', 0);
		define('ARCADE_CAT_STYLE_ARCADE', 1);
		define('ARCADE_CAT_STYLE_FORUM', 2);
		define('ARCADE_CAT_STYLE_SIMPLE_NAME', 3);

		define('ARCADE_CAT_DISPLAY_BOTH', 0);
		define('ARCADE_CAT_DISPLAY_NAME', 1);
		define('ARCADE_CAT_DISPLAY_IMAGE', 2);

		define('ARCADE_NO_DISPLAY', 0);
		define('ARCADE_DISPLAY_ARCADE', 1);
		define('ARCADE_DISPLAY_FORUM', 2);
		define('ARCADE_DISPLAY_PORTAL', 3);
		define('ARCADE_DISPLAY_EVERY', 4);
		define('ARCADE_DISPLAY_EVERY_EXCEPT_PORTAL', 5);

		define('ARCADE_CAT_MIN_HEIGHT', 120);

		// Log types
		define('ARCADE_LOG_CRITICAL', 0);
		define('ARCADE_LOG_ADMIN', 1);
		define('ARCADE_LOG_MOD', 2);
		define('ARCADE_LOG_USERS', 3);

		define('SCORETYPE_HIGH', 0);
		define('SCORETYPE_LOW', 1);

		define('ARCADE_POSITION_LEFT', 'l');
		define('ARCADE_POSITION_CENTER', 'c');
		define('ARCADE_POSITION_RIGHT', 'r');

		define('ARCADE_CAT_TEST', 1);

		define('ARCADE_CAT', 0);
		define('ARCADE_CAT_GAMES', 1);
		define('ARCADE_LINK', 2);

		define('ARCADE_CHECK_EVERYONE', 0);
		define('ARCADE_CHECK_USER_NORMAL', 1);
		define('ARCADE_CHECK_DISABLED', 2);

		define('ARCADE_FLAG_LINK_TRACK', 1);

		define('ARCADE_GUEST_NONE', 0);
		define('ARCADE_GUEST_VIEW', 1);
		define('ARCADE_GUEST_PLAY', 2);

		define('LIMIT_PLAY_TYPE_NONE', 0);
		define('LIMIT_PLAY_TYPE_POSTS', 1);
		define('LIMIT_PLAY_TYPE_DAYS', 2);
		define('LIMIT_PLAY_TYPE_BOTH', 3);

		define('ARCADE_FAV_ID'	 , -1);
		define('ARCADE_SEARCH_ID', -2);

		define('ARCADE_FAV_ADD', 1);
		define('ARCADE_FAV_DEL', 2);

		define('ARCADE_ORDER_FIXED', 'f');
		define('ARCADE_ORDER_INSTALLDATE', 'd');
		define('ARCADE_ORDER_NAME', 'n');
		define('ARCADE_ORDER_PLAYS', 'p');
		define('ARCADE_ORDER_RATING', 'r');
		define('ARCADE_ORDER_HIGHLIGHTED', 'h');
		define('ARCADE_ORDER_CAT', 'c');

		define('ARCADE_ORDER_ASC', 'a');
		define('ARCADE_ORDER_DESC', 'd');

		define('ARCADE_INDEX_PAGE', 'index');

		define('ARCADE_POSITION_TOP', 1);
		define('ARCADE_POSITION_MIDDLE', 2);
		define('ARCADE_POSITION_BOTTOM', 3);

		define('GAME_CONTROL_KEYBOARD_MOUSE', 1);
		define('GAME_CONTROL_KEYBOARD', 2);
		define('GAME_CONTROL_MOUSE', 3);

		define('GAME_TYPE_FLASH', 1);
		define('GAME_TYPE_HTML5', 2);

		define('UNKNOWN_GAME', 0);
		define('AMOD_GAME', 1);
		define('IBPRO_GAME', 2);
		define('V3ARCADE_GAME', 3);
		define('IBPROV3_GAME', 4);
		define('ARCADELIB_GAME', 5);
		define('NOSCORE_GAME', 6);
		define('AR_GAME', 7);
		define('PHPBBARCADE_GAME', 8);
		define('PHPBB_RA_GAME', 9);
		define('OLYMPUS_GAME', 10);

		define('ARCADE_MIN_GAME_WIDTH', 100);
		define('ARCADE_MIN_GAME_HEIGHT', 100);

		define('ARCADE_FREE', -1);

		define('ARCADE_JV_POINTS_SYSTEM', 1);
		define('ARCADE_ULTIMATE_POINTS_SYSTEM', 2);

		define('ARCADE_MCHAT', 1);
		define('ARCADE_AJAX_CHAT', 2);
		define('ARCADE_AJAX_SHOUTBOX', 3);
		define('ARCADE_JV_SHOUTBOX', 4);

		define('ARCADE_BOARD3_PORTAL', 1);
		define('ARCADE_SIMPLE_PORTAL', 2);
		define('ARCADE_KISS_PORTAL', 3);

		define('ARCADE_REPORT_DOUBLE', 0);
		define('ARCADE_REPORT_SCORING', 1);
		define('ARCADE_REPORT_PLAYING', 2);
		define('ARCADE_REPORT_DOWNLOADING', 3);
		define('ARCADE_REPORT_OTHER', 4);

		define('ARCADE_REPORT_OPEN', 0);
		define('ARCADE_REPORT_CLOSE', 1);

		define('ARCADE_BANNED_UNKNOWN', 0);
		define('ARCADE_BANNED_ADMIN', 1);
		define('ARCADE_BANNED_INVALID_FORM1', 2);
		define('ARCADE_BANNED_INVALID_FORM2', 3);
		define('ARCADE_BANNED_INVALID_FORM3', 4);
		define('ARCADE_BANNED_TIME_HACK', 5);

		define('SCORE_SECURITY_LOW', 1);
		define('SCORE_SECURITY_MEDIUM', 2);
		define('SCORE_SECURITY_HIGH', 3);

		define('CHALLENGE_TIE', 0);

		define('CHALLENGE_CLOSE', 1);

		define('CHALLENGE_UNACCEPTED', 0);
		define('CHALLENGE_ACCEPTED', 1);

		define('ARCADE_WAIT_TOUR', 0);
		define('ARCADE_START_TOUR', 1);
		define('ARCADE_END_TOUR', 2);

		define('ACL_ARCADE_GROUPS_TABLE',		$table_prefix . 'acl_arcade_groups');
		define('ACL_ARCADE_OPTIONS_TABLE',		$table_prefix . 'acl_arcade_options');
		define('ACL_ARCADE_ROLES_DATA_TABLE',	$table_prefix . 'acl_arcade_roles_data');
		define('ACL_ARCADE_ROLES_TABLE',		$table_prefix . 'acl_arcade_roles');
		define('ACL_ARCADE_USERS_TABLE',		$table_prefix . 'acl_arcade_users');
		define('ARCADE_ACCESS_TABLE',			$table_prefix . 'arcade_access');
		define('ARCADE_CATS_TABLE',				$table_prefix . 'arcade_categories');
		define('ARCADE_CONFIG_TABLE',			$table_prefix . 'arcade_config');
		define('ARCADE_DOWNLOAD_TABLE',			$table_prefix . 'arcade_download');
		define('ARCADE_GAMES_TABLE',			$table_prefix . 'arcade_games');
		define('ARCADE_FAVS_TABLE', 			$table_prefix . 'arcade_favorites');
		define('ARCADE_PLAYS_TABLE',			$table_prefix . 'arcade_plays');
		define('ARCADE_RATING_TABLE',			$table_prefix . 'arcade_game_rating');
		define('ARCADE_SESSIONS_TABLE',			$table_prefix . 'arcade_sessions');
		define('ARCADE_SCORES_TABLE',			$table_prefix . 'arcade_scores');
		define('ARCADE_SUPER_SCORES_TABLE',		$table_prefix . 'arcade_super_scores');
		define('ARCADE_LOGS_TABLE',				$table_prefix . 'arcade_logs');
		define('ARCADE_REPORTS_TABLE',			$table_prefix . 'arcade_reports');
		define('ARCADE_USERS_TABLE',			$table_prefix . 'arcade_users');
		define('ARCADE_USERS_BANNED_TABLE',		$table_prefix . 'arcade_users_banned');
		define('ARCADE_ANNOUNCE_TABLE',			$table_prefix . 'arcade_announce');
		define('ARCADE_ANNOUNCE_DATA_TABLE',	$table_prefix . 'arcade_announce_data');
		define('ARCADE_DELETE_GAMES_TABLE',		$table_prefix . 'arcade_delete_games');
		define('ARCADE_CHALLENGE_TABLE',		$table_prefix . 'arcade_challenge');
		define('ARCADE_CHALLENGE_CHAMP_TABLE',	$table_prefix . 'arcade_challenge_champ');
		define('ARCADE_TOUR_TABLE',				$table_prefix . 'arcade_tour');
		define('ARCADE_TOUR_CHAMP_TABLE',		$table_prefix . 'arcade_tour_champ');
		define('ARCADE_TOUR_WINS_TABLE',		$table_prefix . 'arcade_tour_wins');
		define('ARCADE_RANKS_TABLE',			$table_prefix . 'arcade_ranks');
		define('ARCADE_MENU_TABLE',				$table_prefix . 'arcade_menu');
	}
}
