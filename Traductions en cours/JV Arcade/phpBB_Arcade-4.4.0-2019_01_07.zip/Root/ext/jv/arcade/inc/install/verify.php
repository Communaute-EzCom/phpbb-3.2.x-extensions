<?php
/**
*
* @package phpBB Arcade
* @version $Id: verify.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\install;

class verify
{
	private $passed = true;
	private $redirect = false;

	protected $db, $db_tools, $user, $config, $template, $arcade_config, $arcade, $file_functions, $root_path, $php_ext;

	public function __construct($db, $db_tools, $user, $config, $template, $arcade_config, $arcade, $file_functions, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->db_tools = $db_tools;
		$this->user = $user;
		$this->config = $config;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
		$this->file_functions = $file_functions;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function check_server_requirements($url)
	{
		$requirements = $this->arcade->install('verify')->data->requirements();

		// Step 1
		$this->gen('legend', 'INSTALL_ARCADE_SOFTWARE_VERSION');

		// Test for correct phpBB version
		if (phpbb_version_compare($this->config['version'], $requirements['version']['phpbb'], '<'))
		{
			$this->passed = false;
			$result = $this->arcade->color_text($this->user->lang['NO'], 'red');
		}
		else
		{
			$result = $this->arcade->color_text($this->user->lang['YES']);
		}

		$this->gen('result_explain', 'INSTALL_ARCADE_PHPBB_REQD', $result, $requirements['version']['phpbb']);

		// Step 2
		$this->gen('legend', 'INSTALL_ARCADE_PHP_SETTINGS');

		// Test the minimum PHP version
		$php_version = PHP_VERSION;

		if (phpbb_version_compare($php_version, $requirements['version']['php'], '<'))
		{
			$this->passed = false;
			$result = $this->arcade->color_text($this->user->lang['NO'], 'red');
		}
		else
		{
			$result = $this->arcade->color_text($this->user->lang['YES']);
		}

		$this->gen('result_explain', 'INSTALL_ARCADE_PHP_REQD', $result, $requirements['version']['php']);

		if (@ini_get('allow_url_fopen') == '1' || strtolower(@ini_get('allow_url_fopen')) == 'on')
		{
			$result = $this->arcade->color_text($this->user->lang['YES']);
		}
		else
		{
			$result = $this->arcade->color_text($this->user->lang['NO'], 'red');
		}

		$this->gen('result_explain', 'INSTALL_ARCADE_PHP_URL_FOPEN_SUPPORT', $result);

		// Check for curl
		if (@function_exists('curl_init'))
		{
			$result = $this->arcade->color_text($this->user->lang['YES']);
		}
		else
		{
			$result = $this->arcade->color_text($this->user->lang['NO'], 'red');
		}

		$this->gen('result_explain', 'INSTALL_ARCADE_PHP_CURL_SUPPORT', $result);

		// Check for getimagesize
		if (@function_exists('getimagesize'))
		{
			$result = $this->arcade->color_text($this->user->lang['YES']);
		}
		else
		{
			$this->passed = false;
			$result = $this->arcade->color_text($this->user->lang['NO'], 'red');
		}

		$this->gen('result_explain', 'INSTALL_ARCADE_PHP_GETIMAGESIZE_SUPPORT', $result);

		// Step 3
		$this->gen('legend_explain', 'INSTALL_ARCADE_DIRS_FILES_REQD');

		umask(0);

		$c_all = array('arcade/gamedata/', ((!empty($this->arcade_config['game_path'])) ? $this->arcade_config['game_path'] : 'arcade/games/'), 'games/');

		foreach ($requirements['writable_dirs'] as $dir)
		{
			$exists = $write = false;
			$path = $this->root_path . $dir;
			$this->file_functions->append_slash($path);

			// Try to create the directory if it does not exist
			if (!file_exists($path))
			{
				@mkdir($path, 0777);
			}

			// Now really check
			if (file_exists($path) && is_dir($path))
			{
				if (in_array($dir, $c_all))
				{
					@chmod($path, 0777);
					clearstatcache();
				}
				else
				{
					@chmod($path, 0777);
					clearstatcache();
					//phpbb_chmod($path, CHMOD_ALL);
				}

				$exists = true;

				if (!file_exists($path . 'index.htm') && $this->file_functions->write_file($path . 'index.htm', '', false))
				{
					phpbb_chmod($path . 'index.htm');
					$write = true;
				}

				// Now check if it is writable by storing a simple file
				if (!$write && $this->file_functions->write_file($path . 'test_lock', '', false))
				{
					@unlink($path . 'test_lock');
					$write = true;
				}
			}

			$this->passed = ($exists && $write && $this->passed) ? true : false;

			$exists = ($exists) ? $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_FOUND']) : $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_NOT_FOUND'], 'red');
			$write = ($write) ? ', ' . $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_WRITABLE']) : (($exists) ? ', ' . $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_UNWRITABLE'], 'red') : '');

			$this->gen('result', $this->arcade->root_key($path), $exists . $write);
		}

		if (!empty($requirements['bbcodes']) && count(array_keys($requirements['bbcodes'])))
		{
			// Step 4
			$this->gen('legend_explain', 'INSTALL_ARCADE_BBCODE_REQD');

			$arcade_bbcode = array_keys($requirements['bbcodes']);

			foreach ($arcade_bbcode as $bbcode_tag)
			{
				if ($this->arcade->install('verify')->bbcode_exists($bbcode_tag))
				{
					$result = $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_FOUND']);
				}
				else
				{
					$this->passed = false;

					$result  = $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_NOT_FOUND'], 'red');
					$result .= '<br>' . $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_BBCODE_USAGE'] . ':', 'black');
					$result .= '<textarea readonly="readonly" onclick="this.focus(); this.select();" rows="3" cols="40">' . htmlspecialchars($requirements['bbcodes'][$bbcode_tag]['bbcode_match']) . '</textarea>';
					$result .= '<br><br>' . $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_HTML_REPLACEMENT'] . ':', 'black');
					$result .= '<textarea readonly="readonly" onclick="this.focus(); this.select();" rows="3" cols="40">' . htmlspecialchars($requirements['bbcodes'][$bbcode_tag]['bbcode_tpl']) . '</textarea>';

					$result .= '<br><br>' . $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_BBCODE_HELPLINE'] . ':', 'black');
					$result .= '<textarea readonly="readonly" onclick="this.focus(); this.select();" rows="3" cols="40">' . htmlspecialchars($requirements['bbcodes'][$bbcode_tag]['bbcode_helpline']) . '</textarea>';

					$result .= '<br><br>' . $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_DISPLAY_ON_POSTING'] . ': ', 'black');
					$result .= $this->arcade->color_text(($requirements['bbcodes'][$bbcode_tag]['display_on_posting']) ? $this->user->lang['YES'] : $this->user->lang['NO']);
				}

				$end_bbcode_tag = (substr($bbcode_tag, -1) === '=') ? substr($bbcode_tag, 0, -1) : $bbcode_tag;

				$this->gen('result', '[' . $bbcode_tag . '][/' . $end_bbcode_tag . ']', $result);
			}
		}

		$this->gen('end', $url, 'files');
	}

	public function check_files($url)
	{
		$langs = $this->arcade->install('verify')->installed_languages($this->user->data['user_lang']);

		$this->gen('legend', 'INSTALL_ARCADE_VERIFY_FILES_EXIST');

		$error = false;
		foreach ($this->arcade->install('verify')->data->core_files() as $path => $files)
		{
			if (strpos($path, '{LANG_PATH}') !== false && count($langs))
			{
				foreach ($langs as $lang_id => $lang_path)
				{
					foreach ($this->arcade->install('verify')->data->lang_files() as $lpath => $lfiles)
					{
						foreach ($lfiles as $lfile)
						{
							$e = $this->file_exists(str_replace('{LANG_PATH}', $lang_path, $this->root_path . $lpath . $lfile));

							if (!$error)
							{
								$error = $e;
							}
						}
					}
				}

				$langs = array();
			}

			foreach ($files as $file)
			{
				$e = $this->file_exists(str_replace('{LANG_PATH}', $this->user->data['user_lang'], $this->root_path . $path . $file));

				if (!$error)
				{
					$error = $e;
				}
			}
		}

		if (!$error)
		{
			$this->gen('result', $this->user->lang['INSTALL_ARCADE_VERIFY_FILES_EXIST'], $this->arcade->color_text($this->user->lang['INS_ARCADE_FILES_ALL_EXISTS']));
		}

		$this->gen('end', $url, 'db', 'files');
	}

	public function check_db($url)
	{
		// Step 1
		$this->gen('legend', 'INSTALL_ARCADE_VERIFY_DB_DATA');
		$this->gen('result', 'INSTALL_ARCADE_VERIFY_DB_TABLES', $this->gen('check', 'tables', $this->db_tools->sql_list_tables()));

		// Step 2
		$sql = 'SELECT module_langname FROM ' . MODULES_TABLE;
		$result = $this->db->sql_query($sql);
		$modules = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$langname = current($row);
			$modules[$langname] = $langname;
		}
		$this->db->sql_freeresult($result);

		$this->gen('result', 'INSTALL_ARCADE_VERIFY_DB_UCP_MODULES', $this->gen('check', 'ucp_modules', $modules));
		$this->gen('result', 'INSTALL_ARCADE_VERIFY_DB_MCP_MODULES', $this->gen('check', 'mcp_modules', $modules));
		$this->gen('result', 'INSTALL_ARCADE_VERIFY_DB_ACP_MODULES', $this->gen('check', 'acp_modules', $modules));

		unset($modules);

		// Step 3
		$sql = 'SELECT auth_option FROM ' . ACL_OPTIONS_TABLE;
		$result = $this->db->sql_query($sql);
		$phpbb_options = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$option = current($row);
			$phpbb_options[$option] = $option;
		}
		$this->db->sql_freeresult($result);

		$sql = 'SELECT auth_option FROM ' . ACL_ARCADE_OPTIONS_TABLE;
		$result = $this->db->sql_query($sql);
		$arcade_options = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$option = current($row);
			$arcade_options[$option] = $option;
		}
		$this->db->sql_freeresult($result);

		$this->gen('result', 'INSTALL_ARCADE_VERIFY_DB_PHPBB_PERMISSIONS', $this->gen('check', 'phpbb_permission', $phpbb_options));
		$this->gen('result', 'INSTALL_ARCADE_VERIFY_DB_ARCADE_PERMISSIONS', $this->gen('check', 'arcade_permission', $arcade_options));

		unset($phpbb_options, $arcade_options);

		// Step 4
		$sql = 'SELECT config_name FROM ' . ARCADE_CONFIG_TABLE;
		$result = $this->db->sql_query($sql);
		$configs = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$name = current($row);
			$configs[$name] = $name;
		}
		$this->db->sql_freeresult($result);

		$this->gen('result', 'INSTALL_ARCADE_VERIFY_DB_CONFIGS', $this->gen('check', 'configs', $configs));
		$this->gen('end', $url, 'finish', 'db');

		unset($configs);
	}

	private function file_exists($file_path)
	{
		$result = false;

		if (!file_exists($file_path))
		{
			$this->passed = false;
			$result = $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_NOT_FOUND'], 'red');
		}
		else
		{
			//$result = $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_FOUND']);
		}

		if ($result)
		{
			$this->gen('result', $this->arcade->root_key($file_path), $result);
		}

		return ($result) ? true : false;
	}

	private function gen($type, $v1, $v2 = null, $v3 = null)
	{
		$error = array();
		switch ($type)
		{
			case 'legend':
				$this->template->assign_block_vars('checks', array(
					'S_LEGEND'	=> true,
					'LEGEND'	=> $this->arcade->lang_value($v1)
				));
			break;

			case 'legend_explain':
				$this->template->assign_block_vars('checks', array(
					'S_LEGEND'			=> true,
					'LEGEND'			=> $this->arcade->lang_value($v1),
					'LEGEND_EXPLAIN'	=> $this->arcade->lang_value($v1 . '_EXPLAIN')
				));
			break;

			case 'check':
				foreach ($this->arcade->install('verify')->data->$v1() as $v)
				{
					if ($v1 == 'configs')
					{
						$configs = $v;
						$v = array_shift($v);
					}

					if (!isset($v2[$v]))
					{
						$this->passed = false;
						$error[] = $this->arcade->lang_value($v);

						if (defined('PHPBB_ARCADE_AUTO_INSTALL_REPAIR'))
						{
							switch ($v1)
							{
								case 'tables':
									if (!empty($this->arcade->install('verify')->schema[$v]))
									{
										$this->redirect = true;
										$this->db_tools->sql_create_table($v, $this->arcade->install('verify')->schema[$v]);
									}
								break;

								case 'phpbb_permission':
								case 'arcade_permission':
									$this->redirect = true;
									$is_global = (in_array(substr($v, 0, 2), array('a_', 'm_', 'u_'))) ? 1 : 0;

									$sql_ary = array(
										'auth_option'	=> $v,
										'is_global'		=> $is_global,
										'is_local'		=> ($is_global) ? 0 : 1,
										'founder_only'	=> 0
									);

									$this->db->sql_query('INSERT INTO ' . (($v1 == 'phpbb_permission') ? ACL_OPTIONS_TABLE : ACL_ARCADE_OPTIONS_TABLE) . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
								break;

								case 'configs':
										$this->redirect = true;
										$config_name = array_shift($configs);
										$config_value = array_shift($configs);
										$use_cache = array_shift($configs);

										$this->arcade_config->set($config_name, $config_value, $use_cache);
								break;
							}
						}
					}
				}

				return (count($error)) ? $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_NOT_FOUND'], 'red') . '<br>' . $this->arcade->color_text(implode('<br>', $error), 'black') : $this->arcade->color_text($this->user->lang['INSTALL_ARCADE_ALL_FOUND']);
			break;

			case 'result':
				$this->template->assign_block_vars('checks', array(
					'TITLE'		=> $this->arcade->lang_value($v1),
					'RESULT'	=> $v2,

					'S_EXPLAIN'	=> false,
					'S_LEGEND'	=> false
				));
			break;

			case 'result_explain':
				$this->template->assign_block_vars('checks', array(
					'TITLE'			=> ($v3 !== null) ? sprintf($this->user->lang[$v1], $v3) : $this->arcade->lang_value($v1),
					'TITLE_EXPLAIN'	=> ($v3 !== null) ? sprintf($this->user->lang[$v1 . '_EXPLAIN'], $v3) : $this->arcade->lang_value($v1 . '_EXPLAIN'),
					'RESULT'		=> $v2,

					'S_EXPLAIN'		=> true,
					'S_LEGEND'		=> false
				));
			break;

			case 'end':
				if (!$this->passed && $this->redirect)
				{
					redirect(($v3 !== null) ? "{$v1}&amp;action={$v3}" : $v1);
				}

				$this->template->assign_vars(array(
					'L_SUBMIT'	=> $this->user->lang['INSTALL_ARCADE_' . (($this->passed) ? 'NEXT_STEP' : 'TEST_AGAIN')],
					'U_ACTION'	=> ($this->passed) ? "{$v1}&amp;action={$v2}" : (($v3 !== null) ? "{$v1}&amp;action={$v3}" : $v1)
				));
			break;
		}
	}
}
