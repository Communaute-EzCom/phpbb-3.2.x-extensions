<?php
/**
*
* @package phpBB Arcade
* @version $Id: admin.php 2136 2019-01-05 19:42:24Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class admin extends arcade
{
	public $install;
	protected $phpbb_dispatcher, $container, $path_helper, $ext_manager, $db, $cache, $config, $auth, $request, $user, $template, $arcade_cache, $arcade_config, $arcade_auth, $file_functions, $root_path, $php_ext, $admin_path;

	public function __construct($phpbb_dispatcher, $container, $path_helper, $ext_manager, $db, $cache, $config, $auth, $request, $user, $template, $arcade_cache, $arcade_config, $arcade_auth, $file_functions, $root_path, $php_ext, $adm_relative_path)
	{
		$this->phpbb_dispatcher = $phpbb_dispatcher;
		$this->container = $container;
		$this->path_helper = $path_helper;
		$this->ext_manager = $ext_manager;
		$this->db = $db;
		$this->cache = $cache;
		$this->config = $config;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->file_functions = $file_functions;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->admin_path = $root_path . $adm_relative_path;
	}

	public function install($mode = false)
	{
		if (!isset($this->install))
		{
			$this->install = $this->container('install')->main($mode);
		}

		return $this->install;
	}

	function color_text($text, $color = '')
	{
		if ($color == 'black')
		{
			$text = '<span style="font-weight: normal; color:#000;">' . $text . '</span>';
		}
		else
		{
			$text = '<strong style="color:#' . (($color == 'red') ? 'BC2A4D' : '228822') . '">' . $text . '</strong>';
		}

		return $text;
	}

	/**
	* Set values for a game...
	*/
	public function set_game_data($game_id, $config_name, $config_value, $cat_id = false, $old_cat_id = false, $old_game_scoretype = false)
	{
		$this->game()->install_file->validate_db_data($config_value, $config_name);

		if ($config_name == 'game_name')
		{
			$sql_ary = array(
				$config_name		=> $config_value,
				'game_name_clean'	=> utf8_clean_string($config_value),
			);

			$sql = 'UPDATE ' . ARCADE_GAMES_TABLE. '
					SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
					WHERE game_id = ' . (int) $game_id;
			$this->db->sql_query($sql);
		}
		else
		{
			$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
					SET ' . $this->db->sql_escape($config_name) . " = '" . $this->db->sql_escape($config_value) . "'
					WHERE game_id = " . (int) $game_id;
			$this->db->sql_query($sql);
		}

		if ($cat_id && $old_cat_id && ($cat_id != $old_cat_id))
		{
			$this->set_last_play(array($cat_id, $old_cat_id));
			$this->sync('category', array($cat_id, $old_cat_id));
		}

		if ($config_name == 'game_scoretype' && $config_value != $old_game_scoretype)
		{
			$game_data = array(
				'game_id'			=> $game_id,
				'game_scoretype'	=> $config_value,
			);

			$this->update_highscore($game_data);
		}
	}

	/**
	* Adds game to database. Requires you to provide the game_scorevar and cat_id.
	* The rest of the info is gathered from the install file.
	*/
	public function add_game($game_filename, $cat_id)
	{
		$dir = $this->root_path . $this->arcade_config['game_path'];
		$install_file = $dir . $game_filename . '/' . $game_filename . '.' . $this->php_ext;

		if (!($game_data = $this->game()->install_file->data($dir, $game_filename, $install_file)))
		{
			return false;
		}

		$this->game()->install_file->validate_db_data($game_data);

		$game_name = $game_data['game_name'];

		$games_name = array();
		$sql = 'SELECT game_name, game_swf
				FROM ' . ARCADE_GAMES_TABLE . '
				ORDER BY game_name';
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$games_name[$row['game_name']] = $row['game_swf'];
		}
		$this->db->sql_freeresult($result);

		// We have same duplicate gamename
		if (isset($games_name[$game_name]))
		{
			if ($game_data['game_swf'] == $games_name[$game_name])
			{
				return false;
			}

			$duplicate_games = 0;
			$temp_name = $game_name;
			while (isset($games_name[$game_name]))
			{
				$duplicate_games++;
				$game_name = $temp_name . ' (' . $duplicate_games . ')';
			}
		}

		$sql = 'SELECT MAX(game_order) AS max_order
				FROM ' . ARCADE_GAMES_TABLE;
		$result = $this->db->sql_query($sql);
		$max_order = (int) $this->db->sql_fetchfield('max_order');
		$this->db->sql_freeresult($result);

		$next_order = $max_order + 10;

		$game_insert = array(
			'game_order'		=> (int) $next_order,
			'game_image'		=> (string) $game_data['game_image'],
			'game_desc'			=> $game_data['game_desc'],
			'game_control'		=> (int) $game_data['game_control'],
			'game_control_desc'	=> $game_data['game_control_desc'],
			'game_highscore'	=> 0,
			'game_highdate'		=> 0,
			'game_highuser'		=> 0,
			'game_name'			=> $game_name,
			'game_name_clean'	=> utf8_clean_string($game_name),
			'game_swf'			=> (string) $game_data['game_swf'],
			'game_width'		=> (int) $game_data['game_width'],
			'game_height'		=> (int) $game_data['game_height'],
			'game_installdate'	=> time(),
			'game_filesize'		=> (int) $this->file_functions->filesize(array_filter(array($this->set_path((string) $game_data['game_swf'], 'path'), $this->game()->file_path((string) $game_data['game_swf'])))),
			'game_scorevar'		=> (string) $game_data['game_scorevar'],
			'game_scoretype'	=> (int) $game_data['game_scoretype'],
			'game_type'			=> (int) $game_data['game_type'],
			'game_save_type'	=> (int) $game_data['game_save_type'],
			'cat_id'			=> (int) $cat_id,
			'game_jackpot'		=> (float) $this->arcade_config['jackpot_minimum'],
			'privacy_desc'		=> $game_data['privacy_desc'],
			'privacy_link'		=> $game_data['privacy_link']
		);

		$this->db->sql_query('INSERT INTO ' . ARCADE_GAMES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $game_insert));

		$game_insert['game_id'] = $this->db->sql_nextid();

		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
				SET cat_games = cat_games + 1,
				cat_last_game_installdate = ' . time() . '
				WHERE cat_id = ' . (int) $cat_id;
		$this->db->sql_query($sql);

		return $game_insert;
	}

	/**
	* Delete the files of a game from the server,
	* this includes any extra files and/or folders
	*/
	public function delete_files($game_data, $game_ids = false)
	{
		$errors = array();

		// Check permissions dirs writable
		$check_dirs = array('games/', 'arcade/gamedata/', $this->arcade_config['game_path']);

		foreach ($check_dirs as $dir)
		{
			$path = $this->root_path . $dir;

			if (!phpbb_is_writable($path))
			{
				$errors[] = sprintf($this->user->lang['ARCADE_ERROR_DIR_WRITABLE'], $dir);
			}
		}

		if (!count($errors) && empty($game_data))
		{
			$game_ids = array_map('intval', (is_array($game_ids)) ? array_unique($game_ids) : array($game_ids));

			if (!count($game_ids) || ($game_data = $this->get()->game_data($game_ids)) === false)
			{
				$errors[] = $this->user->lang['NO_GAME_ID'];
			}
		}

		if (!count($errors))
		{
			foreach ($game_data as $key => $value)
			{
				$game_swf = $game_data[$key]['game_swf'];

				if (empty($game_swf))
				{
					if (empty($game_data[$key]['game_scorevar']))
					{
						continue;
					}

					$game_swf = $game_data[$key]['game_scorevar'] . '.swf';
				}

				$file_list = array();
				// Paths for the main and extra game folders
				$game_dir		= $this->set_path($game_swf, 'path');
				$gamedata_dir	= $this->game()->file_path($game_swf);

				// First get file listing for main game folder
				if (file_exists($game_dir))
				{
					$file_list = array_merge($file_list, $this->file_functions->filelist($game_dir, '', false, true));
				}

				// Then get file listing for extra folder
				if ($gamedata_dir)
				{
					$file_list = array_merge($file_list, $this->file_functions->filelist($gamedata_dir, '', false, true));
				}

				$file_list = array_filter($file_list);

				if (count($file_list))
				{
					// Now we also check the directory/file permission of each item in the list.
					$this->check_file_writable($file_list, $errors);

					// If there are no errors we finally remove the files.
					if (!count($errors))
					{
						$this->file_functions->delete_list($file_list);
					}

					unset($file_list);
				}
			}
		}

		return $errors;
	}

	/**
	* Check game_extra files and/or folders
	* to make sure they are writable
	*/
	public function check_file_writable($path, &$errors)
	{
		if (!count($path))
		{
			return;
		}

		foreach ($path as $file)
		{
			if (!phpbb_is_writable($file))
			{
				$errors[] = sprintf($this->user->lang['ARCADE_DELETE_FILES_ERROR_' . ((is_dir($file)) ? 'DIR' : 'FILE')], $this->root_key($file));
			}
		}
	}

	public function old_delete_games($method, $games_swf = '', $delete_reason = '')
	{
		if ($games_swf && !is_array($games_swf))
		{
			$games_swf = array_filter(array($games_swf));

			if (!count($games_swf))
			{
				return $games_swf;
			}
		}

		switch ($method)
		{
			case 'load':
				$sql = 'SELECT game_swf, reason, uninstalldate FROM ' . ARCADE_DELETE_GAMES_TABLE;

				if ($games_swf)
				{
					$sql .= ' WHERE ' . $this->db->sql_in_set('game_swf', $games_swf);
				}

				$result = $this->db->sql_query($sql);
				$swf = array();
				while ($row = $this->db->sql_fetchrow($result))
				{
					$swf[$row['game_swf']] = array(
						'reason'	=> $row['reason'],
						'date'		=> $row['uninstalldate']
					);
				}
				$this->db->sql_freeresult($result);

				return $swf;
			break;

			case 'create':
				foreach ($games_swf as $game_swf)
				{
					$game_swf = $this->file_functions->remove_extension($game_swf);
					$sql_ary = array(
						'game_swf'		=> $game_swf,
						'reason'		=> $delete_reason,
						'uninstalldate'	=> time()
					);

					$this->db->sql_return_on_error(true);
					$this->db->sql_query($sql = 'INSERT INTO ' . ARCADE_DELETE_GAMES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
					$this->db->sql_return_on_error(false);
				}
			break;

			case 'delete':
				$sql = 'DELETE FROM ' . ARCADE_DELETE_GAMES_TABLE . '
						WHERE ' . $this->db->sql_in_set('game_swf', $games_swf);
				$this->db->sql_query($sql);
			break;
		}
	}

	/**
	* Delete a game from the db and remove
	* its data from all relevant tables
	*/
	public function delete_game($game_ids, &$errors, $delete_reason, $resync = true)
	{
		$game_ids = array_map('intval', ((is_array($game_ids)) ? array_unique($game_ids) : array($game_ids)));

		if (!count($game_ids) || ($game_data = $this->get()->game_data($game_ids)) === false)
		{
			$errors[] = $this->user->lang['NO_GAME_ID'];
		}

		if (count($errors))
		{
			return false;
		}

		if ($this->is_post_empty('delete_files') || $this->is_post_empty('sub_delete_files'))
		{
			$errors = $this->delete_files($game_data, $game_ids);
			// Since there are permission errors we don't delete files or db entries.
			// We will display a message to the user. They can either fix the permission errors
			// or not check off the option to remove the files.
			if (count($errors))
			{
				array_unshift($errors, $this->user->lang['ARCADE_DELETE_FILES_ERROR_GAME']);
				return false;
			}
		}

		$delete_tours = $cat_ids = $topic_ids = $games_swf = array();
		foreach ($game_data as $key => $data)
		{
			$cat_ids[]	 = (int)  $data['cat_id'];
			$topic_ids[] = (int) $data['topic_id'];

			if (!empty($data['game_swf']))
			{
				$games_swf[] = $data['game_swf'];
			}
		}

		$sql = 'SELECT tour_id, topic_id, tour_games
				FROM ' . ARCADE_TOUR_TABLE;
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$tgids1 = explode(',', $row['tour_games']);
			$tgids2 = array_diff($tgids1, $game_ids);

			if (count($tgids2) < 3)
			{
				$delete_tours[]	= (int) $row['tour_id'];
				$topic_ids[]	= (int) $row['topic_id'];
			}
			else if (count($tgids1) != count($tgids2))
			{
				$sql = 'UPDATE ' . ARCADE_TOUR_TABLE . "
						SET tour_games = '" . $this->db->sql_escape(implode(',', $tgids2)) . "'
						WHERE tour_id = " . (int) $row['tour_id'];
				$this->db->sql_query($sql);
			}
		}
		$this->db->sql_freeresult($result);

		if (count($delete_tours))
		{
			$this->delete_tour_data($delete_tours);
		}

		$cat_ids	= array_unique($cat_ids);
		$topic_ids	= array_unique($topic_ids);
		$games_swf	= array_unique($games_swf);

		if (count($topic_ids))
		{
			$this->phpbb()->delete_topics($topic_ids);
		}

		$tables = array(ARCADE_DOWNLOAD_TABLE, ARCADE_LOGS_TABLE, ARCADE_PLAYS_TABLE, ARCADE_SCORES_TABLE, ARCADE_GAMES_TABLE, ARCADE_FAVS_TABLE, ARCADE_RATING_TABLE, ARCADE_REPORTS_TABLE, ARCADE_SESSIONS_TABLE, ARCADE_SUPER_SCORES_TABLE, ARCADE_CHALLENGE_TABLE, ARCADE_CHALLENGE_CHAMP_TABLE, ARCADE_TOUR_CHAMP_TABLE, ARCADE_TOUR_WINS_TABLE);

		foreach ($tables as $table)
		{
			$sql = "DELETE FROM $table
					WHERE " . $this->db->sql_in_set('game_id', $game_ids);
			$this->db->sql_query($sql);
		}

		unset($tables);

		if ($resync)
		{
			$this->sync('total_data', 'all');
			$this->sync('users_total_data');
			$this->set_last_play($cat_ids);
			$this->sync('category', $cat_ids);
		}

		if (count($games_swf))
		{
			$this->old_delete_games('create', $games_swf, $delete_reason);
		}

		$this->cache_purge();

		return $game_data;
	}

	/**
	* Delete a user from the arcade db and remove
	* its data from all relevant tables
	*/
	public function delete_user($user_ids)
	{
		if (!$user_ids)
		{
			return;
		}

		if (!is_array($user_ids))
		{
			$user_ids = array($user_ids);
		}

		$tables = array(ACL_ARCADE_USERS_TABLE, ARCADE_USERS_BANNED_TABLE, ARCADE_USERS_TABLE, ARCADE_SESSIONS_TABLE, ARCADE_REPORTS_TABLE, ARCADE_LOGS_TABLE, ARCADE_ACCESS_TABLE, ARCADE_TOUR_CHAMP_TABLE, ARCADE_TOUR_WINS_TABLE);

		foreach ($tables as $table_name)
		{
			$sql = 'DELETE FROM ' . $table_name . '
					WHERE ' . $this->db->sql_in_set('user_id', $user_ids);
			$this->db->sql_query($sql);
		}

		$sql = 'SELECT announce_id FROM ' . ARCADE_ANNOUNCE_DATA_TABLE . '
				WHERE ' . $this->db->sql_in_set('user_id', $user_ids);
		$result = $this->db->sql_query($sql);
		$announcement = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$sql_ary = array(
				'user_id'		=> (in_array($this->user->data['user_id'], $user_ids)) ? 0 : $this->user->data['user_id'],
				'username'		=> (in_array($this->user->data['user_id'], $user_ids)) ? '' : $this->user->data['username'],
				'user_colour'	=> (in_array($this->user->data['user_id'], $user_ids)) ? '' : $this->user->data['user_colour']
			);

			$sql = 'UPDATE ' . ARCADE_ANNOUNCE_DATA_TABLE . '
					SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
					WHERE announce_id = ' . (int) $row['announce_id'];
			$this->db->sql_query($sql);
		}
		$this->db->sql_freeresult($result);

		$sql = 'SELECT tour_id, topic_id FROM ' . ARCADE_TOUR_TABLE . '
				WHERE ' . $this->db->sql_in_set('tour_wins', $user_ids) . '
				 AND tour_status = ' . ARCADE_END_TOUR;
		$result = $this->db->sql_query($sql);
		$delete_tours = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$delete_tours[(int) $row['tour_id']] = (int) $row['topic_id'];
		}
		$this->db->sql_freeresult($result);

		if (count($delete_tours))
		{
			$this->delete_tour_data(array_keys($delete_tours), array_values($delete_tours));
		}

		if ($this->arcade_config['announce_author'])
		{
			$sql = 'SELECT username
					FROM ' . USERS_TABLE . '
					WHERE ' . $this->db->sql_in_set('user_id', $user_ids);
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				if ($this->arcade_config['announce_author'] == $row['username'])
				{
					$this->arcade_config->set('announce_author', '');
					break;
				}
			}
			$this->db->sql_freeresult($result);
		}

		if (in_array($this->arcade_config['shout_user_id'], $user_ids))
		{
			$this->arcade_config->set('shout_user_id', 0);
		}

		$this->reset('user', $user_ids);
		$this->reset('challenge', $user_ids);
		$this->sync('total_data', 'all');
		$this->cache_purge('user');
	}

	public function delete_tour_data($tour_ids, $topic_ids = false)
	{
		$tour_ids = array_map('intval', (is_array($tour_ids)) ? array_unique($tour_ids) : array($tour_ids));

		if (count($tour_ids))
		{
			if ($topic_ids !== false)
			{
				$this->phpbb()->delete_topics($topic_ids);
			}

			$tables = array(ARCADE_TOUR_TABLE, ARCADE_TOUR_CHAMP_TABLE, ARCADE_TOUR_WINS_TABLE);

			foreach ($tables as $table_name)
			{
				$sql = "DELETE FROM $table_name
						WHERE " . $this->db->sql_in_set('tour_id', $tour_ids);
				$this->db->sql_query($sql);
			}
		}
	}

	/**
	* Toggle report opened or closed
	*/
	public function report_toggle($action, $report_id)
	{
		$sql = 'UPDATE ' . ARCADE_REPORTS_TABLE . '
				SET report_closed = ' . (($action == 'close') ? ARCADE_REPORT_CLOSE : ARCADE_REPORT_OPEN) . '
				WHERE report_id = ' . (int) $report_id;
		$this->db->sql_query($sql);

		if ($this->db->sql_affectedrows())
		{
			$this->arcade_config->increment('reports_open', ($action == 'close') ? -1 : 1);
		}
	}

	/**
	* All-encompasing reset function
	*
	* Modes:
	* - user			Reset users data, must have passed $user_ids
	* - user_scores		Reset users score data, must have passed $user_ids
	* - super_record	Reset users super score data, must have passed $user_ids
	* - jackpot_min_max	Reset games to jackpot minimum that are less than minimum and jackpot maximum that are higher than maximum.
	* - challenge		Reset users challenge data, must have passed $user_ids
	*/
	public function reset($mode, $user_ids = false)
	{
		if (!$user_ids && $mode != 'jackpot_min_max')
		{
			return false;
		}

		if ($user_ids && !is_array($user_ids))
		{
			$user_ids = array($user_ids);
		}

		switch ($mode)
		{
			case 'user':
				$sql = 'SELECT game_id FROM ' . ARCADE_RATING_TABLE . '
						WHERE ' . $this->db->sql_in_set('user_id', $user_ids);
				$result = $this->db->sql_query($sql);
				$resync_ratings = array();
				while ($row = $this->db->sql_fetchrow($result))
				{
					$resync_ratings[] = $row['game_id'];
				}
				$this->db->sql_freeresult($result);

				$tables = array(ARCADE_FAVS_TABLE, ARCADE_RATING_TABLE, ARCADE_DOWNLOAD_TABLE, ARCADE_SUPER_SCORES_TABLE);

				foreach ($tables as $table_name)
				{
					$sql = 'DELETE FROM ' . $table_name . '
							WHERE ' . $this->db->sql_in_set('user_id', $user_ids);
					$this->db->sql_query($sql);
				}

				if (count($resync_ratings))
				{
					$this->sync('rating', $resync_ratings);
				}
			case 'user_scores':
				$resync_cats = $resync_games = array();

				$sql_array = array(
					'SELECT'	=> 'g.game_id, g.cat_id, g.game_scoretype, g.game_highuser',
					'FROM'		=> array(
						ARCADE_GAMES_TABLE	=> 'g',
					),
					'LEFT_JOIN'	=> array(
						array(
							'FROM'	=> array(ARCADE_SCORES_TABLE => 's'),
							'ON'	=> 'g.game_id = s.game_id'
						)
					),
					'WHERE' 	=> $this->db->sql_in_set('s.user_id', $user_ids),
				);
				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$resync_cats[$row['cat_id']] = 1;

					$resync_games[$row['game_id']] = array(
						'game_id'			=> $row['game_id'],
						'game_scoretype'	=> $row['game_scoretype'],
						'game_highuser'		=> $row['game_highuser'],
					);
				}
				$this->db->sql_freeresult($result);

				$tables = array(ARCADE_SCORES_TABLE);

				if (($mode != 'user_scores') || ($mode == 'user_scores' && !$this->request->variable('retain_plays', false)))
				{
					$tables[] = ARCADE_PLAYS_TABLE;

					$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
							SET user_arcade_last_play = 0
							WHERE ' . $this->db->sql_in_set('user_id', $user_ids);
					$this->db->sql_query($sql);
				}

				foreach ($tables as $table_name)
				{
					$sql = 'DELETE FROM ' . $table_name . '
							WHERE ' . $this->db->sql_in_set('user_id', $user_ids);
					$this->db->sql_query($sql);
				}

				if (count($resync_cats))
				{
					$this->set_last_play(array_keys($resync_cats));
					$this->sync('category', array_keys($resync_cats));
				}

				if (count($resync_games))
				{
					$this->sync('game', array_keys($resync_games));

					foreach ($resync_games as $key => $value)
					{
						if (in_array($value['game_highuser'], $user_ids))
						{
							$this->update_highscore($value);
						}
					}
				}

				$this->sync('users_total_data');
			break;

			case 'super_record':
				$sql = 'SELECT s.game_id FROM ' . ARCADE_SUPER_SCORES_TABLE . ' s, ' . ARCADE_GAMES_TABLE . ' g
						WHERE ' . $this->db->sql_in_set('s.user_id', $user_ids) . '
						AND s.game_id = g.game_id
						AND s.user_id <> g.game_highuser';
				$result = $this->db->sql_query($sql);
				$delete_ids = array();
				while ($row = $this->db->sql_fetchrow($result))
				{
					$delete_ids[] = $row['game_id'];
				}
				$this->db->sql_freeresult($result);

				if (count($delete_ids))
				{
					$sql = 'DELETE FROM ' . ARCADE_SUPER_SCORES_TABLE . '
							WHERE ' . $this->db->sql_in_set('game_id', array_map('intval', $delete_ids));
					$this->db->sql_query($sql);

					$this->sync('super_champ', $delete_ids);
					$this->sync('users_total_data');
				}
			break;

			case 'jackpot_min_max':
				$game_ids_min = $game_ids_max = array();
				$sql_array = array(
					'SELECT'	=> 'g.game_id, g.game_jackpot',
					'FROM'		=> array(
						ARCADE_GAMES_TABLE	=> 'g',
					),
					'WHERE'		=> 'g.game_jackpot < ' . (float) $this->arcade_config['jackpot_minimum'] . ' OR g.game_jackpot > ' . (float) $this->arcade_config['jackpot_maximum'],
					'ORDER_BY'		=> 'g.game_id ASC',
				);

				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					if ($row['game_jackpot'] < $this->arcade_config['jackpot_minimum'])
					{
						$game_ids_min[] = $row['game_id'];
					}

					if ($row['game_jackpot'] > $this->arcade_config['jackpot_maximum'])
					{
						$game_ids_max[] = $row['game_id'];
					}
				}
				$this->db->sql_freeresult($result);

				if (count($game_ids_min))
				{
					$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
							SET game_jackpot = ' . (float) $this->arcade_config['jackpot_minimum'] . '
							WHERE ' . $this->db->sql_in_set('game_id', $game_ids_min);
					$this->db->sql_query($sql);
				}

				if (count($game_ids_max))
				{
					$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
							SET game_jackpot = ' . (float) $this->arcade_config['jackpot_maximum'] . '
							WHERE ' . $this->db->sql_in_set('game_id', $game_ids_max);
					$this->db->sql_query($sql);
				}
			break;

			case 'challenge':
				$sql = 'DELETE FROM ' . ARCADE_CHALLENGE_TABLE . '
						WHERE ' . $this->db->sql_in_set('challenger_id', $user_ids) . ' OR ' . $this->db->sql_in_set('opponent_id', $user_ids);
				$this->db->sql_query($sql);

				$sql = 'DELETE FROM ' . ARCADE_CHALLENGE_CHAMP_TABLE . '
						WHERE ' . $this->db->sql_in_set('champ_challenger_id', $user_ids) . ' OR ' . $this->db->sql_in_set('champ_opponent_id', $user_ids);
				$this->db->sql_query($sql);
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}
	}

	/**
	* Move game to new category
	*/
	public function move_game($game_id, $old_cat_id, $new_cat_id)
	{
		$errors = array();
		if (empty($game_id))
		{
			$errors[] = $this->user->lang['NO_GAME_IDS'];
		}

		if (!$old_cat_id || !$new_cat_id)
		{
			$errors[] = $this->user->lang['NO_CAT_ID'];
		}

		if ($old_cat_id == $new_cat_id)
		{
			$errors[] = $this->user->lang['MOVE_SAME_CAT_ID'];
		}

		if (count($errors))
		{
			return $errors;
		}

		if (!is_array($game_id))
		{
			$game_id = array((int) $game_id);
		}

		$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
				SET cat_id = ' . (int) $new_cat_id . '
				WHERE ' . $this->db->sql_in_set('game_id', $game_id);
		$this->db->sql_query($sql);

		$this->set_last_play($new_cat_id);
		$this->sync('category', $new_cat_id);

		$this->set_last_play($old_cat_id);
		$this->sync('category', $old_cat_id);

		return $errors;
	}

	/**
	* Reset game data
	*/
	public function reset_game($action, $game_id, $cat_id)
	{
		$errors = array();
		if (!$game_id)
		{
			$errors[] = $this->user->lang['NO_GAME_ID'];
		}

		if (!$cat_id)
		{
			$errors[] = $this->user->lang['NO_CAT_ID'];
		}

		if (count($errors))
		{
			return $errors;
		}

		if (!is_array($game_id))
		{
			$game_id = array((int) $game_id);
		}

		$game_ids = array_map('intval', $game_id);

		$retain_plays			= $this->request->variable('retain_plays', false);
		$retain_super_champion	= $this->request->variable('retain_super_champion', false);

		if (!$retain_plays)
		{
			$sql = 'DELETE FROM ' . ARCADE_PLAYS_TABLE . '
					WHERE ' . $this->db->sql_in_set('game_id', $game_ids);
			$this->db->sql_query($sql);
		}

		$sql = 'DELETE FROM ' . ARCADE_SCORES_TABLE . '
				WHERE ' . $this->db->sql_in_set('game_id', $game_ids);
		$this->db->sql_query($sql);

		$sql_ary = array(
			'game_highscore'=> 0,
			'game_highuser'	=> 0,
			'game_highdate'	=> 0
		);

		if (!$retain_plays)
		{
			$sql_ary['game_plays'] = 0;
		}

		switch ($action)
		{
			case 'reset_game_install_date':
			case 'reset_install_date_marked':
				$retain_super_champion = false;
				$sql_ary['game_installdate'] = time();
			case 'reset_marked':
				$action = 'reset_marked';

				if (!$retain_super_champion)
				{
					$sql = 'DELETE FROM ' . ARCADE_SUPER_SCORES_TABLE . '
							WHERE ' . $this->db->sql_in_set('game_id', $game_ids);
					$this->db->sql_query($sql);
				}
			break;
		}

		if ($action == 'reset_marked')
		{
			$sql = 'DELETE FROM ' . ARCADE_RATING_TABLE . '
					WHERE ' . $this->db->sql_in_set('game_id', $game_ids);
			$this->db->sql_query($sql);

			$sql = 'DELETE FROM ' . ARCADE_DOWNLOAD_TABLE . '
					WHERE ' . $this->db->sql_in_set('game_id', $game_ids);
			$this->db->sql_query($sql);

			$sql_ary += array(
				'game_votetotal'		=> 0,
				'game_votesum'			=> 0,
				'game_download_total'	=> 0,
				'game_reward'			=> 0,
				'game_jackpot'			=> (float) $this->arcade_config['jackpot_minimum'],
			);
		}

		$sql = 'UPDATE ' . ARCADE_GAMES_TABLE. '
				SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
				WHERE ' . $this->db->sql_in_set('game_id', $game_ids);
		$this->db->sql_query($sql);

		$this->set_last_play($cat_id);
		$this->sync('category', $cat_id);
		$this->sync('users_total_data');

		return $errors;
	}

	/**
	* Copies permissions from one category to others
	*
	* @param int	$src_cat_id			The source category we want to copy permissions from
	* @param array	$dest_cat_ids		The destination category/categories we want to copy to
	* @param bool	$clear_dest_perms	True if destination permissions should be deleted
	* @param bool	$add_log			True if log entry should be added
	*
	* @return bool						False on error
	*
	* @author bantu
	*/
	public function copy_category_permissions($src_cat_id, $dest_cat_ids, $clear_dest_perms = true, $add_log = true)
	{
		// Only one cat id specified
		if (!is_array($dest_cat_ids))
		{
			$dest_cat_ids = array($dest_cat_ids);
		}

		// Make sure cat ids are integers
		$src_cat_id = (int) $src_cat_id;
		$dest_cat_ids = array_map('intval', $dest_cat_ids);

		// No source category or no destination categories specified
		if (empty($src_cat_id) || empty($dest_cat_ids))
		{
			return false;
		}

		// Check if source cat exists
		$sql = 'SELECT cat_name
				FROM ' . ARCADE_CATS_TABLE . '
				WHERE cat_id = ' . $src_cat_id;
		$result = $this->db->sql_query($sql);
		$src_cat_name = $this->db->sql_fetchfield('cat_name');
		$this->db->sql_freeresult($result);

		// Source cat doesn't exist
		if (empty($src_cat_name))
		{
			return false;
		}

		// Check if destination cats exists
		$sql = 'SELECT cat_id, cat_name
				FROM ' . ARCADE_CATS_TABLE . '
				WHERE ' . $this->db->sql_in_set('cat_id', $dest_cat_ids);
		$result = $this->db->sql_query($sql);

		$dest_cat_ids = $dest_cat_names = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$dest_cat_ids[]		= (int) $row['cat_id'];
			$dest_cat_names[]	= $row['cat_name'];
		}
		$this->db->sql_freeresult($result);

		// No destination cat exists
		if (empty($dest_cat_ids))
		{
			return false;
		}

		// Rowsets we're going to insert
		$users_sql_ary = $groups_sql_ary = array();

		// Query acl users table for source cat data
		$sql = 'SELECT user_id, auth_option_id, auth_role_id, auth_setting
				FROM ' . ACL_ARCADE_USERS_TABLE . '
				WHERE cat_id = ' . $src_cat_id;
		$result = $this->db->sql_query($sql);

		while ($row = $this->db->sql_fetchrow($result))
		{
			$row = array(
				'user_id'			=> (int) $row['user_id'],
				'auth_option_id'	=> (int) $row['auth_option_id'],
				'auth_role_id'		=> (int) $row['auth_role_id'],
				'auth_setting'		=> (int) $row['auth_setting']
			);

			foreach ($dest_cat_ids as $dest_cat_id)
			{
				$users_sql_ary[] = $row + array('cat_id' => $dest_cat_id);
			}
		}
		$this->db->sql_freeresult($result);

		// Query acl groups table for source cat data
		$sql = 'SELECT group_id, auth_option_id, auth_role_id, auth_setting
				FROM ' . ACL_ARCADE_GROUPS_TABLE . '
				WHERE cat_id = ' . $src_cat_id;
		$result = $this->db->sql_query($sql);

		while ($row = $this->db->sql_fetchrow($result))
		{
			$row = array(
				'group_id'			=> (int) $row['group_id'],
				'auth_option_id'	=> (int) $row['auth_option_id'],
				'auth_role_id'		=> (int) $row['auth_role_id'],
				'auth_setting'		=> (int) $row['auth_setting']
			);

			foreach ($dest_cat_ids as $dest_cat_id)
			{
				$groups_sql_ary[] = $row + array('cat_id' => $dest_cat_id);
			}
		}
		$this->db->sql_freeresult($result);

		$this->db->sql_transaction('begin');

		// Clear current permissions of destination cats
		if ($clear_dest_perms)
		{
			$sql = 'DELETE FROM ' . ACL_ARCADE_USERS_TABLE . '
					WHERE ' . $this->db->sql_in_set('cat_id', $dest_cat_ids);
			$this->db->sql_query($sql);

			$sql = 'DELETE FROM ' . ACL_ARCADE_GROUPS_TABLE . '
					WHERE ' . $this->db->sql_in_set('cat_id', $dest_cat_ids);
			$this->db->sql_query($sql);
		}

		$this->db->sql_multi_insert(ACL_ARCADE_USERS_TABLE, $users_sql_ary);
		$this->db->sql_multi_insert(ACL_ARCADE_GROUPS_TABLE, $groups_sql_ary);

		if ($add_log)
		{
			$this->add_log('admin', 'LOG_ARCADE_CATEGORY_COPIED_PERMISSIONS', $src_cat_name, implode(', ', $dest_cat_names));
		}

		$this->db->sql_transaction('commit');

		return true;
	}

	/**
	* Pulls the arcade download data from a remote site
	* This expects the data to be gzcompressed, and serialized
	* it is then cached locally
	*/
	public function get_remote_data($url, $timeout = 10)
	{
		$error = false;
		$md5_url = md5($url);

		if (($list = $this->cache->get('_arcade_dl_' . $md5_url)) === false)
		{
			if (function_exists('curl_init'))
			{
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
				$list = curl_exec($ch);

				if ($errno = curl_errno($ch)) {
					$error = "cURL error ({$errno}): " . curl_error($ch);
				}

				curl_close($ch);
			}
			else if (@ini_get('allow_url_fopen'))
			{
				$context = stream_context_create(array(
					'ssl'=>array(
						'verify_peer'		=>false,
						'verify_peer_name'	=>false
					)
				));

				$list = file_get_contents($url, false, $context);
			}

			$list = @gzuncompress($list);
			$list = (is_string($list) && (preg_match("/^[adobis]:[0-9]+:.*[;}]/si", $list))) ? unserialize($list) : false;

			if (is_array($list) && count($list))
			{
				$list['md5_url'] = $md5_url;
				$this->cache->put('_arcade_dl_' . $md5_url, $list, $this->hour($this->arcade_config['cache_time']));
			}
		}

		if ($error)
		{
			$list['error'] = $error;
		}

		return $list;
	}

	/**
	* Purges the cached arcade download list
	*/
	public function purge_download_cache()
	{
		// Purge all arcade acp download list cache files
		if ($files = scandir($this->cache->cache_dir))
		{
			foreach ($files as $file)
			{
				$rs = (strpos($file, 'data_arcade_recent_sites') !== false) ? true : false;

				if ((!$rs && strpos($file, 'data_arcade_dl_') === false) || ($rs && $this->is_post_empty('retain_weblinks')))
				{
					continue;
				}

				$this->cache->remove_file($this->cache->cache_dir . $file);
			}
		}
	}

	/**
	* Move games up and down by fixed order
	*/
	public function move_game_by($game_id, $cat_id, $action)
	{
		switch($action)
		{
			case 'g_move_up':
				$move = 15;
			break;

			case 'g_move_down':
				$move = -15;
			break;
		}

		$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
				SET game_order = game_order + ' . $move . '
				WHERE game_id = ' . (int) $game_id;
		$this->db->sql_query($sql);

		$sql = 'SELECT game_id, game_order FROM ' . ARCADE_GAMES_TABLE . '
				WHERE cat_id = ' . (int) $cat_id . '
				ORDER BY game_order ASC';
		$result = $this->db->sql_query($sql);

		$i = 10;
		while ($row = $this->db->sql_fetchrow($result))
		{
			$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
					SET game_order = ' . $i . '
					WHERE game_id = ' . (int) $row['game_id'];
			$this->db->sql_query($sql);
			$i += 10;
		}
		$this->db->sql_freeresult($result);
	}

	/**
	* Correctly updated the current highscore holder of a game
	*/
	public function update_highscore($game_data)
	{
		$high_score_type = ($game_data['game_scoretype'] == SCORETYPE_HIGH) ? true : false;

		$sql = 'SELECT score, user_id, score_date
				FROM ' . ARCADE_SCORES_TABLE . '
				WHERE game_id = ' . (int) $game_data['game_id'] . '
				ORDER BY score ' . (($high_score_type) ? 'DESC' : 'ASC') . ', score_date ASC';
		$result = $this->db->sql_query_limit($sql, 1);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!empty($row))
		{
			$sql_ary = array(
				'game_highscore'	=> $row['score'],
				'game_highuser'		=> $row['user_id'],
				'game_highdate'		=> $row['score_date']
			);
		}
		else
		{
			$sql_ary = array(
				'game_highscore' => 0,
				'game_highuser'  => 0,
				'game_highdate'  => 0
			);
		}

		$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
				SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
				WHERE game_id = ' . (int) $game_data['game_id'];
		$this->db->sql_query($sql);

		if ($super_score = $this->game()->super_champion($game_data['game_id'], true))
		{
			if (!empty($row))
			{
				if (($high_score_type && $super_score < $row['score']) || (!$high_score_type && $super_score > $row['score']))
				{
					$sql_ary = array(
						'user_id'		=> $row['user_id'],
						'score'			=> $row['score'],
						'score_date'	=> $row['score_date'],
					);

					$this->game()->update_super_score($sql_ary, $game_data['game_id']);
				}
			}
		}
		else if (!empty($row))
		{
			$sql_ary = array(
				'game_id'		=> (int) $game_data['game_id'],
				'user_id'		=> (int) $row['user_id'],
				'score'			=> $row['score'],
				'score_date'	=> $row['score_date']
			);

			$this->db->sql_return_on_error(true);
			$this->db->sql_query('INSERT INTO ' . ARCADE_SUPER_SCORES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
			$this->db->sql_return_on_error(false);
		}
	}

	public function search_game($keywords, &$total_games, $start, $url, &$errors, $cat_id = false)
	{
		if (!$keywords)
		{
			$errors[] = $this->user->lang['ARCADE_SEARCH_NO_MATCHES'];
		}
		else
		{
			$searchterm = '*' . strtolower($keywords) . '*';
			$searchterm = str_replace('*', $this->db->get_any_char() , $searchterm);
			$searchterm = str_replace('?', $this->db->get_one_char() , $searchterm);

			$total_games = $this->get->total('game', 'games_search', $searchterm, false, false, false, false, $cat_id);

			if ($total_games)
			{
				$sql = 'SELECT game_id, game_name, game_name_clean, game_type, game_save_type, game_image, game_desc, game_plays, cat_id
						FROM ' . ARCADE_GAMES_TABLE . '
						WHERE game_name_clean ' . $this->db->sql_like_expression($searchterm) . '
						' . (($cat_id) ? ' AND cat_id = ' . (int) $cat_id : '') . '
						ORDER BY game_name_clean ASC';
				$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);

				while ($row = $this->db->sql_fetchrow($result))
				{
					$this->template->assign_block_vars('find_games', array(
						'GAME_ID'			=> $row['game_id'],
						'GAME_NAME'			=> $this->get->game_name($row['game_name'], false, 'play', $row['cat_id'], $row['game_id'], 'x', false, false, false, true),
						'GAME_TYPE'			=> $this->game->type($row['game_type'], true),
						'GAME_SAVE_TYPE'	=> $this->game->save_type($row['game_save_type'], true),
						'GAME_DESC'			=> nl2br($row['game_desc']),
						'GAME_PLAYS'		=> $row['game_plays'],
						'GAME_IMAGE'		=> ($this->optionget('view_game_image')) ? $this->get->game_image($row['game_image'], 30, 30, 'x', 'play', $row['cat_id'], $row['game_id'], false, true) : false,

						'U_EDIT'			=> str_replace('mode=category', 'mode=games', $url) . '&amp;g=' . $row['game_id'] . '&amp;action=edit',
						'U_DELETE'			=> $url . '&amp;g=' . $row['game_id'] . '&amp;action=' . (($cat_id) ? "g_delete&amp;parent_id={$cat_id}" : 'delete')
					));
				}
				$this->db->sql_freeresult($result);
			}
			else
			{
				$errors[] = $this->user->lang['ARCADE_SEARCH_NO_MATCHES'];
			}
		}
	}

	/**
	* Update the edited user score data
	*/
	public function update_score($score_data, $user_id, $game_id)
	{
		$sql = 'UPDATE ' . ARCADE_SCORES_TABLE . '
				SET ' . $this->db->sql_build_array('UPDATE', $score_data) . '
				WHERE user_id = ' . (int) $user_id . '
				AND game_id = ' . (int) $game_id;
		$this->db->sql_query($sql);

		// After we update the score and comment data
		// We update the highscore holder for the game
		$row = $this->get()->game_data($game_id);
		$this->set_last_play($row['cat_id']);
		$this->update_highscore($row);
	}

	/**
	* Delete a user score
	*/
	public function delete_score($game_data, $user_id)
	{
		$retain_plays = $this->request->variable('retain_plays', false);

		$sql = 'DELETE FROM ' . ARCADE_SCORES_TABLE . '
				WHERE ' . $this->db->sql_in_set('game_id', $game_data['game_id']) . '
				AND   ' . $this->db->sql_in_set('user_id', $user_id);
		$this->db->sql_query($sql);

		if (!$retain_plays)
		{
			$sql = 'DELETE FROM ' . ARCADE_PLAYS_TABLE . '
					WHERE ' . $this->db->sql_in_set('game_id', $game_data['game_id']) . '
					AND   ' . $this->db->sql_in_set('user_id', $user_id);
			$this->db->sql_query($sql);
		}

		$this->set_last_play($game_data['cat_id']);
		$this->sync('game', $game_data['game_id']);
		$this->sync('category', $game_data['cat_id']);
		$this->sync('total_data', 'plays');

		// After we update the score we update the highscore holder for the game
		if ($user_id == $game_data['game_highuser'])
		{
			$this->update_highscore($game_data);
		}
	}

	/*
	* Set the last play data for the category
	* If the correct last play data cannot be
	* found it clears
	*/
	public function set_last_play($cat_ids = false)
	{
		// If we don't have a cat id we get all categories
		if (!$cat_ids)
		{
			$cat_ids = array();
			$sql = 'SELECT cat_id
					FROM ' . ARCADE_CATS_TABLE . '
					ORDER BY cat_id';
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$cat_ids[] = $row['cat_id'];
			}
			$this->db->sql_freeresult($result);
		}

		$cat_ids = array_map('intval', (is_array($cat_ids)) ? array_unique($cat_ids) : array($cat_ids));

		foreach ($cat_ids as $cat_id)
		{
			$sql_array = array(
				'SELECT'	=> 'g.game_id, g.game_name,
								s.score, s.score_date,
								u.user_id, u.username, u.user_colour',
				'FROM'		=> array(ARCADE_GAMES_TABLE => 'g'),
				'LEFT_JOIN'	=> array(
					array('FROM' => array(ARCADE_SCORES_TABLE	=> 's'), 'ON' => 'g.game_id = s.game_id'),
					array('FROM' => array(USERS_TABLE			=> 'u'), 'ON' => 's.user_id = u.user_id')
				),
				'WHERE'		=> "g.cat_id = $cat_id
					AND g.game_id = s.game_id
					AND s.user_id = u.user_id",
				'ORDER_BY'	=> 's.score_date DESC'
			);
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, 1);
			$row = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			if ($row)
			{
				$sql_ary = array(
					'cat_last_play_game_id'		=> $row['game_id'],
					'cat_last_play_game_name'	=> $row['game_name'],
					'cat_last_play_score'		=> $row['score'],
					'cat_last_play_time'		=> $row['score_date'],
					'cat_last_play_user_id'		=> $row['user_id'],
					'cat_last_play_username'	=> $row['username'],
					'cat_last_play_user_colour'	=> $row['user_colour']
				);

				$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
						SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . "
						WHERE cat_id = $cat_id";
				$this->db->sql_query($sql);

				unset($cat_ids[array_search($cat_id, $cat_ids)]);
			}
		}

		if (count($cat_ids))
		{
			$sql_ary = array(
				'cat_last_play_game_id'		=> 0,
				'cat_last_play_game_name'	=> '',
				'cat_last_play_user_id'		=> 0,
				'cat_last_play_score'		=> 0,
				'cat_last_play_time'		=> 0,
				'cat_last_play_username'	=> '',
				'cat_last_play_user_colour'	=> '',
			);

			$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
					SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
					WHERE ' . $this->db->sql_in_set('cat_id', $cat_ids);
			$this->db->sql_query($sql);
		}
	}

	/**
	* Send install file to the browser
	*/
	public function download_install_file($file, $filename, $use_method, $methods)
	{
		if (!in_array($use_method, $methods))
		{
			$use_method = '.tar';
		}

		include($this->root_path . 'includes/functions_compress.' . $this->php_ext);

		if ($use_method == '.zip')
		{
			$compress = new \compress_zip('w', $this->root_path . 'store/' . $filename . $use_method);
		}
		else
		{
			$compress = new \compress_tar('w', $this->root_path . 'store/' . $filename . $use_method, $use_method);
		}

		$compress->add_data('', 'index.htm');
		$compress->add_data($file, $filename . '.' . $this->php_ext);

		$compress->close();
		$compress->download($filename);
		@unlink($this->root_path . 'store/' . $filename . $use_method);

		garbage_collection();
		exit_handler();
	}

	public function game_control_select($value = 0)
	{
		$option_ary = (in_array($value, array(GAME_CONTROL_KEYBOARD_MOUSE, GAME_CONTROL_KEYBOARD, GAME_CONTROL_MOUSE))) ? array() : array(0 => 'ARCADE_UNKNOWN');

		$option_ary += array(
			GAME_CONTROL_KEYBOARD_MOUSE	=> 'ARCADE_KEYBOARD_MOUSE',
			GAME_CONTROL_KEYBOARD		=> 'ARCADE_KEYBOARD',
			GAME_CONTROL_MOUSE			=> 'ARCADE_MOUSE'
		);

		return $this->build_select(array_filter($option_ary), $value);
	}

	/**
	* Create game type dropdown
	*/
	public function game_type_select($value = 0, $default_value = '')
	{
		$option_ary = ($value == UNKNOWN_GAME || $default_value != '') ? array(UNKNOWN_GAME => ($default_value != '') ? $default_value : 'ARCADE_UNKNOWN') : array();

		$option_ary += array(
			GAME_TYPE_FLASH => 'GAME_TYPE_FLASH',
			GAME_TYPE_HTML5 => 'GAME_TYPE_HTML5'
		);

		return $this->build_select(array_filter($option_ary), $value);
	}

	/**
	* Create game type dropdown
	*/
	public function game_save_type_select($value = 0, $default_value = '')
	{
		$option_ary = ($value == UNKNOWN_GAME || $default_value != '') ? array(UNKNOWN_GAME => ($default_value != '') ? $default_value : 'ARCADE_UNKNOWN') : array();

		$option_ary += array(
			AMOD_GAME			=> 'AMOD_GAME',
			AR_GAME				=> 'AR_GAME',
			IBPRO_GAME			=> 'IBPRO_GAME',
			ARCADELIB_GAME		=> 'ARCADELIB_GAME',
			V3ARCADE_GAME		=> 'V3ARCADE_GAME',
			IBPROV3_GAME		=> 'IBPROV3_GAME',
			PHPBBARCADE_GAME	=> 'PHPBBARCADE_GAME',
			PHPBB_RA_GAME		=> 'PHPBB_RA_GAME',
			OLYMPUS_GAME		=> 'OLYMPUS_GAME',
			NOSCORE_GAME		=> 'NOSCORE_GAME'
		);

		return $this->build_select(array_filter($option_ary), $value);
	}

	/**
	* Create game score type dropdown
	*/
	public function game_scoretype_select($value = 0)
	{
		$option_ary = array(
			SCORETYPE_HIGH	=> 'ARCADE_GAME_SCORETYPE_HIGH',
			SCORETYPE_LOW	=> 'ARCADE_GAME_SCORETYPE_LOW'
		);

		return $this->build_select($option_ary, $value);
	}

	/**
	* Simple version of jumpbox, just lists authed categories
	*/
	public function make_cat_select($select_id = false, $ignore_id = false, $ignore_acl = false, $ignore_nongame = false, $ignore_emptycat = true, $only_acl_play = false, $return_array = false)
	{
		// This query is identical to the jumpbox one
		$sql = 'SELECT cat_id, cat_name, parent_id, cat_type, left_id, right_id
				FROM ' . ARCADE_CATS_TABLE . '
				ORDER BY left_id ASC';
		$result = $this->db->sql_query($sql, 600);

		$right = 0;
		$padding_store = array('0' => '');
		$padding = '';
		$cat_list = ($return_array) ? array() : '';

		// Sometimes it could happen that category will be displayed here not be displayed within the index page
		// This is the result of categories not displayed at index, having list permissions and a parent of a category with no permissions.
		// If this happens, the padding could be "broken"

		while ($row = $this->db->sql_fetchrow($result))
		{
			if ($row['left_id'] < $right)
			{
				$padding .= '&nbsp; &nbsp;';
				$padding_store[$row['parent_id']] = $padding;
			}
			else if ($row['left_id'] > $right + 1)
			{
				$padding = (isset($padding_store[$row['parent_id']])) ? $padding_store[$row['parent_id']] : '';
			}

			$right = $row['right_id'];
			$disabled = false;

			if (!$ignore_acl && $this->arcade_auth->acl_gets(array('c_list', 'c_play'), $row['cat_id']) && $this->auth->acl_gets('a_arcade_cat', 'm_arcade_game'))
			{
				if ($only_acl_play && !$this->arcade_auth->acl_get('c_play', $row['cat_id']))
				{
					$disabled = true;
				}
			}
			else if (!$ignore_acl)
			{
				continue;
			}

			if (
				((is_array($ignore_id) && in_array($row['cat_id'], $ignore_id)) || $row['cat_id'] == $ignore_id)
				||
				// Non-postable category with no subcategories, don't display
				($row['cat_type'] == ARCADE_CAT && ($row['left_id'] + 1 == $row['right_id']) && $ignore_emptycat)
				||
				($row['cat_type'] != ARCADE_CAT_GAMES && $ignore_nongame)
				)
			{
				// continue;
				$disabled = true;
			}

			if ($return_array)
			{
				// Include some more information...
				$selected = (is_array($select_id)) ? ((in_array($row['cat_id'], $select_id)) ? true : false) : (($row['cat_id'] == $select_id) ? true : false);
				$cat_list[$row['cat_id']] = array_merge(array('padding' => $padding, 'selected' => ($selected && !$disabled), 'disabled' => $disabled), $row);
			}
			else
			{
				$selected = (is_array($select_id)) ? ((in_array($row['cat_id'], $select_id)) ? ' selected="selected"' : '') : (($row['cat_id'] == $select_id) ? ' selected="selected"' : '');
				$cat_list .= '<option value="' . $row['cat_id'] . '"' . (($disabled) ? ' disabled="disabled" class="disabled-option"' : $selected) . '>' . $padding . $row['cat_name'] . '</option>';
			}
		}
		$this->db->sql_freeresult($result);
		unset($padding_store);

		return $cat_list;
	}

	/**
	* Get cat details
	*/
	public function get_cat_info($cat_id)
	{
		if (!$cat_id)
		{
			return false;
		}

		$sql = 'SELECT *
				FROM ' . ARCADE_CATS_TABLE . '
				WHERE cat_id = ' . (int) $cat_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			return false;
		}

		return $row;
	}

	/**
	* Get cat branch
	*/
	public function get_cat_branch($cat_id, $type = 'all', $order = 'descending', $include_cat = true)
	{
		switch ($type)
		{
			case 'parents':
				$condition = 'c1.left_id BETWEEN c2.left_id AND c2.right_id';
			break;

			case 'children':
				$condition = 'c2.left_id BETWEEN c1.left_id AND c1.right_id';
			break;

			default:
				$condition = 'c2.left_id BETWEEN c1.left_id AND c1.right_id OR c1.left_id BETWEEN c2.left_id AND c2.right_id';
			break;
		}

		$rows = array();

		$sql = 'SELECT c2.*
				FROM ' . ARCADE_CATS_TABLE . ' c1
				LEFT JOIN ' . ARCADE_CATS_TABLE . " c2 ON ($condition)
				WHERE c1.cat_id = " . (int) $cat_id . '
				ORDER BY c2.left_id ' . (($order == 'descending') ? 'ASC' : 'DESC');
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (!$include_cat && $row['cat_id'] == $cat_id)
			{
				continue;
			}

			$rows[] = $row;
		}
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	* Creates cat image dropdown
	*/
	public function generate_cat_images($cat_image)
	{
		$dir = $this->set_image_path('cat');

		if (!file_exists($dir))
		{
			trigger_error('ARCADE_CAT_IMAGE_PATH_ERROR', E_USER_ERROR);
		}

		$category_images = array();
		if ($files = scandir($dir))
		{
			foreach ($files as $file)
			{
				// The rank image has to be a jpg, gif or png
				if (!preg_match('#(\.gif|\.png|\.jpg|\.jpeg)$#i', $file) || strlen($file) > 255)
				{
					continue;
				}

				$stats = getimagesize($dir . $file);

				if ($stats !== false)
				{
					$category_images[] = $file;
				}
			}
		}

		$existing_imgs = array();

		$sql = 'SELECT cat_image
				FROM ' . ARCADE_CATS_TABLE;
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$existing_imgs[] = $row['cat_image'];
		}
		$this->db->sql_freeresult($result);

		$filename_list = $category_selected = '';
		for ($i = 0, $category_images_count = count($category_images); $i < $category_images_count; $i++)
		{
			$category_selected = ($cat_image && $category_images[$i] == $cat_image) ? 'selected="selected"' : '';

			$filename_list .= '<option value="' . $category_images[$i] . '"' . $category_selected . '>' . $category_images[$i] . ((in_array($category_images[$i], $existing_imgs)) ? ' ' . $this->user->lang['ARCADE_RANK_IMAGE_IN_USE'] : '') . '</option>';
		}

		return '<option value=""' . ((!$category_selected) ? ' selected="selected"' : '') . '>----------</option>' . $filename_list;
	}

	public function rev_optionset(&$user_row, $key, $value)
	{
		$var = $user_row['user_arcade_options'];

		if ($value && !($var & 1 << $this->keyoptions[$key]))
		{
			$var += 1 << $this->keyoptions[$key];
		}
		else if (!$value && ($var & 1 << $this->keyoptions[$key]))
		{
			$var -= 1 << $this->keyoptions[$key];
		}
		else
		{
			return false;
		}

		$user_row['user_arcade_options'] = $var;
		return true;
	}

	/**
	* View log
	* If $log_count is set to false, we will skip counting all entries in the database.
	*/
	public function view_log($mode, &$log, &$log_count, $limit = 0, $offset = 0, $cat_id = 0, $game_id = 0, $limit_days = 0, $sort_by = 'l.log_time DESC', $keywords = '')
	{
		$sql_cat = '';
		$game_id_list = $is_auth = array();

		$profile_url = (defined('IN_ADMIN') && $this->admin_path && $this->auth->acl_get('a_')) ? append_sid("{$this->admin_path}index.{$this->php_ext}", $this->module_url('manage') . '&amp;mode=users&amp;action=prefs') : append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=viewprofile');

		switch ($mode)
		{
			case 'admin':
				$log_type = ARCADE_LOG_ADMIN;
			break;

			case 'mod':
				$log_type = ARCADE_LOG_MOD;

				if ($game_id)
				{
					$sql_cat = 'AND l.game_id = ' . (int) $game_id;
				}
				else if (is_array($cat_id))
				{
					$sql_cat = 'AND ' . $this->db->sql_in_set('l.cat_id', array_map('intval', $cat_id));
				}
				else if ($cat_id)
				{
					$sql_cat = 'AND l.cat_id = ' . (int) $cat_id;
				}
			break;

			case 'user':
			case 'users':
				$log_type = ARCADE_LOG_USERS;
			break;

			case 'critical':
				$log_type = ARCADE_LOG_CRITICAL;
			break;

			default:
				return;
		}

		// Use no preg_quote for $keywords because this would lead to sole backslashes being added
		// We also use an OR connection here for spaces and the | string. Currently, regex is not supported for searching (but may come later).
		$keywords = preg_split('#[\s|]+#u', utf8_strtolower($keywords), 0, PREG_SPLIT_NO_EMPTY);
		$sql_keywords = '';

		if (!empty($keywords))
		{
			$keywords_pattern = array();

			// Build pattern and keywords...
			for ($i = 0, $num_keywords = count($keywords); $i < $num_keywords; $i++)
			{
				$keywords_pattern[] = preg_quote($keywords[$i], '#');
				$keywords[$i] = $this->db->sql_like_expression($this->db->get_any_char() . $keywords[$i] . $this->db->get_any_char());
			}

			$keywords_pattern = '#' . implode('|', $keywords_pattern) . '#ui';

			$operations = array();
			foreach ($this->user->lang as $key => $value)
			{
				if (!is_array($value) && substr($key, 0, 4) == 'LOG_' && preg_match($keywords_pattern, $value))
				{
					$operations[] = $key;
				}
			}

			$sql_keywords = 'AND (';
			if (!empty($operations))
			{
				$sql_keywords .= $this->db->sql_in_set('l.log_operation', $operations) . ' OR ';
			}
			$sql_keywords .= 'LOWER(l.log_data) ' . implode(' OR LOWER(l.log_data) ', $keywords) . ')';
		}

		if ($log_count !== false)
		{
			$sql = 'SELECT COUNT(l.log_id) AS total_entries
					FROM ' . ARCADE_LOGS_TABLE . ' l, ' . USERS_TABLE . " u
					WHERE l.log_type = $log_type
					AND l.user_id = u.user_id
					AND l.log_time >= $limit_days
					$sql_keywords
					$sql_cat";
			$result = $this->db->sql_query($sql);
			$log_count = (int) $this->db->sql_fetchfield('total_entries');
			$this->db->sql_freeresult($result);
		}

		// $log_count may be false here if false was passed in for it,
		// because in this case we did not run the COUNT() query above.
		// If we ran the COUNT() query and it returned zero rows, return;
		// otherwise query for logs below.
		if ($log_count === 0)
		{
			// Save the queries, because there are no logs to display
			$offset = 0;
			return $offset;
		}

		while ($offset >= $log_count)
		{
			$offset = max(0, $offset - $limit);
		}

		$sql = 'SELECT l.*, u.username, u.username_clean, u.user_colour
				FROM ' . ARCADE_LOGS_TABLE . ' l, ' . USERS_TABLE . " u
				WHERE l.log_type = $log_type
				AND u.user_id = l.user_id
				" . (($limit_days) ? "AND l.log_time >= $limit_days" : '') . "
				$sql_keywords
				$sql_cat
				ORDER BY $sort_by";
		$result = $this->db->sql_query_limit($sql, $limit, $offset);

		$i = 0;
		$log = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			if ($row['game_id'])
			{
				$game_id_list[] = $row['game_id'];
			}

			$log[$i] = array(
				'id'				=> $row['log_id'],

				'user_id'			=> $row['user_id'],
				'username'			=> $row['username'],
				'username_full'		=> $this->get()->username_string('full', $row['user_id'], $row['username'], $row['user_colour'], false, $profile_url),

				'ip'				=> $row['log_ip'],
				'time'				=> $row['log_time'],
				'cat_id'			=> $row['cat_id'],
				'game_id'			=> $row['game_id'],

				'action'			=> (isset($this->user->lang[$row['log_operation']])) ? $this->user->lang[$row['log_operation']] : '{' . ucfirst(str_replace('_', ' ', $row['log_operation'])) . '}'
			);

			if (!empty($row['log_data']))
			{
				$log_data_ary = @unserialize($row['log_data']);
				$log_data_ary = ($log_data_ary === false) ? array() : $log_data_ary;

				if (isset($this->user->lang[$row['log_operation']]))
				{
					// Check if there are more occurrences of % than arguments, if there are we fill out the arguments array
					// It doesn't matter if we add more arguments than placeholders
					if ((substr_count($log[$i]['action'], '%') - count($log_data_ary)) > 0)
					{
						$log_data_ary = array_merge($log_data_ary, array_fill(0, substr_count($log[$i]['action'], '%') - count($log_data_ary), ''));
					}

					$log_ary = array();
					foreach ($log_data_ary as $value)
					{
						$ld_ary = explode(', ', $value);

						$log_msg = '';
						$score_err = false;
						foreach ($ld_ary as $ld)
						{
							$log_msg .= (($log_msg != '') ? ', ' : '') . $this->lang_value($ld);

							if (strpos($row['log_operation'], 'LOG_ARCADE_FORM_SCORE_ERROR') !== false && strpos($ld, 'ARCADE_SCORE_ERR') !== false)
							{
								$score_err = true;
							}
						}

						$log_ary[] = ($score_err) ? '<span class="error">' . $log_msg . '</span>' : $log_msg;
					}

					$log[$i]['action'] = vsprintf($log[$i]['action'], $log_ary);

					// If within the admin panel we do not censor text out
					if (defined('IN_ADMIN') && $this->auth->acl_get('a_'))
					{
						$log[$i]['action'] = bbcode_nl2br($log[$i]['action']);
					}
					else
					{
						$log[$i]['action'] = bbcode_nl2br(censor_text($log[$i]['action']));
					}
				}
				else if (!empty($log_data_ary))
				{
					$log[$i]['action'] .= '<br>' . implode('', $log_data_ary);
				}
			}

			$i++;
		}
		$this->db->sql_freeresult($result);

		if (count($game_id_list))
		{
			$game_id_list = array_unique($game_id_list);

			// This query is not really needed if move_games() updates the cat_id field,
			// although it's also used to determine if the game still exists in the database
			$sql = 'SELECT game_id, cat_id
				FROM ' . ARCADE_GAMES_TABLE . '
				WHERE ' . $this->db->sql_in_set('game_id', array_map('intval', $game_id_list));
			$result = $this->db->sql_query($sql);

			while ($row = $this->db->sql_fetchrow($result))
			{
				$is_auth[$row['game_id']] = $row['cat_id'];
			}
			$this->db->sql_freeresult($result);

			foreach ($log as $key => $row)
			{
				if (isset($is_auth[$row['game_id']]))
				{
					$log[$key]['viewcat'] = ($this->auth->acl_get('a_arcade_cat')) ? append_sid("{$this->admin_path}index.{$this->php_ext}", $this->module_url('manage') . '&amp;mode=category&amp;parent_id=' . $is_auth[$row['game_id']] . '&amp;g=' . $row['game_id']) . '#g' . $row['game_id'] : false;
					$log[$key]['viewgame'] = ($this->arcade_auth->acl_get('c_play', $is_auth[$row['game_id']])) ? $this->url("mode=play&amp;g={$row['game_id']}") : false;
					//$log[$key]['viewlogs'] = ($this->auth->acl_get('m_')) ? append_sid("{$this->root_path}mcp.{$this->php_ext}", $this->module_url('logs') . '&amp;mode=game_logs&amp;g=' . $row['game_id'], true, $this->user->session_id) : false;
					$log[$key]['editgame'] = ($this->auth->acl_get('a_arcade_game')) ? append_sid("{$this->admin_path}index.{$this->php_ext}", $this->module_url('manage') . '&amp;mode=games&amp;action=edit&amp;g=' . $row['game_id']) : false;
				}
			}
		}

		return $offset ? $offset : 0;
	}

	/**
	* Display progress bar for syncinc categories
	*/
	public function display_progress_bar()
	{
		adm_page_header($this->user->lang['SYNC_IN_PROGRESS']);

		$this->template->set_filenames(array(
			'body' => 'progress_bar.html')
		);

		$this->template->assign_vars(array(
			'L_PROGRESS'			=> $this->user->lang['SYNC_IN_PROGRESS'],
			'L_PROGRESS_EXPLAIN'	=> $this->user->lang['SYNC_IN_PROGRESS_EXPLAIN']
		));

		adm_page_footer();
	}

	public function adm_username($user_id, $username, $user_colour, $url = '')
	{
		if (!$url)
		{
			$url = append_sid("{$this->admin_path}index.{$this->php_ext}", $this->module_url('manage') . '&amp;mode=users&amp;action=prefs');
		}
		else
		{
			$url .= '&amp;action=prefs';
		}

		return $this->get()->user_name('full', $user_id, $username, $user_colour, false, '', $url);
	}

	public function confirm_box($method, $confirm, $s_hidden_fields = '')
	{
		$this->template->assign_var('S_CONFIRM_SUPER_CHAM', (in_array($method, array('reset_marked'))) ? true : false);

		switch ($method)
		{
			case 'delete_files':
				$l_title	= 'ARCADE_DELETE_FILES';
				$l_explain	= "{$l_title}_WARNING";
				$this->template->assign_var('S_CONFIRM_REASON_DELETE', (in_array($method, array('reset_marked'))) ? true : false);
			break;

			case 'retain_super_champion':
				$l_title	= 'ARCADE_RETAIN_SUPER_CHAMPION';
				$l_explain	= "{$l_title}_EXPLAIN";
			break;

			case 'reset_marked':
				$method = 'retain_plays';
			case 'retain_plays':
				$l_title	= 'ARCADE_RETAIN_PLAYS';
				$l_explain	= "{$l_title}_EXPLAIN";
			break;
		}

		$this->template->assign_vars(array(
			'L_ARCADE_CONFIRM'			=> $this->user->lang[$l_title],
			'L_ARCADE_CONFIRM_EXPLAIN'	=> $this->user->lang[$l_explain],
			'CONFIRM_NAME'				=> $method
		));

		$s_hidden_fields = ($s_hidden_fields != '') ? build_hidden_fields($s_hidden_fields) : '';

		confirm_box(false, $confirm, $s_hidden_fields, 'arcade/confirm_body.html');
	}

	public function add_rvlog($log_msg, $rv_key, $data1 = '', $data2 = '')
	{
		$sep = '<br>&raquo;&nbsp;';
		if ($rv_key === true)
		{
			$lk1	= ($this->request->variable('retain_super_champion', false)) ? 'ARCADE_RETAIN_SUPER_CHAMPION' : '';
			$lk2	= ($this->request->variable('retain_plays', false)) ? 'ARCADE_RETAIN_PLAYS' : '';
			$sep1	= ($lk1) ? $sep : '';
			$sep2	= ($lk2) ? (($sep1) ? ',&nbsp;' : $sep) : '';

			$args = array('admin', $log_msg, $sep1, $lk1, $sep2, $lk2, $data1);
		}
		else
		{
			$lang_key	= ($rv_key && $this->request->variable($rv_key, false)) ? 'ARCADE_' . strtoupper($rv_key) : '';
			$sep		= ($lang_key) ? $sep : '';
			$args = array('admin', $log_msg, $sep, $lang_key);
			if ($data1) {$args[] = $data1;}
			if ($data2) {$args[] = $data2;}
		}

		return call_user_func_array(array($this, 'add_log'), $args);
	}
}
