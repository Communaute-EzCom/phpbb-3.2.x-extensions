<?php
/**
*
* @package phpBB Arcade
* @version $Id: base.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\ext;

class base implements ext_interface
{
	protected $version, $name, $language;

	public function get_version()
	{
		return $this->version;
	}

	public function get_name()
	{
		return $this->name;
	}

	public function get_language()
	{
		return $this->language;
	}

	public function get_template_acp()
	{
		return array();
	}
}
