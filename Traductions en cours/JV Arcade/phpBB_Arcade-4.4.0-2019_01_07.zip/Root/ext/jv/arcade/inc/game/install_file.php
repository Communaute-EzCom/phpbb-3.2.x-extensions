<?php
/**
*
* @package phpBB Arcade
* @version $Id: install_file.php 2136 2019-01-05 19:42:24Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class install_file
{
	protected $db, $arcade, $file_functions, $root_path, $php_ext;
	public $game_data;

	public function __construct($db, $arcade, $file_functions, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->arcade = $arcade;
		$this->file_functions = $file_functions;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->game_data = array();
	}

	public function game_data()
	{
		return $this->game_data;
	}

	public function data($dir, $file, $install_file)
	{
		$game_data = array();

		if (!file_exists($install_file))
		{
			$type = '';
			if ($f = $this->path($dir, $file, $type))
			{
				$install_file = $f;
			}
		}

		if (file_exists($install_file))
		{
			if (!$this->data_check($install_file, $game_data, array(), $file))
			{
				if (!$this->convert($dir, $file))
				{
					return false;
				}
				else if (count($this->game_data))
				{
					$game_data = array_merge($game_data, $this->game_data);
				}
			}
		}

		return (count($game_data)) ? $game_data : false;
	}

	protected function path($dir, &$file_name, &$type, $extract = false, $re_check = false)
	{
		// Check to make sure a valid config file is present
		$install_file = '';
		$orig_file_name = $file_name;

		// As far as I know all ibpro games start with "game_" if this is not the case
		// please let me know as this will have to be changed
		if (($extract || $re_check) && substr($file_name, 0, 5) == 'game_')
		{
			$file_name = substr($file_name, 5);
		}

		if ($extract)
		{
			$game_config1	= $game_config3 = $dir . $file_name . '.' . $this->php_ext;
			$game_config2	= $dir . $orig_file_name . '.' . $this->php_ext;
			$game_xml1		= $dir . 'game.xml';
			$game_xml2		= $dir . 'game.xml';
			$v3_config		= $dir . $file_name . '.game.' . $this->php_ext;
			$ra_config		= $dir . $file_name . '_config.ini';
			$olympus_config	= $dir . 'install.xml';
		}
		else
		{
			$game_config1	= $dir . $file_name . '/' . $file_name . '.' . $this->php_ext;
			$game_config2	= $dir . $orig_file_name . '/'. $orig_file_name . '.' . $this->php_ext;
			$game_config3	= $dir . $orig_file_name . '/'. $file_name . '.' . $this->php_ext;
			$game_xml1		= $dir . $file_name . '/' . 'game.xml';
			$game_xml2		= $dir . $orig_file_name . '/' . 'game.xml';
			$v3_config		= $dir . $file_name . '/'. $file_name . '.game.' . $this->php_ext;
			$ra_config		= $dir . $file_name . '/'. $file_name . '_config.ini';
			$olympus_config	= $dir . $file_name . '/' . 'install.xml';
		}

		if (file_exists($ra_config))
		{
			$install_file = $ra_config;
			$type = 'relax';
		}
		else if (file_exists($game_xml1))
		{
			$install_file = $game_xml1;
			$type = 'xml1';
		}
		else if (file_exists($game_xml2))
		{
			$install_file = $game_xml2;
			$type = 'xml2';
		}
		else if (file_exists($v3_config))
		{
			$install_file = $v3_config;
			$type = 'v3arcade';
		}
		else if (file_exists($game_config1))
		{
			$install_file = $game_config1;
			$type = 'arcade';
		}
		else if (file_exists($game_config2))
		{
			$install_file = $game_config2;
			$type = 'orig';
		}
		else if (file_exists($game_config3))
		{
			$install_file = $game_config3;
			$type = 'mix';
		}
		else if (file_exists($olympus_config))
		{
			$install_file = $olympus_config;
			$type = 'olympus';
		}

		// Improperly packed game checking
		if ($re_check && $install_file)
		{
			if (in_array($type, array('orig', 'mix')))
			{
				$this->file_functions->append_slash($orig_file_name);
				$this->file_functions->move_dir($dir . $orig_file_name, $dir);
				$install_file = str_replace($orig_file_name, '', $install_file);
			}
			else
			{
				$dfn = $file_name;
				$this->file_functions->append_slash($dfn);
				$this->file_functions->move_dir($dir . $dfn, $dir);
				$install_file = str_replace($dfn, '', $install_file);
			}
		}
		else if ($extract && !$re_check && !$install_file)
		{
			// re-check add path + game folder
			$install_file = $this->path($dir, $orig_file_name, $type, false, true);
		}

		return $install_file;
	}

	public function convert($dir, $game_filename, $extract = false)
	{
		$game_st = '';
		$convert_install_file = false;
		$orig_game_filename = $game_filename;

		$type = '';
		$install_file = $this->path($dir, $game_filename, $type, $extract);

		switch ($type)
		{
			case 'orig':
			case 'xml2':
				$game_filename = $orig_game_filename;
			break;
		}

		if ($install_file)
		{
			$update = true;

			switch ($type)
			{
				case 'xml1':
				case 'xml2':
					$install_array = $this->file_functions->xml2array($install_file);
					$this->file_functions->delete_file($install_file);

					foreach ($install_array as $key => $value)
					{
						if (is_string($value))
						{
							$install_array[$key] = trim($value);
						}
					}

					$game_filename = $this->file_functions->remove_extension($install_array['game']['swf']);

					if (!$game_filename)
					{
						break;
					}

					$install_file = $dir . (($extract) ? '' : $game_filename . '/') . $game_filename . '.' . $this->php_ext;

					$data = array(
						'game_name'			=> $install_array['game']['name'],
						'game_desc'			=> $install_array['game']['description'] . ' ' . $install_array['game']['directions'],
						'game_control'		=> UNKNOWN_GAME,
						'game_control_desc'	=> '',
						'game_width'		=> (int) $install_array['game']['width'],
						'game_height'		=> (int) $install_array['game']['height'],
						'game_scoretype'	=> (strtolower($install_array['game']['revscore']) == 'false') ? SCORETYPE_HIGH : SCORETYPE_LOW,
						'game_save_type'	=> (strtolower($install_array['game']['highscore']) == 'false') ? NOSCORE_GAME : AR_GAME,
						'game_type'			=> GAME_TYPE_FLASH
					);

					$convert_install_file = true;
				break;

				case 'relax':
					$install_array = parse_ini_file($install_file);
					$this->file_functions->delete_file($install_file);

					foreach ($install_array as $key => $value)
					{
						if (is_string($value))
						{
							$install_array[$key] = trim($value);
						}
					}

					$install_file = $dir . (($extract) ? '' : $game_filename . '/') . $game_filename . '.' . $this->php_ext;

					$game_control = (!empty($install_array['controle'])) ? (int) $install_array['controle'] : UNKNOWN_GAME;

					switch ($game_control)
					{
						case 1:
							$game_control = GAME_CONTROL_KEYBOARD;
						break;

						case 2:
							$game_control = GAME_CONTROL_MOUSE;
						break;

						case 3:
							$game_control = GAME_CONTROL_KEYBOARD_MOUSE;
						break;

						default:
							$game_control = UNKNOWN_GAME;
					}

					$data = array(
						'game_name'			=> $install_array['nom'],
						'game_desc'			=> $install_array['description'],
						'game_control'		=> $game_control,
						'game_control_desc'	=> '',
						'game_width'		=> (int) $install_array['largeur'],
						'game_height'		=> (int) $install_array['hauteur'],
						'game_scoretype'	=> (int) $install_array['highscore_type'] ? SCORETYPE_LOW : SCORETYPE_HIGH,
						'game_save_type'	=> PHPBB_RA_GAME,
						'game_type'			=> !empty($install_array['jeuxhtml5']) ? GAME_TYPE_HTML5 : GAME_TYPE_FLASH
					);

					if (!empty($install_array['variable']) && $install_array['variable'] != $game_filename)
					{
						$data['game_scorevar'] = $install_array['variable'];
					}

					$convert_install_file = true;
				break;

				case 'olympus':
					$install_array = $this->file_functions->xml2array($install_file);
					$this->file_functions->delete_file($install_file);

					foreach ($install_array as $key => $value)
					{
						if (is_string($value))
						{
							$install_array[$key] = trim($value);
						}
					}

					$game_filename = $this->file_functions->remove_extension($install_array['game']['filename']);

					if (!$game_filename)
					{
						break;
					}

					$install_file = $dir . (($extract) ? '' : $game_filename . '/') . $game_filename . '.' . $this->php_ext;

					$data = array(
						'game_name'			=> $install_array['game']['name'],
						'game_desc'			=> $install_array['game']['description'],
						'game_image'		=> $install_array['game']['icon'],
						'game_control'		=> UNKNOWN_GAME,
						'game_control_desc'	=> '',
						'game_width'		=> (int) $install_array['game']['width'],
						'game_height'		=> (int) $install_array['game']['height'],
						'game_scoretype'	=> (!$install_array['game']['bestScoreFirst']) ? SCORETYPE_HIGH : SCORETYPE_LOW,
						'game_save_type'	=> OLYMPUS_GAME,
						'game_type'			=> GAME_TYPE_FLASH
					);

					if (!empty($install_array['game']['variable']) && $install_array['game']['variable'] != $game_filename)
					{
						$data['game_scorevar'] = $install_array['game']['variable'];
					}

					$convert_install_file = true;
				break;
				
				case 'v3arcade':
					// No support
					$install_file = '';
				break;

				default:
					$file_contents = file_get_contents($install_file);

					if (strpos($file_contents, '$game_data') !== false)
					{
						$update = false;
						$convert_install_file = true;
					}
					else if (strpos($file_contents, '$ibp_config') === false)
					{
						if (strpos($file_contents, '$config') === false)
						{
							$update = false;
						}

						// We have to read the ibpro config file contents and replace the $config variable
						// or there will be problems since we will have overwritten the phpbb config variable
						if ($update)
						{
							$ibp_config = str_replace('$config', '$ibp_config', $file_contents);
							$this->file_functions->write_file($install_file, $ibp_config);
						}
					}

					if ($update)
					{
						// Since we now have a nice config file lets include it
						@include($install_file);

						// Remove extra spaces from array strings
						foreach ($ibp_config as $key => $value)
						{
							if (is_string($value))
							{
								$ibp_config[$key] = trim($value);
							}
						}

						// $ibp_config['gname'] -> $game_filename

						$convert_install_file = true;
						$gkeys = strtolower($ibp_config['gkeys']);

						$data = array(
							'game_name'			=> $ibp_config['gtitle'],
							'game_desc'			=> $ibp_config['gwords'] . ((!empty($ibp_config['object']) && $ibp_config['object'] != '1' && $ibp_config['gwords'] != $ibp_config['object']) ? ' ' . $ibp_config['object'] : ''),
							'game_control'		=> (strpos($gkeys, 'mouse') !== false) ? GAME_CONTROL_MOUSE : UNKNOWN_GAME,
							'game_control_desc'	=> ($gkeys && $gkeys != 'mouse' && $gkeys != 'mouse.') ? $ibp_config['gkeys'] : '',
							'game_width'		=> $ibp_config['gwidth'],
							'game_height'		=> $ibp_config['gheight'],
							'game_scoretype'	=> (!isset($ibp_config['highscore_type']) || $ibp_config['highscore_type'] == 'high') ? SCORETYPE_HIGH : SCORETYPE_LOW,
							'game_type'			=> GAME_TYPE_FLASH
						);

						$gamedata_path = $dir . 'gamedata/' . $game_filename;

						// Find game type
						if (file_exists($gamedata_path . '/v32game.txt') || file_exists($gamedata_path . '/v3game.txt'))
						{
							// We have found a v3x game
							$data['game_save_type'] = IBPROV3_GAME;
						}
						else if (file_exists($gamedata_path . '/'. $game_filename . '.txt'))
						{
							// We have found an arcadelib game
							$data['game_save_type'] = ARCADELIB_GAME;
						}
						else
						{
							$data['game_save_type'] = IBPRO_GAME;
						}
					}

					unset($file_contents);
				break;
			}

			if (!$update || !$convert_install_file)
			{
				if (!isset($game_data) || !is_array($game_data))
				{
					$game_data = array();
				}

				if (!$this->data_check($install_file, $game_data, array(), $game_filename))
				{
					$data = $game_data;
					$update = $convert_install_file = true;
				}
			}

			// Here is where we create the new install file and place it in the correct location
			if ($update && $convert_install_file)
			{
				$game_swf_file = $dir . (($extract) ? '' : $game_filename . '/') . $game_filename . '.swf';

				$support_html5 = array(IBPRO_GAME, PHPBBARCADE_GAME, PHPBB_RA_GAME);

				if (isset($data['game_save_type']) && in_array($data['game_save_type'], $support_html5) && $data['game_type'] == GAME_TYPE_FLASH && !file_exists($game_swf_file))
				{
					$data['game_type'] = GAME_TYPE_HTML5;
				}

				if (!$this->update(false, $data, $install_file))
				{
					$convert_install_file = false;
				}
			}

			return ($convert_install_file) ? $game_filename : false;
		}

		return false;
	}

	public function create(&$data)
	{
		static $_cache_default_install_file;

		if (empty($_cache_default_install_file))
		{
			$_cache_default_install_file = file_get_contents($this->arcade->ext_path() . 'inc/game/default_install_file.' . $this->php_ext);
		}

		$this->validate($data, true);
		$this->game_data = $data;

		$game_type		= $this->arcade->game()->type($this->game_data['game_type']);
		$game_save_type	= $this->arcade->game()->save_type($this->game_data['game_save_type']);

		switch ($this->game_data['game_control'])
		{
			case GAME_CONTROL_KEYBOARD_MOUSE:
				$game_control = 'GAME_CONTROL_KEYBOARD_MOUSE';
			break;

			case GAME_CONTROL_KEYBOARD:
				$game_control = 'GAME_CONTROL_KEYBOARD';
			break;

			case GAME_CONTROL_MOUSE:
				$game_control = 'GAME_CONTROL_MOUSE';
			break;

			default:
				$game_control = 'UNKNOWN_GAME';
			break;
		}

		switch ($this->game_data['game_scoretype'])
		{
			case SCORETYPE_HIGH:
				$game_scoretype = 'SCORETYPE_HIGH';
			break;

			case SCORETYPE_LOW:
				$game_scoretype = 'SCORETYPE_LOW';
			break;

			default:
				$game_scoretype = 'SCORETYPE_HIGH';
			break;
		}

		$game_image = '$game_file . ' . "'.gif'";
		$game_scorevar = '$game_file';

		$game_folder = (!empty($this->game_data['game_swf'])) ? $this->file_functions->remove_extension($this->game_data['game_swf']) : 'Empty';

		if ($this->game_data['game_name'] == 'Empty' && $game_folder != 'Empty')
		{
			$data['game_name'] = $this->game_data['game_name'] = str_replace(array('_jvh5', '_'), array('', ' '), $game_folder);
		}

		if (!empty($this->game_data['game_image']) && $this->game_data['game_image'] != $game_folder . '.gif')
		{
			$image_name = $this->file_functions->remove_extension($this->game_data['game_image']);

			if ($image_name == $game_folder)
			{
				$image_ext = substr(strrchr($this->game_data['game_image'], '.'), 1);
				$game_image = '$game_file . ' . "'.{$image_ext}'";
			}
			else
			{
				$game_image = "'" . $this->game_data['game_image'] . "'";
			}
		}

		if (!empty($this->game_data['game_scorevar']) && $this->game_data['game_scorevar'] != $game_folder)
		{
			$game_scorevar = "'" . $this->game_data['game_scorevar'] . "'";
		}

		$this->validate_data($this->game_data);
		$search = array('{GAME_NAME}', "'{GAME_SCOREVAR}'", '{GAME_DESC}', "'{GAME_CONTROL}'", '{GAME_CONTROL_DESC}', "'{GAME_IMAGE}'", "'{GAME_TYPE}'", "'{GAME_WIDTH}'", "'{GAME_HEIGHT}'", "'{GAME_SCORETYPE}'", "'{GAME_SAVE_TYPE}'", '{GAME_PRIVACY_DESC}', '{GAME_PRIVACY_LINK}');
		$replace = array($this->game_data['game_name'], $game_scorevar, $this->game_data['game_desc'], $game_control, $this->game_data['game_control_desc'], $game_image, $game_type, $this->game_data['game_width'], $this->game_data['game_height'], $game_scoretype, $game_save_type, $this->game_data['privacy_desc'], $this->game_data['privacy_link']);

		return str_replace($search, $replace, $_cache_default_install_file);
	}

	public function row_update($game_id)
	{
		$return = false;

		if ($game_id)
		{
			$data = array();
			$return = $this->update($game_id, $data);
		}

		return $return;
	}

	public function update($game_id, &$data, $install_file = false)
	{
		if ($game_id && !$data)
		{
			$data = $this->arcade->get()->game_data($game_id);
		}

		if (empty($data) || (!$install_file && empty($data['game_swf'])))
		{
			return false;
		}

		if (!$install_file)
		{
			$install_file = $this->arcade->set_path($data['game_swf'], 'install');
		}

		$return = $this->file_functions->write_file($install_file, $this->create($data, true));

		if (!$return)
		{
			if (!$game_id)
			{
				if (empty($data['game_id']))
				{
					if (!empty($data['game_name']))
					{
						$sql = "SELECT game_id
								FROM " . ARCADE_GAMES_TABLE . "
								WHERE game_name_clean = '" . $this->db->sql_escape(utf8_clean_string($data['game_name'])) . "'";
						$result = $this->db->sql_query($sql);
						$game_id = (int) $this->db->sql_fetchfield('game_id');
						$this->db->sql_freeresult($result);
					}
				}
				else
				{
					$game_id = $data['game_id'];
				}
			}

			if ($game_id && !empty($data['game_name']))
			{
				$this->arcade->add_log('critical', $game_id, 'LOG_ARCADE_GAME_INSTALL_FILE_' . ((file_exists($install_file)) ? 'UNWRITABLE' : 'NOT_FOUND'), $data['game_name'], $this->arcade->root_key($install_file));
			}
		}

		return $return;
	}

	public function data_check($install_file, &$game_data, $_db_info = array(), $game_filename = '')
	{
		$r = true;
		$valid = false;
		$ext = substr(strrchr($install_file, '.'), 1);
		$install_file = ($ext == $this->php_ext) ? $install_file : '';

		if ($install_file && file_exists($install_file))
		{
			$version = file_get_contents($install_file, null, null, 47, 5);

			if (version_compare($version, '5.3.0', '<'))
			{
				$r = false;
			}
		}
		else
		{
			$r = false;
		}

		if (!count($game_data) && $install_file)
		{
			$valid = true;
			@include($install_file);

			if (count($game_data) && $game_filename)
			{
				$game_data['game_swf'] = "{$game_filename}.swf";
			}
		}

		if ($r)
		{
			if (count($_db_info))
			{
				if (count($game_data))
				{
					foreach ($game_data as $key => $value)
					{
						if (!isset($_db_info[$key]) || htmlspecialchars_decode($this->arcade->check_addslashes($_db_info[$key])) != $this->arcade->check_addslashes($value))
						{
							$r = false;
							break;
						}
					}
				}
				else
				{
					$r = false;
				}
			}

			if ($r)
			{
				$require_var = array(
					'game_name', 'game_desc', 'game_control', 'game_control_desc', 'game_image', 'game_scorevar', 'game_type',
					'game_width', 'game_height', 'game_scoretype', 'game_save_type', 'privacy_desc', 'privacy_link'
				);

				foreach ($require_var as $var)
				{
					if (!isset($game_data[$var]) || ($var == 'game_name' && !$game_data[$var]) || ($var === 'game_width' && $game_data[$var] < ARCADE_MIN_GAME_WIDTH) || ($var === 'game_height' && $game_data[$var] < ARCADE_MIN_GAME_HEIGHT))
					{
						$r = false;
						break;
					}
				}
			}
		}

		return $r ? (($valid) ? $this->validate($game_data) : true) : false;
	}

	public function validate_data(&$gd)
	{
		$gd['game_name']			= utf8_normalize_nfc($this->arcade->check_addslashes(strip_tags(htmlspecialchars_decode($gd['game_name']))));
		$gd['game_desc']			= utf8_normalize_nfc($this->arcade->check_addslashes(strip_tags(htmlspecialchars_decode($gd['game_desc']))));
		$gd['game_control_desc']	= utf8_normalize_nfc($this->arcade->check_addslashes(strip_tags(htmlspecialchars_decode($gd['game_control_desc']))));
		$gd['privacy_desc']			= utf8_normalize_nfc($this->arcade->check_addslashes(htmlspecialchars_decode($gd['privacy_desc'])));
		$gd['privacy_link']			= utf8_normalize_nfc($this->arcade->check_addslashes(htmlspecialchars_decode($gd['privacy_link'])));

		$gd['game_image']			= $this->arcade->check_addslashes($gd['game_image']);
		$gd['game_scorevar']		= $this->arcade->check_addslashes($gd['game_scorevar']);
	}

	public function validate_db_data(&$value, $key = '')
	{
		$validate_columns = array('game_name', 'game_desc', 'game_control_desc', 'game_image', 'game_scorevar', 'privacy_desc', 'privacy_link');

		if (is_array($value))
		{
			foreach ($value as $k => $v)
			{
				if (in_array($k, $validate_columns))
				{
					$this->sc($value[$k], !in_array($k, array('privacy_desc', 'privacy_link')));
				}
			}
		}
		else if ($key && in_array($key, $validate_columns))
		{
			$this->sc($value, !in_array($key, array('privacy_desc', 'privacy_link')));
		}
	}

	private function sc(&$v, $st = true)
	{
		$v = htmlspecialchars_decode($v);
		$v = $st ? strip_tags(htmlspecialchars_decode($v)) : htmlspecialchars_decode($v);
		$v = utf8_htmlspecialchars(stripslashes($v));
	}

	public function validate(&$fl_data, $create = false)
	{
		$r = true;
		// verify old install file and correction type
		if (empty($fl_data['game_save_type']) && !empty($fl_data['game_type']))
		{
			$fl_data['game_save_type'] = $fl_data['game_type'];
			$fl_data['game_type'] = GAME_TYPE_FLASH;
		}

		$valid_data = array(
			'game_name'			=> (string) (!empty($fl_data['game_name']))			? $fl_data['game_name'] : 'Empty',
			'game_desc'			=> (string) (!empty($fl_data['game_desc']))			? $fl_data['game_desc'] : '',
			'game_control'		=> (int)	(!empty($fl_data['game_control']))		? $fl_data['game_control'] : UNKNOWN_GAME,
			'game_control_desc'	=> (string) (!empty($fl_data['game_control_desc']))	? $fl_data['game_control_desc'] : '',
			'game_image'		=> (string) (!empty($fl_data['game_image']))		? $fl_data['game_image'] : '',
			'game_scorevar'		=> (string) (!empty($fl_data['game_scorevar']))		? $fl_data['game_scorevar'] : '',
			'game_type'			=> (int)	(!empty($fl_data['game_type']))			? $fl_data['game_type'] : UNKNOWN_GAME,
			'game_width'		=> (int)	(!empty($fl_data['game_width']))		? $fl_data['game_width'] : 640,
			'game_height'		=> (int)	(!empty($fl_data['game_height']))		? $fl_data['game_height'] : 480,
			'game_scoretype'	=> (int)	(!empty($fl_data['game_scoretype']))	? $fl_data['game_scoretype'] : SCORETYPE_HIGH,
			'game_save_type'	=> (int)	(!empty($fl_data['game_save_type']))	? $fl_data['game_save_type'] : UNKNOWN_GAME,
			'privacy_desc'		=> (string) (!empty($fl_data['privacy_desc']))		? $fl_data['privacy_desc'] : '',
			'privacy_link'		=> (string) (!empty($fl_data['privacy_link']))		? $fl_data['privacy_link'] : ''
		);

		if ($valid_data['game_width'] < ARCADE_MIN_GAME_WIDTH || $valid_data['game_height'] < ARCADE_MIN_GAME_HEIGHT)
		{
			$valid_data['game_width']	= (int) ARCADE_MIN_GAME_WIDTH;
			$valid_data['game_height']	= (int) ARCADE_MIN_GAME_HEIGHT;
		}

		switch ($valid_data['game_control'])
		{
			case GAME_CONTROL_KEYBOARD_MOUSE:
				$valid_data['game_control'] = (int) GAME_CONTROL_KEYBOARD_MOUSE;
			break;

			case GAME_CONTROL_KEYBOARD:
				$valid_data['game_control'] = (int) GAME_CONTROL_KEYBOARD;
			break;

			case GAME_CONTROL_MOUSE:
				$valid_data['game_control'] = (int) GAME_CONTROL_MOUSE;
			break;

			default:
				$valid_data['game_control'] = (int) UNKNOWN_GAME;
			break;
		}

		switch ($valid_data['game_scoretype'])
		{
			case SCORETYPE_HIGH:
				$valid_data['game_scoretype'] = (int) SCORETYPE_HIGH;
			break;

			case SCORETYPE_LOW:
				$valid_data['game_scoretype'] = (int) SCORETYPE_LOW;
			break;

			default:
				$valid_data['game_scoretype'] = (int) SCORETYPE_HIGH;
			break;
		}

		$this->validate_data($valid_data);

		if ($create)
		{
			// Use more data - create install file
			$fl_data = array_merge($fl_data, $valid_data);
		}
		else
		{
			foreach ($valid_data as $key => $value)
			{
				if (!isset($fl_data[$key]) || $this->arcade->check_addslashes($fl_data[$key]) !== $value)
				{
					$r = false;
					break;
				}
			}
		}

		return $r;
	}
}
