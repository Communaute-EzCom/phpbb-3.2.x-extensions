<?php
/**
*
* @package phpBB Arcade
* @version $Id: session.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class session
{
	public $game_sid		= '';
	public $game_popup		= false;
	public $lighting		= false;
	public $info_block		= false;

	protected $db, $user, $request, $config, $arcade_config, $arcade;

	public function __construct($db, $user, $request, $config, $arcade_config, $arcade)
	{
		$this->db = $db;
		$this->user = $user;
		$this->request = $request;
		$this->config = $config;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	public function main($use_cookie_popup = false)
	{
		$arcade_gsid = (string) $this->request->variable('arcade_gsid', '');
		$this->game_sid = ($arcade_gsid) ? $arcade_gsid : null;

		if ($this->game_sid === null)
		{
			$game_sid = (string) $this->request->variable('game_sid', '');
			$this->game_sid = ($game_sid) ? $game_sid : null;
		}

		$this->game_popup		= ($this->request->variable('gp', false) || strtolower($this->request->variable('mode', '')) == 'popup') ? true : false;

		$this->game_sid			= ($this->game_sid) ? $this->game_sid : $this->get('sid');
		$this->game_popup		= ($use_cookie_popup && !$this->game_popup) ? $this->get('popup', false) : $this->game_popup;
		$this->lighting			= $this->get('lighting', false);
		$this->info_block		= $this->get('info_block', false);
	}

	public function begin($game_id)
	{
		$return = -1;
		$create = true;

		$start_time	= time();
		$game_id	= (int) $game_id;
		$user_id	= (int) $this->user->data['user_id'];

		if (!$this->request->is_set_post('start'))
		{
			$sql = 'SELECT randgid1, randgid2, session_id
					FROM ' . ARCADE_SESSIONS_TABLE . "
					WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
					AND game_id = $game_id
					AND user_id = $user_id";
			$result = $this->db->sql_query($sql);
			$row = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			if ($row)
			{
				$create = false;

				if (!$this->user->data['is_registered'])
				{
					if (!$this->game_sid)
					{
						$this->game_sid = $row['session_id'];
					}

					$return = $game_id * $row['randgid1'] ^ $row['randgid2'];
				}
			}
		}

		if ($create)
		{
			$this->delete();
			$this->game_sid = md5(uniqid($this->user->ip));
			$rand_nums = $this->arcade->rand_num($game_id);

			$sql_ary = array(
				'session_id'		=> (string) $this->game_sid,
				'phpbb_session_id'	=> (string) $this->user->session_id,
				'game_id'			=> $game_id,
				'user_id'			=> $user_id,
				'game_popup'		=> $this->game_popup,
				'randchar1'			=> 0,
				'randchar2'			=> 0,
				'randgid1'			=> $rand_nums['r1'],
				'randgid2'			=> $rand_nums['r2'],
				'start_time'		=> $start_time,
				'post_data'			=> ''
			);

			$this->db->sql_query('INSERT INTO ' . ARCADE_SESSIONS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));

			$this->set_cookie(true);
		}

		return ($create) ? $rand_nums['rgid'] : $return;
	}

	public function add_game_randchar($session_id = false, $jvah5_scorevar = false)
	{
		if (!$session_id)
		{
			$session_id = $this->game_sid;
		}

		if (!$session_id)
		{
			return array();
		}

		$rand_nums = $this->arcade->rand_num();

		$sql_ary = array(
			'randchar1' => $rand_nums['r1'],
			'randchar2' => $rand_nums['r2'],
			'microtime' => time()
		);

		$sql = 'UPDATE ' . ARCADE_SESSIONS_TABLE . ' SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . "
				WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
				AND user_id = " . (int) $this->user->data['user_id'] . "
				AND session_id = '" . $this->db->sql_escape($session_id) . "'";
		$this->db->sql_query($sql);

		if ($this->config['cookie_secure'] && $jvah5_scorevar != 'h5verify')
		{
			$sql = 'SELECT game_popup
					FROM ' . ARCADE_SESSIONS_TABLE . "
					WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
					AND user_id = " . (int) $this->user->data['user_id'] . "
					AND session_id = '" . $this->db->sql_escape($session_id) . "'";
			$result = $this->db->sql_query($sql);
			$sql_ary['game_popup'] = (int) $this->db->sql_fetchfield('game_popup');
			$this->db->sql_freeresult($result);
		}

		return $sql_ary;
	}

	public function security($type)
	{
		if (!$type || !$this->game_sid || !$this->user->data['is_registered'])
		{
			return;
		}

		$sql = 'UPDATE ' . ARCADE_SESSIONS_TABLE . ' SET security = ' . (int) $type . "
				WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
				AND user_id = " . (int) $this->user->data['user_id'] . "
				AND session_id = '" . $this->db->sql_escape($this->game_sid) . "'";
		$this->db->sql_query($sql);
	}

	public function uid()
	{
		$uid = false;

		if ($this->game_sid)
		{
			$sql = 'SELECT user_id
					FROM ' . ARCADE_SESSIONS_TABLE . "
					WHERE session_id = '" . $this->db->sql_escape($this->game_sid) . "'";
			$result = $this->db->sql_query($sql);
			$uid = (int) $this->db->sql_fetchfield('user_id');
			$this->db->sql_freeresult($result);
		}

		return $uid;
	}

	public function pd($pd)
	{
		$s_pd = $this->get('pd');
		return (!$s_pd || $s_pd === md5($pd)) ? true : false;
	}

	public function delete()
	{
		$sql = 'DELETE FROM ' . ARCADE_SESSIONS_TABLE . "
			WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
			AND user_id = " . (int) $this->user->data['user_id'];

		$this->db->sql_query($sql);

		$this->set_cookie(false, false, false);
	}

	private function get($p, $default = '')
	{
		return $this->request->variable($this->config['cookie_name'] . "_arcade_{$p}", $default, false, \phpbb\request\request_interface::COOKIE);
	}

	/**
	* Set arcade cookie, this is used to track the game id,
	* sid and popup value
	*/
	public function set_cookie($create = false, $show = false, $delete_data = true)
	{
		// The cookies is removed once the score.php output
		// is displayed. It just used to check whether of not
		// to use the simple header

		// If the function is called with no parameters and show
		// set to true it will return all cookies formatted to be displayed
		if ($show)
		{
			$return = 'Not game_sid cookie!';

			if (!$create && empty($this->game_sid))
			{
				$return = '<b>COOKIE</b><br><br><pre>';
				$return .= var_export($_COOKIE, true);
				$return .= '</pre>';
			}

			return $return;
		}

		if ($create)
		{
			$set_time = intval(time() + $this->arcade_config['session_length']);
			$this->user->set_cookie('arcade_sid', $this->game_sid, $set_time);
			$this->user->set_cookie('arcade_popup', $this->game_popup, $set_time);
		}
		else
		{
			$set_time = (time() - intval($this->arcade_config['session_length'] * 2));
			$this->user->set_cookie('arcade_sid', '', $set_time);

			if ($delete_data)
			{
				$this->user->set_cookie('arcade_popup', '', $set_time);
				$this->user->set_cookie('arcade_pd', '', $set_time);
			}
		}
	}
}
