<?php
/**
*
* @package phpBB Arcade
* @version $Id: arcade.php 2113 2018-11-30 11:02:27Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class arcade extends main
{
	public $page_title = '';
	public $display, $get, $game, $challenge, $tournament, $phpbb, $points, $shout, $portal, $ext, $data, $cats, $games, $tours;
	public $keyoptions = array('arcade_pm' => 0, 'challenge' => 1, 'view_avatars' => 2, 'view_game_image' => 3, 'view_popup_icon' => 4, 'bbcode' => 5, 'smilies' => 6, 'game_over_random_games' => 7, 'game_over_sound' => 8, 'game_over_animation' => 9, 'game_over_animation_sound' => 10);
	protected $phpbb_dispatcher, $container, $path_helper, $ext_manager, $db, $cache, $config, $auth, $request, $user, $template, $arcade_cache, $arcade_config, $arcade_auth, $file_functions, $root_path, $php_ext, $admin_path;

	public function __construct($phpbb_dispatcher, $container, $path_helper, $ext_manager, $db, $cache, $config, $auth, $request, $user, $template, $arcade_cache, $arcade_config, $arcade_auth, $file_functions, $root_path, $php_ext, $adm_relative_path)
	{
		$this->phpbb_dispatcher = $phpbb_dispatcher;
		$this->container = $container;
		$this->path_helper = $path_helper;
		$this->ext_manager = $ext_manager;
		$this->db = $db;
		$this->cache = $cache;
		$this->config = $config;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->file_functions = $file_functions;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->admin_path = $root_path . $adm_relative_path;
	}

	public function main($type = '')
	{
		$this->set_data($type);

		$this->template->assign_vars(array(
			'S_IN_ARCADE'		=> true,

			'LOADING_IMG1'		=> $this->get()->image('src', 'img', 'loading1.gif'),
			'LOADING_IMG2'		=> $this->get()->image('src', 'img', 'loading2.gif'),
			'ARCADE_LOGO'		=> $this->get()->image('full', 'img', 'logo_transparent.png', 'PHPBBARCADE_GAME', true)
		));

		if (defined('ADMIN_START'))
		{
			$this->header('path');
		}
	}

	public function display()
	{
		if (!isset($this->display))
		{
			$this->display = $this->container('display');
		}

		return $this->display;
	}

	public function get()
	{
		if (!isset($this->get))
		{
			$this->get = $this->container('content');
		}

		return $this->get;
	}

	public function game($use_cookie_popup = false)
	{
		if (!isset($this->game))
		{
			$this->game = $this->container('game', true, false, $use_cookie_popup);
		}

		return $this->game;
	}

	public function points()
	{
		if (!isset($this->points))
		{
			$this->points = $this->container('points', true);
		}

		return $this->points;
	}

	public function shout()
	{
		if (!isset($this->shout))
		{
			$this->shout = $this->container('shout', true);
		}

		return $this->shout;
	}

	public function portal()
	{
		if (!isset($this->portal))
		{
			$this->portal = $this->container('portal', true);
		}

		return $this->portal;
	}

	public function ext()
	{
		if (!isset($this->ext))
		{
			$this->ext = $this->container('ext_helper');
		}

		return $this->ext;
	}

	public function cats()
	{
		if (!isset($this->cats))
		{
			$this->cats = $this->arcade_cache->obtain_arcade_cats();
		}

		return $this->cats;
	}

	public function games()
	{
		if (!isset($this->games))
		{
			$this->games = $this->arcade_cache->obtain_arcade_games();
		}

		return $this->games;
	}

	public function tours()
	{
		if (!isset($this->tours))
		{
			$this->tours = $this->arcade_cache->obtain_arcade_tours();
		}

		return $this->tours;
	}

	public function hidden_users($reload = false)
	{
		if (!isset($this->hidden_users) || $reload)
		{
			$this->hidden_users = $this->arcade_cache->obtain_arcade_hidden_scores();
		}

		return $this->hidden_users;
	}

	public function challenge()
	{
		if (!isset($this->challenge))
		{
			$this->challenge = $this->container('challenge', true, false, true);
		}

		return $this->challenge;
	}

	public function tournament()
	{
		if (!isset($this->tournament))
		{
			$this->tournament = $this->container('tournament', true, false, true);
		}

		return $this->tournament;
	}

	public function phpbb()
	{
		if (!isset($this->phpbb))
		{
			$this->phpbb = $this->container('phpbb');
		}

		return $this->phpbb;
	}

	public function data($key = false)
	{
		if (!isset($this->data))
		{
			$this->data = array(
				'popup_icon'	=> '',
				'no_avatar'		=> ''
			);

			if ($this->arcade_config['display_game_popup_icon'] && $popup_icon = $this->get()->image('src', 'img', 'popup.png'))
			{
				$this->data['popup_icon'] = $popup_icon;
			}

			if ($this->optionget('view_avatars') && $no_avatar = $this->get()->image('src', 'img', 'noavatar.gif'))
			{
				$this->data['no_avatar'] = $no_avatar;
			}

			$this->data['html5_icon'] = $this->get()->image('full', 'img', 'html5_icon.png', 'GAME_HTML5', true, '', 'arcade_watermark');
			$this->data['flash_icon'] = $this->get()->image('full', 'img', 'flash_icon.png', 'GAME_FLASH', true, '', 'arcade_watermark');
		}

		if ($key)
		{
			if (!isset($this->data[$key]))
			{
				$this->data[$key] = false;
			}

			return ($this->data[$key]) ? true : false;
		}

		return $this->data;
	}

	public function gbl($params = false, $lang = 'arcade')
	{
		return ($this->game()->session->game_popup) ? $this->close_win() : $this->back_link($params, $lang);
	}

	/**
	* All-encompasing sync function
	*
	* Modes:
	* - category		Sync category data
	* - game			Sync game data
	* - super_champ		Sync super champion data
	* - rating			Sync rating data
	* - total_data		Sync games, plays, downloads, users, reports data
	*/
	public function sync($mode, $id = '')
	{
		if ($id == '' && ($mode == 'rating' || $mode == 'game'))
		{
			trigger_error('ARCADE_SYNC_MODE_NOT_SUPPORTED');
		}

		switch($mode)
		{
			case 'category':
				$sql = 'SELECT cat_id
					FROM ' . ARCADE_CATS_TABLE;

				if ($id != '')
				{
					if (!is_array($id))
					{
						$id = array((int) $id);
					}

					$sql .= ' WHERE ' . $this->db->sql_in_set('cat_id', array_map('intval', $id)) . ' GROUP BY cat_id';
				}

				$cat_result = $this->db->sql_query($sql);

				while ($cat_row = $this->db->sql_fetchrow($cat_result))
				{
					$cat_id = $cat_row['cat_id'];

					$sql = 'SELECT game_installdate
							FROM ' . ARCADE_GAMES_TABLE . '
							WHERE cat_id = ' . (int) $cat_id . '
							ORDER BY game_installdate DESC';
					$result = $this->db->sql_query_limit($sql, 1);
					$cat_last_game_installdate = $this->db->sql_fetchfield('game_installdate');
					$this->db->sql_freeresult($result);

					$sql = 'SELECT COUNT(*) AS cat_games
							FROM ' . ARCADE_GAMES_TABLE . '
							WHERE cat_id = ' . (int) $cat_id;
					$result = $this->db->sql_query($sql);
					$cat_games = $this->db->sql_fetchfield('cat_games');
					$this->db->sql_freeresult($result);

					$sql_array = array(
						'SELECT'		=> 'SUM(p.total_plays) AS cat_plays',
						'FROM'			=> array(
							ARCADE_GAMES_TABLE	=> 'g',
						),
						'LEFT_JOIN'		=> array(
							array(
								'FROM'	=> array(ARCADE_PLAYS_TABLE => 'p'),
								'ON'	=> 'g.game_id = p.game_id'
							),
						),
						'WHERE'			=> 'g.cat_id = ' . (int) $cat_id . '
							AND g.game_id = p.game_id',
					);

					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query($sql);
					$cat_plays = (int) $this->db->sql_fetchfield('cat_plays');
					$this->db->sql_freeresult($result);

					$sql_ary = array(
						'cat_games'					=> (int) $cat_games,
						'cat_plays'					=> (int) $cat_plays,
						'cat_last_game_installdate'	=> (int) $cat_last_game_installdate,
					);

					$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
							SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
							WHERE cat_id = ' . (int) $cat_id;
					$this->db->sql_query($sql);
				}
				$this->db->sql_freeresult($cat_result);
			break;

			case 'game':
				if (!is_array($id))
				{
					$id = ($id) ? array((int) $id) : array();
				}

				$sql = 'SELECT SUM(total_plays) AS game_plays, game_id
						FROM ' . ARCADE_PLAYS_TABLE . '
						WHERE ' . $this->db->sql_in_set('game_id', array_map('intval', $id)) . '
						GROUP BY game_id';
				$result = $this->db->sql_query($sql);

				$plays_id = array();
				while ($row = $this->db->sql_fetchrow($result))
				{
					$plays_id[] = $row['game_id'];
					$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
							SET game_plays = ' . (int) $row['game_plays'] . '
							WHERE game_id = ' . (int) $row['game_id'];
					$this->db->sql_query($sql);
				}
				$this->db->sql_freeresult($result);

				$no_plays = array();
				if (!empty($plays_id))
				{
					foreach ($id as $game_id)
					{
						if (!in_array($game_id, $plays_id))
						{
							$no_plays[] = $game_id;
						}
					}
				}
				else
				{
					$no_plays = $id;
				}

				if (!empty($no_plays))
				{
					$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
							SET game_plays = 0
							WHERE ' . $this->db->sql_in_set('game_id', $no_plays);
					$this->db->sql_query($sql);
				}
			break;

			case 'super_champ':
				if (!is_array($id))
				{
					$id = array((int) $id);
				}

				$sql = 'SELECT game_id, game_highuser, game_highscore, game_highdate
						FROM ' . ARCADE_GAMES_TABLE . '
						WHERE ' . $this->db->sql_in_set('game_id', array_map('intval', $id)) . '
						AND game_highscore > 0';
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$sql_ary = array(
						'user_id'		=> (int) $row['game_highuser'],
						'score'			=> $row['game_highscore'],
						'score_date'	=> $row['game_highdate']
					);

					$this->game()->update_super_score($sql_ary, $row['game_id']);
				}
				$this->db->sql_freeresult($result);
			break;

			case 'rating':
				if (!is_array($id))
				{
					$id = ($id) ? array((int) $id) : array();
				}

				$sql = 'SELECT game_id, COUNT(*) AS game_votetotal, SUM(game_rating) AS game_votesum
						FROM ' . ARCADE_RATING_TABLE . '
						WHERE ' . $this->db->sql_in_set('game_id', array_map('intval', $id)) . '
						GROUP BY game_id';
				$result = $this->db->sql_query($sql);

				$plays_id = array();
				while ($row = $this->db->sql_fetchrow($result))
				{
					$plays_id[] = $row['game_id'];
					$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
							SET game_votetotal	= ' . (int) $row['game_votetotal'] . ',
								game_votesum	= ' . (int) $row['game_votesum'] . '
							WHERE game_id = ' . (int) $row['game_id'];
					$this->db->sql_query($sql);
				}
				$this->db->sql_freeresult($result);

				$no_plays = array();
				if (count($plays_id))
				{
					foreach ($id as $game_id)
					{
						if (!in_array($game_id, $plays_id))
						{
							$no_plays[] = $game_id;
						}
					}
				}
				else
				{
					$no_plays = $id;
				}

				if (count($no_plays))
				{
					$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
							SET game_votetotal = 0, game_votesum = 0
							WHERE ' . $this->db->sql_in_set('game_id', $no_plays);
					$this->db->sql_query($sql);
				}
			break;

			case 'total_data':
				if (!is_array($id))
				{
					$id = array($id);
				}

				if (in_array('all' , $id))
				{
					$this->arcade_config->set('install_games', intval($this->get()->total('game', 'games')));
				}

				if (in_array('plays' , $id) || in_array('all' , $id))
				{
					$play_data = $this->get()->total('game', 'plays_data');
					$this->arcade_config->set('total_plays', intval($play_data['t_plays']), false);
					$this->arcade_config->set('total_plays_time', intval($play_data['t_time']), false);
				}

				if (in_array('downloads' , $id) || in_array('all' , $id))
				{
					$this->arcade_config->set('total_downloads', intval($this->get()->total('game', 'all_downloads')), false);
				}

				if (in_array('reports' , $id) || in_array('all' , $id))
				{
					$this->arcade_config->set('reports_open', intval($this->get()->total('game', 'reports_open')));
				}

				if (in_array('challenge' , $id) || in_array('all' , $id))
				{
					$challenge_total = $this->get()->total('game', 'total_challs');
					$this->arcade_config->set('challenge_total_plays', intval($challenge_total['total_plays']), false);
					$this->arcade_config->set('challenge_total_plays_time', intval($challenge_total['total_times']), false);
				}

				if (in_array('tour' , $id) || in_array('all' , $id))
				{
					$tour_total = $this->get()->total('game', 'tour_total_data');

					$this->arcade_config->set('tour_total', intval($this->get()->total('game', 'total_tours', true)));
					$this->arcade_config->set('tour_total_plays', intval($tour_total['total_plays']), false);
					$this->arcade_config->set('tour_total_plays_time', intval($tour_total['total_times']), false);
				}
			break;

			case 'users_total_data':
				if ($id && !is_array($id))
				{
					$id = array((int) $id);
				}

				$sql = 'UPDATE ' . ARCADE_USERS_TABLE . ' SET ' . $this->db->sql_build_array('UPDATE', array(
					'arcade_total_played'		=> 0,
					'arcade_total_plays'		=> 0,
					'arcade_total_time'			=> 0,
					'arcade_total_wins'			=> 0,
					'arcade_total_super_scores'	=> 0,
					'arcade_total_downloads'	=> 0
				));

				if ($id)
				{
					$sql .= ' WHERE ' . $this->db->sql_in_set('user_id', array_map('intval', $id));
				}
				$this->db->sql_query($sql);

				$users_total_data = array();
				$sql_array = array(
					'SELECT'		 => 'u.user_id, COUNT(p.game_id) AS played_games, SUM(p.total_plays) AS total_plays, SUM(p.total_time) AS total_time',
					'FROM'			 => array(USERS_TABLE => 'u'),
					'LEFT_JOIN'		 => array(array('FROM' => array(ARCADE_PLAYS_TABLE => 'p'), 'ON' => 'u.user_id = p.user_id')),
					'WHERE'			 => 'u.user_id = p.user_id',
					'GROUP_BY'		 => 'u.user_id'
				);

				if ($id)
				{
					$sql_array['WHERE'] .= ' AND ' . $this->db->sql_in_set('u.user_id', array_map('intval', $id));
				}

				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$users_total_data[$row['user_id']] = array(
						'arcade_total_played'	=> $row['played_games'],
						'arcade_total_plays'	=> $row['total_plays'],
						'arcade_total_time'		=> $row['total_time'],
					);
				}
				$this->db->sql_freeresult($result);

				$sql_array = array(
					'SELECT'		 => 'u.user_id, COUNT(g.game_id) AS total_wins',
					'FROM'			 => array(USERS_TABLE => 'u'),
					'LEFT_JOIN'		 => array(array('FROM' => array(ARCADE_GAMES_TABLE => 'g'), 'ON' => 'u.user_id = g.game_highuser')),
					'WHERE'			 => 'u.user_id = g.game_highuser',
					'GROUP_BY'		 => 'u.user_id'
				);

				if ($id)
				{
					$sql_array['WHERE'] .= ' AND ' . $this->db->sql_in_set('u.user_id', array_map('intval', $id));
				}

				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$users_total_data[$row['user_id']]['arcade_total_wins'] = $row['total_wins'];
				}
				$this->db->sql_freeresult($result);

				$sql_array = array(
					'SELECT'		 => 'u.user_id, COUNT(s.game_id) AS total_super_scores',
					'FROM'			 => array(USERS_TABLE => 'u'),
					'LEFT_JOIN'		 => array(array('FROM' => array(ARCADE_SUPER_SCORES_TABLE => 's'), 'ON' => 'u.user_id = s.user_id')),
					'WHERE'			 => 'u.user_id = s.user_id',
					'GROUP_BY'		 => 'u.user_id'
				);

				if ($id)
				{
					$sql_array['WHERE'] .= ' AND ' . $this->db->sql_in_set('u.user_id', array_map('intval', $id));
				}

				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$users_total_data[$row['user_id']]['arcade_total_super_scores'] = $row['total_super_scores'];
				}
				$this->db->sql_freeresult($result);

				$sql_array = array(
					'SELECT'		 => 'u.user_id, SUM(d.total) AS total_downloads',
					'FROM'			 => array(USERS_TABLE => 'u'),
					'LEFT_JOIN'		 => array(array('FROM' => array(ARCADE_DOWNLOAD_TABLE => 'd'), 'ON' => 'u.user_id = d.user_id')),
					'WHERE'			 => 'u.user_id = d.user_id',
					'GROUP_BY'		 => 'u.user_id'
				);

				if ($id)
				{
					$sql_array['WHERE'] .= ' AND ' . $this->db->sql_in_set('u.user_id', array_map('intval', $id));
				}

				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$users_total_data[$row['user_id']]['arcade_total_downloads'] = $row['total_downloads'];
				}
				$this->db->sql_freeresult($result);

				foreach ($users_total_data as $user_id => $row)
				{
					$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
							SET ' . $this->db->sql_build_array('UPDATE', $users_total_data[$user_id]) . '
							WHERE user_id = ' . (int) $user_id;
					$this->db->sql_query($sql);
				}
				unset($users_total_data);
			break;

			default:
				trigger_error('NO_MODE');
			break;
		}
	}

	public function hidden_score($game_id, $user_id)
	{
		return ($this->user->data['user_id'] != $user_id && !empty($this->hidden_users()[$game_id][$user_id])) ? true : false;
	}

	public function page_title($key = '', $ex_key = '', $add_nav = '', $ext_params = false, $ignore_first_nav = false)
	{
		global $arcade_page;

		$extra_nav = '';
		if ($ext_params)
		{
			$ext_param = explode('=', $ext_params);

			if (count($ext_param) > 1)
			{
				list($param_name, $param_value) = $ext_param;
				$param_value = (int) $param_value;

				if ($param_value)
				{
					switch ($param_name)
					{
						case 'st':
						case 'c':
							if ($param_value && ($cat_name = $this->get()->cat_field($param_value, 'cat_name', true)) !== false)
							{
								$extra_nav = $this->user->lang('ARCADE_CATEGORY_NAME', $cat_name);
								$key = ((!empty($this->user->lang[$key])) ? $this->user->lang[$key] : $key) . ' :: ' . $extra_nav;
							}
						break;

						case 'g':
							if ($param_value && ($game_name = $this->get()->game_field($param_value, 'game_name', true)) !== false)
							{
								$extra_nav = $this->user->lang('ARCADE_V_GAME_NAME', $game_name);
								$key = ((!empty($this->user->lang[$key])) ? $this->user->lang[$key] : $key) . ' :: ' . $extra_nav;
							}
						break;
					}
				}
			}
		}

		$arcade_page		= ($arcade_page == 'tour') ? 'tournament' : $arcade_page;
		$main				= $this->lang_value(strtoupper($arcade_page));
		$title				= $main . (($key) ? '&nbsp;/&nbsp;' . $this->lang_value($key) : '');
		$this->page_title	= $main . (($ex_key) ? '&nbsp;&bull;&nbsp;' . $this->lang_value($ex_key) : '') . (($key) ? '&nbsp;-&nbsp;' . $this->lang_value($key) : '');

		$this->template->assign_var('L_ARCADE_TITLE', $title);

		if (!$ignore_first_nav && $add_nav && $key && $key != $this->lang_value($key, true))
		{
			$title = ($extra_nav) ? str_replace(' :: ' . $extra_nav, '', $this->page_title) : $this->page_title;
			$search = ($ex_key) ? '&nbsp;&bull;&nbsp;' : '&nbsp;-&nbsp;';
			$this->add_navlink('add', $add_nav, str_replace("$main$search", '', $title), '', false);
		}

		if ($extra_nav)
		{
			$add_nav .= "&amp;{$param_name}={$param_value}";
			$this->add_navlink('add', $add_nav, $extra_nav, '', false);
		}
	}

	public function return_links($game_data, $br = true)
	{
		$s_content_flow_begin = ($this->user->lang['DIRECTION'] == 'ltr') ? 'left' : 'right';

		return (($br) ? '<br><br>' : '') . (($this->game()->session->game_popup) ? sprintf($this->user->lang['ARCADE_RETURN_LINKS_POPUP'], '<a class="'. $s_content_flow_begin .'" href="'. $this->url("mode=popup&amp;g={$game_data['game_id']}") .'">', $game_data['game_name'], '</a>') . $this->refresh_close_win($game_data) : sprintf($this->user->lang['ARCADE_RETURN_LINKS'], '<a class="'. $s_content_flow_begin .'" href="'. $this->url("mode=play&amp;g={$game_data['game_id']}") .'">', $game_data['game_name'], '</a>', '<a class="'. $s_content_flow_begin .'" href="'. $this->url("mode=cat&amp;c={$game_data['cat_id']}&amp;g={$game_data['game_id']}#g{$game_data['game_id']}") .'">', $game_data['cat_name'], '</a>', '<a class="'. $s_content_flow_begin .'" href="'. $this->url() .'">', '</a>'));
	}

	public function add_navlink($method, $params, $lkey = '', $cat_data = '', $lvc = true)
	{
		if ($method == 'add')
		{
			$this->template->assign_block_vars('navlinks', array(
				'FORUM_NAME'	=> ($lvc) ? $this->lang_value($lkey) : $lkey,
				'U_VIEW_FORUM'	=> $this->url($params)
			));
		}
		else if (!empty($cat_data))
		{
			if (!$this->arcade_auth->acl_get('c_view', $cat_data['cat_id']))
			{
				return $cat_data;
			}

			if ($method == 'cat')
			{
				// Get category parents
				$cat_parents = $this->get()->arcade_parents($cat_data);

				if (!empty($cat_parents))
				{
					// Build navigation links
					foreach ($cat_parents as $parent_cat_id => $parent_data)
					{
						list($parent_name, $parent_type) = array_values($parent_data);

						// Skip this parent if the user does not have the permission to view it
						if (!$this->arcade_auth->acl_get('c_view', $parent_cat_id))
						{
							continue;
						}

						$this->template->assign_block_vars('navlinks', array(
							'S_IS_CAT'		=> ($parent_type == ARCADE_CAT) ? true : false,
							'S_IS_LINK'		=> ($parent_type == ARCADE_LINK) ? true : false,
							'S_IS_POST'		=> ($parent_type == ARCADE_CAT_GAMES) ? true : false,
							'FORUM_NAME'	=> $parent_name,
							'FORUM_ID'		=> $parent_cat_id,
							'U_VIEW_FORUM'	=> $this->url('mode=cat&amp;c=' . $parent_cat_id)
						));
					}
				}
			}

			$this->template->assign_block_vars('navlinks', array(
				'S_IS_CAT'		=> ($cat_data['cat_type'] == ARCADE_CAT) ? true : false,
				'S_IS_LINK'		=> ($cat_data['cat_type'] == ARCADE_LINK) ? true : false,
				'S_IS_POST'		=> ($cat_data['cat_type'] == ARCADE_CAT_GAMES) ? true : false,
				'FORUM_NAME'	=> ($method == 'cat_stat') ? sprintf($this->user->lang['ARCADE_CAT_STATS'], $cat_data['cat_name']) : $cat_data['cat_name'],
				'FORUM_ID'		=> $cat_data['cat_id'],
				'U_VIEW_FORUM'	=> $this->url('mode=' . (($method == 'cat_stat') ? 'stats' : 'cat') . '&amp;c=' . $cat_data['cat_id'])
			));

			if ($params && $method == 'cat_game')
			{
				$this->add_navlink('add', $params . ((!empty($cat_data['tour_id'])) ? '&amp;tour_id=' . $cat_data['tour_id'] : '') . '&amp;g=' . $cat_data['game_id'], $cat_data['game_name'], '', false);
			}

			$this->template->assign_vars(array(
				'CAT_NAME'			=> $cat_data['cat_name'],
				'U_VIEW_CATEGORY'	=> $this->url('mode=cat&amp;c=' . $cat_data['cat_id'])
			));

			return $cat_data;
		}
	}

	public function verify_age($type, $age, $back_link = '')
	{
		// Founder check and Bots exemption age limit
		if (($this->arcade_config['founder_exempt'] && $this->user->data['user_type'] == USER_FOUNDER) || (!$this->user->data['is_registered'] && $this->user->data['is_bot']))
		{
			return;
		}

		if (!$this->user->data['is_registered'])
		{
			$message = ($type == 'cat') ? 'ARCADE_BLOCKED_CAT_VIEW' : 'ARCADE_BLOCKED_GAME_PLAY';
			trigger_error($this->user->lang[$message] . $back_link);
		}

		$user_age = $this->get()->user_age();

		if ($user_age === '')
		{
			$message = ($type == 'cat') ? 'ARCADE_BLOCKED_NO_AGE_CAT' : 'ARCADE_BLOCKED_NO_AGE_PLAY';
			trigger_error($this->user->lang[$message] . $back_link);
		}

		if ($user_age < $age)
		{
			$message = ($type == 'cat') ? 'ARCADE_BLOCKED_CAT_AGE' : 'ARCADE_BLOCKED_PLAY_AGE';
			trigger_error(sprintf($this->user->lang[$message], $age) . $back_link);
		}
	}

	public function limit_play($back_link = '')
	{
		if ($this->arcade_config['limit_play'] != LIMIT_PLAY_TYPE_NONE)
		{
			$total_posts = intval($this->arcade_config['limit_play_total_posts']);
			$days = intval($this->arcade_config['limit_play_days']);
			$posts = intval($this->arcade_config['limit_play_posts']);
			$current_time = time();
			$old_time = $current_time - (60 * 60 * 24 * $days);
			$error = array();

			if ($total_posts && $this->arcade_config['limit_play'] == LIMIT_PLAY_TYPE_POSTS || $this->arcade_config['limit_play'] == LIMIT_PLAY_TYPE_BOTH)
			{
				$sql = 'SELECT COUNT(post_id) AS total_posts
						FROM ' . POSTS_TABLE . '
						WHERE poster_id = ' . (int) $this->user->data['user_id'] . '
						AND post_postcount > 0';
				$result = $this->db->sql_query($sql);
				$actual_total_posts = (int) $this->db->sql_fetchfield('total_posts');
				$this->db->sql_freeresult($result);

				if ($actual_total_posts < $total_posts)
				{
					$error[] = sprintf($this->user->lang['ARCADE_LIMIT_PLAY_TYPE_POSTS'], $total_posts, $total_posts - $actual_total_posts);
				}
			}

			if ($days && $posts && $this->arcade_config['limit_play'] == LIMIT_PLAY_TYPE_DAYS || $this->arcade_config['limit_play'] == LIMIT_PLAY_TYPE_BOTH)
			{
				$sql = 'SELECT COUNT(post_id) AS total_posts
						FROM ' . POSTS_TABLE . '
						WHERE poster_id = ' . (int) $this->user->data['user_id'] . '
						AND post_time
						BETWEEN ' . (int) $old_time . ' AND ' . (int) $current_time . '
						AND post_postcount > 0';
				$result = $this->db->sql_query($sql);
				$actual_posts_per_day = (int) $this->db->sql_fetchfield('total_posts');
				$this->db->sql_freeresult($result);

				if ($actual_posts_per_day < $posts)
				{
					$error[] = sprintf($this->user->lang['ARCADE_LIMIT_PLAY_TYPE_DAYS'], $posts, $days, $posts - $actual_posts_per_day);
				}
			}

			if (count($error))
			{
				trigger_error(implode('<br><br>', $error) . (($back_link) ? $back_link : $this->back_link()));
			}
		}
	}

	public function set_game_size(&$new_game_width, &$new_game_height, $game_width, $game_height, $game_swf, $game_type)
	{
		$new_game_width	 = (!empty($this->arcade_config['game_width']))  ? $this->arcade_config['game_width']  : $game_width;
		$new_game_height = (!empty($this->arcade_config['game_height'])) ? $this->arcade_config['game_height'] : $game_height;

		if ($this->arcade_config['game_autosize'] && $game_type == GAME_TYPE_FLASH)
		{
			$game_file = $this->set_path($game_swf);

			if (file_exists($game_file))
			{
				$stats = getimagesize($game_file);

				if ($stats !== false)
				{
					$new_game_width	 = $stats[0];
					$new_game_height = $stats[1];
				}
			}
		}
	}

	public function number_format($num, $default = false)
	{
		$num = (float) $num;

		if ($default)
		{
			return number_format($num, 2, '.', '');
		}

		if (!$num)
		{
			return 0;
		}

		$decimals = explode('.', $num);
		if (!empty($decimals[1]) || !empty($decimals[2]))
		{
			$decimals = strlen(rtrim($decimals[1], '0'));
			$decimals = ($decimals > 2) ? 2 : $decimals;
		}
		else
		{
			$decimals = 0;
		}

		return number_format($num, $decimals, $this->user->lang['SEPARATOR_DECIMAL'], $this->user->lang['SEPARATOR_THOUSANDS']);
	}

	/**
	* Take seconds and convert to readable format
	* Example usage of filter:
	* To return days, hours, minutes and seconds
	* $filter = 'day|hour|minute|second';
	* If $filter is set to false it returns full result
	*/
	public function time_format($secs, $full_label = false, $first_chars = false, $filter = false)
	{
		$output = '';
		$filter = ($filter) ? explode('|', strtolower($filter)) : false;

		$minute = ($full_label) ? 'minute' : 'min';
		$second = ($full_label) ? 'second' : 'sec';

		$time_array = array(
			'year'		=> 60 * 60 * 24 * 365,
			'month'		=> 60 * 60 * 24 * 30,
			'week'		=> 60 * 60 * 24 * 7,
			'day'		=> 60 * 60 * 24,
			'hour'		=> 60 * 60,
			$minute		=> 60,
			$second		=> 0,
		);

		foreach ($time_array as $key => $value)
		{
			if ($filter && !in_array($key, $filter))
			{
				continue;
			}

			$item = ($value) ? intval(intval($secs) / $value) : intval($secs);
			if ($item > 0)
			{
				$secs = $secs - ($item * $value);
				$text = $this->user->lang['TIME_' . strtoupper($key) . (($item > 1) ? 'S' : '')];

				if ($first_chars)
				{
					$this->first_chars($text);
					$output .= " $item$text.";
				}
				else
				{
					$output .= " $item $text";
				}
			}
		}

		return $output;
	}

	public function hour($value)
	{
		return intval($value * 3600);
	}

	public function first_chars(&$string, $cut = false, $value = 2, $encoding = 'UTF-8')
	{
		$str = substr($string, 0, 1);
		$value = (is_array($value)) ? $value : array((int) $value);

		if ($cut && in_array($str, $value))
		{
			$string = substr($string, 1);
		}
		else if (!$cut)
		{
			$string = mb_substr($string, 0, 1, $encoding);
		}
	}

	public function max_chars(&$text, $search = ',', $max = 255)
	{
		if (strlen($text) > $max)
		{
			for ($i=0; $max<strlen($text); $i++)
			{
				$last_value = $search . substr(strrchr($text, $search), 1);
				$text = str_replace($last_value, '', $text);
			}
		}
	}

	public function check_addslashes($str)
	{
		if (strpos($str, '\\') !== false)
		{
			$str = str_replace('\\', '', $str);
			return $this->check_addslashes($str);
		}

		if (strpos(str_replace("\'", "", $str), "'") !== false)
		{
			return addslashes($str);
		}
		else
		{
			return $str;
		}
	}

	public function download_groups_days($group_ids, $value = false)
	{
		if (!is_array($group_ids))
		{
			$group_ids = array((int) $group_ids);
		}

		$return = array();
		$group_data = explode(',', ($value) ? $value : $this->arcade_config['download_per_day_groups']);

		foreach ($group_data as $data)
		{
			if (!empty($data))
			{
				$gd = explode(':', $data);

				if (!empty($gd[1]) && in_array($gd[0], $group_ids))
				{
					$return[$gd[0]] = (int) $gd[1];
				}
			}
		}

		return ($value === null) ? ((count($return)) ? intval(array_shift($return)) : 0) : $return;
	}

	/**
	* Validate Date
	* @param String $string a date in the yyyy-mm-dd format
	*/
	public function validate_date($date_string, $time_string = '')
	{
		$date = explode('-', $date_string);
		if (empty($date) || count($date) != 3)
		{
			return array();
		}

		list($year, $mon, $day) = array_map('intval', $date);

		if (!checkdate($mon, $day, $year))
		{
			return array();
		}

		$return = array(
			'year'	=> $year,
			'mon'	=> $mon,
			'day'	=> $day
		);

		if ($time_string)
		{
			if (!count($time = $this->validate_time($time_string)))
			{
				return array();
			}

			$return += $time;
		}

		return $return;
	}

	/**
	* Validate Time
	* @param String $string a time in the hh:mm format
	*/
	public function validate_time($time_string)
	{
		$time = explode(':', $time_string);
		if (empty($time) || count($time) != 2)
		{
			return array();
		}

		list($hour, $min) = array_map('intval', $time);
		if (($hour < 0 || $hour > 23) || ($min < 0 || $min > 59))
		{
			return array();
		}

		return array(
			'hour'	=> $hour,
			'min'	=> $min
		);
	}

	public function time_stamp($year, $monday = 1, $day = 1, $hour = 0, $min = 0, $sec = 0, $timezone = true)
	{
		$zone_offset = 0;

		if ($timezone)
		{
			$now = $this->user->create_datetime();
			$zone_offset = $now->getOffset();
		}

		$time_stamp = gmmktime((int) $hour, (int) $min, (int) $sec, (int) $monday, (int) $day, (int) $year);

		if ($time_stamp === false || $time_stamp === -1)
		{
			$time_stamp = 0;
		}

		$time_stamp -= $zone_offset;

		return (int) $time_stamp;
	}

	public function gen_board_datetime($type, $time = 0, $format = false, $new_score_gc = 0, $reset_hour = '')
	{
		if (!in_array($type, array('board_time', 'reset_month', 'reset_quarter_year', 'reset_half_year', 'reset_end_year', 'reset_days')))
		{
			$time = 0;
			$format = false;
			$type = 'board_time';
		}

		static $_pa_cache_timezone;

		if (!isset($_pa_cache_timezone))
		{
			try
			{
				$_pa_cache_timezone = new \DateTimeZone($this->config['board_timezone']);
			}
			catch (\Exception $e)
			{
				// If the timezone the user has selected is invalid, we fall back to UTC.
				$_pa_cache_timezone = new \DateTimeZone('UTC');
			}
		}

		if (!$time)
		{
			$time = time();
		}

		$modify = '';
		$hour = $min = $sec = 0;
		$dt = new \DateTime;
		$dt->setTimezone($_pa_cache_timezone);
		$dt->setTimestamp($time);

		switch ($type)
		{
			case 'reset_month':
				$modify = 'first day of next month';
			break;

			case 'reset_quarter_year':
				$month = $dt->format('n');

				if ($month < 4)
				{
					$modify = 'first day of april';
				}
				else if ($month > 3 && $month < 7)
				{
					$modify = 'first day of july';
				}
				else if ($month > 6 && $month < 10)
				{
					$modify = 'first day of october';
				}
				else if ($month > 9)
				{
					$modify = 'next year, first day of january';
				}
			break;

			case 'reset_half_year':
				$month = $dt->format('n');
				$modify = ($month < 7) ? 'first day of july' : 'next year, first day of january';
			break;

			case 'reset_end_year':
				$modify = 'next year, first day of january';
			break;

			case 'reset_days':
				$reset_hour = ($reset_hour !== '') ? $reset_hour : $this->arcade_config['auto_reset_score_hour'];
				$this->hour_min($reset_hour, $hour, $min);
				$new_score_gc = ($new_score_gc > 0) ? $new_score_gc : $this->arcade_config['auto_reset_score_gc'];
				$days = intval($new_score_gc / 86400);
				$modify = '+' . $days . ' days';
			break;
		}

		if ($type !== 'board_time')
		{
			$dt->setTime($hour, $min, $sec);
		}

		if (!$format && $modify)
		{
			$dt->modify($modify);
		}

		return ($format) ? $dt->format($this->config['default_dateformat']) : $dt->getTimestamp();
	}

	public function hour_min($hour_min, &$hour, &$min)
	{
		$hour_min = explode(':', $hour_min);
		$hour = (int) $hour_min[0];
		$min = (!empty($hour_min[1])) ? (int) $hour_min[1] : 0;

		$hour = ($hour >= 0 && $hour <= 23) ? $hour : 0;
		$min = ($min >= 0 && $min <= 59) ? $min : 0;

		return (($hour < 10) ? "0{$hour}" : $hour) . ':' . (($min < 10) ? "0{$min}" : $min);
	}

	public function gen_auto_reset_score_days($fix = 0, $new_score_gc = 0, $reset_hour = '')
	{
		$time_stamp = 0;
		$fix = intval($new_score_gc ? $fix : $this->arcade_config['auto_reset_score_type']);

		if ($fix)
		{
			switch ($fix)
			{
				// Month
				case 1:
					$type = 'reset_month';
					$time_stamp = $this->gen_board_datetime($type);
				break;

				// Quarter Year
				case 2:
					$type = 'reset_quarter_year';
					$time_stamp = $this->gen_board_datetime($type);
				break;

				// Half Year
				case 3:
					$type = 'reset_half_year';
					$time_stamp = $this->gen_board_datetime($type);
				break;

				// Year
				case 4:
					$type = 'reset_end_year';
					$time_stamp = $this->gen_board_datetime($type);
				break;

				default:
					$fix = 0;
			}
		}

		if (!$fix)
		{
			// Days
			$type = 'reset_days';
			$time_stamp = $this->gen_board_datetime($type, 0, false, $new_score_gc, $reset_hour);
		}

		return $time_stamp;
	}

	/**
	* Displays html code for images including
	* dimensions if possible
	*
	* Thanks easygo
	*/
	public function set_image($path, $alt = '', $style = '', $class = '')
	{
		if (!empty($alt))
		{
			$alt = $this->lang_value($alt);
			$alt = ' alt="' . $alt . '" title="' . $alt . '"';
		}
		else
		{
			$alt = ' alt="" title=""';
		}

		$style = (!empty($style)) ? ' style="' . $style . '"' : '';
		$class = (!empty($class)) ? ' class="' . $class . '"' : '';

		return '<img' . $class . ' src="' . $path . '"' . $alt . $style . '>';
	}

	/**
	* Set the rating image for the game
	*/
	public function set_rating_image($data, $mode = '', $light = false)
	{
		$rate_block	= ($this->get()->cat_locked($data['cat_id']) || !$this->user->data['is_registered']) ? true : false;
		$c_rate		= ($this->arcade_auth->acl_get('c_rate', $data['cat_id'])) ? true : false;
		$c_new_rate = ($this->arcade_auth->acl_get('c_re_rate', $data['cat_id'])) ? true : false;

		if ($data['game_votetotal'] > 0)
		{
			$star_width = (int) (($data['game_votesum'] / $data['game_votetotal']) * 16);
		}
		else
		{
			$star_width = 0;
		}

		$title = '';

		if (!$c_rate && !$rate_block)
		{
			$title.= $this->user->lang['ARCADE_RATING_NO_PERMISSION'];
		}
		else if ($c_rate && !$c_new_rate && (!empty($data['game_rating'])) && !$rate_block)
		{
			$title.= sprintf($this->user->lang['ARCADE_RATING_ALREADY'], $data['game_rating']);
		}

		$arn_width = (96 + (strlen($data['game_votetotal']) * 6));

		$star_image = "<div class='arcade-star' style='height: 16px; ". (!$mode ? "width: 100px; margin-right: auto; margin-left: auto;" : '') ."' id='star_{$data['game_id']}'>
						<ul class='arcade-rate" . (($light) ? ' light' : '') . "'" . ($title ? "title='{$title}'" : "") . ">";

		if ($star_width)
		{
			$star_image.= "<li class='arcade-current-rate' style='width: {$star_width}px;'></li>";
		}

		$star_image.= "<li class='arcade-rating-num" . (($light) ? ' arcade-white' : '') . "' style='width: {$arn_width}px;'><span title='{$this->user->lang['ARCADE_RATING_NUM']}'>({$data['game_votetotal']})</span></li>";

		if (($c_rate && (empty($data['game_rating'])) && !$rate_block) || ($c_rate && $c_new_rate && !$rate_block))
		{
			for ($x = 1; $x <= 5; $x++)
			{
				$star_image.= '<li><a href="#" title="' . sprintf($this->user->lang['ARCADE_RATING_VALUE'], $x) . '" class="arcade-rate-' . $x . '" data-jvarcade="ajax" data-mode="' . (($mode) ? 'mode_' : '') . 'rating" data-type="arcade" data-action="' . $x . '" data-gameid="' . $data['game_id'] . '" data-catid="' . $data['cat_id'] . '" data-popup="' . $light . '" rel="nofollow">' . $x . '</a></li>';
			}
		}

		$star_image.= "</ul></div>";

		return $star_image;
	}

	public function set_fav_image($game_data, $game_id, $mode = '', $light = false)
	{
		if (!$this->user->data['is_registered'])
		{
			return '';
		}
		else
		{
			$image = "<div style='display: inline-block; height: 14px;' id='fav_{$game_id}'>";

			if (!empty($game_data[$game_id]))
			{
				$image .= '<a href="#"' . ((!$mode) ? ' id="fav_fun"' : '') . ' data-jvarcade="ajax" data-mode="' . (($mode) ? 'mode_' : '') . 'fav" data-type="arcade" data-action="' . ARCADE_FAV_DEL . '" data-gameid="' . $game_id . '" data-popup="' . $light . '" rel="nofollow"><img class="arcade_fav" src="' . $this->get()->image('src', 'img', 'remove_favorite.png') . '" title="' . $this->user->lang['ARCADE_REMOVE_FAV'] . '" alt="' . $this->user->lang['ARCADE_REMOVE_FAV'] . '">';
			}
			else
			{
				$image .= '<a href="#"' . ((!$mode) ? ' id="fav_fun"' : '') . ' data-jvarcade="ajax" data-mode="' . (($mode) ? 'mode_' : '') . 'fav" data-type="arcade" data-action="' . ARCADE_FAV_ADD . '" data-gameid="' . $game_id . '" data-popup="' . $light . '" rel="nofollow"><img class="arcade_fav" src="' . $this->get()->image('src', 'img', 'add_favorite.png') . '" title="' . $this->user->lang['ARCADE_ADD_FAV'] . '" alt="' . $this->user->lang['ARCADE_ADD_FAV'] . '">';
			}

			$image .= '</a></div>';

			return $image;
		}
	}

	public function send_score($mode)
	{
		$arcade_do	=strtolower($this->request->variable('do', ''));
		$arcade_act	= strtolower($this->request->variable('act', ''));
		$scoretype	= ($arcade_act == 'arcade' && $arcade_do == 'newscore') ? IBPRO_GAME : (($arcade_act == 'arcadelib') ? ARCADELIB_GAME : ((strtolower($this->request->variable('autocom', '')) == 'arcade') ? IBPROV3_GAME : (($arcade_act == 'rarcade') ? PHPBB_RA_GAME : ((($arcade_act == 'arcadeoa' && $arcade_do == 'newscore') || strtolower($this->request->variable('action', '')) == 'submit_score') ? OLYMPUS_GAME : false))));

		if ($scoretype === false)
		{
			$jva_h5_type	= ($this->request->is_set_post('jva_h5_score')) ? strtolower($this->request->variable('jva_h5_score', '')) : false;
			$phparcade_type	= ($this->request->is_set_post('sendscore')) ? strtolower($this->request->variable('sendscore', '')) : false;
			$v3arcade_type	= ($this->request->is_set_post('sessdo')) ? strtolower($this->request->variable('sessdo', '')) : false;
			$scoretype		= ($jva_h5_type || $phparcade_type) ? PHPBBARCADE_GAME : (($v3arcade_type) ? V3ARCADE_GAME : false);
		}

		if (in_array($scoretype, array(IBPRO_GAME, IBPROV3_GAME, ARCADELIB_GAME, PHPBB_RA_GAME, OLYMPUS_GAME)))
		{
			$sql = 'SELECT post_data
					FROM ' . ARCADE_SESSIONS_TABLE . "
					WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
						AND session_id = '" . $this->db->sql_escape($this->game()->session->game_sid) . "'
						AND user_id = " . (int) $this->user->data['user_id'];
			$result = $this->db->sql_query_limit($sql, 1);
			$post_data = (string) $this->db->sql_fetchfield('post_data');
			$this->db->sql_freeresult($result);

			if ($post_data)
			{
				$post_data = explode("\n", $post_data);

				foreach ($post_data as $pd)
				{
					list($key, $value) = explode('=', $pd);

					$this->request->overwrite($key, $value, \phpbb\request\request_interface::POST);
					$this->request->overwrite($key, $value);
				}
			}
		}

		return $scoretype;
	}

	public function userdata($mode, $user_id = false, $username = false)
	{
		$one_column = false;
		$arcade_data = false;

		switch ($mode)
		{
			case 'user_id':
				$one_column = true;
				$columns = 'u.user_id';
			break;

			case 'username':
				$one_column = true;
				$columns = 'u.username';
			break;

			case 'user_type':
				$one_column = true;
				$columns = 'u.user_type';
			break;

			case 'full_username':
				$columns = 'u.user_id, u.username, u.user_colour';
			break;

			case 'all_user_data':
				$columns = 'u.*';
			break;

			case 'user_info':
				$arcade_data = true;
				$columns = 'u.user_type, u.user_id, u.username, u.user_options, u.user_colour, u.user_avatar, u.user_avatar_type, u.user_avatar_width, u.user_avatar_height, u.user_rank, u.user_posts,
					au.arcade_total_played, au.arcade_total_plays, au.arcade_total_time, au.arcade_total_wins, au.arcade_total_super_scores, au.arcade_total_downloads,
					au.user_arcade_options, au.games_sort_order, au.games_sort_dir, au.user_arcade_rank, au.arcade_cat_style, au.arcade_cat_games_style';
			break;

			case 'options':
				$arcade_data = true;
				$columns = 'u.user_type, u.user_id, u.username, u.user_options, au.user_arcade_options, au.games_sort_order, au.games_sort_dir, au.arcade_cat_style, au.arcade_cat_games_style, au.user_arcade_rank';
			break;

			case 'set_auth':
				$arcade_data = true;
				$columns = 'u.user_type, u.user_id, u.username, u.user_colour, u.user_lang, u.user_ip, u.user_options, u.user_permissions, au.user_arcade_options, au.user_arcade_permissions';
			break;

			case 'all':
				$arcade_data = true;
				$columns = 'u.*, a.*';
			break;

			default:
				$columns = false;
			break;
		}

		$userdata = ($one_column) ? false : array();

		if ($columns && ($user_id || $username))
		{
			$left_join = ($arcade_data) ? 'LEFT JOIN ' . ARCADE_USERS_TABLE . ' au ON u.user_id = au.user_id' : '';

			$sql = "SELECT $columns
					FROM " . USERS_TABLE . " u
					$left_join
					WHERE " . (($username) ? "u.username_clean = '" . $this->db->sql_escape(utf8_clean_string($username)) . "'" : 'u.user_id = ' . (int) $user_id);
			$result = $this->db->sql_query($sql);

			if ($one_column)
			{
				$userdata = $this->db->sql_fetchfield(str_replace(array('u.', 'au.'), '', $columns));
			}
			else
			{
				$userdata = $this->db->sql_fetchrow($result);
			}

			$this->db->sql_freeresult($result);

			if ($userdata && $arcade_data && !isset($userdata['user_arcade_options']))
			{
				$this->set_userdata($userdata);
			}
		}

		return $userdata;
	}

	public function games_list($type)
	{
		$play_games = false;
		$s_played_games = ($this->user->data['is_registered'] && $this->arcade_config['played_colour']) ? true : false;

		if ($this->arcade_config['total_plays'])
		{
			if ($type == 'quick_jump' && $this->arcade_config['load_list'] && $s_played_games)
			{
				// Quick jump of all the games in the arcade...
				$played_games = $this->get()->played_games();
				$this->template->assign_var('PLAYED_GAME_TITLE', ' title="' . $this->user->lang['ARCADE_PLAYED_GAMES_HIGHLIGHT'] . '"');
			}
		}

		$user_age = $this->get()->user_age();
		$founder_exemption = ($this->arcade_config['founder_exempt'] && $this->user->data['user_type'] == USER_FOUNDER) ? true : false;

		if ($this->arcade_config['total_plays'] || $type == 'quick_jump')
		{
			foreach ((($type == 'quick_jump') ? $this->games() : $this->get()->played_games(false, true)) as $gid => $game)
			{
				if (!$this->arcade_auth->acl_get('c_view', $game['cat_id']) || ($type == 'quick_jump' && !$this->arcade_auth->acl_get('c_play', $game['cat_id'])))
				{
					continue;
				}

				if ($this->arcade_config['load_list'])
				{
					$cat_age = $this->get()->cat_field($game['cat_id'], 'cat_age');

					if ($type == 'quick_jump' && ($this->get()->cat_locked($game['cat_id']) || ($cat_age && !$founder_exemption && ($user_age === '' || ($user_age < $cat_age)))))
					{
						continue;
					}

					$this->template->assign_block_vars($type, array(
						'S_PLAYED_GAME'	=> (!$s_played_games || !empty($played_games[$gid])) ? true : false,
						'GAME_ID'		=> $gid,
						'GAME_NAME'		=> $game['game_name'],
					));
				}
				else
				{
					if (($type == 'quick_jump') && ($this->get()->cat_locked($game['cat_id'])))
					{
						continue;
					}

					$play_games = true;
					break;
				}
			}
		}

		if (!$this->arcade_config['load_list'])
		{
			$this->template->assign_var((($type == 'quick_jump') ? 'HEADER_' : 'STATS_') . 'GAMES_LIST_LOADING', ($play_games) ? '<a href="#" data-jvarcade="ajax" data-mode="games_list" data-type="arcade" data-action="' . (($type == 'quick_jump') ? 'all' : 'played') . '" rel="nofollow"><b>' . $this->user->lang['ARCADE_GAMES_LIST_LOAD'] .'</b></a>' : $this->user->lang['ARCADE_NO_GAMES']);
		}
	}

	public function users_list()
	{
		if ($this->arcade_config['load_list'])
		{
			foreach ($this->obtain_arcade_users() as $_uid => $_user)
			{
				$this->template->assign_block_vars('stat_user_jump', array(
					'USER_ID'	=> $_uid,
					'USERNAME'	=> $_user['username'])
				);
			}
		}
		else
		{
			$this->template->assign_var('USERS_LIST_LOADING', (count($this->obtain_arcade_users())) ? '<a href="#" data-jvarcade="ajax" data-mode="users_list" data-type="arcade" data-action="played" rel="nofollow"><b>' . $this->user->lang['ARCADE_USERS_LIST_LOAD'] .'</b></a>' : $this->user->lang['ARCADE_NO_PLAYS']);
		}
	}

	public function confirm($lang_ary, $game_id = false)
	{
		$this->template->assign_vars(array(
			'S_USE_SIMPLE_HEADER'	=> $this->game()->session->game_popup,

			'MESSAGE_TITLE'			=> $lang_ary['MESSAGE_TITLE'],
			'MESSAGE_TEXT'			=> $lang_ary['MESSAGE_TEXT'],
		));

		if (!empty($lang_ary['CONFIRM_BUTTON1']))
		{
			$this->template->assign_vars(array(
				'S_RESTART_GAME'		=> true,
				'S_RESTART_TYPE'		=> (!empty($lang_ary['TYPE'])) ? $lang_ary['TYPE'] : false,

				'U_ACTION1'				=> $this->url('mode=' . (($this->game()->session->game_popup) ? 'popup' : 'play') . '&amp;g=' . $game_id),

				'CONFIRM_BUTTON1'		=> $lang_ary['CONFIRM_BUTTON1']
			));
		}

		$this->display()->page($lang_ary['PAGE_TITLE'], 'arcade/message_body.html');
	}

	public function banned($type, $user_id = false, $user_ip = '', $game_id = false, $score = 0, $formtime = 0)
	{
		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
			$user_ip = $this->user->ip;
		}

		if ($user_id == ANONYMOUS || is_array($user_id))
		{
			return;
		}

		$sql_ary = array(
			'user_id'		=> (int) $user_id,
			'banned_type'	=> (int) $type,
			'banned_ip'		=> $user_ip,
			'banned_date'	=> time(),
			'game_id'		=> (int) $game_id,
			'formtime'		=> (int) $formtime,
			'score'			=> (float) $score
		);

		$this->db->sql_return_on_error(true);
		$this->db->sql_query('INSERT INTO ' . ARCADE_USERS_BANNED_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
		$this->db->sql_return_on_error(false);

		$this->cache->destroy('_arcade_ban_users');
	}

	/**
	* Set the headers to notify the browser not to cache
	* If this isn't here the IBPro v3 games will not work
	*/
	public function set_header_no_cache()
	{
		@header("HTTP/1.0 200 OK");
		@header("HTTP/1.1 200 OK");
		@header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
		@header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
		@header('Pragma: no-cache');
	}

	public function cache_purge($mode = 'all')
	{
		$tables = $keys = array();

		switch ($mode)
		{
			case 'rating':
				$tables[]	= ARCADE_GAMES_TABLE;
				$tables[]	= ARCADE_RATING_TABLE;
			break;
			case 'all':
				$tables[]	= ARCADE_CHALLENGE_CHAMP_TABLE;
				$tables[]	= ARCADE_TOUR_CHAMP_TABLE;
				$keys[]		= '_arcade_games_filesize';
				$keys[]		= '_arcade_cats';
				$keys[]		= '_arcade_games';
				$keys[]		= '_arcade_tour_check';
			case 'user':
				$keys[]		= '_arcade_hidden_scores';
				$keys[]		= '_arcade_challenge_leaders_all';
				$keys[]		= '_arcade_tours';
				$keys[]		= '_arcade_tour_leaders_all';
			case 'profile':
				$tables[]	= ARCADE_CATS_TABLE;
				$keys[]		= '_arcade_challenge_leaders';
				$keys[]		= '_arcade_tour_leaders';
				$keys[]		= '_arcade_announcement';
			case 'score':
				$keys[]		= '_arcade_leaders';

				$tables[]	= USERS_TABLE;

				if ($mode != 'profile')
				{
					$tables[] = ARCADE_GAMES_TABLE;
					$keys[] = '_arcade_leaders_all';
					$keys[] = '_arcade_super_champion_all';
				}
			break;
		}

		if (count($tables))
		{
			$this->cache->destroy('sql', $tables);
		}

		if (count($keys))
		{
			foreach ($keys as $key)
			{
				$this->cache->destroy($key);
			}
		}
	}

	public function root_key($file)
	{
		return str_replace($this->root_path, '[ROOT]/', $file);
	}

	public function rand_num($g_id = 1)
	{
		$g_id = (int) $g_id;
		$rand_nums['r1'] = $this->rand();
		$rand_nums['r2'] = $this->rand($rand_nums['r1']);

		$rand_nums['rgid'] = $g_id * $rand_nums['r1'] ^ $rand_nums['r2'];

		if (!$rand_nums['rgid'])
		{
			$this->rand_num();
		}

		return $rand_nums;
	}

	public function rand($rand_num = false, $start_num = 2, $end_num = 200)
	{
		$start_num = intval(($start_num < 2) ? 2 : $start_num);
		$end_num = intval(($end_num < 2) ? 2 : $end_num);

		if ($start_num >= $end_num)
		{
			$end_num = ($start_num + 1);
		}

		$new_rand_num = rand($start_num, $end_num);

		if ($rand_num !== false && $rand_num == $new_rand_num)
		{
			$new_rand_num = $this->rand($rand_num, $start_num, $end_num);
		}

		return $new_rand_num;
	}

	public function style(&$style_id, $cat_id = false, $game_id = false)
	{
		if (!$style_id)
		{
			$cat_style = false;
			if ($cat_id || $game_id)
			{
				if (!$cat_id && $game_id)
				{
					$cat_id = (int) $this->get()->game_field($game_id, 'cat_id', false);
				}

				if ($cat_id)
				{
					$cat_style = (int) $this->get()->cat_field($cat_id, 'cat_style', false);
				}
			}

			if ($cat_style)
			{
				$style_id = $cat_style;
			}
			else if ($this->arcade_config['default_style'])
			{
				$style_id = (int) $this->arcade_config['default_style'];
			}
		}

		$style_id = ($style_id) ? $style_id : false;
	}

	public function compress_methods($remove_dot = false)
	{
		if ($remove_dot)
		{
			$methods = array('tar');
			$available_methods = array('gz' => 'zlib', 'bz2' => 'bz2', 'zip' => 'zlib');
		}
		else
		{
			$methods = array('.tar');
			$available_methods = array('.tar.gz' => 'zlib', '.tar.bz2' => 'bz2', '.zip' => 'zlib');
		}

		foreach ($available_methods as $type => $module)
		{
			if (!@extension_loaded($module))
			{
				continue;
			}
			$methods[] = $type;
		}

		return $methods;
	}

	public function obtain_users_online(&$online_users, $page_verify_ignore = false)
	{
		$prew_id = array();
		$prew_ip = array();
		// a little discrete magic to cache this for 30 seconds
		$online_users['online_time'] = (int) (($this->arcade_config['online_time'] > 0) ? $this->arcade_config['online_time'] : $this->config['load_online_time']);
		$online_time = intval(time() - ($online_users['online_time'] * 60));

		$sql = 'SELECT s.session_viewonline, s.session_page, s.session_ip, u.user_type, u.user_id, u.username, u.user_colour, g.game_id, g.game_name, g.cat_id
			FROM		' . ARCADE_SESSIONS_TABLE . '	a
			LEFT JOIN	' . SESSIONS_TABLE . '			s ON a.phpbb_session_id = s.session_id
			LEFT JOIN	' . USERS_TABLE . '				u ON a.user_id = u.user_id
			LEFT JOIN	' . ARCADE_GAMES_TABLE . '		g ON a.game_id = g.game_id
			WHERE a.phpbb_session_id = s.session_id
			AND s.session_user_id = u.user_id
			AND ' . $this->db->sql_in_set('g.cat_id', $this->get()->permissions(array('c_view', 'c_play')), false, true) . '
			AND (a.user_id <> ' . ANONYMOUS . ' AND a.start_time >= ' . ($online_time - ((int) ($online_time % 30))) . ')
				OR
				(a.user_id = ' . ANONYMOUS . ' AND a.start_time >= ' . ($online_time - ((int) ($online_time % 60))) . ')
			ORDER BY a.start_time DESC';
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$page_verify_ignore = ($page_verify_ignore && $row['user_id'] == $this->user->data['user_id']) ? true : false;

			if (!$page_verify_ignore && $this->playing_page($row['session_page']) === false)
			{
				continue;
			}

			$username = ($row['user_id'] == ANONYMOUS) ? $this->user->lang['GUEST'] : $row['username'];
			$username = $this->get()->user_name(($row['user_type'] <> USER_IGNORE) ? 'full' : 'no_profile', $row['user_id'], $username, $row['user_colour'], 'arcade', 'x');

			if ($row['user_id'] != ANONYMOUS && !isset($prew_id[$row['user_id']]))
			{
				$prew_id[$row['user_id']] = 1;

				if (!$row['session_viewonline'])
				{
					$player_link = '<em>' . $username . '</em>';
					$online_users['hidden_online']++;
				}
				else
				{
					$player_link = $username;
					$online_users['visible_online']++;
				}
			}
			else if ($row['user_id'] == ANONYMOUS && !isset($prew_ip[$row['session_ip']]))
			{
				$prew_ip[$row['session_ip']] = 1;
				$player_link = $username;
				$online_users['guests_online']++;
			}
			else
			{
				continue;
			}

			if ($row['session_viewonline'] || $this->auth->acl_get('u_viewonline'))
			{
				// Build a list of users playing a game
				if (!isset($online_users['games_names'][$row['game_id']]))
				{
					$online_users['games_names'][$row['game_id']] = $this->get()->game_name($row['game_name'], false, 'play', $row['cat_id'], $row['game_id'], 'x');
					$online_users['games_players'][$row['game_id']] = $player_link;
				}
				else
				{
					$online_users['games_players'][$row['game_id']] .= ', ' . $player_link;
				}
			}
		}
		$this->db->sql_freeresult($result);

		$online_users['total_online'] = intval($online_users['guests_online'] + $online_users['visible_online'] + $online_users['hidden_online']);
	}

	public function obtain_arcade_users()
	{
		// This is used to allow the user to see every user in a drop
		// so they can select one to see his/her scores...
		$sql_array = array(
			'SELECT'		=> 'u.user_id, u.username, u.username_clean',
			'FROM'			=> array(USERS_TABLE	=> 'u'),
			'LEFT_JOIN'		=> array(
				array('FROM'	=> array(ARCADE_PLAYS_TABLE => 'p'), 'ON' => 'u.user_id = p.user_id')
			),
			'WHERE'			=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
				AND u.user_id = p.user_id',
			'ORDER_BY'		=> 'u.username_clean ASC',
		);

		$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
		$result = $this->db->sql_query($sql, $this->hour($this->arcade_config['cache_time']));

		$arcade_users = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$arcade_users[$row['user_id']] = array(
				'username' => $row['username']
			);
		}
		$this->db->sql_freeresult($result);

		return $arcade_users;
	}

	public function post_var($key, $format = 'string', $undefined = false)
	{
		$return = ($this->request->is_set_post($key)) ? true : false;

		if ($undefined)
		{
			return (!$return || $this->request->variable($key, '') == 'undefined') ? true : false;
		}

		switch ($format)
		{
			case 'int':
				$return = ($return) ? (int) $this->request->variable($key, 0) : 0;
			break;

			case 'num':
				$return = ($return) ? $this->request->variable($key, 0.0) : 0;
			break;

			case 'float':
				$return = round((($return) ? (float) $this->request->variable($key, 0.0) : 0.00), 2);
			break;

			default:
				$return = ($return) ? $this->request->variable($key, '') : '';
			break;
		}

		return $return;
	}

	public function build_select($option_ary, $option_default = false)
	{
		$html = '';
		foreach ($option_ary as $value => $title)
		{
			$selected = ($option_default !== false && $value == $option_default) ? ' selected="selected"' : '';
			$html .= '<option value="' . $value . '"' . $selected . '>' . ((!empty($this->user->lang[$title])) ? $this->user->lang[$title] : $title) . '</option>';
		}

		return $html;
	}

	public function set_path($file, $type = '', $use_phpbb_root = true, $game_type = false, $game_save_type = false)
	{
		$path = $this->file_functions->remove_extension($file);

		switch ($type)
		{
			case 'install':
				$return = $this->arcade_config['game_path'] . $path . '/' . $path . '.' . $this->php_ext;
			break;

			case 'path':
				$return = $this->arcade_config['game_path'] . $path . '/';
			break;

			case 'gamedata':
				$return = 'arcade/gamedata/' . $path . '/';
			break;

			case 'v3arcade_gamedata':
				$return = 'games/' . $path . '/';
			break;

			default:
				if ($game_type == GAME_TYPE_HTML5)
				{
					if ($game_save_type == PHPBB_RA_GAME)
					{
						$return = $this->arcade_config['game_path'] . $path . '/' . $path . '.html';
					}
					else
					{
						// Verify 4 paths. Possible paths:
						// 1. Default path		arcade/gamedata/game_name/index.html
						// 2. 					arcade/gamedata/game_name/game_name.html
						// 3. 					arcade/games/game_name/index.html
						// 4. 					arcade/games/game_name/game_name.html

						$return = 'arcade/gamedata/' . $path . '/index.html';

						if (!file_exists($this->root_path . $return) && file_exists($this->root_path . $this->arcade_config['game_path'] . $path . '/' . $path . '.html'))
						{
							$return = $this->arcade_config['game_path'] . $path . '/' . $path . '.html';
						}
						else if (file_exists($this->root_path . $this->arcade_config['game_path'] . $path . '/index.html'))
						{
							$return = $this->arcade_config['game_path'] . $path . '/index.html';
						}
						else if (file_exists($this->root_path . 'arcade/gamedata/' . $path . '/' . $path . '.html'))
						{
							$return = 'arcade/gamedata/' . $path . '/' . $path . '.html';
						}
					}
				}
				else
				{
					$return = $this->arcade_config['game_path'] . $path . '/' . $file;
				}
			break;
		}

		return ($use_phpbb_root) ? $this->root_path . $return : $return;
	}

	public function set_game_image_path($img)
	{
		$game_path = $this->arcade_config['game_path'];
		$this->file_functions->trailing_slash($game_path);
		$file_folder = $this->file_functions->remove_extension($img);
		$img_path = $this->root_path . $game_path . $file_folder . '/' . $img;

		if (!@file_exists($img_path) || !@is_readable($img_path))
		{
			$img_path = $this->root_path . $game_path . $file_folder . '/pics/' . $img;

			if (!@file_exists($img_path) || !@is_readable($img_path))
			{
				$ext = strrchr($img, '.');

				$ibp_image = array(
					$this->root_path . $game_path . $file_folder . '/' . $file_folder . '1' . $ext,
					$this->root_path . $game_path . $file_folder . '/' . $file_folder . '2' . $ext,
				);

				foreach ($ibp_image as $image)
				{
					if (@file_exists($image) && @is_readable($image))
					{
						$img_path = $image;
						break;
					}
				}

				if (!@file_exists($img_path) || !@is_readable($img_path))
				{
					$img_path = $this->set_image_path() . 'no_image.png';
				}
			}
		}

		return str_replace($this->root_path, $this->web_path(), $img_path);
	}

	public function validate_data($mode, $key, $value, $min = 0, $max = 0, $bool = false)
	{
		$return = false;

		switch ($mode)
		{
			case 'string':
				if (utf8_strlen(htmlspecialchars_decode($value)) < $min)
				{
					$return = sprintf($this->user->lang['ARCADE_SET_TOO_SHORT'], $this->lang_value($key), $min);
				}

				if ($max && utf8_strlen(htmlspecialchars_decode($value)) > $max)
				{
					$return = sprintf($this->user->lang['ARCADE_SET_TOO_LONG'], $this->lang_value($key), $max);
				}
			break;

			case 'int':
				$value = (int) $value;
			case 'float':
				if ($mode == 'float')
				{
					$value = (float) $value;
				}

				if ($value < $min)
				{
					$return = sprintf($this->user->lang['ARCADE_SET_TOO_LOW'], $this->lang_value($key), $min);
				}

				if ($max && $value > $max)
				{
					$return = sprintf($this->user->lang['ARCADE_SET_TOO_BIG'], $this->lang_value($key), $max);
				}
			break;
		}

		return ($bool && $return) ? true : $return;
	}

	public function select_cat_styles($value, $cat = false)
	{
		$option_ary = array(
			0	=> 'ARCADE_STYLE_BASIC',
			1	=> 'ARCADE_STYLE_ARCADE',
			2	=> 'ARCADE_STYLE_FORUM'
		);

		if ($cat)
		{
			$option_ary += array(3 => 'ARCADE_STYLE_SIMPLE_TEXT');
		}

		return $this->build_select($option_ary, $value);
	}

	public function select_games_sort_dir($value)
	{
		$option_ary = array(
			ARCADE_ORDER_ASC	=> 'ASCENDING',
			ARCADE_ORDER_DESC	=> 'DESCENDING'
		);

		return $this->build_select($option_ary, $value);
	}

	public function select_games_sort_order($value)
	{
		$option_ary = array(
			ARCADE_ORDER_FIXED			=> 'ARCADE_GAMES_SORT_FIXED',
			ARCADE_ORDER_INSTALLDATE	=> 'ARCADE_GAMES_SORT_INSTALLDATE',
			ARCADE_ORDER_NAME			=> 'ARCADE_NAME',
			ARCADE_ORDER_PLAYS			=> 'ARCADE_GAMES_SORT_PLAYS',
			ARCADE_ORDER_RATING			=> 'ARCADE_GAMES_SORT_RATING'
		);

		return $this->build_select($option_ary, $value);
	}

	public function message_language(&$lang_dir, $key = '')
	{
		global $lang;

		if ($lang_dir == 'default_lang')
		{
			$lang_dir = $this->config['default_lang'];
		}

		$lang = array();
		if ($this->user->data['user_lang'] != $lang_dir || empty($this->user->lang['ARCADE_DEFAULT']))
		{
			if (file_exists($this->ext_path() . "language/{$lang_dir}/arcade.{$this->php_ext}"))
			{
				include($this->root_path . 'language/' . $lang_dir . "/common.{$this->php_ext}");
				include($this->ext_path() . "language/{$lang_dir}/arcade.{$this->php_ext}");
			}
			else if ($this->user->data['user_lang'] != $this->config['default_lang'] && file_exists($this->ext_path() . "language/{$this->config['default_lang']}/arcade.{$this->php_ext}"))
			{
				$lang_dir = $this->config['default_lang'];
				include($this->root_path . 'language/' . $this->config['default_lang'] . "/common.{$this->php_ext}");
				include($this->ext_path() . "language/{$this->config['default_lang']}/arcade.{$this->php_ext}");
			}
		}

		if (!count($lang))
		{
			$lang_dir = $this->user->data['user_lang'];
			$lang = $this->user->lang;
		}

		if ($key)
		{
			return (!empty($lang[$key])) ? $lang[$key] : $key;
		}
	}

	public function allow_bots()
	{
		$r = false;

		if ($this->user->data['is_registered'] || ($this->user->data['user_type'] != USER_IGNORE) || !$this->user->data['is_bot'])
		{
			return $r;
		}

		$allow_bots = array();

		// Before starting the game exempt the Bots from permissions check.
		// Params array('bot_name' => true)
		$vars = array('allow_bots');
		extract($this->phpbb_dispatcher()->trigger_event('jv.arcade.game.add_allow_bots', compact($vars)));

		if (count($allow_bots))
		{
			foreach ($allow_bots as $bot_name => $value)
			{
				if (strpos($this->user->data['username_clean'], $bot_name) !== false)
				{
					$r = true;
					break;
				}
			}
		}

		return $r;
	}

	public function array_column_sort(&$array, $column = '', $order = 'desc', $original_key = true)
	{
		$order = strtoupper($order);
		$new_array = $sortable_array = array();

		foreach ($array as $k => $v)
		{
			if (is_array($v))
			{
				foreach ($v as $k2 => $v2)
				{
					if ($k2 == $column)
					{
						$sortable_array[$k] = $v2;
					}
				}
			}
			else if ($k == $column)
			{
				$sortable_array[$k] = $v;
			}
		}

		switch ($order)
		{
			case 'A':
			case 'ASC':
			case SORT_ASC:
				($original_key) ? asort($sortable_array) : sort($sortable_array);
			break;

			default:
				($original_key) ? arsort($sortable_array) : rsort($sortable_array);
			break;
		}

		foreach ($sortable_array as $k => $v)
		{
			$new_array[$k] = $array[$k];
		}

		if (count($new_array))
		{
			$array = $new_array;
		}

		unset($new_array, $sortable_array);
	}

	public function array_sort_keys(&$array, $keys = array(), $order = 'desc')
	{
		if (count($keys))
		{
			$new_array = array();

			foreach ($keys as $key)
			{
				if (isset($array[$key]))
				{
					$new_array[$key] = $array[$key];
				}
			}

			if (count($new_array))
			{
				$array = $new_array;
			}

			unset($new_array);
		}
		else
		{
			switch ($order)
			{
				case 'A':
				case 'ASC':
				case SORT_ASC:
					ksort($array);
				break;

				default:
					krsort($array);
				break;
			}
		}
	}

	public function announce_data($lang_dir, $name, $full = false, $reload = false)
	{
		$data = $this->arcade_cache->obtain_arcade_announcement();

		if (!$full)
		{
			$data = (isset($data[$lang_dir][$name])) ? $data[$lang_dir][$name] : false;

			if (!$reload && $data === false)
			{
				$msg_file = $this->ext_path() . "language/{$lang_dir}/msg/{$name}.txt";

				if (file_exists($msg_file))
				{
					if ($this->lang_name($lang_dir) != '')
					{
						$content = file_get_contents($msg_file);

						if (!empty($content))
						{
							$this->create_announce_db(false, $lang_dir, $name);

							$data = $this->announce_data($lang_dir, $name, false, true);
							$this->cache->destroy('_arcade_announcement');
						}
					}
				}
			}
		}

		return $data;
	}

	public function default_announces($all = true)
	{
		$return = array(
			'global_announce',
			'game_announce',
			'arcade_pm',
			'champions_game_announce',
			'report_game_announce',
			'tour_announce',
			'challenge_pm'
		);

		if ($all)
		{
			$return = array_merge($return, array(
				'tour_end_announce',
				'arcade_super_champion_pm',
				'challenge_accept_pm', 'challenge_final_loser_pm', 'challenge_final_tie_pm', 'challenge_final_winner_pm',
				'challenge_reject_pm', 'challenge_report_game_pm', 'challenge_withdraw_pm'
			));
		}

		return $return;
	}

	public function create_announce_db($back_default_data = false, $lang_dir = '', $announce_name = '')
	{
		$announce_ids = array();

		if ($back_default_data && !$lang_dir && !$announce_name)
		{
			$this->delete_table_data(array(ARCADE_ANNOUNCE_TABLE, ARCADE_ANNOUNCE_DATA_TABLE));
		}
		else
		{
			$sql = 'SELECT announce_id, announce_name FROM ' . ARCADE_ANNOUNCE_TABLE . (($announce_name != '') ? " WHERE announce_name = '" . $this->db->sql_escape($announce_name) . "'" : '');
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$announce_ids[$row['announce_name']] = (int) $row['announce_id'];
			}
			$this->db->sql_freeresult($result);
		}

		if (in_array($announce_name, $this->default_announces()) || !$announce_name)
		{
			$sql = 'SELECT lang_iso, lang_local_name FROM ' . LANG_TABLE . (($lang_dir != '') ? " WHERE lang_iso = '" . $this->db->sql_escape($lang_dir) . "'" : '');
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				if (!$announce_name)
				{
					foreach ($this->default_announces() as $name)
					{
						$this->insert_announce_db($back_default_data, $name, $row['lang_iso'], $announce_ids, $row['lang_local_name']);
					}
				}
				else
				{
					$this->insert_announce_db($back_default_data, $announce_name, $row['lang_iso'], $announce_ids, $row['lang_local_name']);
				}
			}
			$this->db->sql_freeresult($result);
		}

		$this->cache->destroy('_arcade_announcement');
	}

	public function insert_announce_db($back_default_data, $announce_name, $lang_dir, &$announce_ids, $lang_name)
	{
		$delete = false;
		$announce_ary = $this->get_announce_tpl($announce_name, $lang_dir);

		if (!isset($announce_ids[$announce_name]))
		{
			$this->db->sql_query('INSERT INTO ' . ARCADE_ANNOUNCE_TABLE . ' ' . $this->db->sql_build_array('INSERT', array('announce_name' => $announce_name)));
			$announce_ids[$announce_name] = (int) $this->db->sql_nextid();
		}
		else if (!$back_default_data)
		{
			$delete = true;
			$this->del_announce_data($announce_ids, $lang_dir);
		}

		if (!$delete)
		{
			$del_ids = array($announce_name => $announce_ids[$announce_name]);
			$this->del_announce_data($del_ids, $lang_dir);
		}

		$this->db->sql_query('INSERT INTO ' . ARCADE_ANNOUNCE_DATA_TABLE . ' ' . $this->db->sql_build_array('INSERT', array(
			'announce_id'	=> $announce_ids[$announce_name],
			'lang_dir'		=> $lang_dir,
			'user_id'		=> $this->user->data['user_id'],
			'username'		=> $this->user->data['username'],
			'user_colour'	=> $this->user->data['user_colour'],
			'subject'		=> utf8_normalize_nfc($announce_ary['subject']),
			'message'		=> utf8_normalize_nfc($announce_ary['message']),
			'announce_date'	=> time()
		)));

		$this->add_log('admin', 'LOG_ARCADE_ANNOUNCE_CREATE_DB_DATA', ((strpos($announce_name, 'arcade_') !== false) ? '' : 'ARCADE_') . strtoupper($announce_name), $lang_name);
	}

	protected function del_announce_data($announce_ids, $lang_dir)
	{
		if (is_array($announce_ids))
		{
			foreach ($announce_ids as $name => $announce_id)
			{
				$sql = 'DELETE FROM ' . ARCADE_ANNOUNCE_DATA_TABLE . '
						WHERE announce_id = ' . (int) $announce_id;

				if ($lang_dir)
				{
					$sql .= " AND lang_dir = '" . $this->db->sql_escape($lang_dir) . "'";
				}

				$this->db->sql_query($sql);
			}
		}
	}

	public function get_announce_tpl($tpl, $lang_dir)
	{
		$announce_data = array(
			'subject' => '',
			'message' => ''
		);

		$lang_dir = $this->ext_path() . "language/{$lang_dir}/msg/{$tpl}.txt";

		if (file_exists($lang_dir))
		{
			$msg = explode("\n", file_get_contents($lang_dir));

			if (count($msg) > 1)
			{
				$subject = array_shift($msg);

				if (strpos($subject, '{SUBJECT}') !== false)
				{
					$announce_data = array(
						'subject' => trim(str_replace('{SUBJECT}', '', $subject)),
						'message' => trim((is_array($msg)) ? implode("\n", $msg) : $msg)
					);
				}
			}
		}

		return $announce_data;
	}

	public function announce_lang($name, &$lang_dir, $default = true)
	{
		$announce = false;

		if ($default)
		{
			if (($announce = $this->announce_data($lang_dir, $name)) !== false && $announce['message'])
			{
				return $announce;
			}
			else if (($announce = $this->announce_data($this->arcade_config['announce_lang'], $name)) !== false && $announce['message'])
			{
				$lang_dir = $this->arcade_config['announce_lang'];
				return $announce;
			}
			else if (($announce = $this->announce_data($this->config['default_lang'], $name)) !== false && $announce['message'])
			{
				$lang_dir = $this->config['default_lang'];
				return $announce;
			}
			else if ($default === true)
			{
				$announce = $this->announce_lang($name, $lang_dir, false);
			}
		}
		else
		{
			$announces = $this->announce_data('', '', true);
			foreach ($announces as $lang_dir => $row)
			{
				if (!empty($announces[$lang_dir][$name]['message']))
				{
					$announce = $announces[$lang_dir][$name];
					break;
				}
			}
			unset($announces);
		}

		return $announce;
	}

	public function delete_table_data($tables)
	{
		if (!is_array($tables))
		{
			$tables = array($tables);
		}

		foreach ($tables as $table)
		{
			switch ($this->db->get_sql_layer())
			{
				case 'sqlite3':
					$this->db->sql_query('DELETE FROM ' . $table);
				break;

				default:
					$this->db->sql_query('TRUNCATE TABLE ' . $table);
				break;
			}
		}
	}

	public function check_module($user_id, $cat_id, $game_id, $tour_id, &$detailed_stats, &$mode, $type, $start, $challenge_id)
	{
		$error = false;
		$params = false;
		$lang_key = 'arcade';

		if (($cat_id && empty($this->cats()[$cat_id])) || (in_array($mode, array('cat')) && !$cat_id))
		{
			$error = 'NO_CAT_ID';
		}
		else if (($game_id && empty($this->games()[$game_id])) ||
			(!$game_id && ((in_array($mode, array('report', 'popup', 'play', 'score'))) ||
				($mode == 'download' && $type != 'data' && $type != 'list')))
		)
		{
			$error = 'NO_GAME_ID';
		}
		else if ($tour_id && empty($this->tours()[$tour_id]))
		{
			$error		= 'NO_TOUR_ID';
			$params		= 'mode=tournament';
			$lang_key	= 'tour';
		}

		if ($error)
		{
			trigger_error($this->user->lang[$error] . $this->gbl($params, $lang_key));
		}

		if (($mode == 'fav' && !$this->user->data['is_registered']) || ($mode == 'ranking' && !$this->arcade_config['ranks_page']))
		{
			$mode = '';
		}

		if ($detailed_stats == 'games_jackpots' && !$this->points()->data['show'])
		{
			$detailed_stats = '';
		}

		if ($mode == 'random' && !$this->user->data['is_bot'] && $this->arcade_config['random_games'])
		{
			if ($game_id = $this->get()->random_game())
			{
				$mode = 'play';

				if (!empty($this->user->page['page']))
				{
					$u_game_play = "arcade.{$this->php_ext}?mode=play&g={$game_id}";

					if ($this->user->page['page'] != $u_game_play)
					{
						$this->update_session_page($u_game_play);
					}
				}
			}
			else
			{
				trigger_error($this->user->lang['ARCADE_RANDOM_GAME_NO_MATCHES'] . $this->back_link());
			}
		}

		switch ($mode)
		{
			case 'popup':
			case 'play':
				$this->container('play_game')->start($mode, $game_id);
			break;

			case 'download':
				if ($this->user->data['user_id'] == ANONYMOUS && ($type == 'data' || $type == 'list'))
				{
					if ($type == 'data')
					{
						$this->container('acp_download_game')->get_data();
					}
					else
					{
						$this->container('acp_download_game')->get_list($cat_id, $start);
					}

					garbage_collection();
					exit_handler();
				}

				$this->container('download_game')->prep($game_id, $type);
			break;

			case 'score':
				if (!$this->user->data['is_registered'])
				{
					if ($this->user->data['is_bot'])
					{
						redirect($this->url());
					}

					redirect(append_sid("{$this->root_path}ucp.{$this->php_ext}", 'mode=login'));
				}

				$this->container('score')->send('score', $game_id);
			break;

			case 'cat':
			case 'fav':
			case 'search':
				$this->container('cat_games')->display($mode, $cat_id, $game_id, $start);
			break;

			case 'stats':
				if ($cat_id)
				{
					$this->display()->cat_stats($mode, $cat_id, $game_id, $start);
				}
				else
				{
					$this->container('stats')->display($mode, $type, $user_id, $game_id, $tour_id, $start, $detailed_stats);
				}
			break;

			case 'report':
				$this->container('game_report')->send($game_id, $type, $challenge_id);
			break;

			case 'ranking':
				$this->display()->game_ranking($start);
			break;
		}
	}

	public function update_session_page($user_page)
	{
		if (!$user_page)
		{
			return;
		}

		$this->user->page['page'] = $user_page;

		$sql = 'UPDATE ' . SESSIONS_TABLE . "
				SET session_page = '" . $this->db->sql_escape(substr($user_page, 0, 199)) . "'
				WHERE session_id = '" . $this->db->sql_escape($this->user->session_id) . "'";
		$this->db->sql_query($sql);
	}

	public function set_filesize($game_id, $game_swf = '', $game_filesize = 0, $up_cache = true)
	{
		if ($game_swf == '')
		{
			$sql = 'SELECT game_swf, game_filesize
					FROM ' . ARCADE_GAMES_TABLE . '
					WHERE game_id = ' . (int) $game_id;
			$result = $this->db->sql_query($sql);
			$row = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			$game_swf = $row['game_swf'];
			$game_filesize = (int) $row['game_filesize'];
		}

		$filesize = $this->file_functions->filesize(array_filter(array($this->set_path($game_swf, 'path'), $this->game()->file_path($game_swf))));

		if ($filesize && $filesize <> $game_filesize)
		{
			$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
					SET game_filesize = '. (int) $filesize . '
					WHERE game_id = ' . (int) $game_id;
			$this->db->sql_query($sql);

			if ($up_cache)
			{
				$this->cache->destroy('_arcade_games_filesize');
			}
		}

		return $filesize;
	}

	/**
	* Display correct report type based on constant passed
	*/
	public function display_report_type($report_type, $only_lang_key = false)
	{
		$key = 'ARCADE_REPORT_OTHER';

		switch ($report_type)
		{
			case ARCADE_REPORT_DOUBLE:
				$key = 'ARCADE_REPORT_DOUBLE';
			break;

			case ARCADE_REPORT_SCORING:
				$key = 'ARCADE_REPORT_SCORING';
			break;

			case ARCADE_REPORT_PLAYING:
				$key = 'ARCADE_REPORT_PLAYING';
			break;

			case ARCADE_REPORT_DOWNLOADING:
				$key = 'ARCADE_REPORT_DOWNLOADING';
			break;
		}

		return ($only_lang_key) ? $key : $this->user->lang[$key];
	}

	public function add_log()
	{
		$args			= func_get_args();
		$mode			= array_shift($args);
		$cat_id			= ($mode == 'mod') ? intval(array_shift($args)) : '';
		$game_id		= (in_array($mode, array('mod', 'admin_gid', 'critical'))) ? intval(array_shift($args)) : '';
		$action			= array_shift($args);
		$data			= (!count($args)) ? '' : serialize($args);

		$sql_ary = array(
			'user_id'		=> (int) ((empty($this->user->data)) ? ANONYMOUS : $this->user->data['user_id']),
			'log_time'		=> time(),
			'log_operation'	=> $action,
			'log_data'		=> $data,
			'log_ip'		=> $this->user->ip
		);

		switch ($mode)
		{
			case 'admin_gid':
				$sql_ary['game_id'] = $game_id;
			case 'admin':
				$sql_ary['log_type'] = ARCADE_LOG_ADMIN;
			break;

			case 'mod':
				$sql_ary += array(
					'log_type'	=> ARCADE_LOG_MOD,
					'cat_id'	=> $cat_id,
					'game_id'	=> $game_id
				);
			break;

			case 'user':
				$sql_ary['log_type'] = ARCADE_LOG_USERS;
			break;

			case 'critical':
				$sql_ary += array(
					'log_type'	=> ARCADE_LOG_CRITICAL,
					'game_id'	=> $game_id
				);
			break;

			default:
				return false;
		}

		$this->db->sql_query('INSERT INTO ' . ARCADE_LOGS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));

		return $this->db->sql_nextid();
	}

	public function optionget($key, $data = false, $other = false)
	{
		$var = ($other) ? $data : $this->user->data['user_arcade_options'];
		return ($var & 1 << $this->keyoptions[$key]) ? true : false;
	}

	public function optionset($key, $value, $data = false, $other = false)
	{
		$var = ($other) ? $data : $this->user->data['user_arcade_options'];

		if ($value && !($var & 1 << $this->keyoptions[$key]))
		{
			$var += 1 << $this->keyoptions[$key];
		}
		else if (!$value && ($var & 1 << $this->keyoptions[$key]))
		{
			$var -= 1 << $this->keyoptions[$key];
		}
		else
		{
			return ($other) ? $var : false;
		}

		if (!$other)
		{
			$this->user->data['user_arcade_options'] = $var;
			return true;
		}
		else
		{
			return $var;
		}
	}

	public function change_config($mode, $config_name, $config_value = '')
	{
		switch ($mode)
		{
			case 'replace':
				if (isset($this->arcade_config[$config_name]))
				{
					$this->arcade_config->offsetSet('pa_orig_v_' . $config_name, $this->arcade_config[$config_name]);
					$this->arcade_config->offsetSet($config_name, $config_value);
				}
			break;

			case 'restore':
				if (isset($this->arcade_config['pa_orig_v_' . $config_name]))
				{
					$this->arcade_config->offsetSet($config_name, $this->arcade_config['pa_orig_v_' . $config_name]);
					$this->arcade_config->offsetUnset('pa_orig_v_' . $config_name);
				}
			break;
		}
	}

	public function lang_name($lang_iso)
	{
		$sql = 'SELECT lang_local_name
			FROM ' . LANG_TABLE . "
			WHERE lang_iso = '" . $this->db->sql_escape($lang_iso) . "'";
		$result = $this->db->sql_query($sql);
		$lang_local_name = $this->db->sql_fetchfield('lang_local_name');
		$this->db->sql_freeresult($result);

		return ($lang_local_name) ? $lang_local_name : '';
	}

	private function set_data($type = '')
	{
		$ac = array('display', 'get', 'game', 'points', 'shout', 'portal', 'cats', 'data');

		if ($this->access())
		{
			$ac = array_merge($ac, array('games', 'tours'));

			if (!defined('IN_ADMIN'))
			{
				$ac[] = 'hidden_users';
			}

			if (in_array($type, array('challenge', 'full')) && $this->access('challenge'))
			{
				$ac[] = 'challenge';
			}

			if (in_array($type, array('tournament', 'full')) && $this->access('tour'))
			{
				$ac[] = 'tournament';
			}
		}

		foreach ($ac as $c)
		{
			$this->$c = $this->$c();
		}

		$this->set_disabled();
	}

	private function playing_page($page)
	{
		$playing_page = false;

		if (strpos($page, 'arcade') !== false && (strpos($page, 'play') !== false || strpos($page, 'popup') !== false || strpos($page, 'random') !== false))
		{
			$playing_page = true;
		}

		return $playing_page;
	}

	private function set_disabled()
	{
		// Return if auto disable is not turned on
		if (!$this->arcade_config['auto_disable'])
		{
			return;
		}

		$current_time = time();

		// Return if auto disable start time is not valid
		$time_array = $this->validate_time($this->arcade_config['auto_disable_start']);
		if (!count($time_array))
		{
			return;
		}

		$auto_disable_start = $this->time_stamp(gmdate('Y'), gmdate('n'), gmdate('j'), $time_array['hour'], $time_array['min'], 0, false);
		$auto_disable_end = $this->time_stamp(gmdate('Y'), gmdate('n'), gmdate('j'), $time_array['hour'], $time_array['min'], 0, false);

		if (!$auto_disable_start || !$auto_disable_end)
		{
			return;
		}

		// Return if auto disable end time is not valid
		$time_array = $this->validate_time($this->arcade_config['auto_disable_end']);
		if (!count($time_array))
		{
			return;
		}

		// Return if auto disable start time is not set earlier than end time
		if ($auto_disable_start >= $auto_disable_end)
		{
			return;
		}

		// If everything checks out let set the correct value for arcade_disable
		if ($current_time >= $auto_disable_start && $current_time < $auto_disable_end)
		{
			if ($this->arcade_config['arcade_disable'] == false)
			{
				$this->arcade_config['arcade_disable'] = true;
				$this->arcade_config->set('arcade_disable', $this->arcade_config['arcade_disable']);
			}
		}
		else
		{
			if ($this->arcade_config['arcade_disable'] == true)
			{
				$this->arcade_config['arcade_disable'] = false;
				$this->arcade_config->set('arcade_disable', $this->arcade_config['arcade_disable']);
			}
		}
	}

	public function hunt_ary(&$new_ary, &$ary, $search, $type = 'key')
	{
		$count = 0;
		if (!is_array($new_ary) || !is_array($ary) || !is_array($search))
		{
			return $count;
		}

		foreach ($ary as $key => $value)
		{
			if (($type == 'key' && !empty($search[$key])) || ($type == 'value' && !empty($search[$value])))
			{
				if (!isset($new_ary[$key]))
				{
					$count++;
				}

				$new_ary[$key] = $value;
				unset($ary[$key]);
			}
		}

		return $count;
	}
/*
	public function cat_style_update($style_id, $new_id = 0)
	{
		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
				SET cat_style = ' . (int) $new_id . '
				WHERE cat_style = ' . (int) $style_id;
		$this->db->sql_query($sql);

		if ($this->arcade_config['default_style'] && $style_id == $this->arcade_config['default_style'])
		{
			$this->arcade_config->set('default_style', $new_id);
		}

		$this->cache->destroy('sql', ARCADE_CATS_TABLE);
		$this->cache->destroy('_arcade_cats');
	}
*/
}
