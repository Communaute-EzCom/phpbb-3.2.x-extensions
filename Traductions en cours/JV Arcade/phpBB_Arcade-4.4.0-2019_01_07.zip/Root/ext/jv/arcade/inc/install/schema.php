<?php
/**
*
* @package phpBB Arcade
* @version $Id: schema.php 2132 2019-01-03 16:09:12Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\install;

class schema
{
	public function data($table_prefix)
	{
		return array(
			"{$table_prefix}acl_arcade_groups"			=> array(
				'COLUMNS'									=> array(
					'group_id'								=> array('UINT', 0),
					'cat_id'								=> array('UINT', 0),
					'auth_option_id'						=> array('UINT', 0),
					'auth_role_id'							=> array('UINT', 0),
					'auth_setting'							=> array('TINT:2', 0)
				),
				'KEYS'										=> array(
					'g_id'									=> array('INDEX', 'group_id'),
					'ao_id'									=> array('INDEX', 'auth_option_id'),
					'ar_id'									=> array('INDEX', 'auth_role_id')
				)
			),
			"{$table_prefix}acl_arcade_options"			=> array(
				'COLUMNS'									=> array(
					'auth_option_id'						=> array('UINT', NULL, 'auto_increment'),
					'auth_option'							=> array('VCHAR:50', ''),
					'is_global'								=> array('BOOL', 0),
					'is_local'								=> array('BOOL', 0),
					'founder_only'							=> array('BOOL', 0)
				),
				'PRIMARY_KEY'								=> 'auth_option_id',
				'KEYS'										=> array(
					'autho'									=> array('UNIQUE', 'auth_option')
				)
			),
			"{$table_prefix}acl_arcade_roles"			=> array(
				'COLUMNS'									=> array(
					'role_id'								=> array('UINT', NULL, 'auto_increment'),
					'role_name'								=> array('VCHAR_UNI', ''),
					'role_description'						=> array('TEXT_UNI', ''),
					'role_type'								=> array('VCHAR:10', ''),
					'role_order'							=> array('USINT', 0)
				),
				'PRIMARY_KEY'								=> 'role_id',
				'KEYS'										=> array(
					'r_type'								=> array('INDEX', 'role_type'),
					'r_order'								=> array('INDEX', 'role_order')
				)
			),
			"{$table_prefix}acl_arcade_roles_data"		=> array(
				'COLUMNS'									=> array(
					'role_id'								=> array('UINT', 0),
					'auth_option_id'						=> array('UINT', 0),
					'auth_setting'							=> array('TINT:2', 0)
				),
				'PRIMARY_KEY'								=> array('role_id', 'auth_option_id'),
				'KEYS'										=> array(
					'aoi'									=> array('INDEX', 'auth_option_id')
				)
			),
			"{$table_prefix}acl_arcade_users"			=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'cat_id'								=> array('UINT', 0),
					'auth_option_id'						=> array('UINT', 0),
					'auth_role_id'							=> array('UINT', 0),
					'auth_setting'							=> array('TINT:2', 0)
				),
				'KEYS'										=> array(
					'user_id'								=> array('INDEX', 'user_id'),
					'ath_opid'								=> array('INDEX', 'auth_option_id'),
					'ath_roid'								=> array('INDEX', 'auth_role_id')
				)
			),
			"{$table_prefix}arcade_access"				=> array(
				'COLUMNS'									=> array(
					'cat_id'								=> array('UINT', 0),
					'user_id'								=> array('UINT', 0),
					'session_id'							=> array('CHAR:32', '')
				),
				'PRIMARY_KEY'								=> array('cat_id', 'user_id', 'session_id')
			),
			"{$table_prefix}arcade_announce"			=> array(
				'COLUMNS'									=> array(
					'announce_id'							=> array('UINT', NULL, 'auto_increment'),
					'announce_name'							=> array('STEXT_UNI', '')
				),
				'PRIMARY_KEY'								=> array('announce_id', 'announce_name')
			),
			"{$table_prefix}arcade_announce_data"		=> array(
				'COLUMNS'									=> array(
					'announce_id'							=> array('UINT', 0),
					'lang_dir'								=> array('VCHAR:30', ''),
					'user_id'								=> array('UINT', 0),
					'username'								=> array('VCHAR', ''),
					'user_colour'							=> array('VCHAR:6', ''),
					'subject'								=> array('VCHAR', ''),
					'message'								=> array('MTEXT', ''),
					'bitfield'								=> array('VCHAR', ''),
					'options'								=> array('UINT:11', 7),
					'uid'									=> array('VCHAR:8', ''),
					'announce_date'							=> array('TIMESTAMP', 0)
				),
				'PRIMARY_KEY'								=> array('announce_id', 'lang_dir')
			),
			"{$table_prefix}arcade_categories"			=> array(
				'COLUMNS'									=> array(
					'cat_id'								=> array('UINT', NULL, 'auto_increment'),
					'parent_id'								=> array('UINT', 0),
					'left_id'								=> array('UINT', 0),
					'right_id'								=> array('UINT', 0),
					'cat_parents'							=> array('MTEXT', ''),
					'cat_name'								=> array('STEXT_UNI', ''),
					'cat_desc'								=> array('TEXT_UNI', ''),
					'cat_desc_bitfield'						=> array('VCHAR', ''),
					'cat_desc_options'						=> array('UINT:11', 7),
					'cat_desc_uid'							=> array('VCHAR:8', ''),
					'cat_link'								=> array('VCHAR_UNI', ''),
					'cat_password'							=> array('VCHAR_UNI', ''),
					'cat_age'								=> array('TINT:2', 0),
					'cat_style'								=> array('USINT', 0),
					'cat_display'							=> array('USINT', 0),
					'cat_image'								=> array('VCHAR', ''),
					'cat_rules'								=> array('TEXT_UNI', ''),
					'cat_rules_link'						=> array('VCHAR_UNI', ''),
					'cat_rules_bitfield'					=> array('VCHAR', ''),
					'cat_rules_options'						=> array('UINT:11', 7),
					'cat_rules_uid'							=> array('VCHAR:8', ''),
					'cat_games_per_page'					=> array('TINT:4', 0),
					'cat_type'								=> array('TINT:4', 0),
					'cat_test'								=> array('BOOL', 0),
					'cat_status'							=> array('TINT:4', 0),
					'cat_games'								=> array('UINT', 0),
					'cat_plays'								=> array('UINT', 0),
					'cat_download'							=> array('BOOL', 1),
					'cat_use_jackpot'						=> array('BOOL', 0),
					'cat_cost'								=> array('DECIMAL:10', 0.00),
					'cat_download_cost'						=> array('DECIMAL:10', 0.00),
					'cat_reward'							=> array('DECIMAL:10', 0.00),
					'cat_last_play_game_id'					=> array('UINT', 0),
					'cat_last_play_game_name'				=> array('VCHAR_UNI', ''),
					'cat_last_play_user_id'					=> array('UINT', 0),
					'cat_last_play_score'					=> array('DECIMAL:25', 0.00),
					'cat_last_play_time'					=> array('TIMESTAMP', 0),
					'cat_last_game_installdate'				=> array('TIMESTAMP', 0),
					'cat_last_play_username'				=> array('VCHAR_UNI', ''),
					'cat_last_play_user_colour'				=> array('VCHAR:6', ''),
					'cat_flags'								=> array('TINT:4', 32),
					'display_subcat_list'					=> array('BOOL', 1),
					'display_on_index'						=> array('BOOL', 1)
				),
				'PRIMARY_KEY'								=> 'cat_id',
				'KEYS'										=> array(
					'lr_id'									=> array('INDEX', array('left_id', 'right_id')),
					'clg_id'								=> array('INDEX', 'cat_last_play_game_id'),
					'status'								=> array('INDEX', 'cat_status'),
					'ctest'									=> array('INDEX', 'cat_test')
				)
			),
			"{$table_prefix}arcade_challenge"			=> array(
				'COLUMNS'									=> array(
					'challenge_id'							=> array('UINT', NULL, 'auto_increment'),
					'challenge_accept'						=> array('TINT:1', 0),
					'challenge_points'						=> array('DECIMAL:15', 0.00),
					//'challenge_bet'						=> array('DECIMAL:15', 0.00),
					'challenger_id'							=> array('UINT', 0),
					'opponent_id'							=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'challenger_game_cost'					=> array('DECIMAL:10', 0.00),
					'opponent_game_cost'					=> array('DECIMAL:10', 0.00),
					'challenge_time'						=> array('TIMESTAMP', 0),
					//'expiration_date'						=> array('TIMESTAMP', 0)
				),
				'PRIMARY_KEY'								=> 'challenge_id',
				'KEYS'										=> array(
					'accept'								=> array('INDEX', 'challenge_accept'),
					'chall_id'								=> array('INDEX', 'challenger_id'),
					'opp_id'								=> array('INDEX', 'opponent_id'),
					'game_id'								=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_challenge_champ"		=> array(
				'COLUMNS'									=> array(
					'champ_id'								=> array('UINT', NULL, 'auto_increment'),
					'champ_challenger_id'					=> array('UINT', 0),
					'champ_challenger_score'				=> array('DECIMAL:25', 0.00),
					'champ_opponent_id'						=> array('UINT', 0),
					'champ_opponent_score'					=> array('DECIMAL:25', 0.00),
					'game_id'								=> array('UINT', 0),
					'champ_winner'							=> array('UINT', 0),
					'champ_challenger_time'					=> array('TIMESTAMP', 0),
					'champ_opponent_time'					=> array('TIMESTAMP', 0),
					'champ_close'							=> array('TINT:1', 0),
					'champ_end_time'						=> array('TIMESTAMP', 0)
				),
				'PRIMARY_KEY'								=> 'champ_id',
				'KEYS'										=> array(
					'ci'									=> array('INDEX', 'champ_challenger_id'),
					'oi'									=> array('INDEX', 'champ_opponent_id'),
					'cg'									=> array('INDEX', 'game_id'),
					'cw'									=> array('INDEX', 'champ_winner'),
					'cc'									=> array('INDEX', 'champ_close')
				)
			),
			"{$table_prefix}arcade_config"				=> array(
				'COLUMNS'									=> array(
					'config_name'							=> array('VCHAR', ''),
					'config_value'							=> array('VCHAR_UNI', ''),
					'is_dynamic'							=> array('BOOL', 0)
				),
				'PRIMARY_KEY'								=> 'config_name',
				'KEYS'										=> array(
					'is_dynamic'							=> array('INDEX', 'is_dynamic')
				)
			),
			"{$table_prefix}arcade_delete_games"		=> array(
				'COLUMNS'									=> array(
					'game_swf'								=> array('VCHAR', ''),
					'reason'								=> array('VCHAR', ''),
					'uninstalldate'							=> array('TIMESTAMP', 0)
				),
				'PRIMARY_KEY'								=> 'game_swf'
			),
			"{$table_prefix}arcade_download"			=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'total'									=> array('UINT', 0),
					'download_time'							=> array('TIMESTAMP', 0)
				),
				'PRIMARY_KEY'								=> array('user_id', 'game_id'),
				'KEYS'										=> array(
					'user_id'								=> array('INDEX', 'user_id'),
					'game_id'								=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_favorites"			=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'highlighted'							=> array('TINT:1', 0)
				),
				'PRIMARY_KEY'								=> array('user_id', 'game_id'),
				'KEYS'										=> array(
					'user_id'								=> array('INDEX', 'user_id'),
					'game_id'								=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_games"				=> array(
				'COLUMNS'									=> array(
					'game_id'								=> array('UINT', NULL, 'auto_increment'),
					'game_save_type'						=> array('TINT:1', 0),
					'game_image'							=> array('VCHAR', ''),
					'game_desc'								=> array('TEXT', ''),
					'game_control'							=> array('TINT:1', 0),
					'game_control_desc'						=> array('TEXT', ''),
					'game_highscore'						=> array('DECIMAL:25', 0.00),
					'game_highdate'							=> array('TIMESTAMP', 0),
					'game_highuser'							=> array('UINT', 0),
					'game_name'								=> array('VCHAR', ''),
					'game_name_clean'						=> array('VCHAR', ''),
					'game_swf'								=> array('VCHAR', ''),
					'game_scorevar'							=> array('VCHAR', ''),
					'game_type'								=> array('TINT:1', 0),
					'game_width'							=> array('UINT:5', 550),
					'game_height'							=> array('UINT:5', 380),
					'game_installdate'						=> array('TIMESTAMP', 0),
					'game_filesize'							=> array('UINT:20', 0),
					'game_scoretype'						=> array('TINT:1', 0),
					'game_order'							=> array('UINT', 0),
					'game_plays'							=> array('UINT', 0),
					'game_votetotal'						=> array('UINT', 0),
					'game_votesum'							=> array('UINT', 0),
					'game_download_total'					=> array('UINT', 0),
					'game_download'							=> array('BOOL', 1),
					'game_cost'								=> array('DECIMAL:10', 0.00),
					'game_download_cost'					=> array('DECIMAL:10', 0.00),
					'game_reward'							=> array('DECIMAL:10', 0.00),
					'game_use_jackpot'						=> array('BOOL', 0),
					'game_jackpot'							=> array('DECIMAL:15', 0.00),
					'cat_id'								=> array('UINT', 0),
					'topic_id'								=> array('UINT', 0),
					'post_id'								=> array('UINT', 0),
					'privacy_desc'							=> array('TEXT', ''),
					'privacy_link'							=> array('TEXT', '')
				),
				'PRIMARY_KEY'								=> 'game_id',
				'KEYS'										=> array(
					'highuser'								=> array('INDEX', 'game_highuser'),
					'installdate'							=> array('INDEX', 'game_installdate'),
					'highdate'								=> array('INDEX', 'game_highdate'),
					'plays'									=> array('INDEX', 'game_plays'),
					'cat_id'								=> array('INDEX', 'cat_id'),
					'gname_clean'							=> array('INDEX', 'game_name_clean'),
					'save_type'								=> array('INDEX', 'game_save_type'),
				)
			),
			"{$table_prefix}arcade_game_rating"			=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'game_rating'							=> array('UINT', 0),
					'rating_date'							=> array('TIMESTAMP', 0)
				),
				'PRIMARY_KEY'								=> array('user_id', 'game_id'),
				'KEYS'										=> array(
					'uid'									=> array('INDEX', 'user_id'),
					'gid'									=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_logs"				=> array(
				'COLUMNS'									=> array(
					'log_id'								=> array('UINT', NULL, 'auto_increment'),
					'user_id'								=> array('UINT', 0),
					'cat_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'log_type'								=> array('TINT:2', 0),
					'log_time'								=> array('TIMESTAMP', 0),
					'log_operation'							=> array('TEXT_UNI', ''),
					'log_data'								=> array('MTEXT', ''),
					'log_ip'								=> array('VCHAR:40', '')
				),
				'PRIMARY_KEY'								=> 'log_id',
				'KEYS'										=> array(
					'log_type'								=> array('INDEX', 'log_type'),
					'cat_id'								=> array('INDEX', 'cat_id'),
					'user_id'								=> array('INDEX', 'user_id'),
					'game_id'								=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_menu"				=> array(
				'COLUMNS'									=> array(
					'menu_id'								=> array('UINT', NULL, 'auto_increment'),
					'menu_type'								=> array('BOOL', 0),
					'menu_display'							=> array('BOOL', 0),
					'new_window'							=> array('BOOL', 0),
					'menu_name'								=> array('VCHAR', ''),
					'menu_fa'								=> array('VCHAR:50', ''),
					'menu_page'								=> array('VCHAR:50', ''),
					'params'								=> array('VCHAR', ''),
					'menu_top'								=> array('VCHAR:50', ''),
					'parent_id'								=> array('UINT', 0),
					'left_id'								=> array('UINT', 0),
					'right_id'								=> array('UINT', 0),
					'auth'									=> array('VCHAR', ''),
				),
				'PRIMARY_KEY'								=> 'menu_id',
				'KEYS'										=> array(
					'lr_id'									=> array('INDEX', array('left_id', 'right_id')),
					'display'								=> array('INDEX', 'menu_display')
				)
			),
			"{$table_prefix}arcade_plays"				=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'total_time'							=> array('TIMESTAMP', 0),
					'total_plays'							=> array('UINT', 0)
				),
				'PRIMARY_KEY'								=> array('user_id', 'game_id'),
				'KEYS'										=> array(
					'user_id'								=> array('INDEX', 'user_id'),
					'game_id'								=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_ranks"				=> array(
				'COLUMNS'									=> array(
					'rank_id'								=> array('UINT', NULL, 'auto_increment'),
					'rank_title'							=> array('STEXT_UNI', ''),
					'rank_min'								=> array('UINT', 0),
					'rank_special'							=> array('BOOL', 0),
					'rank_image'							=> array('VCHAR', '')
				),
				'PRIMARY_KEY'								=> 'rank_id'
			),
			"{$table_prefix}arcade_reports"				=> array(
				'COLUMNS'									=> array(
					'report_id'								=> array('UINT', NULL, 'auto_increment'),
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'report_type'							=> array('TINT:1', 0),
					'report_desc'							=> array('TEXT_UNI', ''),
					'report_desc_bitfield'					=> array('VCHAR', ''),
					'report_desc_options'					=> array('UINT:11', 7),
					'report_desc_uid'						=> array('VCHAR:8', ''),
					'report_time'							=> array('INT:11', 0),
					'report_ip'								=> array('VCHAR:40', ''),
					'report_closed'							=> array('TINT:1', 0),
					'topic_id'								=> array('UINT', 0),
					'post_id'								=> array('UINT', 0)
				),
				'PRIMARY_KEY'								=> 'report_id'
			),
			"{$table_prefix}arcade_scores"				=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'score'									=> array('DECIMAL:25', 0.00),
					'comment_text'							=> array('MTEXT', ''),
					'comment_bitfield'						=> array('VCHAR', ''),
					'comment_options'						=> array('UINT:11', 7),
					'comment_uid'							=> array('VCHAR:8', ''),
					'score_date'							=> array('TIMESTAMP', 0)
				),
				'PRIMARY_KEY'								=> array('user_id', 'game_id'),
				'KEYS'										=> array(
					'user_id'								=> array('INDEX', 'user_id'),
					'game_id'								=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_sessions"			=> array(
				'COLUMNS'									=> array(
					'session_id'							=> array('CHAR:32', ''),
					'game_id'								=> array('UINT', 0),
					'user_id'								=> array('UINT', 0),
					'game_popup'							=> array('TINT:1', 0),
					'randchar1'								=> array('UINT', 0),
					'randchar2'								=> array('UINT', 0),
					'randgid1'								=> array('UINT', 0),
					'randgid2'								=> array('UINT', 0),
					'start_time'							=> array('TIMESTAMP', 0),
					'microtime'								=> array('TIMESTAMP', 0),
					'phpbb_session_id'						=> array('CHAR:32', ''),
					'security'								=> array('TINT:1', 0),
					'post_data'								=> array('MTEXT', '')
				),
				'PRIMARY_KEY'								=> 'session_id',
				'KEYS'										=> array(
					'game_id'								=> array('INDEX', 'game_id'),
					'phpbb_sid'								=> array('INDEX', 'phpbb_session_id')
				)
			),
			"{$table_prefix}arcade_super_scores"		=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'score'									=> array('DECIMAL:25', 0.00),
					'score_date'							=> array('TIMESTAMP', 0)
				),
				'PRIMARY_KEY'								=> array('user_id', 'game_id'),
				'KEYS'										=> array(
					'uid'									=> array('INDEX', 'user_id'),
					'gid'									=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_tour"				=> array(
				'COLUMNS'									=> array(
					'tour_id'								=> array('UINT', NULL, 'auto_increment'),
					'tour_name'								=> array('STEXT_UNI', ''),
					'tour_games'							=> array('TEXT', ''),
					'tour_groups'							=> array('TEXT', ''),
					'play_max'								=> array('UINT', 0),
					'topic_id'								=> array('UINT', 0),
					'post_id'								=> array('UINT', 0),
					'tour_status'							=> array('TINT:1', 0),
					'tour_starttime'						=> array('TIMESTAMP', 0),
					'tour_endtime'							=> array('TIMESTAMP', 0),
					'tour_wins'								=> array('UINT', 0),
					'tour_time'								=> array('TIMESTAMP', 0),
					'reward_1'								=> array('DECIMAL:15', 0.00),
					'reward_2'								=> array('DECIMAL:15', 0.00),
					'reward_3'								=> array('DECIMAL:15', 0.00)
				),
				'PRIMARY_KEY'								=> 'tour_id',
				'KEYS'										=> array(
					'wins'									=> array('INDEX', 'tour_wins'),
					'status'								=> array('INDEX', 'tour_status'),
					'starttime'								=> array('INDEX', 'tour_starttime')
				)
			),
			"{$table_prefix}arcade_tour_champ"			=> array(
				'COLUMNS'									=> array(
					'tour_id'								=> array('UINT', 0),
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0),
					'score'									=> array('DECIMAL:25', 0.00),
					'score_date'							=> array('TIMESTAMP', 0),
					'total_plays'							=> array('UINT', 0),
					'total_time'							=> array('UINT', 0)
				),
				'PRIMARY_KEY'								=> array('tour_id', 'user_id', 'game_id'),
				'KEYS'										=> array(
					'tour_id'								=> array('INDEX', 'tour_id'),
					'user_id'								=> array('INDEX', 'user_id'),
					'game_id'								=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_tour_wins"			=> array(
				'COLUMNS'									=> array(
					'tour_id'								=> array('UINT', 0),
					'user_id'								=> array('UINT', 0),
					'game_id'								=> array('UINT', 0)
				),
				'PRIMARY_KEY'								=> array('tour_id', 'user_id', 'game_id'),
				'KEYS'										=> array(
					'tour_id'								=> array('INDEX', 'tour_id'),
					'user_id'								=> array('INDEX', 'user_id'),
					'game_id'								=> array('INDEX', 'game_id')
				)
			),
			"{$table_prefix}arcade_users"				=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'user_arcade_permissions'				=> array('MTEXT', ''),
					'user_arcade_perm_from'					=> array('UINT', 0),
					'user_arcade_last_download'				=> array('TIMESTAMP', 0),
					'user_arcade_last_play'					=> array('TIMESTAMP', 0),
					'user_arcade_options'					=> array('UINT:11', 223),
					'user_arcade_rank'						=> array('UINT', 0),
					'games_last_search'						=> array('TIMESTAMP', 0),
					'games_last_search_term'				=> array('VCHAR', ''),
					'games_sort_dir'						=> array('VCHAR_UNI:1', 'a'),
					'games_sort_order'						=> array('VCHAR_UNI:1', 'n'),
					'arcade_total_played'					=> array('UINT', 0),
					'arcade_total_plays'					=> array('UINT', 0),
					'arcade_total_time'						=> array('UINT', 0),
					'arcade_total_wins'						=> array('UINT', 0),
					'arcade_total_super_scores'				=> array('UINT', 0),
					'arcade_total_downloads'				=> array('UINT', 0),
					'arcade_cat_style'						=> array('TINT:1', 0),
					'arcade_cat_games_style'				=> array('TINT:1', 0)
		/*
					'arcade_challenge_plays'				=> array('UINT', 0),
					'arcade_challenge_wins'					=> array('UINT', 0),
					'arcade_tournament_plays'				=> array('UINT', 0),
					'arcade_tournament_wins'				=> array('UINT', 0),
		*/
				),
				'PRIMARY_KEY'								=> 'user_id'
			),
			"{$table_prefix}arcade_users_banned"		=> array(
				'COLUMNS'									=> array(
					'user_id'								=> array('UINT', 0),
					'banned_type'							=> array('TINT:1', 0),
					'banned_ip'								=> array('VCHAR:40', ''),
					'banned_date'							=> array('TIMESTAMP', 0),
					'game_id'								=> array('UINT', 0),
					'formtime'								=> array('UINT:11', 0),
					'score'									=> array('DECIMAL:25', 0.00)
				),
				'PRIMARY_KEY'								=> 'user_id'
			)
		);
	}
}
