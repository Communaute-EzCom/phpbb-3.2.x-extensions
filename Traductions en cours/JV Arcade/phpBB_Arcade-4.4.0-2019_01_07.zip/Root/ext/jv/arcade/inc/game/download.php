<?php
/**
*
* @package phpBB Arcade
* @version $Id: download.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class download
{
	protected $db, $cache, $user, $auth, $request, $template, $arcade_config, $arcade_auth, $arcade, $file_functions, $root_path, $php_ext;

	public function __construct($db, $cache, $user, $auth, $request, $template, $arcade_config, $arcade_auth, $arcade, $file_functions, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->cache = $cache;
		$this->user = $user;
		$this->auth = $auth;
		$this->request = $request;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->file_functions = $file_functions;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function prep($game_id, $type)
	{
		if (!$game_id)
		{
			trigger_error($this->user->lang['NO_GAME_ID'] . $this->arcade->back_link());
		}

		$game_info = $this->arcade->get()->game_cat_data($game_id);

		if (!$this->arcade->game()->download_auth('user_cat', $game_info['cat_id'], true, true, true))
		{
			send_status_line(403, 'Forbidden');
			trigger_error($this->user->lang['NO_PERMISSION_ARCADE_DOWNLOAD'] . $this->arcade->back_link());
		}
		else
		{
			if (!$this->arcade->game()->download_auth('user_cat', $game_info['cat_id'], true, true))
			{
				trigger_error($this->user->lang['ARCADE_CAT_LOCKED_ERROR'] . $this->arcade->back_link());
			}

			if (!$this->arcade->game()->download_auth('user_cat', $game_info['cat_id'], $game_info['cat_download'], $game_info['game_download'], true))
			{
				trigger_error(sprintf($this->user->lang['ARCADE_GAME_DOWNLOAD_NOT_ALLOWED'], $game_info['game_name']) . $this->arcade->back_link());
			}

			if (!$game_info['game_swf'])
			{
				trigger_error(sprintf($this->user->lang['ARCADE_EMPTY_VALUE_ERROR'], 'game_swf') . $this->arcade->back_link());
			}

			// Check flood control
			$interval				= intval(($this->user->data['user_id'] == ANONYMOUS) ? $this->arcade_config['download_anonymous_interval'] : $this->arcade_config['download_interval']);
			$download_per_day_group	= $this->arcade->download_groups_days($this->user->data['group_id'], null);
			$download_per_day		= ($download_per_day_group) ? $download_per_day_group : intval($this->arcade_config['download_per_day']);

			if (($interval || $download_per_day) && !$this->arcade->game()->download_auth('flood', $game_info['cat_id']))
			{
				$diff_time = time() - $interval;

				if ($interval && $this->user->data['user_arcade_last_download'] > $diff_time)
				{
					trigger_error(sprintf($this->user->lang['ARCADE_NO_DOWNLOAD_TIME'], $this->arcade->time_format($interval, true), $this->arcade->time_format($this->user->data['user_arcade_last_download'] - $diff_time, true)) . $this->arcade->back_link());
				}

				if ($download_per_day)
				{
					$sql = 'SELECT COUNT(game_id) AS total
							FROM ' . ARCADE_DOWNLOAD_TABLE . '
							WHERE user_id = ' . (int) $this->user->data['user_id'] . '
								AND download_time > ' . $this->arcade->time_stamp(gmdate('Y'), gmdate('n'), gmdate('j'));
					$result = $this->db->sql_query($sql);
					$download_total = (int) $this->db->sql_fetchfield('total');
					$this->db->sql_freeresult($result);

					if ($download_total >= $download_per_day)
					{
						trigger_error(sprintf($this->user->lang['ARCADE_GAME' . (($download_per_day > 1) ? 'S' : '') . '_NOT_DOWNLOAD_DAY'], $this->arcade->number_format($download_per_day)) . $this->arcade->back_link());
					}
				}
			}

			$this->arcade->add_navlink('cat_game', 'mode=play', '', $game_info);

			$use_method = ($this->arcade_config['download_file_type'] !== '') ? $this->arcade_config['download_file_type'] : $this->request->variable('use_method', '');
			$methods = $this->arcade->compress_methods();

			$show_points = false;
			if ($this->arcade->points()->data['show'] && !$this->arcade->test_system())
			{
				$game_download_cost = $this->arcade->points()->game_download_cost($game_info);

				if ($game_download_cost != ARCADE_FREE && $game_download_cost > 0 && !$this->arcade_auth->acl_get('c_downloadfree', $game_info['cat_id']))
				{
					$show_points = true;

					if ($this->arcade->points()->data['total'] < $game_download_cost)
					{
						trigger_error(sprintf($this->user->lang['ARCADE_NO_POINTS_DOWLOAD'], $this->arcade->points()->data['name']) . $this->arcade->back_link());
					}
				}
			}

			// Let the user decide in which format he wants to have the game downloaded in
			if ((!$this->request->variable('download', false) && $show_points && $type != 'acp') || (!$use_method))
			{
				$disabled_method = ($this->arcade_config['download_file_type'] !== '') ? true : false;
				$this->arcade->page_title = sprintf($this->user->lang[(($disabled_method) ? 'DOWNLOADING_GAME' : 'ARCADE_DOWNLOAD_FORMAT')], $game_info['game_name']);

				$radio_buttons = '';

				if (!$disabled_method)
				{
					foreach ($methods as $method)
					{
						$checked = (($method == $use_method) || (!$use_method && $method == '.tar')) ? ' checked="checked"' : '';
						$radio_buttons .= '<input type="radio"' . ((!$radio_buttons) ? ' id="use_method"' : '') . ' class="radio" value="' . $method . '" name="use_method"' . $checked . '>&nbsp;' . $method . '&nbsp;';
					}
				}

				$this->template->assign_vars(array(
					'S_DOWNLOAD_GAME_COST'		=> $show_points,
					'S_SELECT_METHOD'			=> (!$this->arcade_config['download_file_type']) ? true : false,
					'U_ACTION'					=> $this->arcade->url("mode=download&amp;g={$game_id}"),

					'L_ARCADE_DOWNLOAD_COST'	=> ($show_points) ? sprintf($this->user->lang['ARCADE_DOWNLOAD_COST_POINTS'], $this->arcade->number_format($game_download_cost) . ' ' . $this->arcade->points()->data['name']) : '',
					'GAME_NAME'					=> $game_info['game_name'],
					'ARCADE_DOWNLOAD_FORMAT'	=> $this->arcade->page_title,
					'RADIO_BUTTONS'				=> $radio_buttons
				));

				$this->arcade->display()->main_box('arcade', $this->arcade_config['welcome_download'], $this->arcade_config['search_download']);
				$this->arcade->display()->online_playing();
				$this->arcade->display()->page($this->arcade->page_title, 'arcade/download_body.html');
			}

			$this->download($game_info, $use_method, $methods);
		}
	}

	public function download($game, $use_method, $methods, $update = true, $download = true, $trigger = true)
	{
		if (!class_exists('compress'))
		{
			include($this->root_path . 'includes/functions_compress.' . $this->php_ext);
		}

		$backup_path = $this->root_path . $this->arcade_config['cat_backup_path'] . $this->characters_encoding($this->arcade->get()->cat_field($game['cat_id'], 'cat_name')) . '/';
		$path = ($download && $this->arcade_config['download_on_demand']) ? $this->root_path . 'store/' : $backup_path;

		// If we are not in download mode or we are but we are not serving games on demand
		// we check for and setup the backup directory category folder
		if (!$download || ($download && !$this->arcade_config['download_on_demand']))
		{
			if (!phpbb_is_writable($this->root_path . $this->arcade_config['cat_backup_path']))
			{
				trigger_error(sprintf($this->user->lang['ARCADE_ERROR_DIR_WRITABLE'], $this->arcade_config['cat_backup_path']), E_USER_WARNING);
			}

			if (!file_exists($path))
			{
				@mkdir($path, 0777);
				phpbb_chmod($path, CHMOD_READ | CHMOD_WRITE);
			}

			if (!file_exists($path . 'index.htm') && !file_exists($path . 'index.html'))
			{
				$content = '';
				$this->file_functions->write_file($path . 'index.htm', $content, false);
				phpbb_chmod($path . 'index.htm');
			}

			if (!phpbb_is_writable($path))
			{
				trigger_error(sprintf($this->user->lang['ARCADE_ERROR_DIR_WRITABLE'], str_replace($this->root_path, '', $path)), E_USER_WARNING);
			}
		}

		if ($update && !$this->arcade->test_system())
		{
			$this->update_total($game['game_id']);
			$this->arcade_config->increment('total_downloads', 1);
		}

		$filename = $this->file_functions->remove_extension($game['game_swf']);

		if (!in_array($use_method, $methods))
		{
			$use_method = '.tar';
		}

		// If the file exists in the backup directory and if the file modification time of the game install file is less than or equal to
		// the file modification time of the compressed folder in the backup directory send the file in the backup directory instead
		// of creating the compressed file again.
		if ($download && file_exists($backup_path . $filename . $use_method) && (@filemtime($this->arcade->set_path($game['game_swf'], 'install')) <= @filemtime($backup_path . $filename . $use_method)))
		{
			$this->send_download_to_browser($backup_path, $filename, $use_method);
			garbage_collection();
			exit_handler();
		}

		$game_file = $this->arcade->set_path($game['game_swf'], '', true, $game['game_type'], $game['game_save_type']);
		$game_path = $this->arcade->set_path($game['game_swf'], 'path');
		$gamedata = $this->arcade->game()->file_path($game['game_swf']);

		$error = array();
		if (!file_exists($game_file))
		{
			$error[] = $this->arcade->root_key($game_file);
		}

		if (count($error))
		{
			if (!$this->arcade->test_system())
			{
				$this->arcade->add_log('critical', $game['game_id'], 'LOG_ARCADE_ERROR_GAME_FILE_MISSING', $game['game_name'], implode('<br>', $error));
			}

			if ($trigger)
			{
				if ($this->auth->acl_get('a_') && defined('DEBUG'))
				{
					trigger_error(sprintf($this->user->lang['ARCADE_DOWNLOAD_MISSING_FILES_DEBUG'], implode('<br>', $error)) . $this->arcade->back_link());
				}
				else
				{
					trigger_error(sprintf($this->user->lang['ARCADE_DOWNLOAD_MISSING_FILES']) . $this->arcade->back_link());
				}
			}
		}

		if ($use_method == '.zip')
		{
			$compress = new \compress_zip('w', $path . $filename . $use_method);
		}
		else
		{
			$compress = new \compress_tar('w', $path . $filename . $use_method, $use_method);
		}

		$file_list = $this->file_functions->filelist($game_path, '', false);

		if ($gamedata)
		{
			$file_list = array_merge($file_list, $this->file_functions->filelist($gamedata, '', false));
		}

		// Correct path locations before adding files
		$dir_list = array();
		$search = array($game_path, $this->root_path . 'arcade/gamedata', $this->root_path . 'games');
		$replace = array('', 'gamedata', 'games');

		// Add all the game files
		$file_list = array_unique($file_list);
		foreach ($file_list as $file)
		{
			$dir_list[] = dirname($file);
			$compress->add_custom_file($file, str_replace($search, $replace, $file));
		}
		unset($file_list);
/*
		// Add blank index.htm files
		$dir_list = array_unique($dir_list);
		foreach ($dir_list as $dir)
		{
			$this->file_functions->append_slash($dir);
			$compress->add_data('', str_replace($search, $replace, $dir) . 'index.htm');
		}
		unset($dir_list);
*/
		// Close file
		$compress->close();

		if ($download)
		{
			$this->send_download_to_browser($path, $filename, $use_method);
			// Delete file from the store once user downloads it if serving download on demand
			if ($this->arcade_config['download_on_demand'])
			{
				@unlink($path . $filename . $use_method);
			}

			if ($this->arcade->points()->data['show'])
			{
				$game_download_cost = $this->arcade->points()->game_download_cost($game);

				if ($game_download_cost != ARCADE_FREE && $game_download_cost > 0 && !$this->arcade_auth->acl_get('c_downloadfree', $game['cat_id']))
				{
					$this->arcade->points()->set('subtract', $this->user->data['user_id'], $game_download_cost);
				}
			}

			garbage_collection();
			exit_handler();
		}
	}

	private function update_total($game_id)
	{
		$time = time();
		// Update download count
		$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
				SET game_download_total = game_download_total + 1
				WHERE game_id = ' . (int) $game_id;
		$this->db->sql_query($sql);

		$sql = 'UPDATE ' . ARCADE_DOWNLOAD_TABLE . '
				SET total = total + 1, download_time = ' . $time . '
				WHERE game_id = ' . (int) $game_id . ' AND user_id = ' . (int) $this->user->data['user_id'];
		$this->db->sql_query($sql);

		if (!$this->db->sql_affectedrows())
		{
			$sql_ary = array(
				'game_id'		=> (int) $game_id,
				'user_id'		=> (int) $this->user->data['user_id'],
				'total'			=> 1,
				'download_time'	=> $time
			);

			$this->db->sql_query('INSERT INTO ' . ARCADE_DOWNLOAD_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
		}

		$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
				SET user_arcade_last_download = ' . $time . ', arcade_total_downloads = arcade_total_downloads + 1
				WHERE user_id = ' . (int) $this->user->data['user_id'];
		$this->db->sql_query($sql);

		$this->cache->destroy('sql', ARCADE_GAMES_TABLE);
	}

	private function characters_encoding($string)
	{
		$string = str_replace(array("\xC3\x80", "\xC3\x81", "\xC3\x82", "\xC3\x83", "\xC3\x84", "\xC3\x85")				, "\x41", $string); // A
		$string = str_replace(array("\xC3\x88", "\xC3\x89", "\xC3\x8a", "\xC3\x8b")										, "\x45", $string); // E
		$string = str_replace(array("\xC3\x8c", "\xC3\x8d", "\xC3\x8e", "\xC3\x8f")										, "\x49", $string); // I
		$string = str_replace(array("\xC3\x92", "\xC3\x93", "\xC3\x94", "\xC3\x95", "\xC3\x96", "\xC5\x90")				, "\x4F", $string); // O
		$string = str_replace(array("\xC3\x99", "\xC3\x9a", "\xC3\x9b", "\xC3\x9c", "\xC5\xB0")							, "\x55", $string); // U
		$string = str_replace(array("\xC3\x9d")																			, "\x59", $string); // Y
		$string = str_replace(array("\xC3\xa0", "\xC3\xa1", "\xC3\xa2", "\xC3\xa3", "\xC3\xa4", "\xC3\xa5")				, "\x61", $string); // a
		$string = str_replace(array("\xC3\xa8", "\xC3\xa9", "\xC3\xaa", "\xC3\xab")										, "\x65", $string); // e
		$string = str_replace(array("\xC3\xac", "\xC3\xad", "\xC3\xae", "\xC3\xaf")										, "\x69", $string); // i
		$string = str_replace(array("\xC3\xb1")																			, "\x6e", $string); // n
		$string = str_replace(array("\xC3\xb2", "\xC3\xb3", "\xC3\xb4", "\xC3\xb5", "\xC3\xb6", "\xC3\xb0", "\xC5\x91")	, "\x6F", $string); // o
		$string = str_replace(array("\xC3\xb9", "\xC3\xba", "\xC3\xbb", "\xC3\xbc", "\xC5\xB1")							, "\x75", $string); // u
		$string = str_replace(array("\xC3\xbd", "\xC3\xbf")																, "\x79", $string); // y
		$string = str_replace(" "																						, "_"	, $string); // space

		return trim(preg_replace('/[^\w -]+/', '', htmlspecialchars_decode($string)));
	}

	private function send_download_to_browser($path, $filename, $use_method, $download_name = false)
	{
		if ($download_name === false)
		{
			$download_name = $filename;
		}

		header('Cache-Control: public');
		header("Content-Type: " . $this->file_functions->mime_type($use_method));
		header("Content-Disposition: attachment; " . $this->file_functions->header_filename($download_name . $use_method));

		$game_file = $path . $filename . $use_method;
		$size = @filesize($game_file);

		if ($size)
		{
			header("Content-Length: $size");
		}

		$fp = @fopen($game_file, 'rb');

		if ($fp)
		{
			while (!feof($fp))
			{
				echo fread($fp, 1024);
			}

			fclose($fp);
		}
		else
		{
			@readfile($game_file);
		}

		flush();
	}
}
