<?php
/**
*
* @package phpBB Arcade
* @version $Id: content.php 2121 2018-12-16 16:57:57Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class content
{
	protected $db, $auth, $user, $arcade_cache, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext;

	public function __construct($db, $auth, $user, $arcade_cache, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->user = $user;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function total($mode, $action, $id = false, $zero = false, $ca = false, $s_can_play = false, $details = false, $sec_id = false)
	{
		if (!in_array($mode, array('game', 'user')) || !$action)
		{
			return 0;
		}

		$left_join	= '';
		$one		= false;
		$array		= false;
		$mode		= strtolower($mode);
		$action		= strtolower($action);
		$game_mode	= (strpos($action, 'challenge') === false) ? 'arcade' : 'challenge';

		switch ($mode)
		{
			case 'game':
				switch ($action)
				{
					case 'games':
						$where = ($id) ? 'g.cat_id = ' . (int) $id : '1=1';
					break;

					case 'search':
						$where  = $this->db->sql_in_set('g.cat_id', $this->game_search_protection(), true, true);
						$where .= ' AND g.game_name_clean ' . $this->db->sql_like_expression($id);
					break;

					case 'search_char':
						$where  = $this->db->sql_in_set('g.cat_id', $this->game_search_protection(), true, true);
						$where .= ' AND g.game_name_clean ' . $this->db->sql_like_expression(substr($id, 0, 1) . $this->db->get_any_char());
					break;

					case 'search_char_other':
						$where = $this->db->sql_in_set('g.cat_id', $this->game_search_protection(), true, true);

						for ($i = 97; $i < 123; $i++)
						{
							$where .= ' AND g.game_name_clean NOT ' . $this->db->sql_like_expression(chr($i) . $this->db->get_any_char());
						}
					break;

					case 'search_newgames':
						$where  = $this->db->sql_in_set('g.cat_id', $this->game_search_protection(), true, true);
						$where .= ' AND g.game_installdate >= ' . (int) $id;
					break;

					case 'games_search':
						$where = 'g.game_name_clean ' . $this->db->sql_like_expression($id);

						if ($sec_id)
						{
							$where .= ' AND g.cat_id = ' . (int) $sec_id;
						}
					break;

					case 'favorites':
						$left_join	= ' LEFT JOIN ' . ARCADE_FAVS_TABLE . ' f ON g.game_id = f.game_id';
						$where		= 'g.game_id = f.game_id' . (($id) ? ' AND f.user_id = ' . (int) $id : '');
					break;

					case 'downloaded_games':
						$where = (($zero) ? '1=1' : 'g.game_download_total > 0') . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'played_games':
						if ($details)
						{
							$left_join	 = ' LEFT JOIN ' . ARCADE_PLAYS_TABLE . ' p ON g.game_id = p.game_id';
							$where		 = ($zero) ? '1=1' : 'g.game_id = p.game_id';
						}
						else
						{
							$where = ($zero) ? '1=1' : 'g.game_plays > 0';
						}

					case 'not_played_games':
						$where = ($action == 'not_played_games') ? 'g.game_plays = 0' : $where;

						if ($id)
						{
							$where .= ' AND g.cat_id = ' . (int) $id;
						}
					break;

					case 'super_champions':
						$left_join	= ' LEFT JOIN ' . ARCADE_SUPER_SCORES_TABLE . ' s ON g.game_id = s.game_id';
						$where		= 'g.game_id = s.game_id' . (($id) ? ' AND s.user_id = ' . (int) $id : '') . (($sec_id) ? ' AND g.cat_id = ' . (int) $sec_id : '');
					break;

					case 'favs':
						$left_join	= ' LEFT JOIN ' . ARCADE_FAVS_TABLE . ' f ON g.game_id = f.game_id';
						$where		= 'g.game_id = f.game_id' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'rated_games':
						$where		= 'g.game_votetotal > 0' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'games_jackpots':
						$where		= 'g.game_jackpot > 0 AND ' . $this->db->sql_in_set('g.game_id', $this->arcade->points()->get_games_jackpot(), false, true) . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'challenge_played_games':
						$left_join	= ' LEFT JOIN ' . ARCADE_CHALLENGE_CHAMP_TABLE . ' cc ON g.game_id = cc.game_id';
						$where		= 'g.game_id = cc.game_id AND cc.champ_close = ' . CHALLENGE_CLOSE . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'tour_played_games':
						$left_join	= ' LEFT JOIN ' . ARCADE_TOUR_CHAMP_TABLE . ' tc ON g.game_id = tc.game_id';
						$left_join .= ' LEFT JOIN ' . ARCADE_TOUR_TABLE . ' t ON tc.tour_id = t.tour_id';
						$where		= 'g.game_id = tc.game_id AND tc.tour_id = t.tour_id AND t.tour_status = ' . ARCADE_END_TOUR . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					// use current only acp
					case 'downloads':
						$left_join  = ' LEFT JOIN ' . ARCADE_DOWNLOAD_TABLE . ' d ON g.game_id = d.game_id';
						$where		= 'g.game_id = d.game_id' . (($id) ? ' AND d.user_id = ' . (int) $id : '') . (($zero) ? ' AND d.download_time >= ' . (time() - ($zero * 86400)) : '');
					break;

					case 'scores_or_super_champions':
						$left_join  = ' LEFT JOIN ' . ARCADE_SCORES_TABLE . ' s ON g.game_id = s.game_id';
						$left_join .= ' LEFT JOIN ' . ARCADE_SUPER_SCORES_TABLE . ' sc ON g.game_id = sc.game_id';
						$where		= '(g.game_id = s.game_id OR g.game_id = sc.game_id)';
					break;

					case 'plays_data':
						$array = true;
						$sql = 'SELECT SUM(total_plays) AS t_plays, SUM(total_time) AS t_time
								FROM ' . ARCADE_PLAYS_TABLE;
					break;

					case 'all_downloads':
						$one = true;
						$sql = 'SELECT SUM(total) AS total
								FROM ' . ARCADE_DOWNLOAD_TABLE;
					break;

					case 'reports':
						$one = true;
						$sql = 'SELECT COUNT(report_id) AS total
								FROM ' . ARCADE_REPORTS_TABLE;

						if ($id)
						{
							$sql .= ' WHERE report_time >= ' . (time() - ($id * 86400));
						}
					break;

					case 'reports_open':
						$one = true;
						$sql = 'SELECT COUNT(report_id) AS total
								FROM ' . ARCADE_REPORTS_TABLE . '
								WHERE report_closed = ' . ARCADE_REPORT_OPEN;
					break;

					case 'total_challs':
						$array = true;
						$sql = 'SELECT COUNT(champ_id) AS total_plays, SUM(champ_challenger_time + champ_opponent_time) AS total_times
								FROM ' . ARCADE_CHALLENGE_CHAMP_TABLE . '
								WHERE champ_close = ' . CHALLENGE_CLOSE;
					break;

					case 'total_tours':
						$one = true;
						$sql = 'SELECT COUNT(tour_id) AS total
								FROM ' . ARCADE_TOUR_TABLE . '
								WHERE tour_status ' . (($id) ? '= ' : '<> ') . ARCADE_END_TOUR;
					break;

					case 'tour_total_data':
						$array = true;
						$sql = 'SELECT SUM(tc.total_plays) AS total_plays, SUM(tc.total_time) AS total_times
								FROM ' . ARCADE_TOUR_TABLE . ' t
								LEFT JOIN ' . ARCADE_TOUR_CHAMP_TABLE . '  tc ON t.tour_id = tc.tour_id
								WHERE t.tour_status = ' . ARCADE_END_TOUR;
					break;

					case 'deleted_games':
						$one = true;
						$sql = 'SELECT COUNT(game_swf) AS total FROM ' . ARCADE_DELETE_GAMES_TABLE;

						if ($id)
						{
							$sql .= ' WHERE uninstalldate >= ' . (time() - ($id * 86400));
						}
					break;

					default:
						return 0;
					break;
				}
			break;

			case 'user':
				switch ($action)
				{
					case 'played_users':
						if ($ca || $id)
						{
							$left_join	= ' LEFT JOIN ' . ARCADE_PLAYS_TABLE . ' p ON u.user_id = p.user_id';
							$where		= ($zero) ? '1=1' : 'u.user_id = p.user_id';

							$left_join .= ' LEFT JOIN ' . ARCADE_GAMES_TABLE . ' g ON p.game_id = g.game_id';
							$where	   .= ' AND p.game_id = g.game_id' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
						}
						else
						{
							$left_join	= ' LEFT JOIN ' . ARCADE_USERS_TABLE . ' au ON u.user_id = au.user_id';
							$where		= ($zero) ? '1=1' : 'u.user_id = au.user_id AND au.arcade_total_plays > 0';
						}
					break;

					case 'highscores':
						if ($ca || $id)
						{
							$left_join	= ' LEFT JOIN ' . ARCADE_GAMES_TABLE . ' g ON u.user_id = g.game_highuser';
							$where		= 'u.user_id = g.game_highuser' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
						}
						else
						{
							$left_join	= ' LEFT JOIN ' . ARCADE_USERS_TABLE . ' au ON u.user_id = au.user_id';
							$where		= 'u.user_id = au.user_id AND au.arcade_total_wins > 0';
						}
					break;

					case 'super_champions':
						if ($ca || $id)
						{
							$left_join	 = ' LEFT JOIN ' . ARCADE_SUPER_SCORES_TABLE . '  s ON u.user_id = s.user_id';
							$left_join	.= ($id) ? ' LEFT JOIN ' . ARCADE_GAMES_TABLE . ' g ON s.game_id = g.game_id' : '';
							$where		 = 'u.user_id = s.user_id' . (($id) ? ' AND s.game_id = g.game_id AND g.cat_id = ' . (int) $id : '');
						}
						else
						{
							$left_join	 = ' LEFT JOIN ' . ARCADE_USERS_TABLE . ' au ON u.user_id = au.user_id';
							$where		 = 'u.user_id = au.user_id AND au.arcade_total_super_scores > 0';
						}
					break;

					case 'challenge_played_users':
						$left_join	= ' LEFT JOIN ' . ARCADE_CHALLENGE_CHAMP_TABLE . ' cc ON u.user_id = cc.champ_challenger_id OR u.user_id = cc.champ_opponent_id';
						$where		= 'cc.champ_close = ' . CHALLENGE_CLOSE . ' AND (u.user_id = cc.champ_challenger_id OR u.user_id = cc.champ_opponent_id)';
					break;

					case 'challenge_winners':
						$left_join	= ' LEFT JOIN ' . ARCADE_CHALLENGE_CHAMP_TABLE . ' cc ON u.user_id = cc.champ_winner';
						$where		= 'cc.champ_close = ' . CHALLENGE_CLOSE . ' AND u.user_id = cc.champ_winner';
					break;

					case 'tour_winners':
						$left_join	= ' LEFT JOIN ' . ARCADE_TOUR_TABLE . ' t ON u.user_id = t.tour_wins';
						$where		= 't.tour_status = ' . ARCADE_END_TOUR . ' AND u.user_id = t.tour_wins';
					break;

					case 'tour_played_users':
						$left_join	= ' LEFT JOIN ' . ARCADE_TOUR_CHAMP_TABLE . ' tc ON u.user_id = tc.user_id';
						$left_join .= ' LEFT JOIN ' . ARCADE_TOUR_TABLE . ' t ON tc.tour_id = t.tour_id';
						$where		= 't.tour_status = ' . ARCADE_END_TOUR . ' AND tc.tour_id = t.tour_id AND u.user_id = tc.user_id';
					break;

					// use only acp
					case 'downloads':
						$left_join  = ' LEFT JOIN ' . ARCADE_DOWNLOAD_TABLE . ' d ON u.user_id = d.user_id';
						$where		= 'u.user_id = d.user_id' . (($zero) ? ' AND d.download_time >= ' . (time() - ($zero * 86400)) : '');
					break;

					case 'scores':
						$left_join	= ' LEFT JOIN ' . ARCADE_SCORES_TABLE . ' s ON u.user_id = s.user_id';
						$where		= 'u.user_id = s.user_id' . (($id) ? ' AND s.game_id = ' . (int) $id : '');
					break;

					case 'banned':
						$one = true;
						$sql = 'SELECT COUNT(user_id) AS total FROM ' . ARCADE_USERS_BANNED_TABLE;

						if ($id)
						{
							$sql .= ' WHERE banned_date >= ' . (time() - ($id * 86400));
						}
					break;

					default:
						return 0;
					break;
				}

			break;
		}

		if (!$one && !$array)
		{
			$and_game_cats = '';
			if ($ca)
			{
				$c_auth = ($s_can_play) ? 'c_play' : array('c_view', 'c_play');
				$cat_ids = $this->permissions($c_auth);

				if ($action == 'downloaded_games')
				{
					$cat_ids = array_intersect($this->permissions('c_download'), $cat_ids);
				}

				$and_game_cats = ' AND ' . $this->db->sql_in_set('g.cat_id', array_map('intval', $cat_ids), false, true);
			}

			$and_user_type = ' AND u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')';

			switch ($mode)
			{
				case 'game':
					$column_name = 'g.game_id';
					$table_name  = ARCADE_GAMES_TABLE . ' g';
					$and_user_type = '';
				break;

				case 'user':
					$column_name = 'u.user_id';
					$table_name  = USERS_TABLE . ' u';
					$and_game_cats = '';
				break;
			}

			if ($this->db->get_sql_layer() === 'sqlite3')
			{
				$sql = "SELECT COUNT({$column_name}) AS total
						FROM (
							SELECT DISTINCT {$column_name}
							FROM {$table_name}
							{$left_join}
							WHERE {$where} {$and_game_cats} {$and_user_type}
						)";
			}
			else
			{
				$sql = "SELECT COUNT(DISTINCT {$column_name}) AS total
						FROM {$table_name}
						{$left_join}
						WHERE {$where} {$and_game_cats} {$and_user_type}";
			}
		}

		$sql = str_replace(array('1=1 AND', 'AND 1=1'), '', $sql);

		$result = $this->db->sql_query($sql);
		$total = ($array) ? $this->db->sql_fetchrow($result) : (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		return $total;
	}

	public function game_search_protection()
	{
		$cat_ids = array();

		// Bots exemption age limit
		$bots_exemption	= (!$this->user->data['is_registered'] && $this->user->data['is_bot']) ? true : false;
		$pass_check		= (($this->arcade_config['search_filter_password'] == ARCADE_CHECK_EVERYONE) || ($this->arcade_config['search_filter_password'] == ARCADE_CHECK_USER_NORMAL && $this->user->data['user_type'] != USER_FOUNDER)) ? true : false;
		$age_check		= (!$bots_exemption && (($this->arcade_config['search_filter_age'] == ARCADE_CHECK_EVERYONE) || ($this->arcade_config['search_filter_age'] == ARCADE_CHECK_USER_NORMAL && $this->user->data['user_type'] != USER_FOUNDER))) ? true : false;

		if (!$pass_check && !$age_check)
		{
			return $cat_ids;
		}

		$sql = 'SELECT c.cat_id, c.cat_age, c.cat_password, a.user_id
				FROM ' . ARCADE_CATS_TABLE . ' c
				LEFT JOIN ' . ARCADE_ACCESS_TABLE . " a ON (c.cat_id = a.cat_id
				AND a.session_id = '" . $this->db->sql_escape($this->user->session_id) . "' AND a.user_id = " . $this->user->data['user_id'] . ")";
		$result = $this->db->sql_query($sql);

		$user_age = $this->user_age();

		while($row = $this->db->sql_fetchrow($result))
		{
			if (($user_age === '' && $row['cat_age'] && $age_check) || ($row['cat_age'] && $user_age < $row['cat_age'] && $age_check) || ($row['cat_password'] && $row['user_id'] != $this->user->data['user_id'] && $pass_check))
			{
				// forbidden categories
				$cat_ids[] = $row['cat_id'];
			}
		}
		$this->db->sql_freeresult($result);

		return $cat_ids;
	}

	public function permissions($opts)
	{
		$return = array();

		if (!is_array($opts))
		{
			$opts = array($opts);
		}

		foreach ($opts as $opt)
		{
			$return = array_merge($return, array_keys($this->arcade_auth->acl_getc($opt, true)));
		}

		return array_unique($return);
	}

	public function user_age($user_birthday = false)
	{
		if ($user_birthday === false)
		{
			$user_birthday = $this->user->data['user_birthday'];
		}

		$age = '';

		if ($user_birthday)
		{
			list($bday_day, $bday_month, $bday_year) = array_map('intval', explode('-', $user_birthday));

			if ($bday_year)
			{
				$now = $this->user->create_datetime();
				$now = phpbb_gmgetdate($now->getTimestamp() + $now->getOffset());

				$diff = $now['mon'] - $bday_month;
				if ($diff == 0)
				{
					$diff = ($now['mday'] - $bday_day < 0) ? 1 : 0;
				}
				else
				{
					$diff = ($diff < 0) ? 1 : 0;
				}

				$age = max(0, (int) ($now['year'] - $bday_year - $diff));
			}
		}

		return $age;
	}

	/**
	* Get one of the following fields from the games:
	*
	* game_id -> game_name, game_image, game_width, game_height, cat_id
	*/
	public function game_field($game_id, $field, $deb = true)
	{
		if (isset($this->arcade->games()[$game_id][$field]))
		{
			return $this->arcade->games()[$game_id][$field];
		}

		if ($deb)
		{
			if (!isset($this->arcade->games()[$game_id]))
			{
				$msg = sprintf($this->user->lang['ARCADE_INVALID_GAME_ID'], $game_id);
			}
			else
			{
				$msg = sprintf($this->user->lang['ARCADE_INVALID_FIELD'], $field);
			}

			trigger_error($msg, E_USER_ERROR);
		}

		return false;
	}

	/**
	* Get one of the following fields from the categories:
	*
	* cat_id, cat_name, cat_style, cat_status, cat_link, cat_type, cat_test, cat_age, cat_download, cat_password, cat_rules
	* cat_rules_link, parent_id, cat_parents, left_id, right_id, cat_desc, cat_desc_options, cat_desc_uid
	* cat_desc_bitfield, cat_rules_options, cat_rules_uid, cat_rules_bitfield, cat_games_per_page, cat_use_jackpot, cat_flags
	*/
	public function cat_field($cat_id, $field, $deb = true)
	{
		if (isset($this->arcade->cats()[$cat_id][$field]))
		{
			return $this->arcade->cats()[$cat_id][$field];
		}

		if ($deb)
		{
			if (!isset($this->arcade->cats()[$cat_id]))
			{
				$msg = sprintf($this->user->lang['ARCADE_INVALID_CAT_ID'], $cat_id);
			}
			else
			{
				$msg = sprintf($this->user->lang['ARCADE_INVALID_FIELD'], $field);
			}

			trigger_error($msg, E_USER_ERROR);
		}

		return false;
	}

	/**
	* Get one of the following fields from the tournament:
	*
	* tour_id, tour_name, tour_status
	*/
	public function tour_field($tour_id, $field, $deb = true)
	{
		if (isset($this->arcade->tours()[$tour_id][$field]))
		{
			return $this->arcade->tours()[$tour_id][$field];
		}

		if ($deb)
		{
			if (!isset($this->arcade->tours()[$tour_id]))
			{
				$msg = sprintf($this->user->lang['ARCADE_TOUR_ID_ERROR'], $tour_id);
			}
			else
			{
				$msg = sprintf($this->user->lang['ARCADE_INVALID_FIELD'], $field);
			}

			trigger_error($msg, E_USER_ERROR);
		}

		return false;
	}

	// This code is used to calculate the actual rank.
	// For example if there are ties...
	public function actual_rank(&$actual_rank, &$rank, $value, &$last_value, $ignore_empty = false)
	{
		$value = (is_numeric($value)) ? $value : 0;
		$actual_rank++;

		if ((!$ignore_empty && !$value) || $last_value != $value)
		{
			$rank = $actual_rank;
		}

		$last_value = $value;
	}

	public function user_rank($user_rank, $user_records, $width = false)
	{
		static $_cache_arcade_ranks;

		$data = array(
			'rank_title'	=> '',
			'rank_img'		=> '',
			'rank_img_src'	=> ''
		);

		if (!isset($_cache_arcade_ranks))
		{
			$_cache_arcade_ranks = $this->arcade_cache->obtain_arcade_ranks();
		}

		if (!empty($user_rank))
		{
			if (!empty($_cache_arcade_ranks['special'][$user_rank]['rank_image']) && $rank_src = $this->image('src', 'rank', $_cache_arcade_ranks['special'][$user_rank]['rank_image']))
			{
				$data = array(
					'rank_title'	=> $_cache_arcade_ranks['special'][$user_rank]['rank_title'],
					'rank_img'		=> '<img src="' . $rank_src . '" alt="' . $_cache_arcade_ranks['special'][$user_rank]['rank_title'] . '" title="' . $_cache_arcade_ranks['special'][$user_rank]['rank_title'] . '"' . (($width) ? ' width="' . $width . '"' : '') . '>',
					'rank_img_src'	=> $rank_src
				);
			}
			else if (!empty($_cache_arcade_ranks['special'][$user_rank]['rank_title']))
			{
				$data['rank_title'] = $_cache_arcade_ranks['special'][$user_rank]['rank_title'];
			}
		}
		else if ($user_records !== false)
		{
			if (!empty($_cache_arcade_ranks['normal']))
			{
				foreach ($_cache_arcade_ranks['normal'] as $rank)
				{
					if ($user_records >= $rank['rank_min'])
					{
						if (!empty($rank['rank_image']) && $rank_src = $this->image('src', 'rank', $rank['rank_image']))
						{
							$data = array(
								'rank_title'	=> $rank['rank_title'],
								'rank_img'		=> '<img src="' . $rank_src . '" alt="' . $rank['rank_title'] . '" title="' . $rank['rank_title'] . '"' . (($width) ? ' width="' . $width . '"' : '') . '>',
								'rank_img_src'	=> $rank_src
							);
						}
						else if (!empty($rank['rank_title']))
						{
							$data['rank_title'] = $rank['rank_title'];
						}

						break;
					}
				}
			}
		}

		return $data;
	}

	public function user_name($mode, $user_id, $username, $user_colour, $type = false, $title = '', $custom_url = false, $ex_id = false, $chars_limit = false, $pos = '')
	{
		if (!in_array($type, array('arcade', 'challenge', 'tournament', 'pm', 'pm_quotereport', 'profile')))
		{
			$type = false;
		}

		$ex_title = '';

		if ($chars_limit && $this->arcade_config['username_maxchars'] && (utf8_strlen($username) > $this->arcade_config['username_maxchars']))
		{
			$ex_title = (strpos($title, $username) === false) ? $username . ' :: ' : '';
			$username = substr($username, 0, $this->arcade_config['username_maxchars']) . '&hellip;';
		}

		if ($type && $user_id && $user_id != ANONYMOUS)
		{
			$active_link = false;
			$this->active_check("{$type}_user", $active_link, $title, false, $ex_id);

			if ($active_link)
			{
				switch ($type)
				{
					case 'arcade':
						$custom_url = $this->arcade->url('mode=stats');
					break;

					case 'challenge':
					case 'tournament':
						$ex_id = ($type == 'tournament' && $ex_id) ? "&amp;tour_id=$ex_id" : '';
						$custom_url = $this->arcade->url("mode=stats&amp;type=$type$ex_id");
					break;

					case 'pm':
						$custom_url = $this->arcade->url('i=pm&amp;mode=compose', 'ucp', $this->user->session_id);
					break;

					case 'pm_quotereport':
						$pos = 'postform';
						$custom_url = $this->arcade->url("i=pm&amp;mode=compose&amp;rid=$ex_id", 'ucp', $this->user->session_id);
					break;
				}
			}
		}
		else
		{
			$title = false;
		}

		$username = $this->username_string($mode, $user_id, $username, $user_colour, false, $custom_url, $pos);

		return (($title) ? str_replace('<a', '<a title="' . $ex_title . $title . '"', $username) : $username);
	}

	public function username_string($mode, $user_id, $username, $username_colour = '', $guest_username = false, $custom_profile_url = false, $pos = '')
	{
		static $_profile_cache;

		if (empty($_profile_cache))
		{
			$_profile_cache['base_url'] = append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=viewprofile&amp;u={USER_ID}');
			$_profile_cache['tpl_noprofile'] = '{USERNAME}';
			$_profile_cache['tpl_noprofile_colour'] = '<span style="color: {USERNAME_COLOUR};" class="username-coloured">{USERNAME}</span>';
			$_profile_cache['tpl_profile'] = '<a href="{PROFILE_URL}">{USERNAME}</a>';
			$_profile_cache['tpl_profile_colour'] = '<a href="{PROFILE_URL}" style="color: {USERNAME_COLOUR};" class="username-coloured">{USERNAME}</a>';
		}

		switch ($mode)
		{
			case 'full':
			case 'no_profile':
			case 'colour':
				$username_colour = ($username_colour) ? '#' . $username_colour : '';

				if ($mode == 'colour')
				{
					return $username_colour;
				}

			case 'username':
				if ($guest_username === false)
				{
					$username = ($username) ? $username : $this->user->lang['GUEST'];
				}
				else
				{
					$username = ($user_id && $user_id != ANONYMOUS) ? $username : ((!empty($guest_username)) ? $guest_username : $this->user->lang['GUEST']);
				}

				if ($mode == 'username')
				{
					return $username;
				}
			case 'profile':

				if ($custom_profile_url || $this->auth->acl_get('u_viewprofile'))
				{
					$profile_url = ($custom_profile_url !== false) ? $custom_profile_url . '&amp;u=' . (int) $user_id : str_replace(array('={USER_ID}', '=%7BUSER_ID%7D'), '=' . (int) $user_id, $_profile_cache['base_url']);
				}
				else
				{
					$profile_url = '';
				}

				if ($mode == 'profile')
				{
					return $profile_url;
				}
		}

		if ($profile_url)
		{
			$profile_url .= '#' . $pos;
		}

		if (($mode == 'full' && !$profile_url) || $mode == 'no_profile')
		{
			return str_replace(array('{USERNAME_COLOUR}', '{USERNAME}'), array($username_colour, $username), (!$username_colour) ? $_profile_cache['tpl_noprofile'] : $_profile_cache['tpl_noprofile_colour']);
		}

		return str_replace(array('{PROFILE_URL}', '{USERNAME_COLOUR}', '{USERNAME}'), array($profile_url, $username_colour, $username), (!$username_colour) ? $_profile_cache['tpl_profile'] : $_profile_cache['tpl_profile_colour']);
	}

	public function user_avatar($avatar, $avatar_type, $width, $height, $title = '', $mode = false, $user_id = false, $ex_id = false)
	{
		$user_avatar = '';

		if ($this->arcade_config['display_user_avatar'] && $this->arcade->optionget('view_avatars'))
		{
			if (!in_array($mode, array('arcade', 'challenge', 'tournament', 'profile')))
			{
				$mode = false;
			}

			$avatar_data = array(
				'avatar'		=> $avatar,
				'avatar_type'	=> $avatar_type,
				'avatar_width'	=> '{WIDTH}',
				'avatar_height'	=> '{HEIGHT}'
			);

			$user_avatar = phpbb_get_avatar($avatar_data, '{TITLE}');

			if (!$user_avatar && $this->arcade->data('no_avatar'))
			{
				$user_avatar = '<img width="{WIDTH}" height="{HEIGHT}" src="' . $this->arcade->data()['no_avatar'] . '" alt="{TITLE}" title="{TITLE}">';
			}

			if ($user_avatar)
			{
				$active_avatar = false;

				if ($mode && $this->arcade_config['enable_user_avatar_link'] && $user_id && $user_id != ANONYMOUS)
				{
					$this->active_check("{$mode}_user", $active_avatar, $title, false, $ex_id);

					if ($active_avatar)
					{
						switch ($mode)
						{
							case 'arcade':
								$user_avatar = '<a href="' . $this->arcade->url("mode=stats&amp;u={$user_id}") . '">' . $user_avatar . '</a>';
							break;

							case 'challenge':
							case 'tournament':
								$ex_id = ($mode == 'tournament' && $ex_id) ? "&amp;tour_id=$ex_id" : '';
								$user_avatar = '<a href="' . $this->arcade->url("mode=stats&amp;type=$mode$ex_id&amp;u={$user_id}") . '">' . $user_avatar . '</a>';
							break;

							case 'profile':
								$user_avatar = '<a href="' . $this->arcade->url("mode=viewprofile&amp;u={$user_id}", 'memberlist', $this->user->session_id) . '">' . $user_avatar . '</a>';
							break;
						}
					}
				}
				else
				{
					$this->active_check('def', $active_avatar, $title);
				}

				if (!$width || !$height)
				{
					$width = $height = 100;
				}

				if (strpos($user_avatar, 'title="{TITLE}"') === false)
				{
					$user_avatar = str_replace('alt="{TITLE}"', 'alt="{TITLE}" title="{TITLE}"', $user_avatar);
				}

				$user_avatar = str_replace(array('{WIDTH}', '{HEIGHT}', '{TITLE}'), array($width, $height, $title), $user_avatar);
				$user_avatar = (strpos($user_avatar, 'class="') !== false) ? str_replace('class="', 'class="arcade_img_border ', $user_avatar) : str_replace('<img', '<img class="arcade_img_border"', $user_avatar);
			}
		}

		return $user_avatar;
	}

	public function game_image($image, $width = 50, $height = 50, $title = '', $mode = false, $cat_id = false, $game_id = false, $user_id = false, $new_page = false, $ex_id = false)
	{
		$game_image = '';
		if ($image && (($this->arcade_config['display_game_image'] && $this->arcade->optionget('view_game_image')) || !empty($GLOBALS['arcade_skip_disable_img'])))
		{
			$img_src = ($this->arcade_config['protect_game_img']) ? $this->arcade->url("img={$image}") : $this->arcade->set_game_image_path($image);
			$game_image = '<img class="arcade_img_border" src="' . $img_src . '" alt="" title="" width="' . $width . '" height="' . $height . '">';

			if (!in_array($mode, array('play', 'popup', 'stats', 'download', 'challenge', 'tournament')))
			{
				$mode = false;
			}

			if ($mode && $this->arcade_config['enable_image_link'] && $cat_id && $game_id)
			{
				$active_image = false;
				$this->active_check($mode, $active_image, $title, $cat_id, $ex_id);

				if ($active_image)
				{
					if (in_array($mode, array('challenge', 'tournament')))
					{
						$ex_id = ($mode == 'tournament' && $ex_id) ? "&amp;tour_id=$ex_id" : '';
						$mode = "stats&amp;type=$mode$ex_id";
					}

					$game_image = '<a' . (($new_page) ? ' onclick="window.open(this.href); return false;"' : '') . ' href="' . $this->arcade->url("mode=$mode&amp;g=$game_id" . (($user_id) ? "&amp;u=$user_id" : '')) . '">' . (($title) ? str_replace('alt="" title=""', 'alt="' . $title . '" title="' . $title . '"', $game_image) : $game_image) . '</a>';
				}
			}

			if ($this->arcade_config['watermark_game_img'] && $game_id && $width >= $this->arcade_config['watermark_min_size'] && $height >= $this->arcade_config['watermark_min_size'])
			{
				$game_image = '<div class="arcade_vimg">' . $game_image . $this->arcade->data[(($this->game_field($game_id, 'game_type') == GAME_TYPE_HTML5) ? 'html5' : 'flash') . '_icon'] . '</div>';
			}
		}

		return $game_image;
	}

	public function game_popup($mode, $cat_id, $game_id, $width, $height, $title = '', $size = 15)
	{
		$game_popup = '';

		if (!in_array($mode, array('icon', 'link')))
		{
			$mode = false;
		}

		if ($mode && $cat_id && $game_id && $width && $height && (($mode == 'icon' && $this->arcade_config['display_game_popup_icon'] && $this->arcade->data('popup_icon') && $this->arcade->optionget('view_popup_icon')) || ($mode != 'icon')))
		{
			$active_popup = false;
			$this->active_check($mode, $active_popup, $title, $cat_id);

			if ($active_popup)
			{
				switch ($mode)
				{
					case 'icon':
						$size = ($size === 15) ? (int) $this->arcade_config['game_popup_icon_size'] : $size;
						$game_popup = '<a href="' . $this->arcade->url("mode=popup&amp;g={$game_id}") . '" data-jvarcade="game_popup" data-width="' . $width . '" data-height="' . $height . '"><img class="arcade_popup_icon" width="' . $size . '" height="' . $size . '" src="' . $this->arcade->data()['popup_icon'] . '" alt="' . $title . '" title="' . $title . '"></a>';
					break;

					case 'link':
						$game_popup = '<a href="' . $this->arcade->url("mode=popup&amp;g={$game_id}") . '" data-jvarcade="game_popup" data-width="' . $width . '" data-height="' . $height . '">' . $this->user->lang['ARCADE_PLAYING_NEW_WINDOW'] . '</a>';
						$game_popup = ($title) ? str_replace('<a', '<a title="' . $title . '"', $game_popup) : $game_popup;
					break;
				}
			}
		}

		return $game_popup;
	}

	public function game_name($gname, $chars_limit = true, $mode = false, $cat_id = false, $game_id = false, $title = '', $tooltip = false, $header = false, $user_id = false, $new_page = false, $ex_id = false)
	{
		$game_name = $ex_title = '';

		if ($gname)
		{
			global $arcade_game_count;

			$arcade_game_count = intval((!empty($arcade_game_count)) ? $arcade_game_count : 0);

			if ($chars_limit && $this->arcade_config['gamename_maxchars'] && (utf8_strlen($gname) > $this->arcade_config['gamename_maxchars']))
			{
				$ex_title = (strpos($title, $gname) === false) ? $gname . ' :: ' : '';
				$gname = substr($gname, 0, $this->arcade_config['gamename_maxchars']) . '&hellip;';
			}

			if (!in_array($mode, array('play', 'popup', 'stats', 'download', 'challenge', 'tournament')))
			{
				$mode = false;
			}

			if ($mode && $cat_id && $game_id)
			{
				$active_game_name = false;
				$this->active_check($mode, $active_game_name, $title, $cat_id, $ex_id);

				if ($active_game_name && in_array($mode, array('challenge', 'tournament')))
				{
					$ex_id = ($mode == 'tournament' && $ex_id) ? "&amp;tour_id=$ex_id" : '';
					$mode = "stats&amp;type=$mode$ex_id";
				}

				if ($tooltip)
				{
					// Use onclick function to work the text selection.
					$game_name = '<a' . (($active_game_name) ? ' onclick="window.open(this.href, \'' . ((!$new_page) ? '_self' : '') . '\'); return false;" href="' . $this->arcade->url("mode=$mode&amp;g=$game_id" . (($user_id) ? "&amp;u=$user_id" : '')) . '"' : '') . '>' . $gname . '</a>';
				}
				else if ($active_game_name)
				{
					$game_name = '<a' . (($new_page) ? ' onclick="window.open(this.href); return false;"' : '') . ' href="' . $this->arcade->url("mode=$mode&amp;g=$game_id" . (($user_id) ? "&amp;u=$user_id" : '')) . '">' . $gname . '</a>';
				}

				if ($active_game_name && !$tooltip && $title)
				{
					$game_name = str_replace('<a', '<a title="' . $ex_title . $title . '"', $game_name);
				}

				if ($tooltip)
				{
					$a_style = ($header) ? ' style="font-weight: normal;"' : '';
					$a_style = ($active_game_name) ? $a_style : ' style="cursor: default; text-decoration: none;' . (($header) ? ' font-weight: normal;' : '') . '"';
					$game_name = str_replace(">$gname</a>", ' class="genmed arcade_tooltip"' . $a_style . '>' . $gname . '<span' . (($arcade_game_count > 3) ? ' style="top: auto; bottom: -15px; max-height: 10em;"' : '') . (($header) ? ' class="arcade_header"' : '') . '>' . $tooltip . '</span></a>', $game_name);
				}
			}

			$game_name = ($game_name) ? $game_name : $gname;
		}

		return $game_name;
	}

	public function cat_name($cat_name, $cat_id, $game_id = false, $title = '', $par = true, $class = '')
	{
		if (!$cat_name || !$cat_id)
		{
			return '';
		}

		$active_link = false;
		$this->active_check('cat', $active_link, $title, $cat_id);

		if ($active_link)
		{
			$title		= ($title) ? ' title="' . $title . '"' : '';
			$cat_name	= ($par) ? "[ $cat_name ]" : $cat_name;
			$cat_name	= '<a' . (($class) ? ' class="' . $class . '"' : '') . ' href="' . $this->arcade->url("mode=cat&amp;c={$cat_id}" . (($game_id) ? "&amp;g={$game_id}" : '')) . (($game_id) ? "#g{$game_id}" : '') . '"' . $title . '>' . $cat_name . '</a>';
		}
		else
		{
			$cat_name	= ($par) ? "($cat_name)" : $cat_name;
			$cat_name	= '<span' . (($class) ? ' class="' . $class . '"' : '') . '>' . $cat_name . '</span>';
		}

		return $cat_name;
	}

	public function tour_name($tour_id, $tour_name, $title = '', $final = false, $tooltip = false)
	{
		if (!$tour_id || !$tour_name)
		{
			return '';
		}

		$final = ($final) ? '&amp;type=final' : '';
		$h_url = $this->arcade->url("mode=tournament{$final}&amp;tour_id={$tour_id}") . '#tour_top';

		if ($tooltip)
		{
			$h_url = '<a href="' . $h_url . '" class="genmed arcade_tooltip" style="font-weight: normal;">' . $tour_name . '<span class="arcade_header">' . $tooltip . '</span></a>';
		}
		else
		{
			$title = ($title == 'x') ? 'ARCADE_VIEW_TOUR' : $title;
			$title = ($title) ? ' title="' . $this->arcade->lang_value($title) . '"' : '';

			$h_url = '<a href="' . $h_url . '"' . $title . '>' . $tour_name . '</a>';
		}

		return $h_url;
	}

	public function cat_locked($cat_id)
	{
		return ($this->cat_field($cat_id, 'cat_status', false) == ITEM_LOCKED && !$this->auth->acl_get('a_arcade_game')) ? true : false;
	}

	public function cat_data($cat_id)
	{
		$sql_array = array(
			'SELECT'	=> 'c.cat_id, c.cat_name, c.cat_desc, c.cat_desc_uid, c.cat_desc_bitfield, c.cat_desc_options, c.parent_id, c.cat_parents, c.left_id, c.right_id',
			'FROM'		=> array(
				ARCADE_CATS_TABLE	=> 'c',
			),
			'WHERE'		=> $this->db->sql_in_set('cat_id', $cat_id),
		);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		if (is_array($cat_id))
		{
			$row = $this->db->sql_fetchrowset($result);
		}
		else
		{
			$row = $this->db->sql_fetchrow($result);
		}
		$this->db->sql_freeresult($result);

		return ($row) ? $row : false;
	}

	public function user_categories($user_id = false, $highscores = false)
	{
		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
		}

		$sql_array = array(
			'SELECT'		 => 'c.cat_id, c.cat_name, c.left_id',
			'FROM'			 => array(ARCADE_GAMES_TABLE	=> 'g'),
			'LEFT_JOIN'		 => array(
				array('FROM' => array(ARCADE_PLAYS_TABLE => 'p'),	'ON' => 'g.game_id = p.game_id'),
				array('FROM' => array(ARCADE_CATS_TABLE => 'c'),	'ON' => 'g.cat_id = c.cat_id'),
			),
			'WHERE'			 => 'p.user_id = ' . (int) $user_id . '
				AND ' . $this->db->sql_in_set('c.cat_id', $this->permissions(array('c_view', 'c_play')), false, true),
			'ORDER_BY'		 => 'c.left_id ASC',
		);

		if ($highscores)
		{
			$sql_array['WHERE'] .= ' AND g.game_highuser = ' . (int) $user_id;
		}

		$cats = array($this->user->lang['ARCADE_ALL_CATEGORIES']);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$cats[$row['cat_id']] = $row['cat_name'];
		}
		$this->db->sql_freeresult($result);

		if (count($cats) == 1)
		{
			$cats = array();
		}

		return $cats;
	}

	public function group_data($group_ids)
	{
		$group_ids = array_map('intval', (is_array($group_ids)) ? array_unique($group_ids) : array($group_ids));

		$groups = array();
		$sql = 'SELECT group_id, group_name, group_type, group_colour
				FROM ' . GROUPS_TABLE . '
				WHERE ' . $this->db->sql_in_set('group_id', $group_ids) . '
				ORDER BY group_type DESC, group_name ASC';
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$groups[(int) $row['group_id']] = array(
				'group_name'	=> $row['group_name'],
				'group_type'	=> $row['group_type'],
				'group_colour'	=> $row['group_colour']
			);
		}
		$this->db->sql_freeresult($result);

		return $groups;
	}

	public function game_data($game_id, $order = false, $limit = false, $start = 0)
	{
		$game_id = (is_array($game_id)) ? array_unique(array_map('intval', $game_id)) : (int) $game_id;

		$sql_array = array(
			'SELECT'		=> 'g.*',
			'FROM'			=> array(
				ARCADE_GAMES_TABLE	=> 'g',
			),
			'WHERE'			=> $this->db->sql_in_set('g.game_id', $game_id),
			'ORDER_BY'		=> 'g.game_name_clean ASC'
		);

		if ($order)
		{
			$sql_array['ORDER_BY'] = $order;
		}

		$sql = $this->db->sql_build_query('SELECT', $sql_array);

		if ($limit)
		{
			$result = $this->db->sql_query_limit($sql, $limit, $start);
		}
		else
		{
			$result = $this->db->sql_query($sql);
		}

		if (is_array($game_id))
		{
			$row = $this->db->sql_fetchrowset($result);
		}
		else
		{
			$row = $this->db->sql_fetchrow($result);
		}

		$this->db->sql_freeresult($result);

		return ($row) ? $row : false;
	}

	public function game_cat_data($game_id, $rating = false, $order = false, $limit = false, $start = 0, $only_view = false)
	{
		$game_id = (is_array($game_id)) ? array_unique(array_map('intval', $game_id)) : (int) $game_id;

		$sql_array = array(
			'SELECT'		=> 'g.*,
								c.cat_name, c.cat_desc, c.cat_type, c.cat_status, c.cat_desc_uid, c.cat_desc_bitfield, c.cat_desc_options, c.parent_id, c.cat_parents, c.left_id, c.right_id, c.cat_download, c.cat_download_cost, c.cat_cost, c.cat_reward, c.cat_use_jackpot, c.cat_age',
			'FROM'			=> array(
				ARCADE_GAMES_TABLE	=> 'g',
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(ARCADE_CATS_TABLE => 'c'),
					'ON'	=> 'g.cat_id = c.cat_id'
				),
			),
			'WHERE'			=> $this->db->sql_in_set('g.game_id', $game_id),
			'ORDER_BY'		=> 'c.cat_name ASC, g.game_name_clean ASC'
		);

		if ($only_view)
		{
			$sql_array['WHERE'] .= ' AND ' . $this->db->sql_in_set('c.cat_id', $this->permissions('c_view'), false, true);
		}

		if ($rating)
		{
			$sql_array['SELECT'] .= ', r.game_rating';
			$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_RATING_TABLE => 'r'), 'ON' => 'g.game_id = r.game_id AND r.user_id = ' . (int) $this->user->data['user_id']);
		}

		if ($order)
		{
			$sql_array['ORDER_BY'] = $order;
		}

		$sql = $this->db->sql_build_query('SELECT', $sql_array);

		if ($limit)
		{
			$result = $this->db->sql_query_limit($sql, $limit, $start);
		}
		else
		{
			$result = $this->db->sql_query($sql);
		}

		if (is_array($game_id))
		{
			$row = $this->db->sql_fetchrowset($result);
		}
		else
		{
			$row = $this->db->sql_fetchrow($result);
		}

		$this->db->sql_freeresult($result);

		return ($row) ? $row : false;
	}

	private function active_check($mode, &$active, &$title, $cat_id = false, $ex_id = false)
	{
		if (!empty($GLOBALS['arcade_skip_active_link']))
		{
			$title = '';
			$active = false;
			return;
		}

		switch ($mode)
		{
			case 'play':
			case 'popup':
			case 'icon':
			case 'link':
			case 'cat':
				$active = false;

				if ($cat_id)
				{
					$founder_exemption = ($this->arcade_config['founder_exempt'] && $this->user->data['user_type'] == USER_FOUNDER) ? true : false;

					if ($founder_exemption)
					{
						$url_disabled = false;
					}
					else
					{
						$user_age		= $this->user_age();
						$cat_age		= $this->cat_field($cat_id, 'cat_age');
						$url_disabled	= ($cat_age && ($user_age === '' || ($user_age < $cat_age))) ? true : false;
					}

					if ($mode == 'cat')
					{
						$active = (!$url_disabled && !$this->cat_locked($cat_id) && $this->arcade_auth->acl_get('c_view', $cat_id)) ? true : false;
					}
					else
					{
						$nw		= ($mode == 'play' || (!$this->user->data['is_bot'] && $this->auth->acl_get('u_arcade_popup'))) ? true : false;
						$active	= ($nw && !$url_disabled && !$this->cat_locked($cat_id) && $this->arcade_auth->acl_get('c_play', $cat_id)) ? true : false;
					}
				}

				if ($mode == 'cat')
				{
					$title = ($active) ? (($title == 'x') ? 'ARCADE_VIEW_CATEGORY' : $title) : '';
				}
				else
				{
					$title_key = ($mode == 'play' || $mode == 'popup') ? 'CLICK_PLAY' : 'PLAYING_NEW_WINDOW';
					$title	= ($active) ? (($title == 'x') ? 'ARCADE_' . $title_key : $title) : '';
				}
			break;

			case 'tournament':
				$mode = ($ex_id) ? 'tour' : 'tours';
			case 'stats':
			case 'challenge':
				$active	= ($this->auth->acl_get('u_arcade_viewstats')) ? true : false;
				$title	= ($active) ? (($title == 'x') ? 'ARCADE_VIEW_' . (($mode == 'stats') ? '' : strtoupper($mode) . '_') . 'STATS' : $title) : '';
				$title	= ($mode == 'tour') ? sprintf($this->user->lang['ARCADE_VIEW_TOUR_STATS'], $this->tour_field($ex_id, 'tour_name')) : $title;
			break;

			case 'download':
				$active	= $this->arcade->game()->download_auth('user_cat', $cat_id, $this->cat_field($cat_id, 'cat_download'), true);
				$title	= ($active) ? (($title == 'x') ? 'ARCADE_DOWNLOAD_GAME' : $title) : '';
			break;

			case 'tournament_user':
				$mode = (($ex_id) ? 'tour' : 'tours') . '_user';
			case 'arcade_user':
			case 'challenge_user':
				$mode = str_replace('_user', '', $mode);
				$active	= ($this->auth->acl_get('u_arcade_viewstats')) ? true : false;
				$title	= ($active) ? (($title == 'x') ? 'ARCADE_VIEW_' . (($mode == 'arcade') ? '' : strtoupper($mode) . '_') . 'STATS' : $title) : '';
				$title	= ($mode == 'tour') ? sprintf($this->user->lang['ARCADE_VIEW_TOUR_STATS'], $this->tour_field($ex_id, 'tour_name')) : $title;
			break;

			case 'profile_user':
				$active	= ($this->auth->acl_get('u_viewprofile')) ? true : false;
				$title	= ($active) ? (($title == 'x') ? 'ARCADE_VIEW_MEMBER_PROFILE' : $title) : '';
			break;

			case 'pm_user':
			case 'pm_quotereport_user':
				$active	= ($this->auth->acl_get('u_sendpm')) ? true : false;
				$title	= ($active) ? (($title == 'x') ? 'SEND_PRIVATE_MESSAGE' : $title) : '';
			break;

			default:
				$title	= '';
				$active	= false;
			break;
		}

		$title = $this->arcade->lang_value($title);
	}

	public function leaders_image($pos, $con = false, $mode = 'full')
	{
		$pos = (int) $pos;

		if (($pos < 1) || (!$con && $pos > 3))
		{
			return '';
		}

		$leader_img = array(
			1 => '1st',
			2 => '2nd',
			3 => '3rd'
		);

		$alt = array(
			1 => 'ARCADE_FIRST',
			2 => 'ARCADE_SECOND',
			3 => 'ARCADE_THIRD'
		);

		if ($con && $pos > 3)
		{
			$leader_img[$pos]	= 'trophy';
			$alt[$pos]			= sprintf($this->user->lang['ARCADE_PLACE'], $pos);
		}

		return $this->image($mode, 'img', $leader_img[$pos] . '.gif', $alt[$pos], false, 'vertical-align: middle;');
	}

	/**
	* This function checks to see if there are style specific
	* category images first
	*/
	public function image($mode, $type, $image, $alt = '', $default = false, $style = '', $class = '')
	{
		$type = strtolower($type);
		$user_style_path = $all_path = '';

		if (!$image || !in_array($type, array('rank', 'cat', 'img')))
		{
			return false;
		}

		$all_path = $this->arcade->set_image_path($type);
		$user_style_path = $this->arcade->set_image_path($type, true);

		if ($default === false && file_exists($user_style_path . $image))
		{
			$path = $user_style_path . $image;
		}
		else if (file_exists($all_path . $image))
		{
			$path = $all_path . $image;
		}
		else
		{
			if ($image !== 'no_image.png')
			{
				return $this->image($mode, $type, 'no_image.png', $alt, $default, $style, $class);
			}
			else if (!$default)
			{
				return $this->image($mode, $type, 'no_image.png', $alt, true, $style, $class);
			}

			return false;
		}

		$path = str_replace($this->root_path, $this->arcade->web_path(), $path);

		switch (strtolower($mode))
		{
			case 'full':
				return $this->arcade->set_image($path, $alt, $style, $class);
			break;

			case 'src':
				return $path;
			break;

			default:
				return false;
			break;
		}
	}

	/**
	* Return an array containing all the game ids and names
	* of the games the user has played, if no user id is
	* passed it defaults to viewing user
	* $all = true, all users played
	*/
	public function played_games($user_id = false, $all = false)
	{
		if ($all)
		{
			$sql_array = array(
				'SELECT'	=> 'g.game_id, g.game_name_clean',
				'FROM'		=> array(ARCADE_GAMES_TABLE => 'g'),
				'WHERE'		=> 'g.game_plays > 0',
				'ORDER_BY'	=> 'g.game_name_clean ASC'
			);
		}
		else
		{
			if (!$this->user->data['is_registered'] || !$this->arcade_config['played_colour'])
			{
				return array();
			}

			if (!$user_id)
			{
				$user_id = $this->user->data['user_id'];
			}

			$sql_array = array(
				'SELECT'	=> 'g.game_id',
				'FROM'		=> array(ARCADE_GAMES_TABLE	=> 'g'),
				'LEFT_JOIN'	=> array(
					array('FROM' => array(ARCADE_PLAYS_TABLE => 'p'), 'ON' => 'g.game_id = p.game_id')
				),
				'WHERE'		=> 'p.user_id = ' . (int) $user_id,
			);
		}

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$played = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			if ($all)
			{
				$played[$row['game_id']] = array(
					'cat_id'	=> $this->game_field($row['game_id'], 'cat_id'),
					'game_name'	=> $this->game_field($row['game_id'], 'game_name')
				);
			}
			else
			{
				$played[$row['game_id']] = 1;
			}
		}
		$this->db->sql_freeresult($result);

		return $played;
	}

	/**
	* Display a users favorite games, if no user id
	* is passed it default to viewing user
	*/
	public function fav_data($user_id = false, $game_id = false)
	{
		if (!$user_id)
		{
			$user_id = (int) $this->user->data['user_id'];
		}

		if ($user_id == ANONYMOUS || !$this->auth->acl_get('u_arcade_favorites'))
		{
			return false;
		}

		$sql_array = array(
			'SELECT'		=> 'f.highlighted, g.game_id, g.game_name, g.game_name_clean',
			'FROM'			=> array(
				ARCADE_FAVS_TABLE => 'f',
			),
			'LEFT_JOIN'		=> array(
				array(
					'FROM'	=> array(ARCADE_GAMES_TABLE => 'g'),
					'ON'	=> 'f.game_id = g.game_id'
				),
			),
			'WHERE'			=> 'f.user_id = ' . (int) $user_id . '
				AND ' . $this->db->sql_in_set('g.cat_id', $this->permissions(array('c_view', 'c_play')), false, true),
			'ORDER_BY'		=> 'g.game_name_clean ASC',
		);

		if ($game_id)
		{
			$sql_array['WHERE'] .= ' AND f.game_id = ' . (int) $game_id;
		}

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$fav = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$fav[$row['game_id']] = array(
				'game_name'		=> $row['game_name'],
				'highlighted'	=> $row['highlighted']
			);
		}
		$this->db->sql_freeresult($result);

		return $fav;
	}

	public function arcade_parents(&$cat_data)
	{
		$cat_parents = array();

		if ($cat_data['parent_id'] > 0)
		{
			if ($cat_data['cat_parents'] == '')
			{
				$sql = 'SELECT cat_id, cat_name, cat_type
						FROM ' . ARCADE_CATS_TABLE . '
						WHERE left_id < ' . (int) $cat_data['left_id'] . '
						AND right_id > ' . (int) $cat_data['right_id'] . '
						ORDER BY left_id ASC';
				$result = $this->db->sql_query($sql);

				while ($row = $this->db->sql_fetchrow($result))
				{
					$cat_parents[$row['cat_id']] = array($row['cat_name'], (int) $row['cat_type']);
				}
				$this->db->sql_freeresult($result);

				$cat_data['cat_parents'] = serialize($cat_parents);

				$sql = 'UPDATE ' . ARCADE_CATS_TABLE . "
						SET cat_parents = '" . $this->db->sql_escape($cat_data['cat_parents']) . "'
						WHERE parent_id = " . (int) $cat_data['parent_id'];
				$this->db->sql_query($sql);
			}
			else
			{
				$cat_parents = unserialize($cat_data['cat_parents']);
			}
		}

		return $cat_parents;
	}

	/**
	* Get a random game_id from the arcade
	* This is done like this to support all db types
	* since some do not have a RAND() function
	*/
	public function random_game($limit = 0, $cat_ids = false, $ignore_game_ids = false, $ignore_auth = false, $not_played = false)
	{
		$sql_array = array(
			'SELECT'		=> 'g.game_id',
			'FROM'			=> array(
				ARCADE_GAMES_TABLE	=> 'g',
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(ARCADE_CATS_TABLE => 'c'),
					'ON'	=> 'g.cat_id = c.cat_id'
				),
			)
		);

		if (!$this->auth->acl_get('a_arcade_game'))
		{
			$sql_array['WHERE'] = 'c.cat_status <> ' . ITEM_LOCKED;
		}

		if (!$ignore_auth)
		{
			$sql_array['WHERE'] = ((!empty($sql_array['WHERE'])) ? $sql_array['WHERE'] . ' AND ' : '') . $this->db->sql_in_set('c.cat_id', $this->game_search_protection(), true, true) . '
				AND ' . $this->db->sql_in_set('c.cat_id', $this->permissions('c_play'), false, true) . '
				AND ' . $this->db->sql_in_set('g.game_id', array_map('intval', $this->arcade->points()->get_games_big_cost()), true, true);
		}

		if ($not_played)
		{
			$sql_array['WHERE'] = ((!empty($sql_array['WHERE'])) ? $sql_array['WHERE'] . ' AND ' : '') . 'g.game_plays = 0';
		}

		if ($cat_ids)
		{
			if (!is_array($cat_ids))
			{
				$cat_ids = array((int) $cat_ids);
			}

			$sql_array['WHERE'] = ((!empty($sql_array['WHERE'])) ? $sql_array['WHERE'] . ' AND ' : '') . $this->db->sql_in_set('c.cat_id', array_map('intval', $cat_ids));
		}

		if ($ignore_game_ids)
		{
			if (!is_array($ignore_game_ids))
			{
				$ignore_game_ids = array((int) $ignore_game_ids);
			}

			$sql_array['WHERE'] = ((!empty($sql_array['WHERE'])) ? $sql_array['WHERE'] . ' AND ' : '') . $this->db->sql_in_set('g.game_id', array_map('intval', $ignore_game_ids), true);
		}

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql, 600);
		$row = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		// Return false if no games are found
		$game_id = false;
		if (count($row))
		{
			if ($limit)
			{
				$game_id = array();
				for ($i=0; $i < count($row); $i++)
				{
					if ($limit >= count($row))
					{
						$game_id[] = $row[$i]['game_id'];
					}
					else
					{
						$game_id[] = $row[mt_rand(0, count($row) - 1)]['game_id'];
						$game_id = array_unique($game_id);

						if (count($game_id) == $limit)
						{
							break;
						}

						$v = ($i + 1);
						if ($v == count($row))
						{
							$i--;
						}
					}
				}
			}
			else
			{
				$game_id = $row[mt_rand(0, count($row) - 1)]['game_id'];
			}
		}

		return $game_id;
	}

	public function gamename_tooltip($game_data, $header = true, $title = true, $control = true, $hilit = false, $chars_limit = true)
	{
		$game_control	= '';
		$game_desc		= ($game_data['game_desc']) ? str_replace("\n", '', censor_text(nl2br($game_data['game_desc']))) : '';

		if ($control)
		{
			$game_control .= ($game_data['game_control']) ? $this->arcade->game()->control($game_data['game_control']) : '';
			$game_control .= ($game_data['game_control_desc']) ? '<br>' . str_replace("\n", '', censor_text(nl2br($game_data['game_control_desc']))) : '';
		}

		if ($title)
		{
			$game_desc = '<b>' . $this->user->lang['ARCADE_GAME_DESC'] . ':</b><br>' . $game_desc;

			if ($control && $game_control)
			{
				$game_control = '<br><br><b>' . $this->user->lang['ARCADE_GAME_CONTROL'] . ':</b><br>' . $game_control;
			}
		}

		$game_name = $this->game_name($game_data['game_name'], $chars_limit, 'play', $game_data['cat_id'], $game_data['game_id'], '', $game_desc . (($hilit) ? '' : $game_control), $header);

		if ($hilit)
		{
			$game_name = preg_replace('#(?!<.*)(?<!\w)(' . $hilit . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<i class="posthilit">$1</i>', $game_name);

			if ($game_control)
			{
				$game_name = str_replace('</span></a>', $game_control . '</span></a>', $game_name);
			}
		}

		return $game_name;
	}

	public function new_challenge()
	{
		$sql = 'SELECT game_id
				FROM ' . ARCADE_CHALLENGE_TABLE . '
				WHERE challenge_accept = ' . CHALLENGE_UNACCEPTED . '
				AND opponent_id = ' . (int) $this->user->data['user_id'] . '
				AND ' . $this->db->sql_in_set('challenger_id', array_map('intval', array_keys($this->arcade->ban_users())), true, true);
		$result = $this->db->sql_query_limit($sql, 1);
		$new_challenge = (int) $this->db->sql_fetchfield('game_id');
		$this->db->sql_freeresult($result);

		return ($new_challenge) ? true : false;
	}

	public function detailed_stats(&$detailed_stats, &$data, $online = false)
	{
		$return	= true;
		$key	= 'ARCADE_' . strtoupper($detailed_stats);

		switch ($detailed_stats)
		{
			case 'highscores':
			case 'not_played_games':
			case 'played_games':
			case 'played_users':
			case 'games_jackpots':
			case 'super_champions':
			case 'favs':
			case 'rated_games':
			case 'challenge_played_games':
			case 'challenge_played_users':
			case 'challenge_winners':
			case 'tours_played_games':
			case 'tours_played_users':
			case 'tours_winners':
				$data = ($online) ? "VIEWING_{$key}" : str_replace(array('CHALLENGE_', 'TOURS_'), '', $key);
			break;

			default:
				$return = $detailed_stats = false;
			break;
		}

		return $return;
	}

	function auth_categories()
	{
		$sql_array = array(
			'SELECT'	=> 'c.cat_id, c.cat_name, c.left_id',
			'FROM'		=> array(ARCADE_CATS_TABLE	=> 'c'),
			'WHERE'		=> $this->db->sql_in_set('c.cat_id', $this->permissions(array('c_view', 'c_play')), false, true),
			'ORDER_BY'	=> 'c.left_id ASC'
		);

		$cats = array($this->user->lang['ARCADE_ALL_CATEGORIES']);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$cats[$row['cat_id']] = $row['cat_name'];
		}
		$this->db->sql_freeresult($result);

		if (count($cats) == 1)
		{
			$cats = array();
		}

		return $cats;
	}
}
