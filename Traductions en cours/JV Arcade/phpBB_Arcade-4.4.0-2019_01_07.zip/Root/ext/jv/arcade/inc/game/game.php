<?php
/**
*
* @package phpBB Arcade
* @version $Id: game.php 2139 2019-01-07 11:57:04Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class game
{
	public $install_file, $session;

	protected $db, $cache, $user, $auth, $request, $arcade_config, $arcade_auth, $arcade;

	public function __construct($db, $cache, $user, $auth, $request, $arcade_config, $arcade_auth, $arcade)
	{
		$this->db = $db;
		$this->cache = $cache;
		$this->user = $user;
		$this->auth = $auth;
		$this->request = $request;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
	}

	public function main()
	{
		$this->install_file = $this->arcade->container('game_install_file');
		$this->session = $this->arcade->container('game_session', true);
	}

	public function type($game_type, $display = false)
	{
		switch ($game_type)
		{
			case GAME_TYPE_FLASH:
				$key = 'GAME_TYPE_FLASH';
			break;

			case GAME_TYPE_HTML5:
				$key = 'GAME_TYPE_HTML5';
			break;

			default:
				$key = ($display) ? 'ARCADE_UNKNOWN' : 'UNKNOWN_GAME';
			break;
		}

		if ($display)
		{
			$key = $this->arcade->lang_value($key);
		}

		return $key;
	}

	public function save_type($save_type, $display = false)
	{
		switch ($save_type)
		{
			case AMOD_GAME:
				$key = 'AMOD_GAME';
			break;

			case AR_GAME:
				$key = 'AR_GAME';
			break;

			case IBPRO_GAME:
				$key = 'IBPRO_GAME';
			break;

			case V3ARCADE_GAME:
				$key = 'V3ARCADE_GAME';
			break;

			case IBPROV3_GAME:
				$key = 'IBPROV3_GAME';
			break;

			case ARCADELIB_GAME:
				$key = 'ARCADELIB_GAME';
			break;

			case PHPBBARCADE_GAME:
				$key = 'PHPBBARCADE_GAME';
			break;

			case PHPBB_RA_GAME:
				$key = 'PHPBB_RA_GAME';
			break;

			case OLYMPUS_GAME:
				$key = 'OLYMPUS_GAME';
			break;

			case NOSCORE_GAME:
				$key = 'NOSCORE_GAME';
			break;

			default:
				$key = ($display) ? 'ARCADE_UNKNOWN' : 'UNKNOWN_GAME';
			break;
		}

		if ($display)
		{
			$key = $this->arcade->lang_value($key);
		}

		return $key;
	}

	public function control($type, $mode = 'full')
	{
		$game_control = '';
		switch ($type)
		{
			case GAME_CONTROL_KEYBOARD_MOUSE:
				$game_control = $this->arcade->get()->image($mode, 'img', 'keyboard_mouse.png', 'ARCADE_KEYBOARD_MOUSE');
			break;

			case GAME_CONTROL_KEYBOARD:
				$game_control = $this->arcade->get()->image($mode, 'img', 'keyboard.png', 'ARCADE_KEYBOARD');
			break;

			case GAME_CONTROL_MOUSE:
				$game_control = $this->arcade->get()->image($mode, 'img', 'mouse.png', 'ARCADE_MOUSE');
			break;
		}

		return $game_control;
	}

	public function get_protection($type)
	{
		$use_protection = false;

		switch($type)
		{
			case AMOD_GAME:
				$use_protection = ($this->arcade_config['protect_amod']) ? true : false;
			break;

			case V3ARCADE_GAME:
				$use_protection = ($this->arcade_config['protect_v3arcade']) ? true : false;
			break;

			case PHPBBARCADE_GAME:
				$use_protection = ($this->arcade_config['protect_phpbbarcade']) ? true : false;
			break;

			default:
			break;
		}

		return $use_protection;
	}

	public function update_save_type($save_type, $game_id)
	{
		$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
				SET game_save_type = ' . (int) $save_type . '
				WHERE game_id = ' . (int) $game_id;
		$this->db->sql_query($sql);

		$this->install_file->row_update($game_id);
	}

	public function update_plays($game_id, $cat_id, $total_time, $last_play_time = false, $game_ary = array(), $cat_ary = array(), $user_id = false, $new_highscore = false, $new_superscore = false)
	{
		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
		}

		// Increase play time for games that do not submit scores (60 sec./plays).
		if ($total_time === null)
		{
			$total_time = 60;
		}

		$sql = 'UPDATE ' . ARCADE_PLAYS_TABLE . '
				SET total_plays = total_plays + 1, total_time = total_time + ' . (int) $total_time . '
				WHERE game_id = ' . (int) $game_id . '
				AND user_id   = ' . (int) $user_id;
		$this->db->sql_query($sql);

		$new_game = false;
		if (!$this->db->sql_affectedrows())
		{
			$sql_ary = array(
				'game_id'		=> (int) $game_id,
				'user_id'		=> (int) $user_id,
				'total_time'	=> (int) $total_time,
				'total_plays'	=> 1
			);

			$new_game = true;
			$this->db->sql_return_on_error(true);
			$this->db->sql_query('INSERT INTO ' . ARCADE_PLAYS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
			$this->db->sql_return_on_error(false);
		}

		$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
				SET arcade_total_plays = arcade_total_plays + 1, arcade_total_time = arcade_total_time + ' . (int) $total_time . '
				' . (($new_game) ? ', arcade_total_played = arcade_total_played + 1' : '') . '
				' . (($new_highscore) ? ', arcade_total_wins = arcade_total_wins + 1' : '') . '
				' . (($new_superscore) ? ', arcade_total_super_scores = arcade_total_super_scores + 1' : '') . '
				' . (($last_play_time) ? ', user_arcade_last_play = ' . (int) $last_play_time : '') . '
				WHERE user_id = ' . (int) $user_id;
		$this->db->sql_query($sql);

		$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
				SET game_plays = game_plays + 1
				' . ((count($game_ary)) ? ', ' . $this->db->sql_build_array('UPDATE', $game_ary) : '') . '
				WHERE game_id = ' . (int) $game_id;
		$this->db->sql_query($sql);

		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
				SET cat_plays = cat_plays + 1
				' . ((count($cat_ary)) ? ', ' . $this->db->sql_build_array('UPDATE', $cat_ary) : '') . '
				WHERE cat_id = ' . (int) $cat_id;
		$this->db->sql_query($sql);

		$this->arcade_config->increment('total_plays', 1, true);
		$this->arcade_config->increment('total_plays_time', $total_time, true);
		$this->cache->destroy('sql', ARCADE_PLAYS_TABLE);
	}

	public function update_last_play_time()
	{
		$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
				SET user_arcade_last_play = ' . time() . '
				WHERE user_id = ' . (int) $this->user->data['user_id'];
		$this->db->sql_query($sql);
	}

	public function super_champion($game_id, $l_score = false)
	{
		$select		= ($l_score) ? 's.score' : 's.score, s.score_date, u.user_id, u.username, u.user_colour, u.user_avatar, u.user_avatar_type, u.user_avatar_width, u.user_avatar_height';
		$left_join	= ($l_score) ? '' : ' LEFT JOIN ' . USERS_TABLE . ' u ON s.user_id = u.user_id';

		$sql = "SELECT {$select}
				FROM " . ARCADE_SUPER_SCORES_TABLE . " s
				{$left_join}
				WHERE s.game_id = " . (int) $game_id . (($l_score) ? '' : ' AND s.user_id = u.user_id');
		$result = $this->db->sql_query($sql);
		$super_champion = ($l_score) ? $this->db->sql_fetchfield('score') : $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		return (!empty($super_champion)) ? $super_champion : false;
	}

	public function update_super_score($score_data, $game_id)
	{
		$sql = 'UPDATE ' . ARCADE_SUPER_SCORES_TABLE . '
				SET ' . $this->db->sql_build_array('UPDATE', $score_data) . '
				WHERE game_id = ' . (int) $game_id;
		$this->db->sql_query($sql);

		if (!$this->db->sql_affectedrows())
		{
			$score_data['game_id'] = (int) $game_id;

			$this->db->sql_return_on_error(true);
			$this->db->sql_query('INSERT INTO ' . ARCADE_SUPER_SCORES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $score_data));
			$this->db->sql_return_on_error(false);
		}
	}

	public function file_path($file, $use_phpbb_root = true)
	{
		if (file_exists($this->arcade->set_path($file, 'gamedata', $use_phpbb_root)))
		{
			return $this->arcade->set_path($file, 'gamedata', $use_phpbb_root);
		}
		else if (file_exists($this->arcade->set_path($file, 'v3arcade_gamedata', $use_phpbb_root)))
		{
			return $this->arcade->set_path($file, 'v3arcade_gamedata', $use_phpbb_root);
		}
		else
		{
			return false;
		}
	}

	public function download_auth($type, $cat_id = false, $cat_download = false, $game_download = false, $ignore_cat_locked = false)
	{
		$perm = false;

		if ($this->arcade_config['download_system'])
		{
			switch ($type)
			{
				case 'acp_dl_version':
					$perm = (!empty($cat_id['req_min']) && phpbb_version_compare($cat_id['req_min'], ARCADE_ACP_DL_SYSTEM_VERSION, '>='));
				break;

				case 'acp_module':
					$perm = $this->arcade_config['download_list'];
				break;

				case 'user':
					$perm = $this->auth->acl_get('u_arcade_download');
				break;

				case 'cat':
					$perm = $cat_download;
				break;

				case 'user_cat':
					$perm = $cat_id && $this->auth->acl_get('u_arcade_download') && $cat_download && $game_download && ($ignore_cat_locked || !$this->arcade->get()->cat_locked($cat_id)) && $this->arcade_auth->acl_get('c_download', $cat_id);
				break;

				case 'flood':
					$perm = $cat_id && $this->arcade_auth->acl_get('c_ignoreflood_download', $cat_id);
				break;
			}
		}

		return $perm || $this->arcade->test_system();
	}

	public function download_stat_auth($total = false)
	{
		return $this->arcade_config['download_system'] && $this->auth->acl_get('u_arcade_download') && $this->arcade_auth->acl_getc_global('c_download') && (!$total || $this->arcade_config['total_downloads']);
	}

	/**
	* Function used to quickly show the contents of variables
	*/
	public function debug($var = false)
	{
		$return = '';
		$this->request->enable_super_globals();

		if ($var !== false)
		{
			unset(
				$var['game_highscore'],
				$var['game_highuser'],
				$var['game_highdate'],
				$var['game_votetotal'],
				$var['game_votesum'],
				$var['game_cost'],
				$var['game_reward'],
				$var['game_jackpot'],
				$var['game_use_jackpot'],
				$var['cat_desc'],
				$var['cat_style'],
				$var['cat_type'],
				$var['cat_status'],
				$var['cat_desc_uid'],
				$var['cat_desc_bitfield'],
				$var['cat_desc_options'],
				$var['parent_id'],
				$var['left_id'],
				$var['right_id'],
				$var['cat_parents'],
				$var['cat_test'],
				$var['cat_cost'],
				$var['cat_reward'],
				$var['cat_use_jackpot'],
				$var['game_rating'],
				$var['security']
			);

			$return .= '</p><div style="font-size: 13px;"><strong>GAME_DATA<br><br></strong><pre>';
			$return .= var_export($var, true);
			$return .= '</pre><br><br></div>';

			$debug = array(
				'POST'		=> $_POST,
				'GET'		=> $_GET,
				'COOKIE'	=> $_COOKIE
			);

			foreach ($debug as $key => $value)
			{
				$return .= '<div style="font-size: 13px;"><strong>' . $key . '<br><br></strong>';
				$return .= '<pre>';
				$return .= var_export($value, true);
				$return .= '</pre>';
				$return .= '<br><br></div>';
			}

			$return .= '<p>';
		}
		else
		{
			$debug = array(
				'POST'		=> $_POST,
				'GET'		=> $_GET,
				'REQUEST'	=> $_REQUEST,
				'COOKIE'	=> $_COOKIE,
				'SERVER'	=> $_SERVER
			);

			$return .= '</p>';

			foreach ($debug as $key => $value)
			{
				$return .= '<div style="font-size: 13px;"><strong>' . $key . '<br><br></strong>';
				$return .= '<pre>';
				$return .= var_export($value, true);
				$return .= '</pre>';
				$return .= '<br><br></div>';
			}

			$return .= '<p>';
		}

		return $return;
	}
}
