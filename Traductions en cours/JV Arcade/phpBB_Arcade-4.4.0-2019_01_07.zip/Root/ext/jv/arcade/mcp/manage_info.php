<?php
/**
*
* @package phpBB Arcade
* @version $Id: manage_info.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\mcp;

class manage_info
{
	function module()
	{
		return array(
			'filename'			=> '\jv\arcade\mcp\manage_module',
			'title'				=> 'MCP_ARCADE',
			'modes'				=> array(
				'games'			=> array('title' => 'MCP_ARCADE_MANAGE_GAMES'	, 'auth' => 'ext_jv/arcade && acl_u_arcade && acl_m_arcade_game', 'cat' => array('MCP_CAT_ARCADE')),
				'tournament'	=> array('title' => 'MCP_ARCADE_MANAGE_TOUR'	, 'auth' => 'ext_jv/arcade && acl_u_arcade && acl_m_arcade_tour', 'cat' => array('MCP_CAT_ARCADE'))
			)
		);
	}
}
