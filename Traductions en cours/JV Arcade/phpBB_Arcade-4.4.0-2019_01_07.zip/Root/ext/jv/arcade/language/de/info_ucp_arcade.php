<?php
/**
*
* @package phpBB Arcade
* @version $Id: info_ucp_arcade.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

//Arcade
$lang = array_merge($lang, array(
	'UCP_ARCADE'							=> 'phpBB Arcade',
	'UCP_ARCADE_CAT_GAMES_STYLE'			=> 'Kategorienstil Spiele',
	'UCP_ARCADE_CAT_STYLE'					=> 'Kategorienstil',
	'UCP_ARCADE_DELETE_FAVORITE'			=> 'Bevorzugtes Spiel entfernen',
	'UCP_ARCADE_DELETE_FAVORITES'			=> 'Bevorzugte Spiele entfernen',
	'UCP_ARCADE_DELETE_FAVORITES_CONFIRM'	=> 'Bist du sicher, dass du diese bevorzugten Spiele entfernen möchtest?',
	'UCP_ARCADE_DELETE_FAVORITE_CONFIRM'	=> 'Bist du sicher, dass du dieses bevorzugte Spiel entfernen möchtest?',
	'UCP_ARCADE_DISPLAY_GAME_IMAGE'			=> 'Spielvorschau anzeigen',
	'UCP_ARCADE_DISPLAY_POPUP_ICON'			=> 'Popupsymbol anzeigen',
	'UCP_ARCADE_FAVORITES'					=> 'Favoriten verwalten',
	'UCP_ARCADE_FAVORITES_DELETED'			=> 'Bevorzugte Spiele erfolgreich entfernt.',
	'UCP_ARCADE_FAVORITES_EXPLAIN'			=> 'Du kannst unten deine Lieblingsspiele ansehen, markieren und löschen.',
	'UCP_ARCADE_FAVORITE_DELETED'			=> 'Bevorzugtes Spiel erfolgreich entfernt.',
	'UCP_ARCADE_GAME_OVER_ANIMATION'		=> 'Spiele Animation ab am Ende eines Spiels',
	'UCP_ARCADE_GAME_OVER_ANIMATION_SOUND'	=> 'Aktiviere Ton für Animation',
	'UCP_ARCADE_GAME_OVER_RANDOM_GAMES'		=> 'Zeige zufällige Spiele am Ende eines Spiels an',
	'UCP_ARCADE_GAME_OVER_SOUND'			=> 'Spiele Game Over-Ton am Ende eines Spiels ab',
	'UCP_ARCADE_NO_PERM_PM_LOSS_HIGHSCORE'	=> 'Du hast keine Berechtigung, Nachrichten über den Verlust deiner Meisterschaften zu empfangen.',
	'UCP_ARCADE_POST'						=> 'Beitragseinstellungen',
	'UCP_ARCADE_POST_EXPLAIN'				=> 'Beitragseinstellungen anpassen',
	'UCP_ARCADE_SELECTED_HIGHLIGHT'			=> 'Ausgewählte markieren',
	'UCP_ARCADE_SELECTED_HIGHLIGHT_REMOVE'	=> 'Ausgewählte Markierung entfernen',
	'UCP_ARCADE_SEND_PM_EXPLAIN'			=> 'Wenn du ein Spiel oder eine Herausforderung im Duell gegen einen Benutzer verlierst, wirst du per privater Nachricht darüber informiert.',
	'UCP_ARCADE_SETTINGS'					=> 'Einstellungen',
	'UCP_ARCADE_SETTINGS_EXPLAIN'			=> 'Diese Einstellungen kontrollieren verschiedene Bereiche der Spielhalle.',
	'UCP_CAT_ARCADE'						=> 'Spielhalle',
	'UCP_CHALLENGE_ENABLED'					=> 'Herausforderung aktiviert',
	'UCP_CHALLENGE_ENABLED_EXPLAIN'			=> 'Falls aktiviert, können sich Spieler duellieren.',
));
