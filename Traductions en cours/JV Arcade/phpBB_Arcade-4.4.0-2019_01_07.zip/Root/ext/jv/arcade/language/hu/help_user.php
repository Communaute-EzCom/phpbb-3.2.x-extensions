<?php
/**
*
* @package phpBB Arcade
* @version $Id: help_user.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'ARCADE_HELP_FAQ_BLOCK_INTRO'						=> 'Bevezető',
	'ARCADE_HELP_FAQ_BLOCK_GENERAL'						=> 'Általános kérdése',
	'ARCADE_HELP_FAQ_BLOCK_USER_SET'					=> 'Felhasználói beállítások',
	'ARCADE_HELP_FAQ_BLOCK_PLAYING'						=> 'Játszással kapcsolatos kérdések',
	'ARCADE_HELP_FAQ_BLOCK_CAT'							=> 'Kategóriákkal kapcsolatos kérdések',
	'ARCADE_HELP_FAQ_BLOCK_SEARCH'						=> 'Kereséssel kapcsolatos kérdések',
	'ARCADE_HELP_FAQ_BLOCK_FAV'							=> 'Kedvenc játékokkal kapcsolatos kérdések',
	'ARCADE_HELP_FAQ_BLOCK_CHALLENGE'					=> 'Kihívással kapcsolatos kérdések',
	'ARCADE_HELP_FAQ_BLOCK_TOUR'						=> 'Versennyel kapcsolatos kérdések',
	'ARCADE_HELP_FAQ_BLOCK_POINTS'						=> 'Pontrendszerrel kapcsolatos kérdések',
	'ARCADE_HELP_FAQ_BLOCK_ARCADE'						=> 'phpBB Arcade kérdések',
// step 1
	'ARCADE_HELP_FAQ_INTRO_ARCADE_ANSWER'				=> 'A játékterem a felhasználók szórakoztatását biztosítja, különféle flash és Html5-ős játékokkal. A játékterem használatának engedélyezése az adminisztrátortól függ, de neked is lehetőséged van ki- vagy bekapcsolni egyes szolgáltatásokat a felhasználói vezérlő pultban. Ezzel együtt az alábbi útmutatót valószínűleg hasznosnak fogod találni.',
	'ARCADE_HELP_FAQ_INTRO_ARCADE_QUESTION'				=> 'Mi az a játékterem?',

	'ARCADE_HELP_FAQ_INTRO_REG_ANSWER'					=> 'A regisztráció nem feltétlenül kötelező, a játékterem adminisztrátorán múlik, hogy a játék használatához szükséges-e. Vedd figyelembe, hogy ha regisztrálsz és belépsz a játékterembe akkor számos további hasznos funkcióhoz férhetsz hozzá, mint például: (Az elért pontszámaidat elmentheted, kommentálhatod a játékokat, kijelölhetsz kedvenc játékokat, értékelheted a játékokat, más felhasználókat kihívhatsz egy versenyre, vagy akár részt is vehetsz egy elindított versenyen és még sok más hasznos dolog…), természetesen ezek a funkciók használatát is az adminisztrátor állítja be így lehet egyes funkciók nincsenek használatban.',
	'ARCADE_HELP_FAQ_INTRO_REG_QUESTION'				=> 'Miért kell egyáltalán regisztrálnom?',

	'ARCADE_HELP_FAQ_INTRO_FUN_ANSWER'					=> 'A játékterem számos funkciókat tartalmaz, de csak azok elérhetőek amiket az adminisztrátor bekapcsol illetve engedélyez.
															<br><strong>Funkciók:</strong>
															<ul>
																<li>Beállítások, személyre szabás.</li>
																<li>Kategorizált játékok.</li>
																<li>Új játékok megtekintése.</li>
																<li>Véletlen játék játszása.</li>
																<li>Kedvenc játékok kiválasztása ill. kiemelése.</li>
																<li>Játékok értékelése.</li>
																<li>Játékok keresése.</li>
																<li>Játékok hibabejelentése.</li>
																<li>Játékok letöltése.</li>
																<li>Játszás új ablakban.</li>
																<li>Játszás teljes képernyőn.</li>
																<li>Játékok átméretezése.</li>
																<li>Játék háttérvilágítás ki/be kapcsolása.</li>
																<li>Verseny, több játék és felhasználó között.</li>
																<li>Felhasználók kihívása egy játékban.</li>
																<li>Véletlen kihívás generálása.</li>
																<li>Részletes különálló statisztikák</li>
																<li>Játékok statisztikái.</li>
																<li>Felhasználók statisztikái.</li>
																<li>Kategóriák statisztikái.</li>
																<li>Ranglista.</li>
																<li>Pontrendszer használat.</li>
																<li>És még sok más…</li>
															</ul>',
	'ARCADE_HELP_FAQ_INTRO_FUN_QUESTION'				=> 'Milyen funkciókat tartalmaz a játékterem?',
// step 2
	'ARCADE_HELP_FAQ_GENERAL_GAME_RATING_ANSWER'		=> 'A játékok értékelése egy igen hasznos funkció. A felhasználók számára megkönnyíti a keresést, ugyanis, ha egy játékot minél többen értékelnek jóra akkor a játék a statisztikában is mindig előrébb kerül, így a legjobbra értékelt játékot a felhasználók könnyen megtalálják.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_RATING_QUESTION'		=> 'Mire jó a játékok értékelése?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_RANDOM_ANSWER'		=> 'A véletlen játék azért jó, mert nem egy bizonyos kategóriából választ ki egy játékot, hanem bármit elénk tárhat így nem válik unalmassá, ha például állandóan egy kategóriának a játékaival játszunk.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_RANDOM_QUESTION'		=> 'Mire jó a véletlen játék?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_BUG_ANSWER'			=> 'A hibás játékokat célszerű jelenteni az adminisztrátornak, hogy a játékot mihamarabb javítani tudjuk. Minden játék tartalmaz egy hibabejelentési linket amit ilyen esetben kell használni. A link használata azért fontos mert ez tartalmazza az összes játék információt is amit külön nekünk nem kell megírni, csak is a felmerülő hiba jelenséget. A hiba leírásába célszerű megadni, hogy a hiba melyik böngészőnél jelentkezett, ugyanis nem biztos, hogy a hiba előfordul másik böngésző használata esetében is. Továbbá érdemes az is leírni, hogy milyen eszközön történt a hiba Pl:(Pc, tablet vagy mobil). A Html5-ős játékoknál az is mérvadó lehet, hogy a képernyőnk mely felbontást használta.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_BUG_QUESTION'			=> 'Ha egy játék hibás akkor mi a teendő?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_DOWNLOAD_ANSWER'		=> 'Igen, amennyiben az adminisztrátor engedélyezi.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_DOWNLOAD_QUESTION'	=> 'A játékokat le lehet tölteni?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_NAME_LINK_ANSWER'		=> 'Amennyiben van jogosultságod a játékkal játszani abban az esetben a játék neve linkként jelenik meg.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_NAME_LINK_QUESTION'	=> 'A játék nevek többsége link, de egyes nevek sima szövegként jelennek meg, miért?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_USER_STAT_ANSWER'		=> 'Amennyiben van rá jogosultságod a játéktermi menüben kattints a „Statisztikák” menü pontra, és ott a lap alján válaszd ki az adott játékot, felhasználót.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_USER_STAT_QUESTION'	=> 'Hogyan tekinthetem meg egy adott játék, felhasználó statisztikai adatait?',

	'ARCADE_HELP_FAQ_GENERAL_USER_RECORD_ANSWER'		=> 'Igen, a felhasználó statisztikai adatainál az avatar alatt kattints az „Összes rekord megtekintése” linkre.',
	'ARCADE_HELP_FAQ_GENERAL_USER_RECORD_QUESTION'		=> 'Megtudom-e nézni egy felhasználónak, csak a rekordjait?',

	'ARCADE_HELP_FAQ_GENERAL_SUPER_CHAMP_ANSWER'		=> 'A szuper bajnok az a felhasználó aki tartja a legmagasabb elért eredményt az adott játékban. A szuper bajnok nem rendelkezik trófeával, kivéve, ha ő áll az első helyen is. Ha az adminisztrátor újraindítja a játéktermet akkor lehetősége van megtartani a szuper bajnokokat, így lehetőség van látni, hogy mi is volt az eddig legmagasabb elért eredmény egy játékban.',
	'ARCADE_HELP_FAQ_GENERAL_SUPER_CHAMP_QUESTION'		=> 'Mi az a szuper bajnok?',

	'ARCADE_HELP_FAQ_GENERAL_RANG_LIST_ANSWER'			=> 'A ranglista a megszerzett trófeák mennyiségét veszi figyelembe, minél több trófeával rendelkezik egy felhasználó annál jobb rangsorolásba kerül. A rang kép meghatározását az adminisztrátor adja meg, mégpedig úgy, hogy adott mennyiségű trófeához köti az egyes rang képeket.',
	'ARCADE_HELP_FAQ_GENERAL_RANG_LIST_QUESTION'		=> 'Mi az a ranglista?',
// step 3
	'ARCADE_HELP_FAQ_USER_SET_CONFIG_ANSWER'			=> 'Amennyiben regisztrált felhasználó vagy, minden beállításod az adatbázisban kerül tárolásra. Ezek megváltoztatásához kattints a Felhasználói vezérlőpult linkre (általában az oldal tetején található). Itt megváltoztathatod az összes beállításodat.',
	'ARCADE_HELP_FAQ_USER_SET_CONFIG_QUESTION'			=> 'Hogyan tudom megváltoztatni a beállításaimat?',

	'ARCADE_HELP_FAQ_USER_SET_CHALL_DISABLE_ANSWER'		=> 'Akkor érdemes kikapcsolni, ha nem szeretnéd, hogy más felhasználó kihívhasson téged egy jó kis versenyre, amennyiben kikapcsolód te magad sem fogsz tudni kihívni egy másik felhasználót. Vedd figyelembe, hogy a kihívást az adminisztrátor is kikapcsolhatja.',
	'ARCADE_HELP_FAQ_USER_SET_CHALL_DISABLE_QUESTION'	=> 'Kihívás engedélyezése, érdemes kikapcsolni?',

	'ARCADE_HELP_FAQ_USER_SET_IMG_DISABLE_ANSWER'		=> 'Akkor érdemes kikapcsolni, ha számodra az oldal betöltése túl lassú.',
	'ARCADE_HELP_FAQ_USER_SET_IMG_DISABLE_QUESTION'		=> 'Avatarok, játék képek megjelenítése, érdemes kikapcsolni?',

	'ARCADE_HELP_FAQ_USER_SET_CAT_STYLE_ANSWER'			=> 'A játékterem több stílusban is meg tud jelenni, személyre szabhatod, hogy neked melyik tetszik, ezt az opciót az adminisztrátor felülbírálhatja.',
	'ARCADE_HELP_FAQ_USER_SET_CAT_STYLE_QUESTION'		=> 'Mi az a kategória stílus?',

	'ARCADE_HELP_FAQ_USER_SET_FAV_MANAGE_ANSWER'		=> 'Itt tudod a már felvett kedvenc játékaidat eltávolítani a kedvencek közül, továbbá kiemelté teheted az egyes játékokat.',
	'ARCADE_HELP_FAQ_USER_SET_FAV_MANAGE_QUESTION'		=> 'Mi az a kedvencek kezelése?',
// step 4
	'ARCADE_HELP_FAQ_PLAYING_NOT_PLAY_ANSWER'			=> 'Ennek számos oka lehet:
															<ul>
																<li>A játékok futtatásához elengedhetetlen, hogy a számítógépeden telepítve legyen a <a href="http://www.adobe.com/go/getflashplayer/" title="Adobe Flash Player beszerzése">„flash player”</a>, lehetőleg a legfrissebb verziója.</li>
																<li>A böngészőben nincs engedélyezve a „javascript futtatása”.</li>
																<li>Az adminisztrátor nem adott engedélyt az adott játék játszására.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_NOT_PLAY_QUESTION'			=> 'Miért nem tudok játszani?',

	'ARCADE_HELP_FAQ_PLAYING_NOT_SAVE_SCORE_ANSWER'		=> 'Ennek számos oka lehet:
															<ul>
																<li>Először is győződj meg, hogy a böngésződben engedélyezve legyen a „Cookies”, azaz a sütik használata.</li>
																<li>Győződj meg arról, hogy be-e vagy jelentkezve.</li>
																<li>A játék helytelen elindítása.</li>
																<li>A játék hibás.</li>
																<li>Az adminisztrátor nem adott engedélyt az adott játék eredmény benyújtására.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_NOT_SAVE_SCORE_QUESTION'	=> 'Miért nem tudom menteni az elért pontszámaimat?',

	'ARCADE_HELP_FAQ_PLAYING_GAME_SIZE_ANSWER'			=> 'Némelyik játéknál előfordulhat, hogy nem fér bele a fórum által használt megjelenésbe, ezért lehetőség van az információ blokk becsukására ezzel megnövelve a játék helyét. Továbbá lehetőség van a játékok nagyítására illetve kicsinyítésére vagy játszhatunk teljes képernyőn, esetleg új ablakban, amennyiben az adminisztrátor engedélyezi.',
	'ARCADE_HELP_FAQ_PLAYING_GAME_SIZE_QUESTION'		=> 'Mi a teendő, ha egy játék mérete túl nagy vagy túl kicsi?',

	'ARCADE_HELP_FAQ_PLAYING_POPUP_ANSWER'				=> 'Igen, amennyiben az adminisztrátor engedélyezi.',
	'ARCADE_HELP_FAQ_PLAYING_POPUP_QUESTION'			=> 'Játszhatok-e egy játékot új ablakban?',

	'ARCADE_HELP_FAQ_PLAYING_FULL_SCREEN_ANSWER'		=> 'Igen, amennyiben az adminisztrátor engedélyezi a számodra a játékok átméretezését.',
	'ARCADE_HELP_FAQ_PLAYING_FULL_SCREEN_QUESTION'		=> 'Játszhatok-e egy játékot teljes képernyőn?',

	'ARCADE_HELP_FAQ_PLAYING_MOBILE_ANSWER'				=> 'Igen, de a legtöbb esetben csak a Html5-ős játékok futnak a mobil készülékeken.',
	'ARCADE_HELP_FAQ_PLAYING_MOBILE_QUESTION'			=> 'Játszhatok-e mobiltelefonon?',

	'ARCADE_HELP_FAQ_PLAYING_BACKLIGHT_ANSWER'			=> 'A háttérvilágításnak két hasznos tulajdonsága van.
															<ul>
																<li>A játék körüli teret elsötétíti, hogy ne zavarjon.</li>
																<li>A játék körüli gombokat inaktívvá teszi, hogy véletlenül se kattintsunk egy linkre, ez megakadályozza, hogy másik oldal töltődjön be játék közben.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_BACKLIGHT_QUESTION'		=> 'Mi az a háttérvilágítás?',

	'ARCADE_HELP_FAQ_PLAYING_WHITE_SCREEN_ANSWER'		=> 'Előfordulhat, hogy egy játék igen nagy terjedelmű ezért a lassabb internet kapcsolat esetében várni kell míg a játék betöltődik.',
	'ARCADE_HELP_FAQ_PLAYING_WHITE_SCREEN_QUESTION'		=> 'Játék elindításánál fehér képernyő, miért?',

	'ARCADE_HELP_FAQ_PLAYING_HIDDEN_SCORE_ANSWER'		=> 'Az érintett játék kihívás alatt áll, ezért az érintett felhasználók eredménye rejtve van mindenki számára, míg a kihívás véget nem ér.',
	'ARCADE_HELP_FAQ_PLAYING_HIDDEN_SCORE_QUESTION'		=> 'Az eredmény felsorolásnál illetve, a bajnok eredménye helyén a „Rejtve” szöveg található, miért?',
// step 5
	'ARCADE_HELP_FAQ_CAT_USER_PERMISSION_ANSWER'		=> 'Ha belépsz egy kategóriába akkor alul megtalálod a „Játéktermi jogosultságok” címet, és alatta fel van sorolva a rád vonatkozó jogosultságok.',
	'ARCADE_HELP_FAQ_CAT_USER_PERMISSION_QUESTION'		=> 'Milyen jogosultságok vonatkoznak rám?',

	'ARCADE_HELP_FAQ_CAT_PASSWORD_ANSWER'				=> 'Ha egy kategóriát jelszó véd akkor azt egy adminisztrátortól kell kikérni.',
	'ARCADE_HELP_FAQ_CAT_PASSWORD_QUESTION'				=> 'Kategória jelszót kér, mi a teendő?',

	'ARCADE_HELP_FAQ_CAT_AGE_ANSWER'					=> 'Előfordulhat, hogy egy kategóriába az adminisztrátorok gyenge, könnyen játszható játékokat gyűjtenek össze a kiskorúak számára, ezért csak a fiatalok játszhatnak abban a kategóriában. Ezen kívül vannak olyan játékok amiket viszont a kiskorúaktól akarnak távol tartani ezért csak nagykorúak léphetnek be egyes kategóriákba.',
	'ARCADE_HELP_FAQ_CAT_AGE_QUESTION'					=> 'Egyes kategóriákat életkor határ véd, miért?',

	'ARCADE_HELP_FAQ_CAT_STAT_ANSWER'					=> 'Igen, ha belépsz a kategóriába akkor a kategória neve mellett fogod megtalálni a „Kategória statisztika megtekintése” linket.',
	'ARCADE_HELP_FAQ_CAT_STAT_QUESTION'					=> 'Szeretném a kategóriák egyenkénti statisztikáját megtekinteni, lehetséges?',
// step 6
	'ARCADE_HELP_FAQ_SEARCH_GAME_ANSWER'				=> 'Ha a keresési funkció be van kapcsolva akkor középtájt találod meg a keresési mezőt ahova beírhatod a keresett játék nevét. Továbbá lehetőség van a játék kezdőbetűire rákeresned, ehhez elég csak ráklikkelned a kereset kezdőbetűre.',
	'ARCADE_HELP_FAQ_SEARCH_GAME_QUESTION'				=> 'Hogyan tudok megkeresni egy játékot?',

	'ARCADE_HELP_FAQ_SEARCH_SNIP_GAME_ANSWER'			=> 'A kereső figyelembe veszi automatikusan a szó részeket is. Tehát, ha az írjuk a keresőbe, hogy <strong>pac</strong>, akkor a <strong>Pacman</strong> nevű játékot is ki fogja adni.',
	'ARCADE_HELP_FAQ_SEARCH_SNIP_GAME_QUESTION'			=> 'Hogyan keresek meg egy olyan játékot aminek nem ismerem a pontos nevét?',
// step 7
	'ARCADE_HELP_FAQ_FAV_ANSWER'						=> 'Ha egy játékot kedvencnek jelölsz akkor nem kell később azzal foglalkozni, hogy kikeresd a számos játékok közül, hanem egyszerűen megtalálhatod a kedvenceid közt. Ezzel magadnak spórolsz egy csomó időt.',
	'ARCADE_HELP_FAQ_FAV_QUESTION'						=> 'Mire jó egy játékot kedvencnek jelölni?',

	'ARCADE_HELP_FAQ_FAV_HIGHLIGHT_ANSWER'				=> 'Lehetőséged van a kedvencek közül is kiemelni azokat a játékokat amivel leginkább játszol, ezt megteheted a felhasználói vezérlő pultban.',
	'ARCADE_HELP_FAQ_FAV_HIGHLIGHT_QUESTION'			=> 'Túl sok a kedvenc játékom, hogyan tudok könnyebben rátalálni egyes játékokra?',
// step 8
	'ARCADE_HELP_FAQ_CHALLENGE_PERMISSION_ANSWER'		=> 'A kihívás csak akkor látható, ha be van kapcsolva és az adminisztrátor engedélyezi a hozzáférést.',
	'ARCADE_HELP_FAQ_CHALLENGE_PERMISSION_QUESTION'		=> 'Miért nem látom a kihívást?',

	'ARCADE_HELP_FAQ_CHALLENGE_ACCEPT_ANSWER'			=> 'Amennyiben érkezik számodra egy kihívás az akkor teljes amikor a kihívás oldalon elfogadod, vagy elutasítod, ha ez megtörtént utána lehet játszani.',
	'ARCADE_HELP_FAQ_CHALLENGE_ACCEPT_QUESTION'			=> 'Érkezett számomra egy kihívás, lejátszottam a játékot, de továbbra is azt jelzi, hogy érkezett számomra egy kihívás, miért?',

	'ARCADE_HELP_FAQ_CHALLENGE_START_ANSWER'			=> 'A kihívás oldalán klikk a kihívás gombra, erre betöltődik az adott űrlap, amiben a következők szerepelnek:
															<ul>
																<li>Játékok listája.</li>
																<li>Kedvencek listája. <em>Amennyiben van felvéve kedvenc játék.</em></li>
																<li>Felhasználói lista, vagy felhasználó megadása.</li>
																<li>Barátok listája. <em>Amennyiben van felvéve barát.</em></li>
															</ul>
															<br>Itt egy játékot és felhasználót kell, hogy ki válasz amennyiben ez megtörtént klikk a kihívás elküldése gombra.
															<br>Megjegyzés: <em>Amennyiben használatban van egy pontrendszer, tétet is meg lehet adni. A tétet megszabhatja, vagy akár fix tétet is beállíthat egy adminisztrátor.</em>',
	'ARCADE_HELP_FAQ_CHALLENGE_START_QUESTION'			=> 'Hogyan tudok elindítani egy kihívást?',

	'ARCADE_HELP_FAQ_CHALLENGE_ARRIVED_ANSWER'			=> 'Azok a kihívások amik számodra érkeztek. Elfogadhatod, vagy elutasíthatod őket.',
	'ARCADE_HELP_FAQ_CHALLENGE_ARRIVED_QUESTION'		=> 'Mit jelent az „Érkezett kihívás”?',

	'ARCADE_HELP_FAQ_CHALLENGE_SENT_ANSWER'				=> 'Azok a kihívások, amiket te indítottál más felhasználók felé. Ezeket a kihívásokat vissza is vonhatod.',
	'ARCADE_HELP_FAQ_CHALLENGE_SENT_QUESTION'			=> 'Mit jelent a „Küldött kihívás”?',

	'ARCADE_HELP_FAQ_CHALLENGE_ONGOING_ANSWER'			=> 'Azok a kihívások amik már el lettek fogadva, és a kihívás már mind két fél számára játszható, de te vagy a másik fél se játszotta még le. Ha egy játék hibás lenne akkor esélyünk van bejelenteni, és a kihívás ebben az esetben törlésre kerül.',
	'ARCADE_HELP_FAQ_CHALLENGE_ONGOING_QUESTION'		=> 'Mit jelent a „Folyamatban lévő kihívás”?',

	'ARCADE_HELP_FAQ_CHALLENGE_GAME_CHAMP_ANSWER'		=> 'Ha normál ablakban játszol akkor a játék opciók táblában szerepel a „Bajnok kihívása” link. Kattints rá, és akkor egyszerűen kihívhatod a bajnokot.',
	'ARCADE_HELP_FAQ_CHALLENGE_GAME_CHAMP_QUESTION'		=> 'Hogyan tudom egyszerűen kihívni egy játék bajnokát?',

	'ARCADE_HELP_FAQ_CHALLENGE_PRACTICE_ANSWER'			=> 'Míg a kihívást nem fogadod el addig igen, de miután már elfogadtad a kihívást már nincs lehetőség további gyakorlásra.',
	'ARCADE_HELP_FAQ_CHALLENGE_PRACTICE_QUESTION'		=> 'Érkezett számomra egy kihívás, van-e mód gyakorlásra?',

	'ARCADE_HELP_FAQ_CHALLENGE_POINTS_ANSWER'			=> 'Ha kihív téged egy felhasználó, és tétnek meghatározz például 100 pontot akkor az a kihívás pillanatában levonásra kerül az egyenlegedből, ha az érintett játéknak költsége is van például: 5 pont, akkor az is levonásra kerül, tehát összesen ebben az esetben 105 pontot von le tőled a rendszer, azért, hogy fedezve legyen a teljes kihívás lejátszása. Amennyiben elutasítod a kihívást abban az esetben azonnal visszatérítésre kerül a levont összeg. Ha egy kihívás elfogadásra kerül, de a játék nem kerül lejátszásra, és közben a kihívás ideje lejár, akkor is vissza utalásra kerül a tét és a játék költség.',
	'ARCADE_HELP_FAQ_CHALLENGE_POINTS_QUESTION'			=> 'Kihívtak, és eltűnt egy csomó pontom, miért?',

	'ARCADE_HELP_FAQ_CHALLENGE_BUG_GAME_ANSWER'			=> 'Ilyen esetben a folyamatban lévő kihívásoknál szerepelő hibabejelentési linket kell használni, a jelentett játék kihívása azonnal törlésre fog kerülni, ha volt tét akkor azt visszautalja a rendszer.',
	'ARCADE_HELP_FAQ_CHALLENGE_BUG_GAME_QUESTION'		=> 'Kihívtak, de az érintett játék hibás, mi a teendő?',

	'ARCADE_HELP_FAQ_CHALLENGE_DRAW_BET_ANSWER'			=> 'Amennyiben egy kihívás döntetlen úgy a feltett tét mindkét felhasználónak visszautalásra fog kerülni.',
	'ARCADE_HELP_FAQ_CHALLENGE_DRAW_BET_QUESTION'		=> 'Mi történik a téttel akkor, ha a kihívás döntetlen lesz?',

	'ARCADE_HELP_FAQ_CHALLENGE_EXP_TIME_ANSWER'			=> 'A lejárati idő azt az időt jelzi mikor is a kihívás automatikusan törlésre kerül, ez idő alatt a kihívást teljesíteni kell.',
	'ARCADE_HELP_FAQ_CHALLENGE_EXP_TIME_QUESTION'		=> 'Mi az a „Lejárati idő”?',

	'ARCADE_HELP_FAQ_CHALLENGE_END_ANSWER'				=> 'A kihívás minden egyes menetéről privát üzenet értesít, amennyiben engedélyezve van a privát üzenet.',
	'ARCADE_HELP_FAQ_CHALLENGE_END_QUESTION'			=> 'Honnan tudom, hogy vége a kihívásnak?',

	'ARCADE_HELP_FAQ_CHALLENGE_PREVENT_ANSWER'			=> 'A kihívás minden egyes menetéről privát üzenet értesít, amennyiben engedélyezve van a privát üzenet.',
	'ARCADE_HELP_FAQ_CHALLENGE_PREVENT_QUESTION'		=> 'Hogyan tudom megakadályozni, hogy kihívjanak?',
// step 9
	'ARCADE_HELP_FAQ_TOUR_PRACTICE_ANSWER'				=> 'A verseny elindulása előtt igen, de ha már elindult a verseny nincs mód további gyakorlásra. A versenyhez tartozó összes játék kiértékelésre kerül, függetlenül, hogy hányadik helyen álltál.',
	'ARCADE_HELP_FAQ_TOUR_PRACTICE_QUESTION'			=> 'Van-e mód gyakorlásra?',

	'ARCADE_HELP_FAQ_TOUR_PLAY_NUM_ANSWER'				=> 'Minden egyes elindított játék azonnal beszámításra kerül független attól, hogy mentjük-e az eredményt.',
	'ARCADE_HELP_FAQ_TOUR_PLAY_NUM_QUESTION'			=> 'Játszok egy játékot, de nem mentem el az elért eredményt, a játszások száma még is növekszik a versenyben, miért?',

	'ARCADE_HELP_FAQ_TOUR_NO_RESULT_ANSWER'				=> 'A versenyben előre megadott csoport(ok) vehetnek részt, győződj meg arról, hogy te tagja-e vagy a megadott csoport(ok)nak. Amennyiben mégis tagja lennél az adott csoportnak, úgy fordulj egy adminisztrátorhoz.',
	'ARCADE_HELP_FAQ_TOUR_NO_RESULT_QUESTION'			=> 'Játszottam egy játékot, de az eredményt nem látom a versenyben, miért?',

	'ARCADE_HELP_FAQ_TOUR_RIGHT_RESULT_ANSWER'			=> 'Ha a versenyben megadott maximum játszások számát eléred akkor a további játszás eredményei már nem kerülnek be a versenybe.',
	'ARCADE_HELP_FAQ_TOUR_RIGHT_RESULT_QUESTION'		=> 'Újra játszottam egy játékot jobb eredménnyel, de nem íródott be a versenybe, miért?',
// step 10
	'ARCADE_HELP_FAQ_POINTS_SYSTEM_ANSWER'				=> 'A pontrendszer egy összetett kiegészítő amit az adminisztrátor adhat hozzá a fórumhoz illetve a játékterem használatához. A pontrendszer használatakor a játékterem használhat különféle jutalmakat és költségeket, ezeket is az adminisztrátor határozza meg.',
	'ARCADE_HELP_FAQ_POINTS_SYSTE_QUESTION'				=> 'Mi az a pontrendszer?',

	'ARCADE_HELP_FAQ_POINTS_REWARD_ANSWER'				=> 'A jutalom alapesetben két esetben kapható meg: Szuper bajnoki, bajnoki cím megszerzése esetén. A jutalom összegét az adminisztrátor határozza meg.',
	'ARCADE_HELP_FAQ_POINTS_REWARD_QUESTION'			=> 'Mit takar a jutalom?',

	'ARCADE_HELP_FAQ_POINTS_JACKPOT_ANSWER'				=> 'A főnyeremény a játék költségéből származik. Minden játék indításánál a játék költsége hozzáadásra kerül a főnyereményhez, így a főnyeremény mindaddig növekszik míg azt valaki meg nem szerzi. A főnyeremény min/max. összegét az adminisztrátor meghatározhatja.',
	'ARCADE_HELP_FAQ_POINTS_JACKPOT_QUESTION'			=> 'Mit takar a főnyeremény?',

	'ARCADE_HELP_FAQ_POINTS_COST_ANSWER'				=> 'A játék költség azaz összeg ami levonásra kerül minden egyes játék elindításánál, vedd figyelembe, hogy a költségek egyes kategóriákban, játékokban eltérő lehet. A költség összegét az adminisztrátor határozza meg.',
	'ARCADE_HELP_FAQ_POINTS_COST_QUESTION'				=> 'Mit takar a játék költség?',

	'ARCADE_HELP_FAQ_POINTS_DOWNLOAD_COST_ANSWER'		=> 'A játék letöltési költség azaz összeg ami levonásra kerül minden egyes játék letöltése esetén, vedd figyelembe, hogy a költségek egyes kategóriákban, játékokban eltérő lehet. A költség összegét az adminisztrátor határozza meg.',
	'ARCADE_HELP_FAQ_POINTS_DOWNLOAD_COST_QUESTION'		=> 'Mit takar a játék letöltési költség?',
// step 11
	'ARCADE_HELP_FAQ_ARCADE_CREATE_ANSWER'				=> 'Ezt a kiegészítőt (eredeti formájában) a <a href="https://jv-arcade.com/">JV-Arcade Group</a> készítette, adta ki, és gyakorolja a szerzői jogokat felette. A GNU General Public License alatt érhető el, és szabadon terjeszthető. További információért lásd a linket.',
	'ARCADE_HELP_FAQ_ARCADE_CREATE_QUESTION'			=> 'Ki készítette ezt a játéktermet?',

	'ARCADE_HELP_FAQ_ARCADE_NOT_AVAILABLE_X_ANSWER'		=> 'Ezt a kiegészítőt a JV-Arcade Group készítette, és licenceli. Ha úgy gondolod, hogy újabb szolgáltatások, funkciók szükségesek a játékterembe, vagy valamilyen működési hibát találtál, látogasd meg a <a href="https://jv-arcade.com/New_Ideas.html">Játékterem, új ötletek centrumát</a>, ahol ezzel kapcsolatban további információkat kaphatsz.',
	'ARCADE_HELP_FAQ_ARCADE_NOT_AVAILABLE_X_QUESTION'	=> 'Miért nem érhető el az X szolgáltatás?'
));
