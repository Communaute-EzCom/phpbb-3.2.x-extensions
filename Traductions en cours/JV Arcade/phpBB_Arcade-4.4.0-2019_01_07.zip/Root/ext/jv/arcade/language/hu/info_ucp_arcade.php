<?php
/**
*
* @package phpBB Arcade
* @version $Id: info_ucp_arcade.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

//Arcade
$lang = array_merge($lang, array(
	'UCP_ARCADE'							=> 'phpBB Arcade',
	'UCP_ARCADE_CAT_GAMES_STYLE'			=> 'Kategória játék stílus',
	'UCP_ARCADE_CAT_STYLE'					=> 'Kategória stílus',
	'UCP_ARCADE_DELETE_FAVORITE'			=> 'Kedvenc játék törlése',
	'UCP_ARCADE_DELETE_FAVORITES'			=> 'Kedvenc játékok törlése',
	'UCP_ARCADE_DELETE_FAVORITES_CONFIRM'	=> 'Biztos vagy benne, hogy törölni szeretnéd ezeket a játékokat a kedvenceid közül?',
	'UCP_ARCADE_DELETE_FAVORITE_CONFIRM'	=> 'Biztos vagy benne, hogy törölni szeretnéd ezt a játékot a kedvenceid közül?',
	'UCP_ARCADE_DISPLAY_GAME_IMAGE'			=> 'Játék képek megjelenítése',
	'UCP_ARCADE_DISPLAY_POPUP_ICON'			=> 'Popup ikon megjelenítése',
	'UCP_ARCADE_FAVORITES'					=> 'Kedvencek kezelése',
	'UCP_ARCADE_FAVORITES_DELETED'			=> 'Kedvenc játékok sikeresen törölve.',
	'UCP_ARCADE_FAVORITES_EXPLAIN'			=> 'Itt megtekintheted, kiemelheted és törölhetted a kedvenc játékaidat.',
	'UCP_ARCADE_FAVORITE_DELETED'			=> 'Kedvenc játék sikeresen törölve.',
	'UCP_ARCADE_GAME_OVER_ANIMATION'		=> 'Animáció lejátszása a játék végén',
	'UCP_ARCADE_GAME_OVER_ANIMATION_SOUND'	=> 'Animáció hang engedélyezése',
	'UCP_ARCADE_GAME_OVER_RANDOM_GAMES'		=> 'Véletlen játékok kijelzése a játék végén',
	'UCP_ARCADE_GAME_OVER_SOUND'			=> 'Game over hang lejátszása a játék végén',
	'UCP_ARCADE_NO_PERM_PM_LOSS_HIGHSCORE'	=> 'Nincs jogosultságod a privát üzenetek fogadására, trófea elvesztése esetén.',
	'UCP_ARCADE_POST'						=> 'Hozzászólás beállítások',
	'UCP_ARCADE_POST_EXPLAIN'				=> 'Hozzászólás beállítások személyre szabása.',
	'UCP_ARCADE_SELECTED_HIGHLIGHT'			=> 'Kijelöltek kiemelése',
	'UCP_ARCADE_SELECTED_HIGHLIGHT_REMOVE'	=> 'Kijelöltek kiemelésének eltávolítása',
	'UCP_ARCADE_SEND_PM_EXPLAIN'			=> 'Ha egy játékban megdöntik a rekordodat vagy ép szeretne egy felhasználó kihívni egy versenyre, akkor privát üzenet fog értesíteni.',
	'UCP_ARCADE_SETTINGS'					=> 'Beállítások kezelése',
	'UCP_ARCADE_SETTINGS_EXPLAIN'			=> 'Játékterem beállításainak személyre szabása.',
	'UCP_CAT_ARCADE'						=> 'Játékterem',
	'UCP_CHALLENGE_ENABLED'					=> 'Kihívás engedélyezése',
	'UCP_CHALLENGE_ENABLED_EXPLAIN'			=> 'Ha engedélyezed, akkor a felhasználók kihívhatnak a játékokban egy párbajra.',
));
