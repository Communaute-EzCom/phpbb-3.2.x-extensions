<?php
/**
*
* @package phpBB Arcade
* @version $Id: expired_challenge.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\cron;

class expired_challenge extends \phpbb\cron\task\base
{
	protected $db, $arcade, $arcade_config;

	public function __construct($db, $arcade, $arcade_config)
	{
		$this->db				= $db;
		$this->arcade			= $arcade;
		$this->arcade_config	= $arcade_config;
	}

	public function run()
	{
		$time = time();

		$sql = 'SELECT * FROM ' . ARCADE_CHALLENGE_TABLE . "
				WHERE challenge_time <= {$time}";
		$result = $this->db->sql_query($sql);

		$cids = array();
		while ($del = $this->db->sql_fetchrow($result))
		{
			$cids[] = $del['challenge_id'];

			$sql = 'DELETE FROM '. ARCADE_CHALLENGE_CHAMP_TABLE .'
					WHERE game_id = '. (int) $del['game_id'] .'
					AND champ_opponent_id = '. (int) $del['opponent_id'] .'
					AND champ_challenger_id = '. (int) $del['challenger_id'] .'
					AND champ_close <> ' . CHALLENGE_CLOSE;
			$this->db->sql_query($sql);

			if ($this->arcade->points()->data['installed'])
			{
				$challenger_total_cost	= floatval($del['challenge_points'] + $del['challenger_game_cost']);
				$opponent_total_cost	= floatval($del['challenge_points'] + $del['opponent_game_cost']);

				if ($challenger_total_cost > 0)
				{
					$this->arcade->points()->set('add', $del['challenger_id'], $challenger_total_cost);
				}

				if ($opponent_total_cost > 0)
				{
					$this->arcade->points()->set('add', $del['opponent_id'], $opponent_total_cost);
				}
			}
		}
		$this->db->sql_freeresult($result);

		if (count($cids))
		{
			$this->db->sql_query('DELETE FROM ' . ARCADE_CHALLENGE_TABLE . ' WHERE ' . $this->db->sql_in_set('challenge_id', $cids));
		}

		$this->arcade_config->set('challenge_exp_last_gc', $time, false);
	}

	public function is_runnable()
	{
		return !empty($this->arcade_config['time_gc']);
	}

	public function should_run()
	{
		return $this->arcade_config['challenge_exp_last_gc'] < time() - $this->arcade_config['time_gc'];
	}
}
