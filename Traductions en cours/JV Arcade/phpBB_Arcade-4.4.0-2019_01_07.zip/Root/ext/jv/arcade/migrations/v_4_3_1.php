<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_3_1.php 2121 2018-12-16 16:57:57Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_3_1 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\jv\arcade\migrations\v_4_3_0'
		);
	}

	public function update_data()
	{
		return array(
			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		global $user;

		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);

		$arcade_install->set_config(array(
			array('version', '4.3.1')
		));
	}
}
