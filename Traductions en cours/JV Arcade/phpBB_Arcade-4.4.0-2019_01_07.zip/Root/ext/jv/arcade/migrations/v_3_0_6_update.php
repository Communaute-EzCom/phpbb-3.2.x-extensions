<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_3_0_6_update.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

class v_3_0_6_update extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return (!empty($this->config['phpbb_arcade_version']) || empty($this->config['arcade_install'])) ? true : false;
	}

	static public function depends_on()
	{
		return array('\jv\arcade\migrations\v_4_0_RC1');
	}

	public function update_schema()
	{
		return array(
			'change_columns' => array("{$this->table_prefix}arcade_categories"	=> array('cat_password' => array('VCHAR_UNI', ''))),
			'add_columns'	 => array("{$this->table_prefix}arcade_menu"		=> array('quick_link'	=> array('BOOL', 0)))
		);
	}

	public function update_data()
	{
		return array(
			// install phpbb config
			array('config.add',		array('phpbb_arcade_version', '4.0.RC1')),
			array('custom',			array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		$sql = "UPDATE {$this->table_prefix}arcade_menu
				SET quick_link = 1
				WHERE menu_name = '" . $this->db->sql_escape('ARCADE_SEARCH_NEW_GAMES') . "'
					AND menu_type = 1";
		$this->sql_query($sql);

		$sql = "UPDATE {$this->table_prefix}arcade_menu
				SET params = '" . $this->db->sql_escape('i=-jv-arcade-ucp-manage_module&amp;mode=settings') . "'
				WHERE menu_name = '" . $this->db->sql_escape('ARCADE_GLOBAL') . "'
					AND menu_type = 1
					AND menu_page = 'ucp'";
		$this->sql_query($sql);

		$sql = "UPDATE {$this->table_prefix}arcade_menu
				SET params = '" . $this->db->sql_escape('i=-jv-arcade-ucp-manage_module&amp;mode=post') . "'
				WHERE menu_name = '" . $this->db->sql_escape('POST') . "'
					AND menu_type = 1
					AND menu_page = 'ucp'";
		$this->sql_query($sql);

		$sql = "UPDATE {$this->table_prefix}arcade_menu
				SET params = '" . $this->db->sql_escape('i=-jv-arcade-ucp-manage_module&amp;mode=favorites') . "'
				WHERE menu_name = '" . $this->db->sql_escape('ARCADE_GAME_FAVS') . "'
					AND menu_type = 1
					AND menu_page = 'ucp'";
		$this->sql_query($sql);

		// update all arcade modules
		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\main_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MAIN_INDEX') . "'
		AND module_class = 'acp'
		AND module_mode = 'main'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_GENERAL') . "'
		AND module_class = 'acp'
		AND module_mode = 'settings'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_GAME') . "'
		AND module_class = 'acp'
		AND module_mode = 'game'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_CHALLENGE') . "'
		AND module_class = 'acp'
		AND module_mode = 'challenge'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_TOUR') . "'
		AND module_class = 'acp'
		AND module_mode = 'tournament'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_FEATURE') . "'
		AND module_class = 'acp'
		AND module_mode = 'feature'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_ARCADE_PAGE') . "'
		AND module_class = 'acp'
		AND module_mode = 'apage'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_CHALLENGE_PAGE') . "'
		AND module_class = 'acp'
		AND module_mode = 'cpage'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_TOUR_PAGE') . "'
		AND module_class = 'acp'
		AND module_mode = 'tpage'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_PATH') . "'
		AND module_class = 'acp'
		AND module_mode = 'path'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\settings_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade && acl_a_arcade_settings') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_SETTINGS_LOAD') . "'
		AND module_class = 'acp'
		AND module_mode = 'load'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\main_manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_menu') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MANAGE_MENU') . "'
		AND module_class = 'acp'
		AND module_mode = 'menu'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_cat') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MANAGE_CATEGORIES') . "'
		AND module_class = 'acp'
		AND module_mode = 'category'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_game') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MANAGE_GAMES') . "'
		AND module_class = 'acp'
		AND module_mode = 'games'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_user') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MANAGE_USERS') . "'
		AND module_class = 'acp'
		AND module_mode = 'users'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_user') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MANAGE_CHALLENGES') . "'
		AND module_class = 'acp'
		AND module_mode = 'challenges'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_tour') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MANAGE_TOUR') . "'
		AND module_class = 'acp'
		AND module_mode = 'tournament'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\main_manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_announce') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MANAGE_ANNOUNCE') . "'
		AND module_class = 'acp'
		AND module_mode = 'announce'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\main_manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_ranks') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_MANAGE_RANKS') . "'
		AND module_class = 'acp'
		AND module_mode = 'ranks'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\plugin_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_plugin') . "', module_display = 0
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_PLUGIN_INSTALL') . "'
		AND module_class = 'acp'
		AND module_mode = 'install'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\plugin_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_plugin') . "', module_display = 0
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_PLUGIN_MANAGE') . "'
		AND module_class = 'acp'
		AND module_mode = 'manage'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\games_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_game') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_ADD_GAMES') . "'
		AND module_class = 'acp'
		AND module_mode = 'add_games'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\games_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_game') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_UNPACK_GAMES') . "'
		AND module_class = 'acp'
		AND module_mode = 'unpack_games'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\games_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_backup') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_BACKUP_GAMES') . "'
		AND module_class = 'acp'
		AND module_mode = 'backup_games'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\games_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_game') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_DOWNLOADS_GAMES') . "'
		AND module_class = 'acp'
		AND module_mode = 'downloads_games'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\utilities_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_utilities') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_UTILITIES_REPORTS') . "'
		AND module_class = 'acp'
		AND module_mode = 'reports'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\utilities_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && (acl_a_arcade || acl_a_arcade_user)') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_UTILITIES_USERS_BANNED') . "'
		AND module_class = 'acp'
		AND module_mode = 'users_banned'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\utilities_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_utilities') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_UTILITIES_DOWNLOAD_STATS') . "'
		AND module_class = 'acp'
		AND module_mode = 'download_stats'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\utilities_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_utilities') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_UTILITIES_CREATE_INSTALL') . "'
		AND module_class = 'acp'
		AND module_mode = 'create_install'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\utilities_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_UTILITIES_USER_GUIDE') . "'
		AND module_class = 'acp'
		AND module_mode = 'user_guide'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\logs_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_viewlogs') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_LOGS_ADMIN') . "'
		AND module_class = 'acp'
		AND module_mode = 'admin'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\logs_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_viewlogs') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_LOGS_MOD') . "'
		AND module_class = 'acp'
		AND module_mode = 'mod'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\logs_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_viewlogs') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_LOGS_USERS') . "'
		AND module_class = 'acp'
		AND module_mode = 'users'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\logs_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_arcade_viewlogs') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_LOGS_CRITICAL') . "'
		AND module_class = 'acp'
		AND module_mode = 'critical'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\permission_roles_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_cauth && acl_a_roles') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_CAT_ROLES') . "'
		AND module_class = 'acp'
		AND module_mode = 'cat_roles'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\permissions_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_cauth && (acl_a_authusers || acl_a_authgroups)') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_CATEGORY_PERMISSIONS') . "'
		AND module_class = 'acp'
		AND module_mode = 'setting_category_local'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\permissions_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_authusers && acl_a_cauth') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_USERS_CATEGORY_PERMISSIONS') . "'
		AND module_class = 'acp'
		AND module_mode = 'setting_user_local'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\permissions_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_authgroups && acl_a_cauth') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_GROUPS_CATEGORY_PERMISSIONS') . "'
		AND module_class = 'acp'
		AND module_mode = 'setting_group_local'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\permissions_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_cauth && acl_a_authusers && acl_a_authgroups') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_CATEGORY_PERMISSIONS_COPY') . "'
		AND module_class = 'acp'
		AND module_mode = 'setting_category_copy'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\permissions_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_viewauth') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_ARCADE_PERMISSION_TRACE') . "'
		AND module_class = 'acp'
		AND module_mode = 'trace'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\acp\permissions_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_a_viewauth') . "'
		WHERE module_langname = '" . $this->db->sql_escape('ACP_VIEW_ARCADE_CATEGORY_PERMISSIONS') . "'
		AND module_class = 'acp'
		AND module_mode = 'view_category_local'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\mcp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_u_arcade && acl_m_arcade_game') . "'
		WHERE module_langname = '" . $this->db->sql_escape('MCP_ARCADE_MANAGE_GAMES') . "'
		AND module_class = 'mcp'
		AND module_mode = 'games'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\mcp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_u_arcade && acl_u_arcade_tour && acl_m_arcade_tour') . "'
		WHERE module_langname = '" . $this->db->sql_escape('MCP_ARCADE_MANAGE_TOUR') . "'
		AND module_class = 'mcp'
		AND module_mode = 'tournament'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\ucp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_u_arcade') . "'
		WHERE module_langname = '" . $this->db->sql_escape('UCP_ARCADE_SETTINGS') . "'
		AND module_class = 'ucp'
		AND module_mode = 'settings'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\ucp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_u_arcade') . "'
		WHERE module_langname = '" . $this->db->sql_escape('UCP_ARCADE_POST') . "'
		AND module_class = 'ucp'
		AND module_mode = 'post'";
		$this->sql_query($sql);

		$sql = 'UPDATE ' . MODULES_TABLE . "
		SET module_basename = '" . $this->db->sql_escape('\jv\arcade\ucp\manage_module') . "', module_auth = '" . $this->db->sql_escape('ext_jv/arcade && acl_u_arcade && acl_u_arcade_favorites') . "'
		WHERE module_langname = '" . $this->db->sql_escape('UCP_ARCADE_FAVORITES') . "'
		AND module_class = 'ucp'
		AND module_mode = 'favorites'";
		$this->sql_query($sql);

		$sql = "UPDATE {$this->table_prefix}arcade_config
				SET config_value = '" . $this->db->sql_escape('4.0.RC1') . "'
				WHERE config_name = '" . $this->db->sql_escape('version') . "'";
		$this->sql_query($sql);

		$sql = 'DELETE FROM ' . CONFIG_TABLE . "
				WHERE config_name = '" . $this->db->sql_escape('arcade_install') . "'";
		$this->sql_query($sql);
	}
}
