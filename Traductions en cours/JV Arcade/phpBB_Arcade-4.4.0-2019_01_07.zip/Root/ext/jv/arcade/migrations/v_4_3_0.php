<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_3_0.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_3_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\phpbb\db\migration\data\v32x\v323',
			'\jv\arcade\migrations\v_4_2_7'
		);
	}

	public function update_data()
	{
		return array(
			array('if', array(
				array('module.exists', array('acp', 'ACP_CAT_ARCADE_SETTINGS', 'ACP_ARCADE_SETTINGS_ARCADE_PAGE')),
				array('module.remove', array('acp', 'ACP_CAT_ARCADE_SETTINGS', 'ACP_ARCADE_SETTINGS_ARCADE_PAGE'))
			)),
			array('if', array(
				array('module.exists', array('acp', 'ACP_CAT_ARCADE_SETTINGS', 'ACP_ARCADE_SETTINGS_CHALLENGE_PAGE')),
				array('module.remove', array('acp', 'ACP_CAT_ARCADE_SETTINGS', 'ACP_ARCADE_SETTINGS_CHALLENGE_PAGE'))
			)),
			array('if', array(
				array('module.exists', array('acp', 'ACP_CAT_ARCADE_SETTINGS', 'ACP_ARCADE_SETTINGS_TOUR_PAGE')),
				array('module.remove', array('acp', 'ACP_CAT_ARCADE_SETTINGS', 'ACP_ARCADE_SETTINGS_TOUR_PAGE'))
			)),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_SETTINGS', array(
					'module_basename'	=> '\jv\arcade\acp\settings_module',
					'modes'				=> array('page')
				)
			)),
			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		global $user;

		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);

		$arcade_install->delete_config(array(
			array('arcade_leaders'),
			array('arcade_leaders_header'),
			array('challenge_leaders'),
			array('challenge_leaders_header'),
			array('tour_leaders'),
			array('tour_leaders_header'),
			array('challenge_top_games_header'),
			array('challenge_latest_winners'),
			array('challenge_most_popular'),
			array('challenge_least_popular'),
			array('challenge_most_played_users'),
			array('challenge_least_played_users'),
			array('tour_top_games'),
			array('tour_latest_winners'),
			array('tour_most_popular'),
			array('tour_least_popular'),
			array('tour_most_played_users'),
			array('tour_least_played_users'),
			array('challenge_welcome_index'),
			array('tour_welcome_index'),
			array('challenge_welcome_stats'),
			array('tour_welcome_stats'),
			array('challenge_welcome_detailed_stats'),
			array('tournament_welcome_detailed_stats')
		));

		$arcade_install->set_config(array(
			array('auto_reset_score_top', 10),
			array('auto_reset_score_type', 0),
			array('auto_reset_score_time', 0, false),
			array('detailed_stats_icon', 1),
			array('detailed_stats_icon_size', 20),
			array('game_popup_icon_size', 15),
			array('latest_highscores_avatar', 1),
			array('latest_highscores_avatar_size', 20),
			array('leaders', 3),
			array('leaders_avatar', 1),
			array('leaders_avatar_size', 30),
			array('leaders_stats', 5),
			array('new_games_style', 1),
			array('newest_games_img', 1),
			array('newest_games_img_size', 20),
			array('search_cat_stats', 1),
			array('search_download', 0),
			array('stats_icon', 1),
			array('stats_icon_size', 20),
			array('welcome_cat_stats', 1),
			array('welcome_download', 0),
			array('welcome_search', 0),
			array('auto_reset_score', 0),
			array('version', '4.3.0')
		));
	}
}
