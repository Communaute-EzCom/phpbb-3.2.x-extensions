<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_2_0.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_2_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\phpbb\db\migration\data\v32x\v322',
			'\jv\arcade\migrations\v_4_1_0'
		);
	}

	public function update_schema()
	{
		return array(
			'add_columns'	=> array(
				"{$this->table_prefix}arcade_games" => array('game_save_type' => array('TINT:1', 0))
			),
			'drop_columns'	=> array(
				"{$this->table_prefix}arcade_sessions" => array('game_type')
			),
			'drop_keys'		=> array("{$this->table_prefix}arcade_games" => array('game_type')),
			'add_index'		=> array("{$this->table_prefix}arcade_games" => array('save_type' => array('game_save_type')))
		);
	}

	public function update_data()
	{
		return array(
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_SETTINGS', array(
					'module_basename'	=> '\jv\arcade\acp\ext_module',
					'modes'				=> array('settings')
				)
			)),
			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		global $user;

		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);
		$arcade_install->add_bbcodes($arcade_install->data->bbcodes());

		$sql = "SELECT game_id, game_type, game_save_type
				FROM {$this->table_prefix}arcade_games";
		$result = $this->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (!$row['game_save_type'])
			{
				$sql = "UPDATE {$this->table_prefix}arcade_games
						SET game_save_type = " . (int) $row['game_type'] . ", game_type = 1
						WHERE game_id = " . (int) $row['game_id'];
				$this->sql_query($sql);
			}
		}
		$this->db->sql_freeresult($result);

		switch ($this->db->get_sql_layer())
		{
			case 'sqlite3':
				$this->db->sql_query('DELETE FROM ' . $this->table_prefix . 'arcade_logs');
			break;

			default:
				$this->db->sql_query('TRUNCATE TABLE ' . $this->table_prefix . 'arcade_logs');
			break;
		}

		$arcade_install->delete_config(array(
			array('arcade_flash_intro'),
			array('arcade_flash_header_label'),
			array('arcade_flash_logo'),
			array('arcade_flash_highscores'),
			array('b3portal_ignstats'),
			array('disable_b3_arcade_modules'),
			array('b3portal_disable'),
			array('hide_b3arcade')
		));

		$arcade_install->set_config(array(
			array('display_game_save_type', 1),
			array('protect_game_img', 0),
			array('protect_phpbbarcade', 0),
			array('protect_amod', 0),
			array('protect_v3arcade', 0),
			array('activation_key', ''),
			array('download_system', 1),
			array('flash_version', '28.0.0.0'),
			array('version', '4.2.0')
		));
	}
}
