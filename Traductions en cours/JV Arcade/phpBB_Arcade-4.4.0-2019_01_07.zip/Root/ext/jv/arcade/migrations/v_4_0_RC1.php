<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_0_RC1.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_0_RC1 extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return $this->db_tools->sql_table_exists("{$this->table_prefix}arcade_config");
	}

	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v310\extensions');
	}

	public function update_schema()
	{
		$schema = new \jv\arcade\inc\install\schema();
		return array('add_tables' => $schema->data($this->table_prefix));
	}

	public function revert_schema()
	{
		$schema = new \jv\arcade\inc\install\schema();
		return array('drop_tables' => array_keys($schema->data($this->table_prefix)));
	}

	public function update_data()
	{
		$sql = "SELECT role_name
				FROM {$this->table_prefix}acl_roles";
		$result = $this->sql_query($sql);
		$roles = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$roles[] = $row['role_name'];
		}
		$this->db->sql_freeresult($result);

		return array(
			// install phpbb config
			array('config.add', array('phpbb_arcade_version', '4.0.RC1')),

			// install acp global permissions
			array('permission.add', array('a_arcade')),
			array('permission.add', array('a_arcade_menu')),
			array('permission.add', array('a_arcade_announce')),
			array('permission.add', array('a_arcade_backup')),
			array('permission.add', array('a_cauth')),
			array('permission.add', array('a_arcade_settings')),
			array('permission.add', array('a_arcade_points_settings')),
			array('permission.add', array('a_arcade_game')),
			array('permission.add', array('a_arcade_delete_game')),
			array('permission.add', array('a_arcade_cat')),
			array('permission.add', array('a_arcade_delete_cat')),
			array('permission.add', array('a_arcade_plugin')),
			array('permission.add', array('a_arcade_plugin_remove')),
			array('permission.add', array('a_arcade_user')),
			array('permission.add', array('a_arcade_utilities')),
			array('permission.add', array('a_arcade_viewlogs')),
			array('permission.add', array('a_arcade_clearlogs')),
			array('permission.add', array('a_arcade_tour')),
			array('permission.add', array('a_arcade_reset_game')),
			array('permission.add', array('a_arcade_delete_tour')),
			array('permission.add', array('a_arcade_ranks')),
			// install mcp global permissions
			array('permission.add', array('m_arcade_game')),
			array('permission.add', array('m_arcade_reset_game')),
			array('permission.add', array('m_arcade_change_gamename')),
			array('permission.add', array('m_arcade_tour')),
			array('permission.add', array('m_arcade_tour_reward')),
			// install ucp global permissions
			array('permission.add', array('u_arcade')),
			array('permission.add', array('u_arcade_challenge')),
			array('permission.add', array('u_arcade_download')),
			array('permission.add', array('u_arcade_favorites')),
			array('permission.add', array('u_arcade_ignoreflood_search')),
			array('permission.add', array('u_arcade_popup')),
			array('permission.add', array('u_arcade_pm')),
			array('permission.add', array('u_arcade_resolution')),
			array('permission.add', array('u_arcade_search')),
			array('permission.add', array('u_arcade_view_whoisplaying')),
			array('permission.add', array('u_arcade_viewstats')),
			array('permission.add', array('u_arcade_tour')),
			// install admin permissions set
			array('if', array(
				(in_array('ROLE_ADMIN_FULL', $roles)),
				array('permission.permission_set', array('ROLE_ADMIN_FULL', array('a_arcade', 'a_arcade_menu', 'a_arcade_announce', 'a_arcade_backup', 'a_cauth', 'a_arcade_settings', 'a_arcade_points_settings', 'a_arcade_game', 'a_arcade_delete_game', 'a_arcade_cat', 'a_arcade_delete_cat', 'a_arcade_user', 'a_arcade_utilities', 'a_arcade_viewlogs', 'a_arcade_clearlogs', 'a_arcade_tour', 'a_arcade_reset_game', 'a_arcade_delete_tour', 'a_arcade_ranks')))
			)),
			array('if', array(
				(in_array('ROLE_ADMIN_STANDARD', $roles)),
				array('permission.permission_set', array('ROLE_ADMIN_STANDARD', array('a_arcade', 'a_arcade_backup', 'a_cauth', 'a_arcade_settings', 'a_arcade_points_settings', 'a_arcade_game', 'a_arcade_delete_game', 'a_arcade_cat', 'a_arcade_delete_cat', 'a_arcade_user', 'a_arcade_utilities', 'a_arcade_viewlogs', 'a_arcade_clearlogs', 'a_arcade_tour', 'a_arcade_reset_game', 'a_arcade_delete_tour')))
			)),
			array('if', array(
				(in_array('ROLE_ADMIN_FORUM', $roles)),
				array('permission.permission_set', array('ROLE_ADMIN_FORUM', array('a_arcade', 'a_cauth', 'a_arcade_settings', 'a_arcade_game', 'a_arcade_cat', 'a_arcade_user', 'a_arcade_utilities', 'a_arcade_viewlogs')))
			)),
			array('if', array(
				(in_array('ROLE_ADMIN_USERGROUP', $roles)),
				array('permission.permission_set', array('ROLE_ADMIN_USERGROUP', array('a_arcade', 'a_cauth', 'a_arcade_settings', 'a_arcade_game', 'a_arcade_cat', 'a_arcade_user', 'a_arcade_utilities', 'a_arcade_viewlogs')))
			)),
			// install mod permissions set
			array('if', array(
				(in_array('ROLE_MOD_FULL', $roles)),
				array('permission.permission_set', array('ROLE_MOD_FULL', array('m_arcade_game', 'm_arcade_reset_game', 'm_arcade_change_gamename', 'm_arcade_tour', 'm_arcade_tour_reward')))
			)),
			array('if', array(
				(in_array('ROLE_MOD_STANDARD', $roles)),
				array('permission.permission_set', array('ROLE_MOD_STANDARD', array('m_arcade_game', 'm_arcade_tour')))
			)),
			// install user permissions set
			array('if', array(
				(in_array('ROLE_USER_FULL', $roles)),
				array('permission.permission_set', array('ROLE_USER_FULL', array('u_arcade', 'u_arcade_challenge', 'u_arcade_download', 'u_arcade_favorites', 'u_arcade_ignoreflood_search', 'u_arcade_popup', 'u_arcade_pm', 'u_arcade_resolution', 'u_arcade_search', 'u_arcade_view_whoisplaying', 'u_arcade_viewstats', 'u_arcade_tour')))
			)),
			array('if', array(
				(in_array('ROLE_USER_STANDARD', $roles)),
				array('permission.permission_set', array('ROLE_USER_STANDARD', array('u_arcade', 'u_arcade_challenge', 'u_arcade_download', 'u_arcade_favorites', 'u_arcade_ignoreflood_search', 'u_arcade_popup', 'u_arcade_pm', 'u_arcade_resolution', 'u_arcade_search', 'u_arcade_view_whoisplaying', 'u_arcade_viewstats', 'u_arcade_tour')))
			)),
			array('if', array(
				(in_array('ROLE_USER_LIMITED', $roles)),
				array('permission.permission_set', array('ROLE_USER_LIMITED', array('u_arcade', 'u_arcade_challenge', 'u_arcade_download', 'u_arcade_favorites', 'u_arcade_popup', 'u_arcade_pm', 'u_arcade_resolution', 'u_arcade_search', 'u_arcade_view_whoisplaying', 'u_arcade_viewstats', 'u_arcade_tour')))
			)),
			array('if', array(
				(in_array('ROLE_USER_NOPM', $roles)),
				array('permission.permission_set', array('ROLE_USER_NOPM', array('u_arcade', 'u_arcade_challenge', 'u_arcade_download', 'u_arcade_favorites', 'u_arcade_popup', 'u_arcade_resolution', 'u_arcade_search', 'u_arcade_view_whoisplaying', 'u_arcade_viewstats', 'u_arcade_tour')))
			)),
			array('if', array(
				(in_array('ROLE_USER_NOAVATAR', $roles)),
				array('permission.permission_set', array('ROLE_USER_NOAVATAR', array('u_arcade', 'u_arcade_challenge', 'u_arcade_download', 'u_arcade_favorites', 'u_arcade_popup', 'u_arcade_pm', 'u_arcade_resolution', 'u_arcade_search', 'u_arcade_view_whoisplaying', 'u_arcade_viewstats', 'u_arcade_tour')))
			)),

			array('if', array(
				(in_array('ROLE_USER_NEW_MEMBER', $roles)),
				array('permission.permission_set', array('ROLE_USER_NEW_MEMBER', array('u_arcade', 'u_arcade_challenge', 'u_arcade_pm', 'u_arcade_search', 'u_arcade_view_whoisplaying', 'u_arcade_viewstats', 'u_arcade_tour')))
			)),
			// install ucp modules
			array('module.add', array('ucp', 0, 'UCP_CAT_ARCADE')),
			array('module.add', array(
				'ucp', 'UCP_CAT_ARCADE', array(
					'module_basename'	=> '\jv\arcade\ucp\manage_module',
					'modes'				=> array('settings', 'post', 'favorites')
				)
			)),
			// install mcp modules
			array('module.add', array('mcp', 0, 'MCP_CAT_ARCADE')),
			array('module.add', array(
				'mcp', 'MCP_CAT_ARCADE', array(
					'module_basename'	=> '\jv\arcade\mcp\manage_module',
					'modes'				=> array('games', 'tournament')
				)
			)),
			// install acp modules
			array('module.add', array('acp', 0, 'ACP_CAT_ARCADE')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE', array(
					'module_basename'	=> '\jv\arcade\acp\main_module',
					'modes'				=> array('main')
				)
			)),
			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_SETTINGS')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_SETTINGS', array(
					'module_basename'	=> '\jv\arcade\acp\settings_module',
					'modes'				=> array('settings', 'game', 'challenge', 'tournament', 'feature', 'apage', 'cpage', 'tpage', 'path', 'load')
				)
			)),
			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_MANAGE')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_MANAGE', array(
					'module_basename'	=> '\jv\arcade\acp\main_manage_module',
					'modes'				=> array('menu')
				)
			)),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_MANAGE', array(
					'module_basename'	=> '\jv\arcade\acp\manage_module',
					'modes'				=> array('category', 'games', 'users', 'challenges', 'tournament')
				)
			)),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_MANAGE', array(
					'module_basename'	=> '\jv\arcade\acp\main_manage_module',
					'modes'				=> array('announce', 'ranks')
				)
			)),

			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_PLUGIN')),
			array('module.add', array('acp', 'ACP_CAT_ARCADE_PLUGIN', 'ACP_ARCADE_PLUGIN_INSTALL')),
			array('module.add', array('acp', 'ACP_CAT_ARCADE_PLUGIN', 'ACP_ARCADE_PLUGIN_MANAGE')),

			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_GAMES_FEATURE')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_GAMES_FEATURE', array(
					'module_basename'	=> '\jv\arcade\acp\games_module',
					'modes'				=> array('add_games', 'unpack_games', 'backup_games', 'downloads_games')
				)
			)),
			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_UTILITIES')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_UTILITIES', array(
					'module_basename'	=> '\jv\arcade\acp\utilities_module',
					'modes'				=> array('reports', 'users_banned', 'download_stats', 'create_install', 'user_guide')
				)
			)),
			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_LOGS')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_LOGS', array(
					'module_basename'	=> '\jv\arcade\acp\logs_module',
					'modes'				=> array('admin', 'mod', 'users', 'critical')
				)
			)),
			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_PERMISSION_ROLES')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_PERMISSION_ROLES', array(
					'module_basename'	=> '\jv\arcade\acp\permission_roles_module',
					'modes'				=> array('cat_roles')
				)
			)),
			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_PERMISSIONS')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_PERMISSIONS', array(
					'module_basename'	=> '\jv\arcade\acp\permissions_module',
					'modes'				=> array('setting_category_local', 'setting_category_copy', 'setting_user_local', 'setting_group_local')
				)
			)),
			array('module.add', array('acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_PERMISSION_MASKS')),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_PERMISSION_MASKS', array(
					'module_basename'	=> '\jv\arcade\acp\permissions_module',
					'modes'				=> array('trace', 'view_category_local')
				)
			)),
			array('custom', array(array($this, 'arcade_install'))),
		);
	}

	public function arcade_install()
	{
		global $user;
		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);

		$arcade_install->set_config($arcade_install->data->configs());
		$arcade_install->permission_add($arcade_install->data->arcade_permission());
		$arcade_install->permission_role_add($arcade_install->data->arcade_roles());
		$arcade_install->permission_set($arcade_install->data->arcade_roles_set());

		$sql = "SELECT menu_id
				FROM {$this->table_prefix}arcade_menu
				WHERE menu_id > 0";
		$result = $this->sql_query($sql);
		$menu_id = (int) $this->db->sql_fetchfield('menu_id');
		$this->db->sql_freeresult($result);

		if (!$menu_id)
		{
			$arcade_install->add_menu($arcade_install->data->menu());
		}
	}
}
