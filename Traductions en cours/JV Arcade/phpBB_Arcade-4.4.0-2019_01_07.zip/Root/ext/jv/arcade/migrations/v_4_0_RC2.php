<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_0_RC2.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_0_RC2 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\arcade\migrations\v_4_0_RC1');
	}

	public function update_schema()
	{
		return array(
			'add_columns'	=> array(
				"{$this->table_prefix}arcade_menu"		=> array('menu_top' => array('VCHAR:50', '')),
				"{$this->table_prefix}arcade_sessions"	=> array('post_data' => array('MTEXT', ''))
			),
			'drop_columns'	=> array("{$this->table_prefix}arcade_menu" => array('top'))
		);
	}

	public function update_data()
	{
		$sql = "SELECT role_name
				FROM {$this->table_prefix}acl_roles";
		$result = $this->sql_query($sql);
		$phpbb_roles = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$phpbb_roles[] = $row['role_name'];
		}
		$this->db->sql_freeresult($result);

		return array(
			// install acp global permissions
			array('permission.add', array('a_arcade_install')),
			// install admin permissions set
			array('if', array(
				(in_array('ROLE_ADMIN_FULL', $phpbb_roles)),
				array('permission.permission_set', array('ROLE_ADMIN_FULL', array('a_arcade_install')))
			)),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE', 'ACP_CAT_ARCADE_INSTALL_FEATURES'
			)),
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_INSTALL_FEATURES', array(
					'module_basename'	=> '\jv\arcade\acp\install_module',
					'modes'				=> array('install_verify', 'update_game_data', 'convert_game_ins_file')
				)
			)),

			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		global $user;

		$menu_top = array(
			'ARCADE_STATS'				=> array('arcade' => 1),
			'ARCADE_PLAYED_GAMES'		=> array('arcade' => 1),
			'ARCADE_NOT_PLAYED_GAMES'	=> array('arcade' => 1),
			'ARCADE_PLAYED_USERS'		=> array('arcade' => 1),
			'ARCADE_HIGHSCORES'			=> array('arcade' => 1),
			'ARCADE_SUPER_CHAMPIONS'	=> array('arcade' => 1),
			'ARCADE_RATED_GAMES'		=> array('arcade' => 1),
			'ARCADE_GAMES_JACKPOTS'		=> array('arcade' => 1),
			'ARCADE_WINNERS'			=> array('arcade' => 1),
			'ARCADE_GAME_FAVS'			=> array('arcade' => 1, 'ucp' => 'tabs'),
			'FAQ'						=> array('faq' => 'faqlinks'),
			'ARCADE_GLOBAL'				=> array('ucp' => 'tabs'),
			'POST'						=> array('ucp' => 'tabs'),
			'ARCADE_SEARCH_NEW_GAMES'	=> array('arcade' => 'top_games'),
			'ARCADE_MY_FAVORITE_GAMES'	=> array('arcade' => 'top_games'),
			'ARCADE_FINISHED_TOURS'		=> array('arcade' => 'tour_top'),
			'ARCADE_MY_STATS'			=> array('arcade' => 'userbox')
		);

		foreach ($menu_top as $menu_name => $data)
		{
			foreach ($data as $menu_page => $top)
			{
				$sql = "UPDATE {$this->table_prefix}arcade_menu
						SET menu_top = '" . $this->db->sql_escape($top) . "'
						WHERE menu_name = '" . $this->db->sql_escape($menu_name) . "'
							AND menu_type = 1
							AND menu_page = '" . $this->db->sql_escape($menu_page) . "'";
				$this->sql_query($sql);
			}
		}

		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);
		$arcade_install->add_bbcodes($arcade_install->data->bbcodes());

		$arcade_install->set_config(array(
			array('b3portal_ignstats', 0),
			array('version', '4.0.RC2'),
			array('flash_version', '18.0.0.232')
		));

		$arcade_install->delete_config('cm_currency_id');

		$sql = "DELETE FROM {$this->table_prefix}config
				WHERE config_name = '" . $this->db->sql_escape('phpbb_arcade_version') . "'";
		$this->sql_query($sql);
	}
}
