<?php
/**
*
* @package phpBB Arcade
* @version $Id: getHiScores.php 2110 2018-11-28 08:07:20Z KillBill $
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

define('IN_PHPBB', true);
define('IN_PHPBB_ARCADE', true);

$str='';
$x=1;

while ($x <= 10)
{
	$str.= "&ibproName$x=Name$x&ibproScore$x=$x";
	$x++;
}

$str.= '&EOS=1&blah';
echo $str;
