<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox_b3portal\modules;

class shoutbox extends \board3\portal\modules\module_base
{
	public $columns		= 21;
	public $name		= 'JV_SHOUTBOX_PORTAL_MODULE';
	public $image_src	= '';
	public $language	= array(
		'vendor'	=> 'jv/shoutbox_b3portal',
		'file'		=> 'common'
	);

	protected $auth, $config, $jv_shoutbox;

	public function __construct($auth, $config, $jv_shoutbox = null)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->jv_shoutbox = $jv_shoutbox;
	}

	public function get_template_center($module_id)
	{
		if ($this->jv_shoutbox && $this->config['jv_shoutbox_enable'] && $this->auth->acl_get('u_jv_shoutbox_view'))
		{
			$this->jv_shoutbox->active_page('portal');
			$this->jv_shoutbox->display();

			return '@jv_shoutbox/shoutbox.html';
		}
	}

	public function get_template_acp($module_id)
	{
		return array(
			'title'	=> 'MODULE_OPTIONS',
			'vars'	=> array(
				'legend1' => 'ACP_PORTAL_GENERAL_INFO',
			),
		);
	}

	public function install($module_id)
	{
	}

	public function uninstall($module_id, $db)
	{
	}
}
