<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox_b3portal\migrations;

class v_1_0_2 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\shoutbox_b3portal\migrations\v_1_0_1');
	}

	public function revert_data()
	{
		if ($this->db_tools->sql_table_exists("{$this->table_prefix}portal_modules"))
		{
			$columns = $this->db_tools->sql_list_columns("{$this->table_prefix}portal_modules");

			if (isset($columns['module_id']) && isset($columns['module_classname']))
			{
				$sql = "DELETE FROM {$this->table_prefix}portal_modules
						WHERE module_classname " . $this->db->sql_like_expression('\\\jv\\\shoutbox_b3portal' . $this->db->get_any_char());
				$this->sql_query($sql);
			}
		}

		return array();
	}
}
