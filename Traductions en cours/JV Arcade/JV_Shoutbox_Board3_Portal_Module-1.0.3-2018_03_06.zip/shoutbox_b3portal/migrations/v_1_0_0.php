<?php
/**
*
* @package JV Shoutbox
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\shoutbox_b3portal\migrations;

class v_1_0_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\phpbb\db\migration\data\v310\extensions',
			'\phpbb\db\migration\data\v31x\v316',
			'\board3\portal\migrations\v210',
			'\jv\shoutbox\migrations\v_1_0_0_RC2'
		);
	}
}
