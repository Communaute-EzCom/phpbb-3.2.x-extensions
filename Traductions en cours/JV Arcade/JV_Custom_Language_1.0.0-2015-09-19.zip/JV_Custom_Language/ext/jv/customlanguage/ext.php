<?php
/**
*
* @package JV Custom Language
* @version $Id$
* @author 2011-2015 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2015 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\customlanguage;

class ext extends \phpbb\extension\base
{
}
