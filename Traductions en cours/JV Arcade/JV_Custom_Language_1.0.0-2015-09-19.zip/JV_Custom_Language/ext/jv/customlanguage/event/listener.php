<?php
/**
*
* @package JV Custom Language
* @version $Id$
* @author 2011-2015 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2015 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\customlanguage\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup' => 'language'
		);
	}

	public function language($event)
	{
		$event['lang_set_ext'] = array_merge($event['lang_set_ext'], array(
			array(
				'ext_name' => 'jv/customlanguage',
				'lang_set' => 'common'
			)
		));
	}
}
