<?php
/**
*
* @package JV Add System Bot
* @version $Id$
* @author 2011-2015 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2015 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\addsystembot\migrations;

class v_1_0_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v310\extensions');
	}

	public function update_data()
	{
		if (!isset($this->config['jv_system_bot_user_id']))
		{
			$bot_name = 'System [Bot]';

			$sql = 'SELECT user_id
					FROM ' . USERS_TABLE . "
					WHERE username_clean = '" . $this->db->sql_escape(utf8_clean_string($bot_name)) . "'";
			$result = $this->sql_query($sql);
			$user_id = (int) $this->db->sql_fetchfield('user_id');
			$this->db->sql_freeresult($result);

			if ($user_id)
			{
				trigger_error('The migration can not be executed, because the System [Bot] user already exists.', E_USER_WARNING);
			}

			$sql = 'SELECT group_id, group_colour FROM ' . GROUPS_TABLE . " WHERE group_name = 'BOTS'";
			$result = $this->sql_query($sql);
			$bot = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			$group_id = (!empty($bot['group_id'])) ? (int) $bot['group_id'] : 0;

			if (!$group_id)
			{
				trigger_error('The migration can not be executed, because the Bot group was not found.', E_USER_WARNING);
			}

			$system_bot_row = array(
				'user_type'					=> USER_IGNORE,
				'group_id'					=> $group_id,
				'username'					=> $bot_name,
				'user_password'				=> '',
				'user_colour'				=> $bot['group_colour'],
				'user_email'				=> '',
				'user_email_hash'			=> 0,
				'user_allow_pm'				=> 0,
				'user_allow_massemail'		=> 0,
			);

			$phpbb_default_columns = array(
				'user_id', 'user_permissions', 'user_perm_from', 'user_ip', 'user_regdate', 'username_clean', 'user_passchg', 'user_birthday',
				'user_lastvisit', 'user_lastmark', 'user_lastpost_time', 'user_lastpage', 'user_last_confirm_key', 'user_last_search', 'user_warnings',
				'user_last_warning', 'user_login_attempts', 'user_inactive_reason', 'user_inactive_time', 'user_posts', 'user_lang', 'user_timezone',
				'user_dateformat', 'user_style', 'user_rank', 'user_new_privmsg', 'user_unread_privmsg', 'user_last_privmsg', 'user_message_rules',
				'user_full_folder', 'user_emailtime', 'user_topic_show_days', 'user_topic_sortby_type', 'user_topic_sortby_dir', 'user_post_show_days',
				'user_post_sortby_type', 'user_post_sortby_dir', 'user_notify', 'user_notify_pm', 'user_notify_type', 'user_allow_viewonline',
				'user_allow_viewemail', 'user_options', 'user_avatar', 'user_avatar_type', 'user_avatar_width', 'user_avatar_height', 'user_sig',
				'user_sig_bbcode_uid', 'user_sig_bbcode_bitfield', 'user_jabber', 'user_actkey', 'user_newpasswd', 'user_form_salt', 'user_new',
				'user_reminded', 'user_reminded_time'
			);

			// load all columns
			$sql = 'SELECT *
					FROM ' . USERS_TABLE . "
					WHERE group_id = $group_id";
			$result = $this->db->sql_query_limit($sql, 1);
			$user_rows = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			if (!$user_rows)
			{
				$sql = 'SELECT *
						FROM ' . USERS_TABLE . '
						WHERE user_id = ' . ANONYMOUS;
				$result = $this->db->sql_query_limit($sql, 1);
				$user_rows = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);
			}

			foreach ($user_rows as $key => $value)
			{
				if (!in_array($key, $phpbb_default_columns) && !isset($system_bot_row[$key]))
				{
					// Any additional variables in $system_bot_row not covered above?
					$system_bot_row[$key] = (is_numeric($value)) ? 0 : '';
				}
			}

			if (!function_exists('user_add'))
			{
				include($this->phpbb_root_path . 'includes/functions_user.' . $this->php_ext);
			}

			$user_id = (int) user_add($system_bot_row);

			return array(
				// Add config
				array('config.add', array('jv_system_bot_user_id', $user_id))
			);
		}

		return array();
	}

	public function revert_data()
	{
		if (!empty($this->config['jv_system_bot_user_id']))
		{
			if (!function_exists('user_delete'))
			{
				include($this->phpbb_root_path . 'includes/functions_user.' . $this->php_ext);
			}

			user_delete('retain', $this->config['jv_system_bot_user_id']);
		}

		return array(
			// Remove config
			array('config.remove', array('jv_system_bot_user_id'))
		);
	}
}
