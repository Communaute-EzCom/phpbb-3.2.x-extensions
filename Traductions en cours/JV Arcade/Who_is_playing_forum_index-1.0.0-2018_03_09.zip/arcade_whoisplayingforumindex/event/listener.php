<?php
/**
*
* @package phpBB Arcade - Who is playing on forum index page
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade_whoisplayingforumindex\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $ext_enable = false;
	protected $arcade, $arcade_config;

	public function __construct($ext, $arcade = null, $arcade_config = null)
	{
		if ($arcade && defined('ARCADE_MIN_EXT_VERSION') && phpbb_version_compare($ext->version, ARCADE_MIN_EXT_VERSION, '>='))
		{
			$this->ext_enable = true;
			$this->arcade = $arcade;
			$this->arcade_config = $arcade_config;
		}
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.index_modify_page_title' => 'display'
		);
	}

	public function display($event)
	{
		if ($this->ext_enable && $this->arcade_config['ext_whoisplaying_forum_index_display'] && $this->arcade->access('arcade', false))
		{
			$this->arcade->display()->online_playing();
		}
	}
}
