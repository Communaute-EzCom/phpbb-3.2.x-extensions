<?php
/**
*
* @package phpBB Arcade - Who is playing on forum index page
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade_whoisplayingforumindex;

use phpbb\extension\base;

class ext extends base
{
	public function is_enableable()
	{
		return defined('ARCADE_VERSION') && phpbb_version_compare(ARCADE_VERSION, '4.2.2', '>=');
	}
}
