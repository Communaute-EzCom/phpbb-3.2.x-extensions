<?php
/**
*
* @package phpBB Arcade
* @version $Id: file.php 1944 2018-04-15 00:17:27Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
if (!defined('IN_PHPBB') || !defined('IN_PHPBB_ARCADE'))
{
	exit;
}

// Thank you sun.
if (isset($_SERVER['CONTENT_TYPE']))
{
	if ($_SERVER['CONTENT_TYPE'] === 'application/x-java-archive')
	{
		exit;
	}
}
else if (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], 'Java') !== false)
{
	exit;
}

require($phpbb_root_path . 'includes/startup.' . $phpEx);

require($phpbb_root_path . 'phpbb/class_loader.' . $phpEx);
$phpbb_class_loader = new \phpbb\class_loader('phpbb\\', "{$phpbb_root_path}phpbb/", $phpEx);
$phpbb_class_loader->register();

$phpbb_config_php_file = new \phpbb\config_php_file($phpbb_root_path, $phpEx);
extract($phpbb_config_php_file->get_all());

if (!defined('PHPBB_ENVIRONMENT'))
{
	@define('PHPBB_ENVIRONMENT', 'production');
}

if (!defined('PHPBB_INSTALLED') || empty($dbms) || empty($acm_type))
{
	exit;
}

require($phpbb_root_path . 'includes/constants.' . $phpEx);
require($phpbb_root_path . 'includes/functions.' . $phpEx);
require($phpbb_root_path . 'includes/utf/utf_tools.' . $phpEx);

// Setup class loader first
$phpbb_class_loader_ext = new \phpbb\class_loader('\\', "{$phpbb_root_path}ext/", $phpEx);
$phpbb_class_loader_ext->register();

//phpbb_load_extensions_autoloaders($phpbb_root_path);

// Set up container
$phpbb_container_builder = new \phpbb\di\container_builder($phpbb_root_path, $phpEx);
$phpbb_container = $phpbb_container_builder->with_config($phpbb_config_php_file)->get_container();

$phpbb_class_loader->set_cache($phpbb_container->get('cache.driver'));
$phpbb_class_loader_ext->set_cache($phpbb_container->get('cache.driver'));

$cache		= $phpbb_container->get('cache');
$request	= $phpbb_container->get('request');
$db			= $phpbb_container->get('dbal.conn');

unset($dbpasswd);

$config = $phpbb_container->get('config');

if (!class_exists('jv\arcade\inc\arcade'))
{
	exit;
}

$browser = strtolower($request->header('User-Agent', 'msie 6.0'));

$arcade_cache	= $phpbb_container->get('jv.arcade.cache');
$file_functions	= $phpbb_container->get('jv.arcade.functions_file');
$arcade_config	= $phpbb_container->get('jv.arcade.config');

if ($request->is_set('swf'))
{
	$filename = $request->variable('swf', '');

	if (!$filename)
	{
		send_status_line(403, 'Forbidden');
	}
	else
	{
		send_swf_to_browser($filename, $browser);
	}

	$file_functions->file_gc();
}

if ($request->is_set('img'))
{
	$filename = $request->variable('img', 'no_image.png');

	$filename = ($filename) ? $filename : 'no_image.png';

	$ext = substr(strrchr($filename, '.'), 1);

	if (strpos($filename, '.') === false || !in_array($ext, array('png', 'gif', 'jpg', 'jpeg')))
	{
		send_status_line(403, 'Forbidden');
	}
	else
	{
		send_img_to_browser($filename, $browser);
	}

	$file_functions->file_gc();
}

function send_swf_to_browser($file, $browser)
{
	global $request, $arcade_config, $file_functions, $phpbb_root_path;

	$path = $request->variable('p', 0);

	$game_path = ($path === 1) ? "arcade/swf/" : $arcade_config['game_path'];
	$file_functions->trailing_slash($game_path);

	$file_path = $phpbb_root_path . $game_path . '/' . (($path == 1) ? "" : "{$file}/") . $file . '.swf';

	if ((@file_exists($file_path) && @is_readable($file_path)) && !headers_sent())
	{
		header('Cache-Control: public');
		header('Content-Type: application/x-shockwave-flash');

		if ((strpos(strtolower($browser), 'msie') !== false) && !$file_functions->is_greater_ie_version($browser, 7))
		{
			if (strpos(strtolower($browser), 'msie 6.0') !== false)
			{
				header('Expires: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
			}
			else
			{
				header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
			}
		}
		else
		{
			header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
		}

		$size = @filesize($file_path);

		if ($size)
		{
			header("Content-Length: $size");
		}

		if (@readfile($file_path) == false)
		{
			$fp = @fopen($file_path, 'rb');

			if ($fp !== false)
			{
				while (!feof($fp))
				{
					echo fread($fp, 8192);
				}

				fclose($fp);
			}
		}

		flush();
	}
	else
	{
		send_status_line(404, 'Not Found');
	}
}

function send_img_to_browser($file, $browser)
{
	global $phpbb_container, $arcade_config, $file_functions, $phpbb_root_path;

	$game_path = $arcade_config['game_path'];
	$file_functions->trailing_slash($game_path);
	$file_folder = $file_functions->remove_extension($file);
	$file_path = $phpbb_root_path . $game_path . $file_folder . '/' . $file;

	if (!@file_exists($file_path) || !@is_readable($file_path))
	{
		$file_path = $phpbb_root_path . $game_path . $file_folder . '/pics/' . $file;

		if (!@file_exists($file_path) || !@is_readable($file_path))
		{
			$ext = strrchr($file, '.');

			$ibp_image = array(
				$phpbb_root_path . $game_path . $file_folder . '/' . $file_folder . '1' . $ext,
				$phpbb_root_path . $game_path . $file_folder . '/' . $file_folder . '2' . $ext,
			);

			foreach ($ibp_image as $image)
			{
				if (@file_exists($image) && @is_readable($image))
				{
					$file_path = $image;
					break;
				}
			}

			if (!@file_exists($file_path) || !@is_readable($file_path))
			{
				$file_path = $phpbb_container->get('jv.arcade.main')->set_image_path() . 'no_image.png';
			}
		}
	}

	if ((@file_exists($file_path) && @is_readable($file_path)) && !headers_sent())
	{
		$stamp = @filemtime($file_path);
		if (!empty($stamp) && $file_functions->set_modified_headers($stamp, $browser))
		{
			return;
		}

		header('Cache-Control: public');

		$image_data = @getimagesize($file_path);
		header('Content-Type: ' . image_type_to_mime_type($image_data[2]));

		if ((strpos(strtolower($browser), 'msie') !== false) && !$file_functions->is_greater_ie_version($browser, 7))
		{
			header('Content-Disposition: attachment; ' . $file_functions->header_filename($file));

			if (strpos(strtolower($browser), 'msie 6.0') !== false)
			{
				header('Expires: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
			}
			else
			{
				header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
			}
		}
		else
		{
			header('Content-Disposition: inline; ' . $file_functions->header_filename($file));
			header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
		}

		$size = @filesize($file_path);

		if ($size)
		{
			header("Content-Length: $size");
		}

		if (@readfile($file_path) == false)
		{
			$fp = @fopen($file_path, 'rb');

			if ($fp !== false)
			{
				while (!feof($fp))
				{
					echo fread($fp, 8192);
				}

				fclose($fp);
			}
		}

		flush();
	}
	else
	{
		send_status_line(404, 'Not Found');
	}
}