<?php
/**
*
* @package phpBB Arcade
* @version $Id: getHiScores.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

define('IN_PHPBB', true);
define('IN_PHPBB_ARCADE', true);

$str='';
$x=1;

while ($x <= 10)
{
	$str.= "&ibproName$x=Name$x&ibproScore$x=$x";
	$x++;
}

$str.= '&EOS=1&blah';
echo $str;
