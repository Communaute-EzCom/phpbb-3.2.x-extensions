<?php
/**
*
* @package phpBB Arcade
* @version $Id: score.php 1968 2018-05-25 19:15:45Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\controller;

class score
{
	protected $arcade;

	public function __construct($arcade)
	{
		$this->arcade = $arcade;
	}

	public function amod_game()
	{
		$this->arcade->container('scoretype')->set(AMOD_GAME);
	}

	public function ar_game()
	{
		$this->arcade->container('scoretype')->set(AR_GAME);
	}

	public function ra_game()
	{
		$this->arcade->container('scoretype')->set(PHPBB_RA_GAME);
	}
}
