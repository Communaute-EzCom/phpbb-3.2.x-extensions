<?php
/**
*
* @package phpBB Arcade
* @version $Id: install_module.php 1944 2018-04-15 00:17:27Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class install_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $admin_path;
	protected $db, $request, $cache, $user, $config, $template, $php_ext;
	protected $arcade_config, $arcade_auth, $arcade, $file_functions;

	public function __construct()
	{
		global $phpbb_admin_path;
		global $db, $request, $cache, $user, $config, $template, $phpEx;
		global $arcade_config, $arcade_auth, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->admin_path = $phpbb_admin_path;
		$this->db = $db;
		$this->request = $request;
		$this->cache = $cache;
		$this->user = $user;
		$this->config = $config;
		$this->template = $template;
		$this->php_ext = $phpEx;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->file_functions = $this->arcade->container('functions_file');
	}

	public function main($id, $mode)
	{
		$explain = '';
		$this->user->add_lang_ext('jv/arcade', 'install');

		$action = ($this->request->variable('action', ''));

		$this->tpl_name = 'arcade/acp_install';

		switch ($mode)
		{
			case 'install_verify':
				$this->user->add_lang_ext('jv/arcade', array('info_ucp_arcade', 'info_mcp_arcade'));

				switch ($action)
				{
					case 'files':
						$this->page_title = 'INSTALL_ARCADE_VERIFY_FILES';
						$this->arcade->install('verify')->verify->check_files($this->u_action);
					break;

					case 'db':
						$this->page_title = 'INSTALL_ARCADE_VERIFY_DB';
						$this->arcade->install('verify')->verify->check_db($this->u_action);
					break;

					case 'finish':
						$message  = $this->user->lang['INSTALL_ARCADE_FINISH'];
						$message .= '<br><br><a onclick="window.open(this.href); return false;" href="' . $this->arcade_config['support_domain'] . 'donate/index.php?mode=start#arcade_donate"><img src="' . $this->arcade_config['support_domain'] . 'dev/images/paypal_donate.png" alt="' . $this->user->lang['INSTALL_ARCADE_DONATE_TITLE'] . '" title="' . $this->user->lang['INSTALL_ARCADE_DONATE_TITLE'] . '"></a>';
						$message .= '<br><br><a href="' . append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('main')) . '">' . $this->user->lang['INSTALL_ARCADE_MAIN_PAGE'] . '</a>';

						trigger_error($message, E_USER_NOTICE);
					break;

					default:
						if ($this->arcade_config['version'] != ARCADE_VERSION || $this->arcade_config['version'] != $this->arcade->install('verify')->data->version())
						{
							trigger_error(sprintf($this->user->lang['INSTALL_ARCADE_VERIFY_ERROR_DB_VERSION'], '<a href="' . append_sid("{$this->admin_path}index.{$this->php_ext}", 'i=acp_extensions&amp;mode=main') . '">', '</a>'), E_USER_WARNING);
						}

						$this->page_title = 'INSTALL_ARCADE_REQUIREMENTS';
						//$this->config->increment('assets_version', 1);
						//$this->arcade->container('phpbb_cache.driver')->purge();
						$this->arcade->install('verify')->verify->check_server_requirements($this->u_action);
				}
			break;

			case 'update_game_data':
				$this->page_title = 'INS_ARCADE_UPDATE_GAME_DATA';

				if (!$action)
				{
					$explain = $this->submit('INS_ARCADE_UPDATE_GAME_DATA', true);
				}
				else
				{
					$limit = INS_ARCADE_UPDATE_DATA_LIMIT;

					$total_games		= (int) $this->request->variable('total_games', 0);
					$start				= (int) $this->request->variable('start', 0);
					$uns_filesize		= (int) $this->request->variable('uns_filesize', 0);
					$uns_game_hw		= (int) $this->request->variable('uns_game_hw', 0);
					$game_file_exists	= (int) $this->request->variable('game_file_exists', 0);
					$up_install_file	= (int) $this->request->variable('up_install_file', 0);
					$unwritable_file	= (int) $this->request->variable('unwritable_file', 0);
					$file_exists		= (int) $this->request->variable('file_exists', 0);
					$correct_data		= (int) $this->request->variable('correct_data', 0);
					$update_data		= (int) $this->request->variable('update_data', 0);

					if (!$total_games)
					{
						$sql = 'SELECT COUNT(game_id) as total_games
								FROM ' . ARCADE_GAMES_TABLE;
						$result = $this->db->sql_query($sql);
						$total_games = (int) $this->db->sql_fetchfield('total_games');
						$this->db->sql_freeresult($result);
					}

					$this->arcade->valid_start($start, $total_games);

					if ($total_games)
					{
						$sql = 'SELECT game_id, game_name, game_desc, game_control, game_control_desc, game_image, game_swf, game_scorevar, game_type, game_save_type, game_width, game_height, game_scoretype, game_filesize
								FROM ' . ARCADE_GAMES_TABLE . '
								ORDER BY game_name ASC';
						$result = $this->db->sql_query_limit($sql, $limit, $start);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$update_data_filesize = $update_data_hw = false;

							if (empty($row['game_swf']) && !empty($row['game_scorevar']))
							{
								$row['game_swf'] = $row['game_scorevar'] . '.swf';
							}

							if (!empty($row['game_swf']))
							{
								$game_file = $this->arcade->set_path($row['game_swf'], '', true, $row['game_type'], $row['game_save_type']);

								if (file_exists($game_file))
								{
									$filesize = $this->file_functions->filesize(array_filter(array($this->arcade->set_path($row['game_swf'], 'path'), $this->arcade->game->file_path($row['game_swf']))));

									if (!$filesize)
									{
										$uns_filesize++;
										$this->arcade->add_log('critical', $row['game_id'], 'LOG_ARCADE_GAME_NOT_DETECT_FILESIZE', $row['game_name']);
									}
									else if ($filesize <> $row['game_filesize'])
									{
										$update_data_filesize = true;
									}

									$fs = (GAME_TYPE_HTML5 != $row['game_type']) ? $this->file_functions->filesize(array_filter(array($game_file))) : 0;
									$size_ignore = (GAME_TYPE_HTML5 == $row['game_type'] || ($fs && $fs > 55000000)) ? true : false;
									$stats = ($size_ignore) ? false : getimagesize($game_file);

									if ($stats !== false)
									{
										$new_game_width  = (int) $stats[0];
										$new_game_height = (int) $stats[1];

										if (($new_game_width >= ARCADE_MIN_GAME_WIDTH && $row['game_width'] <> $new_game_width) || ($new_game_height >= ARCADE_MIN_GAME_HEIGHT && $row['game_height'] <> $new_game_height))
										{
											$update_data_hw = true;
										}
									}
									else if (!$size_ignore)
									{
										$uns_game_hw++;
										$this->arcade->add_log('critical', $row['game_id'], 'LOG_ARCADE_GAME_NOT_DETECT_HW', $row['game_name']);
									}

									if ($update_data_filesize || $update_data_hw)
									{
										$sql_ary = array();
										if ($update_data_filesize)
										{
											$sql_ary['game_filesize'] = (int) $filesize;
										}

										if ($update_data_hw)
										{
											$sql_ary['game_width']  = $new_game_width;
											$sql_ary['game_height'] = $new_game_height;
										}

										$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
												SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
												WHERE game_id = ' . (int) $row['game_id'];
										$this->db->sql_query($sql);

										if ($update_data_hw)
										{
											$install_file = $this->arcade->set_path($row['game_swf'], 'install');

											$row['game_width']  = $new_game_width;
											$row['game_height'] = $new_game_height;

											// If not found game install file - We are trying to create.
											$force_update = false;
											if (!file_exists($install_file))
											{
												if (!$this->arcade->game->install_file->update(false, $row))
												{
													$file_exists++;
													$this->arcade->add_log('critical', $row['game_id'], 'LOG_ARCADE_GAME_INSTALL_FILE_NOT_FOUND', $row['game_name'], $this->arcade->root_key($install_file));
												}
												else
												{
													$force_update = true;
													$up_install_file++;
												}
											}

											if (!$force_update)
											{
												if ($this->arcade->game->install_file->update(false, $row))
												{
													$up_install_file++;
												}
												else
												{
													$unwritable_file++;
												}
											}
										}

										$update_data++;
									}
									else
									{
										$correct_data++;
									}
								}
								else
								{
									$game_file_exists++;
									$this->arcade->add_log('critical', $row['game_id'], 'LOG_ARCADE_GAME_FILE_NOT_FOUND', $row['game_name'], $this->arcade->root_key($game_file));
								}
							}
						}
						$this->db->sql_freeresult($result);

						$start += $limit;

						if ($limit && $start < $total_games && $limit < $total_games)
						{
							$redirect = $this->u_action . "&amp;action=run&amp;start=$start&amp;total_games=$total_games&amp;uns_filesize=$uns_filesize&amp;uns_game_hw=$uns_game_hw&amp;game_file_exists=$game_file_exists&amp;up_install_file=$up_install_file&amp;unwritable_file=$unwritable_file&amp;file_exists=$file_exists&amp;correct_data=$correct_data&amp;update_data=$update_data";
							$redirect = meta_refresh(3, $redirect);
							$explain  = '</p><div class="errorbox notice"><p>' . $this->user->lang['INS_ARCADE_UPDATE_GAME_DATA_PROC_EXPLAIN'] . '<br><br>' . sprintf($this->user->lang['ARCADE_GAME_PROCESSING'], $this->arcade->get->image('full', 'img', 'loading2.gif', 'INS_ARCADE_UPDATE_GAME_DATA', true), $start, $total_games) . '</p></div><p>';
						}
						else
						{
							$this->result($this->user->lang['ACP_ARCADE_INSTALL_GAMES'], $total_games);
							$this->result($this->user->lang['INS_ARCADE_GAME_DATA_CORRECT'], $correct_data);
							$this->result($this->user->lang['INS_ARCADE_GAME_DATA_UPDATED'], $update_data);

							if ($game_file_exists)
							{
								$this->result($this->user->lang['INS_ARCADE_GAME_FILES_NOT_FOUND'], $game_file_exists);
							}

							if ($uns_filesize)
							{
								$this->result($this->user->lang['INS_ARCADE_UND_GAMES_FILESIZE'], $uns_filesize);
							}

							if ($uns_game_hw)
							{
								$this->result($this->user->lang['INS_ARCADE_UND_GAMES_WIDTH_HEIGHT'], $uns_game_hw);
							}

							$this->result($this->user->lang['INS_ARCADE_GAME_INSTALL_FILE_UPDATED'], $up_install_file);

							if ($file_exists)
							{
								$this->result($this->user->lang['INS_ARCADE_GAME_INSTALL_FILES_NOT_FOUND'], $file_exists);
							}

							if ($unwritable_file)
							{
								$this->result($this->user->lang['INS_ARCADE_GAME_INSTALL_FILES_UNWRITABLE'], $unwritable_file);
							}

							$explain = '</p><div class="successbox"><h3>' . $this->user->lang['INFORMATION'] . '</h3><p>' . $this->user->lang['INS_ARCADE_UPDATE_GAME_DATA_END'];

							if ($uns_filesize || $uns_game_hw || $game_file_exists || $file_exists || $unwritable_file)
							{
								$explain .= '<br>' . $this->user->lang['INS_ARCADE_ADD_ERROR_LOG'];
							}

							$explain .= '</p></div><p>';

							if ($update_data)
							{
								$this->cache->destroy('_arcade_games_filesize');
							}
						}
					}
					else
					{
						$explain = '</p><div class="errorbox"><h3>' . $this->user->lang['INFORMATION'] . '</h3><p>' . $this->user->lang['ARCADE_NO_GAMES'] . '</p></div><p>';
					}
				}
			break;

			case 'convert_game_ins_file':
				$this->page_title = 'INS_ARCADE_GAME_CONVERT_FILE';

				if (!$action)
				{
					$explain = $this->submit('INS_ARCADE_UPDATE_GAME_DATA', true);
				}
				else
				{
					$delete_games = array();
					$limit = INS_ARCADE_CONVERT_GAME_INSTALL_FILE_LIMIT;

					$total_games		= (int) $this->request->variable('total_games', 0);
					$start				= (int) $this->request->variable('start', 0);
					$convert_file		= (int) $this->request->variable('convert_file', 0);
					$install_files		= (int) $this->request->variable('install_files', 0);
					$file_exists		= (int) $this->request->variable('file_exists', 0);
					$unwritable_file	= (int) $this->request->variable('unwritable_file', 0);
					$del_games			= (int) $this->request->variable('delete_games', 0);

					if (!$total_games)
					{
						$sql = 'SELECT COUNT(game_id) as total_games
								FROM ' . ARCADE_GAMES_TABLE;
						$result = $this->db->sql_query($sql);
						$total_games = (int) $this->db->sql_fetchfield('total_games');
						$this->db->sql_freeresult($result);

						$sql = 'SELECT game_id, game_name, game_swf, cat_id
								FROM ' . ARCADE_GAMES_TABLE . '
								ORDER BY game_name DESC';
						$result = $this->db->sql_query($sql);
						$duplicate_swf_name = $swf_names = array();
						while ($row = $this->db->sql_fetchrow($result))
						{
							if (!empty($swf_names[$row['game_swf']]))
							{
								$duplicate_swf_name[$row['game_swf']] = array(
									'game_name'	=> $row['game_name'],
									'game_id'	=> $row['game_id'],
									'cat_id'	=> $row['cat_id']
								);
							}

							$swf_names[$row['game_swf']] = 1;
						}
						$this->db->sql_freeresult($result);

						if (count($duplicate_swf_name))
						{
							$errors = array();
							foreach ($duplicate_swf_name as $swf_name => $row)
							{
								$delete_games[] = $row['game_name'];
								$this->arcade->delete_game($row['game_id'], $errors, $this->user->lang['ACP_ARCADE_DOUBLE_GAME']);
							}
						}
					}

					$this->arcade->valid_start($start, $total_games);

					if ($total_games)
					{
						$sql = 'SELECT game_id, game_name, game_desc, game_control, game_control_desc, game_image, game_swf, game_scorevar, game_type, game_save_type, game_width, game_height, game_scoretype, cat_id
								FROM ' . ARCADE_GAMES_TABLE . '
								ORDER BY game_name ASC';
						$result = $this->db->sql_query_limit($sql, $limit, $start);
						$errors = array();
						while ($row = $this->db->sql_fetchrow($result))
						{
							if (empty($row['game_swf']))
							{
								if (empty($row['game_scorevar']))
								{
									$delete_games[] = $row['game_name'];
									$this->arcade->delete_game($row['game_id'], $errors);
									continue;
								}

								$row['game_swf'] = $row['game_scorevar'] . '.swf';
							}

							$install_file = $this->arcade->set_path($row['game_swf'], 'install');

							// If not found game install file - We are trying to create.
							if (!file_exists($install_file))
							{
								$new_game_ary = $row;
								if (!$this->arcade->game->install_file->update(false, $new_game_ary))
								{
									$file_exists++;
									$this->arcade->add_log('critical', $row['game_id'], 'LOG_ARCADE_GAME_INSTALL_FILE_NOT_FOUND', $row['game_name'], $this->arcade->root_key($install_file));
									continue;
								}
								else
								{
									$convert_file++;
									$this->update_game_data($new_game_ary, $row);
									continue;
								}
							}

							$game_data = array();
							if ($this->arcade->game->install_file->data_check($install_file, $game_data, $row))
							{
								$install_files++;
								continue;
							}

							$new_game_ary = $row;
							if ($this->arcade->game->install_file->update(false, $new_game_ary))
							{
								$convert_file++;

								$this->update_game_data($new_game_ary, $row);
							}
							else
							{
								$unwritable_file++;
							}
						}
						$this->db->sql_freeresult($result);

						if (count($delete_games))
						{
							$del_games += count($delete_games);
							$this->arcade->add_log('admin', 'LOG_ARCADE_DELETE_GAME' . ((count($delete_games) > 1) ? 'S' : ''), implode(', ', $delete_games));
						}

						$start += $limit;

						if ($limit && $start < $total_games && $limit < $total_games)
						{
							$redirect = $this->u_action . "&amp;action=run&amp;start=$start&amp;total_games=$total_games&amp;convert_file=$convert_file&amp;install_files=$install_files&amp;file_exists=$file_exists&amp;unwritable_file=$unwritable_file&amp;delete_games=$del_games";
							$redirect = meta_refresh(3, $redirect);
							$explain = '</p><div class="errorbox notice"><p>' . $this->user->lang['INS_ARCADE_CONVERT_GAME_INSTALL_FILE_EXPLAIN'] . '<br><br>' . sprintf($this->user->lang['INS_ARCADE_CONVERT_GAME_INSTALL_FILE_PROCESSING'], $this->arcade->get->image('full', 'img', 'loading2.gif', 'INS_ARCADE_GAME_CONVERT_FILE', true), $start, $total_games) . '</p></div><p>';
						}
						else
						{
							$this->result($this->user->lang['ACP_ARCADE_INSTALL_GAMES'], $total_games);

							if ($del_games)
							{
								$this->arcade->cache_purge();
								$this->result($this->user->lang['INS_ARCADE_DELETE_DUPLICATE_GAME' . (($del_games > 1) ? 'S' : '')], $del_games);
							}

							$this->result($this->user->lang['INS_ARCADE_DATA_FILES_CORRECT'], $install_files);
							$this->result($this->user->lang['INS_ARCADE_CONVERT_TOTAL_GAME_INSTALL_FILES'], $convert_file);

							if ($file_exists)
							{
								$this->result($this->user->lang['INS_ARCADE_GAME_INSTALL_FILES_NOT_FOUND'], $file_exists);
							}

							if ($unwritable_file)
							{
								$this->result($this->user->lang['INS_ARCADE_GAME_INSTALL_FILES_UNWRITABLE'], $unwritable_file);
							}

							$explain = '</p><div class="' . (($file_exists || $unwritable_file) ? 'errorbox' : 'successbox') . '"><h3>' . $this->user->lang['INFORMATION'] . '</h3><p>' . $this->user->lang['INS_ARCADE_CONVERT_GAME_INSTALL_FILE_END'];

							if ($file_exists || $unwritable_file)
							{
								$explain .= '<br>' . $this->user->lang['INS_ARCADE_ADD_ERROR_LOG'];
							}

							$explain .= '</p></div><p>';
						}
					}
					else
					{
						$explain = '</p><div class="errorbox"><h3>' . $this->user->lang['INFORMATION'] . '</h3><p>' . $this->user->lang['ARCADE_NO_GAMES'] . '</p></div><p>';
					}
				}
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		$this->template->assign_vars(array(
			'L_ARCADE_TITLE'			=> $this->user->lang[$this->page_title],
			'L_ARCADE_TITLE_EXPLAIN'	=> ($explain) ? $explain : $this->user->lang[$this->page_title . '_EXPLAIN']
		));
	}

	private function result($title, $result)
	{
		$this->template->assign_block_vars('checks', array(
			'TITLE'		=> $title,
			'RESULT'	=> $result,

			'S_EXPLAIN'	=> false,
			'S_LEGEND'	=> false
		));
	}

	private function submit($key, $write_exp = false)
	{
		$this->template->assign_vars(array(
			'S_HIDDEN' => build_hidden_fields(array('action' => true)),
			'U_ACTION' => $this->u_action,
			'L_SUBMIT' => $this->user->lang[$key]
		));

		if ($write_exp)
		{
			return $this->user->lang[$this->page_title . '_EXPLAIN'] . '<br>' . $this->user->lang['INS_ARCADE_FILE_WRITE_EXPLAIN'];
		}
	}

	private function update_game_data(&$new_game_ary, $row)
	{
		if (!$this->arcade->game->install_file->data_check(false, $new_game_ary, $row))
		{
			unset($new_game_ary['game_id']);

			$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
					SET ' . $this->db->sql_build_array('UPDATE', $new_game_ary) . '
					WHERE game_id = ' . (int) $row['game_id'];
			$this->db->sql_query($sql);
		}
	}
}
