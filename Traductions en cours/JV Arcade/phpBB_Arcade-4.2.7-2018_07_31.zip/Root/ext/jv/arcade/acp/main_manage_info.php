<?php
/**
*
* @package phpBB Arcade
* @version $Id: main_manage_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class main_manage_info
{
	function module()
	{
		return array(
			'filename'			=> '\jv\arcade\acp\main_manage_module',
			'title'				=> 'ACP_ARCADE_MANAGE',
			'modes'				=> array(
				'menu'			=> array('title' => 'ACP_ARCADE_MANAGE_MENU'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_menu'	, 'cat' => array('ACP_CAT_ARCADE_MANAGE')),
				'announce'		=> array('title' => 'ACP_ARCADE_MANAGE_ANNOUNCE'	, 'auth' => 'ext_jv/arcade && acl_a_arcade_announce', 'cat' => array('ACP_CAT_ARCADE_MANAGE')),
				'ranks'			=> array('title' => 'ACP_ARCADE_MANAGE_RANKS'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_ranks'	, 'cat' => array('ACP_CAT_ARCADE_MANAGE'))
			)
		);
	}
}
