<?php
/**
*
* @package phpBB Arcade
* @version $Id: install_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class install_info
{
	function module()
	{
		return array(
			'filename'					=> '\jv\arcade\acp\install_module',
			'title'						=> 'ACP_ARCADE_INSTALL_FEATURES',
			'modes'						=> array(
				'install_verify'		=> array('title' => 'ACP_ARCADE_INSTALL_VERIFY',				'auth' => 'ext_jv/arcade && acl_a_arcade_install', 'cat' => array('ACP_CAT_ARCADE_INSTALL_FEATURES')),
				'update_game_data'		=> array('title' => 'ACP_ARCADE_INSTALL_UPDATE_GAME_DATA',		'auth' => 'ext_jv/arcade && acl_a_arcade_install', 'cat' => array('ACP_CAT_ARCADE_INSTALL_FEATURES')),
				'convert_game_ins_file'	=> array('title' => 'ACP_ARCADE_INSTALL_CONVERT_GAME_INS_FILE',	'auth' => 'ext_jv/arcade && acl_a_arcade_install', 'cat' => array('ACP_CAT_ARCADE_INSTALL_FEATURES'))
			)
		);
	}
}
