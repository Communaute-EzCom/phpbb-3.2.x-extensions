<?php
/**
*
* @package phpBB Arcade
* @version $Id: permission_roles_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class permission_roles_info
{
	function module()
	{
		return array(
			'filename'		=> '\jv\arcade\acp\permission_roles_module',
			'title'			=> 'ACP_ARCADE_PERMISSION_ROLES',
			'modes'			=> array(
				'cat_roles'	=> array('title' => 'ACP_ARCADE_CAT_ROLES', 'auth' => 'ext_jv/arcade && acl_a_roles && acl_a_cauth', 'cat' => array('ACP_CAT_ARCADE_PERMISSION_ROLES'))
			)
		);
	}
}
