<?php
/**
*
* @package phpBB Arcade
* @version $Id: main_module.php 2037 2018-07-25 20:00:07Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class main_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $admin_path;
	protected $db, $cache, $config, $auth, $request, $user, $template, $root_path, $php_ext;
	protected $arcade_cache, $arcade_config, $arcade;

	private $actual_time;

	public function __construct()
	{
		global $phpbb_admin_path;
		global $db, $cache, $config, $auth, $request, $user, $template, $phpbb_root_path, $phpEx;
		global $arcade_cache, $arcade_config, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check(($user->data['user_type'] == USER_FOUNDER) ? 'acp_main' : '');

		$this->admin_path = $phpbb_admin_path;
		$this->db = $db;
		$this->cache = $cache;
		$this->config = $config;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
		$this->actual_time = time();
	}

	public function main($id, $mode)
	{
		$notice = array();
		$this->tpl_name = 'arcade/acp_main';
		$user_founder = ($this->user->data['user_type'] == USER_FOUNDER) ? true : false;
		$mode_title_disable = false;
		$action = $this->request->variable('action', '');

		switch ($action)
		{
			case 'term_of_use':
			case 'version_check':
				if ($this->auth->acl_get('a_arcade_install'))
				{
					$mode = $action;
				}
			break;

			case 'users_default_settings':
				if ($this->auth->acl_get('a_arcade') && $this->auth->acl_get('a_arcade_user'))
				{
					$mode = $action;
				}
			break;

			case 'close_cookie':
				$this->arcade_config->set('cookie_secure_info_time', intval($this->actual_time + ARCADE_COOKIE_INFO_CLOSE_TIME));
			break;
		}

		if ($this->auth->acl_get('a_arcade_install') && $this->request->variable('update_vc', false))
		{
			$arcade_vc = $this->request->variable('arcade_vc', false);
			$this->arcade_config->set('version_check_enable', ($arcade_vc) ? 1 : 0);
			$this->arcade->add_log('admin', 'LOG_ARCADE_VERSION_CHECK' . (($arcade_vc) ? '_ENABLED' : '_DISABLED'));

			trigger_error($this->user->lang['CONFIG_UPDATED'] . (($this->request->is_ajax()) ? '' : adm_back_link($this->u_action)), E_USER_NOTICE);
		}

		$u_action = $this->u_action;
		$page_title = $this->page_title;
		$versioncheck_force = $this->request->variable('versioncheck_force', false);

		$vars = array('mode', 'action', 'notice', 'u_action', 'page_title', 'mode_title_disable');
		extract($this->arcade->phpbb_dispatcher()->trigger_event('jv.arcade.acp_main_before', compact($vars)));
		$this->page_title = $page_title;

		switch ($mode)
		{
			case 'main':
				$this->page_title = ($this->page_title) ? $this->page_title : 'ACP_ARCADE_MAIN';

				if ($this->arcade_config['activation_key'] || $this->arcade->localhost())
				{
					if ($action)
					{
						if (!confirm_box(true))
						{
							switch ($action)
							{
								case 'reset_arcade':
								case 'reset_scores_all':
								case 'reset_playing_record':
								case 'reset_challenge':
								case 'reset_comment':
								case 'reset_users_data':
								case 'reset_users_settings':
								case 'reset_downloads':
								case 'reset_jackpot':
								case 'reset_points':
								case 'reset_super_champion':
								case 'purge_sessions':
								case 'resync_totals_data':
								case 'resync_users_total_data':
									$confirm = true;
									$confirm_lang = 'ARCADE_' . strtoupper($action);
								break;

								default:
									$confirm = false;
								break;
							}

							if ($confirm)
							{
								$s_hidden_fields = array(
									'i'			=> $id,
									'mode'		=> $mode,
									'action'	=> $action
								);

								if ($action == 'reset_arcade' || $action == 'reset_scores_all')
								{
									$this->arcade->confirm_box(($action == 'reset_arcade') ? 'retain_super_champion' : 'retain_plays', $confirm_lang, $s_hidden_fields);
								}
								else
								{
									confirm_box(false, $confirm_lang, build_hidden_fields($s_hidden_fields), 'confirm_body.html');
								}
							}
						}
						else
						{
							if ((!$this->auth->acl_get('a_arcade')) ||
								($action == 'reset_points' && !$this->auth->acl_get('a_arcade_points_settings')) ||
								(in_array($action, array('reset_scores_all', 'reset_users_data', 'reset_users_settings', 'reset_comment', 'reset_super_champion')) && !$this->auth->acl_get('a_arcade_user')) ||
								(in_array($action, array('reset_arcade', 'reset_challenge')) && !$this->auth->acl_gets('a_arcade_game', 'a_arcade_user')) ||
								($action == 'purge_sessions' && !$user_founder))
							{
								send_status_line(403, 'Forbidden');
								trigger_error($this->user->lang['NO_AUTH_OPERATION'] . (($this->request->is_ajax()) ? '' : adm_back_link($this->u_action)), E_USER_WARNING);
							}

							switch ($action)
							{
								case 'reset_arcade':
								case 'reset_scores_all':
								case 'reset_playing_record':
								case 'reset_challenge':
								case 'reset_comment':
								case 'reset_users_data':
								case 'reset_users_settings':
								case 'reset_downloads':
								case 'reset_jackpot':
								case 'reset_points':
								case 'reset_super_champion':
								case 'purge_sessions':
									$this->reset($action);
								break;

								case 'resync_totals_data':
									$this->arcade->sync('total_data', 'all');
									$this->cache->destroy('_arcade_games_filesize');
								break;

								case 'resync_users_total_data':
									$this->arcade->sync('users_total_data');
									$this->arcade->cache_purge('score');
								break;

								default:
									trigger_error('NO_MODE', E_USER_ERROR);
								break;
							}

							$log_msg = 'LOG_ARCADE_' . strtoupper($action);

							if (in_array($action, array('reset_arcade', 'reset_scores_all')))
							{
								$var_key = ($action == 'reset_arcade') ? 'retain_super_champion' : 'retain_plays';
								$this->arcade->add_rvlog($log_msg, $var_key);
							}
							else
							{
								$this->arcade->add_log('admin', $log_msg);
							}

							trigger_error($this->user->lang['ARCADE_' . strtoupper($action) . '_DONE'] . (($this->request->is_ajax()) ? '' : adm_back_link($this->u_action)), E_USER_NOTICE);
						}
					}

					$update_to_date = false;
					$versioncheck_force = ($this->auth->acl_get('a_arcade_install') && $versioncheck_force) ? true : false;

					if ($this->arcade_config['version_check_enable'] || $versioncheck_force)
					{
						$update_to_date = $this->arcade->container('version_check')->main('jv/arcade', $this->u_action, $versioncheck_force, true);
					}

					$arcade_version = ((($this->auth->acl_get('a_arcade_install') && $this->arcade_config['version_check_enable']) || ($versioncheck_force)) ? '<strong style="color:#'. (($update_to_date) ? '228822' : 'BC2A4D') .';">' . $this->arcade_config['version'] : '<strong>' . $this->arcade_config['version']) . '</strong>';

					$install_verify = '';
					if ($this->auth->acl_get('a_arcade_install'))
					{
						$verify_link	= append_sid("{$this->admin_path}index.{$this->php_ext}", $this->arcade->module_url('install') . '&amp;mode=install_verify');
						$install_verify = '[ <a href="'. $verify_link .'" title="'. $this->user->lang['ACP_ARCADE'] .' - '. $this->user->lang['ACP_ARCADE_INSTALL_VERIFY'] .'">'. $this->user->lang['ACP_ARCADE_INSTALL_VERIFY'] .'</a> ]';
					}

					$this->template->assign_vars(array(
						'S_USER_FOUNDER'					=> $user_founder,
						'S_ARCADE_INSTALL'					=> $this->auth->acl_get('a_arcade_install'),
						'S_ARCADE_VC'						=> ($this->arcade_config['version_check_enable']) ? true : false,
						'S_ARCADE_MANAGE'					=> ($this->auth->acl_get('a_arcade')) ? true : false,
						'S_GAMES_USERS_MANAGE'				=> ($this->auth->acl_gets('a_arcade_game', 'a_arcade_user')) ? true : false,
						'S_USERS_MANAGE'					=> ($this->auth->acl_get('a_arcade_user')) ? true : false,
						'S_SHOW_POINTS'						=> ($this->arcade->points->data['installed'] && $this->auth->acl_get('a_arcade_points_settings')) ? true : false,

						'U_ACTION'							=> $this->u_action,
						'U_VERSIONCHECK'					=> $this->u_action . '&amp;action=version_check',
						'U_VERSIONCHECK_FORCE'				=> $this->u_action . '&amp;versioncheck_force=1',
						'U_USERS_DEFAULT_SETTINGS'			=> $this->u_action . '&amp;action=users_default_settings',

						'ACP_ARCADE_TERM_OF_USE'			=> '[ <a href="'. $this->u_action . '&amp;action=term_of_use' .'">'. $this->user->lang['ACP_ARCADE_TERM_OF_USE'] .'</a> ]',
						'ARCADE_INSTALL_VERIFY'				=> $install_verify,
						'ARCADE_START'						=> $this->user->format_date($this->arcade_config['arcade_startdate']),
						'STAT_INSTALL_GAMES'				=> $this->arcade->number_format(intval($this->arcade_config['install_games'])),
						'STAT_DOWNLOAD_GAMES'				=> $this->arcade->number_format(intval($this->arcade_config['total_downloads'])),
						'STAT_DOWNLOAD_GAMES_DAY'			=> $this->data_per_day($this->arcade_config['total_downloads']),
						'STAT_PLAYS_GAMES'					=> $this->arcade->number_format(intval($this->arcade_config['total_plays'])),
						'STAT_PLAYS_GAMES_DAY'				=> $this->data_per_day($this->arcade_config['total_plays']),
						'CHALLENGE_STAT_PLAYS_GAMES'		=> $this->arcade->number_format(intval($this->arcade_config['challenge_total_plays'])),
						'CHALLENGE_STAT_PLAYS_GAMES_DAY'	=> $this->data_per_day($this->arcade_config['challenge_total_plays'], 'challenge'),
						'STAT_USERS_PLAYED'					=> $this->arcade->number_format(intval($this->arcade->get->total('user', 'played_users'))),
						'CHALLENGE_STAT_USERS_PLAYED'		=> $this->arcade->number_format(intval($this->arcade->get->total('user', 'challenge_played_users'))),
						'ARCADE_RESETDATE'					=> $this->arcade_config['arcade_resetdate'] ? $this->user->format_date($this->arcade_config['arcade_resetdate']) : $this->user->lang['ACP_ARCADE_RESET_NO_DATE'],
						'CHALLENGE_RESETDATE'				=> $this->user->format_date($this->arcade_config['challenge_resetdate']),
						'STATS_FINISHED_TOURS'				=> (!empty($this->arcade_config['tour_total'])) ? $this->arcade->number_format(intval($this->arcade_config['tour_total'])) : 0,
						'STATS_TOUR_USERS_PLAYED'			=> (!empty($this->arcade_config['tour_total'])) ? $this->arcade->number_format(intval($this->arcade->get->total('user', 'tour_played_users'))) : 0,
						'ARCADE_VERSION'					=> ($this->auth->acl_get('a_arcade_install')) ? '<a href="' . $this->u_action . '&amp;action=version_check' . '" title="' . $this->user->lang['MORE_INFORMATION'] . '">' . $arcade_version . '</a>&nbsp;[&nbsp;<a href="' . $this->u_action . '&amp;versioncheck_force=1' . '">' . $this->user->lang['VERSIONCHECK_FORCE_UPDATE'] . '</a>&nbsp;]' : $arcade_version,
						'ARCADE_GAMES_FILESIZE'				=> get_formatted_filesize($this->arcade_cache->obtain_arcade_games_filesize()),

						'L_ARCADE_FINISHED_TOURS'			=> $this->user->lang['ARCADE_FINISHED_TOUR' . (($this->arcade_config['tour_total'] > 1) ? 'S' : '')]
					));

					if ($this->config['cookie_secure'] && $this->arcade_config['cookie_secure_info_time'] < $this->actual_time && $this->arcade_config['activation_key'] && !$this->request->is_set('new_activation_key'))
					{
						$cookie_set = ($this->auth->acl_get('a_server')) ? '<br>' . sprintf($this->user->lang['ARCADE_COOKIE_SECURE_LINK'], '<a href="' . append_sid("{$this->admin_path}index.{$this->php_ext}", 'i=board&amp;mode=cookie') . '">', '</a>') : '';

						$this->template->assign_vars(array(
							'S_COOKIE_CLOSE_BUTTON'	=> true,
							'U_CLOSE_COOKIE_INFO'	=> $this->u_action . '&amp;action=close_cookie'
						));

						$notice[] = $this->user->lang['ARCADE_COOKIE_SECURE_NOTICE'] . $cookie_set;
					}
				}

				if (count($notice))
				{
					$this->template->assign_vars(array(
						'S_ARCADE_NOTICE'	=> true,

						'ARCADE_NOTICE'		=> implode('<br><br>', $notice)
					));
				}
			break;

			case 'term_of_use':
				$mode_title_disable = true;
				$this->page_title = 'ACP_ARCADE_TERM_OF_USE';

				$s_content_flow_begin = ($this->user->lang['DIRECTION'] == 'ltr') ? 'left' : 'right';
				$back = '<br><br><a href="' . $this->u_action . '" style="float: ' . $s_content_flow_begin . ';">&laquo; ' . $this->user->lang['BACK'] . '</a>';

				$this->template->assign_vars(array(
					'S_ARCADE_USE_ONLY_DESC'	=> true,
					'L_ARCADE_TITLE'			=> $this->user->lang[$this->page_title],
					'L_ARCADE_TITLE_EXPLAIN'	=> sprintf($this->user->lang[$this->page_title . '_EXPLAIN'], $this->arcade_config['support_domain']) . $back
				));
			break;

			case 'version_check':
				$this->page_title = 'ACP_VERSION_CHECK';
				$this->tpl_name = 'arcade/version_check';

				$this->arcade->container('version_check')->main('jv/arcade', $this->u_action, $versioncheck_force);
			break;

			case 'users_default_settings':
				$this->page_title = 'ACP_ARCADE_USERS_DEFAULT_SETTINGS_TITLE';

				if ($this->arcade->is_post_empty('update'))
				{
					$this->arcade_config->set('default_cat_style', (int) $this->request->variable('arcade_cat_style', 0));
					$this->arcade_config->set('default_cat_games_style', (int) $this->request->variable('arcade_cat_games_style', 0));
					$this->arcade_config->set('arcade_cat_size', $this->request->variable('cat_size', 'small'));
					$this->arcade_config->set('override_user_cat_style', (($this->request->variable('override_cat_style', false)) ? 1 : 0));
					$this->arcade_config->set('default_games_sort_order', $this->request->variable('games_sort_order', 'n'));
					$this->arcade_config->set('default_games_sort_dir', $this->request->variable('games_sort_dir', 'a'));

					$this->arcade->add_log('admin', 'LOG_ARCADE_USERS_DEFAULT_SETTINGS');
					trigger_error($this->user->lang['CONFIG_UPDATED'] . adm_back_link($this->u_action . '&amp;action=users_default_settings'), E_USER_NOTICE);
				}

				$this->user->add_lang('acp/board');
				$this->user->add_lang_ext('jv/arcade', 'info_ucp_arcade');

				$s_hidden_fields = build_hidden_fields(array(
					'action' => 'users_default_settings'
				));

				$this->template->assign_vars(array(
					'S_USERS_DEFAULT_SETTINGS'	=> true,
					'S_OVERRIDE_STYLE'			=> ($this->arcade_config['override_user_cat_style']) ? true : false,
					'S_HIDDEN_FIELDS'			=> $s_hidden_fields,
					'S_CAT_SIZE'				=> $this->arcade_config['arcade_cat_size'],

					'ARCADE_CAT_STYLES'			=> $this->arcade->select_cat_styles($this->arcade_config['default_cat_style']),
					'ARCADE_CAT_GAMES_STYLES'	=> $this->arcade->select_cat_styles($this->arcade_config['default_cat_games_style']),
					'GAMES_SORT_ORDER'			=> $this->arcade->select_games_sort_order($this->arcade_config['default_games_sort_order']),
					'GAMES_SORT_DIR'			=> $this->arcade->select_games_sort_dir($this->arcade_config['default_games_sort_dir'])
				));
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		if (!$mode_title_disable)
		{
			$this->template->assign_vars(array(
				'L_ARCADE_TITLE'			=> $this->user->lang['ACP_ARCADE_' . strtoupper($mode) . '_TITLE'],
				'L_ARCADE_TITLE_EXPLAIN'	=> $this->user->lang['ACP_ARCADE_' . strtoupper($mode) . '_TITLE_EXPLAIN']
			));
		}
	}

	protected function reset($action)
	{
		switch ($action)
		{
			case 'reset_arcade':
				$retain_super_champion = ($this->request->variable('retain_super_champion', false)) ? true : false;

				$delete_tables = array(ARCADE_FAVS_TABLE, ARCADE_RATING_TABLE, ARCADE_DOWNLOAD_TABLE);

				if (!$retain_super_champion)
				{
					$delete_tables[] = ARCADE_SUPER_SCORES_TABLE;
				}

				$this->arcade->delete_table_data($delete_tables);

				$sql_ary = array(
					'game_votetotal'		=> 0,
					'game_download_total'	=> 0,
					'game_votesum'			=> 0,
					'game_download_cost'	=> 0,
					'game_cost'				=> 0,
					'game_reward'			=> 0,
					'game_jackpot'			=> (float) $this->arcade_config['jackpot_minimum'],
					'game_use_jackpot'		=> 0,
				);

				$this->arcade_config->set('total_downloads', 0, false);

			case 'reset_playing_record':
				$this->arcade_config->set('record_playing_users', 0, false);
				$this->arcade_config->set('record_playing_date', $this->actual_time, false);

				if ($action == 'reset_playing_record')
				{
					break;
				}
			case 'reset_scores_all':
				$retain_plays = ($action == 'reset_scores_all' && $this->request->variable('retain_plays', false)) ? true : false;

				$delete_tables = array(ARCADE_SCORES_TABLE);

				if (!$retain_plays)
				{
					$delete_tables[] = ARCADE_PLAYS_TABLE;
				}

				$this->arcade->delete_table_data($delete_tables);

				if (!$retain_plays)
				{
					$sql_ary['game_plays'] = 0;
				}

				$sql_ary['game_highscore']	= 0;
				$sql_ary['game_highuser']	= 0;
				$sql_ary['game_highdate']	= 0;

				$sql = 'UPDATE ' . ARCADE_GAMES_TABLE. '
						SET ' . $this->db->sql_build_array('UPDATE', $sql_ary);
				$this->db->sql_query($sql);

				$sql_ary = array(
					'cat_last_play_game_id'			=> 0,
					'cat_last_play_game_name'		=> '',
					'cat_last_play_user_id'			=> 0,
					'cat_last_play_score'			=> 0,
					'cat_last_play_time'			=> 0,
					'cat_last_play_username'		=> '',
					'cat_last_play_user_colour'		=> '',
				);

				if (!$retain_plays)
				{
					$sql_ary['cat_plays'] = 0;
				}

				if ($action == 'reset_arcade')
				{
					$sql_ary['cat_download_cost'] = 0;
					$sql_ary['cat_cost'] = 0;
					$sql_ary['cat_reward'] = 0;
					$sql_ary['cat_use_jackpot'] = 0;
				}

				$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
						SET ' . $this->db->sql_build_array('UPDATE', $sql_ary);
				$this->db->sql_query($sql);

				$this->arcade->sync('category');

				if (!$retain_plays)
				{
					$this->arcade_config->set('total_plays', 0, false);
					$this->arcade_config->set('total_plays_time', 0, false);
					$this->arcade_config->set('arcade_resetdate', $this->actual_time);
				}

				$sql = "UPDATE " . ARCADE_USERS_TABLE . '
						SET arcade_total_wins = 0';

				if ($action == 'reset_arcade')
				{
					$sql .= ', games_last_search = 0, games_last_search_term = "", user_arcade_last_download = 0, arcade_total_downloads = 0';

					if (!$retain_super_champion)
					{
						$sql .= ', arcade_total_super_scores = 0';
					}
				}

				if (!$retain_plays)
				{
					$sql .= ', user_arcade_last_play = 0, arcade_total_played = 0, arcade_total_plays = 0, arcade_total_time = 0';
				}

				$this->db->sql_query($sql);

				$this->arcade->cache_purge();
			break;

			case 'reset_users_data':
				$this->arcade->delete_table_data(array(ARCADE_FAVS_TABLE, ARCADE_RATING_TABLE));

				$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
						SET game_votetotal = 0, game_votesum = 0';
				$this->db->sql_query($sql);
			break;

			case 'reset_users_settings':
				$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
						SET ' . $this->db->sql_build_array('UPDATE', $this->arcade->user_default_settings()) . '
						WHERE user_id <> ' . ANONYMOUS;
				$this->db->sql_query($sql);
/*
				// default settings guest user
				$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
						SET ' . $this->db->sql_build_array('UPDATE', arcade_user_default_settings(ANONYMOUS)) . '
						WHERE user_id = ' . ANONYMOUS;
				$this->db->sql_query($sql);
*/
			break;

			case 'reset_downloads':
				$this->arcade->delete_table_data(ARCADE_DOWNLOAD_TABLE);

				$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
						SET game_download_total = 0';
				$this->db->sql_query($sql);

				$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
						SET user_arcade_last_download = 0, arcade_total_downloads = 0';
				$this->db->sql_query($sql);

				$this->arcade_config->set('total_downloads', 0, false);
			break;

			case 'reset_points':
				$sql_ary = array(
					'cat_download_cost'	=> 0,
					'cat_cost'			=> 0,
					'cat_reward'		=> 0,
					'cat_use_jackpot'	=> 0,
				);

				$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
					SET ' . $this->db->sql_build_array('UPDATE', $sql_ary);
				$this->db->sql_query($sql);

				$sql_ary = array(
					'game_download_cost'	=> 0,
					'game_cost'				=> 0,
					'game_reward'			=> 0,
					'game_use_jackpot'		=> 0,
				);

				$this->arcade->cache_purge();
			case 'reset_jackpot':
				$sql_ary['game_jackpot'] = (float) $this->arcade_config['jackpot_minimum'];

				$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
						SET ' . $this->db->sql_build_array('UPDATE', $sql_ary);
				$this->db->sql_query($sql);
			break;

			case 'purge_sessions':
				$this->arcade->delete_table_data(array(ARCADE_ACCESS_TABLE, ARCADE_SESSIONS_TABLE));
			break;

			case 'reset_challenge':
				$this->arcade->delete_table_data(array(ARCADE_CHALLENGE_TABLE, ARCADE_CHALLENGE_CHAMP_TABLE));

				$this->arcade_config->set('challenge_resetdate', $this->actual_time);
				$this->arcade_config->set('challenge_total_plays', 0, false);
				$this->arcade_config->set('challenge_total_plays_time', 0, false);

				$this->cache->destroy('sql', ARCADE_CHALLENGE_CHAMP_TABLE);

				$this->cache->destroy('_arcade_challenge_leaders');
				$this->cache->destroy('_arcade_challenge_leaders_all');
			break;

			case 'reset_comment':
				$sql_ary = array(
					'comment_text'		=> '',
					'comment_bitfield'	=> '',
					'comment_options'	=> 0,
					'comment_uid'		=> ''
				);

				$sql = 'UPDATE ' . ARCADE_SCORES_TABLE . '
						SET ' . $this->db->sql_build_array('UPDATE', $sql_ary);
				$this->db->sql_query($sql);
			break;

			case 'reset_super_champion':
				$sql = 'SELECT g.game_id
						FROM ' . ARCADE_GAMES_TABLE . ' g
						LEFT JOIN ' . ARCADE_SUPER_SCORES_TABLE . ' s ON g.game_id = s.game_id
						WHERE g.game_highscore <> s.score';
				$result = $this->db->sql_query($sql);
				$game_ids = array();
				while ($row = $this->db->sql_fetchrow($result))
				{
					$game_ids[] = (int) $row['game_id'];
				}
				$this->db->sql_freeresult($result);

				if (count($game_ids))
				{
					$sql = 'DELETE FROM ' . ARCADE_SUPER_SCORES_TABLE . '
							WHERE ' . $this->db->sql_in_set('game_id', $game_ids);
					$this->db->sql_query($sql);

					$this->arcade->sync('super_champ', $game_ids);
					$this->arcade->sync('users_total_data');
					$this->arcade->cache_purge('score');
				}
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}
	}

	public function data_per_day($data, $type = '')
	{
		$date = intval(($type == 'challenge') ? $this->arcade_config['challenge_resetdate'] : (($this->arcade_config['arcade_resetdate']) ? $this->arcade_config['arcade_resetdate'] : $this->arcade_config['arcade_startdate']));

		$arcadedays = ($this->actual_time - $date) / 86400;
		$arcadedays = ($arcadedays <= 0) ? 1 : $arcadedays;
		$data_per_day = sprintf('%.2f', $data / $arcadedays);

		if ($data_per_day > $data)
		{
			$data_per_day = sprintf('%.2f', $data);
		}

		return $data_per_day;
	}
}
