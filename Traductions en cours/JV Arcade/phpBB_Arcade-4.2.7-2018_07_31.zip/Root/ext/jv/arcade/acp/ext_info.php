<?php
/**
*
* @package phpBB Arcade
* @version $Id: ext_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class ext_module_info
{
	function module()
	{
		return array(
			'filename'		=> '\jv\arcade\acp\ext_module',
			'title'			=> 'ACP_ARCADE_SETTINGS',
			'modes'			=> array(
				'settings'	=> array('title' => 'ACP_ARCADE_SETTINGS_EXT', 'auth' => 'ext_jv/arcade && (acl_a_arcade_settings || acl_a_arcade_install)', 'cat' => array('ACP_CAT_ARCADE_SETTINGS'), 'after' => 'ACP_ARCADE_SETTINGS_GENERAL')
			)
		);
	}
}
