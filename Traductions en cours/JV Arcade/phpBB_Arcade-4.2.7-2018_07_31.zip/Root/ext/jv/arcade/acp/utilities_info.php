<?php
/**
*
* @package phpBB Arcade
* @version $Id: utilities_info.php 2035 2018-07-25 11:10:48Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class utilities_info
{
	function module()
	{
		return array(
			'filename'				=> '\jv\arcade\acp\utilities_module',
			'title'					=> 'ACP_ARCADE_UTILITIES',
			'modes'					=> array(
				'reports'			=> array('title' => 'ACP_ARCADE_UTILITIES_REPORTS'			, 'auth' => 'ext_jv/arcade && acl_a_arcade_utilities'				, 'cat' => array('ACP_CAT_ARCADE_UTILITIES')),
				'deleted_games'		=> array('title' => 'ACP_ARCADE_UTILITIES_DELETED_GAMES'	, 'auth' => 'ext_jv/arcade && acl_a_arcade_utilities'				, 'cat' => array('ACP_CAT_ARCADE_UTILITIES'), 'after' => 'ACP_ARCADE_UTILITIES_REPORTS'),
				'users_banned'		=> array('title' => 'ACP_ARCADE_UTILITIES_USERS_BANNED'		, 'auth' => 'ext_jv/arcade && (acl_a_arcade || acl_a_arcade_user)'	, 'cat' => array('ACP_CAT_ARCADE_UTILITIES')),
				'download_stats'	=> array('title' => 'ACP_ARCADE_UTILITIES_DOWNLOAD_STATS'	, 'auth' => 'ext_jv/arcade && acl_a_arcade_utilities'				, 'cat' => array('ACP_CAT_ARCADE_UTILITIES')),
				'create_install'	=> array('title' => 'ACP_ARCADE_UTILITIES_CREATE_INSTALL'	, 'auth' => 'ext_jv/arcade && acl_a_arcade_utilities'				, 'cat' => array('ACP_CAT_ARCADE_UTILITIES')),
				'user_guide'		=> array('title' => 'ACP_ARCADE_UTILITIES_USER_GUIDE'		, 'auth' => 'ext_jv/arcade'											, 'cat' => array('ACP_CAT_ARCADE_UTILITIES')),
			)
		);
	}
}
