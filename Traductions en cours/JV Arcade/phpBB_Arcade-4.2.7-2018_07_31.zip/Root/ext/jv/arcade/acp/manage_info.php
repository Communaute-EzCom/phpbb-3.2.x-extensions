<?php
/**
*
* @package phpBB Arcade
* @version $Id: manage_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class manage_info
{
	function module()
	{
		return array(
			'filename'			=> '\jv\arcade\acp\manage_module',
			'title'				=> 'ACP_ARCADE_MANAGE',
			'modes'				=> array(
				'category'		=> array('title' => 'ACP_ARCADE_MANAGE_CATEGORIES'	, 'auth' => 'ext_jv/arcade && acl_a_arcade_cat'	, 'cat' => array('ACP_CAT_ARCADE_MANAGE')),
				'games'			=> array('title' => 'ACP_ARCADE_MANAGE_GAMES'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_game', 'cat' => array('ACP_CAT_ARCADE_MANAGE')),
				'users'			=> array('title' => 'ACP_ARCADE_MANAGE_USERS'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_user', 'cat' => array('ACP_CAT_ARCADE_MANAGE')),
				'challenges'	=> array('title' => 'ACP_ARCADE_MANAGE_CHALLENGES'	, 'auth' => 'ext_jv/arcade && acl_a_arcade_user', 'cat' => array('ACP_CAT_ARCADE_MANAGE'), 'display' => false),
				'tournament'	=> array('title' => 'ACP_ARCADE_MANAGE_TOUR'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_tour', 'cat' => array('ACP_CAT_ARCADE_MANAGE'))
			)
		);
	}
}
