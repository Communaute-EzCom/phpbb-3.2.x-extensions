<?php
/**
*
* @package phpBB Arcade
* @version $Id: settings_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class settings_info
{
	function module()
	{
		return array(
			'filename'			=> '\jv\arcade\acp\settings_module',
			'title'				=> 'ACP_ARCADE_SETTINGS',
			'modes'				=> array(
				'settings'		=> array('title' => 'ACP_ARCADE_SETTINGS_GENERAL'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'game'			=> array('title' => 'ACP_ARCADE_SETTINGS_GAME'			, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'challenge'		=> array('title' => 'ACP_ARCADE_SETTINGS_CHALLENGE'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'tournament'	=> array('title' => 'ACP_ARCADE_SETTINGS_TOUR'			, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'feature'		=> array('title' => 'ACP_ARCADE_SETTINGS_FEATURE'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'apage'			=> array('title' => 'ACP_ARCADE_SETTINGS_ARCADE_PAGE'	, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'cpage'			=> array('title' => 'ACP_ARCADE_SETTINGS_CHALLENGE_PAGE', 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'tpage'			=> array('title' => 'ACP_ARCADE_SETTINGS_TOUR_PAGE'		, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'path'			=> array('title' => 'ACP_ARCADE_SETTINGS_PATH'			, 'auth' => 'ext_jv/arcade && acl_a_arcade_settings'				, 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'load'			=> array('title' => 'ACP_ARCADE_SETTINGS_LOAD'			, 'auth' => 'ext_jv/arcade && acl_a_arcade && acl_a_arcade_settings', 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
				'paar'			=> array('title' => 'ACP_ARCADE_SETTINGS_PAAR'			, 'auth' => 'ext_jv/arcade && acl_a_arcade && acl_a_arcade_settings', 'cat' => array('ACP_CAT_ARCADE_SETTINGS')),
			)
		);
	}
}
