<?php
/**
*
* @package phpBB Arcade
* @version $Id: main_manage_module.php 1982 2018-05-28 22:10:35Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class main_manage_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;
	private $parent_id = 0;

	protected $admin_path;
	protected $db, $cache, $config, $request, $user, $template, $root_path, $php_ext;
	protected $arcade_config, $arcade;

	public function __construct()
	{
		global $phpbb_admin_path;
		global $db, $cache, $config, $request, $user, $template, $phpbb_root_path, $phpEx;
		global $arcade_config, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade = $arcade->container('admin', true);
		$arcade->auth_check();

		$this->admin_path = $phpbb_admin_path;
		$this->db = $db;
		$this->cache = $cache;
		$this->config = $config;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	public function main($id, $mode)
	{
		$time				= time();
		$errors				= array();
		$this->tpl_name		= 'arcade/acp_main_manage';
		$action				= $this->request->variable('action', '');
		$submit				= $this->arcade->is_post_empty('submit');
		$update				= ($this->request->variable('update', false)) ? true : false;
		$start				= (int) $this->request->variable('start', 0);
		$this->arcade->valid_start($start);

		switch ($mode)
		{
			case 'menu':
				$form_key = 'acp_arcade_menu';
				add_form_key($form_key);
				$arcade_menu = $this->arcade->container('menu');

				$main_menu = $arcade_menu->obtain_menu(true);

				$return				= false;
				$menu_data			= array();
				$menu_id			= (int) $this->request->variable('m', 0);
				$this->parent_id	= (int) $this->request->variable('parent_id', 0);

				$this->template->assign_var('S_MANAGE_MENU', true);

				switch ($action)
				{
					case 'edit':
						$page_title = 'EDIT_MENU';
						$this->page_title = $page_title;
						$l_title = $this->user->lang[$page_title];

						$menu_data = array('menu_id' => $menu_id);
					case 'add':
						if ($action == 'add')
						{
							$page_title = 'CREATE_MENU';
							$this->page_title = $page_title;
							$l_title = $this->user->lang[$page_title];
						}

						$this->parent_id = (int) $this->request->variable('menu_parent_id', $this->parent_id);

						$menu_data += array(
							'menu_name'		=> $this->request->variable('menu_name', '', true),
							'menu_display'	=> (bool) $this->request->variable('menu_display', true),
							'new_window'	=> (bool) $this->request->variable('new_window', false),
							'menu_fa'		=> $this->request->variable('menu_fa', ''),
							'menu_page'		=> $this->request->variable('menu_page', ''),
							'menu_top'		=> $this->request->variable('menu_top', ''),
							'parent_id'		=> $this->parent_id,
							'params'		=> str_replace(array('"', '&quot;', '&#34;'), "'", $this->request->variable('menu_params', '')),
							'auth'			=> str_replace('&amp;', '&', $this->request->variable('menu_auth', ''))
						);

						if ($update)
						{
							if (!check_form_key($form_key))
							{
								$errors[] = $this->user->lang['FORM_INVALID'];
							}
							else
							{
								$errors = $this->update_menu_data($menu_data, $main_menu);
							}

							if (!count($errors))
							{
								$this->cache->destroy('_arcade_menu');

								$message = ($action == 'add') ? $this->user->lang['ARCADE_MENU_CREATED'] : $this->user->lang['ARCADE_MENU_UPDATED'];

								trigger_error($message . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id));
							}
						}

						$exclude_menu = array($menu_id);
						$select_id = $menu_data['parent_id'];

						if ($action == 'edit')
						{
							$row = $this->get_menu_info($menu_id);

							if (!$update)
							{
								$menu_data = $row;
							}
							else
							{
								$menu_data['menu_type'] = $row['menu_type'];
								$menu_data['left_id'] = $row['left_id'];
								$menu_data['right_id'] = $row['right_id'];
							}

							// Make sure no direct child menu are able to be selected as parents.
							$childs = $this->get_menu_branch($menu_id, 'children');

							foreach ($childs as $child)
							{
								$exclude_menu[] = $child['menu_id'];
							}
						}
						else
						{
							$select_id = $this->parent_id;
						}

						$menu_list = '';
						if (empty($menu_data['menu_type']))
						{
							$level = 1;
							$right = 0;
							$padding = '';
							$num_store = $padding_store = array('0' => '');

							$sm1 = $sm2 = $sm3 = 0;
							$this->get_sub_menu($main_menu, $menu_data, $sm1, $sm2, $sm3);
							$menu_level = ($sm3) ? (($menu_data['parent_id']) ? 3 : 4) : (($sm2) ? 3 : (($sm1) ? 2 : 1));

							$sql = 'SELECT menu_id, menu_name, menu_page, parent_id, left_id, right_id
									FROM ' . ARCADE_MENU_TABLE . '
									ORDER BY left_id ASC';
							$result = $this->db->sql_query($sql);
							while ($row = $this->db->sql_fetchrow($result))
							{
								if ($row['left_id'] < $right)
								{
									$level++;
									$padding .= '&nbsp; &nbsp;';
									$num_store[$row['parent_id']] = $level;
									$padding_store[$row['parent_id']] = $padding;
								}
								else if ($row['left_id'] > $right + 1)
								{
									if (isset($padding_store[$row['parent_id']]))
									{
										$level = $num_store[$row['parent_id']];
										$padding = $padding_store[$row['parent_id']];
									}
									else
									{
										$level = 1;
										$padding = '';
									}
								}

								$right = $row['right_id'];
								$level = ($level) ? $level : 1;

								$max_level = 4;
								$total_level = $menu_level + $level;
								$disabled = ($max_level < $total_level || in_array($row['menu_id'], $exclude_menu));

								$selected = ($row['menu_id'] == $select_id) ? ' selected="selected"' : false;
								$menu_list .= '<option value="' . $row['menu_id'] . '"' . (($selected) ? $selected : (($disabled) ? ' disabled="disabled" class="disabled-option"' : '')) . '>' . $padding . $this->arcade->lang_value($row['menu_name']) . '</option>';
							}
							$this->db->sql_freeresult($result);
							unset($num_store, $padding_store);
						}

						$this->template->assign_vars(array(
							'S_ADD_MENU'		=> true,
							'S_SELECT_MENU'		=> ($menu_list) ? true : false,
							'S_DEFAULT_MENU'	=> !empty($menu_data['menu_type']),
							'S_MENU_PARENT_ID'	=> $menu_data['parent_id'],
							'S_PARENT_OPTIONS'	=> $menu_list,
							'S_DISPLAY_MENU'	=> $menu_data['menu_display'],
							'S_OPEN_NEW_WINDOW'	=> $menu_data['new_window'],
							'S_MENU_ONCLICK'	=> ($menu_data['menu_page'] == 'onclick' || $menu_data['menu_page'] == 'data-jvarcade') ? true : false,
							'S_MENU_PAGE'		=> ($menu_data['menu_page']) ? true : false,
							'S_MENU_NAME'		=> $this->arcade->lang_value($menu_data['menu_name']),

							'L_MENU_FA_EXPLAIN'	=> sprintf($this->user->lang['ARCADE_MENU_FA_EXPLAIN'], '<a href="https://www.w3schools.com/icons/fontawesome_icons_webapp.asp" onclick="window.open(this.href); return false;">', '</a>'),

							'U_ACTION'			=> $this->u_action . "&amp;action=$action" . (($action == 'edit') ? "&amp;parent_id={$this->parent_id}&amp;m=$menu_id" : ''),
							'MENU_NAME'			=> $menu_data['menu_name'],
							'MENU_FA'			=> $menu_data['menu_fa'],
							'MENU_PAGE'			=> $menu_data['menu_page'],
							'MENU_PARAMS'		=> $menu_data['params'],
							'MENU_TOP'			=> $menu_data['menu_top'],
							'MENU_AUTH'			=> $menu_data['auth']
						));

						$return = true;
					break;

					case 'move_up':
					case 'move_down':
						if (!$menu_id)
						{
							trigger_error($this->user->lang['NO_ARCADE_MENU_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						$sql = 'SELECT *
								FROM ' . ARCADE_MENU_TABLE . '
								WHERE menu_id = ' . (int) $menu_id . '
								AND parent_id = ' . (int) $this->parent_id;
						$result = $this->db->sql_query($sql);
						$row = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);

						if (!$row)
						{
							trigger_error($this->user->lang['NO_ARCADE_MENU_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						$move_menu_name = $this->move_menu_by($row, $action);

						if ($move_menu_name !== false)
						{
							$this->cache->destroy('_arcade_menu');
							$this->arcade->add_log('admin', 'LOG_ARCADE_MENU_' . strtoupper($action), $row['menu_name'], $move_menu_name);
						}
					break;

					case 'delete':
						$menu_data = $this->get_menu_info($menu_id);

						if (!$menu_data || $menu_data['menu_type'])
						{
							$menu_data = false;
						}

						if (!$menu_data)
						{
							trigger_error($this->user->lang['NO_ARCADE_MENU_ID'] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id), E_USER_WARNING);
						}

						if (confirm_box(true))
						{
							$ls = $this->delete_menu($menu_data);

							$this->cache->destroy('_arcade_menu');
							$this->arcade->add_log('admin', "LOG_ARCADE_MENU{$ls}_DELETE", $menu_data['menu_name']);
							trigger_error($this->user->lang["ARCADE_MENU{$ls}_DELETED"] . adm_back_link($this->u_action . '&amp;parent_id=' . $this->parent_id));
						}
						else
						{
							$menu_ids	= array($menu_data['menu_id']);
							$rows		= $this->get_menu_branch($menu_data['menu_id'], 'children', 'descending', false);

							foreach ($rows as $row)
							{
								if (!$row['menu_type'])
								{
									$menu_ids[] = $row['menu_id'];
								}
							}

							$s_hidden_fields = array(
								'action'	=> $action,
								'm'			=> $menu_id,
							);

							confirm_box(false, 'ARCADE_MENU' . ((count($menu_ids) > 1) ? 'S' : '') . '_DELETE', build_hidden_fields($s_hidden_fields));
						}
					break;
				}

				if (!$return)
				{
					$page_title = 'ACP_ARCADE_MANAGE_MENU';
					$this->page_title = $page_title;
					$l_title = $this->user->lang[$page_title];
					$l_title_explain = $this->user->lang[$page_title . '_EXPLAIN'];

					if (!$this->parent_id)
					{
						$navigation = $this->user->lang['ARCADE_MAIN_MENU'];
					}
					else
					{
						$navigation = '<a href="' . $this->u_action . '">' . $this->user->lang['ARCADE_MAIN_MENU'] . '</a>';
						$menu_nav = $this->get_menu_branch($this->parent_id, 'parents');
						foreach ($menu_nav as $row)
						{
							if ($row['menu_id'] == $this->parent_id)
							{
								$navigation .= ' -&gt; ' . $this->arcade->lang_value($row['menu_name']);
							}
							else
							{
								$navigation .= ' -&gt; <a href="' . $this->u_action . '&amp;parent_id=' . $row['menu_id'] . '">' . $this->arcade->lang_value($row['menu_name']) . '</a>';
							}
						}
					}

					$sql = 'SELECT *
							FROM ' . ARCADE_MENU_TABLE . '
							WHERE parent_id = ' . (int) $this->parent_id . '
							ORDER BY left_id ASC';
					$result = $this->db->sql_query($sql);

					if ($row = $this->db->sql_fetchrow($result))
					{
						do
						{
							if (!$row['menu_display'])
							{
								$folder_image = '<img src="' . $this->admin_path . 'images/icon_folder_lock.gif" alt="' . $this->user->lang['LOCKED'] . '" title="' . $this->user->lang['LOCKED'] . '">';
							}
							else
							{
								$folder_image = ($row['left_id'] + 1 != $row['right_id']) ? '<img src="' . $this->admin_path . 'images/icon_subfolder.gif" alt="' . $this->user->lang['ARCADE_SUB_MENU'] . '" title="' . $this->user->lang['ARCADE_SUB_MENU'] . '">' : '<img src="' . $this->admin_path . 'images/icon_folder.gif" alt="' . $this->user->lang['ARCADE_MENU'] . '" title="' . $this->user->lang['ARCADE_MENU'] . '">';
							}

							$url = $this->u_action . "&amp;parent_id=$this->parent_id&amp;m=" . (int) $row['menu_id'];

							$sub_menu = $subsub_menu = $subsubsub_menu = 0;
							$this->get_sub_menu($main_menu, $row, $sub_menu, $subsub_menu, $subsubsub_menu);

							$this->template->assign_block_vars('acp_a_menu', array(
								'S_SUB_MENU'		=> ($sub_menu) ? $sub_menu : (($subsub_menu) ? $subsub_menu : $subsubsub_menu),
								'S_DEFAULT_MENU'	=> (!empty($row['menu_type'])) ? true : false,

								'FOLDER'			=> $folder_image,
								'NAME'				=> $this->arcade->lang_value($row['menu_name']),

								'U_MENU'			=> $this->u_action . '&amp;parent_id=' . $row['menu_id'],
								'U_MOVE_UP'			=> $url . '&amp;action=move_up',
								'U_MOVE_DOWN'		=> $url . '&amp;action=move_down',
								'U_EDIT'			=> $url . '&amp;action=edit',
								'U_DELETE'			=> $url . '&amp;action=delete'
							));
						}
						while ($row = $this->db->sql_fetchrow($result));
					}
					$this->db->sql_freeresult($result);

					if ($this->parent_id)
					{
						$row = $this->get_menu_info($this->parent_id);

						if ($row)
						{
							$url = $this->u_action . '&amp;parent_id=' . $this->parent_id . '&amp;m=' . (int) $row['menu_id'];

							$this->template->assign_vars(array(
								'S_NAV_MENU'	=> true,

								'U_EDIT'		=> $url . '&amp;action=edit',
								'U_DELETE'		=> (!empty($row['menu_type'])) ? '' : $url . '&amp;action=delete'
							));
						}
					}

					$s_hidden_fields = build_hidden_fields(array(
						'parent_id' => $this->parent_id,
					));

					$this->template->assign_vars(array(
						'S_HIDDEN_FIELDS'	=> $s_hidden_fields,
						'U_ACTION'			=> $this->u_action,
						'NAVIGATION'		=> $navigation
					));
				}
			break;

			case 'announce':
				$form_key = 'acp_arcade_announce';
				add_form_key($form_key);

				$this->template->assign_vars(array(
					'S_MANAGE_ANNOUNCE'	=> true,
					'U_ACTION'			=> $this->u_action
				));

				$default_announce_lang	= $this->request->variable('default_announce_lang', $this->arcade_config['announce_lang']);
				$announce_lang			= $this->request->variable('announce_lang', $this->user->data['user_lang']);
				$announce_name			= $this->request->variable('announce_name', '');
				$sync_announce			= (bool) $this->request->variable('sync_all_games_announce', false);
				$sync_limit				= (int) $this->request->variable('sync_limit', $this->arcade_config['game_announce_sync_limit']);
				$sync_limit				= ($sync_limit < 5 || $sync_limit > 300) ? 50 : $sync_limit;

				if ($this->arcade->is_post_empty('reset_all_announce'))
				{
					$announce_name = '';
					if (confirm_box(true))
					{
						$this->arcade->create_announce_db(true);
						$this->arcade->add_log('admin', 'LOG_ARCADE_ALL_ANNOUNCE_RESTORE_DEFAULT_DATA');
						trigger_error($this->user->lang['ARCADE_RESTORE_DEFAULT_DATA_SUCCESS'] . adm_back_link($this->u_action));
					}
					else
					{
						if ($this->arcade->is_post_empty('confirm_uid'))
						{
							redirect($this->u_action);
						}

						$s_hidden_fields = array(
							'reset_all_announce' => true,
						);

						confirm_box(false, 'ARCADE_ALL_ANNOUNCE_RESTORE_DEFAULT_DATA', build_hidden_fields($s_hidden_fields));
					}
				}
				else if ($this->arcade_config['game_announce'] && $sync_announce)
				{
					$page_title			= 'ARCADE_GAME_ANNOUNCE_SYNC';
					$this->page_title	= $page_title;
					$l_title			= $this->user->lang[$page_title];

					$game_ids = array();
					$ignore_cat_ids = array_map('intval', explode(',', $this->arcade_config['game_announce_ignore_cats']));

					if (count($ignore_cat_ids))
					{
						foreach ($this->arcade->games as $game_id => $row)
						{
							if (!in_array($row['cat_id'], $ignore_cat_ids))
							{
								$game_ids[] = $game_id;
							}
						}
					}
					else
					{
						$game_ids = array_keys($this->arcade->games);
					}

					$total_games = count($game_ids);

					if ($total_games)
					{
						$game_data = $this->arcade->get->game_cat_data($game_ids, false, 'g.game_name_clean ASC', $sync_limit, $start);
					}

					if (count($this->arcade->games))
					{
						if (!empty($game_data))
						{
							$forum_id = $this->arcade->phpbb()->create_game_announcement($game_data);

							$start += $sync_limit;

							if ($start < $total_games && $sync_limit < $total_games)
							{
								$redirect = $this->u_action . "&amp;announce_name=$announce_name&amp;sync_all_games_announce=true&amp;start=$start";
								$redirect = meta_refresh(3, $redirect);

								$this->template->assign_vars(array(
									'S_GAME_ANNOUNCE_PROCESSING'		=> true,
									'ARCADE_GAME_ANNOUNCE_PROCESSING'	=> sprintf($this->user->lang['ARCADE_GAME_PROCESSING'], $this->arcade->get->image('full', 'img', 'loading2.gif', 'ARCADE_GAME_ANNOUNCE_SYNC', true), $start, $total_games)
								));

								break;
							}

							if ($forum_id)
							{
								$this->arcade->phpbb()->delete_topics_not_existing_games($forum_id);
							}
						}

						if (count($ignore_cat_ids))
						{
							$sql = 'SELECT game_id, topic_id
									FROM ' . ARCADE_GAMES_TABLE . '
									WHERE ' . $this->db->sql_in_set('cat_id', $ignore_cat_ids);
							$result = $this->db->sql_query($sql);
							$game_ids = $topic_ids = array();
							while ($row = $this->db->sql_fetchrow($result))
							{
								$game_ids[] = $row['game_id'];
								$topic_ids[] = $row['topic_id'];
							}
							$this->db->sql_freeresult($result);

							if (count($game_ids))
							{
								$this->arcade->phpbb()->delete_topics($topic_ids);

								$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . "
										SET topic_id = 0, post_id = 0
										WHERE " . $this->db->sql_in_set('game_id', $game_ids);
								$this->db->sql_query($sql);
							}
						}

						$this->arcade->add_log('admin', 'LOG_ARCADE_GAME_ANNOUNCE_SYNC');
						trigger_error($this->user->lang['ARCADE_SYNC_SUCCESS'] . adm_back_link($this->u_action . (($announce_name) ? "&amp;announce_name=$announce_name" : '') . (($announce_lang) ? "&amp;announce_lang=$announce_lang" : '')));
					}
					else
					{
						trigger_error($this->user->lang['ARCADE_NO_INSTALL_GAME'] . adm_back_link($this->u_action . (($announce_name) ? "&amp;announce_name=$announce_name" : '') . (($announce_lang) ? "&amp;announce_lang=$announce_lang" : '')), E_USER_WARNING);
					}
				}

				if (!$update && $announce_name)
				{
					$submit = true;
				}

				if ($this->arcade->is_post_empty('restore_data'))
				{
					if (!$announce_name || !$announce_lang)
					{
						trigger_error($this->user->lang['ARCADE_ANNOUNCE_NO_ID'] . adm_back_link($this->u_action), E_USER_WARNING);
					}

					if (confirm_box(true))
					{
						$lang_dir = $this->arcade->ext_path() . "language/{$announce_lang}/msg/{$announce_name}.txt";

						if (!file_exists($lang_dir))
						{
							$errors[] = $this->arcade->root_key($lang_dir);
						}

						if (count($errors))
						{
							$msg = 'ARCADE_FILE' . ((count($errors) > 1) ? 'S' : '') . '_NOT_FOUND';
							trigger_error(sprintf($this->user->lang[$msg], implode('<br>', $errors)) . adm_back_link($this->u_action . (($announce_name) ? "&amp;announce_name=$announce_name" : '') . (($announce_lang) ? "&amp;announce_lang=$announce_lang" : '')), E_USER_WARNING);
						}
						else
						{
							if (($announce_data = $this->arcade->announce_data($announce_lang, $announce_name)) !== false)
							{
								$announce_id = (int) $announce_data['announce_id'];

								$this->arcade->create_announce_db(false, $announce_lang, $announce_name);
							}

							$log_msg = 'LOG_ARCADE_RESTORE_DEFAULT_DATA_' . ((strpos($announce_name, '_pm') !== false) ? 'PM' : 'ANNOUNCE');
							$this->arcade->add_log('admin', $log_msg, ((strpos($announce_name, 'arcade_') !== false) ? '' : 'ARCADE_') . strtoupper($announce_name));
							trigger_error($this->user->lang['ARCADE_RESTORE_DEFAULT_DATA_SUCCESS'] . adm_back_link($this->u_action . (($announce_name) ? "&amp;announce_name=$announce_name" : '') . (($announce_lang) ? "&amp;announce_lang=$announce_lang" : '')));
						}
					}
					else
					{
						$s_hidden_fields = array(
							'restore_data'	=> true,
							'announce_name'	=> $announce_name,
							'announce_lang'	=> $announce_lang
						);

						confirm_box(false, 'ARCADE_RESTORE_DEFAULT_DATA', build_hidden_fields($s_hidden_fields));
					}
				}

				if (!$submit)
				{
					$page_title			= 'ACP_ARCADE_MANAGE_ANNOUNCE';
					$this->page_title	= $page_title;
					$l_title			= $this->user->lang[$page_title];
					$l_title_explain	= $this->user->lang[$page_title . '_EXPLAIN'];

					$announce_author = $this->request->variable('announce_author', $this->arcade_config['announce_author'], true);
				}

				$sql = 'SELECT lang_iso, lang_local_name FROM ' . LANG_TABLE;
				$result = $this->db->sql_query($sql);
				$lang_row = array();
				while ($row = $this->db->sql_fetchrow($result))
				{
					$lang_row[$row['lang_iso']] = $row['lang_local_name'];
				}
				$this->db->sql_freeresult($result);

				if ($update)
				{
					if (!$default_announce_lang || !in_array($default_announce_lang, array_keys($lang_row)))
					{
						$errors[] = $this->user->lang['WRONG_DATA_LANG'];
					}

					if (!$announce_author)
					{
						//$errors[] = $this->user->lang['NO_USER_SPECIFIED'];
					}
					else if (!($this->arcade->userdata('user_id', false, $announce_author)))
					{
						$errors[] = $this->user->lang['NO_USER'];
					}
				}

				if (count($errors))
				{
					$submit = $update = false;
				}

				if (!$update)
				{
					$this->template->assign_var('S_ANNOUNCE_LANG_OPTIONS', (count($lang_row) > 1) ? language_select(($submit) ? $announce_lang : $default_announce_lang) : '');
				}

				if (!$submit && !$update)
				{
					$s_options = '';
					$def_names = array();
					$new_insert_data = false;
					$announce_ary = $this->arcade->announce_data('', '', true);

					// Start Announcements default database data check, repair.
					$default_announces = $this->arcade->default_announces();

					$sql = 'SELECT COUNT(announce_id) AS total FROM ' . ARCADE_ANNOUNCE_TABLE;
					$result = $this->db->sql_query($sql);
					$total = (int) $this->db->sql_fetchfield('total');
					$this->db->sql_freeresult($result);

					if ($total <> count($default_announces))
					{
						$announce_ary = array();
					}

					if (count($announce_ary) && !empty($announce_ary[$default_announce_lang]))
					{
						foreach ($announce_ary[$default_announce_lang] as $announce_file => $row)
						{
							if (($key = array_search($announce_file, $default_announces)) !== false)
							{
								unset($default_announces[$key]);
							}
						}
					}

					$default_announces = array_filter($default_announces);

					if (!count($announce_ary))
					{
						$this->arcade->create_announce_db(true);
						$new_insert_data = true;
					}
					else if (empty($announce_ary[$default_announce_lang]))
					{
						$this->arcade->create_announce_db(false, $default_announce_lang);
						$new_insert_data = true;
					}
					else if (count($default_announces))
					{
						foreach ($default_announces as $name)
						{
							$this->arcade->create_announce_db(false, $default_announce_lang, $name);
							$new_insert_data = true;
						}
					}

					if ($new_insert_data)
					{
						$announce_ary = $this->arcade->announce_data('', '', true);
					}
					// End Announcements default database data check, repair.

					// sorting
					foreach ($announce_ary[$default_announce_lang] as $announce_file => $row)
					{
						if (in_array($announce_file, $this->arcade->default_announces(false)))
						{
							$prefix = explode('_', $announce_file);
							$prefix = $prefix[0];
							$type = strrchr($announce_file, '_');

							if (!in_array($announce_file, $def_names))
							{
								$def_names[] = $announce_file;
							}

							foreach ($announce_ary[$default_announce_lang] as $announce_file => $row)
							{
								if (in_array($prefix, array('arcade', 'tour', 'challenge')) && !in_array($announce_file, $def_names) && (strpos($announce_file, $prefix) !== false) && (strpos($announce_file, $type) !== false))
								{
									$def_names[] = $announce_file;
								}
							}
						}
					}

					foreach ($def_names as $announce_file)
					{
						$lang_value = 'ARCADE_' . strtoupper(str_replace('arcade_', '', $announce_file));

						if (in_array($announce_file, $this->arcade->default_announces(false)))
						{
							if ($s_options)
							{
								$s_options .= "</optgroup>\n";
							}

							$s = (!in_array($announce_file, array('global_announce', 'game_announce', 'champions_game_announce', 'report_game_announce'))) ? 'S' : '';
							$s_options .= '<optgroup label="' . $this->arcade->lang_value($lang_value . $s) . '">' . "\n";
						}

						$s_options .= '<option value="' . $announce_file . '">&nbsp;&nbsp;&nbsp;&nbsp;' . $this->arcade->lang_value($lang_value) . "</option>\n";
					}

					if ($s_options)
					{
						$s_options .= "</optgroup>\n";
					}

					$this->template->assign_vars(array(
						'S_ANNOUNCE_MANAGE'				=> true,
						'S_ANNOUNCE_OPTIONS'			=> $s_options,

						'S_ANNOUNCE_DEFAULT_LANG'		=> $this->config['default_lang'],
						'ANNOUNCE_AUTHOR'				=> $announce_author,
						'ANNOUNCE_FIND_USERNAME'		=> '[ <a href="'. append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=searchuser&amp;form=acp_arcade_announce&amp;field=announce_author&amp;select_single=true').'" onclick="find_username(this.href); return false;">'. $this->user->lang['FIND_USERNAME'] .'</a> ]'
					));
				}
				else if ($submit)
				{
					$preview = $this->arcade->is_post_empty('preview');
					$use_forum_announces = array('game_announce', 'champions_game_announce', 'tour_announce', 'report_game_announce');

					if (!$announce_name)
					{
						trigger_error($this->user->lang['ARCADE_ANNOUNCE_NO_ID'] . adm_back_link($this->u_action), E_USER_WARNING);
					}
					else if (($announce_data = $this->arcade->announce_data($announce_lang, $announce_name)) === false)
					{
						$this->arcade->create_announce_db(false, $announce_lang, $announce_name);
						$announce_data = $this->arcade->announce_data($announce_lang, $announce_name);
					}

					$announce_id = (int) $announce_data['announce_id'];

					if ($announce_name == 'global_announce')
					{
						$display_global_announce		= (int) $this->request->variable('display_global_announce', $this->arcade_config['display_global_announce']);
						$display_global_announce_author	= $this->request->variable('global_announce_author', $this->arcade_config['display_global_announce_author']);
						$display_global_announce_guest	= $this->request->variable('announce_anonym', $this->arcade_config['display_global_announce_guest']);
						$global_announce_scroll			= $this->request->variable('announce_scroll', $this->arcade_config['global_announce_scroll']);
						$global_announce_scroll_type	= $this->request->variable('announce_scroll_type', $this->arcade_config['global_announce_scroll_type']);
						$global_announce_scroll_speed	= $this->request->variable('announce_scroll_speed', $this->arcade_config['global_announce_scroll_speed']);
					}

					$this->user->add_lang('posting');

					if (in_array($announce_name, $this->arcade->default_announces(false)))
					{
						$announce_enable = $this->request->variable('announce_enable', $this->arcade_config[$announce_name]);
					}

					if (in_array($announce_name, $use_forum_announces))
					{
						$announce_forum = $this->request->variable('announce_forum', $this->arcade_config["{$announce_name}_forum"]);

						if ($announce_name == 'game_announce')
						{
							$ignore_cat_ids = $this->request->variable('announce_ignore_cats', array(0));
							$ignore_cat_ids = array_filter(array_map('intval', (($action) ? $ignore_cat_ids : explode(',', $this->arcade_config['game_announce_ignore_cats']))));
						}
					}

					$title_key = 'ARCADE_MANAGE_' . strtoupper($announce_name);

					$page_title			= $this->arcade->lang_value($title_key);
					$this->page_title	= $page_title;
					$l_title			= $page_title;
					$l_title_explain	= $this->arcade->lang_value($title_key . '_EXPLAIN');

					if ($action || $preview)
					{
						$announce_data = array(
							'user_id'		=> (int) $this->user->data['user_id'],
							'username'		=> $this->user->data['username'],
							'user_colour'	=> $this->user->data['user_colour'],
							'subject'		=> $this->request->variable('announce_title', '', true),
							'message'		=> $this->request->variable('message', '', true),
							'uid'			=> '',
							'bitfield'		=> '',
							'options'		=> 0
						);

						// original message - $announce_message
						$announce_message = $announce_data['message'];
						generate_text_for_storage($announce_data['message'], $announce_data['uid'], $announce_data['bitfield'], $announce_data['options'], $this->request->variable('announce_parse_bbcode', false), $this->request->variable('announce_parse_urls', false), $this->request->variable('announce_parse_smilies', false));

						if ($action)
						{
							if (!check_form_key($form_key))
							{
								trigger_error($this->user->lang['FORM_INVALID'] . adm_back_link($this->u_action), E_USER_WARNING);
							}

							if ($announce_name == 'global_announce')
							{
								if ($display_global_announce != $this->arcade_config['display_global_announce'])
								{
									$this->arcade_config->set('display_global_announce', $display_global_announce);
								}

								if ($display_global_announce_author != $this->arcade_config['display_global_announce_author'])
								{
									$this->arcade_config->set('display_global_announce_author', ($display_global_announce_author) ? 1 : 0);
								}

								if ($display_global_announce_guest != $this->arcade_config['display_global_announce_guest'])
								{
									$this->arcade_config->set('display_global_announce_guest', ($display_global_announce_guest) ? 1 : 0);
								}

								if ($global_announce_scroll != $this->arcade_config['global_announce_scroll'])
								{
									$this->arcade_config->set('global_announce_scroll', ($global_announce_scroll) ? 1 : 0);
								}

								if ($global_announce_scroll_type != $this->arcade_config['global_announce_scroll_type'])
								{
									if (!in_array($global_announce_scroll_type, array('right', 'left', 'down', 'up')))
									{
										$global_announce_scroll_type = 'right';
									}

									$this->arcade_config->set('global_announce_scroll_type', $global_announce_scroll_type);
								}

								if ($global_announce_scroll_speed != $this->arcade_config['global_announce_scroll_speed'])
								{
									$global_announce_scroll_speed = intval(($global_announce_scroll_speed <= 0 || $global_announce_scroll_speed > 99) ? 5 : $global_announce_scroll_speed);
									$this->arcade_config->set('global_announce_scroll_speed', $global_announce_scroll_speed);
								}
							}
							else
							{
								// db send original message
								$announce_data['message'] = $announce_message;
								$announce_data['uid'] = $announce_data['bitfield'] = '';
							}

							$sql_ary = array(
								'user_id'		=> (int) $this->user->data['user_id'],
								'username'		=> (string) $this->user->data['username'],
								'user_colour'	=> (string) $this->user->data['user_colour'],
								'subject'		=> (string) $announce_data['subject'],
								'message'		=> (string) $announce_data['message'],
								'bitfield'		=> (string) $announce_data['bitfield'],
								'options'		=> (int) $announce_data['options'],
								'uid'			=> (string) $announce_data['uid'],
								'announce_date'	=> $time
							);

							$sql = 'UPDATE ' . ARCADE_ANNOUNCE_DATA_TABLE . '
									SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
									WHERE announce_id = ' . $announce_id . "
									AND lang_dir = '" . $announce_lang . "'";
							$this->db->sql_query($sql);

							if ($announce_name == 'challenge_pm')
							{
								$announce_enable = true;
							}

							if (isset($announce_enable) && $announce_enable != $this->arcade_config[$announce_name])
							{
								$this->arcade_config->set($announce_name, ($announce_enable) ? 1 : 0);
							}

							if (in_array($announce_name, $use_forum_announces) && $announce_forum != $this->arcade_config["{$announce_name}_forum"])
							{
								$this->arcade_config->set("{$announce_name}_forum", (int) $announce_forum);
							}

							if ($announce_name == 'game_announce')
							{
								$ignore_cats = implode(',', $ignore_cat_ids);

								if ($ignore_cats != $this->arcade_config['game_announce_ignore_cats'])
								{
									$this->arcade->max_chars($ignore_cats);
									$this->arcade_config->set('game_announce_ignore_cats', $ignore_cats);
								}

								if ($sync_limit != $this->arcade_config['game_announce_sync_limit'])
								{
									$this->arcade_config->set('game_announce_sync_limit', $sync_limit);
								}
							}

							$this->cache->destroy('_arcade_announcement');
							$this->arcade->add_log('admin', 'LOG_ARCADE_' . strtoupper($announce_name), $lang_row[$announce_lang]);
							trigger_error($this->user->lang['ARCADE_ANNOUNCE_UPDATE_SUCCESS'] . adm_back_link($this->u_action . (($announce_name) ? "&amp;announce_name=$announce_name" : '') . (($announce_lang) ? "&amp;announce_lang=$announce_lang" : '')));
						}
					}

					$announce_preview = ($preview) ? generate_text_for_display($announce_data['message'], $announce_data['uid'], $announce_data['bitfield'], $announce_data['options']) : '';

					// Build custom bbcodes array
					if (!function_exists('display_custom_bbcodes'))
					{
						include($this->root_path . 'includes/functions_display.' . $this->php_ext);
					}

					display_custom_bbcodes();

					if (isset($announce_data['message']))
					{
						$c_data = generate_text_for_edit($announce_data['message'], $announce_data['uid'], $announce_data['options']);
					}

					$s_hidden_fields = build_hidden_fields(array(
						'submit'		=> true,
						'announce_name'	=> $announce_name
					));

					$lang_prefix = 'ARCADE_' . strtoupper(str_replace('arcade_', '', $announce_name));
					$this->template->assign_vars(array(
						'S_ANNOUNCE_SETTINGS'				=> (isset($announce_enable)) ? true : false,
						'S_ANNOUNCE_EDIT'					=> true,
						'S_BBCODE_FLASH'					=> true,
						'S_BBCODE_QUOTE'					=> true,
						'S_BBCODE_IMG'						=> true,
						'S_LINKS_ALLOWED'					=> true,
						'S_DISABLED'						=> ($announce_name == 'challenge_pm') ? ' disabled="disabled"' : '',
						'S_ANNOUNCE_ENABLE'					=> (!empty($announce_enable)) ? true : false,
						'S_ANNOUNCE_BBCODE_CHECKED'			=> ($c_data['allow_bbcode']) ? true : false,
						'S_ANNOUNCE_SMILIES_CHECKED'		=> ($c_data['allow_smilies']) ? true : false,
						'S_ANNOUNCE_URLS_CHECKED'			=> ($c_data['allow_urls']) ? true : false,
						'S_HIDDEN_FIELDS'					=> $s_hidden_fields,

						'U_SMILIES'							=> append_sid("{$this->root_path}posting.{$this->php_ext}", 'mode=smilies'),

						'L_ANNOUNCE_ENABLE'					=> $this->arcade->lang_value($lang_prefix),
						'L_ANNOUNCE_EXPLAIN'				=> ($this->arcade->lang_value($lang_prefix . '_EXPLAIN', true)) ? $this->user->lang[$lang_prefix . '_EXPLAIN'] : false,
						'L_ANNOUNCE_SUBJECT'				=> (strpos($announce_name, '_pm') !== false) ? $this->user->lang['SUBJECT'] : $this->user->lang['ARCADE_ANNOUNCE_' . (($announce_name == 'global_announce') ? 'TITLE' : 'SUBJECT')],
						'L_ANNOUNCE_MESSAGE'				=> (strpos($announce_name, '_pm') !== false) ? $this->user->lang['MESSAGE'] : $this->user->lang['ARCADE_ANNOUNCE_' . (($announce_name == 'global_announce') ? 'MESSAGE' : 'POST')],

						'ANNOUNCE_LANG_EDIT'				=> $lang_row[$announce_lang],
						'ANNOUNCE_TITLE'					=> censor_text($announce_data['subject']),
						'ANNOUNCE_TEXT'						=> $c_data['text'],
						'ANNOUNCE_PREVIEW'					=> $announce_preview
					));

					if (in_array($announce_name, $use_forum_announces))
					{
						$this->template->assign_vars(array(
							'S_ANNOUNCE_FORUM'		=> true,

							'SELECT_ANNOUNCE_FORUM'	=> make_forum_select($announce_forum, false, true, true, true, false, false)
						));

						if ($announce_name == 'game_announce')
						{
							$this->template->assign_vars(array(
								'S_GAME_ANNOUNCE'		=> true,
								'ANNOUNCE_SYNC_LIMIT'	=> $sync_limit,
								'SELECT_ANNOUNCE_CATS'	=> $this->arcade->make_cat_select($ignore_cat_ids, false, true, true)
							));
						}
					}
					else if ($announce_name == 'global_announce')
					{
						$display_option_ary = array(
							ARCADE_DISPLAY_EVERY	=> 'ARCADE_EVERY_PAGE',
							ARCADE_DISPLAY_ARCADE	=> 'ARCADE_PAGES',
							ARCADE_DISPLAY_FORUM	=> 'ARCADE_FORUM_PAGES'
						);

						if ($this->arcade->portal->data['show'])
						{
							$display_option_ary += array(
								ARCADE_DISPLAY_PORTAL				=> 'ARCADE_PORTAL_PAGES',
								ARCADE_DISPLAY_EVERY_EXCEPT_PORTAL	=> 'ARCADE_EVERY_PAGE_EXCEPT_PORTAL'
							);
						}

						$scroll_option_ary = array(
							'right'	=> 'ARCADE_LEFT_TO_RIGHT',
							'left'	=> 'ARCADE_RIGHT_TO_LEFT',
							'down'	=> 'ARCADE_TOP_TO_DOWN',
							'up'	=> 'ARCADE_BOTTOM_TO_UP'
						);

						$this->template->assign_vars(array(
							'S_DISPLAY_GLOBAL_ANNOUNCE'			=> true,
							'S_ANNOUNCE_AUTHOR'					=> ($display_global_announce_author) ? true : false,
							'S_ANNOUNCE_ANONYM'					=> ($display_global_announce_guest) ? true : false,
							'S_ANNOUNCE_SCROLL'					=> ($global_announce_scroll) ? true : false,
							'S_ANNOUNCE_DISPLAY_OPTIONS'		=> $this->arcade->build_select($display_option_ary, $display_global_announce),
							'S_ANNOUNCE_SCROLL_TYPE_OPTIONS'	=> $this->arcade->build_select($scroll_option_ary, $global_announce_scroll_type),

							'ANNOUNCE_SCROLL_SPEED'				=> (int) $global_announce_scroll_speed
						));
					}
				}
				else if ($update)
				{
					if ($this->arcade_config['announce_lang'] != $default_announce_lang)
					{
						$this->arcade_config->set('announce_lang', $default_announce_lang);
					}

					if ($this->arcade_config['announce_author'] != $announce_author)
					{
						$this->arcade_config->set('announce_author', $announce_author);
					}

					$this->arcade->add_log('admin', 'LOG_ARCADE_ANNOUNCE_GENERAL_SETTINGS');
					trigger_error($this->user->lang['CONFIG_UPDATED'] . adm_back_link($this->u_action));
				}
			break;

			case 'ranks':
				$action = ($this->arcade->is_post_empty('add')) ? 'add' : $action;
				$action = ($this->arcade->is_post_empty('save')) ? 'save' : $action;
				$rank_id = (int) $this->request->variable('id', 0);

				$page_title = 'ACP_ARCADE_MANAGE_RANKS';
				$this->page_title = $page_title;
				$this->template->assign_var('S_MANAGE_RANKS', true);
				$form_name = 'acp_arcade_ranks';
				add_form_key($form_name);
				$this->user->add_lang('acp/posting');

				switch ($action)
				{
					case 'save':
						if (!check_form_key($form_name))
						{
							trigger_error($this->user->lang['FORM_INVALID']. adm_back_link($this->u_action), E_USER_WARNING);
						}

						$rank_title		= $this->request->variable('title', '', true);
						$special_rank	= $this->request->variable('special_rank', 0);
						$min_records	= ($special_rank) ? 0 : max(0, $this->request->variable('min_records', 0));
						$rank_image		= $this->request->variable('rank_image', '');

						// The rank image has to be a jpg, gif or png
						if ($rank_image != '' && !preg_match('#(\.gif|\.png|\.jpg|\.jpeg)$#i', $rank_image))
						{
							$rank_image = '';
						}

						if (!$rank_title)
						{
							trigger_error($this->user->lang['NO_RANK_TITLE'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						$sql_ary = array(
							'rank_title'		=> $rank_title,
							'rank_special'		=> $special_rank,
							'rank_min'			=> $min_records,
							'rank_image'		=> htmlspecialchars_decode($rank_image)
						);

						if ($rank_id)
						{
							$sql = 'UPDATE ' . ARCADE_RANKS_TABLE . ' SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . " WHERE rank_id = $rank_id";
							$message = $this->user->lang['RANK_UPDATED'];

							$this->arcade->add_log('admin', 'LOG_RANK_UPDATED', $rank_title);
						}
						else
						{
							$sql = 'INSERT INTO ' . ARCADE_RANKS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
							$message = $this->user->lang['RANK_ADDED'];

							$this->arcade->add_log('admin', 'LOG_RANK_ADDED', $rank_title);
						}
						$this->db->sql_query($sql);

						$this->cache->destroy('_arcade_ranks');

						trigger_error($message . adm_back_link($this->u_action));
					break;

					case 'delete':
						if (!$rank_id)
						{
							trigger_error($this->user->lang['MUST_SELECT_RANK'] . adm_back_link($this->u_action), E_USER_WARNING);
						}

						if (confirm_box(true))
						{
							$sql = 'SELECT rank_title
									FROM ' . ARCADE_RANKS_TABLE . '
									WHERE rank_id = ' . $rank_id;
							$result = $this->db->sql_query($sql);
							$rank_title = (string) $this->db->sql_fetchfield('rank_title');
							$this->db->sql_freeresult($result);

							$sql = 'DELETE FROM ' . ARCADE_RANKS_TABLE . "
									WHERE rank_id = $rank_id";
							$this->db->sql_query($sql);

							$sql = 'UPDATE ' . ARCADE_USERS_TABLE . "
									SET user_arcade_rank = 0
									WHERE user_arcade_rank = $rank_id";
							$this->db->sql_query($sql);

							$this->cache->destroy('_arcade_ranks');

							$this->arcade->add_log('admin', 'LOG_RANK_REMOVED', $rank_title);
						}
						else
						{
							confirm_box(false, $this->user->lang['CONFIRM_OPERATION'], build_hidden_fields(array(
								'i'			=> $id,
								'mode'		=> $mode,
								'rank_id'	=> $rank_id,
								'action'	=> 'delete'
							)));
						}
					break;

					case 'edit':
					case 'add':
						$data = $ranks = $existing_imgs = array();

						$sql = 'SELECT *
								FROM ' . ARCADE_RANKS_TABLE . '
								ORDER BY rank_min ASC, rank_special ASC';
						$result = $this->db->sql_query($sql);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$existing_imgs[] = $row['rank_image'];

							if ($action == 'edit' && $rank_id == $row['rank_id'])
							{
								$ranks = $row;
							}
						}
						$this->db->sql_freeresult($result);

						$imglist = filelist($this->arcade->set_image_path('rank'), '');
						$edit_img = $filename_list = '';

						foreach ($imglist as $path => $img_ary)
						{
							sort($img_ary);

							foreach ($img_ary as $img)
							{
								$img = $path . $img;

								if ($ranks && $img == $ranks['rank_image'])
								{
									$selected = ' selected="selected"';
									$edit_img = $img;
								}
								else
								{
									$selected = '';
								}

								if (strlen($img) > 255)
								{
									continue;
								}

								$filename_list .= '<option value="' . htmlspecialchars($img) . '"' . $selected . '>' . $img . ((in_array($img, $existing_imgs)) ? ' ' . $this->user->lang['ARCADE_RANK_IMAGE_IN_USE'] : '') . '</option>';
							}
						}

						$filename_list = '<option value=""' . (($edit_img == '') ? ' selected="selected"' : '') . '>----------</option>' . $filename_list;
						unset($existing_imgs, $imglist);

						$this->template->assign_vars(array(
							'S_EDIT'			=> true,
							'RANKS_PATH'		=> $this->arcade->set_image_path('rank'),
							'U_ACTION'			=> $this->u_action . '&amp;id=' . $rank_id,

							'RANK_TITLE'		=> (isset($ranks['rank_title'])) ? $ranks['rank_title'] : '',
							'S_FILENAME_LIST'	=> $filename_list,
							'RANK_IMAGE'		=> ($edit_img) ? $this->arcade->get()->image('src', 'rank', $edit_img) : $this->admin_path . 'images/spacer.gif',
							'S_SPECIAL_RANK'	=> (isset($ranks['rank_special']) && $ranks['rank_special']) ? true : false,
							'MIN_RECORDS'		=> (isset($ranks['rank_min']) && !$ranks['rank_special']) ? $ranks['rank_min'] : 0)
						);

						return;
					break;
				}

				$this->template->assign_var('U_ACTION', $this->u_action);

				$sql = 'SELECT *
						FROM ' . ARCADE_RANKS_TABLE . '
						ORDER BY rank_special DESC, rank_min ASC, rank_title ASC';
				$result = $this->db->sql_query($sql);

				while ($row = $this->db->sql_fetchrow($result))
				{
					$this->template->assign_block_vars('ranks', array(
						'S_RANK_IMAGE'		=> ($row['rank_image']) ? true : false,
						'S_SPECIAL_RANK'	=> ($row['rank_special']) ? true : false,

						'RANK_IMAGE'		=> $this->arcade->get()->image('src', 'rank', $row['rank_image']),
						'RANK_TITLE'		=> $row['rank_title'],
						'MIN_RECORDS'		=> $row['rank_min'],

						'U_EDIT'			=> $this->u_action . '&amp;action=edit&amp;id=' . $row['rank_id'],
						'U_DELETE'			=> $this->u_action . '&amp;action=delete&amp;id=' . $row['rank_id'])
					);
				}
				$this->db->sql_freeresult($result);
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		if (count($errors))
		{
			$this->template->assign_vars(array(
				'S_ERROR'	=> true,
				'ERROR_MSG'	=> implode('<br>', $errors)
			));
		}

		$this->template->assign_vars(array(
			'L_TITLE'			=> (!empty($l_title)) ? $l_title : '',
			'L_TITLE_EXPLAIN'	=> (!empty($l_title_explain)) ? $l_title_explain : ''
		));
	}

	/**
	* Update menu data
	*/
	public function update_menu_data(&$menu_data, $main_menu)
	{
		$errors = array();

		if ($v = $this->arcade->validate_data('string', 'ARCADE_MENU_NAME', $menu_data['menu_name'], 3, 255))
		{
			$errors[] = $v;
		}

		if (!$menu_data['parent_id'] && !$menu_data['menu_fa'])
		{
			$errors[] = $this->user->lang['ARCADE_MAIN_MENU_ICON_ERROR'];
		}

		if ($v = $this->arcade->validate_data('string', 'ARCADE_MENU_FA', $menu_data['menu_fa'], 0, 50))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('string', 'ARCADE_MENU_PAGE', $menu_data['menu_page'], 0, 50))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('string', 'ARCADE_MENU_PARAMS', $menu_data['params'], 0, 255))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('string', 'ARCADE_MENU_TOP', $menu_data['menu_top'], 0, 50))
		{
			$errors[] = $v;
		}

		if ($v = $this->arcade->validate_data('string', 'ARCADE_MENU_AUTH', $menu_data['auth'], 0, 255))
		{
			$errors[] = $v;
		}

		$menu_data_sql = $menu_data;

		if (count($errors))
		{
			return $errors;
		}

		if (!isset($menu_data_sql['menu_id']))
		{
			if ($menu_data_sql['parent_id'])
			{
				$sql = 'SELECT left_id, right_id
						FROM ' . ARCADE_MENU_TABLE . '
						WHERE menu_id = ' . (int) $menu_data_sql['parent_id'];
				$result = $this->db->sql_query($sql);
				$row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				if (!$row)
				{
					trigger_error($this->user->lang['ARCADE_PARENT_MENU_NO_EXIST'] . adm_back_link($this->u_action . '&amp;' . $this->parent_id), E_USER_WARNING);
				}

				$sql = 'UPDATE ' . ARCADE_MENU_TABLE . '
						SET left_id = left_id + 2, right_id = right_id + 2
						WHERE left_id > ' . $row['right_id'];
				$this->db->sql_query($sql);

				$sql = 'UPDATE ' . ARCADE_MENU_TABLE . '
						SET right_id = right_id + 2
						WHERE ' . $row['left_id'] . ' BETWEEN left_id AND right_id';
				$this->db->sql_query($sql);

				$menu_data_sql['left_id'] = $row['right_id'];
				$menu_data_sql['right_id'] = $row['right_id'] + 1;
			}
			else
			{
				$sql = 'SELECT MAX(right_id) AS right_id
						FROM ' . ARCADE_MENU_TABLE;
				$result = $this->db->sql_query($sql);
				$row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				$menu_data_sql['left_id'] = $row['right_id'] + 1;
				$menu_data_sql['right_id'] = $row['right_id'] + 2;
			}

			$this->db->sql_query('INSERT INTO ' . ARCADE_MENU_TABLE . ' ' . $this->db->sql_build_array('INSERT', $menu_data_sql));

			$menu_data['menu_id'] = $this->db->sql_nextid();

			$this->arcade->add_log('admin', 'LOG_ARCADE_MENU_ADD', $menu_data['menu_name']);
		}
		else
		{
			$row = $this->get_menu_info($menu_data_sql['menu_id']);
			$sub_menu = $subsub_menu = $subsubsub_menu = 0;
			$this->get_sub_menu($main_menu, $row, $sub_menu, $subsub_menu, $subsubsub_menu);

			if ($row['menu_type'] || $subsubsub_menu > 0)
			{
				if ($row['menu_type'])
				{
					$menu_data_sql = $row;
					unset($menu_data_sql['left_id'], $menu_data_sql['right_id']);
					$menu_data_sql['menu_name'] = $menu_data['menu_name'];
					$menu_data_sql['menu_display'] = $menu_data['menu_display'];
					$menu_data_sql['menu_fa'] = $menu_data['menu_fa'];

					if ($menu_data_sql['menu_page'] != 'onclick' && $menu_data_sql['menu_page'] != 'data-jvarcade')
					{
						$menu_data_sql['new_window'] = $menu_data['new_window'];
					}
				}

				if ($subsubsub_menu > 0)
				{
					$menu_data_sql['parent_id'] = $row['parent_id'];
				}
				else
				{
					$left_id = ($row['left_id'] + 1);

					if ($left_id == $row['right_id'] || !$row['menu_page'])
					{
						$menu_data_sql['parent_id'] = $menu_data['parent_id'];
					}
				}

				if (!$row['menu_type'])
				{
					$menu_data_sql['auth'] = $menu_data['auth'];
				}

				$menu_data = $menu_data_sql;
			}

			if (!$menu_data_sql['menu_page'] || $menu_data_sql['menu_page'] == 'onclick' || $menu_data_sql['menu_page'] == 'data-jvarcade')
			{
				$menu_data_sql['new_window'] = false;
			}

			if ($row['parent_id'] != $menu_data_sql['parent_id'])
			{
				if ($row['menu_id'] != $menu_data_sql['parent_id'])
				{
					$this->move_menu($menu_data_sql['menu_id'], $menu_data_sql['parent_id']);
				}
				else
				{
					$menu_data_sql['parent_id'] = $row['parent_id'];
				}
			}

			$menu_id = $menu_data_sql['menu_id'];
			unset($menu_data_sql['menu_id']);

			$sql = 'UPDATE ' . ARCADE_MENU_TABLE . '
					SET ' . $this->db->sql_build_array('UPDATE', $menu_data_sql) . '
					WHERE menu_id = ' . (int) $menu_id;
			$this->db->sql_query($sql);

			$menu_data['menu_id'] = (int) $menu_id;

			$this->arcade->add_log('admin', 'LOG_ARCADE_MENU_EDIT', $menu_data['menu_name']);
		}

		return $errors;
	}

	public function get_sub_menu($main_menu, $menu_data, &$sub_menu, &$subsub_menu, &$subsubsub_menu)
	{
		if (isset($menu_data['menu_id']))
		{
			$sub = array();
			$sub['sub_' . $menu_data['menu_id']] = 0;
			$sub['subsub_' . $menu_data['menu_id']] = 0;
			$sub['subsubsub_' . $menu_data['menu_id']] = 0;

			foreach ($main_menu as $menu_id => $row)
			{
				if ($row['parent_id'] && $menu_data['menu_id'] == $row['parent_id'])
				{
					$sub['sub_' . $menu_data['menu_id']]++;

					foreach ($main_menu as $menu_id2 => $row2)
					{
						if ($row['left_id'] < $row2['left_id'] && $row['right_id'] > $row2['right_id'])
						{
							if ($row2['menu_tpl'] == 'arcade_menu.submenu.subsubmenu')
							{
								$sub['subsub_' . $menu_data['menu_id']]++;
							}
							else if ($row2['menu_tpl'] == 'arcade_menu.submenu.subsubmenu.subsubsubmenu')
							{
								$sub['subsubsub_' . $menu_data['menu_id']]++;
							}
						}
					}
				}
			}

			$sub_menu		= $sub['sub_' . $menu_data['menu_id']];
			$subsub_menu	= $sub['subsub_' . $menu_data['menu_id']];
			$subsubsub_menu	= $sub['subsubsub_' . $menu_data['menu_id']];
		}
	}

	/**
	* Get menu details
	*/
	public function get_menu_info($menu_id)
	{
		if (!$menu_id)
		{
			return false;
		}

		$sql = 'SELECT *
				FROM ' . ARCADE_MENU_TABLE . '
				WHERE menu_id = ' . (int) $menu_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			return false;
		}

		return $row;
	}

	/**
	* Get menu branch
	*/
	public function get_menu_branch($menu_id, $type = 'all', $order = 'descending', $include_menu = true)
	{
		switch ($type)
		{
			case 'parents':
				$condition = 'm1.left_id BETWEEN m2.left_id AND m2.right_id';
			break;

			case 'children':
				$condition = 'm2.left_id BETWEEN m1.left_id AND m1.right_id';
			break;

			default:
				$condition = 'm2.left_id BETWEEN m1.left_id AND m1.right_id OR m1.left_id BETWEEN m2.left_id AND m2.right_id';
			break;
		}

		$rows = array();

		$sql = 'SELECT m2.*
				FROM ' . ARCADE_MENU_TABLE . ' m1
				LEFT JOIN ' . ARCADE_MENU_TABLE . " m2 ON ($condition)
				WHERE m1.menu_id = " . (int) $menu_id . '
				ORDER BY m2.left_id ' . (($order == 'descending') ? 'ASC' : 'DESC');
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (!$include_menu && $row['menu_id'] == $menu_id)
			{
				continue;
			}

			$rows[] = $row;
		}
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	* Move menu
	*/
	public function move_menu($from_id, $to_id)
	{
		$moved_ids = array();

		$moved_menu = $this->get_menu_branch($from_id, 'children');
		$from_data = $moved_menu[0];
		$diff = count($moved_menu) * 2;

		for ($i = 0; $i < count($moved_menu); ++$i)
		{
			$moved_ids[] = (int) $moved_menu[$i]['menu_id'];
		}

		// Resync parents
		$sql = 'UPDATE ' . ARCADE_MENU_TABLE . "
				SET right_id = right_id - $diff
				WHERE left_id < " . (int) $from_data['right_id'] . "
				AND right_id > " . (int) $from_data['right_id'];
		$this->db->sql_query($sql);

		// Resync righthand side of tree
		$sql = 'UPDATE ' . ARCADE_MENU_TABLE . "
				SET left_id = left_id - $diff, right_id = right_id - $diff
				WHERE left_id > " . (int) $from_data['right_id'];
		$this->db->sql_query($sql);

		if ($to_id > 0)
		{
			// Retrieve $to_data again, it may have been changed...
			$to_data = $this->get_menu_info($to_id);

			// Resync new parents
			$sql = 'UPDATE ' . ARCADE_MENU_TABLE . "
					SET right_id = right_id + $diff
					WHERE " . $to_data['right_id'] . ' BETWEEN left_id AND right_id
					AND ' . $this->db->sql_in_set('menu_id', $moved_ids, true);
			$this->db->sql_query($sql);

			// Resync the righthand side of the tree
			$sql = 'UPDATE ' . ARCADE_MENU_TABLE . "
					SET left_id = left_id + $diff, right_id = right_id + $diff
					WHERE left_id > " . $to_data['right_id'] . '
					AND ' . $this->db->sql_in_set('menu_id', $moved_ids, true);
			$this->db->sql_query($sql);

			// Resync moved branch
			$to_data['right_id'] += $diff;

			if ($to_data['right_id'] > $from_data['right_id'])
			{
				$diff = '+ ' . ($to_data['right_id'] - $from_data['right_id'] - 1);
			}
			else
			{
				$diff = '- ' . abs($to_data['right_id'] - $from_data['right_id'] - 1);
			}
		}
		else
		{
			$sql = 'SELECT MAX(right_id) AS right_id
					FROM ' . ARCADE_MENU_TABLE . '
					WHERE ' . $this->db->sql_in_set('menu_id', $moved_ids, true);
			$result = $this->db->sql_query($sql);
			$row = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			$diff = '+ ' . ($row['right_id'] - $from_data['left_id'] + 1);
		}

		$sql = 'UPDATE ' . ARCADE_MENU_TABLE . "
				SET left_id = left_id $diff, right_id = right_id $diff
				WHERE " . $this->db->sql_in_set('menu_id', $moved_ids);
		$this->db->sql_query($sql);
	}

	/**
	* Move menu position by $steps up/down
	*/
	public function move_menu_by($menu_row, $action = 'move_up', $steps = 1)
	{
		/**
		* Fetch all the siblings between the menu's current spot
		* and where we want to move it to. If there are less than $steps
		* siblings between the current spot and the target then the
		* menu will move as far as possible
		*/
		$sql = 'SELECT menu_id, menu_name, left_id, right_id
				FROM ' . ARCADE_MENU_TABLE . "
				WHERE parent_id = {$menu_row['parent_id']}
				AND " . (($action == 'move_up') ? "right_id < {$menu_row['right_id']} ORDER BY right_id DESC" : "left_id > {$menu_row['left_id']} ORDER BY left_id ASC");
		$result = $this->db->sql_query_limit($sql, $steps);

		$target = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$target = $row;
		}
		$this->db->sql_freeresult($result);

		if (!count($target))
		{
			// The menu is already on top or bottom
			return false;
		}

		/**
		* $left_id and $right_id define the scope of the nodes that are affected by the move.
		* $diff_up and $diff_down are the values to substract or add to each node's left_id
		* and right_id in order to move them up or down.
		* $move_up_left and $move_up_right define the scope of the nodes that are moving
		* up. Other nodes in the scope of ($left_id, $right_id) are considered to move down.
		*/
		if ($action == 'move_up')
		{
			$left_id = $target['left_id'];
			$right_id = $menu_row['right_id'];

			$diff_up = $menu_row['left_id'] - $target['left_id'];
			$diff_down = $menu_row['right_id'] + 1 - $menu_row['left_id'];

			$move_up_left = $menu_row['left_id'];
			$move_up_right = $menu_row['right_id'];
		}
		else
		{
			$left_id = $menu_row['left_id'];
			$right_id = $target['right_id'];

			$diff_up = $menu_row['right_id'] + 1 - $menu_row['left_id'];
			$diff_down = $target['right_id'] - $menu_row['right_id'];

			$move_up_left = $menu_row['right_id'] + 1;
			$move_up_right = $target['right_id'];
		}

		// Now do the dirty job
		$sql = 'UPDATE ' . ARCADE_MENU_TABLE . "
				SET left_id = left_id + CASE
				WHEN left_id BETWEEN {$move_up_left} AND {$move_up_right} THEN -{$diff_up}
				ELSE {$diff_down}
				END,
				right_id = right_id + CASE
				WHEN right_id BETWEEN {$move_up_left} AND {$move_up_right} THEN -{$diff_up}
				ELSE {$diff_down}
				END
				WHERE
				left_id BETWEEN {$left_id} AND {$right_id}
				AND right_id BETWEEN {$left_id} AND {$right_id}";
		$this->db->sql_query($sql);

		return $target['menu_name'];
	}

	/**
	* Remove complete menu
	*/
	public function delete_menu($menu_data)
	{
		$menu_ids	= array($menu_data['menu_id']);
		$rows		= $this->get_menu_branch($menu_data['menu_id'], 'children', 'descending', false);

		foreach ($rows as $row)
		{
			if ($row['menu_type'])
			{
				$this->move_menu($row['menu_id'], 0);

				$sql = 'UPDATE ' . ARCADE_MENU_TABLE . '
						SET parent_id = 0, menu_display = 0
						WHERE menu_id = ' . (int) $row['menu_id'];
				$this->db->sql_query($sql);
			}
			else
			{
				$menu_ids[] = $row['menu_id'];
			}
		}

		$diff = count($menu_ids) * 2;

		$sql = 'DELETE FROM ' . ARCADE_MENU_TABLE . '
				WHERE ' . $this->db->sql_in_set('menu_id', $menu_ids);
		$this->db->sql_query($sql);

		// Resync tree
		$sql = 'UPDATE ' . ARCADE_MENU_TABLE . "
				SET right_id = right_id - $diff
				WHERE left_id < {$menu_data['right_id']} AND right_id > {$menu_data['right_id']}";
		$this->db->sql_query($sql);

		$sql = 'UPDATE ' . ARCADE_MENU_TABLE . "
				SET left_id = left_id - $diff, right_id = right_id - $diff
				WHERE left_id > {$menu_data['right_id']}";
		$this->db->sql_query($sql);

		return (count($menu_ids) > 1) ? 'S' : '';
	}
}
