<?php
/**
*
* @package phpBB Arcade
* @version $Id: main_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class main_info
{
	function module()
	{
		return array(
			'filename'	=> '\jv\arcade\acp\main_module',
			'title'		=> 'ACP_ARCADE_MAIN',
			'modes'		=> array(
				'main'	=> array('title'=> 'ACP_ARCADE_MAIN_INDEX', 'auth' => 'ext_jv/arcade', 'cat' => array('ACP_ARCADE_MAIN'))
			)
		);
	}
}
