<?php
/**
*
* @package phpBB Arcade
* @version $Id: permissions_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\acp;

class permissions_info
{
	function module()
	{
		return array(
			'filename'						=> '\jv\arcade\acp\permissions_module',
			'title'							=> 'ACP_ARCADE_PERMISSIONS',
			'modes'							=> array(
				'setting_category_local'	=> array('title' => 'ACP_ARCADE_CATEGORY_PERMISSIONS'		, 'auth' => 'ext_jv/arcade && acl_a_cauth && (acl_a_authusers || acl_a_authgroups)'	, 'cat' => array('ACP_CAT_ARCADE_PERMISSIONS')),
				'setting_category_copy'		=> array('title' => 'ACP_ARCADE_CATEGORY_PERMISSIONS_COPY'	, 'auth' => 'ext_jv/arcade && acl_a_cauth && acl_a_authusers && acl_a_authgroups'	, 'cat' => array('ACP_CAT_ARCADE_PERMISSIONS')),
				'setting_user_local'		=> array('title' => 'ACP_ARCADE_USERS_CATEGORY_PERMISSIONS'	, 'auth' => 'ext_jv/arcade && acl_a_authusers && acl_a_cauth'						, 'cat' => array('ACP_CAT_ARCADE_PERMISSIONS')),
				'setting_group_local'		=> array('title' => 'ACP_ARCADE_GROUPS_CATEGORY_PERMISSIONS', 'auth' => 'ext_jv/arcade && acl_a_authgroups && acl_a_cauth'						, 'cat' => array('ACP_CAT_ARCADE_PERMISSIONS')),

				'trace'						=> array('title' => 'ACP_ARCADE_PERMISSION_TRACE'			, 'auth' => 'ext_jv/arcade && acl_a_viewauth', 'display' => false					, 'cat' => array('ACP_CAT_ARCADE_PERMISSION_MASKS')),
				'view_category_local'		=> array('title' => 'ACP_VIEW_ARCADE_CATEGORY_PERMISSIONS'	, 'auth' => 'ext_jv/arcade && acl_a_viewauth'										, 'cat' => array('ACP_CAT_ARCADE_PERMISSION_MASKS')),
			)
		);
	}
}
