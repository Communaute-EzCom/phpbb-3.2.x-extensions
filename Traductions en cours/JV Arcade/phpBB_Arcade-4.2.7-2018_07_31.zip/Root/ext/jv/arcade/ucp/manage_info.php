<?php
/**
*
* @package phpBB Arcade
* @version $Id: manage_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\ucp;

class manage_info
{
	function module()
	{
		return array(
			'filename'	=> '\jv\arcade\ucp\manage_module',
			'title'		=> 'UCP_ARCADE',
			'modes'		=> array(
				'settings'	=> array('title' => 'UCP_ARCADE_SETTINGS'	, 'auth' => 'ext_jv/arcade && acl_u_arcade', 'cat'							 => array('UCP_CAT_ARCADE')),
				'post'		=> array('title' => 'UCP_ARCADE_POST'		, 'auth' => 'ext_jv/arcade && acl_u_arcade', 'cat'							 => array('UCP_CAT_ARCADE')),
				'favorites'	=> array('title' => 'UCP_ARCADE_FAVORITES'	, 'auth' => 'ext_jv/arcade && acl_u_arcade && acl_u_arcade_favorites', 'cat' => array('UCP_CAT_ARCADE'))
			)
		);
	}
}
