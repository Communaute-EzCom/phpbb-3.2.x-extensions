<?php
/**
*
* @package phpBB Arcade
* @version $Id: ajax.php 1944 2018-04-15 00:17:27Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

define('IN_PHPBB', true);
define('IN_PHPBB_ARCADE', true);
define('PHPBB_ARCADE_START', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './../../../../';
$phpbb_root_relative_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

$user->session_begin(false);
$auth->acl($user->data);
$user->setup();

if (!$request->is_ajax())
{
	send_status_line(403, 'Forbidden');
	trigger_error('NOT_AUTHORISED');
}

if (class_exists('jv\arcade\inc\arcade') && isset($arcade) && $phpbb_container->get('ext.manager')->is_enabled('jv/arcade'))
{
	$mode		= $request->variable('mode', '');
	$type		= $request->variable('type', '');
	$action		= $request->variable('action', '');
	$game_id	= (int) $request->variable('g', 0);
	$cat_id		= (int) $request->variable('c', 0);
	$start		= (int) $request->variable('start', 0);
	$limit		= (int) $request->variable('limit', 0);
	$popup		= (bool) $request->variable('popup', false);
	$user_id	= (int) $user->data['user_id'];

	if (!$user->data['is_registered'] && in_array($mode, array('challenge', 'rating', 'mode_rating', 'fav', 'mode_fav')))
	{
		if ($user->data['is_bot'])
		{
			exit;
		}
		else
		{
			$arcade->error('INFORMATION', 'ARCADE_SESSION_TIME_END', 403);
		}
	}

	$arcade = $arcade->get_driver($type);

	$new_val = intval($action);

	if (!$arcade->access() || ($type == 'challenge' && !$arcade->access('challenge', false)) || ($type == 'tournament' && !$arcade->access('tour')) ||
		(in_array($mode, array('rating', 'mode_rating')) && (!$game_id || !$cat_id || !$arcade_auth->acl_get('c_rate', $cat_id) || $arcade->get->cat_locked($cat_id) || $new_val < 1 || $new_val > 5)) ||
		(in_array($mode, array('fav', 'mode_fav')) && (!$game_id || !$auth->acl_get('u_arcade_favorites') || $new_val < 1 || $new_val > 2)))
	{
		$arcade->error('INFORMATION', 'NOT_AUTHORISED', 403);
	}

	if (in_array($mode, array('continue_games_list', 'continue_users_list')) && $start <= 1)
	{
		$mode = '';
	}

	switch ($mode)
	{
		case 'challenge':
		case 'games_list':
		case 'continue_games_list':
			$s_played_games = ($action == 'all' && in_array($type, array('arcade', 'challenge')) && $user->data['is_registered'] && $arcade_config['played_colour']) ? true : false;

			if ($s_played_games)
			{
				$played_games = ($type == 'challenge') ? $arcade->challenge->get_played_games() : $arcade->get->played_games();
			}

			$x = 0;
			$json_data = array('total_games' => 0);

			$user_age = $arcade->get->user_age();
			$founder_exemption = ($arcade_config['founder_exempt'] && $user->data['user_type'] == USER_FOUNDER) ? true : false;

			switch ($type)
			{
				case 'challenge':
					$play_games = ($action == 'all') ? $arcade->challenge->play_games() : $arcade->challenge->get_played_games(false, true);
				break;

				case 'tournament':
					$play_games = $arcade->tournament->get_played_games();
				break;

				default:
					$play_games = ($action == 'all') ? $arcade->games : $arcade->get->played_games(false, true);
			}

			foreach ($play_games as $gid => $game)
			{
				$cat_age = $arcade->get->cat_field($game['cat_id'], 'cat_age');

				if (!$arcade_auth->acl_get('c_view', $game['cat_id']) || ($action == 'all' && (!$arcade_auth->acl_get('c_play', $game['cat_id']) || $arcade->get->cat_locked($game['cat_id']) || ($cat_age && !$founder_exemption && ($user_age === '' || ($user_age < $cat_age))))))
				{
					continue;
				}

				$json_data['total_games']++;

				if ($start > $json_data['total_games'])
				{
					continue;
				}

				if ($x < $limit)
				{
					$json_data['games'][$x] = array(
						'game_id'	=> $gid,
						'game_name'	=> $game['game_name']
					);

					if ($action == 'all')
					{
						$json_data['games'][$x]['not_played'] = ($s_played_games && empty($played_games[$gid])) ? true : false;
					}
				}

				$x++;

				if ($mode == 'challenge' && $game['game_fav'] && $auth->acl_get('u_arcade_favorites'))
				{
					$json_data['fav_games'][] = array(
						'game_id'		=> $gid,
						'game_name'		=> $game['game_name'],
						'highlighted'	=> $game['highlighted']
					);
				}
			}

			unset($play_games);

			if ($json_data['total_games'])
			{
				if (in_array($mode, array('challenge', 'games_list')) && $s_played_games)
				{
					$json_data['select_title'] = $user->lang[(($type == 'challenge') ? 'CHALLENGE' : 'ARCADE') . '_PLAYED_GAMES_HIGHLIGHT'];
				}

				if ($mode == 'challenge' && !empty($json_data['fav_games']))
				{
					$json_data['l_highlighted'] = $user->lang['ARCADE_HIGHLIGHTED_GAME'];
				}
			}
			else if (in_array($mode, array('challenge', 'games_list')))
			{
				$json_data['l_no_data'] = $user->lang['ARCADE_NO_' . (($action == 'all') ? 'GAMES' : 'PLAYS')];
			}

			$arcade->json($json_data);
		break;

		case 'users_list':
		case 'continue_users_list':
			$x = 0;
			$json_data = array('total_users' => 0);

			switch ($type)
			{
				case 'challenge':
					$play_users = $arcade->challenge->obtain_all_users(true, true);
				break;

				case 'tournament':
					$play_users = $arcade->tournament->obtain_all_users();
				break;

				default:
					$play_users = $arcade->obtain_arcade_users();
			}

			foreach ($play_users as $uid => $row)
			{
				$json_data['total_users']++;

				if ($start > $json_data['total_users'])
				{
					continue;
				}

				if ($x < $limit)
				{
					$json_data['users'][$x] = array(
						'user_id'	=> $uid,
						'username'	=> $row['username']
					);
				}

				$x++;
			}

			unset($play_users);

			if ($mode == 'users_list' && !$json_data['total_users'])
			{
				$json_data['l_no_data'] = $user->lang['ARCADE_NO_PLAYS'];
			}

			$arcade->json($json_data);
		break;

		case 'rating':
		case 'mode_rating':
			$sql = 'SELECT game_id
					FROM ' . ARCADE_RATING_TABLE . '
					WHERE game_id = ' . $game_id . '
					AND user_id = ' . $user_id;
			$result = $db->sql_query($sql);
			$re_game_id = (int) $db->sql_fetchfield('game_id');
			$db->sql_freeresult($result);

			if (!$re_game_id || $re_game_id && $arcade_auth->acl_get('c_re_rate', $cat_id))
			{
				$sql_ary = array(
					'game_id'		=> $game_id,
					'user_id'		=> $user_id,
					'game_rating'	=> $new_val,
					'rating_date'	=> time()
				);

				if ($re_game_id)
				{
					$sql = 'UPDATE ' . ARCADE_RATING_TABLE . '
							SET ' . $db->sql_build_array('UPDATE', $sql_ary) . '
							WHERE game_id = ' . $game_id . '
							AND user_id = ' . $user_id;
					$db->sql_query($sql);
				}
				else
				{
					$db->sql_return_on_error(true);
					$db->sql_query('INSERT INTO ' . ARCADE_RATING_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_ary));
					$db->sql_return_on_error(false);
				}

				$arcade->sync('rating', $game_id);
			}

			$sql_array = array(
				'SELECT'	=> 'g.game_votetotal, g.game_votesum, r.game_rating',
				'FROM'		=> array(ARCADE_RATING_TABLE => 'r'),
				'LEFT_JOIN'	=> array(array(
				'FROM'		=> array(ARCADE_GAMES_TABLE	 => 'g'),
				'ON'		=> 'r.game_id = g.game_id')),
				'WHERE'		=> 'r.game_id = ' . $game_id . ' AND r.user_id = ' . $user_id);

			$result	= $db->sql_query($db->sql_build_query('SELECT', $sql_array));
			$row	= $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			$c_new_rate = $arcade_auth->acl_get('c_re_rate', $cat_id) ? true : false;

			if ($row['game_votetotal'] > 0)
			{
				$star_width = (int) (($row['game_votesum'] / $row['game_votetotal']) * 16);
			}
			else
			{
				$star_width = 0;
			}

			$arn_width = (96 + (strlen($row['game_votetotal']) * 6));
			$title = (!$c_new_rate && !empty($row['game_rating'])) ? sprintf($user->lang['ARCADE_RATING_ALREADY'], $new_val) : '';

			$image = '<ul class="arcade-rate' . (($popup) ? ' light' : '') . '"' . ($title ? ' title="' . $title . '"' : '') . '>' . "\n";

			if ($star_width)
			{
				$image .= '<li class="arcade-current-rate" style="width:' . $star_width . 'px;"></li>' . "\n";
			}

			$image .= '<li class="arcade-rating-num' . (($popup) ? ' arcade-white' : '') . '" style="width: ' . $arn_width . 'px;"><span title="' . $user->lang['ARCADE_RATING_NUM'] . '">(' . $row['game_votetotal'] . ')</span></li>' . "\n";

			if ($c_new_rate)
			{
				for ($x = 1; $x <= 5; $x++)
				{
					$image.= '<li><a href="#" title="' . sprintf($user->lang['ARCADE_RATING_VALUE'], $x) . '" class="arcade-rate-' . $x . '" data-jvarcade="ajax" data-mode="' . $mode . '" data-type="arcade" data-action="' . $x . '" data-gameid="' . $game_id . '" data-catid="' . $cat_id . '" data-popup="' . $popup . '" rel="nofollow">' . $x . '</a></li>' . "\n";
				}
			}

			$image.= '</ul>';

			$arcade->json(array('image' => $image));
		break;

		case 'fav':
		case 'mode_fav':
			$fav_data = array();
			if ($new_val == ARCADE_FAV_ADD)
			{
				$data = array(
					'user_id' => $user_id,
					'game_id' => $game_id
				);

				$db->sql_return_on_error(true);
				$db->sql_query('INSERT INTO ' . ARCADE_FAVS_TABLE . ' ' . $db->sql_build_array('INSERT', $data));
				$db->sql_return_on_error(false);

				$fav_image	= str_replace($phpbb_root_path, $phpbb_root_relative_path, $arcade->get->image('src', 'img', 'remove_favorite.png'));
				$image		= '<a href="#" data-jvarcade="ajax" data-mode="' . $mode . '" data-type="arcade" data-action="' . ARCADE_FAV_DEL . '" data-gameid="' . $game_id . '" data-popup="' . $popup . '" rel="nofollow"><img class="arcade_fav" src="' . $fav_image . '" title="' . $user->lang['ARCADE_REMOVE_FAV'] . '" alt="' . $user->lang['ARCADE_REMOVE_FAV'] . '"></a>';

				$json_data = array(
					'action'	=> ARCADE_FAV_DEL,
					'src'		=> $fav_image,
					'title'		=> $user->lang['ARCADE_REMOVE_FAV']
				);
			}
			else
			{
				$sql = 'DELETE FROM ' . ARCADE_FAVS_TABLE . '
						WHERE game_id = ' . $game_id . '
						AND   user_id = ' . $user_id;
				$db->sql_query($sql);

				$fav_image	= str_replace($phpbb_root_path, $phpbb_root_relative_path, $arcade->get->image('src', 'img', 'add_favorite.png'));
				$image		= '<a href="#" data-jvarcade="ajax" data-mode="' . $mode . '" data-type="arcade" data-action="' . ARCADE_FAV_ADD . '" data-gameid="' . $game_id . '" data-popup="' . $popup . '" rel="nofollow"><img class="arcade_fav" src="' . $fav_image . '" title="' . $user->lang['ARCADE_ADD_FAV'] . '" alt="' . $user->lang['ARCADE_ADD_FAV'] . '"></a>';
			}

			if ($mode == 'mode_fav' && $arcade_config['search_cats'])
			{
				$game_fav_data = $arcade->get->fav_data();
				$before_game_id = 0;

				if (is_array($game_fav_data) && count($game_fav_data))
				{
					foreach($game_fav_data as $gid => $row)
					{
						if ($game_id == $gid)
						{
							$game_name = $row['game_name'];
							break;
						}

						$before_game_id = $gid;
					}

					if ($new_val == ARCADE_FAV_ADD)
					{
						$fav_data = array(
							'before_game_id'	=> $before_game_id,
							'game_id'			=> $game_id,
							'game_name'			=> $game_name,
							'action'			=> 'add'
						);
					}
					else
					{
						$fav_data = array(
							'game_id'			=> $game_id,
							'action'			=> 'del'
						);
					}
				}
			}

			$json_data = array('image' => $image);

			if ($fav_data)
			{
				$json_data['fav_data'] = $fav_data;
			}

			$arcade->json($json_data);
		break;

		default:
			$arcade->error('ERROR', 'NO_MODE', 500);
	}
}
else
{
	$json_response = new \phpbb\json_response();
	$json_response->send(array('idling' => true));
}
