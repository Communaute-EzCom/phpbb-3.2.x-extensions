<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_2_1.php 1900 2018-03-04 00:28:47Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_2_1 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\arcade\migrations\v_4_2_0');
	}

	public function update_schema()
	{
		return array(
			'add_columns'	=> array(
				"{$this->table_prefix}arcade_menu" => array(
					'menu_fa' => array('VCHAR:50', '')
				)
			),
			'drop_columns'	=> array(
				"{$this->table_prefix}arcade_menu" => array('quick_link')
			),
		);
	}

	public function update_data()
	{
		return array(
			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		global $user;

		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);

		switch ($this->db->get_sql_layer())
		{
			case 'sqlite3':
				$this->db->sql_query('DELETE FROM ' . $this->table_prefix . 'arcade_menu');
			break;

			default:
				$this->db->sql_query('TRUNCATE TABLE ' . $this->table_prefix . 'arcade_menu');
			break;
		}

		$arcade_install->add_menu($arcade_install->data->menu());

		$fix_configs = array('challenge_exp_last_gc', 'challenge_total_plays', 'challenge_total_plays_time', 'record_playing_date',
		'record_playing_users', 'session_last_gc', 'total_downloads', 'total_plays', 'total_plays_time', 'tour_total_plays', 'tour_total_plays_time');

		foreach ($fix_configs as $config_name)
		{
			$sql = "UPDATE {$this->table_prefix}arcade_config
					SET is_dynamic = 1
					WHERE config_name = '" . $this->db->sql_escape($config_name) . "'";
			$this->sql_query($sql);
		}

		$arcade_install->delete_config(array(
			array('display_menu'),
			array('menu_position'),
			array('menu_theme'),
			array('arcade_link'),
			array('box_top')
		));

		$arcade_install->set_config(array(
			array('install_games_limit', 50),
			array('auto_reset_score', 0),
			array('auto_reset_score_days', 90),
			array('auto_reset_score_plays', 0),
			array('auto_reset_score_gc', time(), false),
			array('version', '4.2.1')
		));
	}
}
