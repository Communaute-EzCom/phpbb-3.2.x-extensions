<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_1_RC1.php 1880 2018-02-28 20:13:49Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_1_RC1 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\jv\arcade\migrations\v_4_0_RC6',
			'\phpbb\db\migration\data\v320\v320'
		);
	}

	public function update_data()
	{
		return array(
			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		global $user;

		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);
		$arcade_install->add_bbcodes($arcade_install->data->bbcodes());

		$sql = "DELETE FROM {$this->table_prefix}bbcodes
				WHERE bbcode_tag = '" . $this->db->sql_escape('arcade-popup=') . "'";
		$this->sql_query($sql);

		$sql = "UPDATE {$this->table_prefix}arcade_menu
				SET menu_page = '" . $this->db->sql_escape('app/help') . "',
				params = '" . $this->db->sql_escape('arcade_faq') . "'
				WHERE menu_name = '" . $this->db->sql_escape('FAQ') . "'";
		$this->sql_query($sql);

		$arcade_install->set_config(array(
			array('protect_game_img', 1),
			array('version', '4.1.0-RC1')
		));
	}
}
