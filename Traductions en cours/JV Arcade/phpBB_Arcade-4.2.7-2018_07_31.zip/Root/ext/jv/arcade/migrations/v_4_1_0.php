<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_1_0.php 1880 2018-02-28 20:13:49Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_1_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\phpbb\db\migration\data\v320\v320',
			'\jv\arcade\migrations\v_4_1_RC2'
		);
	}

	public function update_data()
	{
		return array(
			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);

		$arcade_install->set_config(array(
			array('version', '4.1.0')
		));
	}
}
