<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_2_6.php 2039 2018-07-26 08:38:09Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_2_6 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\arcade\migrations\v_4_2_5');
	}

	public function update_schema()
	{
		return array('add_columns' => array(
			"{$this->table_prefix}arcade_users" => array('arcade_cat_games_style' => array('TINT:1', 0))
		));
	}

	public function update_data()
	{
		return array(
			array('module.add', array(
				'acp', 'ACP_CAT_ARCADE_UTILITIES', array(
					'module_basename'	=> '\jv\arcade\acp\utilities_module',
					'modes'				=> array('deleted_games')
				)
			)),
			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		global $user;

		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);

		$arcade_install->set_config(array(
			array('default_cat_games_style', 1),
			array('cookie_secure_info_time', 0),
			array('download_list_per_page', 50),
			array('version', '4.2.6')
		));
	}
}
