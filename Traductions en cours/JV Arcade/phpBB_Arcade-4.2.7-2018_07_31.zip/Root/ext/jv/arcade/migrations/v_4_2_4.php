<?php
/**
*
* @package phpBB Arcade
* @version $Id: v_4_2_4.php 2039 2018-07-26 08:38:09Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\migrations;

use jv\arcade\inc\install as arcade_ins;

class v_4_2_4 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\arcade\migrations\v_4_2_3');
	}

	public function update_schema()
	{
		return array('add_columns' => array(
			"{$this->table_prefix}arcade_users"		=> array('arcade_cat_style' => array('TINT:1', 0)),
			"{$this->table_prefix}arcade_reports"	=> array(
				'topic_id'	=> array('UINT', 0),
				'post_id'	=> array('UINT', 0)
			),
		));
	}

	public function update_data()
	{
		return array(
			array('custom', array(array($this, 'arcade_update')))
		);
	}

	public function arcade_update()
	{
		global $user;

		$arcade_install = new arcade_ins\install($this->db, $this->php_ext, $this->table_prefix);
		$arcade_install->data = new arcade_ins\data($user, $this->config, null, $this->php_ext, $this->table_prefix);

		$arcade_install->delete_config(array(
			array('gc_time'),
			array('auto_reset_score_days')
		));

		$arcade_install->set_config(array(
			array('game_desc_lang', ''),
			array('auto_reset_score', 0),
			array('auto_reset_score_gc', 7776000),
			array('auto_reset_score_last_gc', time(), false),
			array('auto_reset_score_hour', '0:00'),
			array('time_gc', 86400),
			array('version', '4.2.4')
		));
	}
}
