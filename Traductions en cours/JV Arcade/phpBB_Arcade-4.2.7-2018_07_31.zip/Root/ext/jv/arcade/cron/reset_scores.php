<?php
/**
*
* @package phpBB Arcade
* @version $Id: reset_scores.php 2010 2018-06-05 23:44:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\cron;

class reset_scores extends \phpbb\cron\task\base
{
	protected $db, $arcade, $arcade_config;

	public function __construct($db, $arcade, $arcade_config)
	{
		$this->db				= $db;
		$this->arcade			= $arcade;
		$this->arcade_config	= $arcade_config;
	}

	public function run()
	{
		$time = time();

		if ($this->arcade_config['champions_game_announce'])
		{
			$sql = 'SELECT au.arcade_total_wins AS total_wins, u.user_id, u.username, u.user_colour
					FROM ' . ARCADE_USERS_TABLE . ' au, ' . USERS_TABLE . ' u
					WHERE u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
						AND au.user_id = u.user_id
						AND au.arcade_total_wins > 0
					ORDER BY total_wins DESC';
			$result = $this->db->sql_query_limit($sql, 10);
			$champions = $this->db->sql_fetchrowset($result);
			$this->db->sql_freeresult($result);

			if (count($champions))
			{
				$this->arcade->phpbb()->create_champions_game_announcement($champions, $time);
			}
		}

		$delete_tables = array(ARCADE_SCORES_TABLE);

		if (!$this->arcade_config['auto_reset_score_plays'])
		{
			$delete_tables[] = ARCADE_PLAYS_TABLE;
		}

		$this->arcade->delete_table_data($delete_tables);

		if (!$this->arcade_config['auto_reset_score_plays'])
		{
			$sql_ary['game_plays'] = 0;
		}

		$sql_ary['game_highscore']	= 0;
		$sql_ary['game_highuser']	= 0;
		$sql_ary['game_highdate']	= 0;

		$sql = 'UPDATE ' . ARCADE_GAMES_TABLE. '
				SET ' . $this->db->sql_build_array('UPDATE', $sql_ary);
		$this->db->sql_query($sql);

		$sql_ary = array(
			'cat_last_play_game_id'		=> 0,
			'cat_last_play_game_name'	=> '',
			'cat_last_play_user_id'		=> 0,
			'cat_last_play_score'		=> 0,
			'cat_last_play_time'		=> 0,
			'cat_last_play_username'	=> '',
			'cat_last_play_user_colour'	=> '',
		);

		if (!$this->arcade_config['auto_reset_score_plays'])
		{
			$sql_ary['cat_plays'] = 0;
		}

		$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
				SET ' . $this->db->sql_build_array('UPDATE', $sql_ary);
		$this->db->sql_query($sql);

		$this->arcade->sync('category');

		if (!$this->arcade_config['auto_reset_score_plays'])
		{
			$this->arcade_config->set('total_plays', 0, false);
			$this->arcade_config->set('total_plays_time', 0, false);
			$this->arcade_config->set('arcade_resetdate', $time);
		}

		$sql = "UPDATE " . ARCADE_USERS_TABLE . '
				SET arcade_total_wins = 0';

		if (!$this->arcade_config['auto_reset_score_plays'])
		{
			$sql .= ', user_arcade_last_play = 0, arcade_total_played = 0, arcade_total_plays = 0, arcade_total_time = 0';
		}

		$this->db->sql_query($sql);

		$this->arcade->cache_purge();

		$this->arcade->add_log('admin', 'LOG_ARCADE_AUTO_RESET_SCORE');

		$this->arcade_config->set('auto_reset_score_last_gc', $time, false);
	}

	public function is_runnable()
	{
		return !empty($this->arcade_config['auto_reset_score']);
	}

	public function should_run()
	{
		$last_reset_date = $this->arcade->gen_datetime($this->arcade_config['auto_reset_score_last_gc'], false, 0, $this->arcade_config['auto_reset_score_hour']);
		$next_reset_date = $this->arcade->gen_datetime(time(), false, $this->arcade_config['auto_reset_score_gc'], $this->arcade_config['auto_reset_score_hour'], false);

		return !$this->arcade_config['auto_reset_score_last_gc'] || $last_reset_date <= $next_reset_date;
	}
}
