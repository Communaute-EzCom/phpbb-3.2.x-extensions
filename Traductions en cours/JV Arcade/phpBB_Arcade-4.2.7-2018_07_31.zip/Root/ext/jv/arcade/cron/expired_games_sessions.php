<?php
/**
*
* @package phpBB Arcade
* @version $Id: expired_games_sessions.php 2004 2018-06-04 14:12:27Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\cron;

class expired_games_sessions extends \phpbb\cron\task\base
{
	protected $db, $arcade_config;

	public function __construct($db, $arcade_config)
	{
		$this->db				= $db;
		$this->arcade_config	= $arcade_config;
	}

	public function run()
	{
		$time = time();
		$sql = 'DELETE FROM ' . ARCADE_SESSIONS_TABLE . '
			WHERE start_time < ' . intval($time - $this->arcade_config['session_length']);
		$this->db->sql_query($sql);

		$this->arcade_config->set('session_last_gc', $time, false);
	}

	public function is_runnable()
	{
		return !empty($this->arcade_config['time_gc']);
	}

	public function should_run()
	{
		return $this->arcade_config['session_last_gc'] < time() - $this->arcade_config['time_gc'];
	}
}
