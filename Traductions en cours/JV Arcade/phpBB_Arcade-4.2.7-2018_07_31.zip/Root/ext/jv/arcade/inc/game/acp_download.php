<?php
/**
*
* @package phpBB Arcade
* @version $Id: acp_download.php 2046 2018-07-31 18:22:20Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class acp_download
{
	protected $db, $request, $config, $arcade_config, $arcade;

	public function __construct($db, $request, $config, $arcade_config, $arcade)
	{
		$this->db = $db;
		$this->request = $request;
		$this->config = $config;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	public function get_data()
	{
		$categories = array();

		if ($this->arcade->game()->download_auth('acp_module'))
		{
			foreach ($this->arcade->cats() as $cat_id => $row)
			{
				if ($this->arcade->game()->download_auth('cat', $cat_id, $row['cat_download']) && $row['cat_type'] == ARCADE_CAT_GAMES)
				{
					$categories[$cat_id] = $row['cat_name'];
				}
			}
		}

		$download_data = array(
			// phpBB Arcade 4.2.6 lower version - acp downloads module disabled.
			'req_min'		=> '4.2.6',
			'list_enable'	=> ($this->arcade->game()->download_auth('acp_module')) ? true : false,
			'sitename'		=> $this->config['sitename'],
			'message'		=> $this->arcade_config['download_list_message'],
			'filetype'		=> ($this->arcade_config['download_file_type'] !== '') ? true : false,
			'methods'		=> ($this->arcade_config['download_file_type'] !== '') ? array($this->arcade_config['download_file_type']) : $this->arcade->compress_methods(),
			'categories'	=> $categories
		);

		$download_data = gzcompress(serialize($download_data), 9);
		echo $download_data;
	}

	public function get_list($cat_id, $start)
	{
		if ($this->arcade->game()->download_auth('acp_module'))
		{
			$sort_gtype			= (int) $this->request->variable('gt', 0);
			$sort_gstype		= (int) $this->request->variable('gst', 0);
			$sort_time			= (int) $this->request->variable('st', 0);
			$sort_key			= strtolower($this->request->variable('sk', 'd'));
			$sort_dir			= strtolower($this->request->variable('sd', 'd'));
			$per_page			= (int) $this->request->variable('per_page', 50);
			$game_desc_enable	= $this->request->variable('gd', 'n');

			$s_sort		= array('n' => 'g.game_name_clean', 's' => 'g.game_filesize', 't' => 'g.game_type', 'r' => 'g.game_save_type', 'd' => 'g.game_installdate');
			$sort		= (!empty($s_sort[$sort_key])) ? $s_sort[$sort_key] : 'g.game_installdate';
			$sort_dir	= ($sort_dir == 'a') ? 'ASC' : 'DESC';

			// Only allow 10, 20, 50, 100 or 250 games per page
			// This will make sure that there are not tons of different settings out there
			$per_page = (in_array($per_page, array(10, 20, 50, 100, 250))) ? $per_page : 50;

			$download_list = array('per_page' => $per_page);

			$sql_array = array(
				'SELECT'	=> 'COUNT(g.game_id) AS total',
				'FROM'		=> array(ARCADE_GAMES_TABLE => 'g'),
				'LEFT_JOIN'	=> array(array('FROM' => array(ARCADE_CATS_TABLE => 'c'), 'ON' => 'g.cat_id = c.cat_id')),
				'WHERE'		=> ($this->arcade->test_system()) ? 'g.game_id > 0' : 'c.cat_download = 1 AND g.game_download = 1'
			);

			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query($sql, $this->arcade->hour($this->arcade_config['cache_time']));
			$download_list['found'] = $download_list['total'] = (int) $this->db->sql_fetchfield('total');
			$this->db->sql_freeresult($result);

			if ($cat_id)
			{
				$sql_array['WHERE'] .= ' AND g.cat_id = ' . (int) $cat_id;
			}

			if ($sort_time)
			{
				$sql_array['WHERE'] .= ' AND g.game_installdate > ' . (time() - ($sort_time * 86400));
			}

			if ($sort_gtype)
			{
				$sql_array['WHERE'] .= ' AND g.game_type = ' . $sort_gtype;
			}

			if ($sort_gstype)
			{
				$sql_array['WHERE'] .= ' AND g.game_save_type = ' . $sort_gstype;
			}

			if ($cat_id || $sort_time || $sort_gtype || $sort_gstype)
			{
				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query($sql, $this->arcade->hour($this->arcade_config['cache_time']));
				$download_list['total'] = (int) $this->db->sql_fetchfield('total');
				$this->db->sql_freeresult($result);
			}

			$games = array();

			if ($download_list['total'])
			{
				$show_points = ($this->arcade->points()->data['show']) ? true : false;
				$download_list['points_show'] = $show_points;
				$download_list['points_name'] = ($show_points) ? $this->arcade->points()->data['name'] : '';

				$sql_array = array(
					'SELECT'	=> 'g.game_id, g.game_swf, g.game_name, g.game_name_clean, g.game_download_cost, g.game_installdate, g.game_filesize, g.game_type, g.game_save_type,
									c.cat_download_cost',
					'FROM'		=> array(ARCADE_GAMES_TABLE => 'g'),
					'LEFT_JOIN'	=> array(array('FROM' => array(ARCADE_CATS_TABLE => 'c'), 'ON' => 'g.cat_id = c.cat_id')),
					'WHERE'		=> $sql_array['WHERE'],
					'ORDER_BY'	=> $sort . ' ' . $sort_dir
				);

				if ($game_desc_enable == 'y')
				{
					$sql_array['SELECT'] .= ', g.game_desc';
				}

				$this->arcade->valid_start($start, $download_list['total']);

				$sql = $this->db->sql_build_query('SELECT', $sql_array);
				$result = $this->db->sql_query_limit($sql, $per_page, $start, $this->arcade->hour($this->arcade_config['cache_time']));
				while ($row = $this->db->sql_fetchrow($result))
				{
					$games[$row['game_id']] = array(
						'game_name'			=> $row['game_name'],
						'game_swf'			=> $row['game_swf'],
						'game_installdate'	=> $row['game_installdate'],
						'game_filesize'		=> $row['game_filesize'],
						'game_type'			=> $row['game_type'],
						'game_save_type'	=> $row['game_save_type']
					);

					if ($show_points)
					{
						$download_cost = $this->arcade->points()->game_download_cost($row);
						$download_cost = ($download_cost != ARCADE_FREE && $download_cost > 0) ? $download_cost : 0;

						$games[$row['game_id']]['download_cost'] = $download_cost;
					}

					if ($game_desc_enable == 'y')
					{
						$games[$row['game_id']]['game_desc'] = $row['game_desc'];
					}
				}
				$this->db->sql_freeresult($result);
			}

			$download_list['games'] = $games;
			unset($games);

			// Try to save some bandwidth and allows us to still have an array on the other side
			$download_list = gzcompress(serialize($download_list), 9);
			echo $download_list;
		}
	}
}
