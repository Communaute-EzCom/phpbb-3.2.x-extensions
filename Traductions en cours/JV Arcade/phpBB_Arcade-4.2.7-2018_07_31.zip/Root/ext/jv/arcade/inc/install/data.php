<?php
/**
*
* @package phpBB Arcade
* @version $Id: data.php 2046 2018-07-31 18:22:20Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\install;

class data
{
	protected $user, $config, $arcade_config, $php_ext, $table_prefix;

	public function __construct($user, $config, $arcade_config, $php_ext, $table_prefix)
	{
		$this->user = $user;
		$this->config = $config;
		$this->arcade_config = $arcade_config;
		$this->php_ext = $php_ext;
		$this->table_prefix = $table_prefix;
	}

	public function version()
	{
		return '4.2.7';
	}

	public function contact()
	{
		return array(
			'support_domain' => 'https://jv-arcade.com/',
			'connect_domain' => 'https://connect.jv-arcade.com/'
		);
	}

	public function copyright()
	{
		return 'Powered by <a onclick="window.open(this.href); return false;" href="' . $this->contact()['support_domain'] . '">phpBB Arcade</a> © JV-Arcade Group';
	}

	public function requirements()
	{
		return array(
			'version'				=> array(
				'phpbb'				=> '3.2.2',
				'php'				=> '5.4'
			),
			'writable_dirs'			=> (!empty($this->arcade_config)) ? array($this->arcade_config['cat_backup_path'], 'arcade/gamedata/', $this->arcade_config['game_path'], $this->arcade_config['unpack_game_path'], 'cache/', 'games/', 'store/') : array('arcade/backup/', 'arcade/gamedata/', 'arcade/games/', 'arcade/install/', 'cache/', 'games/', 'store/'),
			'bbcodes'				=> $this->bbcodes()
		);
	}

	public function core_files()
	{
		return array(
			'arcade/arcadelib/' => array(
				"getHiScores.{$this->php_ext}",
				"ibproArcadeLib.conf",
				"index.htm",
				"score2.swf"
			),

			"{$this->arcade_config['cat_backup_path']}" => array(
				".htaccess",
				"index.htm"
			),

			"arcade/gamedata/" => array(
				"index.htm"
			),

			"{$this->arcade_config['game_path']}" => array(
				"index.htm"
			),

			"{$this->arcade_config['unpack_game_path']}" => array(
				".htaccess",
				"index.htm"
			),

			"arcade/sounds/" => array(
				"game_over.mp3",
				"game_over.ogg",
				"index.htm"
			),

			"arcade/start_system/jva_game_intro/css/" => array(
				"index.htm",
				"jva_game_intro.css"
			),

			"arcade/start_system/jva_game_intro/images/" => array(
				"index.htm",
				"jva_game_intro_atlas_.png",
				"sample_logo.png"
			),

			"arcade/start_system/jva_game_intro/js/" => array(
				"create_js.js",
				"index.htm",
				"jva_game_intro.js",
				"jva_game_intro_init.js"
			),

			"arcade/start_system/jva_game_intro/sounds/" => array(
				"index.htm",
				"sound1.mp3",
				"sound2.mp3",
				"sound3.mp3",
				"sound4.mp3"
			),

			"arcade/start_system/jva_game_intro/" => array(
				"index.html"
			),

			"arcade/start_system/" => array(
				"core.js",
				"game.js",
				"index.htm"
			),

			"arcade/swf/" => array(
				".htaccess",
				"FlashPlayerUpdate.swf",
				"index.htm",
				"JVA_Game_Score.swf",
				"JVA_Time_Hack_Detect.swf"
			),

			"arcade/" => array(
				"file.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/arcade/acp/" => array(
				".htaccess",
				"ext_info.{$this->php_ext}",
				"ext_module.{$this->php_ext}",
				"games_info.{$this->php_ext}",
				"games_module.{$this->php_ext}",
				"index.htm",
				"install_info.{$this->php_ext}",
				"install_module.{$this->php_ext}",
				"logs_info.{$this->php_ext}",
				"logs_module.{$this->php_ext}",
				"main_info.{$this->php_ext}",
				"main_manage_info.{$this->php_ext}",
				"main_manage_module.{$this->php_ext}",
				"main_module.{$this->php_ext}",
				"manage_info.{$this->php_ext}",
				"manage_module.{$this->php_ext}",
				"permission_roles_info.{$this->php_ext}",
				"permission_roles_module.{$this->php_ext}",
				"permissions_info.{$this->php_ext}",
				"permissions_module.{$this->php_ext}",
				"settings_info.{$this->php_ext}",
				"settings_module.{$this->php_ext}",
				"utilities_info.{$this->php_ext}",
				"utilities_module.{$this->php_ext}"
			),

			"ext/jv/arcade/adm/style/arcade/" => array(
				"acp_announce.html",
				"acp_games.html",
				"acp_install.html",
				"acp_logs.html",
				"acp_main.html",
				"acp_main_manage.html",
				"acp_manage.html",
				"acp_permission_roles.html",
				"acp_permissions.html",
				"acp_setting.html",
				"acp_user_settings.html",
				"acp_utilities.html",
				"arcade.css",
				"category_permission_copy.html",
				"confirm_body.html",
				"confirm_move_games.html",
				"index.htm",
				"permission_roles_mask.html",
				"version_check.html"
			),

			"ext/jv/arcade/adm/style/event/" => array(
				"acp_overall_header_head_append.html",
				"index.htm"
			),

			"ext/jv/arcade/adm/style/images/" => array(
				"index.htm",
				"logo.png",
				"logo_transparent.png"
			),

			"ext/jv/arcade/adm/style/" => array(
				'index.htm'
			),

			"ext/jv/arcade/adm/" => array(
				'index.htm'
			),

			"ext/jv/arcade/ajax/" => array(
				"ajax.{$this->php_ext}",
				'index.htm'
			),

			"ext/jv/arcade/animation/game_over/images/" => array(
				'index.htm',
				'new_record_congratulation_atlas_.png'
			),

			"ext/jv/arcade/animation/game_over/sounds/" => array(
				'index.htm',
				'Sound1.mp3',
				'Sound2.mp3'
			),

			"ext/jv/arcade/animation/game_over/" => array(
				'animation.js',
				'index.html',
			),

			"ext/jv/arcade/animation/" => array(
				'createjs.js',
				'index.htm',
			),

			"ext/jv/arcade/config/" => array(
				".htaccess",
				"arcade.yml",
				"auth.yml",
				"content.yml",
				"cron.yml",
				"detect.yml",
				"ext.yml",
				"game.yml",
				"help.yml",
				"index.htm",
				"install.yml",
				"routing.yml",
				"services.yml",
				"tables.yml"
			),

			"ext/jv/arcade/controller/" => array(
				".htaccess",
				"faq.{$this->php_ext}",
				"index.htm",
				"score.{$this->php_ext}"
			),

			"ext/jv/arcade/cron/" => array(
				".htaccess",
				"expired_challenge.{$this->php_ext}",
				"expired_games_sessions.{$this->php_ext}",
				"index.htm",
				"reset_scores.{$this->php_ext}"
			),

			"ext/jv/arcade/event/" => array(
				".htaccess",
				"index.htm",
				"listener.{$this->php_ext}"
			),

			"ext/jv/arcade/inc/auth/" => array(
				"auth.{$this->php_ext}",
				"auth_admin.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/arcade/inc/cache/" => array(
				"cache.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/arcade/inc/detect/" => array(
				"index.htm",
				"points.{$this->php_ext}",
				"portal.{$this->php_ext}",
				"shout.{$this->php_ext}"
			),

			"ext/jv/arcade/inc/ext/" => array(
				"base.{$this->php_ext}",
				"ext_interface.{$this->php_ext}",
				"helper.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/arcade/inc/game/" => array(
				"acp_download.{$this->php_ext}",
				"cat_games.{$this->php_ext}",
				"default_install_file.{$this->php_ext}",
				"download.{$this->php_ext}",
				"game.{$this->php_ext}",
				"install_file.{$this->php_ext}",
				"session.{$this->php_ext}",
				"ibp.{$this->php_ext}",
				"index.htm",
				"play.{$this->php_ext}",
				"report.{$this->php_ext}",
				"score.{$this->php_ext}",
				"scoretype.{$this->php_ext}"
			),

			"ext/jv/arcade/inc/help/" => array(
				"faq.{$this->php_ext}",
				"index.htm",
				"soft_faq.{$this->php_ext}"
			),

			"ext/jv/arcade/inc/install/" => array(
				"data.{$this->php_ext}",
				"index.htm",
				"install.{$this->php_ext}",
				"schema.{$this->php_ext}",
				"verify.{$this->php_ext}"
			),

			"ext/jv/arcade/inc/" => array(
				".htaccess",
				"admin.{$this->php_ext}",
				"arcade.{$this->php_ext}",
				"challenge.{$this->php_ext}",
				"constants.{$this->php_ext}",
				"content.{$this->php_ext}",
				"display.{$this->php_ext}",
				"functions.{$this->php_ext}",
				"functions_file.{$this->php_ext}",
				"index.htm",
				"main.{$this->php_ext}",
				"menu.{$this->php_ext}",
				"phpbb.{$this->php_ext}",
				"stats.{$this->php_ext}",
				"tournament.{$this->php_ext}",
				"version_check.{$this->php_ext}",
				"viewonline.{$this->php_ext}"
			),

			"ext/jv/arcade/language/{LANG_PATH}/msg/"	=> $this->lang_files(1),
			"ext/jv/arcade/language/{LANG_PATH}/"		=> $this->lang_files(2),

			"ext/jv/arcade/mcp/" => array(
				"index.htm",
				"manage_info.{$this->php_ext}",
				"manage_module.{$this->php_ext}"
			),

			"ext/jv/arcade/migrations/" => array(
				".htaccess",
				"index.htm",
				"v_3_0_6_update.{$this->php_ext}",
				"v_4_0_RC1.{$this->php_ext}",
				"v_4_0_RC2.{$this->php_ext}",
				"v_4_0_RC3.{$this->php_ext}",
				"v_4_0_RC4.{$this->php_ext}",
				"v_4_0_RC5.{$this->php_ext}",
				"v_4_0_RC6.{$this->php_ext}",
				"v_4_1_RC1.{$this->php_ext}",
				"v_4_1_RC2.{$this->php_ext}",
				"v_4_1_0.{$this->php_ext}",
				"v_4_2_0.{$this->php_ext}",
				"v_4_2_1.{$this->php_ext}",
				"v_4_2_2.{$this->php_ext}",
				"v_4_2_3.{$this->php_ext}",
				"v_4_2_4.{$this->php_ext}",
				"v_4_2_5.{$this->php_ext}",
				"v_4_2_6.{$this->php_ext}",
				"v_4_2_7.{$this->php_ext}"
			),

			"ext/jv/arcade/styles/all/template/arcade/" => array(
				"arcade_cat_games.html",
				"arcade_cats.html",
				"arcadelist_body.html",
				"challenge_body.html",
				"detailed_stats_body.html",
				"download_body.html",
				"footer_body.html",
				"forum_cat_games.html",
				"forum_cats.html",
				"header.html",
				"index.htm",
				"index_body.html",
				"jumpbox.html",
				"login_cat.html",
				"main_box.html",
				"mcp_manage_games.html",
				"mcp_manage_tour.html",
				"online_body.html",
				"pagination.html",
				"play_body.html",
				"play_info_box.html",
				"popup_body.html",
				"ranking_body.html",
				"reports_body.html",
				"score_body.html",
				"script_body.html",
				"stats.html",
				"stats_body.html",
				"tournament_body.html",
				"ucp_favorites.html",
				"ucp_post.html",
				"ucp_settings.html"
			),

			"ext/jv/arcade/styles/all/template/event/" => array(
				"index.htm",
				"memberlist_view_user_statistics_after.html",
				"overall_footer_after.html",
				"overall_footer_body_after.html",
				"overall_footer_copyright_append.html",
				"overall_header_content_before.html",
				"overall_header_head_append.html",
				"overall_header_navigation_append.html",
				"simple_footer_after.html",
				"simple_header_head_append.html",
				"viewtopic_body_contact_fields_before.html"
			),

			"ext/jv/arcade/styles/all/template/" => array(
				"index.htm",
				"swfobject.js"
			),

			"ext/jv/arcade/styles/all/theme/images/cats/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/all/theme/images/ranks/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/all/theme/images/" => array(
				"1st.gif",
				"2nd.gif",
				"3rd.gif",
				"add_favorite.png",
				"automatic.png",
				"big.png",
				"flash_icon.png",
				"full_screen.png",
				"get_flash_player.png",
				"gold_crown.gif",
				"html5_icon.html",
				"icon_arcade.gif",
				"index.htm",
				"keyboard.png",
				"keyboard_mouse.png",
				"light_star.png",
				"lightbulb_off.png",
				"lightbulb_on.png",
				"loading1.gif",
				"loading2.gif",
				"logo.png",
				"logo_transparent.png",
				"mouse.png",
				"new_game.gif",
				"no_image.png",
				"noavatar.gif",
				"normal_screen.png",
				"open_close.png",
				"original.png",
				"popup.png",
				"remove_favorite.png",
				"small.png",
				"spacer.gif",
				"star.png",
				"trophy.gif"
			),

			"ext/jv/arcade/styles/all/theme/images/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/all/theme/" => array(
				"arcade.css",
				"arcade_colours.css",
				"arcade_responsive.css",
				"game_popup.css",
				"index.htm"
			),

			"ext/jv/arcade/styles/all/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver/theme/images/cats/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver/theme/images/ranks/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver/theme/images/" => array(
				"add_favorite.png",
				"icon_arcade.gif",
				"index.htm",
				"light_star.png",
				"loading1.gif",
				"loading2.gif",
				"open_close.png",
				"popup.png",
				"remove_favorite.png",
				"star.png"
			),

			"ext/jv/arcade/styles/prosilver/theme/images/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver/theme/" => array(
				"arcade_colours.css",
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver_se/template/arcade/" => array(
				"css.html",
				"index.htm",
				"main_box.html",
				"search_body.html",
				"stats_body.html"
			),

			"ext/jv/arcade/styles/prosilver_se/template/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver_se/theme/images/cats/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver_se/theme/images/ranks/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver_se/theme/images/" => array(
				"add_favorite.png",
				"icon_arcade.gif",
				"index.htm",
				"light_star.png",
				"open_close.png",
				"popup.png",
				"remove_favorite.png",
				"star.png"
			),

			"ext/jv/arcade/styles/prosilver_se/theme/images/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver_se/theme/" => array(
				"arcade_colours.css",
				"arcade_se.css",
				"index.htm"
			),

			"ext/jv/arcade/styles/prosilver_se/" => array(
				"index.htm"
			),

			"ext/jv/arcade/styles/" => array(
				"index.htm"
			),

			"ext/jv/arcade/ucp/" => array(
				"index.htm",
				"manage_info.{$this->php_ext}",
				"manage_module.{$this->php_ext}"
			),

			"ext/jv/arcade/" => array(
				"composer.json",
				"index.htm"
			),

			"ext/jv/arcade_startsystem/adm/style/event/" => array(
				"acp_jv_arcade_main_stats_before.html",
				"index.htm"
			),

			"ext/jv/arcade_startsystem/adm/style/" => array(
				"index.htm"
			),

			"ext/jv/arcade_startsystem/adm/" => array(
				"index.htm"
			),

			"ext/jv/arcade_startsystem/config/" => array(
				".htaccess",
				"index.htm",
				"services.yml"
			),

			"ext/jv/arcade_startsystem/event/" => array(
				".htaccess",
				"index.htm",
				"listener.{$this->php_ext}"
			),

			"ext/jv/arcade_startsystem/inc/" => array(
				".htaccess",
				"acp_settings.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/arcade_startsystem/language/de/" => array(
				"acp_main.{$this->php_ext}",
				"acp_settings.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/arcade_startsystem/language/en/" => array(
				"acp_main.{$this->php_ext}",
				"acp_settings.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/arcade_startsystem/language/hu/" => array(
				"acp_main.{$this->php_ext}",
				"acp_settings.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/arcade_startsystem/language/" => array(
				"index.htm"
			),

			"ext/jv/arcade_startsystem/migrations/" => array(
				".htaccess",
				"index.htm",
				"v_1_0_0.{$this->php_ext}"
			),

			"ext/jv/arcade_startsystem/" => array(
				"composer.json",
				"ext.{$this->php_ext}",
				"index.htm"
			),

			"ext/jv/" => array(
				"index.htm"
			),

			"games/" => array(
				"index.htm"
			),

			"" => array(
				"arcade.{$this->php_ext}"
			),
		);
	}

	public function lang_files($type = false)
	{
		$f = array(
			"ext/jv/arcade/language/{LANG_PATH}/msg/" => array(
				"arcade_pm.txt",
				"arcade_super_champion_pm.txt",
				"challenge_accept_pm.txt",
				"challenge_final_loser_pm.txt",
				"challenge_final_tie_pm.txt",
				"challenge_final_winner_pm.txt",
				"challenge_pm.txt",
				"challenge_reject_pm.txt",
				"challenge_report_game_pm.txt",
				"challenge_withdraw_pm.txt",
				"champions_game_announce.txt",
				"game_announce.txt",
				"global_announce.txt",
				"index.htm",
				"report_game_announce.txt",
				"tour_announce.txt",
				"tour_end_announce.txt"
			),
			"ext/jv/arcade/language/{LANG_PATH}/" => array(
				"arcade.{$this->php_ext}",
				"help_developer.{$this->php_ext}",
				"help_user.{$this->php_ext}",
				"index.htm",
				"info_acp_arcade.{$this->php_ext}",
				"info_mcp_arcade.{$this->php_ext}",
				"info_ucp_arcade.{$this->php_ext}",
				"install.{$this->php_ext}",
				"logs.{$this->php_ext}",
				"permissions_arcade.{$this->php_ext}"
			)
		);

		if ($type == 1)
		{
			$f = $f["ext/jv/arcade/language/{LANG_PATH}/msg/"];
		}
		else if ($type == 2)
		{
			$f = $f["ext/jv/arcade/language/{LANG_PATH}/"];
		}

		return $f;
	}

	public function configs()
	{
		return array(
			array('acp_items_per_page', 10),
			array('anim_game_over_winner', 1),
			array('anim_game_over_losing', 1),
			array('announce_author', $this->user->data['username']),
			array('announce_lang', $this->config['default_lang']),
			array('arcade_cat_size', 'small'),
			array('arcade_disable', 0),
			array('arcade_disable_msg', ''),
			array('arcade_leaders', 5),
			array('arcade_leaders_header', 3),
			array('arcade_pm', 1),
			array('arcade_rank', 1),
			array('arcade_resetdate', 0),
			array('arcade_startdate', time()),
			array('auto_disable', 0),
			array('auto_disable_end', ''),
			array('auto_reset_score', 0),
			array('auto_reset_score_hour', '0:00'),
			array('auto_reset_score_gc', 7776000),
			array('auto_reset_score_last_gc', time(), false),
			array('auto_reset_score_plays', 0),
			array('auto_disable_start', ''),
			array('backup_limit', 50),
			array('ban_user_ip', 1),
			array('cache_time', 24),
			array('cat_backup_path', 'arcade/backup/'),
			array('cat_leaders', 5),
			array('cat_least_downloaded', 5),
			array('cat_least_popular', 5),
			array('cat_least_played_users', 5),
			array('cat_most_played_users', 5),
			array('cat_longest_held_scores', 5),
			array('cat_most_downloaded', 5),
			array('cat_most_popular', 5),
			array('cat_super_record', 1),
			array('cat_super_champions', 5),
			array('challenge_acc_exp_date', 604800),
			array('challenge_disable', 0),
			array('challenge_disable_msg', ''),
			array('challenge_least_popular', 5),
			array('challenge_latest_winners', 5),
			array('challenge_least_played_users', 5),
			array('challenge_most_played_users', 5),
			array('challenge_leaders', 5),
			array('challenge_leaders_header', 3),
			array('challenge_most_popular', 5),
			array('challenge_ong_exp_date', 1209600),
			array('challenge_bet_minimum', 0),
			array('challenge_bet_maximum', 0),
			array('challenge_bet_fix', 0),
			array('challenge_exp_last_gc', time(), false),
			array('challenge_pm', 1),
			array('challenge_users_select', 1),
			array('challenge_resetdate', time()),
			array('challenge_top_games_header', 10),
			array('challenge_total_plays', 0, false),
			array('challenge_total_plays_time', 0, false),
			array('challenge_welcome_detailed_stats', 1),
			array('challenge_welcome_index', 1),
			array('challenge_welcome_stats', 1),
			array('champions_game_announce', 0),
			array('champions_game_announce_forum', 0),
			array('connect_domain', $this->contact()['connect_domain']),
			array('cookie_secure_info_time', 0),
			array('copyright', $this->copyright()),
			array('corrupt_score_banned', 0),
			array('default_cat_style', 1),
			array('default_cat_games_style', 1),
			array('default_games_sort_dir', 'd'),
			array('default_games_sort_order', 'd'),
			array('default_style', 0),
			array('display_cat_games_stats', 0),
			array('display_desc', 1),
			array('display_game_control', 1),
			array('display_game_type', 1),
			array('display_game_save_type', 1),
			array('display_memberlist', 1),
			array('display_viewtopic', 1),
			array('display_game_image', 1),
			array('display_game_popup_icon', 1),
			array('display_global_announce', 4),
			array('display_global_announce_author', 0),
			array('display_global_announce_guest', 0),
			array('display_user_avatar', 1),
			array('download_anonymous_interval', 0),
			array('download_interval', 0),
			array('download_list', 1),
			array('download_list_message', ''),
			array('download_list_per_page', 50),
			array('download_on_demand', 1),
			array('download_file_type', ''),
			array('download_per_day', 0),
			array('download_per_day_groups', ''),
			array('download_system', 1),
			array('enable_image_link', 1),
			array('enable_user_avatar_link', 1),
			array('first_score_reward', 0),
			array('flash_version', '28.0.0.0'),
			array('forum_rank', 0),
			array('founder_exempt', 0),
			array('game_announce', 0),
			array('game_announce_ignore_cats', ''),
			array('game_announce_sync_limit', 50),
			array('game_announce_forum', 0),
			array('game_autosize', 0),
			array('game_comment', 1),
			array('game_cost', 0),
			array('game_desc_translate', 0),
			array('game_desc_lang', ''),
			array('game_download_cost', 0),
			array('game_height', 0),
			array('game_over_sound', 1),
			array('game_path', 'arcade/games/'),
			array('game_preload', 1),
			array('game_reward', 0),
			array('game_scores', 5),
			array('game_width', 0),
			array('game_zero_negative_score', 0),
			array('game_time_check_time', 5),
			array('game_time_hack_banned', 0),
			array('game_time_tolerance_percent', 30),
			array('games_per_page', 10),
			array('gamename_maxchars', 12),
			array('global_announce', 0),
			array('global_announce_scroll', 0),
			array('global_announce_scroll_type', 'right'),
			array('global_announce_scroll_speed', 5),
			array('display_header', 1),
			array('install_games', 0),
			array('install_games_limit', 50),
			array('jackpot_maximum', 0),
			array('jackpot_minimum', 0),
			array('latest_highscores', 5),
			array('least_downloaded', 5),
			array('least_played_users', 5),
			array('least_popular', 5),
			array('least_jackpot', 5),
			array('least_users_playtime', 5),
			array('limit_play', 0),
			array('limit_play_days', 7),
			array('limit_play_posts', 10),
			array('limit_play_total_posts', 10),
			array('load_jumpbox', 1),
			array('load_list', 0),
			array('longest_held_scores', 5),
			array('most_downloaded', 5),
			array('most_played_users', 5),
			array('most_popular', 5),
			array('most_jackpot', 5),
			array('most_users_playtime', 5),
			array('new_games_delay', 5),
			array('newest_games', 10),
			array('newest_games_tooltip', 1),
			array('online_time', 0),
			array('override_user_cat_style', 0),
			array('parse_bbcode', 1),
			array('play_info_box', 'r'),
			array('paar', -1),
			array('parse_links', 1),
			array('parse_smilies', 1),
			array('play_anonymous_interval', 0),
			array('playfree_reward', 0),
			array('play_interval', 0),
			array('played_colour', 1),
			array('protect_amod', 0),
			array('protect_game_img', 0),
			array('protect_phpbbarcade', 0),
			array('protect_v3arcade', 0),
			array('random_games', 1),
			array('random_games_game_over', 3),
			array('random_games_game_over_enable', 1),
			array('random_challenge', 1),
			array('ranks_page', 0),
			array('record_playing_date', time(), false),
			array('record_playing_users', 0, false),
			array('report_game_announce', 0),
			array('report_game_announce_forum', 0),
			array('reports_open', 0),
			array('resolution_select', 1),
			array('score_form_token_lifetime', 10),
			array('score_security_level', 2),
			array('search_anonymous_interval', 0),
			array('search_cats', 1),
			array('search_detailed_stats', 1),
			array('search_filter_age', 0),
			array('search_filter_password', 0),
			array('search_index', 1),
			array('search_interval', 0),
			array('search_ranks', 0),
			array('search_stats', 1),
			array('session_last_gc', time(), false),
			array('session_length', 86400),
			array('shout_ignore_cats', ''),
			array('shout_score_type', 1),
			array('shout_user_id', 0),
			array('smilies_popup_height', 350),
			array('smilies_popup_width', 500),
			array('stat_items_per_page', 10),
			array('super_champion', 1),
			array('super_champion_avatar', 1),
			array('super_champion_avatar_width', 50),
			array('super_champion_avatar_height', 50),
			array('super_champions', 5),
			array('super_record_reward', 0),
			array('support_domain', $this->contact()['support_domain']),
			array('time_gc', 86400),
			array('total_downloads', 0, false),
			array('total_plays', 0, false),
			array('total_plays_time', 0, false),
			array('tour_announce', 0),
			array('tour_announce_forum', 0),
			array('tour_disable', 0),
			array('tour_disable_msg', ''),
			array('tour_display_news', 0),
			array('tour_display_news_icons', 0),
			array('tour_news_count_start', 5),
			array('tour_news_count_end', 5),
			array('tour_news_icons_count', 10),
			array('tour_news_icons_size', 15),
			array('tour_news_max_display_day', 3),
			array('tour_latest_winners', 5),
			array('tour_leaders', 5),
			array('tour_leaders_header', 3),
			array('tour_least_played_users', 5),
			array('tour_least_popular', 5),
			array('tour_max_games', 20),
			array('tour_min_games', 3),
			array('tour_most_played_users', 5),
			array('tour_most_popular', 5),
			array('tour_reward_enable', 0),
			array('tour_reward_min', 0),
			array('tour_reward_max', 0),
			array('tour_top_games', 10),
			array('tour_total', 0),
			array('tour_total_plays', 0, false),
			array('tour_total_plays_time', 0, false),
			array('tour_welcome_index', 1),
			array('tour_welcome_stats', 1),
			array('tournament_welcome_detailed_stats', 1),
			array('unpack_game_path', 'arcade/install/'),
			array('unpack_games_limit', 200),
			array('username_maxchars', 0),
			array('use_jackpot', 0),
			array('use_points', 0),
			array('use_shout', 0),
			array('version', $this->version()),
			array('version_check_enable', 1),
			array('watermark_game_img', 1),
			array('watermark_min_size', 50),
			array('welcome_cats', 1),
			array('welcome_detailed_stats', 1),
			array('welcome_index', 1),
			array('welcome_stats', 1),
			array('welcome_ranks', 1)
		);
	}

	public function tables()
	{
		return array(
			"{$this->table_prefix}acl_arcade_groups", "{$this->table_prefix}acl_arcade_options", "{$this->table_prefix}acl_arcade_roles", "{$this->table_prefix}acl_arcade_roles_data",
			"{$this->table_prefix}acl_arcade_users", "{$this->table_prefix}arcade_access", "{$this->table_prefix}arcade_announce", "{$this->table_prefix}arcade_announce_data",
			"{$this->table_prefix}arcade_categories", "{$this->table_prefix}arcade_challenge", "{$this->table_prefix}arcade_challenge_champ", "{$this->table_prefix}arcade_config",
			"{$this->table_prefix}arcade_delete_games", "{$this->table_prefix}arcade_download", "{$this->table_prefix}arcade_favorites", "{$this->table_prefix}arcade_games",
			"{$this->table_prefix}arcade_game_rating", "{$this->table_prefix}arcade_logs", "{$this->table_prefix}arcade_menu", "{$this->table_prefix}arcade_plays",
			"{$this->table_prefix}arcade_ranks", "{$this->table_prefix}arcade_reports", "{$this->table_prefix}arcade_scores",
			"{$this->table_prefix}arcade_sessions", "{$this->table_prefix}arcade_super_scores", "{$this->table_prefix}arcade_tour", "{$this->table_prefix}arcade_tour_champ",
			"{$this->table_prefix}arcade_tour_wins", "{$this->table_prefix}arcade_users", "{$this->table_prefix}arcade_users_banned"
		);
	}

	public function ucp_modules()
	{
		return array('UCP_CAT_ARCADE', 'UCP_ARCADE_SETTINGS', 'UCP_ARCADE_POST', 'UCP_ARCADE_FAVORITES');
	}

	public function mcp_modules()
	{
		return array('MCP_CAT_ARCADE', 'MCP_ARCADE_MANAGE_GAMES', 'MCP_ARCADE_MANAGE_TOUR');
	}

	public function acp_modules()
	{
		return array(
				'ACP_CAT_ARCADE', 'ACP_ARCADE_MAIN_INDEX',
				'ACP_CAT_ARCADE_SETTINGS', 'ACP_ARCADE_SETTINGS_GENERAL', 'ACP_ARCADE_SETTINGS_GAME', 'ACP_ARCADE_SETTINGS_CHALLENGE', 'ACP_ARCADE_SETTINGS_TOUR',
				'ACP_ARCADE_SETTINGS_FEATURE', 'ACP_ARCADE_SETTINGS_ARCADE_PAGE', 'ACP_ARCADE_SETTINGS_CHALLENGE_PAGE', 'ACP_ARCADE_SETTINGS_TOUR_PAGE',
				'ACP_ARCADE_SETTINGS_PATH', 'ACP_ARCADE_SETTINGS_LOAD', 'ACP_ARCADE_SETTINGS_PAAR',
				'ACP_CAT_ARCADE_MANAGE', 'ACP_ARCADE_MANAGE_MENU', 'ACP_ARCADE_MANAGE_ANNOUNCE', 'ACP_ARCADE_MANAGE_RANKS',
				'ACP_ARCADE_MANAGE_CATEGORIES', 'ACP_ARCADE_MANAGE_GAMES', 'ACP_ARCADE_MANAGE_USERS', /*'ACP_ARCADE_MANAGE_CHALLENGES',*/ 'ACP_ARCADE_MANAGE_TOUR',
				'ACP_CAT_ARCADE_GAMES_FEATURE', 'ACP_ARCADE_ADD_GAMES', 'ACP_ARCADE_UNPACK_GAMES', 'ACP_ARCADE_BACKUP_GAMES', 'ACP_ARCADE_DOWNLOADS_GAMES',
				'ACP_CAT_ARCADE_UTILITIES', 'ACP_ARCADE_UTILITIES_REPORTS', 'ACP_ARCADE_UTILITIES_DELETED_GAMES', 'ACP_ARCADE_UTILITIES_USERS_BANNED', 'ACP_ARCADE_UTILITIES_DOWNLOAD_STATS',
				'ACP_ARCADE_UTILITIES_CREATE_INSTALL', 'ACP_ARCADE_UTILITIES_USER_GUIDE',
				'ACP_CAT_ARCADE_LOGS', 'ACP_ARCADE_LOGS_ADMIN', 'ACP_ARCADE_LOGS_MOD', 'ACP_ARCADE_LOGS_USERS', 'ACP_ARCADE_LOGS_CRITICAL',
				'ACP_CAT_ARCADE_PERMISSION_ROLES', 'ACP_ARCADE_CAT_ROLES',
				'ACP_CAT_ARCADE_PERMISSIONS', 'ACP_ARCADE_CATEGORY_PERMISSIONS', 'ACP_ARCADE_CATEGORY_PERMISSIONS_COPY', 'ACP_ARCADE_USERS_CATEGORY_PERMISSIONS', 'ACP_ARCADE_GROUPS_CATEGORY_PERMISSIONS',
				'ACP_CAT_ARCADE_PERMISSION_MASKS',  'ACP_ARCADE_PERMISSION_TRACE', 'ACP_VIEW_ARCADE_CATEGORY_PERMISSIONS',
				'ACP_CAT_ARCADE_INSTALL_FEATURES', 'ACP_ARCADE_INSTALL_VERIFY', 'ACP_ARCADE_INSTALL_UPDATE_GAME_DATA', 'ACP_ARCADE_INSTALL_CONVERT_GAME_INS_FILE'
		);
	}

	public function phpbb_permission()
	{
		return array(
			'a_arcade', 'a_arcade_menu', 'a_arcade_announce', 'a_arcade_backup', 'a_cauth', 'a_arcade_settings', 'a_arcade_points_settings', 'a_arcade_game', 'a_arcade_delete_game', 'a_arcade_cat', 'a_arcade_delete_cat', 'a_arcade_user', 'a_arcade_utilities', 'a_arcade_viewlogs', 'a_arcade_clearlogs', 'a_arcade_tour', 'a_arcade_reset_game', 'a_arcade_delete_tour', 'a_arcade_ranks', 'a_arcade_install',
			'm_arcade_game', 'm_arcade_reset_game', 'm_arcade_change_gamename', 'm_arcade_tour', 'm_arcade_tour_reward',
			'u_arcade', 'u_arcade_challenge', 'u_arcade_download', 'u_arcade_favorites', 'u_arcade_ignoreflood_search', 'u_arcade_popup', 'u_arcade_pm', 'u_arcade_resolution', 'u_arcade_search', 'u_arcade_view_whoisplaying', 'u_arcade_viewstats', 'u_arcade_tour'
		);
	}

	public function arcade_permission()
	{
		return array(
			'c_', 'c_list', 'c_view', 'c_play', 'c_playfree', 'c_score', 'c_rate', 'c_re_rate', 'c_comment', 'c_report', 'c_download', 'c_ignorecontrol', 'c_ignoreflood_download', 'c_ignoreflood_play', 'c_downloadfree',
			'u_'
		);
	}

	public function arcade_roles()
	{
		return array(
			array('ROLE_ARCADE_NOACCESS'			, 'c_', 'ROLE_DESCRIPTION_ARCADE_NOACCESS'),
			array('ROLE_ARCADE_FULL'				, 'c_', 'ROLE_DESCRIPTION_ARCADE_FULL'),
			array('ROLE_ARCADE_LIMITED'				, 'c_', 'ROLE_DESCRIPTION_ARCADE_LIMITED'),
			array('ROLE_ARCADE_PLAYONLY'			, 'c_', 'ROLE_DESCRIPTION_ARCADE_PLAYONLY'),
			array('ROLE_ARCADE_STANDARD'			, 'c_', 'ROLE_DESCRIPTION_ARCADE_STANDARD'),
			array('ROLE_ARCADE_STANDARD_DOWNLOADS'	, 'c_', 'ROLE_DESCRIPTION_ARCADE_STANDARD_DOWNLOADS'),
			array('ROLE_ARCADE_VIEWONLY'			, 'c_', 'ROLE_DESCRIPTION_ARCADE_VIEWONLY')
		);
	}

	public function arcade_roles_set()
	{
		return array(
			array('ROLE_ARCADE_NOACCESS'			, 'c_', 'role', false),
			array('ROLE_ARCADE_FULL'				, array('c_', 'c_list', 'c_view', 'c_play', 'c_playfree', 'c_score', 'c_rate', 'c_re_rate', 'c_comment', 'c_report', 'c_download', 'c_ignorecontrol', 'c_ignoreflood_download', 'c_ignoreflood_play', 'c_downloadfree')),
			array('ROLE_ARCADE_LIMITED'				, array('c_', 'c_list', 'c_view', 'c_play', 'c_score')),
			array('ROLE_ARCADE_PLAYONLY'			, array('c_', 'c_list', 'c_view', 'c_play')),
			array('ROLE_ARCADE_STANDARD'			, array('c_', 'c_list', 'c_view', 'c_play', 'c_score', 'c_rate', 'c_comment', 'c_report')),
			array('ROLE_ARCADE_STANDARD_DOWNLOADS'	, array('c_', 'c_list', 'c_view', 'c_play', 'c_score', 'c_rate', 'c_comment', 'c_report', 'c_download')),
			array('ROLE_ARCADE_VIEWONLY'			, array('c_', 'c_list', 'c_view'))
		);
	}

	public function bbcodes()
	{
		return array(
			'arcade-js'				=> array(
				'bbcode_match'			=> '[arcade-js={SIMPLETEXT}]{LOCAL_URL}[/arcade-js]',
				'bbcode_tpl'			=> '<span data-jvarcade_translate="true" data-mode="{SIMPLETEXT}" data-url="{LOCAL_URL}">{SIMPLETEXT}</span>',
				'bbcode_helpline'		=> '',
				'display_on_posting'	=> 0
			),
			'arcade_popup'				=> array(
				'bbcode_match'			=> '[arcade_popup={NUMBER1},{NUMBER2}]{LOCAL_URL}[/arcade_popup]',
				'bbcode_tpl'			=> '<a href="{LOCAL_URL}" data-jvarcade="game_popup" data-width="{NUMBER1}" data-height="{NUMBER2}">{L_ARCADE_PLAYING_NEW_WINDOW}</a>',
				'bbcode_helpline'		=> '',
				'display_on_posting'	=> 0
			)
		);
	}

	public function menu()
	{
		return array(
			array( 1, 1, 1, 0, 'ARCADE',					'fa-gamepad',			'',					'',														'',				 0,  1, 77, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)'),
			array( 2, 1, 1, 0, 'ARCADE',					'fa-gamepad',			'arcade',			'',														'',				 1,  2, 15, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)'),
			array( 3, 1, 1, 0, 'ARCADE_SEARCH_NEW_GAMES',	'',						'arcade',			'mode=search&amp;search_id=newgames',					'top_games',	 2,  3,  4, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_search && aclc_c_play'),
			array( 4, 1, 1, 0, 'ARCADE_FEELING_LUCKY',		'',						'data-jvarcade',	'data-jvarcade="random_game"',							'',				 2,  5,  6, '!user_is_bot && acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acfg_random_games && aclc_c_play'),
			array( 5, 1, 1, 0, 'ARCADE_MY_FAVORITE_GAMES',	'',						'arcade',			'mode=fav',												'top_games',	 2,  7,  8, 'user_is_registered && acl_u_arcade && acl_u_arcade_favorites && (acl_a_ || !acfg_arcade_disable)'),
			array( 6, 1, 1, 0, 'ARCADE_MY_STATS',			'',						'arcade',			'mode=stats&amp;u={USER_ID}',							'userbox',		 2,  9, 10, 'user_is_registered && acl_u_arcade && acl_u_arcade_viewstats && (acl_a_ || !acfg_arcade_disable)'),
			array( 7, 1, 1, 0, 'ARCADE_STATS',				'',						'arcade',			'mode=stats',											'1',			 2, 11, 12, 'acl_u_arcade && acl_u_arcade_viewstats && (acl_a_ || !acfg_arcade_disable)'),
			array( 8, 1, 1, 0, 'ARCADE_RANKING',			'',						'arcade',			'mode=ranking',											'',				 2, 13, 14, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acfg_ranks_page'),
			array( 9, 1, 1, 0, 'CHALLENGE',					'fa-bolt',				'arcade',			'mode=challenge',										'',				 1, 16, 23, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_challenge && (user_is_registered && acl_a_ || !acfg_challenge_disable))'),
			array(10, 1, 1, 0, 'CHALLENGE_RANDOM',			'',						'arcade',			'mode=rand_challenge',									'',				 9, 17, 18, 'user_is_registered && (acl_u_arcade && (acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_challenge && (acl_a_ || !acfg_challenge_disable)) && acfg_random_challenge && aclc_c_play'),
			array(11, 1, 1, 0, 'ARCADE_MY_STATS',			'',						'arcade',			'mode=stats&amp;type=challenge&amp;u={USER_ID}',		'userbox',		 9, 19, 20, 'user_is_registered && (acl_u_arcade && (acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_challenge && (acl_a_ || !acfg_challenge_disable)) && acl_u_arcade_viewstats'),
			array(12, 1, 1, 0, 'ARCADE_STATS',				'',						'arcade',			'mode=stats&amp;type=challenge',						'1',			 9, 21, 22, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_challenge && (user_is_registered && acl_a_ || !acfg_challenge_disable)) && acl_u_arcade_viewstats'),
			array(13, 1, 1, 0, 'TOURNAMENT',				'fa-rocket',			'arcade',			'mode=tournament',										'',				 1, 24, 31, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_tour && (user_is_registered && acl_a_ || !acfg_tour_disable))'),
			array(14, 1, 1, 0, 'ARCADE_FINISHED_TOURS',		'',						'arcade',			'mode=tournament&amp;type=final',						'tour_top',		13, 25, 26, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_tour && (user_is_registered && acl_a_ || !acfg_tour_disable))'),
			array(15, 1, 1, 0, 'ARCADE_MY_STATS',			'',						'arcade',			'mode=stats&amp;type=tournament&amp;u={USER_ID}',		'userbox',		13, 27, 28, 'user_is_registered && acl_u_arcade_viewstats && (acl_u_arcade && (acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_tour && (acl_a_ || !acfg_tour_disable))'),
			array(16, 1, 1, 0, 'ARCADE_STATS',				'',						'arcade',			'mode=stats&amp;type=tournament',						'1',			13, 29, 30, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_tour && (user_is_registered && acl_a_ || !acfg_tour_disable)) && acl_u_arcade_viewstats'),
			array(17, 1, 1, 0, 'ARCADE_DETAILED_STATS',		'fa-indent',			'',					'',														'',				 1, 32, 67, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(18, 1, 1, 0, 'ARCADE_STATISTICS',			'',						'',					'',														'',				17, 33, 50, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(19, 1, 1, 0, 'ARCADE_PLAYED_GAMES',		'',						'arcade',			'mode=stats&amp;ds=played_games',						'1',			18, 34, 35, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(20, 1, 1, 0, 'ARCADE_NOT_PLAYED_GAMES',	'',						'arcade',			'mode=stats&amp;ds=not_played_games',					'1',			18, 36, 37, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(21, 1, 1, 0, 'ARCADE_PLAYED_USERS',		'',						'arcade',			'mode=stats&amp;ds=played_users',						'1',			18, 38, 39, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(22, 1, 1, 0, 'ARCADE_HIGHSCORES',			'',						'arcade',			'mode=stats&amp;ds=highscores',							'1',			18, 40, 41, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(23, 1, 1, 0, 'ARCADE_SUPER_CHAMPIONS',	'',						'arcade',			'mode=stats&amp;ds=super_champions',					'1',			18, 42, 43, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(24, 1, 1, 0, 'ARCADE_GAME_FAVS',			'',						'arcade',			'mode=stats&amp;ds=favs',								'1',			18, 44, 45, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(25, 1, 1, 0, 'ARCADE_RATED_GAMES',		'',						'arcade',			'mode=stats&amp;ds=rated_games',						'1',			18, 46, 47, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats'),
			array(26, 1, 1, 0, 'ARCADE_GAMES_JACKPOTS',		'',						'arcade',			'mode=stats&amp;ds=games_jackpots',						'1',			18, 48, 49, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable) && acl_u_arcade_viewstats && points_show'),
			array(27, 1, 1, 0, 'ARCADE_CHALLENGE_STATS',	'',						'',					'',														'',				17, 51, 58, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_challenge && (user_is_registered && acl_a_ || !acfg_challenge_disable)) && acl_u_arcade_viewstats'),
			array(28, 1, 1, 0, 'ARCADE_PLAYED_GAMES',		'',						'arcade',			'mode=stats&amp;ds=challenge_played_games',				'1',			27, 52, 53, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_challenge && (user_is_registered && acl_a_ || !acfg_challenge_disable)) && acl_u_arcade_viewstats'),
			array(29, 1, 1, 0, 'ARCADE_PLAYED_USERS',		'',						'arcade',			'mode=stats&amp;ds=challenge_played_users',				'1',			27, 54, 55, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_challenge && (user_is_registered && acl_a_ || !acfg_challenge_disable)) && acl_u_arcade_viewstats'),
			array(30, 1, 1, 0, 'ARCADE_WINNERS',			'',						'arcade',			'mode=stats&amp;ds=challenge_winners',					'1',			27, 56, 57, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_challenge && (user_is_registered && acl_a_ || !acfg_challenge_disable)) && acl_u_arcade_viewstats'),
			array(31, 1, 1, 0, 'ARCADE_TOUR_STATS',			'',						'',					'',														'',				17, 59, 66, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_tour && (user_is_registered && acl_a_ || !acfg_tour_disable)) && acl_u_arcade_viewstats'),
			array(32, 1, 1, 0, 'ARCADE_PLAYED_GAMES',		'',						'arcade',			'mode=stats&amp;ds=tours_played_games',					'1',			31, 60, 61, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_tour && (user_is_registered && acl_a_ || !acfg_tour_disable)) && acl_u_arcade_viewstats'),
			array(33, 1, 1, 0, 'ARCADE_PLAYED_USERS',		'',						'arcade',			'mode=stats&amp;ds=tours_played_users',					'1',			31, 62, 63, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_tour && (user_is_registered && acl_a_ || !acfg_tour_disable)) && acl_u_arcade_viewstats'),
			array(34, 1, 1, 0, 'ARCADE_WINNERS',			'',						'arcade',			'mode=stats&amp;ds=tours_winners',						'1',			31, 64, 65, '(acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)) && (acl_u_arcade_tour && (user_is_registered && acl_a_ || !acfg_tour_disable)) && acl_u_arcade_viewstats'),
			array(35, 1, 1, 0, 'SETTINGS',					'fa-cogs',				'ucp',				'i=-jv-arcade-ucp-manage_module&amp;mode=settings',		'tabs',			 1, 68, 73, 'user_is_registered && acl_u_arcade && (acl_a_ || !acfg_arcade_disable)'),
			array(36, 1, 1, 0, 'POST',						'',						'ucp',				'i=-jv-arcade-ucp-manage_module&amp;mode=post',			'tabs',			35, 69, 70, 'user_is_registered && acl_u_arcade && (acl_a_ || !acfg_arcade_disable)'),
			array(37, 1, 1, 0, 'ARCADE_GAME_FAVS',			'',						'ucp',				'i=-jv-arcade-ucp-manage_module&amp;mode=favorites',	'tabs',			35, 71, 72, 'user_is_registered && acl_u_arcade && (acl_a_ || !acfg_arcade_disable) && acl_u_arcade_favorites'),
			array(38, 1, 1, 0, 'FAQ',						'fa-question-circle',	'app/help',			'arcade_faq',											'faqlinks',		 1, 75, 76, 'acl_u_arcade && (user_is_registered && acl_a_ || !acfg_arcade_disable)')
		);
	}
}
