<?php
/**
*
* @package phpBB Arcade
* @version $Id: install.php 2023 2018-06-24 14:52:20Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\install;

use jv\arcade\inc as arcade_inc;

class install
{
	public $data;
	public $schema;
	public $verify;

	protected $db, $arcade, $php_ext, $table_prefix;

	public function __construct($db, $php_ext, $table_prefix, $arcade = null)
	{
		$this->db = $db;
		$this->php_ext = $php_ext;
		$this->table_prefix = $table_prefix;
		$this->arcade = $arcade;
	}

	public function main($mode)
	{
		if ($mode == 'install' || $mode == 'verify')
		{
			if (!isset($this->data))
			{
				$this->data = $this->arcade->container('install_data');
			}

			if (!isset($this->schema))
			{
				$this->schema = $this->arcade->container('install_schema')->data($this->table_prefix);
			}

			if (!isset($this->verify))
			{
				$this->verify = $this->arcade->container('install_verify');
			}
		}

		return $this;
	}

	public function bbcode_exists($bbcode_tag)
	{
		$sql = 'SELECT bbcode_id
				FROM ' . BBCODES_TABLE . "
				WHERE bbcode_tag = '" . $this->db->sql_escape($bbcode_tag) . "'";
		$result = $this->db->sql_query($sql);
		$bbcode_id = (int) $this->db->sql_fetchfield('bbcode_id');
		$this->db->sql_freeresult($result);

		return $bbcode_id;
	}

	public function installed_languages($lang_iso = false)
	{
		$sql = 'SELECT lang_id, lang_iso FROM ' . LANG_TABLE;

		if ($lang_iso)
		{
			$sql .= " WHERE lang_iso != '" . $this->db->sql_escape($lang_iso) . "'";
		}

		$result = $this->db->sql_query($sql);
		$installed_languages = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$installed_languages[$row['lang_id']] = $row['lang_iso'];
		}
		$this->db->sql_freeresult($result);

		return $installed_languages;
	}

	public function check_cons()
	{
		if ($this->arcade === null && !defined('ARCADE_VERSION'))
		{
			global $phpbb_container;
			$ext_path = $phpbb_container->get('ext.manager')->get_extension_path('jv/arcade', true);
			include($ext_path . 'inc/constants.' . $this->php_ext);
			new arcade_inc\constants($this->table_prefix);
		}
	}

	private function multicall($function, $params)
	{
		$this->check_cons();

		if (is_array($params) && !empty($params))
		{
			foreach ($params as $param)
			{
				if (!is_array($param))
				{
					call_user_func(array($this, $function), $param);
				}
				else
				{
					call_user_func_array(array($this, $function), $param);
				}
			}

			return true;
		}

		return false;
	}

	public function set_config($config_name, $config_value = '', $use_cache = true)
	{
		if ($this->multicall(__FUNCTION__, $config_name))
		{
			return;
		}

		global $arcade_config;

		if (!isset($arcade_config))
		{
			global $cache;
			$arcade_config = new arcade_inc\config\db($this->db, $cache, "{$this->table_prefix}arcade_config");
		}

		$arcade_config->set($config_name, $config_value, $use_cache);

		return true;
	}

	public function delete_config($config_name, $use_cache = true)
	{
		if ($this->multicall(__FUNCTION__, $config_name))
		{
			return;
		}

		global $arcade_config;

		if (!isset($arcade_config))
		{
			global $cache;
			$arcade_config = new arcade_inc\config\db($this->db, $cache, "{$this->table_prefix}arcade_config");
		}

		$arcade_config->delete($config_name, $use_cache);

		return true;
	}

	public function permission_exists($auth_option, $global = true)
	{
		if (substr($auth_option, 0, 2) == 'c_')
		{
			$global = false;
		}

		if ($global)
		{
			$type_sql = ' AND is_global = 1';
		}
		else
		{
			$type_sql = ' AND is_local = 1';
		}

		$sql = 'SELECT auth_option_id
				FROM ' . ACL_ARCADE_OPTIONS_TABLE . "
				WHERE auth_option = '" . $this->db->sql_escape($auth_option) . "'"
				. $type_sql;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if ($row)
		{
			return true;
		}

		return false;
	}

	public function permission_add($auth_option, $global = true)
	{
		if ($this->multicall(__FUNCTION__, $auth_option))
		{
			return;
		}

		if (substr($auth_option, 0, 2) == 'c_')
		{
			$global = false;
		}

		if ($this->permission_exists($auth_option, $global))
		{
			return false;
		}

		// We have to add a check to see if the !$global (if global, local, and if local, global) permission already exists.  If it does, acl_add_option currently has a bug which would break the ACL system, so we are having a work-around here.
		if ($this->permission_exists($auth_option, !$global))
		{
			$sql_ary = array(
				'is_global'	=> 1,
				'is_local'	=> 1,
			);
			$sql = 'UPDATE ' . ACL_ARCADE_OPTIONS_TABLE . '
					SET ' . $db->sql_build_array('UPDATE', $sql_ary) . "
					WHERE auth_option = '" . $db->sql_escape($auth_option) . "'";
			$db->sql_query($sql);
		}
		else
		{
			$auth_admin = new arcade_inc\auth\auth_admin();
			$auth_admin->acl_add_option(array((($global) ? 'global' : 'local') => array($auth_option)));
		}

		return true;
	}

	public function permission_role_add($role_name, $role_type = '', $role_description = '')
	{
		if ($this->multicall(__FUNCTION__, $role_name))
		{
			return;
		}

		$sql = 'SELECT role_id FROM ' . ACL_ARCADE_ROLES_TABLE . "
				WHERE role_name = '" . $this->db->sql_escape($role_name) . "'";
		$result = $this->db->sql_query($sql);
		$role_id = (int) $this->db->sql_fetchfield('role_id');
		$this->db->sql_freeresult($result);

		if ($role_id)
		{
			return false;
		}

		$sql = 'SELECT MAX(role_order) AS max FROM ' . ACL_ARCADE_ROLES_TABLE . "
				WHERE role_type = '" . $this->db->sql_escape($role_type) . "'";
		$result = $this->db->sql_query($sql);
		$role_order = (int) $this->db->sql_fetchfield('max');
		$this->db->sql_freeresult($result);
		$role_order = (!$role_order) ? 1 : $role_order + 1;

		$sql_ary = array(
			'role_name'			=> $role_name,
			'role_description'	=> $role_description,
			'role_type'			=> $role_type,
			'role_order'		=> $role_order
		);

		$this->db->sql_query('INSERT INTO ' . ACL_ARCADE_ROLES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));

		return true;
	}

	public function permission_set($name, $auth_option = array(), $type = 'role', $has_permission = true)
	{
		if ($this->multicall(__FUNCTION__, $name))
		{
			return;
		}

		if (!is_array($auth_option))
		{
			$auth_option = array($auth_option);
		}

		$new_auth = array();
		$sql = 'SELECT auth_option_id FROM ' . ACL_ARCADE_OPTIONS_TABLE . '
				WHERE ' . $this->db->sql_in_set('auth_option', $auth_option);
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$new_auth[] = $row['auth_option_id'];
		}
		$this->db->sql_freeresult($result);

		if (!count($new_auth))
		{
			return false;
		}

		$current_auth = array();

		switch ($type)
		{
			case 'role' :
				$sql = 'SELECT role_id FROM ' . ACL_ARCADE_ROLES_TABLE . "
						WHERE role_name = '" . $this->db->sql_escape($name) . "'";
				$result = $this->db->sql_query($sql);
				$role_id = (int) $this->db->sql_fetchfield('role_id');
				$this->db->sql_freeresult($result);

				if (!$role_id)
				{
					return false;
				}

				$sql = 'SELECT auth_option_id, auth_setting FROM ' . ACL_ARCADE_ROLES_DATA_TABLE . '
						WHERE role_id = ' . $role_id;
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$current_auth[$row['auth_option_id']] = $row['auth_setting'];
				}
				$this->db->sql_freeresult($result);
			break;

			case 'group' :
				$sql = 'SELECT group_id
						FROM ' . GROUPS_TABLE . "
						WHERE group_name = '" . $this->db->sql_escape($name) . "'";
				$result = $this->db->sql_query($sql);
				$group_id = (int) $this->db->sql_fetchfield('group_id');
				$this->db->sql_freeresult($result);

				if (!$group_id)
				{
					return false;
				}

				$sql = 'SELECT auth_role_id FROM ' . ACL_ARCADE_GROUPS_TABLE . '
						WHERE group_id = ' . $group_id . '
						AND auth_role_id <> 0
						AND cat_id = 0';
				$result = $this->db->sql_query($sql);
				$role_id = (int) $this->db->sql_fetchfield('auth_role_id');
				$this->db->sql_freeresult($result);

				if ($role_id)
				{
					$sql = 'SELECT role_name FROM ' . ACL_ARCADE_ROLES_TABLE . '
							WHERE role_id = ' . $role_id;
					$result = $this->db->sql_query($sql);
					$role_name = $this->db->sql_fetchfield('role_name');
					$this->db->sql_freeresult($result);

					return $this->permission_set($role_name, $auth_option, 'role', $has_permission);
				}

				$sql = 'SELECT auth_option_id, auth_setting FROM ' . ACL_ARCADE_GROUPS_TABLE . '
						WHERE group_id = ' . $group_id;
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$current_auth[$row['auth_option_id']] = $row['auth_setting'];
				}
				$this->db->sql_freeresult($result);
			break;
		}

		$sql_ary = array();
		switch ($type)
		{
			case 'role' :
				foreach ($new_auth as $auth_option_id)
				{
					if (!isset($current_auth[$auth_option_id]))
					{
						$sql_ary[] = array(
							'role_id'			=> $role_id,
							'auth_option_id'	=> $auth_option_id,
							'auth_setting'		=> $has_permission
						);
					}
				}

				$this->db->sql_multi_insert(ACL_ARCADE_ROLES_DATA_TABLE, $sql_ary);
			break;

			case 'group' :
				foreach ($new_auth as $auth_option_id)
				{
					if (!isset($current_auth[$auth_option_id]))
					{
						$sql_ary[] = array(
							'group_id'			=> $group_id,
							'auth_option_id'	=> $auth_option_id,
							'auth_setting'		=> $has_permission
						);
					}
				}

				$this->db->sql_multi_insert(ACL_ARCADE_GROUPS_TABLE, $sql_ary);
			break;
		}

		$arcade_auth = new arcade_inc\auth\auth();
		$arcade_auth->acl_clear_prefetch();

		return true;
	}

	public function add_bbcodes($bbcodes)
	{
		if (!is_array($bbcodes) || !count($bbcodes))
		{
			return;
		}

		global $cache, $phpbb_root_path;

		if (!class_exists('acp_bbcodes'))
		{
			include($phpbb_root_path . 'includes/acp/acp_bbcodes.' . $this->php_ext);
		}

		$acp_bbcodes = new \acp_bbcodes();

		$sql = 'SELECT MAX(bbcode_id) as max_bbcode_id
				FROM ' . BBCODES_TABLE;
		$result = $this->db->sql_query($sql);
		$max_bbcode_id = (int) $this->db->sql_fetchfield('max_bbcode_id');
		$this->db->sql_freeresult($result);

		$next_bbcode_id = $max_bbcode_id;

		if (($max_bbcode_id + 1) <= NUM_CORE_BBCODES)
		{
			$next_bbcode_id = NUM_CORE_BBCODES;
		}

		foreach ($bbcodes as $bbcode_tag => $values)
		{
			$sql_ary = $acp_bbcodes->build_regexp($values['bbcode_match'], $values['bbcode_tpl']);

			$sql_ary = array_merge($sql_ary, array(
				'bbcode_match'			=> $values['bbcode_match'],
				'bbcode_tpl'			=> $values['bbcode_tpl'],
				'display_on_posting'	=> $values['display_on_posting'],
				'bbcode_helpline'		=> $values['bbcode_helpline']
			));

			if ($bbcode_id = $this->bbcode_exists($bbcode_tag))
			{
				$sql = 'UPDATE ' . BBCODES_TABLE . '
						SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
						WHERE bbcode_id = ' . $bbcode_id;
				$this->db->sql_query($sql);
			}
			else
			{
				$next_bbcode_id++;
				$sql_ary['bbcode_id'] = $next_bbcode_id;

				$this->db->sql_query('INSERT INTO ' . BBCODES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
			}
		}

		$cache->destroy('sql', BBCODES_TABLE);
	}

	public function add_menu($menu_data)
	{
		$sql_ary = array();
		foreach ($menu_data as $row)
		{
			$sql_ary[] = array(
				'menu_id'		=> $row[0],
				'menu_type'		=> $row[1],
				'menu_display'	=> $row[2],
				'new_window'	=> $row[3],
				'menu_name'		=> $row[4],
				'menu_fa'		=> $row[5],
				'menu_page'		=> $row[6],
				'params'		=> $row[7],
				'menu_top'		=> $row[8],
				'parent_id'		=> $row[9],
				'left_id'		=> $row[10],
				'right_id'		=> $row[11],
				'auth'			=> $row[12]
			);
		}

		$this->db->sql_multi_insert("{$this->table_prefix}arcade_menu", $sql_ary);
	}
}
