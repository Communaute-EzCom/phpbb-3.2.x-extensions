<?php
/**
*
* @package phpBB Arcade
* @version $Id: display.php 2035 2018-07-25 11:10:48Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class display
{
	protected $container, $db, $cache, $user, $auth, $config, $request, $template, $arcade_cache, $arcade_auth, $arcade_config, $arcade, $root_path, $php_ext;

	public function __construct($container, $db, $cache, $user, $auth, $config, $request, $template, $arcade_cache, $arcade_auth, $arcade_config, $arcade, $root_path, $php_ext)
	{
		$this->container = $container;
		$this->db = $db;
		$this->cache = $cache;
		$this->user = $user;
		$this->auth = $auth;
		$this->config = $config;
		$this->request = $request;
		$this->template = $template;
		$this->arcade_cache = $arcade_cache;
		$this->arcade_auth = $arcade_auth;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function header_information()
	{
		global $inc_challenge;

		$active = false;
		if (!$this->user->data['is_bot'])
		{
			if (empty($inc_challenge) && $this->user->data['is_registered'] && $this->arcade->access('challenge', false) && $this->arcade->get()->new_challenge())
			{
				$active = true;
				$this->template->assign_vars(array(
					'S_CHALLENGE_INFO_BOX'			=> true,
					'ARCADE_CHALLENGE_INFORMATION'	=> '<a href="' . $this->arcade->url('mode=challenge') . '#boxtop' . '" title="' . $this->user->lang['ARCADE_VIEW_CHALLENGE'] . '">' . $this->user->lang['ARCADE_NEW_CHALLENGE_INFORMATION'] . '</a>'
				));
			}

			if ($this->auth->acl_get('a_'))
			{
				$active = true;
				$this->template->assign_vars(array(
					'S_ARCADE_DISABLED'				=> ($this->auth->acl_get('a_') && $this->arcade_config['arcade_disable']) ? true : false,
					'S_ARCADE_CHALLENGE_DISABLED'	=> ($this->auth->acl_get('a_') && $this->arcade_config['challenge_disable']) ? true : false,
					'S_ARCADE_TOUR_DISABLED'		=> ($this->auth->acl_get('a_') && $this->arcade_config['tour_disable']) ? true : false,
					'S_ARCADE_REPORTS'				=> ($this->user->data['is_registered'] && $this->auth->acl_get('a_arcade_utilities')) ? true : false,
					'S_ARCADE_REPORTS_OPEN'			=> ($this->arcade_config['reports_open']) ? true : false,

					'U_ARCADE_REPORTS_OPEN'			=> append_sid("{$this->root_path}adm/index.{$this->php_ext}", $this->arcade->module_url('utilities') . '&amp;mode=reports', true, $this->user->session_id),

					'ARCADE_REPORTS_OPEN'			=> ($this->arcade_config['reports_open'] > 1) ? sprintf($this->user->lang['ARCADE_REPORTS_OPEN'], $this->arcade_config['reports_open']) : sprintf($this->user->lang['ARCADE_REPORT_OPEN'], $this->arcade_config['reports_open'])
				));
			}
		}

		$this->template->assign_var('S_ARCADE_HEADER', $active);
	}

	public function global_announce()
	{
		$user_lang = ($this->user->data['user_id'] == ANONYMOUS) ? $this->config['default_lang'] : $this->user->data['user_lang'];
		if (($global_announce = $this->arcade->announce_lang('global_announce', $user_lang)) !== false)
		{
			if (empty($this->user->style['template_inherits_id']) && !empty($this->template->orig_tpl_inherits_id))
			{
				$this->user->style['template_inherits_id'] = $this->template->orig_tpl_inherits_id;
			}

			$this->template->assign_vars(array(
				'S_ARCADE_GLOBAL_ANNOUNCE'		=> true,
				'S_GLOBAL_ANNOUNCE_SCROLL'		=> ($this->arcade_config['global_announce_scroll']) ? true : false,

				'GLOBAL_ANNOUNCE_SCROLL_TYPE'	=> $this->arcade_config['global_announce_scroll_type'],
				'GLOBAL_ANNOUNCE_SCROLL_SPEED'	=> (int) $this->arcade_config['global_announce_scroll_speed'],
				'GLOBAL_ANNOUNCE_TITLE'			=> censor_text($global_announce['subject']),
				'GLOBAL_ANNOUNCE_AUTHOR'		=> ($this->arcade_config['display_global_announce_author'] && $global_announce['user_id']) ? $this->user->lang['POST_BY_AUTHOR'] . ' ' . $this->arcade->get()->user_name('full', $global_announce['user_id'], $global_announce['username'], $global_announce['user_colour'], 'arcade', 'x') . ' - ' . $this->user->lang['POST_TIME'] . ': ' . $this->user->format_date($global_announce['announce_date'], false, true) : false,
				'GLOBAL_ANNOUNCE_TEXT'			=> generate_text_for_display($global_announce['message'], $global_announce['uid'], $global_announce['bitfield'], $global_announce['options'])
			));
		}
	}

	public function main_box($mode = 'arcade', $show_welcome_box = true, $show_adv_search = false)
	{
		global $_SID;

		if ($show_welcome_box)
		{
			$total_info = '';
			$this->user_info('header', $mode);
			$this->leaders($mode, 'header_leaders');
			$cache_time = $this->arcade->hour($this->arcade_config['cache_time']);

			switch ($mode)
			{
				case 'challenge':
					// Start challenge top_games
					$this->stats_data('game', 'challenge_top_games', 'most', 0, $this->arcade_config['challenge_top_games_header'], true, 'header_games', '', false, false, true, $cache_time);
					// Start challenge latest winners
					$s_latest_score = $this->stats_data('user', 'challenge_latest_winners', 'most', 0, $this->arcade_config['challenge_latest_winners'], true, 'latest_hsw', '', false, false, true, $cache_time);

					$total = intval($this->arcade_config['challenge_total_plays']);
					if ($total && $this->auth->acl_get('u_arcade_viewstats'))
					{
						$chall_total = sprintf($this->user->lang['ARCADE_STATS_TOTAL_CHALLENGE' . (($total > 1) ? 'S' : '')], $this->arcade->number_format($total));
						$total_plays = sprintf($this->user->lang['ARCADE_STATS_TOTAL_PLAYS_TIME'], $this->arcade->number_format($total * 2), $this->arcade->time_format(intval($this->arcade_config['challenge_total_plays_time'])));
						$total_info  = "{$chall_total}&nbsp;{$total_plays}";
					}
				break;

				case 'tournament':
					// Start tournament top_games
					$this->stats_data('game', 'tour_top_games', 'most', 0, $this->arcade_config['tour_top_games'], true, 'header_games', '', false, false, true, $cache_time);
					// Start tournament latest winners
					$s_latest_score = $this->stats_data('user', 'tour_latest_winners', 'most', 0, $this->arcade_config['tour_latest_winners'], true, 'latest_hsw', '', false, false, false, $cache_time);

					$tour_total = intval($this->arcade_config['tour_total']);
					if ($tour_total && $this->auth->acl_get('u_arcade_viewstats'))
					{
						$tour_total  = sprintf($this->user->lang['ARCADE_STATS_TOTAL_TOUR' . (($tour_total > 1) ? 'S' : '')], $this->arcade->number_format($tour_total));
						$total_plays = sprintf($this->user->lang['ARCADE_STATS_TOTAL_PLAYS_TIME'], $this->arcade->number_format(intval($this->arcade_config['tour_total_plays'])), ($this->arcade_config['tour_total_plays_time']) ? $this->arcade->time_format(intval($this->arcade_config['tour_total_plays_time'])) : 0);
						$total_info  = "{$tour_total}&nbsp;{$total_plays}";
					}
				break;

				default:
					// Start arcade newest_games
					$this->stats_data('game', 'newest_games', 'most', 0, $this->arcade_config['newest_games'], true, 'header_games', '', false, false, true, $cache_time);
					// Start arcade latest highscores
					$s_latest_score = $this->stats_data('user', 'latest_highscores', 'most', 0, $this->arcade_config['latest_highscores'], true, 'latest_hsw', '', false, false, true, $cache_time);

					$install_games = intval($this->arcade_config['install_games']);
					if ($install_games && $this->auth->acl_get('u_arcade_viewstats'))
					{
						$user_can_play_games = intval($this->arcade->get()->total('game', 'games', false, false, true, true));
						$total_plays		 = intval($this->arcade_config['total_plays']);
						$total_downloads	 = intval($this->arcade_config['total_downloads']);

						$user_can_play_games = ($install_games > $user_can_play_games) ? '&nbsp;' . sprintf($this->user->lang['ARCADE_TOTAL_CAN_PLAY_GAMES'], $this->arcade->number_format($user_can_play_games)) : '';
						$install_games		 = sprintf($this->user->lang['ARCADE_TOTAL_GAME' . (($install_games > 1) ? 'S' : '')], $this->arcade->number_format($install_games));
						$total_downloads	 = ($this->arcade->game()->download_stat_auth(true)) ? '&nbsp;' . sprintf($this->user->lang['ARCADE_TOTAL_DOWNLOAD' . (($total_downloads > 1) ? 'S' : '')], $this->arcade->number_format($total_downloads)) : '';
						$total_plays		 = ($total_plays) ? '&nbsp;' . sprintf($this->user->lang['ARCADE_STATS_TOTAL_PLAYS_TIME'], $this->arcade->number_format($total_plays), $this->arcade->time_format(intval($this->arcade_config['total_plays_time']))) : '';
						$total_info			 = "{$install_games}{$user_can_play_games}{$total_downloads}{$total_plays}";
					}
				break;
			}

			$mode = strtoupper($mode);
			$ap   = ($mode == 'ARCADE') ? true : false;
			$a_key = (strpos($mode, 'ARCADE') === false) ? 'ARCADE_' : '';

			$this->template->assign_vars(array(
				'S_ARCADE_SHOW_WELCOME_BOX'		=> true,
				'S_LATEST_SCORE'				=> $s_latest_score,

				'L_ARCADE_WELCOME'				=> sprintf($this->user->lang[$a_key . $mode . '_WELCOME'], $this->arcade->get()->user_name('full', $this->user->data['user_id'], $this->user->data['username'], '', strtolower($mode), 'x')),
				'L_ARCADE_GAMES_TITLE'			=> $this->user->lang['ARCADE_' . (($ap) ? 'NEWEST' : 'TOP') . '_GAMES'],
				'L_ARCADE_LEADERS_TITLE'		=> $this->user->lang[$a_key . $mode . '_LEADERS'],
				'L_ARCADE_LATEST_CHAMP_TITLE'	=> $this->user->lang['ARCADE_LATEST_' . (($ap) ? 'HIGHSCORES' : 'WINNERS')],
				'L_ARCADE_NO_LATEST_CHAMP'		=> $this->user->lang['ARCADE_NO_LATEST_' . (($ap) ? 'HIGHSCORES' : 'WINNERS')],

				'HEADER_TOTAL_INFO'				=> $total_info
			));
		}

		if ($show_adv_search)
		{
			$s_search = ($this->auth->acl_get('u_arcade_search')) ? true : false;

			if ($this->arcade_auth->acl_getc_global('c_play'))
			{
				$this->arcade->games_list('quick_jump');
			}

			$s_fav = ($this->auth->acl_get('u_arcade_favorites')) ? true : false;

			// Quick jump of your favorite games...
			if ($s_fav)
			{
				$this->user_favs(false, 'fav');
			}

			$s_hidden_fields = array('mode' => 'play');
			$s_hidden_search_fields = array('mode' => 'search');
			if (!empty($_SID))
			{
				$s_hidden_fields['sid'] = $s_hidden_search_fields['sid'] = $_SID;
			}

			$this->template->assign_vars(array(
				'S_ACTION_MAIN'					=> $this->arcade->url() . $this->arcade->gametop,
				'S_SHOW_ADV_SEARCH'				=> true,
				'S_HEADER_HIDDEN_FIELDS'		=> build_hidden_fields($s_hidden_fields),
				'S_ACTION_SEARCH'				=> ($s_search) ? $this->arcade->url('mode=search') : false,
				'S_HEADER_HIDDEN_FIELDS_SEARCH'	=> build_hidden_fields($s_hidden_search_fields),
				'S_ARCADE_SEARCH'				=> ($s_search) ? true : false
			));
		}
	}

	public function user_online($user_id)
	{
		$online = false;

		if ($this->config['load_onlinetrack'])
		{
			$sql = 'SELECT MAX(session_time) AS session_time, MIN(session_viewonline) AS session_viewonline
					FROM ' . SESSIONS_TABLE . '
					WHERE session_user_id = ' . (int) $user_id;
			$result = $this->db->sql_query($sql);
			$row = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			$session_time = (isset($row['session_time'])) ? $row['session_time'] : 0;
			$session_viewonline = (isset($row['session_viewonline'])) ? $row['session_viewonline'] : 0;
			unset($row);

			$update_time = $this->config['load_online_time'] * 60;
			$online = (time() - $update_time < $session_time && ((isset($session_viewonline) && $session_viewonline) || $this->auth->acl_get('u_viewonline'))) ? true : false;
		}

		$this->template->assign_vars(array(
			'ONLINE_IMG'	=> (!$this->config['load_onlinetrack']) ? '' : (($online) ? $this->user->img('icon_user_online', 'ONLINE') : $this->user->img('icon_user_offline', 'OFFLINE')),
			'S_ONLINE'		=> ($this->config['load_onlinetrack'] && $online) ? true : false
		));
	}

	public function user_favs($user_id = false, $hkey = 'userfav')
	{
		global $_SID, $game_fav_data;

		if ($user_id)
		{
			unset($game_fav_data);
		}
		else
		{
			$user_id = (int) $this->user->data['user_id'];
		}

		if ($user_id <> ANONYMOUS && $this->auth->acl_get('u_arcade_favorites'))
		{
			$game_fav_data = (!isset($game_fav_data)) ? $this->arcade->get()->fav_data($user_id) : $game_fav_data;

			if (is_array($game_fav_data) && count($game_fav_data))
			{
				foreach ($game_fav_data as $gid => $row)
				{
					$this->template->assign_block_vars($hkey, array(
						'GAME_ID'		=> $gid,
						'GAME_NAME'		=> $row['game_name'],
						'HIGHLIGHTED'	=> $row['highlighted']
					));
				}

				$s_hidden_fields = array('mode' => 'play');
				if (!empty($_SID))
				{
					$s_hidden_fields['sid'] = $s_hidden_search_fields['sid'] = $_SID;
				}

				$this->template->assign_vars(array(
					'S_ACTION_USER_FAV'			=> $this->arcade->url() . $this->arcade->gametop,
					'S_USER_FAV_HIDDEN_FIELDS'	=> build_hidden_fields($s_hidden_fields)
				));
			}
		}
	}

	public function user_info($prefix = 'header', $mode = 'arcade', $user_id = false, $profile = false)
	{
		$prefix = strtoupper($prefix);

		if (!in_array($mode, array('arcade', 'challenge', 'tournament')))
		{
			$mode = 'arcade';
		}

		if ($user_id && $user_id != $this->user->data['user_id'])
		{
			$user_info = $this->arcade->userdata('user_info', $user_id);
		}
		else
		{
			$user_info = $this->user->data;
		}

		$rank_title = $rank_img = $rank_img_src = '';

		$arcade_rank = array(
			'rank_title'	=> '',
			'rank_img'		=> '',
			'rank_img_src'	=> ''
		);

		if ($this->arcade_config['forum_rank'])
		{
			$forum_rank_data = $this->arcade->phpbb()->get_user_rank($user_info['user_rank'], $user_info['user_posts']);
			$rank_title = $forum_rank_data['title'];
			$rank_img = $forum_rank_data['img'];
			$rank_img_src = $forum_rank_data['img_src'];
		}

		if ($user_info['user_type'] == USER_IGNORE)
		{
			if ($this->arcade_config['arcade_rank'])
			{
				$arcade_rank = $this->arcade->get()->user_rank($user_info['user_arcade_rank'], false);
			}

			$GLOBALS['arcade_skip_active_link'] = 1;
			$userdata = array(
				'user_id'			=> $user_info['user_id'],
				'full_username'		=> $this->arcade->get()->username_string('no_profile', $user_info['user_id'], $user_info['username'], $user_info['user_colour']),
				'username'			=> ($user_info['user_id'] == ANONYMOUS) ? $this->user->lang['GUEST'] : $user_info['username'],
				'avatar'			=> ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($user_info['user_avatar'], $user_info['user_avatar_type'], $user_info['user_avatar_width'], $user_info['user_avatar_height']) : '',
				'rank_title'		=> $rank_title,
				'rank_image'		=> $rank_img,
				'rank_image_src'	=> $rank_img_src,
				'a_rank_title'		=> $arcade_rank['rank_title'],
				'a_rank_image'		=> $arcade_rank['rank_img'],
				'a_rank_image_src'	=> $arcade_rank['rank_img_src']
			);
			unset($GLOBALS['arcade_skip_active_link']);
		}
		else
		{
			$extra_data = $games = $td = array();
			$total_wins = $total_ties = $played_games = $total_plays = $total_times = $last_challenge = $last_won_date = $last_play_date = $total_tour = 0;

			if ($this->arcade_config['arcade_rank'])
			{
				$arcade_rank = $this->arcade->get()->user_rank($user_info['user_arcade_rank'], $user_info['arcade_total_wins']);
			}

			if ($mode == 'arcade')
			{
				$played_games	= $user_info['arcade_total_played'];
				$total_plays	= $user_info['arcade_total_plays'];
				$total_times	= $user_info['arcade_total_time'];
				$total_wins		= $user_info['arcade_total_wins'];

				$extra_data = array(
					'total_superscores'	=> $user_info['arcade_total_super_scores'],
					'total_downloads'	=> $user_info['arcade_total_downloads']
				);
			}
			else if ($mode == 'challenge')
			{
				$sql = 'SELECT game_id, champ_challenger_id, champ_challenger_time, champ_opponent_time, champ_winner, champ_end_time
						FROM ' . ARCADE_CHALLENGE_CHAMP_TABLE . '
						WHERE champ_close = ' . CHALLENGE_CLOSE . '
						AND (champ_challenger_id = ' . (int) $user_info['user_id'] . ' OR champ_opponent_id = ' . (int) $user_info['user_id'] . ')
						ORDER BY champ_end_time ASC';
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					if ($row['champ_winner'] == $user_info['user_id'])
					{
						$total_wins++;
						$last_won_date = $row['champ_end_time'];
					}

					if ($row['champ_winner'] == CHALLENGE_TIE)
					{
						$total_ties++;
					}

					if (empty($games[$row['game_id']]))
					{
						$games[$row['game_id']] = 1;
						$played_games++;
					}

					$total_plays++;

					$total_times += ($user_info['user_id'] == $row['champ_challenger_id']) ? $row['champ_challenger_time'] : $row['champ_opponent_time'];
					$last_play_date = $row['champ_end_time'];
				}
				$this->db->sql_freeresult($result);

				$extra_data = array(
					'total_ties'		=> $total_ties,
					'total_loses'		=> intval($total_plays - $total_wins - $total_ties),
					'last_play_date'	=> $last_play_date,
					'last_won_date'		=> $last_won_date
				);
			}
			else if ($mode == 'tournament')
			{
				$sql = 'SELECT t.tour_id, t.tour_wins, t.tour_endtime, tc.game_id, tc.total_plays, tc.total_time
						FROM ' . ARCADE_TOUR_TABLE . '  t, ' . ARCADE_TOUR_CHAMP_TABLE . ' tc
						WHERE t.tour_status = ' . ARCADE_END_TOUR . '
						AND t.tour_id = tc.tour_id
						AND tc.user_id = ' . (int) $user_info['user_id'] . '
						ORDER BY t.tour_endtime ASC';
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					if (empty($td[$row['tour_id']]))
					{
						$td[$row['tour_id']] = 1;
						$total_tour++;

						if ($row['tour_wins'] == $user_info['user_id'])
						{
							$total_wins++;
							$last_won_date = $row['tour_endtime'];
						}
					}

					if (empty($games[$row['game_id']]))
					{
						$games[$row['game_id']] = 1;
						$played_games++;
					}

					$total_plays += $row['total_plays'];
					$total_times += $row['total_time'];
					$last_play_date = $row['tour_endtime'];
				}
				$this->db->sql_freeresult($result);

				$extra_data = array(
					'total_loses'		=> intval($total_tour - $total_wins),
					'total_tour'		=> $total_tour,
					'last_play_date'	=> $last_play_date,
					'last_won_date'		=> $last_won_date
				);
			}

			$userdata = array(
				'user_id'			=> $user_info['user_id'],
				'full_username'		=> $this->arcade->get()->user_name('full', $user_info['user_id'], $user_info['username'], $user_info['user_colour'], (($profile) ? 'profile' : $mode), 'x'),
				'username'			=> $user_info['username'],
				'avatar'			=> ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($user_info['user_avatar'], $user_info['user_avatar_type'], $user_info['user_avatar_width'], $user_info['user_avatar_height'], 'x', (($profile) ? 'profile' : $mode), $user_info['user_id']) : '',
				'rank_title'		=> $rank_title,
				'rank_image'		=> $rank_img,
				'rank_image_src'	=> $rank_img_src,
				'a_rank_title'		=> $arcade_rank['rank_title'],
				'a_rank_image'		=> $arcade_rank['rank_img'],
				'a_rank_image_src'	=> $arcade_rank['rank_img_src'],
				'total_wins'		=> $total_wins,
				'played_games'		=> $played_games,
				'total_plays'		=> $total_plays,
				'total_times'		=> $total_times
			);

			if (count($extra_data))
			{
				$userdata = array_merge($userdata, $extra_data);
			}
		}

		$this->template->assign_vars(array(
			"{$prefix}_AVATAR"				=> $userdata['avatar'],
			"{$prefix}_RANK_TITLE"			=> $userdata['rank_title'],
			"{$prefix}_RANK_IMAGE"			=> $userdata['rank_image'],
			"{$prefix}_RANK_IMAGE_SRC"		=> $userdata['rank_image_src'],
			"{$prefix}_A_RANK_TITLE"		=> $userdata['a_rank_title'],
			"{$prefix}_A_RANK_IMAGE"		=> $userdata['a_rank_image'],
			"{$prefix}_A_RANK_IMAGE_SRC"	=> $userdata['a_rank_image_src'],
			"{$prefix}_USERNAME"			=> $userdata['full_username']
		));

		if ($user_info['user_type'] <> USER_IGNORE)
		{
			if ($mode == 'arcade')
			{
				$this->template->assign_vars(array(
					"{$prefix}_TOTAL_SUPERSCORES"	=> $this->arcade->number_format($userdata['total_superscores']),
					"{$prefix}_TOTAL_DOWNLOADS"		=> $this->arcade->number_format($userdata['total_downloads'])
				));
			}
			else if ($mode == 'challenge')
			{
				$this->template->assign_vars(array(
					"{$prefix}_CHALLENGE_TIES"	=> $this->arcade->number_format($userdata['total_ties']),
					"{$prefix}_CHALLENGE_LOSES"	=> $this->arcade->number_format($userdata['total_loses'])
				));
			}
			else if ($mode == 'tournament')
			{
				$this->template->assign_vars(array(
					"{$prefix}_TOTAL_TOUR"	=> $this->arcade->number_format($userdata['total_tour']),
					"{$prefix}_TOUR_LOSES"	=> $this->arcade->number_format($userdata['total_loses'])
				));
			}

			if (in_array($mode, array('challenge', 'tournament')))
			{
				$this->template->assign_vars(array(
					"{$prefix}_LAST_WON_DATE"	=> ($userdata['last_won_date'] > 0) ? $this->user->format_date($userdata['last_won_date'], (($prefix == 'HEADER') ? 'Y.m.d.' : false), true) : '-',
					"{$prefix}_LAST_PLAY_DATE"	=> ($userdata['last_play_date'] > 0) ? $this->user->format_date($userdata['last_play_date'], (($prefix == 'HEADER') ? 'Y.m.d.' : false), true) : '-'
				));
			}

			$this->template->assign_vars(array(
				"{$prefix}_ARCADE_WINS"		=> $this->arcade->number_format($userdata['total_wins']),
				"{$prefix}_PLAYED_GAMES"	=> $this->arcade->number_format($userdata['played_games']),
				"{$prefix}_ARCADE_PLAYS"	=> $this->arcade->number_format($userdata['total_plays']),
				"{$prefix}_ARCADE_TIMES"	=> ($userdata['total_times'] > 0) ? $this->arcade->time_format($userdata['total_times'], (($prefix == 'HEADER') ? false : true), (($prefix == 'HEADER') ? true : false)) : 0,
			));

			if ($this->arcade->points()->data['show'])
			{
				$this->template->assign_vars(array(
					"S_SHOW_POINTS"			=> true,
					"{$prefix}_USER_POINTS"	=> $this->arcade->number_format($this->arcade->points()->data['total']) . ' ' . $this->arcade->points()->data['name'],
				));
			}

			$mode = strtoupper($mode);
			$this->template->assign_vars(array(
				'S_HEADER_USER_DATA'	=> ($prefix == 'HEADER') ? true : false,
				'L_ARCADE_TOTAL_PLAYS'	=> $this->user->lang['ARCADE_' . (($mode == 'ARCADE' || $mode == 'TOURNAMENT') ? 'STATS_TOTAL_PLAYS' : "PLAYED_{$mode}")],
				'L_ARCADE_WINS'			=> $this->user->lang[(($mode != 'ARCADE') ? 'ARCADE_' : '') . $mode . (($mode == 'ARCADE') ? '_TROPHYS' : '_WINS')]
			));
		}

		unset($user_info);

		return $userdata;
	}

	/**
	* Display Arcade Leaders
	*/
	public function leaders($mode, $html_key)
	{
		if (!in_array($mode, array('arcade', 'challenge', 'tournament')) || !$html_key || !$this->auth->acl_get('u_arcade_viewstats'))
		{
			return;
		}

		switch ($mode)
		{
			case 'arcade':
				$limit				= intval(($this->arcade_config['arcade_leaders'] > $this->arcade_config['arcade_leaders_header']) ? $this->arcade_config['arcade_leaders'] : $this->arcade_config['arcade_leaders_header']);
				$header_leaders		= $this->arcade_cache->obtain_arcade_leaders($limit);
				$real_leaders_count	= count($header_leaders);
				$leaders_count		= ($real_leaders_count > $this->arcade_config['arcade_leaders_header']) ? $this->arcade_config['arcade_leaders_header'] : $real_leaders_count;
			break;

			case 'challenge':
				$limit				= intval(($this->arcade_config['challenge_leaders'] > $this->arcade_config['challenge_leaders_header']) ? $this->arcade_config['challenge_leaders'] : $this->arcade_config['challenge_leaders_header']);
				$header_leaders		= $this->arcade_cache->obtain_challenge_leaders($limit);
				$real_leaders_count	= count($header_leaders);
				$leaders_count		= ($real_leaders_count > $this->arcade_config['challenge_leaders_header']) ? $this->arcade_config['challenge_leaders_header'] : $real_leaders_count;
			break;

			case 'tournament':
				$limit				= intval(($this->arcade_config['tour_leaders'] > $this->arcade_config['tour_leaders_header']) ? $this->arcade_config['tour_leaders'] : $this->arcade_config['tour_leaders_header']);
				$header_leaders		= $this->arcade_cache->obtain_tour_leaders($limit);
				$real_leaders_count	= count($header_leaders);
				$leaders_count		= ($real_leaders_count > $this->arcade_config['tour_leaders_header']) ? $this->arcade_config['tour_leaders_header'] : $real_leaders_count;
			break;
		}

		$leaders_width = 0;
		if ($leaders_count > 0)
		{
			switch ($leaders_count)
			{
				case 1:
					$leaders_width = 100;
				break;

				case 2:
					$leaders_width = 49;
				break;

				default:
					$leaders_width = 33;
				break;
			}

			$rank = $actual_rank = $last_value = 0;
			for ($i = 0; $i < $leaders_count; $i++)
			{
				// This code is used to calculate the actual rank.
				// For example if there are ties...
				$this->arcade->get()->actual_rank($actual_rank, $rank, $header_leaders[$i]['total_wins'], $last_value);

				$user_link = $this->arcade->get()->user_name('full', $header_leaders[$i]['user_id'], $header_leaders[$i]['username'], $header_leaders[$i]['user_colour'], $mode, 'x');

				$this->template->assign_block_vars($html_key, array(
					'S_ARCADE_LEADERS_NEW_LINE'	=> (is_int($actual_rank / 3)) ? true : false,

					'ARCADE_LEADERS_RANK'		=> $rank,
					'ARCADE_LEADERS_AVATAR'		=> ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($header_leaders[$i]['user_avatar'], $header_leaders[$i]['user_avatar_type'], 30, 30, 'x', $mode, $header_leaders[$i]['user_id']) : false,
					'ARCADE_LEADERS'			=> $user_link,
					'ARCADE_LEADERS_IMAGE'		=> $this->arcade->get()->leaders_image($rank, true),
					'VICTORIES'					=> $header_leaders[$i]['total_wins']
				));

				$this->template->assign_var(strtoupper($html_key) . '_WIDTH', $leaders_width);
			}
		}

		return ($leaders_count > 0) ? true : false;
	}

	public function highscores($page, $user_id, $highscore = false)
	{
		static $_arcade_highscores_cache;

		if (($page == 'memberlist' && !$this->arcade_config['display_memberlist']) || ($page == 'viewtopic' && !$this->arcade_config['display_viewtopic']))
		{
			return false;
		}

		if (empty($_arcade_highscores_cache))
		{
			$ban_users = ($highscore) ? array() : $this->arcade->ban_users();

			$_arcade_highscores_cache = array(
				's_viewstats'		=> ($this->auth->acl_get('u_arcade_viewstats')) ? true : false,

				'u_arcade_super_stat'	=> $this->arcade->url('mode=stats&amp;ds=super_champions&amp;u={USER_ID}') . '#arcade_top',
				'u_arcade_stat'			=> $this->arcade->url('mode=stats&amp;u={USER_ID}') . '#userbox',
				'u_challenge_stat'		=> $this->arcade->url('mode=stats&amp;type=challenge&amp;u={USER_ID}') . '#userbox',
				'u_tour_stat'			=> $this->arcade->url('mode=stats&amp;type=tournament&amp;u={USER_ID}') . '#userbox',

				'super_data'			=> array_diff_key($this->arcade_cache->obtain_arcade_super_champion_all(), $ban_users),
				'arcade_data'			=> array_diff_key($this->arcade_cache->obtain_arcade_leaders_all(), $ban_users),
				'challenge_data'		=> ($highscore || $this->arcade->access('challenge')) ? array_diff_key($this->arcade_cache->obtain_challenge_leaders_all(), $ban_users) : false,
				'tour_data'				=> ($highscore || $this->arcade->access('tour')) ? array_diff_key($this->arcade_cache->obtain_tour_leaders_all(), $ban_users) : false,
				'ban_users'				=> $ban_users
			);

			unset($ban_users);
		}

		if (($user_id <= ANONYMOUS) || (!$highscore && !empty($_arcade_highscores_cache['ban_users'][$user_id])))
		{
			return false;
		}

		$total_super_highscores = $s_leader_id = 0;
		$total_highscores = $a_leader_id = 0;
		$total_chall_wins = $c_leader_id = 0;
		$total_tour_wins = $t_leader_id = 0;

		if (!empty($_arcade_highscores_cache['super_data'][$user_id]))
		{
			$total_super_highscores = $_arcade_highscores_cache['super_data'][$user_id];
			$keys = array_keys($_arcade_highscores_cache['super_data']);
			$s_leader_id = array_shift($keys);
		}

		if (!empty($_arcade_highscores_cache['arcade_data'][$user_id]))
		{
			$total_highscores = $_arcade_highscores_cache['arcade_data'][$user_id];
			$keys = array_keys($_arcade_highscores_cache['arcade_data']);
			$a_leader_id = array_shift($keys);
		}

		if (!empty($_arcade_highscores_cache['challenge_data'][$user_id]))
		{
			$total_chall_wins = $_arcade_highscores_cache['challenge_data'][$user_id];
			$keys = array_keys($_arcade_highscores_cache['challenge_data']);
			$c_leader_id = array_shift($keys);
		}

		if (!empty($_arcade_highscores_cache['tour_data'][$user_id]))
		{
			$total_tour_wins = $_arcade_highscores_cache['tour_data'][$user_id];
			$keys = array_keys($_arcade_highscores_cache['tour_data']);
			$t_leader_id = array_shift($keys);
		}

		if ($highscore == 'super_highscore')
		{
			return $total_super_highscores;
		}
		else if ($highscore == 'arcade')
		{
			return $total_highscores;
		}
		else if ($highscore == 'challenge')
		{
			return $total_chall_wins;
		}
		else if ($highscore == 'tour')
		{
			return $total_tour_wins;
		}
		else
		{
			return array(
				'S_ARCADE_STATS'					=> ($_arcade_highscores_cache['s_viewstats']) ? true : false,
				'S_HAS_ARCADE_DISPLAY'				=> ($_arcade_highscores_cache['super_data'] !== false || $_arcade_highscores_cache['arcade_data'] !== false) ? true : false,
				'S_HAS_ARCADE_CHALLENGE_DISPLAY'	=> ($_arcade_highscores_cache['challenge_data'] !== false) ? true : false,
				'S_HAS_ARCADE_TOUR_DISPLAY'			=> ($_arcade_highscores_cache['tour_data'] !== false) ? true : false,

				'S_IS_ARCADE_SUPER_HIGHSCORE'		=> ($s_leader_id > 0 && $s_leader_id == $user_id) ? true : false,
				'S_IS_ARCADE_LEADER'				=> ($a_leader_id > 0 && $a_leader_id == $user_id) ? true : false,
				'S_IS_ARCADE_CHALLENGE_LEADER'		=> ($c_leader_id > 0 && $c_leader_id == $user_id) ? true : false,
				'S_IS_ARCADE_TOUR_LEADER'			=> ($t_leader_id > 0 && $t_leader_id == $user_id) ? true : false,

				'U_ARCADE_SUPER_HIGHSCORE_STATS'	=> str_replace('{USER_ID}', $user_id, $_arcade_highscores_cache['u_arcade_super_stat']),
				'U_ARCADE_STATS'					=> str_replace('{USER_ID}', $user_id, $_arcade_highscores_cache['u_arcade_stat']),
				'U_ARCADE_CHALLENGE_STATS'			=> str_replace('{USER_ID}', $user_id, $_arcade_highscores_cache['u_challenge_stat']),
				'U_ARCADE_TOUR_STATS'				=> str_replace('{USER_ID}', $user_id, $_arcade_highscores_cache['u_tour_stat']),

				'ARCADE_TOTAL_SUPER_HIGHSCORES'		=> $total_super_highscores,
				'ARCADE_TOTAL_HIGHSCORES'			=> $total_highscores,
				'ARCADE_CHALLENGE_TOTAL_WINNING'	=> $total_chall_wins,
				'ARCADE_TOUR_TOTAL_WINNING'			=> $total_tour_wins
			);
		}
	}

	public function cat_auth_level($cat_id, $cat_download)
	{
		$locked = $this->arcade->get()->cat_locked($cat_id);

		$rules = array_filter(array(
			'ARCADE_RULES_PLAY_CAN' . (($this->arcade_auth->acl_get('c_play', $cat_id) && !$locked) ? '' : 'NOT'),
			($this->arcade->points()->data['show'] && $this->arcade_auth->acl_get('c_play', $cat_id) && !$locked) ? 'ARCADE_RULES_PLAY_FREE_CAN' . (($this->arcade_auth->acl_get('c_playfree', $cat_id) && !$locked) ? '' : 'NOT') : '',
			'ARCADE_RULES_SCORE_CAN' . (($this->user->data['is_registered'] && $this->arcade_auth->acl_get('c_score', $cat_id) && !$locked) ? '' : 'NOT'),
			($this->arcade_config['game_comment']) ? 'ARCADE_RULES_COMMENT_CAN' . (($this->user->data['is_registered'] && $this->arcade_auth->acl_get('c_comment', $cat_id) && !$locked) ? '' : 'NOT') : '',
			'ARCADE_RULES_REPORT_CAN' . (($this->arcade_auth->acl_get('c_report', $cat_id) && !$locked) ? '' : 'NOT'),
			'ARCADE_RULES_RATE_CAN' . (($this->user->data['is_registered'] && $this->arcade_auth->acl_get('c_rate', $cat_id) && !$locked) ? '' : 'NOT'),
			'ARCADE_RULES_RE_RATE_CAN' . (($this->user->data['is_registered'] && $this->arcade_auth->acl_get('c_re_rate', $cat_id) && !$locked) ? '' : 'NOT'),
			'ARCADE_RULES_DOWNLOAD_CAN' . (($this->arcade->game()->download_auth('user_cat', $cat_id, $cat_download, true)) ? '' : 'NOT'),
			($this->arcade->points()->data['show'] && $this->arcade->game()->download_auth('user_cat', $cat_id, $cat_download, true)) ? 'ARCADE_RULES_DOWNLOAD_FREE_CAN' . (($this->arcade_auth->acl_get('c_downloadfree', $cat_id) && !$locked) ? '' : 'NOT') : '',
			'ARCADE_RULES_IGNORE_CONTROL_CAN' . (($this->arcade_auth->acl_get('c_ignorecontrol', $cat_id) && !$locked) ? '' : 'NOT')
		));

		foreach ($rules as $rule)
		{
			$this->template->assign_block_vars('rules', array('RULE' => $this->user->lang[$rule]));
		}

		$this->template->assign_var('S_DISPLAY_AUTH_INFO', true);
	}

	public function online_playing($page_verify_ignore = false)
	{
		if ($this->auth->acl_get('u_arcade_view_whoisplaying'))
		{
			$online_users = array(
				'games_names'	=> array(),
				'games_players'	=> array(),
				'total_online'	=> 0,
				'visible_online'=> 0,
				'hidden_online'	=> 0,
				'guests_online'	=> 0,
				'online_time'	=> 0
			);

			$this->arcade->obtain_users_online($online_users, $page_verify_ignore);

			$count = 1;
			if ($online_users['total_online'] > 0)
			{
				foreach ($online_users['games_names'] as $key => $game_name)
				{
					$this->template->assign_block_vars('arcade_online_row', array(
						'GAME'			=> $game_name,
						'PLAYER_LIST'	=> $online_users['games_players'][$key]
					));

					$count++;
				}
			}

			if ($online_users['total_online'] > $this->arcade_config['record_playing_users'])
			{
				$this->arcade_config['record_playing_users']	= $online_users['total_online'];
				$this->arcade_config['record_playing_date']	= time();

				$this->arcade_config->set('record_playing_users', $this->arcade_config['record_playing_users'], false);
				$this->arcade_config->set('record_playing_date', $this->arcade_config['record_playing_date'], false);
			}

			$visible_online	= $this->user->lang('REG_USERS_TOTAL', (int) $online_users['visible_online']);
			$hidden_online	= $this->user->lang('HIDDEN_USERS_TOTAL', (int) $online_users['hidden_online']);
			$guests_online	= $this->user->lang('GUEST_USERS_TOTAL', (int) $online_users['guests_online']);

			$l_online_users	= $this->user->lang('ARCADE_ONLINE_USERS_TOTAL', (int) $online_users['total_online'], $visible_online, $hidden_online, $guests_online);

			$this->template->assign_vars(array(
				'S_CAN_VIEW_WHOISPLAYING'		=> true,

				'ARCADE_TOTAL_USERS_PLAYING'	=> $l_online_users . ' (' . $this->user->lang('VIEW_ONLINE_TIMES', (int) $online_users['online_time']) . ')',
				'ARCADE_RECORD_USERS_PLAYING'	=> sprintf($this->user->lang['ARCADE_ONLINE_USERS_RECORD'], $this->arcade_config['record_playing_users'], $this->user->format_date($this->arcade_config['record_playing_date'], false, true)),
				'GAMES_COUNT'					=> $count
			));
		}
	}

	public function cat_login_box($cat_data)
	{
		// Founder ignore the password.
		if ($this->arcade_config['founder_exempt'] && $this->user->data['user_type'] == USER_FOUNDER)
		{
			return true;
		}

		$password = $this->request->variable('password', '', true);

		$sql = 'SELECT cat_id
				FROM ' . ARCADE_ACCESS_TABLE . '
				WHERE cat_id = ' . (int) $cat_data['cat_id'] . '
				AND user_id = ' . (int) $this->user->data['user_id'] . "
				AND session_id = '" . $this->db->sql_escape($this->user->session_id) . "'";
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if ($row)
		{
			return true;
		}

		if ($this->request->is_set_post('password'))
		{
			if ($password)
			{
				// Remove expired authorised sessions
				$sql = 'SELECT session_id
						FROM ' . SESSIONS_TABLE;
				$result = $this->db->sql_query($sql);

				if ($row = $this->db->sql_fetchrow($result))
				{
					$sql_in = array();
					do
					{
						$sql_in[] = (string) $row['session_id'];
					}
					while ($row = $this->db->sql_fetchrow($result));

					// Remove expired sessions
					$sql = 'DELETE FROM ' . ARCADE_ACCESS_TABLE . '
							WHERE ' . $this->db->sql_in_set('session_id', $sql_in, true);
					$this->db->sql_query($sql);
				}
				$this->db->sql_freeresult($result);

				if (phpbb_check_hash($password, $cat_data['cat_password']))
				{
					$sql_ary = array(
						'cat_id'		=> (int) $cat_data['cat_id'],
						'user_id'		=> (int) $this->user->data['user_id'],
						'session_id'	=> (string) $this->user->session_id
					);

					$this->db->sql_query('INSERT INTO ' . ARCADE_ACCESS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));

					return true;
				}
			}

			$this->template->assign_var('LOGIN_ERROR', $this->user->lang['WRONG_PASSWORD']);
		}

		$this->template->assign_vars(array(
			'CAT_NAME'					=> $cat_data['cat_name'],
			'S_ARCADE_CAT_LOGIN_ACTION'	=> build_url()
		));

		$this->page($this->user->lang['LOGIN'], 'arcade/login_cat.html');
	}

	public function stats_data($mode, $action, $type = 'most', $start = 0, $limit = 3, $tpl = false, $tpl_key = 'arcade', $order_by = '', $id = false, $zero = false, $ca = false, $cache_ttl = 0, $details = false, $sec_id = false, $s_can_play = false)
	{
		if ($limit < 1 || !in_array($mode, array('game', 'user')) || !$action)
		{
			return false;
		}

		global $arcade_game_count, $arcade_page;

		$this->arcade->valid_start($start);

		$extra_col				= '';
		$actual_rank			= $start;
		$data = $tpl_rows		= array();
		$mode					= strtolower($mode);
		$action					= strtolower($action);
		$rank = $last_value		= $arcade_game_count = 0;
		$order					= ($type == 'most') ? 'DESC' : 'ASC';
		$game_mode				= 'stats';
		$user_mode				= 'arcade';

		if (strpos($action, 'challenge') !== false)
		{
			$game_mode = $user_mode = 'challenge';
		}
		else if (strpos($action, 'tour') !== false)
		{
			$game_mode = $user_mode = 'tournament';
		}

		switch ($mode)
		{
			case 'game':
				switch ($action)
				{
					case 'newest_games':
						$extra_col = 'g.game_installdate' . (($this->arcade_config['newest_games_tooltip']) ? ', g.game_desc, g.game_control, g.game_control_desc' : '');
						$order_key = 'g.game_installdate';
					break;

					case 'newest_games_img':
						$extra_col = $order_key = 'g.game_installdate';
					break;

					case 'favorites':
						$extra_col = 'f.highlighted';
						$order_key = 'g.game_name_clean';
					break;

					case 'downloaded_games':
						$extra_col = 'g.game_installdate, g.game_download_total';
						$order_key = 'g.game_download_total';
						$game_mode = 'download';
					break;

					case 'played_games':
						if ($details)
						{
							$extra_col = 'SUM(p.total_plays) AS t_plays, SUM(p.total_time) AS t_time, COUNT(p.user_id) AS t_users';
						}
						else
						{
							$extra_col = 'g.game_plays AS t_plays';
						}

						$order_key = 't_plays';
					break;

					case 'not_played_games':
						$extra_col = 'u.user_id, u.username, u.username_clean, u.user_colour';
						$order_key = '';
					break;

					case 'super_champions':
						$extra_col = 's.score, s.score_date';
						$order_key = 's.score_date';
					break;

					case 'favs':
						$extra_col = 'COUNT(f.user_id) AS total';
						$order_key = 'total';
					break;

					case 'rated_games':
						$extra_col = 'g.game_votetotal, g.game_votesum, r.game_rating, ';
					case 'best_rated_img':
						$extra_col .= '(g.game_votesum / g.game_votetotal) AS rating_avg, g.game_votetotal';
						$order_key = "rating_avg {$order}, g.game_votetotal";
					break;

					case 'games_jackpots':
						$extra_col = 'g.game_jackpot';
						$order_key = 'g.game_jackpot';
					break;

					case 'random':
					case 'random_img':
						$order_key = 'g.game_id';
					break;

					case 'challenge_top_games':
						$extra_col = 'COUNT(cc.game_id) AS total_played';
						$order_key = 'total_played';
					break;

					case 'challenge_played_games':
						$extra_col = '(SUM(cc.champ_challenger_time) + SUM(cc.champ_opponent_time)) AS t_time, COUNT(cc.champ_id) AS t_plays';
						$order_key = 't_plays';
					break;

					case 'tour_played_games':
						$extra_col = 'SUM(tc.total_plays) AS t_plays, SUM(tc.total_time) AS t_time';
						$order_key = 't_plays';
					break;

					case 'tour_top_games':
						// COUNT(tc.game_id)	= Game / users played
						// OR
						// SUM(tc.total_plays)	= Game / total played
						$extra_col = 'SUM(tc.total_plays) AS total_played';
						$order_key = 'total_played';
					break;

					default:
						return false;
					break;
				}
			break;

			case 'user':
				switch ($action)
				{
					case 'latest_highscores':
					case 'longest_highscores':
						$extra_col = 'g.game_id, g.cat_id, g.game_highscore, g.game_highdate';
						$order_key = 'g.game_highdate';
					break;

					case 'users_playtime':
						$extra_col = 'SUM(p.total_time) AS total_time';
						$order_key = 'total_time';
					break;

					case 'played_users':
						if ($ca || $id)
						{
							$extra_col = 'COUNT(p.game_id) AS games_count, SUM(p.total_time) AS t_time, SUM(p.total_plays) AS t_plays';
						}
						else
						{
							$extra_col = 'au.arcade_total_played AS games_count, au.arcade_total_plays AS t_plays, au.arcade_total_time AS t_time';
						}
						$order_key = 't_plays';
					break;

					case 'highscores':
						if ($ca || $id)
						{
							$extra_col = 'COUNT(g.game_id) AS total_wins, SUM(p.total_plays) AS total_plays, SUM(p.total_time) AS total_times';
						}
						else
						{
							$extra_col = 'au.arcade_total_wins AS total_wins, au.arcade_total_plays AS total_plays, au.arcade_total_time AS total_times';
						}
						$order_key = 'total_wins';
					break;

					case 'super_champions':
						if ($ca || $id)
						{
							$extra_col = 'COUNT(s.game_id) AS total_wins';
						}
						else
						{
							$extra_col = 'au.arcade_total_super_scores AS total_wins';
						}
						$order_key = 'total_wins';
					break;

					case 'challenge_latest_winners':
						$extra_col	= 'g.game_id, g.game_name, g.game_width, g.game_height, g.cat_id,
										cc.champ_challenger_id, cc.champ_challenger_score, cc.champ_opponent_score, cc.champ_winner, cc.champ_end_time,
										u2.user_id AS user_id2, u2.username AS username2, u2.user_colour AS user_colour2, u2.user_avatar AS user_avatar2, u2.user_avatar_type AS user_avatar_type2';
						$order_key	= 'cc.champ_end_time';
					break;

					case 'challenge_played_users':
						$extra_col = 'COUNT(cc.champ_id) AS t_plays';
						$order_key = 't_plays';
					break;

					case 'challenge_winners':
						$extra_col = 'COUNT(cc.champ_id) AS total_wins';
						$order_key = 'total_wins';
					break;

					case 'tour_winners':
						$extra_col = 'COUNT(t.tour_id) AS total_wins';
						$order_key = 'total_wins';
					break;

					case 'tour_latest_winners':
						$extra_col	= 't.tour_id, t.tour_name, t.tour_endtime';
						$order_key	= 't.tour_endtime';
					break;

					case 'tour_played_users':
						$extra_col = 'COUNT(tc.game_id) AS games_count, SUM(tc.total_time) AS t_time, SUM(tc.total_plays) AS t_plays';
						$order_key = 't_plays';
					break;

					default:
						return false;
					break;
				}
			break;
		}

		$and_game_cats = '';
		if ($ca)
		{
			$c_auth = ($s_can_play) ? 'c_play' : array('c_view', 'c_play');
			$cat_ids = $this->arcade->get()->permissions($c_auth);

			if ($action == 'downloaded_games')
			{
				$cat_ids = array_intersect($this->arcade->get()->permissions('c_download'), $cat_ids);
			}

			$and_game_cats = ' AND ' . $this->db->sql_in_set('g.cat_id', array_map('intval', $cat_ids), false, true);
		}

		$and_user_type = ' AND u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')';

		switch ($mode)
		{
			case 'user':
				switch ($action)
				{
					case 'users_playtime':
					case 'played_users':
					case 'highscores':
					case 'super_champions':
					case 'challenge_played_users':
					case 'challenge_winners':
					case 'tour_winners':
					case 'tour_played_users':
						$and_game_cats = '';
					break;
				}
			break;
		}

		switch ($mode)
		{
			case 'game':
				$and_user_type = '';
				$sql_array = array(
					'SELECT'	=> 'g.game_id, g.game_name_clean, g.cat_id',
					'FROM'		=> array(ARCADE_GAMES_TABLE => 'g'),
					'WHERE'		=> "1=1{$and_game_cats}{$and_user_type}",
					'ORDER_BY'	=> (($order_key) ? "{$order_key} {$order}, " : '') . 'g.game_name_clean ASC',
				);

				switch ($action)
				{
					case 'challenge_top_games':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_CHALLENGE_CHAMP_TABLE => 'cc'), 'ON' => 'g.game_id = cc.game_id');
						$sql_array['WHERE'] .= ' AND g.game_id = cc.game_id AND cc.champ_close = ' . CHALLENGE_CLOSE;
					case 'newest_games':
					case 'newest_games_img':
					break;

					case 'tour_top_games':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE	=> 'tc'),	'ON' => 'g.game_id = tc.game_id');
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_TOUR_TABLE			=> 't'),	'ON' => 'tc.tour_id = t.tour_id');
						$sql_array['WHERE'] .= ' AND tc.tour_id = t.tour_id
												 AND t.tour_status = ' . ARCADE_END_TOUR . '
												 AND t.tour_wins > ' . ANONYMOUS . '
												 AND g.game_id = tc.game_id';
					break;

					case 'favorites':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_FAVS_TABLE => 'f'), 'ON' => 'g.game_id = f.game_id');
						$sql_array['WHERE'] .= ' AND g.game_id = f.game_id' . (($id) ? ' AND f.user_id = ' . (int) $id : '');
					break;

					case 'downloaded_games':
						$sql_array['WHERE'] .= (($zero) ? '' : ' AND g.game_download_total > 0') . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'played_games':
						if ($details)
						{
							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_PLAYS_TABLE => 'p'), 'ON' => 'g.game_id = p.game_id');
							$sql_array['WHERE'] .= (($zero) ? '' : ' AND g.game_id = p.game_id') . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
						}
						else
						{
							$sql_array['WHERE'] .= (($zero) ? '' : ' AND g.game_plays > 0') . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
						}
					break;

					case 'not_played_games':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_SUPER_SCORES_TABLE => 's'), 'ON' => 'g.game_id = s.game_id');
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(USERS_TABLE => 'u'), 'ON' => 's.user_id = u.user_id');
						$sql_array['WHERE'] .= ' AND g.game_plays = 0' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'super_champions':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_SUPER_SCORES_TABLE => 's'), 'ON' => 'g.game_id = s.game_id');
						$sql_array['WHERE'] .= ' AND g.game_id = s.game_id' . (($id) ? ' AND s.user_id = ' . (int) $id : '') . (($sec_id) ? ' AND g.cat_id = ' . (int) $sec_id : '');
					break;

					case 'favs':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_FAVS_TABLE => 'f'), 'ON' => 'g.game_id = f.game_id');
						$sql_array['WHERE'] .= ' AND g.game_id = f.game_id' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'rated_games':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_RATING_TABLE => 'r'), 'ON' => 'g.game_id = r.game_id AND r.user_id = ' . (int) $this->user->data['user_id']);

						if ($id)
						{
							$sql_array['WHERE'] .= ' AND g.cat_id = ' . (int) $id;
						}
					case 'best_rated_img':
						$sql_array['WHERE'] .= ' AND g.game_votetotal > 0';
					break;

					case 'games_jackpots':
						$sql_array['WHERE'] .= ' AND g.game_jackpot > 0 AND ' . $this->db->sql_in_set('g.game_id', $this->arcade->points()->get_games_jackpot(), false, true) . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'random':
					case 'random_img':
						$game_ids = $this->arcade->get()->random_game($limit);
						$game_ids = (!is_array($game_ids)) ? array((int) $game_ids) : $game_ids;
						$sql_array['WHERE'] .= ' AND ' . $this->db->sql_in_set('g.game_id', array_map('intval', $game_ids), false, true);
						$sql_array['ORDER_BY'] = 'g.game_name_clean ASC';
					break;

					case 'challenge_played_games':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_CHALLENGE_CHAMP_TABLE => 'cc'), 'ON' => 'g.game_id = cc.game_id');
						$sql_array['WHERE'] .= ' AND g.game_id = cc.game_id AND cc.champ_close = ' . CHALLENGE_CLOSE . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'tour_played_games':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE => 'tc'), 'ON' => 'g.game_id = tc.game_id');
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_TOUR_TABLE => 't'), 'ON' => 'tc.tour_id = t.tour_id');
						$sql_array['WHERE'] .= ' AND g.game_id = tc.game_id AND tc.tour_id = t.tour_id AND t.tour_status = ' . ARCADE_END_TOUR . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;
				}

				if (in_array($action, array('favs', 'challenge_top_games', 'challenge_played_games', 'tour_played_games', 'tour_top_games')) || ($details && $action == 'played_games'))
				{
					$sql_array['GROUP_BY'] = 'g.game_id, g.game_name_clean, g.cat_id';
				}
			break;

			case 'user':
				$sql_array = array(
					'SELECT'	=> 'u.user_id, u.username, u.username_clean, u.user_colour, u.user_avatar, u.user_avatar_type',
					'FROM'		=> array(USERS_TABLE => 'u'),
					'WHERE'		=> "1=1{$and_user_type}{$and_game_cats}",
					'ORDER_BY'	=> "{$order_key} {$order}, u.username_clean ASC"
				);

				switch ($action)
				{
					case 'latest_highscores':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_GAMES_TABLE => 'g'), 'ON' => 'u.user_id = g.game_highuser');
						$sql_array['WHERE'] .= ' AND u.user_id = g.game_highuser';
					break;

					case 'longest_highscores':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_GAMES_TABLE => 'g'), 'ON' => 'u.user_id = g.game_highuser');
						$sql_array['WHERE'] .= ' AND u.user_id = g.game_highuser' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
					break;

					case 'users_playtime':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_PLAYS_TABLE => 'p'), 'ON' => 'u.user_id = p.user_id');
						$sql_array['WHERE'] .= ' AND u.user_id = p.user_id';
					break;

					case 'played_users':
						if ($ca || $id)
						{
							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_PLAYS_TABLE => 'p'), 'ON' => 'u.user_id = p.user_id');
							$sql_array['WHERE'] .= ($zero) ? '' : ' AND u.user_id = p.user_id';

							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_GAMES_TABLE => 'g'), 'ON' => 'p.game_id = g.game_id');
							$sql_array['WHERE'] .= ' AND p.game_id = g.game_id' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
						}
						else
						{
							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_USERS_TABLE => 'au'), 'ON' => 'u.user_id = au.user_id');
							$sql_array['WHERE'] .= ($zero) ? '' : ' AND au.arcade_total_plays > 0';
						}
					break;

					case 'highscores':
						if ($ca || $id)
						{
							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_GAMES_TABLE => 'g'), 'ON' => 'u.user_id = g.game_highuser');
							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_PLAYS_TABLE => 'p'), 'ON' => 'u.user_id = p.user_id AND g.game_id = p.game_id');
							$sql_array['WHERE'] .= ' AND u.user_id = g.game_highuser' . (($id) ? ' AND g.cat_id = ' . (int) $id : '');
						}
						else
						{
							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_USERS_TABLE => 'au'), 'ON' => 'u.user_id = au.user_id');
							$sql_array['WHERE'] .= ' AND u.user_id = au.user_id AND au.arcade_total_wins > 0';
						}
					break;

					case 'super_champions':
						if ($ca || $id)
						{
							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_SUPER_SCORES_TABLE => 's'), 'ON' => 'u.user_id = s.user_id');
							if ($id)
							{
								$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_GAMES_TABLE => 'g'), 'ON' => 's.game_id = g.game_id');
							}
							$sql_array['WHERE'] .= ' AND u.user_id = s.user_id' . (($id) ? ' AND s.game_id = g.game_id AND g.cat_id = ' . (int) $id : '');
						}
						else
						{
							$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_USERS_TABLE => 'au'), 'ON' => 'u.user_id = au.user_id');
							$sql_array['WHERE'] .= ' AND u.user_id = au.user_id AND au.arcade_total_super_scores > 0';
						}
					break;

					case 'challenge_latest_winners':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_CHALLENGE_CHAMP_TABLE	=> 'cc'), 'ON' => 'u.user_id = cc.champ_challenger_id');
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_GAMES_TABLE			=> 'g'),  'ON' => 'cc.game_id = g.game_id');
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(USERS_TABLE					=> 'u2'), 'ON' => 'cc.champ_opponent_id = u2.user_id');
						$sql_array['WHERE'] .= ' AND cc.champ_winner <> ' . CHALLENGE_TIE . '
												 AND u.user_id = cc.champ_challenger_id AND cc.champ_opponent_id = u2.user_id
												 AND cc.game_id = g.game_id';

						if ($and_user_type)
						{
							$sql_array['WHERE'] .= ' AND u2.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')';
						}
					break;

					case 'challenge_played_users':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_CHALLENGE_CHAMP_TABLE => 'cc'), 'ON' => 'u.user_id = cc.champ_challenger_id OR u.user_id = cc.champ_opponent_id');
						$sql_array['WHERE'] .= ' AND cc.champ_close = ' . CHALLENGE_CLOSE . ' AND (u.user_id = cc.champ_challenger_id OR u.user_id = cc.champ_opponent_id)';
					break;

					case 'challenge_winners':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_CHALLENGE_CHAMP_TABLE => 'cc'), 'ON' => 'u.user_id = cc.champ_winner');
						$sql_array['WHERE'] .= ' AND cc.champ_close = ' . CHALLENGE_CLOSE . ' AND u.user_id = cc.champ_winner';
					break;

					case 'tour_winners':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_TOUR_TABLE => 't'), 'ON' => 'u.user_id = t.tour_wins');
						$sql_array['WHERE'] .= ' AND t.tour_status = ' . ARCADE_END_TOUR . ' AND u.user_id = t.tour_wins';
					break;

					case 'tour_played_users':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE => 'tc'), 'ON' => 'u.user_id = tc.user_id');
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_TOUR_TABLE		  => 't'),  'ON' => 'tc.tour_id = t.tour_id');
						$sql_array['WHERE'] .= ' AND t.tour_status = ' . ARCADE_END_TOUR . ' AND tc.tour_id = t.tour_id AND u.user_id = tc.user_id';
					break;

					case 'tour_latest_winners':
						$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_TOUR_TABLE => 't'), 'ON' => 'u.user_id = t.tour_wins');
						$sql_array['WHERE'] .= ' AND t.tour_status = ' . ARCADE_END_TOUR . '
												 AND t.tour_wins > ' . ANONYMOUS . '
												 AND t.tour_wins = u.user_id';
					break;
				}

				if (in_array($action, array('users_playtime', 'challenge_played_users', 'challenge_winners', 'tour_winners', 'tour_played_users')) || (in_array($action, array('highscores', 'super_champions', 'played_users')) && ($ca || $id)))
				{
					$sql_array['GROUP_BY'] = 'u.user_id, u.username, u.username_clean, u.user_colour, u.user_avatar, u.user_avatar_type';
				}
			break;
		}

		if ($extra_col)
		{
			$sql_array['SELECT'] .= ", $extra_col";
		}

		if ($order_by)
		{
			$original_order_by = $sql_array['ORDER_BY'];
			$default_sort = ($mode == 'game') ? 'g.game_name_clean' : 'u.username_clean';
			$sql_array['ORDER_BY'] = $order_by . ((strpos($order_by, $default_sort) === false) ? ", $default_sort ASC" : '');
		}

		$rang_key = explode(' ', ($order_by) ? $order_by : $order_key);
		$rang_key = array_shift($rang_key);
		$rang_key = (strpos($rang_key, '.') !== false) ? substr(strrchr($rang_key, '.'), 1) : $rang_key;
		$rang_key = (strpos($rang_key, 'SUM(') !== false) ? 'tp_avg' : $rang_key;

		$sql_array['WHERE'] = str_replace(array('1=1 AND', 'AND 1=1'), '', $sql_array['WHERE']);

		if ($order_by && (!empty($sql_array['GROUP_BY']) || strpos($sql_array['ORDER_BY'], 'time') !== false))
		{
			$x = 1;
			$order_by = explode(', ', $sql_array['ORDER_BY']);

			foreach ($order_by as $order)
			{
				$order = str_replace(array(' asc', ' desc', ' ASC', ' DESC'), '', $order);
				if (strpos($sql_array['SELECT'], $order) === false)
				{
					if (strpos($order, 'time') !== false)
					{
						$sql_array['SELECT']  .= ', (' . $order . ') AS ' . "oldest_time_$x";
						$sql_array['ORDER_BY'] = str_replace($order, "oldest_time_$x", $sql_array['ORDER_BY']);
						$x++;
					}
					else
					{
						$sql_array['ORDER_BY'] = $original_order_by;
					}
				}
			}
		}

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query_limit($sql, $limit, $start, $cache_ttl);

		if ($tpl && $tpl_key)
		{
			while ($row = $this->db->sql_fetchrow($result))
			{
				if ($mode == 'game' || ($mode == 'user' && in_array($action, array('latest_highscores', 'longest_highscores'))))
				{
					$row += array(
						'game_name'		=> $this->arcade->get()->game_field($row['game_id'], 'game_name'),
						'game_image'	=> $this->arcade->get()->game_field($row['game_id'], 'game_image'),
						'game_width'	=> $this->arcade->get()->game_field($row['game_id'], 'game_width'),
						'game_height'	=> $this->arcade->get()->game_field($row['game_id'], 'game_height'),
						'cat_name'		=> $this->arcade->get()->cat_field($row['cat_id'], 'cat_name'),
						'cat_status'	=> $this->arcade->get()->cat_field($row['cat_id'], 'cat_status')
					);
				}

				$value = (!empty($row[$rang_key])) ? $row[$rang_key] : 0;

				if ($rang_key == 'rating_avg' && !empty($row['game_votetotal']))
				{
					$value += $row['game_votetotal'];
				}
				else if ($rang_key == 'tp_avg' && !empty($row['t_plays']))
				{
					$value = intval($row['t_time'] / $row['t_plays']);
				}

				$this->arcade->get()->actual_rank($actual_rank, $rank, $value, $last_value);

				switch ($mode)
				{
					case 'game':
						switch ($action)
						{
							case 'newest_games':
								$arcade_game_count++;
							case 'challenge_top_games':
							case 'tour_top_games':
								$game_mode = 'play';
							break;
						}

						$tpl_rows = array(
							'GAME_CAT_NAME'	=> $this->arcade->get()->cat_name($row['cat_name'], $row['cat_id'], $row['game_id'], 'x', (($action == 'favorites') ? false : true), (($action == 'favorites') ? 'topictitle' : '')),
							'GAME_IMAGE'	=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($row['game_image'], 20, 20, 'x', $game_mode, $row['cat_id'], $row['game_id']) : false,
							'GAME_POPUP'	=> ($this->arcade->optionget('view_popup_icon')) ? $this->arcade->get()->game_popup('icon', $row['cat_id'], $row['game_id'], $row['game_width'], $row['game_height'], 'x') : false,
							'GAME_NAME'		=> ($this->arcade_config['newest_games_tooltip'] && $action == 'newest_games') ? $this->arcade->get()->gamename_tooltip($row) : $this->arcade->get()->game_name($row['game_name'], true, 'play', $row['cat_id'], $row['game_id'], 'x')
						);

						switch ($action)
						{
							case 'challenge_top_games':
							case 'tour_top_games':
								$tpl_rows = array_merge($tpl_rows, array(
									'GAME_PLAYED' => $this->arcade->number_format($row['total_played'])
								));

							case 'random':
							case 'newest_games':
								$data = true;
							break;

							case 'newest_games_img':
							case 'random_img':
								$tpl_rows['GAME_IMAGE'] = ($this->arcade->optionget('view_game_image')) ? str_replace('style="', 'style="padding: 5px; ', $this->arcade->get()->game_image($row['game_image'], 50, 50, $this->user->lang['ARCADE_CLICK_PLAY'] . ': ' . $row['game_name'], 'play', $row['cat_id'], $row['game_id'])) : false;

								$data = true;
							break;

							case 'best_rated_img':
								$title = sprintf($this->user->lang['ARCADE_GAME_RATING_TITLE'], $row['game_name'], $this->arcade->number_format($row['rating_avg']), $this->arcade->number_format($row['game_votetotal']));
								$tpl_rows['GAME_NAME']  = $this->arcade->get()->game_name($row['game_name'], true, 'play', $row['cat_id'], $row['game_id'], $title);
								$tpl_rows['GAME_IMAGE'] = ($this->arcade->optionget('view_game_image')) ? str_replace('style="', 'style="padding: 5px; ', $this->arcade->get()->game_image($row['game_image'], 50, 50, $title, 'play', $row['cat_id'], $row['game_id'])) : false;

								$data = true;
							break;

							case 'downloaded_games':
								$tpl_rows = array_merge($tpl_rows, array(
									'GAME_DATA' => sprintf($this->user->lang['ARCADE_GAME_DOWNLOAD_TOTAL' . (($row['game_download_total'] > 1) ? 'S' : '')], $this->arcade->get()->game_name($row['game_name'], true, $game_mode, $row['cat_id'], $row['game_id'], 'x'), $this->arcade->number_format($row['game_download_total']))
								));

								$data = true;
							break;

							case 'played_games':
							case 'challenge_played_games':
							case 'tour_played_games':
								$tpl_rows = array_merge($tpl_rows, array(
									'U_USERS'		=> $this->arcade->url("mode=stats" . (($action == 'played_games') ? '' : '&amp;type=' . $arcade_page) . "&amp;g={$row['game_id']}") . '#gamebox',

									'RANK'			=> $rank,
									'TOTAL_PLAYS'	=> $this->arcade->number_format($row['t_plays']),

									'GAME_DATA'		=> sprintf($this->user->lang['ARCADE_STATS_PLAY' . (($row['t_plays'] > 1) ? 'S' : '')], $this->arcade->get()->game_name($row['game_name'], true, 'play', $row['cat_id'], $row['game_id'], 'x'), $this->arcade->number_format($row['t_plays']))
								));

								if ($details)
								{
									$tpl_rows = array_merge($tpl_rows, array(
										'TOTAL_USERS'	=> ($action == 'played_games') ? $this->arcade->number_format($row['t_users']) : '',
										'TOTAL_TIME'	=> $this->arcade->time_format($row['t_time']),
										'AVG_TIME'		=> ($row['t_plays']) ? $this->arcade->time_format($row['t_time']/$row['t_plays']) : ''

									));
								}

								$data = true;
							break;

							case 'not_played_games':
								$tpl_rows = array_merge($tpl_rows, array(
									'RANK'		=> $rank,
									'USERNAME'	=> ($row['user_id']) ? $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], $user_mode, 'x') : '-'
								));

								$data = true;
							break;

							case 'favorites':
								$tpl_rows = array_merge($tpl_rows, array(
									'S_GAME_HIGHLIGHTED'	=> $row['highlighted'],
									'GAME_ID'				=> $row['game_id']
								));

								$data = true;
							break;

							case 'super_champions':
								$tpl_rows = array_merge($tpl_rows, array(
									'GAME_SCORE'	=> $this->arcade->number_format($row['score']),
									'GAME_DATE'		=> $this->user->format_date($row['score_date'])
								));

								$data = true;
							break;

							case 'favs':
								$tpl_rows = array_merge($tpl_rows, array(
									'RANK'	=> $rank,
									'TOTAL'	=> $this->arcade->number_format($row['total'])
								));

								$data = true;
							break;

							case 'rated_games':
								$tpl_rows = array_merge($tpl_rows, array(
									'RANK'				=> $rank,
									'AVG_NUM'			=> $this->arcade->number_format($row['rating_avg']),
									'USERS_COUNT'		=> $this->arcade->number_format($row['game_votetotal']),
									'GAME_RATING_IMG'	=> $this->arcade->set_rating_image($row)
								));

								$data = true;
							break;

							case 'games_jackpots':
								$tpl_rows = array_merge($tpl_rows, array(
									'RANK'			=> $rank,
									'GAME_JACKPOT'	=> $this->arcade->number_format($row['game_jackpot'])
								));

								$data = true;
							break;
						}
					break;

					case 'user':
						$username = $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], $user_mode, 'x');

						$tpl_rows = array(
							'AVATAR'	=> ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($row['user_avatar'], $row['user_avatar_type'], 20, 20, 'x', $user_mode, $row['user_id']) : false,
							'USERNAME'	=> $username
						);

						switch ($action)
						{
							case 'latest_highscores':
							case 'challenge_latest_winners':
							case 'tour_latest_winners':
								$this->tpl_latest_hsw($user_mode, $row, $tpl_key);
								$tpl_rows = array();

								$data = true;
							break;

							case 'longest_highscores':
								$tpl_rows = array_merge($tpl_rows, array(
									'GAME_POPUP'		=> ($this->arcade->optionget('view_popup_icon')) ? $this->arcade->get()->game_popup('icon', $row['cat_id'], $row['game_id'], $row['game_width'], $row['game_height'], 'x') : false,
									'GAME_NAME'			=> $this->arcade->get()->game_name($row['game_name'], true, 'play', $row['cat_id'], $row['game_id'], 'x'),

									'RANK'				=> $rank,
									'HIGHSCORE'			=> (!$this->arcade->hidden_score($row['game_id'], $row['user_id'])) ? $this->arcade->number_format($row['game_highscore']) : $this->user->lang['HIDDEN'],
									'HIGHSCORE_DATE'	=> $this->user->format_date($row['game_highdate']),
									'TIME_HELD'			=> $this->arcade->time_format((time() - $row['game_highdate']))
								));

								$data = true;
							break;

							case 'users_playtime':
								$tpl_rows = array_merge($tpl_rows, array(
									'PLAYTIME'	=> $this->arcade->number_format(round($row['total_time']/3600, 2))
								));

								$data = true;
							break;

							case 'played_users':
							case 'challenge_played_users':
							case 'tour_played_users':
								$tpl_rows = array_merge($tpl_rows, array(
									'U_GAMES'		=> $this->arcade->url("mode=stats" . (($action == 'played_users') ? '' : '&amp;type=' . $arcade_page) . "&amp;u={$row['user_id']}") . '#userbox',

									'RANK'			=> $rank,
									'TOTAL_PLAYS'	=> $this->arcade->number_format($row['t_plays']),
									'GAMES_COUNT'	=> ($action == 'played_users') ? $this->arcade->number_format($row['games_count']) : '',
									'TOTAL_TIMES'	=> ($action == 'played_users') ? $this->arcade->time_format($row['t_time']) : '',
									'AVG_TIME'		=> ($action == 'played_users' && $row['t_plays']) ? $this->arcade->time_format($row['t_time']/$row['t_plays']) : '',

									'USER_DATA'		=> sprintf($this->user->lang['ARCADE_STATS_PLAY' . (($row['t_plays'] > 1) ? 'S' : '')], $username, $this->arcade->number_format($row['t_plays']))
								));

								$data = true;
							break;

							case 'highscores':
							case 'challenge_winners':
							case 'tour_winners':
								$u_wins		= ($action == 'highscores') ? "u={$row['user_id']}&amp;hs=1" : "type=$arcade_page&amp;u={$row['user_id']}&amp;w=1";
								$total_wins	= $this->arcade->number_format($row['total_wins']);

								$tpl_rows = array_merge($tpl_rows, array(
									'U_WINS'			=> $this->arcade->url("mode=stats&amp;{$u_wins}") . '#' . (($arcade_page == 'tournament') ? 'userbox' : 'usergamebox'),

									'RANK'				=> $rank,
									'TOTAL_PLAYS'		=> ($action == 'highscores') ? $this->arcade->number_format($row['total_plays']) : '',
									'TOTAL_TIMES'		=> ($action == 'highscores') ? $this->arcade->time_format($row['total_times']) : '',
									'TOTAL_WINS'		=> $total_wins,

									'USER_WINS'			=> sprintf($this->user->lang['ARCADE_STATS_WIN' . (($row['total_wins'] > 1) ? 'S' : '')], $username, "($total_wins)"),
									'USER_WINS_TITLE'	=> sprintf($this->user->lang['ARCADE_STATS_WIN' . (($row['total_wins'] > 1) ? 'S' : '')], $row['username'], "($total_wins)")
								));

								$data = true;
							break;

							case 'super_champions':
								$total_wins		= $this->arcade->number_format($row['total_wins']);
								$title			= $this->user->lang['ARCADE_VIEW_GAME' . (($row['total_wins'] > 1) ? 'S' : '')];
								$u_user			= $this->arcade->url("mode=stats&amp;ds=super_champions&amp;u={$row['user_id']}", 'arcade', false, true);
								$u_user_games	= '<a href="' . $u_user . '" title="' . $title . '">[ ' . $total_wins . ' ]</a>';

								$tpl_rows = array_merge($tpl_rows, array(
									'U_USER'		=> $u_user,
									'U_TOTAL_GAMES'	=> sprintf($this->user->lang['ARCADE_STATS_SUPER_CHAMP_GAME' . (($row['total_wins'] > 1) ? 'S' : '')], $username, $u_user_games),

									'RANK'			=> $rank,
									'TITLE'			=> $title,
									'TOTAL_WINS'	=> $total_wins
								));

								$data = true;
							break;
						}
					break;
				}

				if (!empty($data) && count($tpl_rows))
				{
					$this->template->assign_block_vars("{$tpl_key}", $tpl_rows);
				}
			}
		}
		else
		{
			$data = $this->db->sql_fetchrowset($result);
		}
		$this->db->sql_freeresult($result);

		return (!empty($data)) ? $data : false;
	}

	function tpl_latest_hsw($mode, $row, $tpl_key)
	{
		if ($mode == 'tournament')
		{
			$tour_name			= $this->arcade->get()->tour_name($row['tour_id'], $row['tour_name'], 'x', true);
			$champ_avatar		= ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($row['user_avatar'], $row['user_avatar_type'], 20, 20, 'x', 'tournament', $row['user_id'], $row['tour_id']) : false;
			$winner_name		= $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'tournament', 'x', false, $row['tour_id']);
			$champ_data			= sprintf($this->user->lang['ARCADE_TOUR_UT_WINNER'], $winner_name, $tour_name);
			$champ_date			= sprintf($this->user->lang['ARCADE_TOUR_END_DATE'], $this->user->format_date($row['tour_endtime']));
			$tour_name_tooltip	= $this->arcade->get()->tour_name($row['tour_id'], $row['tour_name'], 'x', true, $champ_date);
			$champ_data_tooltip	= sprintf($this->user->lang['ARCADE_TOUR_UT_WINNER'], $winner_name, $tour_name_tooltip);
		}
		else
		{
			$latest = array(
				'cat_id'		=> $row['cat_id'],
				'game_id'		=> $row['game_id'],
				'game_name'		=> $row['game_name'],
				'game_width'	=> $row['game_width'],
				'game_height'	=> $row['game_height']
			);

			if ($mode == 'arcade')
			{
				$latest = array_merge($latest, array(
					'game_highscore'	=> $row['game_highscore'],
					'game_highdate'		=> $row['game_highdate'],
					'user_id'			=> $row['user_id'],
					'username'			=> $row['username'],
					'user_colour'		=> $row['user_colour'],
					'user_avatar'		=> $row['user_avatar'],
					'user_avatar_type'	=> $row['user_avatar_type']
				));
			}
			else
			{
				$latest = array_merge($latest, array(
					'end_time'				=> $row['champ_end_time'],

					'winner_id'				=> ($row['champ_winner'] == $row['user_id']) ? $row['user_id'] : $row['user_id2'],
					'winner_name'			=> ($row['champ_winner'] == $row['user_id']) ? $row['username'] : $row['username2'],
					'winner_color'			=> ($row['champ_winner'] == $row['user_id']) ? $row['user_colour'] : $row['user_colour2'],
					'winner_avatar'			=> ($row['champ_winner'] == $row['user_id']) ? $row['user_avatar'] : $row['user_avatar2'],
					'winner_avatar_type'	=> ($row['champ_winner'] == $row['user_id']) ? $row['user_avatar_type'] : $row['user_avatar_type2'],
					'winner_score'			=> ($row['champ_winner'] == $row['champ_challenger_id']) ? $row['champ_challenger_score'] : $row['champ_opponent_score'],

					'loser_id'				=> ($row['champ_winner'] == $row['user_id']) ? $row['user_id2'] : $row['user_id'],
					'loser_name'			=> ($row['champ_winner'] == $row['user_id']) ? $row['username2'] : $row['username'],
					'loser_color'			=> ($row['champ_winner'] == $row['user_id']) ? $row['user_colour2'] : $row['user_colour'],
					'loser_score'			=> ($row['champ_winner'] == $row['champ_challenger_id']) ? $row['champ_opponent_score'] : $row['champ_challenger_score']
				));
			}

			$game_popup = ($this->arcade->optionget('view_popup_icon')) ? $this->arcade->get()->game_popup('icon', $latest['cat_id'], $latest['game_id'], $latest['game_width'], $latest['game_height'], 'x') : '';

			if ($mode == 'arcade')
			{
				$high_score			= (!$this->arcade->hidden_score($latest['game_id'], $latest['user_id'])) ? $this->arcade->number_format($latest['game_highscore']) : $this->user->lang['HIDDEN'];
				$latest_scoreuser	= $this->arcade->get()->user_name('full', $latest['user_id'], $latest['username'], $latest['user_colour'], 'arcade', 'x');
				$champ_score		= sprintf($this->user->lang['ARCADE_WELCOME_SCORE'], $high_score);
				$champ_date			= sprintf($this->user->lang['ARCADE_SAVING_DATE'], $this->user->format_date($latest['game_highdate']));
				$game_name			= $this->arcade->get()->game_name($latest['game_name'], true, 'play', $latest['cat_id'], $latest['game_id'], 'x');
				$game_name_tooltip	= $this->arcade->get()->game_name($latest['game_name'], true, 'play', $latest['cat_id'], $latest['game_id'], '', $champ_score . '<br>' . $champ_date, true);

				$champ_avatar		= ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($latest['user_avatar'], $latest['user_avatar_type'], 20, 20, 'x', 'arcade', $latest['user_id']) : false;
				$champ_data			= sprintf($this->user->lang['ARCADE_UG_NEW_CHAMPION'], $latest_scoreuser, $game_popup . ' ' . $game_name, $this->arcade->number_format($latest['game_highscore'])) . ' ' . $champ_score;
				$champ_data_tooltip	= sprintf($this->user->lang['ARCADE_UG_NEW_CHAMPION'], $latest_scoreuser, $game_popup . ' ' . $game_name_tooltip);
			}
			else
			{
				$winner_user		= $this->arcade->get()->user_name('full', $latest['winner_id'], $latest['winner_name'], $latest['winner_color'], 'challenge', 'x');
				$loser_user			= $this->arcade->get()->user_name('full', $latest['loser_id'], $latest['loser_name'], $latest['loser_color'], 'challenge', 'x');
				$champ_date			= sprintf($this->user->lang['ARCADE_CHALLENGE_END_DATE'], $this->user->format_date($latest['end_time']));
				$tooltip_msg		= sprintf($this->user->lang['CHALLENGE_WELCOME_SCORE'], $latest['winner_name'], $this->arcade->number_format($latest['winner_score']), $latest['loser_name'], $this->arcade->number_format($latest['loser_score']));
				$gn_tooltip			= $this->arcade->get()->game_name($latest['game_name'], true, 'play', $latest['cat_id'], $latest['game_id'], '', $tooltip_msg, true);
				$gn_date_tooltip	= $this->arcade->get()->game_name($latest['game_name'], true, 'play', $latest['cat_id'], $latest['game_id'], '', $tooltip_msg . '<br><br>' . $champ_date , true);

				$champ_avatar		= ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($latest['winner_avatar'], $latest['winner_avatar_type'], 20, 20, 'x', 'challenge', $latest['winner_id']) : false;
				$champ_data			= sprintf($this->user->lang['ARCADE_CHALLENGE_UG_WINNER'], $winner_user, $game_popup . ' ' . $gn_tooltip, $loser_user);
				$champ_data_tooltip	= sprintf($this->user->lang['ARCADE_CHALLENGE_UG_WINNER'], $winner_user, $game_popup . ' ' . $gn_date_tooltip, $loser_user);
			}
		}

		$this->template->assign_block_vars($tpl_key, array(
			'HEADING_CHAMP_AVATAR'	=> $champ_avatar,
			'HEADING_CHAMP'			=> $champ_data,
			'HEADING_CHAMP_DATE'	=> $champ_date,
			'HEADING_CHAMP_TOOLTIP'	=> $champ_data_tooltip
		));
	}

	public function cat_stats($mode, $cat_id, $game_id, $start)
	{
		$cat_data = $this->arcade->cats()[$cat_id];

		if (!$cat_data)
		{
			trigger_error($this->user->lang['NO_CAT_ID'] . $this->arcade->back_link());
		}

		$this->stats_data('user', 'longest_highscores', 'least', 0, $this->arcade_config['cat_longest_held_scores'], true, 'record_row', '', $cat_id);
		$this->stats_data('user', 'highscores', 'most', 0, $this->arcade_config['cat_leaders'], true, 'leaders_users', '', $cat_id);
		$this->stats_data('user', 'super_champions', 'most', 0, $this->arcade_config['cat_super_champions'], true, 'super_champions', '', $cat_id);
		$this->stats_data('game', 'played_games', 'most', 0, $this->arcade_config['cat_most_popular'], true, 'pop_games', '', $cat_id);
		$this->stats_data('game', 'played_games', 'least', 0, $this->arcade_config['cat_least_popular'], true, 'lpop_games', '', $cat_id);
		$this->stats_data('user', 'played_users', 'most', 0, $this->arcade_config['cat_most_played_users'], true, 'pop_users', '', $cat_id);
		$this->stats_data('user', 'played_users', 'least', 0, $this->arcade_config['cat_least_played_users'], true, 'lpop_users', '', $cat_id);

		if ($this->arcade->game()->download_stat_auth())
		{
			$this->stats_data('game', 'downloaded_games', 'most', 0, $this->arcade_config['cat_most_downloaded'], true, 'downloaded_games', '', $cat_id);
			$this->stats_data('game', 'downloaded_games', 'least', 0, $this->arcade_config['cat_least_downloaded'], true, 'ldownloaded_games', '', $cat_id);
		}

		$this->template->assign_vars(array(
			'S_IN_STATS'			=> (!$this->arcade_config['display_cat_games_stats']) ? true : false,
			'S_CAT_STATS'			=> ($this->arcade_config['display_cat_games_stats']) ? true : false,

			'L_ARCADE_STATS_TITLE'	=> sprintf($this->user->lang['ARCADE_CAT_STATS'], $cat_data['cat_name']),
			'L_ARCADE_LEADERS'		=> sprintf($this->user->lang['ARCADE_CAT_LEADERS'], $cat_data['cat_name'])
		));

		if ($this->arcade_config['display_cat_games_stats'])
		{
			$this->arcade->container('cat_games')->display($mode, $cat_id, $game_id, $start);
		}
		else
		{
			$this->arcade->page_title = sprintf($this->user->lang['ARCADE_CAT_STATS'], $this->arcade->get()->cat_field($cat_id, 'cat_name'));
			$this->arcade->add_navlink('cat_stat', '', '', $cat_data);

			$this->online_playing();
			$this->page($this->arcade->page_title, "arcade/stats_body.html");
		}
	}

	public function category($root_data = array())
	{
		$parent_id = $visible_cats = 0;
		$cat_rows = $subcats = $cat_ids = $valid_categories = array();
		$arcade_style = ($this->arcade_config['override_user_cat_style']) ? $this->arcade_config['default_cat_style'] : $this->user->data['arcade_cat_style'];

		if (!count($root_data))
		{
			$this->template->assign_vars(array(
				'S_IN_ARCADE_INDEX'		=> true,
				'CAT_IMG'				=> $this->user->img('forum_read', 'NO_NEW_GAMES'),
				'CAT_NEW_IMG'			=> $this->user->img('forum_unread', 'NEW_GAMES'),
				'CAT_LOCKED_IMG'		=> $this->user->img('forum_read_locked', 'NEW_GAMES_LOCKED'),
				'CAT_NEW_LOCKED_IMG'	=> $this->user->img('forum_unread_locked', 'NO_NEW_GAMES_LOCKED')
			));

			$this->main_box('arcade', $this->arcade_config['welcome_index'], $this->arcade_config['search_index']);

			$root_data = array('cat_id' => 0);
			$sql_where = '';
		}
		else
		{
			$sql_where = ' WHERE left_id > ' . (int) $root_data['left_id'] . ' AND left_id < ' . (int) $root_data['right_id'];
		}

		$branch_root_id = $root_data['cat_id'];

		$sql = 'SELECT *
				FROM ' . ARCADE_CATS_TABLE . "
				$sql_where
				ORDER BY left_id";
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$cat_id = (int) $row['cat_id'];

			// Category with no members
			if ($row['cat_type'] == ARCADE_CAT && ($row['left_id'] + 1 == $row['right_id']))
			{
				continue;
			}

			// Skip branch
			if (isset($right_id))
			{
				if ($row['left_id'] < $right_id)
				{
					continue;
				}

				unset($right_id);
			}

			if (!$this->arcade_auth->acl_get('c_list', $cat_id))
			{
				// if the user does not have permissions to list this category, skip everything until next branch
				$right_id = $row['right_id'];
				continue;
			}

			if (isset($cat_rows[$row['parent_id']]))
			{
				$valid_categories[$row['parent_id']] = true;
			}

			$cat_ids[] = $cat_id;

			if ($row['parent_id'] == $root_data['cat_id'] || $row['parent_id'] == $branch_root_id)
			{
				// Direct child of current branch
				$parent_id = $cat_id;
				$cat_rows[$cat_id] = $row;

				if ($row['cat_type'] == ARCADE_CAT && $row['parent_id'] == $root_data['cat_id'])
				{
					$branch_root_id = $cat_id;
				}

				$cat_rows[$parent_id]['orig_cat_last_play_time'] = $row['cat_last_play_time'];
			}
			else if ($row['cat_type'] != ARCADE_CAT)
			{
				$subcats[$parent_id][$cat_id]['display'] = ($row['display_on_index']) ? true : false;
				$subcats[$parent_id][$cat_id]['name'] = $row['cat_name'];
				$subcats[$parent_id][$cat_id]['type'] = $row['cat_type'];
				$subcats[$parent_id][$cat_id]['orig_cat_last_play_time'] = $row['cat_last_play_time'];
				$subcats[$parent_id][$cat_id]['cat_last_game_installdate'] = $row['cat_last_game_installdate'];

				$cat_rows[$parent_id]['cat_games'] += $row['cat_games'];

				// Do not list redirects in LINK Categorys as Games.
				if ($row['cat_type'] != ARCADE_LINK)
				{
					$cat_rows[$parent_id]['cat_plays'] += $row['cat_plays'];
				}

				if ($row['cat_last_play_time'] > $cat_rows[$parent_id]['cat_last_play_time'])
				{
					$cat_rows[$parent_id]['cat_last_play_game_id'] = $row['cat_last_play_game_id'];
					$cat_rows[$parent_id]['cat_last_play_game_name'] = $row['cat_last_play_game_name'];
					$cat_rows[$parent_id]['cat_last_play_time'] = $row['cat_last_play_time'];
					$cat_rows[$parent_id]['cat_last_play_user_id'] = $row['cat_last_play_user_id'];
					$cat_rows[$parent_id]['cat_last_play_username'] = $row['cat_last_play_username'];
					$cat_rows[$parent_id]['cat_last_play_user_colour'] = $row['cat_last_play_user_colour'];
					$cat_rows[$parent_id]['cat_last_play_score'] = $row['cat_last_play_score'];
				}
			}
		}
		$this->db->sql_freeresult($result);

		// Used to tell whatever we have to create a dummy category or not.
		$last_catless = true;

		foreach ($cat_rows as $row)
		{
			// Empty category
			if ($row['parent_id'] == $root_data['cat_id'] && $row['cat_type'] == ARCADE_CAT)
			{
				if (!isset($valid_categories[$row['cat_id']]))
				{
					continue;
				}

				$this->template->assign_block_vars('catrow', array(
					'S_IS_CAT'			=> true,
					'S_VIEW_CAT_GAMES'	=> ($this->arcade_auth->acl_get('c_view', $row['cat_id'])) ? true : false,

					'CAT_ID'			=> $row['cat_id'],
					'CAT_NAME'			=> $row['cat_name'],
					'CAT_DESC'			=> generate_text_for_display($row['cat_desc'], $row['cat_desc_uid'], $row['cat_desc_bitfield'], $row['cat_desc_options']),
					'CAT_FOLDER_IMG'	=> '',
					'CAT_IMAGE'			=> $this->arcade->get()->image('full', 'cat', $row['cat_image'], 'ARCADE_VIEW_CATEGORY'),

					'U_VIEWCAT'			=> $this->arcade->url('mode=cat&amp;c=' . $row['cat_id'])
				));

				continue;
			}

			$visible_cats++;
			$cat_id = (int) $row['cat_id'];

			$cat_new_games = ((time() - $row['cat_last_game_installdate']) <= ($this->arcade_config['new_games_delay'] * 86400)) ? true : false;

			$folder_image = $folder_alt = $l_subcats = '';
			$subcats_list = array();

			// Generate list of subcategorys if we need to
			if (isset($subcats[$cat_id]))
			{
				foreach ($subcats[$cat_id] as $subcat_id => $subcat_row)
				{
					$subcat_new_games = ((time() - $subcat_row['cat_last_game_installdate']) <= ($this->arcade_config['new_games_delay'] * 86400)) ? true : false;

					if ($subcat_row['display'] && $subcat_row['name'])
					{
						$subcats_list[] = array(
							'link'		=> $this->arcade->url('mode=cat&amp;c=' . $subcat_id),
							'name'		=> $subcat_row['name'],
							'type'		=> $subcat_row['type'],
							'unread'	=> $subcat_new_games
						);
					}
					else
					{
						unset($subcats[$cat_id][$subcat_id]);
					}

					// If one subcat has new games the cat gets new games too...
					if ($subcat_new_games)
					{
						$cat_new_games = true;
					}
				}

				$l_subcats = (count($subcats[$cat_id]) == 1) ? $this->user->lang['ARCADE_SUBCAT'] . ': ' : $this->user->lang['ARCADE_SUBCATS'] . ': ';
				$folder_image = ($cat_new_games) ? 'forum_unread_subforum' : 'forum_read_subforum';
			}
			else
			{
				switch ($row['cat_type'])
				{
					case ARCADE_CAT_GAMES:
						$folder_image = ($cat_new_games) ? 'forum_unread' : 'forum_read';
					break;

					case ARCADE_LINK:
						$folder_image = 'forum_link';
					break;
				}
			}

			// Which folder should we display?
			if ($row['cat_status'] == ITEM_LOCKED)
			{
				$folder_image = ($cat_new_games) ? 'forum_unread_locked' : 'forum_read_locked';
				$folder_alt = 'ARCADE_CAT_LOCKED';
			}
			else
			{
				$folder_alt = ($cat_new_games) ? 'ARCADE_NEW_GAMES' : 'ARCADE_NO_NEW_GAMES';
			}

			$l_play_click_count = ($row['cat_type'] == ARCADE_LINK) ? 'CLICKS' : 'PLAYS';
			$play_click_count = ($row['cat_type'] != ARCADE_LINK || $row['cat_flags'] & ARCADE_FLAG_LINK_TRACK) ? $this->arcade->number_format($row['cat_plays']) : '';

			$s_subcats_list = $subcats_row = array();

			foreach ($subcats_list as $subcat)
			{
				$s_subcats_list[] = '<a href="' . $subcat['link'] . '" class="subforum ' . (($subcat['unread']) ? 'unread' : 'read') . '" title="' . $this->user->lang['ARCADE_' . (($subcat['unread']) ? 'NEW_GAMES' : 'NO_NEW_GAMES')] . '">' . $subcat['name'] . '</a>';

				$subcats_row[] = array(
					'U_SUBCAT'		=> $subcat['link'],
					'SUBCAT_NAME'	=> $subcat['name'],
					'S_UNREAD'		=> $subcat['unread'],
					'IS_LINK'		=> $subcat['type'] == ARCADE_LINK
				);
			}

			$s_subcats_list = (string) implode($this->user->lang['COMMA_SEPARATOR'], $s_subcats_list);
			$catless = ($row['parent_id'] == $root_data['cat_id']) ? true : false;

			if ($row['cat_type'] != ARCADE_LINK)
			{
				$u_viewcat = $this->arcade->url('mode=cat&amp;c=' . $row['cat_id']);
			}
			else
			{
				// If the category is a link and we count redirects we need to visit it
				// If the category is having a password or no read access we do not expose the link, but instead handle it in view category
				if (($row['cat_flags'] & ARCADE_FLAG_LINK_TRACK) || $row['cat_password'] || !$this->arcade_auth->acl_get('c_view', $cat_id))
				{
					$u_viewcat = $this->arcade->url('mode=cat&amp;c=' . $row['cat_id']);
				}
				else
				{
					$u_viewcat = $row['cat_link'];
				}
			}

			$this->template->assign_block_vars('catrow', array(
				'S_IS_CAT'				=> false,
				'S_NO_CAT'				=> $catless && !$last_catless,
				'S_IS_LINK'				=> ($row['cat_type'] == ARCADE_LINK) ? true : false,
				'S_CAT_NEW_GAMES'		=> ($cat_new_games) ? true : false,
				'S_LOCKED_CAT'			=> ($row['cat_status'] == ITEM_LOCKED) ? true : false,
				'S_LIST_SUBCATS'		=> ($row['display_subcat_list']) ? true : false,
				'S_VIEW_CAT_GAMES'		=> ($this->arcade_auth->acl_get('c_view', $row['cat_id'])) ? true : false,

				'CAT_NAME'				=> $row['cat_name'],
				'CAT_DESC'				=> generate_text_for_display($row['cat_desc'], $row['cat_desc_uid'], $row['cat_desc_bitfield'], $row['cat_desc_options']),
				'GAMES'					=> $this->arcade->number_format($row['cat_games']),
				$l_play_click_count		=> $play_click_count,
				'CAT_IMG_STYLE'			=> $folder_image,
				'CAT_FOLDER_IMG'		=> $this->user->img($folder_image, $folder_alt),
				'CAT_FOLDER_IMG_ALT'	=> $this->user->lang[$folder_alt],
				'CAT_IMAGE_SRC'			=> $this->arcade->get()->image('src', 'cat', $row['cat_image'], 'ARCADE_VIEW_CATEGORY'),
				'CAT_IMAGE'				=> $this->arcade->get()->image('full', 'cat', $row['cat_image'], 'ARCADE_VIEW_CATEGORY'),
				'DISPLAY_CAT_IMAGE'		=> ($row['cat_display'] != ARCADE_CAT_DISPLAY_NAME) ? true : false,
				'DISPLAY_CAT_NAME'		=> ($row['cat_display'] != ARCADE_CAT_DISPLAY_IMAGE) ? true : false,
				'SUBCATS'				=> $s_subcats_list,
				'LAST_PLAY'				=> ($row['cat_last_play_game_id']) ? $this->last_play($cat_id, $row) : '',

				'L_SUBCAT_STR'			=> $l_subcats,

				'U_VIEWCAT'				=> $u_viewcat,

				// Use arcade style
				'CAT_RULES'				=> ($row['cat_rules']) ? generate_text_for_display($row['cat_rules'], $row['cat_rules_uid'], $row['cat_rules_bitfield'], $row['cat_rules_options']) : false,

				'U_CAT_RULES'			=> ($row['cat_rules_link']) ? $row['cat_rules_link'] : false
			));

			$this->template->assign_block_vars_array('catrow.subcat', $subcats_row);

			$last_catless = $catless;
		}

		$this->template->assign_vars(array(
			'S_ARCADE_CAT_BODY'			=> true,
			'S_ARCADE_CAT_STYLE_BASIC'	=> $arcade_style == ARCADE_CAT_STYLE_BASIC,
			'S_ARCADE_CAT_STYLE_ARCADE'	=> $arcade_style == ARCADE_CAT_STYLE_ARCADE,
			'S_HAS_SUBCAT'				=> ($visible_cats) ? true : false,
			'S_ARCADE_CAT_SIZE'			=> $this->arcade_config['arcade_cat_size'],

			'L_SUBCAT'					=> $this->user->lang['ARCADE_SUBCAT' . (($visible_cats > 1) ? 'S' : '')]
		));
	}

	private function last_play($cat_id, $game_ary)
	{
		$game_image		= ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($this->arcade->get()->game_field($game_ary['cat_last_play_game_id'], 'game_image'), 15, 15, 'x', 'play', $cat_id, $game_ary['cat_last_play_game_id']) . ' ' : '';
		$game_link		= $this->arcade->get()->game_name($game_ary['cat_last_play_game_name'], true, 'play', $cat_id, $game_ary['cat_last_play_game_id'], 'x');
		$player_link	= $this->arcade->get()->user_name('full', $game_ary['cat_last_play_user_id'], $game_ary['cat_last_play_username'], $game_ary['cat_last_play_user_colour'], 'arcade', 'x');
		$last_score		= (!$this->arcade->hidden_score($game_ary['cat_last_play_game_id'], $game_ary['cat_last_play_user_id'])) ? $this->arcade->number_format($game_ary['cat_last_play_score']) : $this->user->lang['HIDDEN'];

		return (($game_image) ? $game_image . ' ' : '') . $game_link . '<br>' . $this->user->lang['ARCADE_PLAYER'] . $this->user->lang['COLON'] . ' ' . $player_link . '<br>' . $this->user->lang['ARCADE_SCORE'] . $this->user->lang['COLON'] . ' ' . $last_score . '<br>' . $this->user->format_date($game_ary['cat_last_play_time']);
	}

	public function tour_news()
	{
		global $inc_tour;

		$time = time();
		$this->template->assign_var('S_IN_ARCADE_TOUR_NEWS', true);

		// 10 min/check
		if (empty($inc_tour) && ($_tour_check = $this->cache->get('_arcade_tour_check')) === false)
		{
			$_tour_check = $time;
			$this->arcade->container('tournament', true);
			$this->cache->put('_arcade_tour_check', $_tour_check, 600);
		}

		$start_tours = $end_tours = $game_ids = array();

		if ($this->arcade_config['tour_news_count_start'])
		{
			$sql = "SELECT tour_id, tour_name, tour_games, topic_id, reward_1, tour_status, tour_starttime, tour_endtime
					FROM " . ARCADE_TOUR_TABLE . '
					WHERE tour_status = ' . ARCADE_START_TOUR . '
					AND tour_endtime > ' . $time . '
					ORDER BY tour_time DESC';
			$result = $this->db->sql_query_limit($sql, intval($this->arcade_config['tour_news_count_start']));
			while ($row = $this->db->sql_fetchrow($result))
			{
				$start_tours[$row['tour_id']] = array(
					'tour_name'			=> $row['tour_name'],
					'game_ids'			=> array_map('intval', explode(',', $row['tour_games'])),
					'topic_id'			=> $row['topic_id'],
					'reward_1'			=> $row['reward_1'],
					'tour_status'		=> $row['tour_status'],
					'tour_starttime'	=> $row['tour_starttime'],
					'tour_endtime'		=> $row['tour_endtime']
				);
			}
			$this->db->sql_freeresult($result);
		}

		$lt_and = (count($start_tours)) ? ' AND ' . $this->db->sql_in_set('t.tour_id', array_keys($start_tours), true) : '';
		$max_display_time = intval($this->arcade_config['tour_news_max_display_day']) * 86400;
		$max_display_time = ($max_display_time > 0) ? $max_display_time : 0;

		if ($this->arcade_config['tour_news_count_end'] && count($this->arcade->tours()))
		{
			$sql = "SELECT t.tour_id, t.tour_name, t.tour_games, t.topic_id, t.reward_1, t.tour_status, t.tour_endtime,
						u.user_id, u.username, u.user_colour
					FROM " . ARCADE_TOUR_TABLE . ' t
					LEFT JOIN ' . USERS_TABLE . ' u ON t.tour_wins = u.user_id
					WHERE t.tour_status = ' . ARCADE_END_TOUR . "
					$lt_and
					" . (($max_display_time > 0) ? 'AND (t.tour_endtime + ' . $max_display_time . ') > ' . time() : '') . '
					ORDER BY t.tour_endtime DESC';
			$result = $this->db->sql_query_limit($sql, intval($this->arcade_config['tour_news_count_end']));
			while ($row = $this->db->sql_fetchrow($result))
			{
				$end_tours[$row['tour_id']] = array(
					'tour_name'		=> $row['tour_name'],
					'game_ids'		=> array_map('intval', explode(',', $row['tour_games'])),
					'topic_id'		=> $row['topic_id'],
					'reward_1'		=> $row['reward_1'],
					'tour_status'	=> $row['tour_status'],
					'tour_endtime'	=> $row['tour_endtime'],
					'user_id'		=> $row['user_id'],
					'username'		=> $row['username'],
					'user_colour'	=> $row['user_colour']
				);
			}
			$this->db->sql_freeresult($result);
		}

		$tours = array($start_tours, $end_tours);

		if (count($start_tours) || count($end_tours))
		{
			if ($this->arcade_config['tour_display_news_icons'] && $this->arcade_config['tour_news_icons_count'])
			{
				foreach ($tours as $tour)
				{
					foreach ($tour as $t_id => $row)
					{
						$game_ids = array_merge($game_ids, $row['game_ids']);
					}
				}

				$game_ids = array_unique($game_ids);

				$game_data = $this->arcade->get()->game_cat_data($game_ids, false, false, false, 0, true);
				$GLOBALS['arcade_skip_disable_img'] = true;

				$this->template->assign_var('S_ARCADE_TOUR_NEWS_ICONS', true);
			}

			$game_icons	= '';
			$icon_size	= intval(($this->arcade_config['tour_news_icons_size'] > 5) ? $this->arcade_config['tour_news_icons_size'] : 5);

			foreach ($tours as $tour)
			{
				foreach ($tour as $t_id => $row)
				{
					$game_icons = array();
					if ($this->arcade_config['tour_display_news_icons'] && $this->arcade_config['tour_news_icons_count'] && $game_data !== false)
					{
						foreach ($game_data as $game)
						{
							if (!in_array($game['game_id'], $row['game_ids']))
							{
								continue;
							}

							$title = sprintf($this->user->lang['ARCADE_GAME_PLAY'], $game['game_name']);
							$game_icons[] = str_replace('img_border"', 'img_border icon"', $this->arcade->get()->game_image($game['game_image'], $icon_size, $icon_size, $title, 'play', $game['cat_id'], $game['game_id']));

							if (count($game_icons) >= $this->arcade_config['tour_news_icons_count'])
							{
								break;
							}
						}
					}

					if ($row['tour_status'] == ARCADE_START_TOUR)
					{
						$date = $row['tour_starttime'];
						$name = $this->arcade->get()->tour_name($t_id, $row['tour_name'], 'x');

						if ($row['reward_1'] > 0 && $this->arcade->points()->data['installed'])
						{
							$msg = sprintf($this->user->lang['ARCADE_TOUR_NEWS_START_REWARD'], $row['tour_name'], $this->arcade->number_format((float) $row['reward_1']), $this->arcade->points()->data['name'], $this->user->format_date($row['tour_endtime'], false, true));
						}
						else
						{
							$msg = sprintf($this->user->lang['ARCADE_TOUR_NEWS_START'], $row['tour_name'], $this->user->format_date($row['tour_endtime'], false, true));
						}
					}
					else
					{
						$date = $row['tour_endtime'];
						$name = $this->arcade->get()->tour_name($t_id, $row['tour_name'], 'x', true);
						$win_username = ($row['user_id']) ? $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'tournament', 'x', false, $t_id) : false;

						if ($win_username)
						{
							if ($row['reward_1'] > 0 && $this->arcade->points()->data['installed'])
							{
								$msg = sprintf($this->user->lang['ARCADE_TOUR_NEWS_END_REWARD'], $row['tour_name'], $win_username, $this->arcade->number_format((float) $row['reward_1']), $this->arcade->points()->data['name']);
							}
							else
							{
								$msg = sprintf($this->user->lang['ARCADE_TOUR_NEWS_END'], $row['tour_name'], $win_username);
							}
						}
						else
						{
							$msg = sprintf($this->user->lang['ARCADE_TOUR_NEWS_END_NO_WIN'], $row['tour_name']);
						}
					}

					if (count($start_tours) && !isset($empty_line) && $row['tour_status'] != ARCADE_START_TOUR)
					{
						$empty_line = true;
						$this->template->assign_block_vars('tour_news', array());
					}

					$this->template->assign_block_vars('tour_news', array(
						'NAME'		=> $name,
						'DATE'		=> $this->user->format_date($date, false, true),
						'STATUS'	=> '<span class="arcade_' . (($row['tour_status'] == ARCADE_START_TOUR) ? 'green' : 'red') . '">' . $this->user->lang['ARCADE_' . (($row['tour_status'] == ARCADE_START_TOUR) ? 'ONGOING' : 'END')] . '</span>',
						'TOPIC'		=> ($row['topic_id']) ? '<a href="' . $this->arcade->url("t={$row['topic_id']}", 'viewtopic') . '" title="' . $this->user->lang['VIEW_TOPIC'] . '">[ ' . $this->user->lang['TOPIC'] . ' ]</a>' : false,
						'MSGS'		=> $msg,
						'ICONS'		=> ($this->arcade_config['tour_display_news_icons']) ? implode('', $game_icons) : ''
					));
				}
			}

			unset($game_data);
			unset($GLOBALS['arcade_skip_disable_img']);
		}
	}

	public function game_ranking($start)
	{
		$this->arcade->page_title('ARCADE_RANKING', '', 'mode=ranking');
		$this->main_box('arcade', $this->arcade_config['welcome_ranks'], $this->arcade_config['search_ranks']);

		$sql_array = array(
			'SELECT'	=> 'COUNT(au.user_id) AS total_data',
			'FROM'		=> array(ARCADE_USERS_TABLE	=> 'au'),
			'LEFT_JOIN'	=> array(
				array('FROM' => array(USERS_TABLE	=> 'u'), 'ON' => 'au.user_id = u.user_id')
			),
			'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
				AND au.user_id = u.user_id'
		);
		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		$total_data = (int) $this->db->sql_fetchfield('total_data');
		$this->db->sql_freeresult($result);

		if ($total_data)
		{
			$dary = array();
			$last_value = '';
			$pos = 0;
			$nov = $s_sort_key = $s_sort_dir = $u_sort_param = '';
			$this->arcade->valid_start($start, $total_data);
			$actual_rank = $start;

			$sort_key = $this->request->variable('sk', 'r');
			$sort_dir = $this->request->variable('sd', 'd');

			$sort_by_text = array('u' => $this->user->lang['USERNAME'], 'r' => $this->user->lang['ARCADE_RANK'], 't' => $this->user->lang['ARCADE_TROPHYS'], 'l' => $this->user->lang['ARCADE_LAST_PLAY']);
			$sort_by_sql = array('u' => 'u.username_clean', 'r' => 'au.user_arcade_rank', 't' => 'au.arcade_total_wins', 'l' => 'au.user_arcade_last_play');

			gen_sort_selects($dary, $sort_by_text, $nov, $sort_key, $sort_dir, $nov, $s_sort_key, $s_sort_dir, $u_sort_param);

			$sql_array = array(
				'SELECT'	=> 'au.arcade_total_wins, au.user_arcade_rank, au.user_arcade_last_play,
					u.user_id, u.username, u.username_clean, u.user_colour, u.user_avatar, u.user_avatar_type',
				'FROM'		=> array(ARCADE_USERS_TABLE => 'au'),
				'LEFT_JOIN'	=> array(
					array('FROM' => array(USERS_TABLE	=> 'u'), 'ON' => 'au.user_id = u.user_id'),
				),
				'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
					AND au.user_id = u.user_id'
			);

			$sql_array['ORDER_BY'] = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

			if ($sort_key == 'r')
			{
				$sql_array['ORDER_BY'] .= ', au.arcade_total_wins ' . (($sort_dir == 'd') ? 'DESC' : 'ASC') . ', u.username_clean ' . (($sort_dir == 'd') ? 'ASC' : 'DESC');
			}

			if ($sort_key == 't')
			{
				$sql_array['ORDER_BY'] .= ', u.username_clean ' . (($sort_dir == 'd') ? 'ASC' : 'DESC');
			}

			$i = 1;
			$sql = $this->db->sql_build_query('SELECT', $sql_array);
			$result = $this->db->sql_query_limit($sql, intval($this->arcade_config['stat_items_per_page']), $start);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$this->arcade->get()->actual_rank($actual_rank, $pos, (in_array($sort_key, array('r', 't'))) ? $row['arcade_total_wins'] : $i, $last_value, true);
				$arcade_rank = $this->arcade->get()->user_rank($row['user_arcade_rank'], $row['arcade_total_wins']);

				$this->template->assign_block_vars('ranking', array(
					'POS'			=> $pos,
					'AVATAR'		=> ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($row['user_avatar'], $row['user_avatar_type'], 20, 20, 'x', 'arcade', $row['user_id']) : false,
					'USERNAME'		=> $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'arcade', 'x'),
					'RANK_TITLE'	=> ($arcade_rank['rank_title']) ? $arcade_rank['rank_title'] : '-',
					'RANK_IMG'		=> $arcade_rank['rank_img'],
					'RANK_SRC'		=> $arcade_rank['rank_img_src'],
					'TOTAL_WINS'	=> ($row['arcade_total_wins']) ? $this->arcade->number_format($row['arcade_total_wins']) : '-',
					'LAST_PLAY'		=> ($row['user_arcade_last_play']) ? $this->user->format_date($row['user_arcade_last_play']) : '-'
				));

				$i++;
			}
			$this->db->sql_freeresult($result);

			$pagination = $this->container->get('pagination');
			$pagination->generate_template_pagination($this->arcade->url('mode=ranking' . (($u_sort_param) ? "&amp;$u_sort_param" : '')), 'pagination', 'start', $total_data, $this->arcade_config['stat_items_per_page'], $start);

			$this->template->assign_var('TOTAL_DATA', sprintf($this->user->lang['ARCADE_TOTAL_DATA'], $total_data));

			if ($s_sort_dir)
			{
				$this->template->assign_vars(array(
					'S_ARCADE_SELECT_SORT_DIR'	=> $s_sort_dir,
					'S_ARCADE_SELECT_SORT_KEY'	=> $s_sort_key,

					'U_ARCADE_STATS_ACTION'		=> $this->arcade->url('mode=ranking')
				));
			}
		}

		$this->page($this->arcade->lang_value($this->arcade->page_title), 'arcade/ranking_body.html');
	}

	public function cat_jumpbox($action, $cat_id = false, $select_all = false, $acl_list = false, $force_display = false)
	{
		// We only return if the jumpbox is not forced to be displayed (in case it is needed for functionality)
		if (!$this->arcade_config['load_jumpbox'] && $force_display === false)
		{
			return;
		}

		$sql = 'SELECT cat_id, cat_name, parent_id, cat_type, left_id, right_id
				FROM ' . ARCADE_CATS_TABLE . '
				ORDER BY left_id ASC';
		$result = $this->db->sql_query($sql, 600);

		$right = $padding = 0;
		$padding_store = array('0' => 0);
		$display_jumpbox = false;
		$iteration = 0;

		// Sometimes it could happen that forums will be displayed here not be displayed within the index page
		// This is the result of forums not displayed at index, having list permissions and a parent of a forum with no permissions.
		// If this happens, the padding could be "broken"

		while ($row = $this->db->sql_fetchrow($result))
		{
			if ($row['left_id'] < $right)
			{
				$padding++;
				$padding_store[$row['parent_id']] = $padding;
			}
			else if ($row['left_id'] > $right + 1)
			{
				// Ok, if the $padding_store for this parent is empty there is something wrong. For now we will skip over it.
				// @todo digging deep to find out "how" this can happen.
				$padding = (isset($padding_store[$row['parent_id']])) ? $padding_store[$row['parent_id']] : $padding;
			}

			$right = $row['right_id'];

			if ($row['cat_type'] == ARCADE_CAT && ($row['left_id'] + 1 == $row['right_id']))
			{
				// Non-postable forum with no subforums, don't display
				continue;
			}

			if (!$this->arcade_auth->acl_get('c_list', $row['cat_id']))
			{
				// if the user does not have permissions to list this forum skip
				continue;
			}

			if ($acl_list && !$this->arcade_auth->acl_gets($acl_list, $row['cat_id']))
			{
				continue;
			}

			$cat_link = $this->arcade->path_helper()->append_url_params($action, array('c' => $row['cat_id']));

			if (!$display_jumpbox)
			{
				$this->template->assign_block_vars('jumpbox_arcade', array(
					'CAT_ID'		=> ($select_all) ? 0 : -1,
					'CAT_NAME'		=> $this->user->lang['ARCADE_' . (($select_all) ? 'ALL_CATEGORIES' : 'SELECT_CATEGORY')],
					'S_CAT_COUNT'	=> $iteration,
					'LINK'			=> $cat_link
				));

				$iteration++;
				$display_jumpbox = true;
			}

			$this->template->assign_block_vars('jumpbox_arcade', array(
				'CAT_ID'			=> $row['cat_id'],
				'CAT_NAME'			=> $row['cat_name'],
				'SELECTED'			=> ($row['cat_id'] == $cat_id) ? ' selected="selected"' : '',
				'S_CAT_COUNT'		=> $iteration,
				'S_IS_CAT'			=> ($row['cat_type'] == ARCADE_CAT) ? true : false,
				'S_IS_LINK'			=> ($row['cat_type'] == ARCADE_LINK) ? true : false,
				'S_IS_CAT_GAMES'	=> ($row['cat_type'] == ARCADE_CAT_GAMES) ? true : false,
				'LINK'				=> $cat_link
			));

			for ($i = 0; $i < $padding; $i++)
			{
				$this->template->assign_block_vars('jumpbox_arcade.level', array());
			}

			$iteration++;
		}
		$this->db->sql_freeresult($result);
		unset($padding_store);

		$url_parts = $this->arcade->path_helper()->get_url_parts($action);

		$this->template->assign_vars(array(
			'S_DISPLAY_JUMPBOX'			=> $display_jumpbox,
			'S_JUMPBOX_ACTION'			=> $action,
			'HIDDEN_FIELDS_FOR_JUMPBOX'	=> build_hidden_fields($url_parts['params'])
		));
	}

	public function cat_rules(&$cat_data)
	{
		if (!$cat_data['cat_rules'] && !$cat_data['cat_rules_link'])
		{
			return;
		}

		if ($cat_data['cat_rules'])
		{
			$cat_data['cat_rules'] = generate_text_for_display($cat_data['cat_rules'], $cat_data['cat_rules_uid'], $cat_data['cat_rules_bitfield'], $cat_data['cat_rules_options']);
		}

		$this->template->assign_vars(array(
			'S_CAT_RULES'	=> true,
			'U_CAT_RULES'	=> $cat_data['cat_rules_link'],
			'CAT_RULES'		=> $cat_data['cat_rules']
		));
	}

	public function page($page_title, $html_body, $online = false, $page_footer = true)
	{
		$styles = array(
			$this->arcade->ext_path('jv/arcade', false) . 'styles',
			'styles'
		);

		$vars = array('styles');
		extract($this->arcade->phpbb_dispatcher()->trigger_event('jv.arcade.set_style', compact($vars)));

		// Output page
		page_header($page_title, $online);

		$styles_dir = array();
		foreach ($styles as $style)
		{
			if (is_dir($this->root_path . $style))
			{
				$styles_dir[] = $style;
			}
		}

		if (count($styles_dir))
		{
			$this->template->set_style($styles_dir);
		}

		$this->template->set_filenames(array(
			'body' => $html_body
		));

		if ($page_footer)
		{
			page_footer();
		}
	}
}
