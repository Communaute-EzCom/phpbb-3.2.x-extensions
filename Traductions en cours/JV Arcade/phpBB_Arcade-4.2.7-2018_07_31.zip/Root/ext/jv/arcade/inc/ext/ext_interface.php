<?php
/**
*
* @package phpBB Arcade
* @version $Id: ext_interface.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\ext;

interface ext_interface
{
	public function get_version();

	public function get_name();

	public function get_language();

	public function get_template_acp();
}
