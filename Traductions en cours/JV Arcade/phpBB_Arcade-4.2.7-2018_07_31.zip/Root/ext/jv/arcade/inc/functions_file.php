<?php
/**
*
* @package phpBB Arcade
* @version $Id: functions_file.php 2021 2018-06-24 12:10:08Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

/**
 * Useful class for directory and file actions
 */
class functions_file
{
	protected $db, $cache, $request;

	public function __construct($db, $cache, $request)
	{
		$this->db = $db;
		$this->cache = $cache;
		$this->request = $request;
	}

	public function write_file($file_path, $data, $empty_return = true)
	{
		if (!$data && $empty_return)
		{
			return false;
		}

		if (($fp = @fopen($file_path, 'wb')) !== false)
		{
			fwrite($fp, $data);
			fclose($fp);

			return true;
		}

		return false;
	}

	function delete_list($dirs)
	{
		if (!count($dirs))
		{
			return;
		}

		foreach ($dirs as $file)
		{
			if (is_dir($file))
			{
				$this->delete_dir($file);
			}
			else
			{
				$this->delete_file($file);
			}
		}
	}

	function copy_file($src_file, $dst_file)
	{
		return copy($src_file, $dst_file);
	}

	function delete_file($file)
	{
		if (in_array($file, array('.', '..')) || !file_exists($file) || !is_file($file))
		{
			return false;
		}

		return unlink($file);
	}

	function move_file($src_file, $dst_file)
	{
		$this->copy_file($src_file, $dst_file);
		$this->delete_file($src_file);
	}

	function copy_dir($src_dir, $dst_dir)
	{
		$this->append_slash($src_dir);
		$this->append_slash($dst_dir);

		if (!is_dir($dst_dir))
		{
			mkdir($dst_dir);
		}

		foreach (scandir($src_dir) as $file)
		{
			if (in_array($file, array('.', '..')))
			{
				continue;
			}

			$src_file = $src_dir . $file;
			$dst_file = $dst_dir . $file;

			if (is_file($src_file))
			{
				if (is_file($dst_file))
				{
					$ow = filemtime($src_file) - filemtime($dst_file);
				}
				else
				{
					$ow = 1;
				}

				if ($ow > 0)
				{
					if (copy($src_file, $dst_file))
					{
						@touch($dst_file, filemtime($src_file));
					}
				}
			}
			else if (is_dir($src_file))
			{
				$this->copy_dir($src_file, $dst_file);
			}
		}
	}

	//$empty, $ignore and $ignore_index only apply to the directory passed as $dir
	function delete_dir($dir, $empty = false, $ignore = '', $ignore_index = false)
	{
		$this->append_slash($dir);

		if (!file_exists($dir) || !is_dir($dir) || !is_readable($dir))
		{
			return false;
		}

		foreach (scandir($dir) as $file)
		{

			if (in_array($file, array('.', '..')) || preg_match('#\.' . $ignore . '$#i', $file))
			{
				continue;
			}

			if ($ignore_index && ($file == 'index.html' || $file == 'index.htm'))
			{
				continue;
			}

			if (is_dir($dir . $file))
			{
				$this->delete_dir($dir . $file);
			}
			else
			{
				$this->delete_file($dir . $file);
			}
		}

		if (!$empty)
		{
			@rmdir($dir);
		}

		return true;
	}

	function move_dir($src_dir, $dst_dir)
	{
		$this->copy_dir($src_dir, $dst_dir);
		$this->delete_dir($src_dir);
	}

	function delete_files($dir, $files_ary, $recursive = true)
	{
		$this->append_slash($dir);

		foreach (scandir($dir) as $file)
		{
			if (in_array($file, array('.', '..')))
			{
				continue;
			}

			if (is_dir($dir . $file))
			{
				if ($recursive)
				{
					$this->delete_files($dir . $file, $files_ary);
				}
			}

			if (in_array($file, $files_ary, true))
			{
				if (is_dir($dir . $file))
				{
					$this->delete_dir($dir . $file);
				}
				else
				{
					$this->delete_file($dir . $file);
				}
			}
		}
	}

	function append_slash(&$dir)
	{
		if ($dir != '' && $dir[strlen($dir) - 1] != '/')
		{
			$dir .= '/';
		}
	}

	function remove_extension($file)
	{
		$ext = strrchr($file, '.');
		while ($ext !== false)
		{
			$file = substr($file, 0, -strlen($ext));
			$ext = strrchr($file, '.');
		}

		return $file;
	}

	function trailing_slash(&$path)
	{
		// Adjust path (no trailing slash)
		if (substr($path, -1, 1) == '/' || substr($path, -1, 1) == '\\')
		{
			$path = substr($path, 0, -1) . '/';
		}

		$path = str_replace(array('../', '..\\', './', '.\\'), '', $path);

		if ($path && ($path[0] == '/' || $path[0] == '\\'))
		{
			$path = '';
		}
	}

	function filesize($files)
	{
		// Seperate files from directories and calculate the size
		$filesize = 0;
		$files = (!is_array($files)) ? array($files) : $files;

		$dir_list = $file_list = array();
		if (is_array($files))
		{
			foreach ($files as $file)
			{
				if (is_dir($file))
				{
					$dir_list[] = $file;
				}
				else if(file_exists($file))
				{
					$filesize += filesize($file);
				}
			}
		}
		unset($files);

		// If there are directories listed we need to list the files and get the file size
		if (!empty($dir_list))
		{
			foreach ($dir_list as $dir)
			{
				$file_list = array_merge($file_list, $this->filelist($dir));
			}
			unset($dir_list);

			foreach ($file_list as $file)
			{
				if (file_exists($file))
				{
					$filesize += filesize($file);
				}
			}
			unset ($file_list);
		}

		return $filesize;
	}

	function filelist($dir, $ignore = '', $ignore_index = true, $include_dir = false)
	{
		$list = array();
		$this->append_slash($dir);

		if (!$dir || !file_exists($dir))
		{
			return $list;
		}

		if ($files = scandir($dir))
		{
			if ($include_dir)
			{
				$list[] = $dir;
			}

			foreach ($files as $file)
			{
				if (in_array($file, array('.', '..')) || preg_match('#\.' . $ignore . '$#i', $file))
				{
					continue;
				}

				if ($ignore_index && ($file == 'index.html' || $file == 'index.htm'))
				{
					continue;
				}

				if (is_dir($dir . $file))
				{
					if ($include_dir)
					{
						$this->append_slash($file);
						$list[] = $dir . $file;
					}

					$list = array_merge($list, $this->filelist($dir . $file, $ignore, $ignore_index));
				}
				else
				{
					$list[] = $dir . $file;
				}
			}
		}

		return $list;
	}

	function xml2array($url, $get_attributes = 1, $priority = 'tag')
	{
		$contents = "";

		if (!function_exists('xml_parser_create'))
		{
			return array ();
		}

		$parser = xml_parser_create('');

		if (!($fp = @fopen($url, 'rb')))
		{
			return array();
		}

		while (!feof($fp))
		{
			$contents .= fread($fp, 8192);
		}

		fclose($fp);
		xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8");
		xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, trim($contents), $xml_values);
		xml_parser_free($parser);

		if (!$xml_values)
		{
			return;
		}

		$xml_array = $parents = $opened_tags = $arr = $repeated_tag_index = array();
		$current = & $xml_array;

		foreach ($xml_values as $data)
		{
			unset ($attributes, $value);
			extract($data);
			$result = array ();
			$attributes_data = array ();

			if (isset ($value))
			{
				if ($priority == 'tag')
				{
					$result = $value;
				}
				else
				{
					$result['value'] = $value;
				}
			}

			if (isset($attributes) && $get_attributes)
			{
				foreach ($attributes as $attr => $val)
				{
					if ($priority == 'tag')
					{
						$attributes_data[$attr] = $val;
					}
					else
					{
						$result['attr'][$attr] = $val;
					}
				}
			}
			if ($type == "open")
			{
				$parent[$level -1] = & $current;
				if (!is_array($current) || (!in_array($tag, array_keys($current))))
				{
					$current[$tag] = $result;
					if ($attributes_data)
					{
						$current[$tag . '_attr'] = $attributes_data;
					}
					$repeated_tag_index[$tag . '_' . $level] = 1;
					$current = & $current[$tag];
				}
				else
				{
					if (isset ($current[$tag][0]))
					{
						$current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
						$repeated_tag_index[$tag . '_' . $level]++;
					}
					else
					{
						$current[$tag] = array($current[$tag], $result);
						$repeated_tag_index[$tag . '_' . $level] = 2;
						if (isset ($current[$tag . '_attr']))
						{
							$current[$tag]['0_attr'] = $current[$tag . '_attr'];
							unset ($current[$tag . '_attr']);
						}
					}
					$last_item_index = $repeated_tag_index[$tag . '_' . $level] - 1;
					$current = & $current[$tag][$last_item_index];
				}
			}
			elseif ($type == "complete")
			{
				if (!isset ($current[$tag]))
				{
					$current[$tag] = $result;
					$repeated_tag_index[$tag . '_' . $level] = 1;
					if ($priority == 'tag' && $attributes_data)
					{
						$current[$tag . '_attr'] = $attributes_data;
					}
				}
				else
				{
					if (isset ($current[$tag][0]) && is_array($current[$tag]))
					{
						$current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
						if ($priority == 'tag' && $get_attributes && $attributes_data)
						{
							$current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
						}
						$repeated_tag_index[$tag . '_' . $level]++;
					}
					else
					{
						$current[$tag] = array ($current[$tag], $result);
						$repeated_tag_index[$tag . '_' . $level] = 1;
						if ($priority == 'tag' && $get_attributes)
						{
							if (isset ($current[$tag . '_attr']))
							{
								$current[$tag]['0_attr'] = $current[$tag . '_attr'];
								unset ($current[$tag . '_attr']);
							}
							if ($attributes_data)
							{
								$current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
							}
						}
						$repeated_tag_index[$tag . '_' . $level]++;
					}
				}
			}
			elseif ($type == 'close')
			{
				$current = & $parent[$level -1];
			}
		}
		return ($xml_array);
	}

	function mime_type($method)
	{
		switch ($method)
		{
			case '.tar':
				$mimetype = 'application/x-tar';
			break;

			case '.tar.gz':
				$mimetype = 'application/x-gzip';
			break;

			case '.tar.bz2':
				$mimetype = 'application/x-bzip2';
			break;

			case '.zip':
				$mimetype = 'application/zip';
			break;

			default:
				$mimetype = 'application/octet-stream';
			break;
		}

		return $mimetype;
	}

	function header_filename($file)
	{
		$user_agent = $this->request->header('User-Agent');

		// There be dragons here.
		// Not many follows the RFC...
		if (strpos($user_agent, 'MSIE') !== false || strpos($user_agent, 'Konqueror') !== false)
		{
			return "filename=" . rawurlencode($file);
		}

		// follow the RFC for extended filename for the rest
		return "filename*=UTF-8''" . rawurlencode($file);
	}

	function set_modified_headers($stamp, $browser)
	{
		// let's see if we have to send the file at all
		$last_load =  $this->request->header('Modified-Since') ? strtotime(trim($this->request->header('Modified-Since'))) : false;

		if (strpos(strtolower($browser), 'msie 6.0') === false && !$this->is_greater_ie_version($browser, 7))
		{
			if ($last_load !== false && $last_load >= $stamp)
			{
				send_status_line(304, 'Not Modified');
				// seems that we need those too ... browsers
				header('Cache-Control: public');
				header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
				return true;
			}
			else
			{
				header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $stamp) . ' GMT');
			}
		}
		return false;
	}

	function file_gc($exit = true)
	{
		if (!empty($this->cache))
		{
			$this->cache->unload();
		}

		$this->db->sql_close();

		if ($exit)
		{
			exit;
		}
	}

	function is_greater_ie_version($user_agent, $version)
	{
		if (preg_match('/msie (\d+)/', strtolower($user_agent), $matches))
		{
			$ie_version = (int) $matches[1];
			return ($ie_version > $version);
		}
		else
		{
			return false;
		}
	}
}
