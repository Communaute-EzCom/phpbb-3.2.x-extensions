<?php
/**
*
* @package phpBB Arcade
* @version $Id: tournament.php 2028 2018-07-02 10:44:15Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class tournament
{
	protected $db, $cache, $auth, $request, $user, $template, $arcade_config, $arcade_auth, $arcade;

	public function __construct($db, $cache, $auth, $request, $user, $template, $arcade_config, $arcade_auth, $arcade)
	{
		$this->db = $db;
		$this->cache = $cache;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
	}

	public function main($in_tour = false, $tpl = false, $tour_id = false, $type = false, $display_main_box = false)
	{
		$total_data		= 0;
		$time			= time();
		$start			= (int) $this->request->variable('start', 0);
		$tour_final		= ($tour_id && $type == 'final' || !$type && $tour_id && $this->arcade->get()->tour_field($tour_id, 'tour_status') == ARCADE_END_TOUR) ? true : false;
		$tours_final	= (!$tour_id && $type == 'final') ? true : false;
		$start_tour_ids	= $end_tour_ids = $tour_data = array();
		$v_status		= ($tour_final || $tours_final) ? '=' : '<>';

		if ($tours_final)
		{
			$total_data = $this->arcade->get()->total('game', 'total_tours', true);
			$this->arcade->valid_start($start, $total_data);
		}

		if ($tour_id)
		{
			$sql = 'SELECT t.*, tc.game_id, tc.score, tc.score_date, tc.total_plays, tc.total_time,
						u.user_id, u.username, u.user_colour, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height
					FROM ' . ARCADE_TOUR_TABLE . ' t
					LEFT JOIN ' . ARCADE_TOUR_CHAMP_TABLE . ' tc ON t.tour_id = tc.tour_id
					LEFT JOIN ' . USERS_TABLE . " u ON tc.user_id = u.user_id
					WHERE t.tour_status $v_status " . ARCADE_END_TOUR . "
					AND t.tour_id = $tour_id
					ORDER BY tc.score ASC, tc.score_date ASC";
		}
		else
		{
			if ($in_tour)
			{
				$extra_columns	= ($tours_final) ? ', u.user_id, u.username, u.user_colour' : '';
				$left_join		= ($tours_final) ? ' LEFT JOIN ' . USERS_TABLE . ' u ON t.tour_wins = u.user_id' : '';

				if ($this->db->get_sql_layer() === 'sqlite3')
				{
					$sql = "SELECT COUNT(tc.user_id) AS total_users, t.tour_id, t.tour_name, t.tour_games, t.tour_groups, t.play_max, t.reward_1, t.reward_2, t.reward_3, t.post_id, t.tour_status, t.tour_starttime, t.tour_endtime $extra_columns
							FROM (
								SELECT DISTINCT tc.user_id, t.tour_id, t.tour_name, t.tour_games, t.tour_groups, t.play_max, t.reward_1, t.reward_2, t.reward_3, t.post_id, t.tour_status, t.tour_starttime, t.tour_endtime $extra_columns
								FROM " . ARCADE_TOUR_TABLE . " t
								LEFT JOIN " . ARCADE_TOUR_CHAMP_TABLE . " tc ON t.tour_id = tc.tour_id AND tc.score_date > 0
								$left_join
								WHERE t.tour_status $v_status " . ARCADE_END_TOUR . "
								GROUP BY t.tour_id, t.tour_name, t.tour_games, t.tour_groups, t.play_max, t.reward_1, t.reward_2, t.reward_3, t.post_id, t.tour_status, t.tour_starttime, t.tour_endtime $extra_columns
								ORDER BY t.tour_status DESC, t.tour_endtime " . (($tours_final) ? 'DESC' : 'ASC') . ", t.tour_id ASC
							)";
							/* , tc.score ASC, tc.score_date ASC */
				}
				else
				{
					$sql = "SELECT COUNT(DISTINCT tc.user_id) AS total_users, t.tour_id, t.tour_name, t.tour_games, t.tour_groups, t.play_max, t.reward_1, t.reward_2, t.reward_3, t.post_id, t.tour_status, t.tour_starttime, t.tour_endtime $extra_columns
							FROM " . ARCADE_TOUR_TABLE . " t
							LEFT JOIN " . ARCADE_TOUR_CHAMP_TABLE . " tc ON t.tour_id = tc.tour_id AND tc.score_date > 0
							$left_join
							WHERE t.tour_status $v_status " . ARCADE_END_TOUR . "
							GROUP BY t.tour_id, t.tour_name, t.tour_games, t.tour_groups, t.play_max, t.reward_1, t.reward_2, t.reward_3, t.post_id, t.tour_status, t.tour_starttime, t.tour_endtime $extra_columns
							ORDER BY t.tour_status DESC, t.tour_endtime " . (($tours_final) ? 'DESC' : 'ASC') . ", t.tour_id ASC";
							/* , tc.score ASC, tc.score_date ASC */
				}
			}
			else
			{
				$sql = 'SELECT t.tour_id, t.tour_name, t.tour_games, t.tour_groups, t.play_max, t.reward_1, t.reward_2, t.reward_3, t.post_id, t.tour_status, t.tour_starttime, t.tour_endtime
						FROM ' . ARCADE_TOUR_TABLE . " t
						WHERE t.tour_status $v_status " . ARCADE_END_TOUR . '
						ORDER BY t.tour_status DESC, t.tour_endtime ASC';
			}
		}

		if ($tours_final)
		{
			$result = $this->db->sql_query_limit($sql, $this->arcade_config['games_per_page'], $start);
		}
		else
		{
			$result = $this->db->sql_query($sql);
		}

		while ($row = $this->db->sql_fetchrow($result))
		{
			if ($row['tour_endtime'] <= $time)
			{
				if (!$tour_final && !$tours_final)
				{
					$end_tour_ids[] = $row['tour_id'];
					continue;
				}
			}
			else if ($row['tour_starttime'] <= $time && $row['tour_status'] == ARCADE_WAIT_TOUR)
			{
				$start_tour_ids[] = $row['tour_id'];
				$row['tour_status'] = ARCADE_START_TOUR;
			}

			if ($tpl)
			{
				if (!isset($tour_data[$row['tour_id']]))
				{
					$tour_data[$row['tour_id']] = array(
						'name'			=> (string) $row['tour_name'],
						'game_ids'		=> array_map('intval', explode(',', $row['tour_games'])),
						'group_ids'		=> array_map('intval', explode(',', $row['tour_groups'])),
						'play_max'		=> (int) $row['play_max'],
						'reward_1'		=> (float) $row['reward_1'],
						'reward_2'		=> (float) $row['reward_2'],
						'reward_3'		=> (float) $row['reward_3'],
						'post_id'		=> (int) $row['post_id'],
						'status'		=> (int) $row['tour_status'],
						'starttime'		=> (int) $row['tour_starttime'],
						'endtime'		=> (int) $row['tour_endtime'],
						'total_users'	=> (isset($row['total_users'])) ? $row['total_users'] : 0,
						'ug'			=> array()
					);

					if ($tours_final && !empty($row['user_id']))
					{
						$tour_data[$row['tour_id']] += array(
							'user_id'				=> $row['user_id'],
							'username'				=> $row['username'],
							'user_colour'			=> $row['user_colour']
						);
					}
				}

				if ($tour_id)
				{
					$tour_data[$row['tour_id']]['ug'][] = array(
						'game_id'				=> $row['game_id'],
						'user_id'				=> $row['user_id'],
						'username'				=> $row['username'],
						'user_colour'			=> $row['user_colour'],
						'user_avatar_type'		=> $row['user_avatar_type'],
						'user_avatar'			=> $row['user_avatar'],
						'user_avatar_width'		=> $row['user_avatar_width'],
						'user_avatar_height'	=> $row['user_avatar_height'],
						'score'					=> $row['score'],
						'score_date'			=> $row['score_date'],
						'total_plays'			=> $row['total_plays'],
						'total_time'			=> $row['total_time']
					);
				}
			}
		}
		$this->db->sql_freeresult($result);

		if ($tour_id && $tpl && !count($tour_data))
		{
			trigger_error(sprintf($this->user->lang['NO_TOUR_ID']) . $this->arcade->back_link('mode=tournament', 'tour'));
		}

		if (count($start_tour_ids))
		{
			$this->update_status($start_tour_ids, ARCADE_START_TOUR);
		}

		if (count($end_tour_ids))
		{
			$this->update_status($end_tour_ids);
		}

		if ($tpl)
		{
			$this->display($type, $tour_data, $tour_id, $total_data, $start);
		}

		if ($in_tour)
		{
			$this->template->assign_var('S_IN_ARCADE_TOURNAMENT', true);
		}

		if ($display_main_box)
		{
			$this->arcade->display()->main_box('tournament', $this->arcade_config['tour_welcome_index']);
		}
	}

	public function update_status($tour_ids, $status = ARCADE_END_TOUR)
	{
		$tour_ids = array_map('intval', (is_array($tour_ids)) ? array_unique($tour_ids) : array($tour_ids));

		if (count($tour_ids))
		{
			$sql = 'UPDATE ' . ARCADE_TOUR_TABLE . '
					SET tour_status = ' . (int) $status . '
					WHERE ' . $this->db->sql_in_set('tour_id', $tour_ids);
			$this->db->sql_query($sql);

			if ($status == ARCADE_END_TOUR)
			{
				$this->close($tour_ids);

				$this->cache->destroy('sql', ARCADE_TOUR_CHAMP_TABLE);
				$this->cache->destroy('_arcade_tour_leaders');
				$this->cache->destroy('_arcade_tour_leaders_all');
			}

			$this->cache->destroy('_arcade_tours');
			$this->cache->destroy('_arcade_tour_check');
		}
	}

	public function display($type, $tour_data, $tour_id = false, $total_data = 0, $start = 0)
	{
		$tour = 0;
		$tour_final  = ($tour_id && $type == 'final') ? true : false;
		$tours_final = (!$tour_id && $type == 'final') ? true : false;
		$group_helper = $this->arcade->container('phpbb_group_helper');

		if ($tours_final)
		{
			$GLOBALS['arcade_skip_disable_img'] = true;

			$this->arcade->container('phpbb_pagination')->generate_template_pagination($this->arcade->url('mode=tournament&amp;type=final'), 'pagination', 'start', $total_data, $this->arcade_config['games_per_page'], $start);

			$this->template->assign_vars(array(
				'S_DISPLAY_ARCADE_END_TOURS'	=> true,
				'TOTAL_DATA'					=> sprintf($this->user->lang['ARCADE_TOTAL_DATA'], $total_data)
			));
		}

		if (!empty($tour_data))
		{
			if ($tour_id && !isset($tour_data[$tour_id]['name']))
			{
				trigger_error(sprintf($this->user->lang['ARCADE_TOUR_ID_ERROR'], $tour_id), E_USER_ERROR);
			}

			$game_ids = $group_ids = array();
			foreach ($tour_data as $t_id => $row)
			{
				$game_ids	= array_merge($game_ids, $row['game_ids']);
				$group_ids	= array_merge($group_ids, $row['group_ids']);
			}

			$game_ids	= array_unique($game_ids);
			$group_ids	= array_unique($group_ids);

			if (count($game_ids) && count($group_ids))
			{
				$game_data	= $this->arcade->get()->game_cat_data($game_ids, false, false, false, 0, true);
				$group_data	= $this->arcade->get()->group_data($group_ids);
				$users_list	= ($tour_final || $type == 'rank') ? true : false;

				if ($game_data !== false && count($group_data))
				{
					$users_data = array();
					$own_has_play = $this->arcade->phpbb()->group_memberships($group_ids, $this->user->data['user_id'], true);

					if (!$own_has_play)
					{
						$GLOBALS['arcade_skip_active_link'] = true;
					}

					foreach ($tour_data as $t_id => $row)
					{
						$tour++;

						if ($tour_id)
						{
							$last_score_type = null;
							foreach ($game_data as $game)
							{
								$own_rank = $actual_rank = $rank = $last_value = $total_plays = 0;
								$highscore_username	= $highscore = $highscore_time = $personal_score = $personal_time = '';
								$high_score_type	= ($game['game_scoretype'] == SCORETYPE_HIGH) ? true : false;

								if ($last_score_type !== $high_score_type)
								{
									$last_score_type = $high_score_type;
									$this->arcade->array_column_sort($row['ug'], 'score', ($high_score_type) ? 'd' : 'a');
								}

								foreach ($row['ug'] as $ug)
								{
									if ($game['game_id'] != $ug['game_id'] || ($users_list && !$ug['score_date']))
									{
										continue;
									}

									if ($users_list)
									{
										if (!isset($users_data[$ug['user_id']]))
										{
											$users_data[$ug['user_id']] = array(
												'user_id'				=> $ug['user_id'],
												'username'				=> $ug['username'],
												'user_colour'			=> $ug['user_colour'],
												'user_avatar_type'		=> $ug['user_avatar_type'],
												'user_avatar'			=> $ug['user_avatar'],
												'user_avatar_width'		=> $ug['user_avatar_width'],
												'user_avatar_height'	=> $ug['user_avatar_height'],
											);
										}

										$users_data[$ug['user_id']]['first_places'] = (!isset($users_data[$ug['user_id']]['first_places'])) ? 1 : $users_data[$ug['user_id']]['first_places'] + 1;
										$users_data[$ug['user_id']]['games'][$game['game_id']] = $this->arcade->get()->game_name($game['game_name'], true, ($tour_final) ? 'tournament' : 'play', $game['cat_id'], $game['game_id'], 'x', false, false, false, false, ($tour_final) ? $t_id : false);
/*
										if ($tour_final)
										{
											$users_data[$ug['user_id']]['games'][$game['game_id']] .= ' (' . $this->user->format_date($ug['score_date'], false, true) . ')';
										}
*/
										break;
									}
									else
									{
										if ($ug['score_date'])
										{
											$this->arcade->get()->actual_rank($actual_rank, $rank, $ug['score'], $last_value);

											if ($ug['user_id'] == $this->user->data['user_id'])
											{
												// own_rank use actual rang num.
												$own_rank		= $actual_rank;
												$personal_score	= $this->arcade->number_format($ug['score']);
												$personal_time	= $this->user->format_date($ug['score_date']);
											}

											if (!$highscore)
											{
												$highscore			= $this->arcade->number_format($ug['score']);
												$highscore_time		= $this->user->format_date($ug['score_date']);
												$highscore_username	= $this->arcade->get()->user_name('full', $ug['user_id'], $ug['username'], $ug['user_colour'], 'tournament', 'x');
											}
										}

										if ($ug['user_id'] == $this->user->data['user_id'])
										{
											$total_plays = $ug['total_plays'];
										}
									}
								}

								if (!$users_list)
								{
									$this->template->assign_block_vars('tour_games', array(
										'S_GAME_PLAY'			=> ((!$row['play_max'] || $row['play_max'] > $total_plays) && !$this->arcade->get()->cat_locked($game['cat_id']) && $own_has_play && $this->arcade_auth->acl_get('c_play', $game['cat_id'])) ? true : false,
										'GAME_IMAGE'			=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($game['game_image'], 20, 20, 'x', 'play', $game['cat_id'], $game['game_id']) : false,
										'GAME_POPUP'			=> ($this->arcade->optionget('view_popup_icon')) ? $this->arcade->get()->game_popup('icon', $game['cat_id'], $game['game_id'], $game['game_width'], $game['game_height'], 'x') : false,
										'GAME_NAME'				=> $this->arcade->get()->game_name($game['game_name'], true, 'play', $game['cat_id'], $game['game_id'], 'x'),
										'GAME_CAT'				=> $this->arcade->get()->cat_name($game['cat_name'], $game['cat_id'], $game['game_id'], 'x'),
										'GAME_PLAY'				=> '<a href="' . $this->arcade->url("mode=play&amp;g={$game['game_id']}") . '">' . $this->user->lang['ARCADE_CLICK_PLAY'] . '</a>',

										'HIGHSCORE_USERNAME'	=> $highscore_username,
										'HIGHSCORE'				=> $highscore,
										'HIGHSCORE_TIME'		=> $highscore_time,
										'PERSONAL_BEST'			=> $personal_score,
										'PERSONAL_BEST_TIME'	=> $personal_time,
										'PERSONAL_RANK'			=> ($own_rank) ? (($own_rank < 4) ? $this->arcade->get()->leaders_image($own_rank) : "$own_rank.") : '-',
										'PLAY_PLAYED'			=> ($row['play_max']) ? sprintf($this->user->lang['ARCADE_REP_VAL_VAL'], $total_plays, $row['play_max']) : $this->user->lang['ARCADE_INFINITE']
									));
								}
							}

							if ($users_list && count($users_data))
							{
								$this->arcade->array_column_sort($users_data, 'first_places');

								foreach ($users_data as $key => $user_data)
								{
									$this->arcade->get()->actual_rank($actual_rank, $rank, $user_data['first_places'], $last_value);

									$this->template->assign_block_vars('tour_users', array(
										'RANK'			=> $rank,
										'AVATAR'		=> ($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($user_data['user_avatar'], $user_data['user_avatar_type'], 20, 20, 'x', 'tournament', $user_data['user_id'], ($tour_final) ? $t_id : false) : false,
										'USERNAME'		=> $this->arcade->get()->user_name('full', $user_data['user_id'], $user_data['username'], $user_data['user_colour'], 'tournament', 'x', false, ($tour_final) ? $t_id : false),
										'FIRST_PLACES'	=> $user_data['first_places'],
										'GAMES'			=> implode(', ', $user_data['games'])
									));
								}
							}
						}
						else
						{
							if ($tours_final)
							{
								$this->template->assign_block_vars('tours', array(
									'TOUR_NAME'		=> $this->arcade->get()->tour_name($t_id, $row['name'], 'x', true),
									'TOUR_END'		=> $this->user->format_date($row['endtime'], false, true),
									'WINNER'		=> (!empty($row['user_id'])) ? $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'tournament', 'x', false, $t_id) : '-',
									'TOPIC'			=> ($row['post_id']) ? '<a href="' . $this->arcade->url("p={$row['post_id']}#p{$row['post_id']}", 'viewtopic') . '" title="' . $this->user->lang['VIEW_TOPIC'] . '">[ ' . $this->user->lang['TOPIC'] . ' ]</a>' : false,
									'USERS'			=> $row['total_users']
								));
							}
							else
							{
								if ($this->arcade->points()->data['installed'])
								{
									$reward = $this->user->lang['ARCADE_NONE'];

									if ($row['reward_1'] > 0)
									{
										$reward = sprintf($this->user->lang['ARCADE_TOUR_MSG_REWARD_1'], $this->arcade->number_format((float) $row['reward_1']), $this->arcade->points()->data['name']);

										if ($row['reward_2'] > 0)
										{
											$reward .= '<br>' . sprintf($this->user->lang['ARCADE_TOUR_MSG_REWARD_2'], $this->arcade->number_format((float) $row['reward_2']), $this->arcade->points()->data['name']);
										}

										if ($row['reward_3'] > 0)
										{
											$reward .= '<br>' . sprintf($this->user->lang['ARCADE_TOUR_MSG_REWARD_3'], $this->arcade->number_format((float) $row['reward_3']), $this->arcade->points()->data['name']);
										}
									}
								}

								$this->template->assign_block_vars('tours', array(
									'TOUR_NAME'		=> $this->arcade->get()->tour_name($t_id, $row['name'], 'x'),
									'TOUR_START'	=> $this->user->format_date($row['starttime'], false, true),
									'TOUR_END'		=> $this->user->format_date($row['endtime'], false, true),
									'TOPIC'			=> ($row['post_id']) ? '<a href="' . $this->arcade->url("p={$row['post_id']}#p{$row['post_id']}", 'viewtopic') . '" title="' . $this->user->lang['VIEW_TOPIC'] . '">[ ' . $this->user->lang['TOPIC'] . ' ]</a>' : false,
									'PLAYS'			=> sprintf($this->user->lang['ARCADE_REPLAYS_GAME'], '<strong>(' . (($row['play_max'] > 0) ? $this->arcade->number_format($row['play_max']) : $this->user->lang['ARCADE_INFINITE']) . ')</strong>'),
									'STATUS'		=> $this->user->lang['ARCADE_' . (($row['status'] == ARCADE_WAIT_TOUR) ? 'WAIT' : 'ONGOING')],
									'USERS'			=> $row['total_users'],
									'REWARD'		=> (!empty($reward)) ? $reward : '',
									'RANK'			=> ($row['total_users']) ? '<a href="' . $this->arcade->url("mode=tournament&amp;tour_id=$t_id&amp;type=rank") . '" title="' . $this->user->lang['ARCADE_VIEW_ACTUAL_RANK'] . '">' . $this->user->lang['CLICK'] . '</a>' : '-'
								));
							}

							foreach ($group_data as $group_id => $group)
							{
								if (!in_array($group_id, $row['group_ids']))
								{
									continue;
								}

								$group_name = $group_helper->get_name($group['group_name']);

								$name = ($group['group_type'] == GROUP_SPECIAL) ? '<b>' . $group_name . '</b>' : $group_name;
								$name = ($group['group_colour']) ? '<span style="color: #' . $group['group_colour'] . '">' . $name . '</span>' : $name;

								$this->template->assign_block_vars('tours.groups', array(
									'GROUP_NAME' => ($this->auth->acl_get('u_viewprofile')) ? '<a href="' . $this->arcade->url("mode=group&amp;g=$group_id", 'memberlist') . '">' . $name . '</a>' : $name
								));
							}

							$gc = 0;
							foreach ($game_data as $game)
							{
								if (!in_array($game['game_id'], $row['game_ids']))
								{
									continue;
								}

								$this->template->assign_block_vars('tours.games', array(
									'GAME_POPUP'	=> ($this->arcade->optionget('view_popup_icon')) ? $this->arcade->get()->game_popup('icon', $game['cat_id'], $game['game_id'], $game['game_width'], $game['game_height'], 'x') : false,
									'GAME_NAME'		=> $this->arcade->get()->game_name($game['game_name'], true, 'play', $game['cat_id'], $game['game_id'], 'x'),
									'GAME_CAT'		=> $this->arcade->get()->cat_name($game['cat_name'], $game['cat_id'], $game['game_id'], 'x')
								));
							}
						}
					}

					unset($GLOBALS['arcade_skip_active_link']);

					if ($tour_id)
					{
						if ($users_list)
						{
							$param_value = ($tour_final) ? 'final' : 'rank';
							$title_value = 'ARCADE_' . (($tour_final) ? 'FINAL' : 'ACTUAL') . '_RANKING';
							$this->arcade->page_title($title_value, $tour_data[$tour_id]['name']);
							$this->arcade->add_navlink('add', "mode=tournament&amp;tour_id=$tour_id", $tour_data[$tour_id]['name']);
							$this->arcade->add_navlink('add', "mode=tournament&amp;tour_id=$tour_id&amp;type=$param_value", $title_value);

							$this->template->assign_vars(array(
								'S_DISPLAY_ARCADE_TOUR_USERS'	=> true,

								'L_ARCADE_TOUR_TITLE'			=> $tour_data[$tour_id]['name'] . ' / ' . $this->user->lang[$title_value]
							));
						}
						else
						{
							$this->arcade->page_title($tour_data[$tour_id]['name'], '', "mode=tournament&amp;tour_id=$tour_id");

							$this->template->assign_vars(array(
								'S_DISPLAY_ARCADE_TOUR'		=> true,

								'L_ARCADE_PLAY_PLAYED'		=> sprintf($this->user->lang['ARCADE_REP_VAL_VAL'], $this->user->lang['ARCADE_PLAYED'], $this->user->lang['ARCADE_CAN_PLAY']),
								'L_ARCADE_TOUR_TITLE'		=> $tour_data[$tour_id]['name']
							));
						}
					}
					else if ($tours_final)
					{
						unset($GLOBALS['arcade_skip_disable_img']);
						$this->arcade->page_title = 'ARCADE_FINISHED_TOUR' . (($tour > 1) ? 'S' : '');
						$this->arcade->add_navlink('add', 'mode=tournament&amp;type=final', $this->arcade->page_title);
					}
				}
			}
		}

		if (!$tour_id)
		{
			$this->template->assign_vars(array(
				'S_DISPLAY_ARCADE_TOURS'	=> true,
				'S_TOUR_REWARD'				=> (!empty($reward)) ? true : false,

				'L_ARCADE_TOUR_TITLE'		=> $this->user->lang[(($tours_final) ? 'ARCADE_FINISHED_TOUR' . (($tour > 1) ? 'S' : '') : 'TOURNAMENT' . (($tour > 1) ? 'S' : ''))]
			));
		}
	}

	public function check($game_id, $high_score_type = null, $score = 0, $current_time = 0, $total_time = 0)
	{
		if (!$game_id)
		{
			return false;
		}

		$return			= false;
		$game_id		= (int) $game_id;
		$tour_data		= $group_ids = array();
		$user_id		= (int) $this->user->data['user_id'];
		$current_time	= intval(($current_time) ? $current_time : time());
		$total_time		= intval(($total_time > 0) ? $total_time : 0);

		$sql = 'SELECT t.tour_id, t.tour_groups, t.tour_games, t.play_max, tc.total_plays, tc.score, tc.score_date
				FROM ' . ARCADE_TOUR_TABLE . ' t
				LEFT JOIN ' . ARCADE_TOUR_CHAMP_TABLE . " tc ON t.tour_id = tc.tour_id AND tc.user_id = $user_id AND tc.game_id = $game_id
				WHERE t.tour_status = " . ARCADE_START_TOUR;
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			if (in_array($game_id, explode(',', $row['tour_games'])))
			{
				$return = ($high_score_type !== null) ? true : false;

				if (!empty($row['play_max']) && !empty($row['total_plays']) &&
					(($high_score_type === null && $row['total_plays'] == $row['play_max']) ||
					$high_score_type !== null && $row['total_plays'] == $row['play_max'] && $row['score_date']))
				{
					continue;
				}

				$tour_data[$row['tour_id']] = array(
					'score'			=> $row['score'],
					'total_plays'	=> $row['total_plays']
				);

				$group_ids = array_merge($group_ids, array_map('intval', explode(',', $row['tour_groups'])));
			}
		}
		$this->db->sql_freeresult($result);

		$group_ids = array_unique($group_ids);

		if (count($tour_data) && count($group_ids))
		{
			if ($this->arcade->phpbb()->group_memberships($group_ids, $user_id, true))
			{
				$cache_purge = false;
				foreach ($tour_data as $tour_id => $row)
				{
					if ($row['total_plays'])
					{
						$sql_ary = array();
						if ($high_score_type !== null)
						{
							$save_score = ($score > 0 && (($row['score'] == 0) || ($high_score_type && $row['score'] < $score) || (!$high_score_type && $row['score'] > $score))) ? true : false;

							if ($save_score)
							{
								$sql_ary = array(
									'score'			=> (float) $score,
									'score_date'	=> (int) $current_time
								);

								$cache_purge = true;
							}
						}

						$sql = 'UPDATE ' . ARCADE_TOUR_CHAMP_TABLE . '
								SET total_time = total_time + ' . (int) $total_time .
								(($high_score_type === null) ? ', total_plays = total_plays + 1' : '') .
								((count($sql_ary)) ? ', ' . $this->db->sql_build_array('UPDATE', $sql_ary) : '') . '
								WHERE game_id = ' . $game_id . '
								AND user_id = ' . $user_id . '
								AND tour_id = ' . $tour_id;
						$this->db->sql_query($sql);

						$return = true;
					}
					else
					{
						$sql_ary = array(
							'tour_id'		=> (int) $tour_id,
							'game_id'		=> (int) $game_id,
							'user_id'		=> (int) $user_id,
							'total_plays'	=> 1
						);

						$this->db->sql_return_on_error(true);
						$this->db->sql_query('INSERT INTO ' . ARCADE_TOUR_CHAMP_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
						$this->db->sql_return_on_error(false);

						$return = true;
					}
				}

				if ($cache_purge)
				{
					$this->cache->destroy('sql', array(ARCADE_TOUR_TABLE, ARCADE_TOUR_CHAMP_TABLE));
				}
			}
		}

		return $return;
	}

	public function close($tour_ids)
	{
		if (empty($tour_ids))
		{
			return;
		}

		if (!is_array($tour_ids))
		{
			$tour_ids = array((int) $tour_ids);
		}

		$total_plays = $total_time = 0;
		$tour_ary = $tour_data = array();

		$sql = 'SELECT t.tour_id, t.tour_name, t.tour_games, t.topic_id, t.reward_1, t.reward_2, t.reward_3,
						tc.game_id, tc.score, tc.score_date, tc.total_plays, tc.total_time,
						u.user_id, u.username, u.user_colour
				FROM ' . ARCADE_TOUR_TABLE . ' t
				LEFT JOIN ' . ARCADE_TOUR_CHAMP_TABLE . ' tc ON t.tour_id = tc.tour_id
				LEFT JOIN ' . USERS_TABLE . ' u ON tc.user_id = u.user_id
				WHERE ' . $this->db->sql_in_set('t.tour_id', $tour_ids) . '
				ORDER BY t.tour_endtime DESC, t.tour_id DESC, tc.score ASC, tc.score_date ASC';
		$result = $this->db->sql_query($sql);

		while ($row = $this->db->sql_fetchrow($result))
		{
			if (!isset($tour_ary[$row['tour_id']]))
			{
				$tour_ary[$row['tour_id']] = array(
					'tour_name'	=> (string) $row['tour_name'],
					'game_ids'	=> array_map('intval', explode(',', $row['tour_games'])),
					'topic_id'	=> (int) $row['topic_id'],
					'reward_1'	=> (float) $row['reward_1'],
					'reward_2'	=> (float) $row['reward_2'],
					'reward_3'	=> (float) $row['reward_3'],
					'ug'		=> array()
				);
			}

			// delete no score game
			if (!$row['score_date'] && $row['game_id'] && $row['user_id'])
			{
				$sql = 'DELETE FROM ' . ARCADE_TOUR_CHAMP_TABLE . '
						WHERE tour_id = ' . (int) $row['tour_id'] . '
						AND game_id = ' . (int) $row['game_id'] . '
						AND user_id = ' . (int) $row['user_id'];
				$this->db->sql_query($sql);

				continue;
			}

			if (!empty($row['user_id']))
			{
				$tour_ary[$row['tour_id']]['ug'][] = array(
					'game_id'		=> $row['game_id'],
					'user_id'		=> $row['user_id'],
					'username'		=> $row['username'],
					'user_colour'	=> $row['user_colour'],
					'score'			=> $row['score'],
					'score_date'	=> $row['score_date'],
					'total_plays'	=> $row['total_plays'],
					'total_time'	=> $row['total_time']
				);
			}
		}
		$this->db->sql_freeresult($result);

		if (count($tour_ary))
		{
			foreach ($tour_ary as $tour_id => $row)
			{
				$last_score_type = null;
				$game_data = $this->arcade->get()->game_cat_data($row['game_ids']);

				$tour_data[$tour_id] = array(
					'tour_id'	=> $tour_id,
					'tour_name'	=> $row['tour_name'],
					'game_ids'	=> $row['game_ids'],
					'topic_id'	=> $row['topic_id'],
					'reward_1'	=> $row['reward_1'],
					'reward_2'	=> $row['reward_2'],
					'reward_3'	=> $row['reward_3']
				);

				foreach ($game_data as $game)
				{
					$high_score_type = ($game['game_scoretype'] == SCORETYPE_HIGH) ? true : false;

					if ($last_score_type !== $high_score_type)
					{
						$last_score_type = $high_score_type;
						$this->arcade->array_column_sort($row['ug'], 'score', ($high_score_type) ? 'd' : 'a');
					}

					foreach ($row['ug'] as $ug)
					{
						if ($game['game_id'] != $ug['game_id'])
						{
							continue;
						}

						$total_plays += $ug['total_plays'];
						$total_time  += $ug['total_time'];

						if (!empty($tour_data[$tour_id]['game_data'][$game['game_id']]))
						{
							continue;
						}

						$tour_data[$tour_id]['game_data'][$game['game_id']] = array(
							'cat_id'			=> $game['cat_id'],
							'cat_name'			=> $game['cat_name'],
							'game_id'			=> $game['game_id'],
							'game_name'			=> $game['game_name'],
							'user_id'			=> $ug['user_id'],
							'username'			=> $ug['username'],
							'user_colour'		=> $ug['user_colour'],
							'score_date'		=> $ug['score_date']
						);

						if ($ug['score_date'])
						{
							$tour_data[$tour_id]['ud'][$ug['user_id']] = array(
								'wins'			=> (empty($tour_data[$tour_id]['ud'][$ug['user_id']]['wins'])) ? 1 : $tour_data[$tour_id]['ud'][$ug['user_id']]['wins'] + 1,
								'user_id'		=> $ug['user_id'],
								'username'		=> $ug['username'],
								'user_colour'	=> $ug['user_colour']
							);

							$sql_ary = array(
								'tour_id' => (int) $tour_id,
								'game_id' => (int) $game['game_id'],
								'user_id' => (int) $ug['user_id']
							);

							$this->db->sql_return_on_error(true);
							$this->db->sql_query('INSERT INTO ' . ARCADE_TOUR_WINS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
							$this->db->sql_return_on_error(false);
						}
					}
				}

				// Check not played games
				if (!empty($tour_data[$tour_id]['game_data']))
				{
					foreach ($tour_data[$tour_id]['game_data'] as $game_id => $null)
					{
						$key = array_search($game_id, $row['game_ids']);
						unset($row['game_ids'][$key]);
					}
				}

				if (count($row['game_ids']))
				{
					foreach ($game_data as $game)
					{
						if (in_array($game['game_id'], $row['game_ids']) && !isset($tour_data[$tour_id]['game_data'][$game['game_id']]))
						{
							// Add data not played games
							$tour_data[$tour_id]['game_data'][$game['game_id']] = array(
								'cat_id'			=> $game['cat_id'],
								'cat_name'			=> $game['cat_name'],
								'game_id'			=> $game['game_id'],
								'game_name'			=> $game['game_name'],
								'score_date'		=> 0
							);
						}
					}
				}
			}

			unset($tour_ary, $game_data);

			foreach ($tour_data as $tour_id => $td)
			{
				if (!empty($td['ud']))
				{
					$this->arcade->array_column_sort($td['ud'], 'wins');

					$x = 0;
					foreach ($td['ud'] as $key => $row)
					{
						$x++;

						if ($x == 1)
						{
							$sql = 'UPDATE ' . ARCADE_TOUR_TABLE . '
									SET tour_wins = ' . (int) $row['user_id'] . '
									WHERE tour_id = ' . (int) $tour_id;
							$this->db->sql_query($sql);
						}

						if ($td['reward_' . $x] > 0 && $this->arcade->points()->data['installed'])
						{
							$td['ud'][$key]['reward'] = $td['reward_' . $x];
							$this->arcade->points()->set('add', $row['user_id'], $td['reward_' . $x]);
						}
						else
						{
							$x = 3;
						}

						if ($x >= 3)
						{
							break;
						}
					}

					if ($this->arcade_config['tour_announce'])
					{
						$this->arcade->array_column_sort($td['game_data'], 'cat_name', 'a');
						$tour_data[$tour_id] = $td;
					}
				}
			}

			$this->arcade_config->increment('tour_total', count($tour_ids));
			$this->arcade_config->increment('tour_total_plays', $total_plays);
			$this->arcade_config->increment('tour_total_plays_time', $total_time);

			if ($this->arcade_config['tour_announce'])
			{
				$this->arcade->phpbb()->create_tour_announcement('tour_end_announce', 'reply', $tour_data);
			}
		}
	}

	public function get_user_tours($user_id = false, $won = false)
	{

		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
		}

		$sql_array = array(
			'SELECT'		 => 't.tour_id, t.tour_name',
			'FROM'			 => array(ARCADE_TOUR_TABLE	=> 't'),
			'LEFT_JOIN'		 => array(
				array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE	=> 'tc'), 'ON' => 't.tour_id = tc.tour_id'),
				array('FROM' => array(ARCADE_TOUR_WINS_TABLE	=> 'tw'), 'ON' => 'tc.tour_id = tw.tour_id AND tc.user_id = tw.user_id AND tc.game_id = tw.game_id')
			),
			'WHERE'			 => 'tc.user_id = ' . (int) $user_id . '
				AND t.tour_status = ' . ARCADE_END_TOUR,
			'ORDER_BY'		 => 't.tour_name ASC',
		);

		if ($won)
		{
			$sql_array['WHERE'] .= ' AND tw.user_id = ' . (int) $user_id;
		}

		$tours = array($this->user->lang['ARCADE_SELECT_TOUR']);

		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$tours[$row['tour_id']] = $row['tour_name'];
		}
		$this->db->sql_freeresult($result);

		if (count($tours) == 1)
		{
			$tours = array();
		}

		return $tours;
	}

	public function game_tours($game_id = false)
	{
		$sql_array = array(
			'SELECT'		 => 't.tour_id, t.tour_name',
			'FROM'			 => array(ARCADE_TOUR_TABLE	=> 't'),
			'LEFT_JOIN'		 => array(
				array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE => 'tc'), 'ON' => 't.tour_id = tc.tour_id')
			),
			'WHERE'			 => 't.tour_status = ' . ARCADE_END_TOUR . '
				AND tc.game_id' . (($game_id) ? ' = ' . (int) $game_id : ' > 0'),
			'GROUP_BY'		 => 't.tour_id, t.tour_name',
			'ORDER_BY'		 => 't.tour_name ASC',
		);
		$tours = array();
		$sql = $this->db->sql_build_query('SELECT', $sql_array);
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$tours[$row['tour_id']] = array(
				'tour_name' => $row['tour_name']
			);
		}
		$this->db->sql_freeresult($result);

		return $tours;
	}

	public function get_options($id = false, $game_id = false, $end = true)
	{
		$options = '<option value="0"' . ((!$id) ? ' selected="selected"' : '') . '>' . $this->user->lang['ARCADE_SELECT_TOUR'] . '</option>';

		foreach ((($game_id) ? $this->game_tours($game_id) : $this->arcade->tours()) as $tour_id => $row)
		{
			if (!$game_id && $end && $row['tour_status'] <> ARCADE_END_TOUR)
			{
				continue;
			}

			$selected = ($tour_id == $id) ? ' selected="selected"' : '';
			$options .= '<option value="' . $tour_id . '"' . $selected . '>' . $row['tour_name'] . '</option>';
		}

		return $options;
	}

	/**
	* Return an array contain all the game ids
	* of the games the all users has played
	*/
	public function get_played_games()
	{
		$sql_array = array(
			'SELECT'	=> 'g.game_id, g.game_name, g.game_name_clean, g.cat_id',
			'FROM'		=> array(ARCADE_TOUR_TABLE => 't'),
			'LEFT_JOIN'	=> array(
				array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE	=> 'tc'), 'ON' => 't.tour_id = tc.tour_id'),
				array('FROM' => array(ARCADE_GAMES_TABLE		=> 'g'),  'ON' => 'tc.game_id = g.game_id')
			),
			'WHERE'		=> 't.tour_status = ' . ARCADE_END_TOUR . '
				AND tc.game_id = g.game_id',
			'ORDER_BY'	=> 'g.game_name_clean ASC'
		);

		$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
		$result = $this->db->sql_query($sql);
		$played = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$played[$row['game_id']] = array(
				'cat_id'	=> $row['cat_id'],
				'game_name'	=> $row['game_name']
			);
		}
		$this->db->sql_freeresult($result);

		return $played;
	}

	/**
	* Cache and return users who have played the tournament
	*/
	public function obtain_all_users()
	{
		$sql_array = array(
			'SELECT'			=> 'u.user_id, u.username, u.username_clean',
			'FROM'				=> array(ARCADE_TOUR_TABLE => 't'),
			'LEFT_JOIN'			=> array(
				array('FROM'	=> array(ARCADE_TOUR_CHAMP_TABLE => 'tc'), 'ON' => 't.tour_id = tc.tour_id'),
				array('FROM'	=> array(USERS_TABLE			 => 'u'), 'ON' => 'tc.user_id = u.user_id')
			),
			'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
				AND t.tour_status = ' . ARCADE_END_TOUR . '
				AND tc.user_id = u.user_id',
			'ORDER_BY'	=> 'u.username_clean ASC',
		);

		$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
		$result = $this->db->sql_query($sql, $this->arcade->hour($this->arcade_config['cache_time']));

		$users = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$users[$row['user_id']] = array(
				'username' => $row['username']
			);
		}
		$this->db->sql_freeresult($result);

		return $users;
	}

	public function games_list()
	{
		$play_games = (count($this->get_played_games())) ? true : false;

		if ($this->arcade_config['load_list'] && $play_games)
		{
			foreach ($this->get_played_games() as $gid => $game)
			{
				$this->template->assign_block_vars('game_jump', array(
					'GAME_ID'	=> $gid,
					'GAME_NAME'	=> $game['game_name'],
				));
			}
		}

		if (!$this->arcade_config['load_list'])
		{
			$this->template->assign_var('STATS_GAMES_LIST_LOADING', ($play_games) ? '<a href="#" data-jvarcade="ajax" data-mode="games_list" data-type="tournament" data-action="played" rel="nofollow"><b>' . $this->user->lang['ARCADE_GAMES_LIST_LOAD'] .'</b></a>' : $this->user->lang['ARCADE_NO_GAMES']);
		}
	}

	public function users_list()
	{
		if ($this->arcade_config['load_list'])
		{
			foreach ($this->obtain_all_users() as $_uid => $_user)
			{
				$this->template->assign_block_vars('stat_user_jump', array(
					'USER_ID'	=> $_uid,
					'USERNAME'	=> $_user['username'])
				);
			}
		}
		else
		{
			$this->template->assign_var('USERS_LIST_LOADING', (count($this->obtain_all_users())) ? '<a href="#" data-jvarcade="ajax" data-mode="users_list" data-type="tournament" data-action="played" rel="nofollow"><b>' . $this->user->lang['ARCADE_USERS_LIST_LOAD'] .'</b></a>' : $this->user->lang['ARCADE_NO_PLAYS']);
		}
	}
}
