<?php
/**
*
* @package phpBB Arcade
* @version $Id: shout.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\detect;

class shout
{
	public $data = array();

	protected $db, $config, $user, $arcade_config, $arcade, $table_prefix, $php_ext;

	public function __construct($db, $config, $user, $arcade_config, $arcade, $table_prefix, $php_ext)
	{
		$this->db = $db;
		$this->config = $config;
		$this->user = $user;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
		$this->table_prefix = $table_prefix;
		$this->php_ext = $php_ext;
	}

	public function main()
	{
		$this->data = array(
			'installed'	=> false,
			'show'		=> false,
			'type'		=> false,
			'enabled'	=> false
		);

		// JV Shoutbox
		if ($this->arcade->ext_enable('jv/shoutbox'))
		{
			define('ARCADE_EXT_CHAT_TABLE', $this->table_prefix . 'jv_shoutbox');

			$this->data['type'] = ARCADE_JV_SHOUTBOX;
			$this->data['installed'] = true;
			$this->data['enabled'] = !empty($this->config['jv_shoutbox_enable']);
		}
		// mChat
		else if ($this->arcade->ext_enable('dmzx/mchat'))
		{
			define('ARCADE_EXT_CHAT_TABLE', $this->table_prefix . 'mchat');

			$this->data['type'] = ARCADE_MCHAT;
			$this->data['installed'] = true;
			$this->data['enabled'] = true;
		}
		else if ($this->arcade->ext_enable('spaceace/ajaxchat'))
		{
			define('ARCADE_EXT_CHAT_TABLE', $this->table_prefix . 'ajax_chat');

			$this->data['type'] = ARCADE_AJAX_CHAT;
			$this->data['installed'] = true;
			$this->data['enabled'] = !empty($this->config['display_ajax_chat']);
		}
		else if ($this->arcade->ext_enable('paul999/ajaxshoutbox'))
		{
			define('ARCADE_EXT_CHAT_TABLE', $this->table_prefix . 'ajax_shoutbox');

			$this->data['type'] = ARCADE_AJAX_SHOUTBOX;
			$this->data['installed'] = true;
			$this->data['enabled'] = true;
		}

		$this->data['show'] = ($this->data['installed'] && $this->data['enabled'] && $this->arcade_config['use_shout']) ? true : false;
	}

	public function msg($scd, $game_data, $score)
	{
		$message = '';
		$type = (int) $this->arcade_config['shout_score_type'];

		switch ($type)
		{
			case 1:
			case 2:
				if (!$scd['first_score'])
				{
					$message = 'ARCADE_MSG' . (($scd['own_new_highscore']) ? '_OWN' : '') . '_NEW_HIGHSCORE';
				}
				else if ($type == 2)
				{
					$message = 'ARCADE_MSG_HIGHSCORE';
				}
			break;

			case 3:
			case 4:
				if ($scd['first_super_score'] && $type == 4)
				{
					$message = 'ARCADE_MSG_SUPERSCORE';
				}
				else if ($scd['new_superscore'])
				{
					$message = 'ARCADE_MSG' . (($scd['own_new_superscore']) ? '_OWN' : '') . '_NEW_SUPERSCORE';
				}
			break;
		}

		if ($message)
		{
			$message = $this->prepare_msg($message, $game_data, $score);
		}

		return $message;
	}

	private function prepare_msg($lang_key, $game_data, $score)
	{
		global $lang;

		$lang_dir = 'default_lang';
		$this->arcade->message_language($lang_dir);

		switch($this->data['type'])
		{
			case ARCADE_MCHAT:
			case ARCADE_AJAX_CHAT:
			case ARCADE_AJAX_SHOUTBOX:
			case ARCADE_JV_SHOUTBOX:
				$arcade_url	= generate_board_url() . '/arcade.' . $this->php_ext;
				$game		= '[url=' . $arcade_url . '?mode=play&amp;g=' . $game_data['game_id'] . $this->arcade->gametop . ']' . $game_data['game_name'] . '[/url]';
				$username	= ($this->user->data['user_colour']) ? '[color=#' . $this->user->data['user_colour'] . ']' . $this->user->data['username'] . '[/color]' : $this->user->data['username'];
				$username	= '[url=' . $arcade_url . '?mode=stats&amp;u=' . $this->user->data['user_id'] . '#userbox]' . $username . '[/url]';
				$message	= sprintf($lang[$lang_key], $game, $username, $score);
			break;

			default:
				//$message = sprintf($lang[$lang_key], $game_data['game_name'], $this->user->data['username'], $score);
				$message = '';
			break;
		}

		return $message;
	}

	public function send($message, $current_time, $shout_user_id = false)
	{
		if (!$message)
		{
			return;
		}

		$enable_bbcode = $enable_urls = $enable_smilies = true;

		if (in_array($this->data['type'], array(ARCADE_JV_SHOUTBOX, ARCADE_MCHAT)))
		{
			$this->sender_user($shout_user_id);
		}
		else if (in_array($this->data['type'], array(ARCADE_AJAX_CHAT, ARCADE_AJAX_SHOUTBOX)))
		{
			$user_data = $this->sender_user($shout_user_id, false);
		}

		switch ($this->data['type'])
		{
			case ARCADE_MCHAT:
			case ARCADE_JV_SHOUTBOX:
				$ary = array(
					'user_id'			=> (int) $shout_user_id,
					'user_ip'			=> $this->user->ip,
					'message'			=> $message,
					'bbcode_bitfield'	=> '',
					'bbcode_uid'		=> '',
					'message_time'		=> $current_time
				);

				$options = 0;

				generate_text_for_storage($ary['message'], $ary['bbcode_uid'], $ary['bbcode_bitfield'], $options, $enable_bbcode, $enable_urls, $enable_smilies);

				if ($this->data['type'] == ARCADE_MCHAT)
				{
					$ary['bbcode_options'] = $options;
				}

				$this->db->sql_query('INSERT INTO ' . ARCADE_EXT_CHAT_TABLE . ' ' . $this->db->sql_build_array('INSERT', $ary));
			break;

			case ARCADE_AJAX_CHAT:
				$ary = array(
					'chat_id'			=> 1,
					'user_id'			=> (int) $user_data['user_id'],
					'username'			=> $user_data['username'],
					'user_colour'		=> $user_data['user_colour'],
					'message'			=> $message,
					'bbcode_bitfield'	=> '',
					'bbcode_uid'		=> '',
					'bbcode_options'	=> 0,
					'time'				=> $current_time,
					'forum_id'			=> 0
				);

				generate_text_for_storage($ary['message'], $ary['bbcode_uid'], $ary['bbcode_bitfield'], $ary['bbcode_options'], $enable_bbcode, $enable_urls, $enable_smilies);
				$this->db->sql_query('INSERT INTO ' . ARCADE_EXT_CHAT_TABLE . ' ' . $this->db->sql_build_array('INSERT', $ary));
			break;

			case ARCADE_AJAX_SHOUTBOX:
				$ary = array(
					'user_id'			=> (int) $user_data['user_id'],
					'post_time'			=> $current_time,
					'bbcode_bitfield'	=> '',
					'bbcode_uid'		=> '',
					'bbcode_options'	=> 0,
					'post_message'		=> $message
				);

				generate_text_for_storage($ary['post_message'], $ary['bbcode_uid'], $ary['bbcode_bitfield'], $ary['bbcode_options'], $enable_bbcode, $enable_urls, $enable_smilies);
				$this->db->sql_query('INSERT INTO ' . ARCADE_EXT_CHAT_TABLE . ' ' . $this->db->sql_build_array('INSERT', $ary));
			break;
		}
	}

	private function sender_user(&$shout_user_id, $only_user_id = true)
	{
		$type = ($only_user_id) ? 'user_id' : 'full_username';

		if ($shout_user_id)
		{
			$user_data = $this->arcade->userdata($type, $shout_user_id);
		}

		if (empty($user_data) && !empty($this->config['jv_system_bot_user_id']))
		{
			$user_data = $this->arcade->userdata($type, $this->config['jv_system_bot_user_id']);
		}

		if (empty($user_data))
		{
			if ($only_user_id)
			{
				$user_data = $this->user->data['user_id'];
			}
			else
			{
				$user_data = array(
					'user_id'		=> $this->user->data['user_id'],
					'username'		=> $this->user->data['username'],
					'user_colour'	=> $this->user->data['user_colour']
				);
			}
		}

		$shout_user_id = intval(($only_user_id) ? $user_data : $user_data['user_id']);

		return $user_data;
	}
}
