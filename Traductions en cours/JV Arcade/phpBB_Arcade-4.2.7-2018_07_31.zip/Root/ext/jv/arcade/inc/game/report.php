<?php
/**
*
* @package phpBB Arcade
* @version $Id: report.php 1980 2018-05-28 15:44:29Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class report
{
	protected $db, $user, $auth, $request, $template, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext;

	public function __construct($db, $user, $auth, $request, $template, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->user = $user;
		$this->auth = $auth;
		$this->request = $request;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function send($game_id, $type, $challenge_id)
	{
		$game_data = $this->arcade->get()->game_cat_data($game_id);

		if (empty($game_data['game_id']))
		{
			trigger_error($this->user->lang['NO_GAME_ID'] . $this->arcade->back_link());
		}

		$report_challenge = ($type == 'challenge' && $challenge_id) ? true : false;

		$back_link = ($report_challenge) ? $this->arcade->back_link('mode=challenge', 'challenge') : $this->arcade->return_links($game_data);

		if (!$this->arcade_auth->acl_get('c_report', $game_data['cat_id']))
		{
			send_status_line(403, 'Forbidden');
			trigger_error($this->user->lang['NO_PERMISSION_ARCADE_REPORT'] . $back_link);
		}

		if ($this->arcade->get()->cat_locked($game_data['cat_id']))
		{
			trigger_error($this->user->lang['ARCADE_CAT_LOCKED_ERROR'] . $back_link);
		}

		$sql = 'SELECT game_id, post_id FROM ' . ARCADE_REPORTS_TABLE . '
				WHERE game_id = ' . (int) $game_data['game_id'];
		$result = $this->db->sql_query($sql);
		$report = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!empty($report['game_id']))
		{
			$message = $this->user->lang['ARCADE_GAME_ALREADY_REPORTED'];

			if ($report_challenge)
			{
				$message .= '<br><br>' . $this->user->lang['ARCADE_DELETE_ALREADY_REPORTED_CHALLENGE'] . '<br>' . implode('<br>', $this->arcade->container('challenge')->report($challenge_id)) . $back_link;
			}
			else
			{
				$message .= $back_link;
			}

			if ($this->arcade_config['report_game_announce_forum'] && !empty($report['post_id']) && $this->auth->acl_get('f_read', $this->arcade_config['report_game_announce_forum']))
			{
				$message .= '<br><br><a href="' . $this->arcade->url("p={$report['post_id']}", 'viewtopic') . "#p{$report['post_id']}" . '">' . $this->user->lang['ARCADE_GAME_REPORT_TOPIC_VIEW'] . '</a>';
			}

			trigger_error($message);
		}

		$form_key = 'arcade_report';
		add_form_key($form_key);

		$this->arcade->add_navlink('add', "mode=report&amp;g={$game_data['game_id']}", 'ARCADE_REPORT');
		$this->arcade->add_navlink('cat_game', 'mode=play', '', $game_data);

		$this->user->add_lang('posting');

		if ($this->request->is_set_post('submit'))
		{
			if (!check_form_key($form_key))
			{
				trigger_error($this->user->lang['FORM_INVALID'] . $back_link);
			}

			$report_message = $this->request->variable('message', '', true);
			$enable_bbcode	= ($this->arcade_config['parse_bbcode']) ? (($this->request->variable('disable_bbcode', false)) ? false : true) : false;
			$enable_smilies	= ($this->arcade_config['parse_smilies']) ? (($this->request->variable('disable_smilies', false)) ? false : true) : false;
			$enable_urls	= ($this->arcade_config['parse_links']) ? (($this->request->variable('disable_magic_url', false)) ? false : true) : false;

			$report_data = array(
				'report_type'			=> (int) $this->request->variable('report_type', 0),
				'report_desc'			=> $report_message,
				'report_desc_bitfield'	=> '',
				'report_desc_options'	=> 0,
				'report_desc_uid'		=> '',
				'report_time'			=> time(),
				'game_id'				=> (int) $game_data['game_id'],
				'user_id'				=> (int) $this->user->data['user_id'],
				'report_ip'				=> $this->user->ip
			);

			generate_text_for_storage($report_data['report_desc'], $report_data['report_desc_uid'], $report_data['report_desc_bitfield'], $report_data['report_desc_options'], $enable_bbcode, $enable_urls, $enable_smilies);

			$message = $this->user->lang['ARCADE_REPORT_SUCCESS'] . '<br><br>' . sprintf($this->user->lang['ARCADE_REPORT_ADDED'], $game_data['game_name']);

			if ($report_challenge)
			{
				$message .= '<br><br>' . $this->user->lang['ARCADE_DELETE_REPORTED_CHALLENGE'] . '<br>' . implode('<br>', $this->arcade->container('challenge')->report($challenge_id));
			}

			if ($this->arcade_config['report_game_announce'])
			{
				$this->arcade->phpbb()->create_report_game_announcement($report_message, $report_data, $game_data);
			}

			$this->db->sql_query('INSERT INTO ' . ARCADE_REPORTS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $report_data));

			$this->arcade_config->increment('reports_open', 1);

			$message .= '<br><br>' . (($report_challenge) ? $back_link : $this->arcade->return_links($game_data, false));

			if ($this->arcade_config['report_game_announce_forum'] && !empty($report_data['post_id']) && $this->auth->acl_get('f_read', $this->arcade_config['report_game_announce_forum']))
			{
				$message .= '<br><br><a href="' . $this->arcade->url("p={$report_data['post_id']}", 'viewtopic') . "#p{$report_data['post_id']}" . '">' . $this->user->lang['ARCADE_GAME_REPORT_TOPIC_VIEW'] . '</a>';
			}

			trigger_error($message);
		}
		else
		{
			$enable_bbcode	= ($this->arcade_config['parse_bbcode']) ? (bool) $this->arcade->optionget('bbcode') : false;
			$enable_smilies	= ($this->arcade_config['parse_smilies']) ? (bool) $this->arcade->optionget('smilies') : false;
			$enable_urls	= ($this->arcade_config['parse_links']) ? true : false;
			$enable_img		= false;
			$enable_flash	= false;
			$enable_qoute	= false;

			if ($enable_smilies)
			{
				// Generate smiley listing
				if (!function_exists('generate_smilies'))
				{
					include($this->root_path . 'includes/functions_posting.' . $this->php_ext);
				}

				generate_smilies('inline', false);
			}

			if ($enable_bbcode)
			{
				// Build custom bbcodes array
				if (!function_exists('display_custom_bbcodes'))
				{
					include($this->root_path . 'includes/functions_display.' . $this->php_ext);
				}

				display_custom_bbcodes();
			}

			$s_hidden_fields = build_hidden_fields(array(
				'mode'	=> 'report',
				'type'	=> $type,
				'cid'	=> $challenge_id,
				'g'		=> $game_data['game_id']
			));

			$report_option_ary = array(
				ARCADE_REPORT_SCORING		=> 'ARCADE_REPORT_SCORING',
				ARCADE_REPORT_PLAYING		=> 'ARCADE_REPORT_PLAYING',
				ARCADE_REPORT_DOUBLE		=> 'ARCADE_REPORT_DOUBLE',
				ARCADE_REPORT_DOWNLOADING	=> 'ARCADE_REPORT_DOWNLOADING',
				ARCADE_REPORT_OTHER			=> 'ARCADE_REPORT_OTHER'
			);

			$GLOBALS['arcade_skip_disable_img'] = 1;

			$this->template->assign_vars(array(
				'S_ACTION'					=> $this->arcade->url(),
				'S_HIDDEN_FIELDS'			=> $s_hidden_fields,

				'S_BBCODE_ALLOWED'			=> $enable_bbcode,
				'S_SMILIES_ALLOWED'			=> ($enable_smilies) ? true : false,
				'S_LINKS_ALLOWED'			=> $enable_urls,

				'S_BBCODE_QUOTE'			=> $enable_qoute,
				'S_BBCODE_FLASH'			=> $enable_flash,
				'S_BBCODE_IMG'				=> $enable_img,

				'BBCODE_STATUS'				=> sprintf($this->user->lang['BBCODE_IS_' . (($enable_bbcode) ? 'ON' : 'OFF')], '<a href="' . append_sid("{$this->root_path}faq.{$this->php_ext}", 'mode=bbcode') . '">', '</a>'),
				'IMG_STATUS'				=> $this->user->lang['IMAGES_ARE_' . (($enable_img) ? 'ON' : 'OFF')],
				'FLASH_STATUS'				=> $this->user->lang['FLASH_IS_' . (($enable_flash) ? 'ON' : 'OFF')],
				'SMILIES_STATUS'			=> $this->user->lang['SMILIES_ARE_' . (($enable_smilies) ? 'ON' : 'OFF')],
				'URL_STATUS'				=> $this->user->lang['URL_IS_' . (($enable_urls) ? 'ON' : 'OFF')],

				'ARCADE_REPORT_OPTIONS'		=> $this->arcade->build_select($report_option_ary, ARCADE_REPORT_SCORING),
				'GAME_DESC'					=> ($game_data['game_desc'] !== '') ? censor_text(nl2br($game_data['game_desc'])) : '',
				'GAME_NAME'					=> $game_data['game_name'],
				'GAME_IMAGE'				=> $this->arcade->get()->game_image($game_data['game_image']),
				'GAME_FILESIZE'				=> ($game_data['game_filesize'] > 0 ) ? sprintf($this->user->lang['ARCADE_GAMES_FILESIZE'], get_formatted_filesize($game_data['game_filesize'])) : sprintf($this->user->lang['ARCADE_GAMES_FILESIZE'], get_formatted_filesize($this->arcade->set_filesize($game_data['game_id']))),
				'POPUP_HEIGHT'				=> $this->arcade_config['smilies_popup_height'],
				'POPUP_WIDTH'				=> $this->arcade_config['smilies_popup_width']
			));

			unset($GLOBALS['arcade_skip_disable_img']);
		}

		$this->arcade->display()->page($this->user->lang['ARCADE_REPORT'], 'arcade/reports_body.html');
	}
}
