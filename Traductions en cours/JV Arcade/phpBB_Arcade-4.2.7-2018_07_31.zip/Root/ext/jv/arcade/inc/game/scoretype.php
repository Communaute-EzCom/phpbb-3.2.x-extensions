<?php
/**
*
* @package phpBB Arcade
* @version $Id: scoretype.php 2023 2018-06-24 14:52:20Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class scoretype
{
	protected $db, $config, $user, $request, $arcade_config, $arcade;

	public function __construct($db, $config, $user, $request, $arcade_config, $arcade)
	{
		$this->db = $db;
		$this->config = $config;
		$this->user = $user;
		$this->request = $request;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	public function set($scoretype)
	{
		$this->arcade->game(true);

		$error = $prepare_score = $undefined_score = false;
		$error_microtime = $error_gs = $error_gid = $error_pch = false;
		$time = time();
		$formtime = 0;

		$arcade_scorevar = '';

		if (!empty($scoretype))
		{
			switch ($scoretype)
			{
				case AMOD_GAME:
					$game_scorevar = $this->arcade->post_var('game_name');
					$score = $this->arcade->post_var('score', 'float');
					$undefined_score = $this->arcade->post_var('score', 'string', true);
					$prepare_score = true;
				break;

				case OLYMPUS_GAME:
					$g_id = $this->arcade->post_var('gameid', 'int');
					$session_id = $this->arcade->post_var('gamesessid', 'string');
				case IBPRO_GAME:
				case ARCADELIB_GAME:
					if (strtolower($this->request->variable('action', '')) == 'submit_score')
					{
						$game_scorevar = $this->arcade->post_var('areabb_variable');
						$score = $this->arcade->post_var('areabb_score', 'float');
						$undefined_score = $this->arcade->post_var('areabb_score', 'string', true);
					}
					else
					{
						$game_scorevar = $this->arcade->post_var('gname');
						$score = $this->arcade->post_var('gscore', 'float');
						$undefined_score = $this->arcade->post_var('gscore', 'string', true);
					}

					$prepare_score = true;
				break;

				case V3ARCADE_GAME:
					$v3arcade = strtolower($this->arcade->post_var('sessdo'));
					$game_scorevar = $this->arcade->post_var('gamename');
					$micro_one = $this->arcade->post_var('microone');
					$score = $this->arcade->post_var('score', 'float');
					$fake_key = $this->arcade->post_var('fakekey');

					switch ($v3arcade)
					{
						case 'sessionstart':
							$session_id = '';

							if ($game_scorevar != '')
							{
								$sql = 'SELECT s.session_id
										FROM ' . ARCADE_SESSIONS_TABLE . ' s, ' . ARCADE_GAMES_TABLE . " g
										WHERE s.phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
										AND s.user_id = " . (int) $this->user->data['user_id'] . "
										AND s.game_id = g.game_id
										AND g.game_scorevar = '" . $this->db->sql_escape($game_scorevar) . "'";
								$result = $this->db->sql_query($sql);
								$session_id = $this->db->sql_fetchfield('s.session_id');
								$this->db->sql_freeresult($result);
							}

							$initbar = $game_scorevar . '|' . $session_id;
							$this->arcade->set_header_no_cache();
							echo '&connStatus=1&initbar='. $initbar .'&val=x';
							garbage_collection();
							exit_handler();
						break;

						case 'permrequest':
							$this->arcade->set_header_no_cache();
							echo '&validate=1&microone='. $score .'|'. $fake_key .'&val=x';
							garbage_collection();
							exit_handler();
						break;

						case 'burn':
							$data				= explode('|', $micro_one);
							$score				= $this->arcade->number_format($data[0], true);
							$game_scorevar		= str_replace("\'", "''", htmlspecialchars(trim($data[1])));
							$session_id			= (isset($data[2])) ? $data[2] : true;
							$undefined_score	= ($this->arcade->post_var('microone', 'string', true) || $data[0] == 'undefined') ? true : false;
							$prepare_score		= true;
						break;
					}
				break;

				case IBPROV3_GAME:
					$arcade_do = strtolower($this->request->variable('do', ''));

					if ($arcade_do == 'verifyscore')
					{
						$_gamedata = $this->arcade->game()->session->add_game_randchar();
						$this->arcade->set_header_no_cache();
						echo '&randchar=' . $_gamedata['randchar1'] . '&randchar2=' . $_gamedata['randchar2'] . (($this->config['cookie_secure']) ? '&gp=' . $_gamedata['game_popup'] : '') . '&savescore=1&blah=OK';

						garbage_collection();
						exit_handler();
					}
					else if ($arcade_do == 'savescore' || $arcade_do == 'newscore')
					{
						$game_scorevar	= $this->arcade->post_var('gname');
						$score			= $this->arcade->post_var('gscore', 'float');
						$original_score	= $this->arcade->post_var('gscore', 'num');
						$game_gkey		= $this->arcade->post_var('arcadegid', 'int');
						$game_skey		= $this->arcade->post_var('enscore', 'float');
						$prepare_score	= true;

						$undefined_score = $this->arcade->post_var('gscore', 'string', true);
					}
				break;

				case AR_GAME:
					$game_scorevar = $this->arcade->post_var('g', 'int');
					$score = $this->arcade->post_var('score', 'float');
					$undefined_score = $this->arcade->post_var('score', 'string', true);
					$prepare_score = true;
				break;

				case PHPBB_RA_GAME:
					$arcade_act = strtolower($this->request->variable('act', ''));

					if (strtolower($this->request->variable('action', '')) == 'arcade' && strtolower($this->request->variable('scoreprep', '')) == 'prepascore')
					{
						$_gamedata = $this->arcade->game()->session->add_game_randchar();
						$this->arcade->set_header_no_cache();
						echo 'myscorekey='.$_gamedata['randchar1'].'&raOK=1&myRAKEY=75zW6L8DmS22qRj75P6kL3P8&myRAKEYoK=1' . (($this->config['cookie_secure']) ? '&gp=' . $_gamedata['game_popup'] : '');

						garbage_collection();
						exit_handler();
					}
					else if ($arcade_act == 'arcade' && strtolower($this->request->variable('do', '')) == 'newscore' && ($gsubmitscore = html_entity_decode($this->request->variable('gsubmitscore', ''))))
					{
						$randchar1 = 0;
						if ($this->arcade->game()->session->game_sid)
						{
							$sql = 'SELECT randchar1
									FROM ' . ARCADE_SESSIONS_TABLE . "
									WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
									AND user_id = " . (int) $this->user->data['user_id'] . "
									AND session_id = '" . $this->db->sql_escape($this->arcade->game()->session->game_sid) . "'";
							$result = $this->db->sql_query($sql);
							$randchar1 = (int) $this->db->sql_fetchfield('randchar1');
							$this->db->sql_freeresult($result);
						}

						$resul_submit = array();
						if ($randchar1)
						{
							$decrypt_submit = $this->decrypt_string($gsubmitscore, $randchar1);
							$resul_submit = explode(';', $decrypt_submit);
						}

						$game_scorevar		= (!empty($resul_submit[0])) ? (string) $resul_submit[0] : '';
						//$javascript			= (!empty($resul_submit[1])) ? (string) $resul_submit[1] : '';
						$score				= (!empty($resul_submit[3])) ? (float) $resul_submit[3] : 0;
						$game_gkey			= (!empty($resul_submit[5])) ? (int) $resul_submit[5] : 0;
						$game_dkey			= $randchar1 + (int) $score;
						$undefined_score	= (!isset($resul_submit[3])) ? true : false;

						if ($this->request->is_ajax())
						{
							if ($game_scorevar && $this->arcade->game()->session->game_sid)
							{
								$data = "gs=$game_scorevar\nscore=$score\ngg=$game_gkey\ngd=$game_dkey";

								$sql = 'UPDATE ' . ARCADE_SESSIONS_TABLE . "
										SET post_data = '" . $this->db->sql_escape($data) . "'
										WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
										AND session_id = '" . $this->db->sql_escape($this->arcade->game()->session->game_sid) . "'
										AND user_id = " . (int) $this->user->data['user_id'];
								$this->db->sql_query($sql);
							}

							echo $this->arcade->url('act=rarcade', 'arcade', false, 'game_done', '/');

							garbage_collection();
							exit_handler();
						}

						$prepare_score = true;
					}
					else if ($arcade_act == 'rarcade')
					{
						$game_scorevar	= $this->arcade->post_var('gs');
						$score			= $this->arcade->post_var('score', 'float');
						$game_gkey		= $this->arcade->post_var('gg', 'int');
						$game_dkey		= $this->arcade->post_var('gd', 'int');
						$undefined_score = $this->arcade->post_var('score', 'string', true);
						$prepare_score = true;
					}
					else
					{
						$error = 'GAME_DATA_CORRUPT';
					}
				break;

				case PHPBBARCADE_GAME:
					$arcade_scorevar	= strtolower($this->arcade->post_var('sendscore'));
					$jvah5_scorevar		= strtolower($this->arcade->post_var('jva_h5_score'));
					//$game_msec			= $this->arcade->post_var('msec', 'int');

					if ($arcade_scorevar == 'verify' || $jvah5_scorevar == 'h5verify')
					{
						$_gamedata = $this->arcade->game()->session->add_game_randchar(false, $jvah5_scorevar);

						if ($jvah5_scorevar == 'h5verify' && $this->request->is_ajax())
						{
							$json_response = new \phpbb\json_response();

							$json_response->send(array(
								'randchar1'		=> $_gamedata['randchar1'],
								'randchar2'		=> $_gamedata['randchar2'],
								'verifyscore'	=> 'ok'
							));
						}

						$this->arcade->set_header_no_cache();
						echo 'randchar1=' . $_gamedata['randchar1'] . '&randchar2=' . $_gamedata['randchar2'] . (($this->config['cookie_secure']) ? '&gp=' . $_gamedata['game_popup'] : '') . '&savescore=ok&blah=OK';

						garbage_collection();
						exit_handler();
					}
					else if ($arcade_scorevar == 'save' || $jvah5_scorevar == 'h5save' || $arcade_scorevar == 'banned' || $jvah5_scorevar == 'banned')
					{
						$game_scorevar	= $this->arcade->post_var('arcade_gsvar');
						$score			= $this->arcade->post_var('arcade_gscore', 'float');
						$original_score	= $this->arcade->post_var('arcade_gscore', 'num');
						$game_gkey		= $this->arcade->post_var('arcade_gkey', 'int');
						$game_skey		= $this->arcade->post_var('arcade_skey', 'float');
						$prepare_score	= true;

						$undefined_score = $this->arcade->post_var('arcade_gscore', 'string', true);
					}
					else if ($arcade_scorevar == 'time_hack')
					{
						if ($this->user->data['is_registered'])
						{
							$this->arcade->game()->session->security(ARCADE_BANNED_TIME_HACK);
						}

						$this->arcade->set_header_no_cache();

						garbage_collection();
						exit_handler();
					}
					else
					{
						$error = 'GAME_DATA_CORRUPT';
					}
				break;

				default:
					$error = 'GAME_S_TYPE_NOT_IDENTIFIED';
				break;
			}
		}

		if (!$this->user->data['is_bot'] && $this->arcade->access())
		{
			// ???
			$style_id = (int) $this->request->variable('style', 0);
			$this->arcade->style($style_id);

			if ($error)
			{
				$this->arcade->setup(false, $style_id, true);

				trigger_error($this->user->lang['ARCADE_' . $error] . $this->arcade->gbl());
			}
			else if ($prepare_score)
			{
				/**
				* This function checks to make sure the game type is the expected type
				* and that the user and game ids exist in the sessions table.
				* It then returns the needed information in an array.
				*/
				if (!empty($game_scorevar))
				{
					if (empty($this->arcade->game()->session->game_sid))
					{
						$error = ($this->config['cookie_secure']) ? 'GAME_SESSION_ID_ERROR' : 'COOKIE_ERROR';
					}
					else
					{
						$score = $this->arcade->number_format($score, true);

						$sql_array = array(
							'SELECT'		=> 's.start_time, s.session_id, s.randchar1, s.randchar2, s.randgid1, s.randgid2, s.game_popup, s.microtime, s.security,
												g.game_id, g.game_name, g.game_image, g.game_width, g.game_height, g.game_scorevar, g.game_highscore, g.game_highuser, g.game_highdate, g.game_scoretype, g.game_type, g.game_save_type, g.game_votetotal, g.game_votesum, g.game_cost, g.game_reward, g.game_jackpot, g.game_use_jackpot, g.cat_id,
												c.cat_name, c.cat_desc, c.cat_style, c.cat_type, c.cat_status, c.cat_desc_uid, c.cat_desc_bitfield, c.cat_desc_options, c.parent_id, c.left_id, c.right_id, c.cat_parents, c.cat_test, c.cat_cost, c.cat_reward, c.cat_use_jackpot,
												r.game_rating',
							'FROM'			=> array(ARCADE_SESSIONS_TABLE	=> 's',
							),
							'LEFT_JOIN'	=> array(
								array(
									'FROM'	=> array(ARCADE_GAMES_TABLE		=> 'g'),
									'ON'	=> 's.game_id = g.game_id'
								),
								array(
									'FROM'	=> array(ARCADE_CATS_TABLE		=> 'c'),
									'ON'	=> 'g.cat_id = c.cat_id'
								),
								array(
									'FROM'	=> array(ARCADE_RATING_TABLE => 'r'),
									'ON'	=> 's.game_id = r.game_id AND s.user_id = r.user_id'
								),
							),
							'WHERE' 		=> "s.phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
								AND s.session_id = '" . $this->db->sql_escape($this->arcade->game()->session->game_sid) . "'
								AND s.user_id = " . (int) $this->user->data['user_id'],
						);
						$sql = $this->db->sql_build_query('SELECT', $sql_array);
						$result = $this->db->sql_query_limit($sql, 1);
						$game_data = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);

						if (!$game_data)
						{
							$uid = $this->arcade->post_var('uid', 'int');
							$uid = ($uid) ? $uid : $this->arcade->game()->session->uid();

							$error = (!$this->user->data['is_registered'] && $uid > ANONYMOUS) ? 'SESSION_TIME_END' : 'BACK_BUTTON_ERROR';
						}
						else
						{
							$this->arcade->style($style_id, $game_data['cat_id'], $game_data['game_id']);
							$this->arcade->setup(false, $style_id, true);
							$this->arcade->game()->session->delete();

							if ($scoretype == PHPBBARCADE_GAME && ($arcade_scorevar == 'banned' || $jvah5_scorevar == 'banned' || ($jvah5_scorevar && !$this->arcade->game()->session->pd($this->arcade->post_var('pd', 'string')))))
							{
								$game_skey = -1;
								$delete_cookie = true;
								if ($this->user->data['is_registered'] && $this->arcade_config['corrupt_score_banned'] && $this->user->data['user_type'] != USER_FOUNDER)
								{
									$this->arcade->banned(ARCADE_BANNED_INVALID_FORM1);
								}

								$error = 'GAME_DATA_CORRUPT';
								$this->create_error_log($scoretype, $game_data, $score, false, false, false, false, false, true);
							}
							else
							{
								$this->arcade->add_navlink('add', '', 'ARCADE_INDEX');
								$this->arcade->game()->session->game_popup = ($game_data['game_popup']) ? true : false;

								$game_data['current_time']	= $time;
								$total_time					= intval($game_data['current_time'] - $game_data['start_time']);
								$game_data['total_time']	= ($total_time <= 0) ? false : $total_time;

								if ($game_data['game_save_type'] == $scoretype && (
									(!empty($session_id) && $session_id !== $game_data['session_id']) ||
									(PHPBBARCADE_GAME != $game_data['game_save_type'] && ((!is_int($game_scorevar) && strtolower($game_scorevar) != strtolower($game_data['game_scorevar'])) || (is_int($game_scorevar) && $game_scorevar != $game_data['game_id'])))))
								{
									$error = 'DIF_SCOREVAR_ERROR';
								}
								else
								{
									$delete_cookie = true;

									if ($game_data['game_save_type'] != $scoretype)
									{
										$error = 'TYPE_ERROR';
										$this->arcade->game()->update_save_type($scoretype, $game_data['game_id']);
									}
									else if (!$game_data['total_time'])
									{
										$error = 'TIME_ERROR';
										$score = ($undefined_score) ? 'undefined' : $score;
										$this->arcade->add_log('critical', $game_data['game_id'], 'LOG_ARCADE_ERROR_PLAYING_TIME', $game_data['game_name'], $score);
									}
									else
									{
										if ($scoretype == PHPBBARCADE_GAME || $scoretype == IBPROV3_GAME || $scoretype == PHPBB_RA_GAME)
										{
											$microtime			= intval(($game_data['microtime'] + $this->arcade_config['score_form_token_lifetime']) - $time);
											$error_microtime	= ($microtime < 0) ? true : false;
											$error_randchar		= (!$game_data['randgid1'] || !$game_data['randgid2'] || !$game_data['randchar1'] || !$game_data['randchar2']) ? true : false;
											$decodegame_key		= (int) $game_data['game_id'] * $game_data['randgid1'] ^ $game_data['randgid2'];

											if ($scoretype != PHPBB_RA_GAME)
											{
												$original_score		= ($scoretype == PHPBBARCADE_GAME) ? substr(round($original_score), 0, 6) : $original_score;
												$decodescore_key	= $original_score * $game_data['randchar1'] ^ $game_data['randchar2'];
												$error_gid			= ($decodegame_key != $game_gkey) ? true : false;
												$error_gs			= ($decodescore_key != $game_skey) ? true : false;
											}

											if ($game_data['microtime'] > 0)
											{
												$formtime = $time - $game_data['microtime'];
												$formtime = ($formtime == 0) ? 1 : $formtime;
											}
										}

										if ($scoretype == PHPBBARCADE_GAME)
										{
											$error_pch = (!phpbb_check_hash($game_data['game_scorevar'], $game_scorevar)) ? true : false;
										}

										if ($scoretype == IBPROV3_GAME && ($this->arcade->post_var('arcadegid', 'string', true) === true || $this->arcade->post_var('enscore', 'string', true) === true))
										{
											$error = 'GAME_DATA_EMPTY_ERROR';
											$score = ($undefined_score) ? 'undefined' : $score;
											$this->arcade->add_log('critical', $game_data['game_id'], 'LOG_ARCADE_GAME_DATA_EMPTY_ERROR', $game_data['game_name'], $score);
										}
										else if (($scoretype == IBPROV3_GAME) && ($error_microtime || $error_randchar || $error_gs || $error_gid))
										{
											$banned_level2 = ($this->arcade_config['score_security_level'] == SCORE_SECURITY_MEDIUM && ($error_gs || $error_gid)) ? true : false;
											$banned_level3 = ($this->arcade_config['score_security_level'] == SCORE_SECURITY_HIGH && ($error_microtime || $error_gs || $error_gid)) ? true : false;

											if (!$undefined_score && $score && $this->arcade_config['corrupt_score_banned'] && $this->user->data['is_registered'] && $this->user->data['user_type'] != USER_FOUNDER && ($banned_level2 || $banned_level3))
											{
												$this->arcade->banned(ARCADE_BANNED_INVALID_FORM2, false, false, $game_data['game_id'], $score, $formtime);
												$error = 'GAME_DATA_CORRUPT';
											}
											else if ($undefined_score)
											{
												$error = 'GAME_DATA_EMPTY';
											}
											else
											{
												$error = 'GAME_DATA_CORRUPT';
											}

											$this->create_error_log($scoretype, $game_data, $score, $error_microtime, $error_gs, $error_gid);
										}
										else if ($scoretype == PHPBBARCADE_GAME && ($error_microtime || $error_pch || $error_randchar || $error_gs || $error_gid))
										{
											$banned_level2 = ($this->arcade_config['score_security_level'] == SCORE_SECURITY_MEDIUM && ($error_pch || $error_gs || $error_gid)) ? true : false;
											$banned_level3 = ($this->arcade_config['score_security_level'] == SCORE_SECURITY_HIGH && ($error_microtime || $error_pch || $error_gs || $error_gid)) ? true : false;

											if (!$undefined_score && $score && $this->arcade_config['corrupt_score_banned'] && $this->user->data['is_registered'] && $this->user->data['user_type'] != USER_FOUNDER && ($banned_level2 || $banned_level3))
											{
												$banned_type = ($error_pch) ? ARCADE_BANNED_INVALID_FORM3 : ARCADE_BANNED_INVALID_FORM2;
												$this->arcade->banned($banned_type, false, false, $game_data['game_id'], $score, $formtime);
												$error = ($error_pch) ? 'DIF_SCOREVAR_ERROR' : 'GAME_DATA_CORRUPT';
											}
											else if ($error_pch)
											{
												$error = 'DIF_SCOREVAR_ERROR';
											}
											else if ($undefined_score)
											{
												$error = 'GAME_DATA_EMPTY';
											}
											else
											{
												$error = 'GAME_DATA_CORRUPT';
											}

											$this->create_error_log($scoretype, $game_data, $score, $error_microtime, $error_gs, $error_gid, $error_pch);
										}
										else if ($scoretype == PHPBB_RA_GAME)
										{
											$error_gid = ($game_gkey != $game_dkey);
											$error_microtime = ($arcade_act == 'rarcade' && $error_microtime) ? $error_microtime : false;

											if ($error_gid || $error_microtime)
											{
												$banned_level2 = ($this->arcade_config['score_security_level'] == SCORE_SECURITY_MEDIUM && $error_gid) ? true : false;
												$banned_level3 = ($this->arcade_config['score_security_level'] == SCORE_SECURITY_HIGH && ($error_microtime || $error_gid)) ? true : false;

												if (!$undefined_score && $score && $this->arcade_config['corrupt_score_banned'] && $this->user->data['is_registered'] && $this->user->data['user_type'] != USER_FOUNDER && ($banned_level2 || $banned_level3))
												{
													$this->arcade->banned(ARCADE_BANNED_INVALID_FORM2, false, false, $game_data['game_id'], $score, $formtime);
													$error = 'GAME_DATA_CORRUPT';
												}
												else if ($undefined_score)
												{
													$error = 'GAME_DATA_EMPTY';
												}
												else
												{
													$error = 'GAME_DATA_CORRUPT';
												}

												$this->create_error_log($scoretype, $game_data, $score, $error_microtime, false, $error_gid);
											}
										}
									}
								}
							}
						}
					}
				}
				else
				{
					if ($scoretype == IBPROV3_GAME && !$game_gkey && $game_skey)
					{
						$error = 'IBPROV3_TYPE_NOT_SUPPORTED';
					}
					else
					{
						$error = 'SCOREVAR_ERROR';
					}
				}

				if (empty($game_data))
				{
					$this->arcade->setup(false, $style_id, true);
				}

				if (!$error)
				{
					if ($undefined_score)
					{
						$this->arcade->add_log('critical', $game_data['game_id'], 'LOG_ARCADE_UNDEFINED_SCORE', $game_data['game_name']);
					}
					else if ($this->user->data['is_registered'] && !empty($game_data['security']))
					{
						if ($game_data['security'] == ARCADE_BANNED_TIME_HACK && $this->arcade_config['game_time_hack_banned'] && $this->user->data['user_type'] != USER_FOUNDER)
						{
							$this->arcade->banned(ARCADE_BANNED_TIME_HACK, false, false, $game_data['game_id'], $score, $formtime);
						}

						$error = 'GAME_DATA_CORRUPT';
						$this->create_error_log($scoretype, $game_data, $score, $error_microtime, $error_gs, $error_gid, $error_pch, true);
					}
				}

				if ($error)
				{
					if (!empty($delete_cookie))
					{
						$this->arcade->game()->session->set_cookie();
					}

					trigger_error($this->user->lang['ARCADE_' . $error] . (($error != 'DIF_SCOREVAR_ERROR' && !empty($game_data)) ? $this->arcade->return_links($game_data, true) : $this->arcade->gbl()));
				}

				$this->arcade->container('score')->send('new', $game_data['game_id'], $game_data, $undefined_score ? 'undefined' : $score);
			}
		}

		// Something went wrong or bot, lets send them to the arcade index.
		redirect($this->arcade->url());
	}

	private function create_error_log($scoretype, $game_data, $score, $error_microtime, $error_gs, $error_gid, $error_pch = false, $hack_time = false, $game_hack = false)
	{
		$errors = array();

		if ($game_hack)
		{
			$errors[] = 'ARCADE_SCORE_ERR_GAME_HACK';
		}
		else
		{
			if ($hack_time)
			{
				$errors[] = 'ARCADE_SCORE_ERR_TIME_HACK';
			}

			if ($error_microtime)
			{
				$errors[] = 'ARCADE_SCORE_ERR_MICRO_TIME';
			}

			$game_key_err = false;
			$score_key_err = false;

			if (!$hack_time && (!$game_data['randgid1'] || !$game_data['randgid2'] || !$game_data['randchar1'] || !$game_data['randchar2']))
			{
				if ((!$game_data['randchar1'] || !$game_data['randchar2']) && (!$game_data['randgid1'] || !$game_data['randgid2']))
				{
					$game_key_err = true;
					$score_key_err = true;
					$errors[] = 'ARCADE_SCORE_ERR_GS_GG_RANDCHAR';
				}
				else if (!$game_data['randchar1'] || !$game_data['randchar2'])
				{
					$score_key_err = true;
					$errors[] = 'ARCADE_SCORE_ERR_GS_RANDCHAR';
				}
				else
				{
					$game_key_err = true;
					$errors[] = 'ARCADE_SCORE_ERR_GG_RANDCHAR';
				}
			}

			if (!$score_key_err && $error_gs)
			{
				$errors[] = 'ARCADE_SCORE_ERR_GS';
			}

			if (!$game_key_err && $error_gid)
			{
				$errors[] = 'ARCADE_SCORE_ERR_GG';
			}

			if ($error_pch)
			{
				$errors[] = 'ARCADE_SCORE_ERR_PCH';
			}
		}

		$this->arcade->add_log('critical', $game_data['game_id'], 'LOG_ARCADE_FORM_SCORE_ERROR' . ((count($errors) > 1) ? 'S' : ''), $game_data['game_name'], $this->arcade->game()->type($game_data['game_type']), $this->arcade->game()->save_type($scoretype), $score, implode(', ', $errors));
	}

	private function decrypt_string($gsubmit, $gkey)
	{
		$gresult = '';
		$i = $j = $char = 0;
		$l_gsubmit = strlen($gsubmit);
		$l_gkey = strlen($gkey);
		while ($i < $l_gsubmit)
		{
			if ($j >= $l_gkey)
			{
				$j = 0;
			}

			$char = intval(substr($gkey,$j,1)) ^ ord(substr($gsubmit, $i, 1));
			$gresult .= chr($char);
			$i++;
			$j++;
		}

		return $gresult;
	}
}
