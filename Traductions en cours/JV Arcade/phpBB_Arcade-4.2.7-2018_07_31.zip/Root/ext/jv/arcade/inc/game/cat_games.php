<?php
/**
*
* @package phpBB Arcade
* @version $Id: cat_games.php 2043 2018-07-26 13:45:52Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class cat_games
{
	protected $db, $cache, $user, $auth, $request, $template, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext;

	public function __construct($db, $cache, $user, $auth, $request, $template, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->cache = $cache;
		$this->user = $user;
		$this->auth = $auth;
		$this->request = $request;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function display($mode, $cat_id, $game_id, $start)
	{
		$search_id	= strtolower($this->request->variable('search_id', ''));
		$term		= $this->request->variable('term', '', true);

		$this->arcade->display()->cat_jumpbox($this->arcade->url('mode=cat'), $cat_id);

		$sort_key = $this->request->variable('sk', $this->user->data['games_sort_order']);
		$sort_dir = $this->request->variable('sd', $this->user->data['games_sort_dir']);

		$limit_days = array();
		$sort_by_text = array('f' => $this->user->lang['ARCADE_GAMES_SORT_FIXED'], 'n' => $this->user->lang['ARCADE_NAME'], 'd' => $this->user->lang['ARCADE_GAMES_SORT_INSTALLDATE'], 'p' => $this->user->lang['ARCADE_GAMES_SORT_PLAYS'], 'r' => $this->user->lang['ARCADE_GAMES_SORT_RATING']);
		$sort_by_sql = array('f' => 'g.game_order', 'n' => 'g.game_name_clean', 'd' => 'g.game_installdate', 'p' => 'g.game_plays', 'r' => 'g.game_votesum / g.game_votetotal ' . (($sort_dir == 'd') ? 'DESC' : 'ASC') . ', g.game_votetotal');

		if ($this->arcade_config['display_game_type'])
		{
			$sort_by_text['t'] = $this->user->lang['ARCADE_GAME_TYPE'];
			$sort_by_sql['t'] = 'g.game_type';
		}

		if ($this->arcade_config['display_game_save_type'])
		{
			$sort_by_text['s'] = $this->user->lang['ARCADE_GAME_SAVE_TYPE'];
			$sort_by_sql['s'] = 'g.game_save_type';
		}

		if ($mode == 'fav')
		{
			$sort_by_text['h'] = $this->user->lang['ARCADE_HIGHLIGHTED_GAME'];
			$sort_by_sql['h'] = 'f.highlighted';
		}

		$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
		gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

		$score_columns = ($this->arcade_config['game_comment']) ? 's.comment_text, s.comment_uid, s.comment_bitfield, s.comment_options,' : '';
		$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

		$sql_array = array(
			'SELECT'	=> "g.game_id, g.game_image, g.game_highscore, g.game_highdate, g.game_highuser, g.game_name, g.game_name_clean, g.game_type,
							g.game_swf, g.game_save_type, g.game_width, g.game_height, g.game_filesize, g.game_plays, g.game_download_total,
							g.game_download, g.game_installdate, g.game_cost, g.game_reward, g.game_use_jackpot, g.game_jackpot, g.cat_id, g.post_id,
							g.game_desc, g.game_control, g.game_control_desc, g.game_votesum, g.game_votetotal, g.game_download_cost, g.game_scoretype,
							c.cat_name, c.cat_download, c.cat_cost, c.cat_reward, c.cat_use_jackpot, c.cat_status, c.cat_download_cost, c.cat_test,
							u.user_id, u.username, u.user_colour,
							s.score, s.score_date,{$score_columns}
							r.game_rating,
							sc.score AS super_score, sc.score_date AS super_score_date",
			'FROM'		=> array(
				ARCADE_GAMES_TABLE	=> 'g',
			),
			'LEFT_JOIN'	=> array(
				array(
					'FROM'	=> array(USERS_TABLE => 'u'),
					'ON'	=> 'g.game_highuser = u.user_id AND u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')'
				),
				array(
					'FROM'	=> array(ARCADE_SCORES_TABLE => 's'),
					'ON'	=> 's.game_id = g.game_id AND s.user_id = ' . (int) $this->user->data['user_id']
				),
				array(
					'FROM'	=> array(ARCADE_RATING_TABLE => 'r'),
					'ON'	=> 'r.game_id = g.game_id AND r.user_id = ' . (int) $this->user->data['user_id']
				),
				array(
					'FROM'	=> array(ARCADE_CATS_TABLE => 'c'),
					'ON'	=> 'g.cat_id = c.cat_id'
				),
				array(
					'FROM'	=> array(ARCADE_SUPER_SCORES_TABLE => 'sc'),
					'ON'	=> 'g.game_id = sc.game_id'
				),
			),
			'WHERE'		=> $this->db->sql_in_set('g.cat_id', $this->arcade->get()->permissions(array('c_view', 'c_play')), false, true),
			'ORDER_BY'	=> $sql_sort,
		);

		if ($this->arcade_config['cat_super_record'])
		{
			$sql_array['SELECT'] .= ', cu.user_id AS champ_user_id, cu.username AS champ_username, cu.user_colour AS champ_user_colour';
			$sql_array['LEFT_JOIN'][] = array('FROM' => array(USERS_TABLE => 'cu'), 'ON' => 'sc.user_id = cu.user_id AND cu.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')');
		}

		$total_games	= 0;
		$s_use_points	= (!$this->user->data['is_bot'] && $this->arcade->points()->data['show']) ? true : false;
		// END building the query need for this page
		$games_per_page = ($this->arcade_config['games_per_page'] > 0) ? $this->arcade_config['games_per_page'] : 1;

		switch($mode)
		{
			// Setup to display all the users favorite games
			case 'fav':
				$this->arcade->add_navlink('add', "mode=$mode", 'ARCADE_FAV');
				// Set the link to the main statistics page in the nav
				$this->template->assign_vars(array(
					'S_IN_FAV'		=> true,
					'L_LIST_TITLE'	=> $this->user->lang['ARCADE_MY_FAVORITE_GAMES']
				));

				if (!($total_games = $this->arcade->get()->total('game', 'favorites', $this->user->data['user_id'], false, true)))
				{
					trigger_error($this->user->lang['ARCADE_NO_GAME_FAVS'] . $this->arcade->back_link());
				}

				$cat_id = ARCADE_FAV_ID;
				$sql_array['SELECT'] .= ', f.highlighted';
				$sql_array['LEFT_JOIN'][] = array('FROM' => array(ARCADE_FAVS_TABLE => 'f'), 'ON' => 'f.game_id = g.game_id AND f.user_id = ' . $this->user->data['user_id']);
				$sql_array['WHERE'] .= ' AND f.game_id = g.game_id';
				$pagination_mode = 'mode=fav';
				$this->arcade->page_title = $this->user->lang['ARCADE_FAV'];
			break;

			// Setup to display search results
			case 'search':
				// Set the link to the main statistics page in the nav
				$this->template->assign_var('S_IN_SEARCH', true);

				$cat_id = ARCADE_SEARCH_ID;

				if ($search_id == 'newgames')
				{
					$this->template->assign_vars(array(
						'S_IN_SEARCH_NEW_GAMES'	=> true,

						'L_LIST_TITLE'			=> $this->user->lang['NEW_GAMES'],
					));

					$new_games_delay = (time() - ($this->arcade_config['new_games_delay'] * 86400));

					if (!($total_games = $this->arcade->get()->total('game', 'search_newgames', $new_games_delay, false, true)))
					{
						trigger_error($this->user->lang['ARCADE_SEARCH_NO_MATCHES'] . $this->arcade->back_link());
					}

					$this->user->add_lang('search');

					$sql_array['WHERE'] .= ' AND g.game_installdate >= ' . (int) $new_games_delay . '
											AND ' . $this->db->sql_in_set('g.cat_id', $this->arcade->get()->game_search_protection(), true, true);
					$pagination_mode = 'mode=search&amp;search_id=newgames';
					$this->arcade->page_title = sprintf($this->user->lang['ARCADE_SEARCH_RESULTS_FOR'], strtolower($this->user->lang['ARCADE_SEARCH_NEW_GAMES']));
				}
				else
				{
					if (!$term)
					{
						trigger_error($this->user->lang['ARCADE_SEARCH_NO_MATCHES'] . $this->arcade->back_link());
					}

					$this->user->add_lang('search');

					$min = 3;
					$max = 30;
					$num = utf8_strlen($term);

					if ($num < $min || $num > $max)
					{
						trigger_error($this->user->lang('IGNORED_TERMS_EXPLAIN', $term) . '<br>' . $this->user->lang('NO_KEYWORDS', $min, $max) . $this->arcade->back_link());
					}

					// Check search flood control
					$interval = ($this->user->data['user_id'] == ANONYMOUS) ? $this->arcade_config['search_anonymous_interval'] : $this->arcade_config['search_interval'];
					if ($interval && !$this->auth->acl_get('u_arcade_ignoreflood_search') && $this->user->data['games_last_search_term'] != $term)
					{
						$time = intval(time() - $interval);
						if ($this->user->data['games_last_search'] > $time)
						{
							trigger_error(sprintf($this->user->lang['ARCADE_NO_SEARCH_TIME'], $this->arcade->time_format($interval, true), $this->arcade->time_format($this->user->data['games_last_search'] - $time, true)) . $this->arcade->back_link());
						}

						$sql_ary = array(
							'games_last_search'			=> time(),
							'games_last_search_term'	=> $term,
						);

						$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
								SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
								WHERE user_id = ' . (int) $this->user->data['user_id'];
						$this->db->sql_query($sql);
					}

					$searchterm = '*' . strtolower($term) . '*';

					// define some vars for urls
					$hilit = implode('|', explode(' ', preg_replace('#\s+#u', ' ', str_replace(array('+', '-', '|', '(', ')', '&quot;'), '', $searchterm))));
					// Do not allow *only* wildcard being used for hilight
					$hilit = (strspn($hilit, '*') === strlen($hilit)) ? '' : $hilit;
					$hilit = (strspn($hilit, '?') === strlen($hilit)) ? '' : $hilit;

					if ($hilit)
					{
						// Remove bad highlights
						$hilit_array = array_filter(explode('|', $hilit), 'strlen');
						foreach ($hilit_array as $key => $value)
						{
							$hilit_array[$key] = str_replace(array('\*', '\?'), '\w*?', preg_quote($value, '#'));
							$hilit_array[$key] = preg_replace('#(^|\s)\\\\w\*\?(\s|$)#', '$1\w+?$2', $hilit_array[$key]);
						}
						$hilit = implode('|', $hilit_array);
					}

					$searchterm = str_replace('*', $this->db->get_any_char() , $searchterm);
					$searchterm = str_replace(array('?', '_'), $this->db->get_one_char() , $searchterm);

					if (!($total_games = $this->arcade->get()->total('game', 'search', $searchterm, false, true)))
					{
						trigger_error($this->user->lang['ARCADE_SEARCH_NO_MATCHES'] . $this->arcade->back_link());
					}

					$sql_array['WHERE'] .= ' AND g.game_name_clean ' . $this->db->sql_like_expression($searchterm) . '
						AND ' . $this->db->sql_in_set('g.cat_id', $this->arcade->get()->game_search_protection(), true, true);
					$pagination_mode = 'mode=search&amp;term=' . urlencode(htmlspecialchars_decode($term));
					$this->arcade->page_title = sprintf($this->user->lang['ARCADE_SEARCH_RESULTS_FOR'], $term);

					$search_matches = $this->user->lang('FOUND_SEARCH_MATCHES', $total_games);

					$this->template->assign_vars(array(
						'S_FOUND_RESULTS'	=> true,
						'SEARCH_TERM'		=> $term,
						'SEARCH_MATCHES'	=> $search_matches
					));
				}
			break;

			// Setup to display games inside specific category
			case 'cat':
			case 'stats':
				$cat_data = ($cat_id && !empty($this->arcade->cats()[$cat_id])) ? $this->arcade->cats()[$cat_id] : false;

				if (!$cat_data)
				{
					trigger_error($this->user->lang['NO_CAT_ID'] . $this->arcade->back_link());
				}

				// Permissions check
				if (!$this->arcade_auth->acl_gets('c_list', 'c_view', $cat_id) || ($cat_data['cat_type'] == ARCADE_LINK && $cat_data['cat_link'] && !$this->arcade_auth->acl_get('c_view', $cat_id)))
				{
					if ($this->user->data['user_id'] != ANONYMOUS)
					{
						trigger_error($this->user->lang['NO_PERMISSION_ARCADE_VIEW'] . $this->arcade->back_link());
					}

					login_box('', $this->user->lang['LOGIN_VIEWARCADE']);
				}

				if (!empty($cat_data['cat_games_per_page']))
				{
					$games_per_page = $cat_data['cat_games_per_page'];
				}

				// Is this category a link? ... User got here either because the
				// number of clicks is being tracked or they guessed the id
				if ($cat_data['cat_type'] == ARCADE_LINK && $cat_data['cat_link'])
				{
					// Does it have click tracking enabled?
					if ($cat_data['cat_flags'] & ARCADE_FLAG_LINK_TRACK)
					{
						$sql = 'UPDATE ' . ARCADE_CATS_TABLE . '
								SET cat_plays = cat_plays + 1
								WHERE cat_id = ' . (int) $cat_id;
						$this->db->sql_query($sql);
					}

					$this->cache->destroy('sql', ARCADE_CATS_TABLE);

					redirect($cat_data['cat_link'], false, true);
				}

				// Build navigation links
				$cat_data = $this->arcade->add_navlink((($mode == 'stats') ? 'cat_stat' : 'cat'), '', '', $cat_data);

				if ($this->arcade_auth->acl_get('c_view', $cat_id))
				{
					$this->arcade->display()->cat_rules($cat_data);
				}

				// age verify
				if ($cat_data['cat_age'])
				{
					$this->arcade->verify_age('cat', $cat_data['cat_age']);
				}

				// Category is passworded ... check whether access has been granted to this
				// user this session, if not show login box
				if ($cat_data['cat_password'])
				{
					$this->arcade->display()->cat_login_box($cat_data);
				}

				$this->template->assign_var('U_CATEGORY_STATS', ($cat_data['cat_type'] == ARCADE_CAT_GAMES && $this->auth->acl_get('u_arcade_viewstats')) ? $this->arcade->url("mode=stats&amp;c=$cat_id" . (($u_sort_param != '') ? "&amp;$u_sort_param" : '') . (($start) ? "&amp;start=$start" : '')) . '#arcade_top' : false);

				$this->arcade->display()->category($cat_data);

				$cat_test		= ($cat_data['cat_test'] == ARCADE_CAT_TEST) ? true : false;
				$s_use_points	= ($s_use_points && !$cat_test) ? true : false;
				$s_locked		= $this->arcade->get()->cat_locked($cat_data['cat_id']);

				if ($cat_test)
				{
					$this->template->assign_var('S_ARCADE_CAT_TEST_MODE', true);
				}

				$sql_array['WHERE'] .= ' AND g.cat_id = ' . (int) $cat_id;
				$pagination_mode = 'mode=cat&amp;c=' . (int) $cat_id;
				$this->arcade->page_title = ($mode == 'stats') ? sprintf($this->user->lang['ARCADE_CAT_STATS'], $cat_data['cat_name']) : $cat_data['cat_name'];

				// This is needed to determine where we are
				// when we are done playing a game and want
				// to return the same category page we were on
				$found_game = false;
				if ($game_id)
				{
					$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
					$result = $this->db->sql_query($sql);
					$row = $this->db->sql_fetchrowset($result);
					$this->db->sql_freeresult($result);

					$total_games = count($row);
					$prev_games = 0;
					foreach ($row as $game)
					{
						if ($game['game_id'] == $game_id)
						{
							$found_game = true;
							break;
						}
						$prev_games++;
					}

					if ($found_game)
					{
						$start = floor(($prev_games) / $games_per_page) * $games_per_page;
					}
				}

				if (!$total_games && (!$game_id || !$found_game))
				{
					$total_games = $this->arcade->get()->total('game', 'games', $cat_id, false, true);
				}
			break;

			default:
			break;
		}

		$this->arcade->valid_start($start, $total_games);

		$this->arcade->display()->main_box('arcade', $this->arcade_config['welcome_cats'], $this->arcade_config['search_cats']);

		if ($this->auth->acl_get('u_arcade_view_whoisplaying'))
		{
			$this->arcade->display()->online_playing();
		}

		$this->arcade->display()->page($this->user->lang['ARCADE'] . ' - ' . $this->arcade->page_title, 'arcade/index_body.html', false, false);
		$arcade_games_style = ($this->arcade_config['override_user_cat_style']) ? $this->arcade_config['default_cat_games_style'] : $this->user->data['arcade_cat_games_style'];

		$this->template->assign_vars(array(
			'S_ARCADE_CAT_BODY'					=> true,
			'S_GAME_COMMENT'					=> $this->arcade_config['game_comment'],
			'S_ARCADE_CAT_GAMES_STYLE_BASIC'	=> $arcade_games_style == ARCADE_CAT_STYLE_BASIC,
			'S_ARCADE_CAT_GAMES_STYLE_ARCADE'	=> $arcade_games_style == ARCADE_CAT_STYLE_ARCADE,

			'CAT_IMG'							=> $this->user->img('forum_read', 'NO_NEW_GAMES'),
			'CAT_NEW_IMG'						=> $this->user->img('forum_unread', 'NEW_GAMES'),
			'CAT_LOCKED_IMG'					=> $this->user->img('forum_read_locked', 'NEW_GAMES_LOCKED'),
			'CAT_NEW_LOCKED_IMG'				=> $this->user->img('forum_unread_locked', 'NO_NEW_GAMES_LOCKED')
		));

		// Not category with games
		if (isset($cat_data) && $cat_data['cat_type'] != ARCADE_CAT_GAMES)
		{
			page_footer();
		}

		// Ok, if someone has only list-access, we only display the category list.
		// We also make this circumstance available to the template in case we want to display a notice. ;)
		if (!$this->arcade_auth->acl_get('c_view', $cat_id) && $cat_id != ARCADE_FAV_ID && $cat_id != ARCADE_SEARCH_ID)
		{
			$this->template->assign_vars(array(
				'S_NO_VIEW_ACCESS' => true,
			));

			page_footer();
		}

		$this->template->assign_vars(array(
			'S_IN_GAMES'			=> (isset($cat_data['cat_type']) && $cat_data['cat_type'] == ARCADE_CAT_GAMES) ? true : false,
			'S_SELECT_SORT_DIR'		=> $s_sort_dir,
			'S_SELECT_SORT_KEY'		=> $s_sort_key,
			'S_ARCADE_ACTION'		=> $this->arcade->url("$pagination_mode&amp;start=$start")
		));

		if ($total_games)
		{
			$time = time();
			$arcade_game_count = 0;

			// Get the favorite games data for the current user...
			$game_fav_data = $this->arcade->get()->fav_data();

			$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
			$result = $this->db->sql_query_limit($sql, $games_per_page, $start);

			// Display the need games...
			if ($row = $this->db->sql_fetchrow($result))
			{
				do
				{
					$arcade_game_count++;
					$game_width = $game_height = 0;
					$this->arcade->set_game_size($game_width, $game_height, $row['game_width'], $row['game_height'], $row['game_swf'], $row['game_type']);
					$row['game_width']	= $game_width;
					$row['game_height']	= $game_height;
					$image_title		= $row['game_name'] . ' (' . (($row['game_filesize'] > 0 ) ? get_formatted_filesize($row['game_filesize']) : get_formatted_filesize($this->arcade->set_filesize($row['game_id']))) . ')';
					$hilit_search		= ($mode == 'search' && $search_id != 'newgames' && (!empty($hilit))) ? $hilit : false;
					$high_score_type	= ($row['game_scoretype'] == SCORETYPE_HIGH) ? true : false;

					if (!in_array($mode, array('cat', 'stats')))
					{
						$s_use_points	= ($s_use_points && $row['cat_test'] != ARCADE_CAT_TEST) ? true : false;
						$s_locked		= $this->arcade->get()->cat_locked($row['cat_id']);
					}

					$u_edit_game = false;
					if (!empty($this->user->data['is_registered']))
					{
						if ($this->auth->acl_get('a_arcade_game'))
						{
							$u_edit_game = append_sid("{$this->root_path}adm/index.{$this->php_ext}", $this->arcade->module_url('manage') . "&amp;mode=games&amp;action=edit&amp;g={$row['game_id']}", true, $this->user->session_id);
						}
						else if ($this->auth->acl_get('m_arcade_game'))
						{
							$u_edit_game = append_sid("{$this->root_path}mcp.{$this->php_ext}", $this->arcade->module_url('manage', 'm') . "&amp;mode=games&amp;action=edit&amp;g={$row['game_id']}", true, $this->user->session_id);
						}
					}

					$comment_display = ($this->arcade_config['game_comment'] && $row['comment_text'] !== '') ? generate_text_for_display($row['comment_text'], $row['comment_uid'], $row['comment_bitfield'], $row['comment_options']) : '';

					$gamesrow = array(
						'S_CAN_REPORT'			=> (!$s_locked && $this->arcade_auth->acl_get('c_report', $row['cat_id'])) ? true : false,
						'S_CAN_DOWNLOAD'		=> $this->arcade->game()->download_auth('user_cat', $row['cat_id'], $row['cat_download'], $row['game_download']),
						'S_GAME_PLAY'			=> (!$s_locked && $this->arcade_auth->acl_get('c_play', $row['cat_id'])) ? true : false,
						'S_GAME_HIGHSCORE'		=> ($row['user_id'] && $row['game_highdate'] > 0) ? true : false,
						'S_GAME_SCORE'			=> ($row['score'] != '') ? true : false,
						'S_USE_HIGHSCORES'		=> ($row['game_save_type'] != NOSCORE_GAME) ? true : false,
						'S_HIDDEN_HIGHSCORE'	=> ($row['user_id'] && $row['game_highdate'] > 0 && $this->arcade->hidden_score($row['game_id'], $row['user_id'])) ? true : false,
						'S_NEW_GAME'			=> ($search_id != 'newgames' && intval($time - $row['game_installdate']) <= intval($this->arcade_config['new_games_delay'] * 86400)) ? true : false,
						'S_TOPIC'				=> ($this->arcade_config['game_announce_forum'] && !empty($row['post_id']) && $this->auth->acl_get('f_read', $this->arcade_config['game_announce_forum'])) ? true : false,

						'CAT_ID'				=> $row['cat_id'],
						'CAT_NAME'				=> $row['cat_name'],
						'U_CAT'					=> $this->arcade->url("mode=cat&amp;c={$row['cat_id']}"),

						'GAME_ID'				=> $row['game_id'],
						'GAME_NAME'				=> $this->arcade->get()->gamename_tooltip($row, false, true, true, $hilit_search),
						'ORIG_GAME_NAME'		=> $this->arcade->get()->gamename_tooltip($row, false, true, true, $hilit_search, false),
						'GAME_IMAGE'			=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($row['game_image'], 50, 50, $image_title, 'play', $row['cat_id'], $row['game_id']) : false,
						'GAME_PLAYS'			=> ($row['game_plays']) ? sprintf($this->user->lang['ARCADE_TIMES_PLAYED'], $this->arcade->number_format($row['game_plays'])) : false,
						'GAME_DOWNLOAD'			=> ($row['game_download_total']) ? sprintf($this->user->lang['ARCADE_TIMES_DOWNLOADED'], $this->arcade->number_format($row['game_download_total'])) : false,
						'GAME_PLAY_POPUP'		=> $this->arcade->get()->game_popup('link', $row['cat_id'], $row['game_id'], $row['game_width'], $row['game_height']),
						'GAME_TYPE'				=> ($this->arcade_config['display_game_type']) ? $this->arcade->game()->type($row['game_type'], true) : false,
						'GAME_SAVE_TYPE'		=> ($this->arcade_config['display_game_save_type']) ? $this->arcade->game()->save_type($row['game_save_type'], true) : false,

						'U_GAME_PLAY'			=> $this->arcade->url("mode=play&amp;g={$row['game_id']}"),
						'U_GAME_DOWNLOAD'		=> $this->arcade->url("mode=download&amp;g={$row['game_id']}"),
						'U_GAME_HIGHSCORES'		=> $this->arcade->url("mode=stats&amp;g={$row['game_id']}"),
						'U_GAME_REPORT'			=> $this->arcade->url("mode=report&amp;g={$row['game_id']}"),
						'U_TOPIC'				=> $this->arcade->url("p={$row['post_id']}", 'viewtopic') . "#p{$row['post_id']}",
						'U_GAME_EDIT'			=> $u_edit_game,
						'U_SCORE_EDIT'			=> ($this->auth->acl_get('a_arcade_user') && !empty($this->user->data['is_registered']) && ($row['score_date'] || $row['super_score_date'])) ? append_sid("{$this->root_path}adm/index.{$this->php_ext}", $this->arcade->module_url('manage') . "&amp;mode=users&amp;action=show_scores&amp;g={$row['game_id']}", true, $this->user->session_id) : '',

						'HIGHLIGHTED'			=> !empty($row['highlighted']) ? true : false,
						'GAME_RATING_IMG'		=> $this->arcade->set_rating_image($row, $mode),
						'GAME_FAV_IMG'			=> (is_array($game_fav_data)) ? $this->arcade->set_fav_image($game_fav_data, $row['game_id'], $mode) : '',

						'GAME_HIGHSCORE'		=> ($row['user_id']) ? $this->arcade->number_format($row['game_highscore']) : '',
						'GAME_HIGHUSER'			=> ($row['user_id']) ? $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'arcade', 'x') : '',
						'GAME_HIGHDATE'			=> ($row['user_id']) ? $this->user->format_date($row['game_highdate']) : '',
						'GAME_COMMENT'			=> ($comment_display !== '') ? $comment_display : '&nbsp;',

						'PERSONAL_HIGHSCORE'	=> $this->arcade->number_format($row['score']),
						'PERSONAL_HIGHDATE'		=> ($row['score_date']) ? $this->user->format_date($row['score_date']) : '',
						'GAME_IMAGE_FIRST'		=> ($row['user_id'] == $this->user->data['user_id'] ) ? $this->arcade->get()->image('full', 'img', '1st.gif', 'ARCADE_FIRST', false, 'vertical-align: middle;') : '' ,
					);

					if ($this->arcade_config['cat_super_record'] && $row['game_save_type'] != NOSCORE_GAME && !empty($row['champ_user_id']))
					{
						$gamesrow = array_merge($gamesrow, array(
							'S_SUPER_RECORD'			=> (($high_score_type && $row['super_score'] > $row['game_highscore']) || (!$high_score_type && $row['super_score'] < $row['game_highscore']) || !$row['user_id']) ? true : false,
							'SUPER_RECORD_USER_NAME'	=> $this->arcade->get()->user_name('full', $row['champ_user_id'], $row['champ_username'], $row['champ_user_colour'], 'profile', 'x'),
							'SUPER_RECORD_SCORE'		=> (!$this->arcade->hidden_score($row['game_id'], $row['champ_user_id'])) ? $this->arcade->number_format($row['super_score']) : $this->user->lang['HIDDEN'],
							'SUPER_RECORD_SCORE_DATE'	=> $this->user->format_date($row['super_score_date'])
						));
					}

					if ($s_use_points)
					{
						$game_cost			= $this->arcade->points()->game_cost($row);
						$game_reward		= $this->arcade->points()->game_reward($row);
						$game_download_cost	= $this->arcade->points()->game_download_cost($row);

						$super_reward		= (float) $this->arcade_config['super_record_reward'];
						$no_score			= ($row['game_highuser'] == 0 && $row['game_highdate'] == 0) ? true : false;
						$add_points			= (!$no_score || $this->arcade_config['first_score_reward']) ? true : false;
						$add_points			= ($add_points && (!$this->arcade_auth->acl_get('c_playfree', $row['cat_id']) || $this->arcade_config['playfree_reward'])) ? true : false;

						$gamesrow = array_merge($gamesrow, array(
							'S_SHOW_POINTS'				=> true,
							'S_USE_JACKPOT'				=> ($this->arcade->points()->use_game_jackpot($row)) ? true : false,
							'S_SUPER_CHAMPION_REWARD'	=> ($super_reward > 0 && !empty($row['champ_user_id'])) ? true : false,

							'SUPER_CHAMPION_REWARD'		=> (!$super_reward) ? $this->user->lang['ARCADE_NONE'] : $this->arcade->number_format($super_reward) . ' ' . $this->arcade->points()->data['name'],
							'GAME_COST'					=> (!$game_cost || $game_cost == ARCADE_FREE || $this->arcade_auth->acl_get('c_playfree', $row['cat_id'])) ? $this->user->lang['ARCADE_NONE'] : $this->arcade->number_format($game_cost) . ' ' . $this->arcade->points()->data['name'],
							'GAME_REWARD'				=> (!$add_points || !$game_reward || $game_reward == ARCADE_FREE) ? $this->user->lang['ARCADE_NONE'] : $this->arcade->number_format($game_reward) . ' ' . $this->arcade->points()->data['name'],
							'DOWNLOAD_COST'				=> (!$game_download_cost || $game_download_cost == ARCADE_FREE || $this->arcade_auth->acl_get('c_downloadfree', $row['cat_id'])) ? $this->user->lang['ARCADE_FREE'] : $this->arcade->number_format($game_download_cost) . ' ' . $this->arcade->points()->data['name']
						));
					}

					$this->template->assign_block_vars('games', $gamesrow);
				}
				while ($row = $this->db->sql_fetchrow($result));
			}
			$this->db->sql_freeresult($result);

			$pagination_mode = $pagination_mode . (($u_sort_param != '') ? "&amp;$u_sort_param" : '');
			$this->arcade->container('phpbb_pagination')->generate_template_pagination($this->arcade->url($pagination_mode), 'pagination', 'start', $total_games, $games_per_page, $start);

			$this->template->assign_vars(array(
				'S_SHOW_POINTS'			=> $s_use_points,
				'S_SHOW_SUPER_RECORD'	=> ($this->arcade_config['cat_super_record']) ? true : false,

				'TOTAL_GAMES'			=> ($total_games) ? $this->user->lang['ARCADE_STATS_TOTAL_GAMES'] . ' (' . $total_games . ')' : false,
				'NEW_GAME_IMG'			=> ($total_games) ? $this->arcade->get()->image('full', 'img', 'new_game.gif', 'NEW_GAME') : ''
			));
		}

		if ($mode == 'cat' && $cat_data['cat_type'] == ARCADE_CAT_GAMES && $this->arcade_auth->acl_get('c_view', $cat_id))
		{
			$this->arcade->display()->cat_auth_level($cat_id, $cat_data['cat_download']);
		}

		page_footer();
	}
}
