<?php
/**
*
* @package phpBB Arcade
* @version $Id: points.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\detect;

class points
{
	public $data = array();

	protected $db, $config, $user, $arcade_config, $arcade;

	public function __construct($db, $config, $user, $arcade_config, $arcade)
	{
		$this->db = $db;
		$this->config = $config;
		$this->user = $user;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
	}

	public function main()
	{
		$this->data = array(
			'installed'	=> false,
			'show'		=> false,
			'type'		=> false,
			'enabled'	=> false,
			'name'		=> '',
			'total'		=> 0
		);

		// JV Points System
		if ($this->arcade->ext_enable('jv/points'))
		{
			if (!defined('USER_POINTS'))
			{
				define('USER_POINTS', 'user_points');
			}

			$this->data['installed'] = true;
			$this->data['type'] = ARCADE_JV_POINTS_SYSTEM;
			$this->data['enabled'] = !empty($this->config['jv_points_enable']);

			if ($this->data['enabled'])
			{
				$this->data['name'] = $this->config['jv_points_name'];
				$this->data['total'] = (float) $this->user->data[USER_POINTS];
			}
		}
		else if ($this->arcade->ext_enable('dmzx/ultimatepoints'))
		{
			if (!defined('USER_POINTS'))
			{
				define('USER_POINTS', 'user_points');
			}

			$this->data['installed'] = true;
			$this->data['type'] = ARCADE_ULTIMATE_POINTS_SYSTEM;
			$this->data['enabled'] = !empty($this->config['points_enable']);

			if ($this->data['enabled'])
			{
				$this->data['name'] = $this->config['points_name'];
				$this->data['total'] = (float) $this->user->data[USER_POINTS];
			}
		}

		$this->data['show'] = ($this->data['installed'] && $this->data['enabled'] && $this->arcade_config['use_points']) ? true : false;
	}

	public function user($user_id = false)
	{
		$total = 0;

		if (in_array($this->data['type'], array(ARCADE_JV_POINTS_SYSTEM, ARCADE_ULTIMATE_POINTS_SYSTEM)))
		{
			if (!$user_id || $user_id == $this->user->data['user_id'])
			{
				$total = $this->data['total'];
			}
			else
			{
				$sql = 'SELECT ' . USER_POINTS . '
						FROM ' . USERS_TABLE . '
						WHERE user_id = ' . (int) $user_id;
				$result = $this->db->sql_query($sql);
				$total = (float) $this->db->sql_fetchfield(USER_POINTS);
				$this->db->sql_freeresult($result);
			}
		}

		return $total;
	}

	public function set($mode, $user_id, $amount, $update = true)
	{
		// Return true if the amount is 0 or free (-1)
		if ($amount <= 0)
		{
			return true;
		}

		$result = false;
		$mode = strtolower($mode);
		switch ($mode)
		{
			case 'add':
				if (in_array($this->data['type'], array(ARCADE_JV_POINTS_SYSTEM, ARCADE_ULTIMATE_POINTS_SYSTEM)))
				{
					$sql = 'UPDATE ' . USERS_TABLE . '
							SET ' . USER_POINTS . ' = ' . USER_POINTS . ' + ' . $amount . '
							WHERE user_id = ' . (int) $user_id;
					$this->db->sql_query($sql);

					$result = true;
				}

			break;

			case 'subtract':
				if (in_array($this->data['type'], array(ARCADE_JV_POINTS_SYSTEM, ARCADE_ULTIMATE_POINTS_SYSTEM)))
				{
					// The user does not have enough points
					if ($this->user->data[USER_POINTS] < $amount)
					{
						$result = false;
					}
					else
					{
						$sql = 'UPDATE ' . USERS_TABLE . '
								SET ' . USER_POINTS . ' = ' . USER_POINTS . ' - ' . $amount . '
								WHERE user_id = ' . (int) $user_id;
						$this->db->sql_query($sql);

						$result = true;
					}
				}

			break;
		}

		// If setting points was successful, update the users current total for display as well
		if ($result && $this->user->data['user_id'] == $user_id)
		{
			if ($mode == 'add')
			{
				$this->data['total'] = $this->data['total'] + $amount;
			}
			else
			{
				$this->data['total'] = $this->data['total'] - $amount;
			}

			if ($update)
			{
				$this->user->data[USER_POINTS] = $this->data['total'];
			}
		}

		return $result;
	}

	public function game_cost($data)
	{
		$cost = 0;
		$game_cost = (float) $data['game_cost'];
		$cat_cost = (float) $data['cat_cost'];

		if (!empty($game_cost))
		{
			$cost = $game_cost;
		}
		else if (!empty($cat_cost))
		{
			$cost = $cat_cost;
		}
		else
		{
			$cost = (float) $this->arcade_config['game_cost'];
		}

		return $cost;
	}

	public function game_reward($data)
	{
		$reward = 0;

		if ($this->use_game_jackpot($data))
		{
			$reward = (float) $data['game_jackpot'];
		}
		else
		{
			$game_reward = (float) $data['game_reward'];
			$cat_reward = (float) $data['cat_reward'];

			if (!empty($game_reward))
			{
				$reward = $game_reward;
			}
			else if (!empty($cat_reward))
			{
				$reward = $cat_reward;
			}
			else
			{
				$reward = (float) $this->arcade_config['game_reward'];
			}
		}

		return $reward;
	}

	public function use_game_jackpot($data)
	{
		$result = false;

		if (!empty($data['game_use_jackpot']))
		{
			$result = true;
		}
		else if (!empty($data['cat_use_jackpot']))
		{
			$result = true;
		}
		else
		{
			$result = $this->arcade_config['use_jackpot'];
		}

		return $result;
	}

	public function game_download_cost($data)
	{
		$cost = 0;
		$game_download_cost = (float) $data['game_download_cost'];
		$cat_download_cost = (float) $data['cat_download_cost'];

		if (!empty($game_download_cost))
		{
			$cost = $game_download_cost;
		}
		else if (!empty($cat_download_cost))
		{
			$cost = $cat_download_cost;
		}
		else
		{
			$cost = (float) $this->arcade_config['game_download_cost'];
		}

		return $cost;
	}

	public function set_game_jackpot($mode, $data)
	{
		$mode = strtolower($mode);
		switch ($mode)
		{
			case 'add':
				$cost = $this->game_cost($data);

				// Return if the amount is 0 or free (-1)
				if ($cost <= 0)
				{
					return false;
				}

				// Make sure jackpot is not less than the minimum
				$jackpot = ($data['game_jackpot'] < $this->arcade_config['jackpot_minimum']) ? $this->arcade_config['jackpot_minimum'] : $data['game_jackpot'];
				// Add to jackpot
				$jackpot += $cost;
				// Make sure jackpot is not more than the maximum if a maximum is set
				if ($this->arcade_config['jackpot_maximum'] && $jackpot > $this->arcade_config['jackpot_maximum'])
				{
					$jackpot = $this->arcade_config['jackpot_maximum'];
				}

				$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
						SET game_jackpot = ' . (float) $jackpot . '
						WHERE game_id = ' . (int) $data['game_id'];
				$this->db->sql_query($sql);

				return $jackpot;
			break;

			case 'clear':
				$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
						SET game_jackpot = ' . (float) $this->arcade_config['jackpot_minimum'] . '
						WHERE game_id = ' . (int) $data['game_id'];
				$this->db->sql_query($sql);
			break;
		}

		return false;
	}

	public function get_games_jackpot()
	{
		static $_cache_jackpot_game_ids;

		if (!isset($_cache_jackpot_game_ids))
		{
			$sql = 'SELECT game_id, game_use_jackpot, cat_id
					FROM ' . ARCADE_GAMES_TABLE . '
					WHERE game_jackpot > 0
					AND ' . $this->db->sql_in_set('cat_id', $this->arcade->get->permissions(array('c_view', 'c_play')), false, true) . '
					ORDER BY game_jackpot DESC';
			$result = $this->db->sql_query($sql);
			$_cache_jackpot_game_ids = array();
			while ($row = $this->db->sql_fetchrow($result))
			{
				$row['cat_use_jackpot'] = $this->arcade->get->cat_field($row['cat_id'], 'cat_use_jackpot');

				if ($this->use_game_jackpot($row))
				{
					$_cache_jackpot_game_ids[] = $row['game_id'];
				}
			}
			$this->db->sql_freeresult($result);
		}

		return $_cache_jackpot_game_ids;
	}

	public function get_games_big_cost($cost = 0)
	{
		static $_cache_big_cost_game_ids;

		$cost = (float) $cost;

		if (!isset($_cache_big_cost_game_ids) || $cost)
		{
			$game_ids = array();

			if ($this->data['show'])
			{
				$sql = 'SELECT g.game_id, g.game_cost, c.cat_cost, c.cat_id
						FROM ' . ARCADE_GAMES_TABLE . ' g
						LEFT JOIN ' . ARCADE_CATS_TABLE . ' c ON g.cat_id = c.cat_id
						WHERE	((g.game_cost > 0) OR
								 (g.game_cost > ' . ARCADE_FREE . ' AND c.cat_cost > 0) OR
								 (g.game_cost > ' . ARCADE_FREE . ' AND c.cat_cost > ' . ARCADE_FREE . ' AND ' . (float) $this->arcade_config['game_cost'] . ' > 0)
								)
						AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get->permissions('c_playfree'), true, true);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					if (($this->game_cost($row) + $cost) > $this->data['total'])
					{
						// can not play game ids
						$game_ids[] = $row['game_id'];
					}
				}
				$this->db->sql_freeresult($result);
			}

			if (!$cost)
			{
				$_cache_big_cost_game_ids = $game_ids;
			}
		}

		return ($cost) ? $game_ids : $_cache_big_cost_game_ids;
	}
}
