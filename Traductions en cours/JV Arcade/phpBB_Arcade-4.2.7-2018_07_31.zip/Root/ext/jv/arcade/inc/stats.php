<?php
/**
*
* @package phpBB Arcade
* @version $Id: stats.php 2035 2018-07-25 11:10:48Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class stats
{
	protected $db, $auth, $request, $user, $template, $arcade_config, $arcade_auth, $arcade;

	public function __construct($db, $auth, $request, $user, $template, $arcade_config, $arcade_auth, $arcade)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
	}

	public function display($mode, $type, $user_id, $game_id, $tour_id, $start, $detailed_stats)
	{
		global $arcade_page, $limit_cat, $sort_by_text, $sort_by_sql, $sort_cat, $sort_key, $sort_dir, $s_limit_cat, $s_sort_key, $s_sort_dir, $u_sort_param;

		$sort_cat = $this->request->variable('st', 0);
		$sort_key = $this->request->variable('sk', '');
		$sort_dir = $this->request->variable('sd', '');

		$limit_cat = array();
		$actual_rank = $start;
		$params = "mode=$mode";
		$s_arcade_stats_dkey = false;
		$total_data = $last_value = $rank = 0;
		$lang_key = $s_limit_cat = $s_sort_key = $s_sort_dir = $u_sort_param = '';

		$this->template->assign_var('S_IN_STATS', true);

		if ($detailed_stats)
		{
			$params .= "&amp;ds=$detailed_stats";
			$title_key	= 'ARCADE_DETAILED_STAT';
			$this->arcade->get()->detailed_stats($detailed_stats, $lang_key);

			if (in_array($detailed_stats, array('played_games', 'not_played_games', 'favs', 'rated_games', 'games_jackpots', 'challenge_played_games', 'tours_played_games')) || ($detailed_stats == 'super_champions' && $user_id))
			{
				$limit_cat = $this->arcade->get()->user_categories($user_id);
			}
			else
			{
				$sort_cat = 0;
			}

			switch ($detailed_stats)
			{
				case 'played_games':
					$s_arcade_stats_dkey = 'S_PLAYED_GAMES';
					$this->arcade->page_title($lang_key, $title_key, $params, "st=$sort_cat");
					$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 'p' => $this->user->lang['ARCADE_GAMES_SORT_PLAYS'], 'u' => $this->user->lang['ARCADE_PLAYED_USERS'], 't' => $this->user->lang['ARCADE_STATS_TOTAL_TIME'], 'a' => $this->user->lang['ARCADE_STATS_AVG']);
					$sort_by_sql = array('g' => 'g.game_name_clean', 'p' => 't_plays', 'u' => 't_users', 't' => 't_time', 'a' => 'SUM(p.total_time) / SUM(p.total_plays)');
					$this->gen_data('game', 'played_games', $start, $total_data);
				break;

				case 'not_played_games':
					$sort_dir = ($sort_dir) ? $sort_dir : 'a';
					$s_arcade_stats_dkey = 'S_NOT_PLAYED_GAMES';
					$this->arcade->page_title($lang_key, $title_key, $params, "st=$sort_cat");
					$sort_by_text = array('p' => $this->user->lang['ARCADE_GAME_NAME'], 's' => $this->user->lang['ARCADE_SUPER_CHAMPIONS']);
					$sort_by_sql = array('p' => 'g.game_name_clean', 's' => 'u.username_clean');
					$this->gen_data('game', 'not_played_games', $start, $total_data);
				break;

				case 'played_users':
					$s_arcade_stats_dkey = 'S_PLAYED_USERS';
					$this->arcade->page_title($lang_key, $title_key, $params);
					$sort_by_text = array('u' => $this->user->lang['USERNAME'], 'p' => $this->user->lang['ARCADE_GAMES_SORT_PLAYS'], 'g' => $this->user->lang['ARCADE_STATS_TOTAL_GAMES'], 't' => $this->user->lang['ARCADE_STATS_TOTAL_TIME'], 'a' => $this->user->lang['ARCADE_STATS_AVG']);
					$sort_by_sql = array('u' => 'u.username_clean', 'p' => 't_plays', 'g' => 'games_count', 't' => 't_time', 'a' => 'au.arcade_total_time / au.arcade_total_plays');
					$this->gen_data('user', 'played_users', $start, $total_data);
				break;

				case 'highscores':
					$s_arcade_stats_dkey = 'S_ARCADE_HIGHSCORES';
					$this->arcade->page_title($lang_key, $title_key, $params);
					$sort_by_text = array('u' => $this->user->lang['USERNAME'], 'p' => $this->user->lang['ARCADE_TROPHYS'], 'g' => $this->user->lang['ARCADE_GAMES_SORT_PLAYS'], 't' => $this->user->lang['ARCADE_STATS_TOTAL_TIME']);
					$sort_by_sql = array('u' => 'u.username_clean', 'p' => 'total_wins', 'g' => 'total_plays', 't' => 'total_times');
					$this->gen_data('user', 'highscores', $start, $total_data);
				break;

				case 'super_champions':
					if ($user_id)
					{
						$method = 'game';
						$username = $this->arcade->userdata('username', $user_id);
						$this->arcade->add_navlink('add', $params, $this->user->lang[$title_key] . '&nbsp;-&nbsp;' . $this->user->lang['ARCADE_SUPER_CHAMPIONS'], '', false);
						$params .= "&amp;u=$user_id";
						$this->arcade->add_navlink('add', $params, $username, '', false);
						$this->arcade->page_title($this->user->lang['ARCADE_SUPER_CHAMPION'] . ' :: ' . $username, $title_key, $params, "st=$sort_cat", true);

						$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 's' => $this->user->lang['ARCADE_SCORE'], 'p' => $this->user->lang['ARCADE_DATE']);
						$sort_by_sql = array('g' => 'g.game_name_clean', 's' => 's.score', 'p' => 's.score_date');
						$this->template->assign_var('S_ARCADE_SUPER_CHAMPION_GAMES', true);
					}
					else
					{
						$method = 'user';
						$user_id = false;
						$this->arcade->page_title($lang_key, $title_key, $params);
						$sort_by_text = array('u' => $this->user->lang['USERNAME'], 'p' => $this->user->lang['ARCADE_GAMES']);
						$sort_by_sql = array('u' => 'u.username_clean', 'p' => 'total_wins');
					}

					$s_arcade_stats_dkey = 'S_ARCADE_SUPER_CHAMPIONS';
					$this->gen_data($method, 'super_champions', $start, $total_data, $user_id);
				break;

				case 'favs':
					$s_arcade_stats_dkey = 'S_ARCADE_FAVS';
					$this->arcade->page_title(str_replace('FAVS', 'GAME_FAVS', $lang_key), $title_key, $params, "st=$sort_cat");
					$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 'p' => $this->user->lang['USERS']);
					$sort_by_sql = array('g' => 'g.game_name_clean', 'p' => 'total');
					$this->gen_data('game', 'favs', $start, $total_data);
				break;

				case 'rated_games':
					$sort_dir = ($sort_dir) ? $sort_dir : 'd';
					$s_arcade_stats_dkey = 'S_ARCADE_RATED_GAMES';
					$this->arcade->page_title($lang_key, $title_key, $params, "st=$sort_cat");
					$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 'p' => $this->user->lang['ARCADE_RATING_GAME']);
					$sort_by_sql = array('g' => 'g.game_name_clean', 'p' => 'rating_avg ' . (($sort_dir == 'd') ? 'DESC' : 'ASC') . ', g.game_votetotal');
					$this->gen_data('game', 'rated_games', $start, $total_data);
				break;

				case 'games_jackpots':
					$s_arcade_stats_dkey = 'S_ARCADE_GAMES_JACKPOTS';
					$this->arcade->page_title($lang_key, $title_key, $params, "st=$sort_cat");
					$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 'p' => $this->user->lang['ARCADE_JACKPOT']);
					$sort_by_sql = array('g' => 'g.game_name_clean', 'p' => 'g.game_jackpot');
					$this->gen_data('game', 'games_jackpots', $start, $total_data);
				break;

				case 'challenge_played_games':
				case 'tours_played_games':
					$s_arcade_stats_dkey = 'S_TOUR_PLAYED_GAMES';
					$this->arcade->page_title($lang_key, $title_key, $params, "st=$sort_cat");
					$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 'p' => $this->user->lang['ARCADE_GAMES_SORT_PLAYS'], 't' => $this->user->lang['ARCADE_STATS_TOTAL_TIME'], 'a' => $this->user->lang['ARCADE_STATS_AVG']);
					$avg = ($detailed_stats == 'challenge_played_games') ? '(SUM(cc.champ_challenger_time) + SUM(cc.champ_opponent_time)) / COUNT(cc.champ_id)' : 'SUM(tc.total_time) / SUM(tc.total_plays)';
					$sort_by_sql = array('g' => 'g.game_name_clean', 'p' => 't_plays', 't' => 't_time', 'a' => $avg);
					$this->gen_data('game', (($arcade_page == 'challenge') ? 'challenge' : 'tour') . '_played_games', $start, $total_data);
				break;

				case 'challenge_played_users':
				case 'tours_played_users':
					$s_arcade_stats_dkey = 'S_TOUR_PLAYED_USERS';
					$this->arcade->page_title($lang_key, $title_key, $params);
					$sort_by_text = array('u' => $this->user->lang['USERNAME'], 'p' => $this->user->lang['ARCADE_GAMES_SORT_PLAYS']);
					$sort_by_sql = array('u' => 'u.username_clean', 'p' => 't_plays');
					$this->gen_data('user', (($arcade_page == 'challenge') ? 'challenge' : 'tour') . '_played_users', $start, $total_data);
				break;

				case 'challenge_winners':
					$this->template->assign_var('S_ARCADE_CHALL_WINNERS', true);
				case 'tours_winners':
					$s_arcade_stats_dkey = 'S_ARCADE_TOUR_WINNERS';
					$this->arcade->page_title($lang_key, $title_key, $params);
					$sort_by_text = array('u' => $this->user->lang['USERNAME'], 'p' => $this->user->lang['ARCADE_TROPHYS']);
					$sort_by_sql = array('u' => 'u.username_clean', 'p' => 'total_wins');

					$this->gen_data('user', (($arcade_page == 'challenge') ? 'challenge' : 'tour') . '_winners', $start, $total_data);
				break;

				default:
					trigger_error($this->user->lang['ARCADE_NO_DETAILED_STAT'] . $this->arcade->back_link());
				break;
			}
		}
		else
		{
			if (in_array($type, array('challenge', 'tournament')))
			{
				$params .= "&amp;type=$type";
			}

			$this->arcade->add_navlink('add', $params, 'ARCADE_STATS');

			if ($type == 'challenge')
			{
				if (($game_id && $user_id) || ($user_id))
				{
					$uid = false;
					$winner = $this->request->variable('w', false);
					$profile = (!$game_id) ? true : false;
					$userdata = $this->arcade->display()->user_info('stats', 'challenge', $user_id, $profile);

					$winner_sql		= ($winner) ? ' AND cc.champ_winner = ' . (int) $user_id : '';
					$game_sql		= ($game_id) ? ' AND cc.game_id = ' . (int) $game_id : '';
					$sql_cat_limit	= '';

					$sort_key = ($sort_key) ? $sort_key : 't';
					$sort_dir = ($sort_dir) ? $sort_dir : 'd';
					$limit_cat = $this->arcade->challenge()->get_user_categories($user_id, $winner);

					$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 'u' => $this->user->lang['CHALLENGE_OPPONENT'], 't' => $this->user->lang['CHALLENGE_END_DATE']);
					$sort_by_sql = array('g' => 'g.game_name_clean', 'u' => 'u.username_clean', 't' => 'cc.champ_end_time');

					if ($game_id)
					{
						unset($sort_by_text['g'], $sort_by_sql['g']);
					}

					gen_sort_selects($limit_cat, $sort_by_text, $sort_cat, $sort_key, $sort_dir, $s_limit_cat, $s_sort_key, $s_sort_dir, $u_sort_param);

					$sql_cat_limit = ($sort_cat) ? ' AND g.cat_id = ' . (int) $sort_cat : '';
					$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

					$sql_array = array(
						'SELECT'	=> 'COUNT(cc.champ_id) AS total_data',
						'FROM'		=> array(ARCADE_CHALLENGE_CHAMP_TABLE	=> 'cc'),
						'LEFT_JOIN'	=> array(
							array('FROM' => array(ARCADE_GAMES_TABLE		=> 'g'), 'ON' => 'cc.game_id = g.game_id'),
							array('FROM' => array(ARCADE_CATS_TABLE			=> 'c'), 'ON' => 'g.cat_id = c.cat_id'),
							array('FROM' => array(USERS_TABLE				=> 'u'), 'ON' => '((cc.champ_challenger_id = u.user_id) OR (cc.champ_opponent_id = u.user_id))'),
						),
						'WHERE'		=> 'cc.champ_close = ' . CHALLENGE_CLOSE . '
							AND u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
							AND u.user_id <> ' . (int) $user_id . '
							AND ((cc.champ_challenger_id = ' . (int) $user_id . ') OR (cc.champ_opponent_id = ' . (int) $user_id . '))
							AND g.cat_id = c.cat_id' . $sql_cat_limit . $game_sql . $winner_sql . '
							AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions('c_view'), false, true)
					);
					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query($sql);
					$total_data = (int) $this->db->sql_fetchfield('total_data');
					$this->db->sql_freeresult($result);

					if (!$total_data)
					{
						if (!$game_id)
						{
							$msgkey = ($winner) ? 'CHELLENGE_NO_WINNER' : 'CHALLENGE_USER_NO_PLAYED';
						}
						else
						{
							$msgkey = 'CHALLENGE_PLAYED_NO_GAME';
						}

						//trigger_error($this->user->lang[$msgkey] . $this->arcade->back_link($params, 'challenge_stats'));
					}
					else
					{
						$this->arcade->valid_start($start, $total_data);

						$sql_array = array(
							'SELECT'	=> 'g.game_id, g.game_name, g.game_name_clean, g.game_image,
											cc.*,
											u.username, u.username_clean, u.user_id, u.user_colour,
											c.cat_id, c.cat_name, c.cat_type, c.parent_id, c.cat_parents, c.left_id, c.right_id, c.cat_desc, c.cat_desc_options, c.cat_desc_uid, c.cat_desc_bitfield',
							'FROM'		=> array(ARCADE_CHALLENGE_CHAMP_TABLE	=> 'cc'),
							'LEFT_JOIN'	=> array(
								array('FROM' => array(ARCADE_GAMES_TABLE		=> 'g'), 'ON' => 'cc.game_id = g.game_id'),
								array('FROM' => array(ARCADE_CATS_TABLE			=> 'c'), 'ON' => 'g.cat_id = c.cat_id'),
								array('FROM' => array(USERS_TABLE				=> 'u'), 'ON' => '((cc.champ_challenger_id = u.user_id) OR (cc.champ_opponent_id = u.user_id))'),
							),
							'WHERE'		=> 'cc.champ_close = ' . CHALLENGE_CLOSE . '
								AND u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
								AND u.user_id <> ' . (int) $user_id . '
								AND ((cc.champ_challenger_id = ' . (int) $user_id . ') OR (cc.champ_opponent_id = ' . (int) $user_id . '))
								AND g.cat_id = c.cat_id' . $sql_cat_limit . $game_sql . $winner_sql . '
								AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions('c_view'), false, true),
							'ORDER_BY'	=> $sql_sort
						);
						$sql = $this->db->sql_build_query('SELECT', $sql_array);
						$result = $this->db->sql_query_limit($sql, $this->arcade_config['stat_items_per_page'], $start);
						$game_count = 0;
						$uid = (!$game_id) ? $user_id : false;
						while ($row = $this->db->sql_fetchrow($result))
						{
							if (!$game_count)
							{
								if ($game_id && $user_id)
								{
									$this->arcade->add_navlink('cat_game', $params, '', $row);
									$this->template->assign_var('S_GAME_NAME', $row['game_name']);
								}
								else if ($sort_cat)
								{
									$this->arcade->add_navlink('add', "$params&amp;cat_id=$sort_cat", $row['cat_name']);
								}
							}

							$game_count++;
							$game_name	= $row['game_name'];
							$scorea		= ($user_id == $row['champ_challenger_id']) ? $row['champ_challenger_score'] : $row['champ_opponent_score'];
							$scoreb		= ($user_id == $row['champ_challenger_id']) ? $row['champ_opponent_score'] : $row['champ_challenger_score'];
							$play_timea	= ($user_id == $row['champ_challenger_id']) ? $row['champ_challenger_time'] : $row['champ_opponent_time'];
							$play_timeb	= ($user_id == $row['champ_challenger_id']) ? $row['champ_opponent_time'] : $row['champ_challenger_time'];
							$game_title	= ($uid) ? sprintf($this->user->lang['ARCADE_VIEW_CHALLENGE_MEMBER_STATS'], $userdata['username']) : 'x';

							$this->template->assign_block_vars('challengerow', array(
								'GAME_IMAGE'		=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($row['game_image'], 20, 20, $game_title, 'challenge', $row['cat_id'], $row['game_id'], $uid) : false,
								'GAME_NAME'			=> $this->arcade->get()->game_name($row['game_name'], false, 'challenge', $row['cat_id'], $row['game_id'], $game_title, false, false, $uid),
								'GAME_IMAGE_FIRST'	=> ($row['champ_winner'] == $user_id) ? $this->arcade->get()->leaders_image(1) : '',

								'SCOREA'			=> $this->arcade->number_format($scorea),
								'PLAY_TIMEA'		=> $this->arcade->time_format($play_timea),
								'OPPONENT_USERNAME'	=> $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'challenge', 'x'),
								'SCOREB'			=> $this->arcade->number_format($scoreb),
								'PLAY_TIMEB'		=> $this->arcade->time_format($play_timeb),
								'END_TIME'			=> $this->user->format_date($row['champ_end_time'])
							));
						}
						$this->db->sql_freeresult($result);
					}

					$this->arcade->display()->user_online($user_id);
					$this->arcade->display()->user_favs($user_id);

					$s_arcade_stats_dkey = 'S_USER_STATS';
					$params .= "&amp;u=$user_id";
					$this->arcade->add_navlink('add', $params, $userdata['username'], '', false);
					$params .= (!$uid && $game_id) ? "&amp;g=$game_id" : '';
					$params2 = $params . (($winner) ? '' : '&amp;w=1');
					$params .= ($winner) ? '&amp;w=1' : '';

					$this->template->assign_vars(array(
						'L_ARCADE_USER_STATS_TYPE'	=> $this->user->lang['ARCADE_VIEW_ALL' . (($winner) ? '' : '_WON') . '_CHALLENGE'],
						'U_ARCADE_USER_STATS_TYPE'	=> $this->arcade->url($params2) . '#usergamebox'
					));

					if (!$game_id)
					{
						$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_USER_STATS'], $userdata['username']));
					}
					else
					{
						$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_GAME_NAME'], $game_name), sprintf($this->user->lang['ARCADE_V_USER_STATS'], $userdata['username']));
					}
				}
				else if ($game_id)
				{
					$game_data = $this->arcade->get()->game_cat_data($game_id);

					$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_GAME_STATS'], $game_data['game_name']));
					$this->arcade->add_navlink('cat_game', $params, '', $game_data);

					$sql_array = array(
						'SELECT'	=> 'COUNT(cc.champ_id) AS total_plays, SUM(cc.champ_challenger_time + cc.champ_opponent_time) AS total_time',
						'FROM'		=> array(ARCADE_CHALLENGE_CHAMP_TABLE	=> 'cc'),
						'LEFT_JOIN'	=> array(
							array('FROM' => array(USERS_TABLE				=> 'u1'), 'ON' => 'cc.champ_challenger_id = u1.user_id'),
							array('FROM' => array(USERS_TABLE				=> 'u2'), 'ON' => 'cc.champ_opponent_id = u2.user_id'),
						),
						'WHERE'		=> 'cc.champ_close = ' . CHALLENGE_CLOSE . '
							AND cc.game_id = ' . (int) $game_data['game_id'] . '
							AND u1.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
							AND u2.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')'
					);
					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query($sql);
					$total = $this->db->sql_fetchrow($result);
					$this->db->sql_freeresult($result);

					$total_data	= (int) $total['total_plays'];
					$game_data	= array_merge($game_data, array(
						'total_plays'	=> $total_data,
						'total_time'	=> (int) $total['total_time']
					));

					if (!$total_data)
					{
						trigger_error(sprintf($this->user->lang['ARCADE_CHALLENGE_GAME_NO_PLAYS'], $this->arcade->get()->game_field($game_data['game_id'], 'game_name')) . $this->arcade->back_link($params, 'challenge_stats'));
					}

					$this->arcade->valid_start($start, $total_data);

					$sql_array = array(
						'SELECT'	=> 'cc.champ_challenger_id, cc.champ_challenger_score, cc.champ_challenger_time, cc.champ_opponent_score, cc.champ_opponent_time, cc.champ_end_time,
										u1.user_id, u1.username, u1.user_colour,
										u2.user_id AS o_user_id, u2.username AS o_username, u2.user_colour AS o_user_colour',
						'FROM'		=> array(ARCADE_CHALLENGE_CHAMP_TABLE	=> 'cc'),
						'LEFT_JOIN'	=> array(
							array('FROM' => array(USERS_TABLE				=> 'u1'), 'ON' => 'cc.champ_challenger_id = u1.user_id'),
							array('FROM' => array(USERS_TABLE				=> 'u2'), 'ON' => 'cc.champ_opponent_id = u2.user_id'),
						),
						'WHERE'		=> 'cc.champ_close = ' . CHALLENGE_CLOSE . '
								AND cc.game_id = ' . (int) $game_id . '
								AND u1.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
								AND u2.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')',
						'ORDER_BY'	=> 'cc.champ_end_time DESC'
					);
					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query_limit($sql, $this->arcade_config['stat_items_per_page'], $start);
					while ($row = $this->db->sql_fetchrow($result))
					{
						$c_score		= ($row['user_id'] == $row['champ_challenger_id']) ? $row['champ_challenger_score'] : $row['champ_opponent_score'];
						$o_score		= ($row['user_id'] == $row['champ_challenger_id']) ? $row['champ_opponent_score'] : $row['champ_challenger_score'];
						$c_play_time	= ($row['user_id'] == $row['champ_challenger_id']) ? $row['champ_challenger_time'] : $row['champ_opponent_time'];
						$o_play_time	= ($row['user_id'] == $row['champ_challenger_id']) ? $row['champ_opponent_time'] : $row['champ_challenger_time'];

						$this->template->assign_block_vars('scorerow', array(
							'CHALLENGER'	=> $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'challenge', 'x'),
							'C_SCORE'		=> $this->arcade->number_format($c_score),
							'C_TIME'		=> $this->arcade->time_format($c_play_time),
							'OPPONENT'		=> $this->arcade->get()->user_name('full', $row['o_user_id'], $row['o_username'], $row['o_user_colour'], 'challenge', 'x'),
							'O_SCORE'		=> $this->arcade->number_format($o_score),
							'O_TIME'		=> $this->arcade->time_format($o_play_time),
							'DATE'			=> $this->user->format_date($row['champ_end_time'])
						));
					}
					$this->db->sql_freeresult($result);

					$s_arcade_stats_dkey = 'S_GAME_STATS';
					$params .= "&amp;g={$game_data['game_id']}";

					$this->gen_game_data($game_data);
				}
				else
				{
					$this->main_data('challenge');
				}

				$this->arcade->display()->main_box('challenge', $this->arcade_config['challenge_welcome_stats']);
			}
			else if ($type == 'tournament')
			{
				$this->template->assign_var('S_ARCADE_TOUR_STATS', true);

				if ($sort_cat || $tour_id)
				{
					$tour_id = ($sort_cat) ? $sort_cat : $tour_id;

					$tour_name = $this->arcade->get()->tour_field($tour_id, 'tour_name');
					$this->arcade->add_navlink('add', "$params&amp;tour_id=$tour_id", $tour_name);
					$this->template->assign_var('TOUR_NAME', $tour_name);
				}

				if (($tour_id && $user_id) || $user_id)
				{
					$won = $this->request->variable('w', 0);

					$wons_sql = ($won && !$game_id) ? ' AND tw.user_id = ' . (int) $user_id : '';
					$game_sql = ($game_id) ? ' AND t.tour_id = ' . (int) $tour_id . ' AND tc.game_id = ' . (int) $game_id : '';

					$sql_tour_limit = '';
					$sql_sort = 'g.game_name_clean ASC';

					if (!$game_id)
					{
						$sort_key = ($sort_key) ? $sort_key : 'g';
						$sort_dir = ($sort_dir) ? $sort_dir : 'a';
						$limit_cat = $this->arcade->tournament->get_user_tours($user_id, $won);
						$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 's' => $this->user->lang['ARCADE_SCORE'], 'd' => $this->user->lang['ARCADE_DATE'], 'p' => $this->user->lang['ARCADE_CHAMPION_PLAYED'], 'm' => $this->user->lang['ARCADE_STATS_TOTAL_TIME'], 't' => $this->user->lang['ARCADE_STATS_AVG']);
						$sort_by_sql = array('g' => 'g.game_name_clean', 's' => 'tc.score', 'd' => 'tc.score_date', 'p' => 'tc.total_plays', 'm' => 'tc.total_time', 't' => 'tc.total_time / tc.total_plays');

						gen_sort_selects($limit_cat, $sort_by_text, $tour_id, $sort_key, $sort_dir, $s_limit_cat, $s_sort_key, $s_sort_dir, $u_sort_param);

						$sql_tour_limit = ($tour_id) ? ' AND t.tour_id = ' . (int) $tour_id : '';
						$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');
					}

					$sql_array = array(
						'SELECT'	=> 'COUNT(g.game_id) AS total_data',
						'FROM'		=> array(ARCADE_TOUR_TABLE => 't'),
						'LEFT_JOIN'	=> array(
							array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE	=> 'tc'), 'ON' => 't.tour_id = tc.tour_id'),
							array('FROM' => array(ARCADE_TOUR_WINS_TABLE	=> 'tw'), 'ON' => 'tc.tour_id = tw.tour_id AND tc.user_id = tw.user_id AND tc.game_id = tw.game_id'),
							array('FROM' => array(ARCADE_GAMES_TABLE		=> 'g'),  'ON' => 'tc.game_id = g.game_id'),
							array('FROM' => array(ARCADE_CATS_TABLE			=> 'c'),  'ON' => 'g.cat_id = c.cat_id'),
							array('FROM' => array(USERS_TABLE				=> 'u'),  'ON' => 'tc.user_id = u.user_id'),
						),
						'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
							AND t.tour_status = ' . ARCADE_END_TOUR . '
							AND g.cat_id = c.cat_id
							AND u.user_id = ' . (int) $user_id . $sql_tour_limit . $game_sql . $wons_sql . '
							AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions('c_view'), false, true)
					);
					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query($sql);
					$total_data = (int) $this->db->sql_fetchfield('total_data');
					$this->db->sql_freeresult($result);

					if (!$total_data)
					{
						if (!$game_id)
						{
							$msgkey = ($won) ? 'ARCADE_USER_NO_HIGHSCORES' : 'ARCADE_PLAYED_NO_GAMES';
						}
						else
						{
							$msgkey = 'ARCADE_PLAYED_NO_GAME';
						}

						//trigger_error($this->user->lang[$msgkey] . $this->arcade->back_link($params, 'tour_stats'));
					}
					else if ($tour_id)
					{
						$this->arcade->valid_start($start, $total_data);

						$sql_array = array(
							'SELECT'	=> 'tc.score, tc.score_date, tc.total_plays, tc.total_time,
											tw.user_id,
											g.game_id, g.game_name, g.game_name_clean, g.game_image,
											c.cat_id, c.cat_name, c.cat_type, c.parent_id, c.cat_parents, c.left_id, c.right_id, c.cat_desc, c.cat_desc_options, c.cat_desc_uid, c.cat_desc_bitfield',
							'FROM'		=> array(ARCADE_TOUR_TABLE => 't'),
							'LEFT_JOIN'	=> array(
								array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE	=> 'tc'), 'ON' => 't.tour_id = tc.tour_id'),
								array('FROM' => array(ARCADE_TOUR_WINS_TABLE	=> 'tw'), 'ON' => 'tc.tour_id = tw.tour_id AND tc.user_id = tw.user_id AND tc.game_id = tw.game_id'),
								array('FROM' => array(ARCADE_GAMES_TABLE		=> 'g'),  'ON' => 'tc.game_id = g.game_id'),
								array('FROM' => array(ARCADE_CATS_TABLE			=> 'c'),  'ON' => 'g.cat_id = c.cat_id'),
								array('FROM' => array(USERS_TABLE				=> 'u'),  'ON' => 'tc.user_id = u.user_id'),
							),
							'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
								AND t.tour_status = ' . ARCADE_END_TOUR . '
								AND g.cat_id = c.cat_id
								AND u.user_id = ' . (int) $user_id . $sql_tour_limit . $game_sql . $wons_sql . '
								AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions('c_view'), false, true),
							'ORDER_BY'	=> $sql_sort
						);
						$sql = $this->db->sql_build_query('SELECT', $sql_array);
						$result = $this->db->sql_query_limit($sql, $this->arcade_config['stat_items_per_page'], $start);
						$game_count = 0;
						while ($row = $this->db->sql_fetchrow($result))
						{
							if (!$game_count && $game_id)
							{
								$this->arcade->add_navlink('cat_game', $params, '', $row);
								$this->template->assign_var('S_GAME_NAME', $row['game_name']);
							}

							$game_count++;
							$game_name	= $row['game_name'];
							$no_score	= (empty($row['score_date']) && empty($row['score'])) ? true : false;
							$this->template->assign_block_vars('gamerow', array(
								'GAME_IMAGE'		=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($row['game_image'], 20, 20, 'x', 'tournament', $row['cat_id'], $row['game_id'], false, false, $tour_id) : false,
								'GAME_NAME'			=> $this->arcade->get()->game_name($row['game_name'], true, 'tournament', $row['cat_id'], $row['game_id'], 'x', false, false, false, false, $tour_id),
								'GAME_IMAGE_FIRST'	=> ($row['user_id'] == $user_id) ? $this->arcade->get()->leaders_image(1) : '',
								'SCORE'				=> ($no_score) ? '-' : ((!$this->arcade->hidden_score($row['game_id'], $user_id)) ? $this->arcade->number_format($row['score']) : $this->user->lang['HIDDEN']),
								'DATE'				=> ($no_score) ? '-' : $this->user->format_date($row['score_date']),
								'TOTAL_PLAYS'		=> $this->arcade->number_format($row['total_plays']),
								'TOTAL_TIME'		=> $this->arcade->time_format($row['total_time']),
								'AVG_TIME'			=> $this->arcade->time_format($row['total_time']/$row['total_plays'])
							));
						}
						$this->db->sql_freeresult($result);
					}

					$profile = (!$game_id) ? true : false;
					$userdata = $this->arcade->display()->user_info('stats', 'tournament', $user_id, $profile);
					$this->arcade->display()->user_online($user_id);
					$this->arcade->display()->user_favs($user_id);

					$s_arcade_stats_dkey = 'S_USER_STATS';
					$params .= "&amp;u=$user_id";
					$this->arcade->add_navlink('add', $params . (($tour_id) ? "&amp;tour_id=$tour_id" : ''), $userdata['username'], '', false);

					if ($tour_id)
					{
						$params2 = $params . "&amp;tour_id=$tour_id" . (($won) ? '' : '&amp;w=1');
						$params .= ($won) ? '&amp;w=1' : '';
					}

					if (!$game_id)
					{
						$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_USER_STATS'], $userdata['username']));
					}
					else
					{
						$total_data = 0;
						$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_GAME_NAME'], $game_name), sprintf($this->user->lang['ARCADE_V_USER_STATS'], $userdata['username']));
					}

					$this->template->assign_vars(array(
						'S_ARCADE_TOURS'			=> (!$tour_id) ? true : false,

						'U_ARCADE_USER_STATS_TYPE'	=> ($tour_id) ? $this->arcade->url($params2, 'arcade', false, 'usergamebox') : false,

						'L_ARCADE_USER_STATS_TYPE'	=> ($tour_id) ? $this->user->lang['ARCADE_VIEW_ALL_' . (($won) ? '' : 'HIGH') . 'SCORES'] : false
					));
				}
				else if ($game_id)
				{
					$game_data = $this->arcade->get()->game_cat_data($game_id);

					if ($tour_id)
					{
						$game_data['tour_id'] = $tour_id;

						$tour_name = $this->arcade->get()->tour_field($tour_id, 'tour_name');
						$this->arcade->add_navlink('add', "$params&amp;tour_id=$tour_id", $tour_name);
						$this->template->assign_var('TOUR_NAME', $tour_name);
					}

					$this->arcade->add_navlink('cat_game', $params, '', $game_data);
					$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_GAME_STATS'], $game_data['game_name']));

					$sql = 'SELECT COUNT(tc.game_id) AS total_data, SUM(tc.total_plays) as total_plays, SUM(tc.total_time) as total_time
							FROM ' . ARCADE_TOUR_TABLE . ' t
							LEFT JOIN ' . ARCADE_TOUR_CHAMP_TABLE . ' tc ON t.tour_id = tc.tour_id
							WHERE t.tour_status = ' . ARCADE_END_TOUR . '
							' . (($tour_id) ? ' AND t.tour_id = ' . (int) $tour_id : '') . '
							AND tc.game_id = ' . (int) $game_data['game_id'];
					$result = $this->db->sql_query($sql);
					$row = $this->db->sql_fetchrow($result);
					$this->db->sql_freeresult($result);

					$game_data = array_merge($game_data, array(
						'total_plays'	=> (int) $row['total_plays'],
						'total_time'	=> (int) $row['total_time']
					));

					if (!$game_data['total_plays'])
					{
						trigger_error(sprintf($this->user->lang['ARCADE_TOUR_GAME_NO_PLAYS'], $game_data['game_name']) . $this->arcade->back_link($params, 'tour_stats'));
					}

					if ($tour_id)
					{
						$this->arcade->valid_start($start, $total_data);
						$score_order = ($game_data['game_scoretype'] == SCORETYPE_HIGH) ? 'DESC' : 'ASC';

						$sql_array = array(
							'SELECT'	=> 'tc.score, tc.score_date, tc.total_plays, tc.total_time,
								u.user_id, u.username, u.user_colour, u.username_clean, u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height',
							'FROM'		=> array(ARCADE_TOUR_TABLE			=> 't'),
							'LEFT_JOIN'	=> array(
								array('FROM' => array(ARCADE_TOUR_CHAMP_TABLE	=> 'tc'), 'ON' => 't.tour_id = tc.tour_id'),
								array('FROM' => array(USERS_TABLE			=> 'u'), 'ON' => 'tc.user_id = u.user_id'),
							),
							'WHERE'		=> 't.tour_id = ' . (int) $tour_id . '
								AND u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
								AND t.tour_status = ' . ARCADE_END_TOUR . '
								AND tc.game_id = ' . (int) $game_data['game_id'] . '
								AND tc.user_id = u.user_id',
							'ORDER_BY'	=> 't.tour_endtime DESC, tc.score ' . $score_order . ', tc.score_date ASC, tc.total_plays DESC'
						);
						$sql = $this->db->sql_build_query('SELECT', $sql_array);
						$result = $this->db->sql_query_limit($sql, $this->arcade_config['stat_items_per_page'], $start);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$this->arcade->get()->actual_rank($actual_rank, $rank, $row['score'], $last_value);
							$this->template->assign_block_vars('scorerow', array(
								'RANK'			=> $rank,
								'USERNAME'		=> $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'tournament', 'x', false, $tour_id),
								'SCORE'			=> $this->arcade->number_format($row['score']),
								'DATE'			=> $this->user->format_date($row['score_date']),
								'TOTAL_PLAYS'	=> $this->arcade->number_format($row['total_plays']),
								'TOTAL_TIME'	=> $this->arcade->time_format($row['total_time'])
							));
						}
						$this->db->sql_freeresult($result);
					}

					$params .= "&amp;g={$game_data['game_id']}";
					$s_arcade_stats_dkey = 'S_GAME_STATS';

					$s_hidden_fields = array(
						'mode'	=> 'stats',
						'type'	=> 'tournament',
						'g'		=> (int) $game_data['game_id']
					);

					if (!empty($_SID))
					{
						$s_hidden_fields['sid'] = $_SID;
					}

					$this->template->assign_vars(array(
						'S_ARCADE_TOURS'	=> (!$tour_id) ? true : false,
						'S_TOUR_OPTIONS'	=> $this->arcade->tournament->get_options($tour_id, $game_id),

						'S_ACTION_GAME'		=> $this->arcade->url() . '#gamebox',
						'S_HIDDEN_FIELDS'	=> build_hidden_fields($s_hidden_fields)
					));

					$this->gen_game_data($game_data);
				}
				else
				{
					$this->main_data('tour');
				}

				$this->arcade->display()->main_box('tournament', $this->arcade_config['tour_welcome_stats']);
			}
			else
			{
				$this->template->assign_var('S_GAME_COMMENT', ($this->arcade_config['game_comment']) ? true : false);

				if (($game_id && $user_id) || ($user_id))
				{
					$highscores = $this->request->variable('hs', 0);

					$highscores_sql	= ($highscores && !$game_id) ? ' AND g.game_highuser = ' . (int) $user_id : '';
					$game_sql		= ($game_id) ? ' AND p.game_id = ' . (int) $game_id : '';

					$sql_cat_limit = '';
					$sql_sort = 'g.game_name_clean ASC';

					if (!$game_id)
					{
						$sort_key = ($sort_key) ? $sort_key : 'g';
						$sort_dir = ($sort_dir) ? $sort_dir : 'a';
						$limit_cat = $this->arcade->get()->user_categories($user_id, $highscores);
						$sort_by_text = array('g' => $this->user->lang['ARCADE_GAME_NAME'], 's' => $this->user->lang['ARCADE_SCORE'], 'd' => $this->user->lang['ARCADE_DATE'], 'p' => $this->user->lang['ARCADE_CHAMPION_PLAYED'], 'm' => $this->user->lang['ARCADE_STATS_TOTAL_TIME'], 't' => $this->user->lang['ARCADE_STATS_AVG']);
						$sort_by_sql = array('g' => 'g.game_name_clean', 's' => 's.score', 'd' => 's.score_date', 'p' => 'p.total_plays', 'm' => 'p.total_time', 't' => 'p.total_time / p.total_plays');

						gen_sort_selects($limit_cat, $sort_by_text, $sort_cat, $sort_key, $sort_dir, $s_limit_cat, $s_sort_key, $s_sort_dir, $u_sort_param);

						$sql_cat_limit = ($sort_cat) ? ' AND g.cat_id = ' . (int) $sort_cat : '';
						$sql_sort = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');
					}

					$sql_array = array(
						'SELECT'	=> 'COUNT(p.game_id) AS total_data',
						'FROM'		=> array(ARCADE_GAMES_TABLE			=> 'g'),
						'LEFT_JOIN'	=> array(
							array('FROM' => array(ARCADE_CATS_TABLE		=> 'c'), 'ON' => 'g.cat_id = c.cat_id'),
							array('FROM' => array(ARCADE_PLAYS_TABLE	=> 'p'), 'ON' => 'g.game_id = p.game_id'),
							array('FROM' => array(USERS_TABLE			=> 'u'), 'ON' => 'p.user_id = u.user_id'),

						),
						'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
							AND g.cat_id = c.cat_id
							AND u.user_id = ' . (int) $user_id . $sql_cat_limit . $game_sql . $highscores_sql . '
							AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions('c_view'), false, true)
					);
					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query($sql);
					$total_data = (int) $this->db->sql_fetchfield('total_data');
					$this->db->sql_freeresult($result);

					$profile = (!$game_id) ? true : false;
					$userdata = $this->arcade->display()->user_info('stats', 'arcade', $user_id, $profile);

					if (!$total_data && !$userdata['total_wins'] && !$userdata['total_superscores'])
					{
						if (!$game_id)
						{
							$msgkey = ($highscores) ? 'ARCADE_USER_NO_HIGHSCORES' : 'ARCADE_PLAYED_NO_GAMES';
						}
						else
						{
							$msgkey = 'ARCADE_PLAYED_NO_GAME';
						}

						trigger_error($this->user->lang[$msgkey] . $this->arcade->back_link($params, 'arcade_stats'));
					}

					if ($total_data)
					{
						$this->arcade->valid_start($start, $total_data);

						$score_columns = ($this->arcade_config['game_comment']) ? 's.*' : 's.score, s.score_date';

						$sql_array = array(
							'SELECT'	=> $score_columns . ', g.game_id, g.game_name, g.game_name_clean, g.game_highuser, g.game_image,
											p.total_time, p.total_plays,
											c.cat_id, c.cat_name, c.cat_type, c.parent_id, c.cat_parents, c.left_id, c.right_id, c.cat_desc, c.cat_desc_options, c.cat_desc_uid, c.cat_desc_bitfield',
							'FROM'		=> array(ARCADE_GAMES_TABLE			=> 'g'),
							'LEFT_JOIN'	=> array(
								array('FROM' => array(ARCADE_CATS_TABLE		=> 'c'), 'ON' => 'g.cat_id = c.cat_id'),
								array('FROM' => array(ARCADE_PLAYS_TABLE	=> 'p'), 'ON' => 'g.game_id = p.game_id'),
								array('FROM' => array(ARCADE_SCORES_TABLE	=> 's'), 'ON' => 'p.game_id = s.game_id AND p.user_id = s.user_id'),
								array('FROM' => array(USERS_TABLE			=> 'u'), 'ON' => 'p.user_id = u.user_id'),
							),
							'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
								AND g.cat_id = c.cat_id
								AND u.user_id = ' . (int) $user_id . $sql_cat_limit . $game_sql . $highscores_sql . '
								AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get()->permissions('c_view'), false, true),
							'ORDER_BY'	=> $sql_sort
						);
						$sql = $this->db->sql_build_query('SELECT', $sql_array);
						$result = $this->db->sql_query_limit($sql, $this->arcade_config['stat_items_per_page'], $start);
						$game_count = 0;
						while ($row = $this->db->sql_fetchrow($result))
						{
							if (!$game_count)
							{
								if ($game_id && $user_id)
								{
									$this->arcade->add_navlink('cat_game', $params, '', $row);
									$this->template->assign_var('S_GAME_NAME', $row['game_name']);
								}
								else if ($sort_cat)
								{
									$this->arcade->add_navlink('add', "$params&amp;cat_id=$sort_cat", $row['cat_name']);
								}
							}

							$game_count++;
							$game_name	= $row['game_name'];
							$no_score	= (empty($row['score_date']) && empty($row['score'])) ? true : false;
							$comment_display = ($this->arcade_config['game_comment'] && $row['comment_text'] !== '') ? generate_text_for_display($row['comment_text'], $row['comment_uid'], $row['comment_bitfield'], $row['comment_options']) : '';

							$this->template->assign_block_vars('gamerow', array(
								'GAME_IMAGE'		=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($row['game_image'], 20, 20, 'x', 'stats', $row['cat_id'], $row['game_id']) : false,
								'GAME_NAME'			=> $this->arcade->get()->game_name($row['game_name'], true, 'stats', $row['cat_id'], $row['game_id'], 'x'),
								'GAME_IMAGE_FIRST'	=> ($row['game_highuser'] == $user_id) ? $this->arcade->get()->leaders_image(1) : '',
								'SCORE'				=> ($no_score) ? '-' : ((!$this->arcade->hidden_score($row['game_id'], $user_id)) ? $this->arcade->number_format($row['score']) : $this->user->lang['HIDDEN']),
								'COMMENT'			=> ($comment_display !== '') ? $comment_display : '&nbsp;',
								'DATE'				=> ($no_score) ? '-' : $this->user->format_date($row['score_date']),
								'TOTAL_PLAYS'		=> $this->arcade->number_format($row['total_plays']),
								'TOTAL_TIME'		=> $this->arcade->time_format($row['total_time']),
								'AVG_TIME'			=> $this->arcade->time_format($row['total_time']/$row['total_plays'])
							));
						}
						$this->db->sql_freeresult($result);
					}

					$this->arcade->display()->user_online($user_id);
					$this->arcade->display()->user_favs($user_id);

					$s_arcade_stats_dkey = 'S_USER_STATS';
					$params .= "&amp;u=$user_id";
					$this->arcade->add_navlink('add', $params, $userdata['username'], '', false);
					$params2 = $params . (($highscores) ? '' : '&amp;hs=1');
					$params .= ($highscores) ? '&amp;hs=1' : '';

					$this->template->assign_vars(array(
						'U_ARCADE_USER_STATS_TYPE'			=> ($userdata['total_wins']) ? $this->arcade->url($params2, 'arcade', false, 'usergamebox') : false,
						'U_ARCADE_USER_SUPER_HIGHSCORES'	=> ($userdata['total_superscores']) ? $this->arcade->url("mode=stats&amp;ds=super_champions&amp;u={$user_id}", 'arcade', false, true) : false,

						'L_ARCADE_USER_STATS_TYPE'			=> $this->user->lang['ARCADE_VIEW_ALL_' . (($highscores) ? '' : 'HIGH') . 'SCORES']
					));

					if (!$game_id)
					{
						$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_USER_STATS'], $userdata['username']));
					}
					else
					{
						$total_data = 0;
						$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_GAME_NAME'], $game_name), sprintf($this->user->lang['ARCADE_V_USER_STATS'], $userdata['username']));
					}
				}
				else if ($game_id)
				{
					$game_data = $this->arcade->get()->game_cat_data($game_id);
					$this->arcade->add_navlink('cat_game', $params, '', $game_data);
					$this->arcade->page_title(sprintf($this->user->lang['ARCADE_V_GAME_STATS'], $game_data['game_name']));

					$sql_array = array(
						'SELECT'	=> 'COUNT(p.game_id) AS total_data, SUM(p.total_plays) AS total_plays, SUM(p.total_time) AS total_time',
						'FROM'		=> array(ARCADE_PLAYS_TABLE			=> 'p'),
						'LEFT_JOIN'	=> array(
							array('FROM' => array(USERS_TABLE			=> 'u'), 'ON' => 'p.user_id = u.user_id'),
						),
						'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
							AND p.game_id = ' . (int) $game_data['game_id'] . '
							AND p.user_id = u.user_id'
					);
					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query($sql);
					$row = $this->db->sql_fetchrow($result);
					$this->db->sql_freeresult($result);

					$total_data = (int) $row['total_data'];

					$game_data = array_merge($game_data, array(
						'total_plays'	=> (int) $row['total_plays'],
						'total_time'	=> (int) $row['total_time']
					));

					if (!$game_data['total_plays'])
					{
						trigger_error(sprintf($this->user->lang['ARCADE_GAME_NO_PLAYS'], $game_data['game_name'], '<a href="' . $this->arcade->url("mode=play&amp;g={$game_data['game_id']}") . '">', '</a>'));
					}

					$actual_position	= 0;
					$score_columns		= ($this->arcade_config['game_comment']) ? 's.*' : 's.score, s.score_date';
					$score_order		= ($game_data['game_scoretype'] == SCORETYPE_HIGH) ? 'DESC' : 'ASC';

					$this->arcade->valid_start($start, $total_data);

					$sql_array = array(
						'SELECT'	=> $score_columns . ', p.total_time, p.total_plays,
							u.user_id, u.username, u.user_colour, u.username_clean, u.user_rank, u.user_posts,
							u.user_avatar_type, u.user_avatar, u.user_avatar_width, u.user_avatar_height,
							a.user_arcade_rank, a.arcade_total_wins',
						'FROM'		=> array(ARCADE_PLAYS_TABLE			=> 'p'),
						'LEFT_JOIN'	=> array(
							array('FROM' => array(ARCADE_SCORES_TABLE	=> 's'), 'ON' => 'p.game_id = s.game_id AND p.user_id = s.user_id'),
							array('FROM' => array(USERS_TABLE			=> 'u'), 'ON' => 'p.user_id = u.user_id'),
							array('FROM' => array(ARCADE_USERS_TABLE	=> 'a'), 'ON' => 'u.user_id = a.user_id'),
						),
						'WHERE'		=> 'u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
							AND p.game_id = ' . (int) $game_data['game_id'] . '
							AND p.user_id = u.user_id
							AND u.user_id = a.user_id',
						'ORDER_BY'	=> 's.score ' . $score_order . ', s.score_date ASC, p.total_plays DESC'
					);
					$sql = $this->db->sql_build_query('SELECT', $sql_array);
					$result = $this->db->sql_query_limit($sql, $this->arcade_config['stat_items_per_page'], $start);
					while ($row = $this->db->sql_fetchrow($result))
					{
						$actual_position++;
						$no_score = (empty($row['score_date']) && empty($row['score'])) ? true : false;

						// Handle the game champion
						if ($actual_position == 1)
						{
							// Added first line super champion
							if ($this->arcade_config['super_champion'] && $game_data['game_save_type'] != NOSCORE_GAME && ($super_champion = $this->arcade->game()->super_champion($game_data['game_id'])) !== false)
							{
								if (!$start && $super_champion['score'] > $row['score'])
								{
									$this->template->assign_block_vars('scorerow', array(
										'RANK'			=> '<b class="arcade-yellow-shadow">' . $this->user->lang['ARCADE_SUPER_CHAMPION'] . '</b>',
										'USERNAME'		=> $this->arcade->get()->user_name('full', $super_champion['user_id'], $super_champion['username'], $super_champion['user_colour'], 'profile', 'x'),
										'SCORE'			=> $this->arcade->number_format($super_champion['score']),
										'COMMENT'		=> '&nbsp;',
										'DATE'			=> $this->user->format_date($super_champion['score_date']),
										'TOTAL_PLAYS'	=> '-',
										'TOTAL_TIME'	=> '-'
									));
								}
							}

							$this->arcade->display()->user_online($row['user_id']);

							if (!$no_score)
							{
								$this->arcade->display()->user_favs($row['user_id']);
							}

							if ($this->arcade_config['forum_rank'])
							{
								$forum_rank_data = $this->arcade->phpbb()->get_user_rank($row['user_rank'], $row['user_posts']);

								$this->template->assign_vars(array(
									'RANK_TITLE'		=> $forum_rank_data['title'],
									'RANK_IMAGE'		=> $forum_rank_data['img'],
									'RANK_IMAGE_SRC'	=> $forum_rank_data['img_src']
								));
							}

							if ($this->arcade_config['arcade_rank'])
							{
								$arcade_user_rank = $this->arcade->get()->user_rank($row['user_arcade_rank'], $row['arcade_total_wins'], 100);

								$this->template->assign_vars(array(
									'A_RANK_TITLE'		=> $arcade_user_rank['rank_title'],
									'A_RANK_IMAGE'		=> $arcade_user_rank['rank_img'],
									'A_RANK_IMAGE_SRC'	=> $arcade_user_rank['rank_img_src']
								));
							}

							$this->template->assign_vars(array(
								'BEST_USER'		=> ($no_score) ? '-' : $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'arcade', 'x'),
								'BEST_SCORE'	=> ($no_score) ? '-' : ((!$this->arcade->hidden_score($game_data['game_id'], $row['user_id'])) ? $this->arcade->number_format($row['score']) : $this->user->lang['HIDDEN']),
								'BEST_DATE'		=> ($no_score) ? '-' : $this->user->format_date($row['score_date']),
								'AVATAR'		=> ($no_score) ? false : (($this->arcade->optionget('view_avatars')) ? $this->arcade->get()->user_avatar($row['user_avatar'], $row['user_avatar_type'], 60, 60, 'x', 'arcade', $row['user_id']) : false)
							));
						}

						$this->arcade->get()->actual_rank($actual_rank, $rank, $row['score'], $last_value);
						$comment_display = ($this->arcade_config['game_comment'] && $row['comment_text'] !== '') ? generate_text_for_display($row['comment_text'], $row['comment_uid'], $row['comment_bitfield'], $row['comment_options']) : '';

						$this->template->assign_block_vars('scorerow', array(
							'RANK'			=> ($no_score) ? '-' : $rank,
							'USERNAME'		=> $this->arcade->get()->user_name('full', $row['user_id'], $row['username'], $row['user_colour'], 'arcade', 'x'),
							'SCORE'			=> ($no_score) ? '-' : ((!$this->arcade->hidden_score($game_data['game_id'], $row['user_id'])) ? $this->arcade->number_format($row['score']) : $this->user->lang['HIDDEN']),
							'COMMENT'		=> ($comment_display !== '') ? $comment_display : '&nbsp;',
							'DATE'			=> ($no_score) ? '-' : $this->user->format_date($row['score_date']),
							'TOTAL_PLAYS'	=> $this->arcade->number_format($row['total_plays']),
							'TOTAL_TIME'	=> $this->arcade->time_format($row['total_time'])
						));
					}
					$this->db->sql_freeresult($result);

					$params .= "&amp;g={$game_data['game_id']}";
					$s_arcade_stats_dkey = 'S_GAME_STATS';

					$this->gen_game_data($game_data);
				}
				else
				{
					$this->main_data();
				}

				$this->arcade->display()->main_box('arcade', $this->arcade_config['welcome_stats'], $this->arcade_config['search_stats']);
			}
		}

		if ($s_arcade_stats_dkey !== false)
		{
			$this->arcade->valid_start($start, $total_data);

			$this->template->assign_var($s_arcade_stats_dkey, true);

			if ($total_data)
			{
				$this->arcade->container('phpbb_pagination')->generate_template_pagination($this->arcade->url($params . (($u_sort_param) ? "&amp;$u_sort_param" : '')), 'pagination', 'start', $total_data, $this->arcade_config['stat_items_per_page'], $start);

				$this->template->assign_var('TOTAL_DATA', sprintf($this->user->lang['ARCADE_TOTAL_DATA'], $this->arcade->number_format($total_data)));

				if ($s_sort_dir && $total_data > 1)
				{
					$this->template->assign_vars(array(
						'S_ARCADE_HIDDEN_CAT'		=> ($detailed_stats && $sort_cat) ? true : false,
						'S_ARCADE_SELECT_SORT_CAT'	=> (count($limit_cat) && $s_limit_cat) ? $s_limit_cat : false,
						'S_ARCADE_SELECT_SORT_DIR'	=> $s_sort_dir,
						'S_ARCADE_SELECT_SORT_KEY'	=> $s_sort_key,

						'U_ARCADE_STATS_ACTION'		=> $this->arcade->url($params)
					));
				}
			}
		}

		$page_html = ($detailed_stats) ? 'detailed_stats' : 'stats';
		$this->arcade->display()->online_playing();
		$this->arcade->display()->page($this->arcade->lang_value($this->arcade->page_title), "arcade/{$page_html}_body.html");
	}

	private function gen_game_data($game_data)
	{
		$this->template->assign_vars(array(
			'S_CAN_DOWNLOAD'	=> $this->arcade->game()->download_auth('user_cat', $game_data['cat_id'], $game_data['cat_download'], $game_data['game_download']),
			'S_GAME_NAME'		=> $game_data['game_name'],

			'GAME_CAT_NAME'		=> $this->arcade->get()->cat_name($game_data['cat_name'], $game_data['cat_id'], $game_data['game_id'], 'x', false),
			'GAME_NAME'			=> $this->arcade->get()->game_name($game_data['game_name'], true, 'play', $game_data['cat_id'], $game_data['game_id'], 'x'),
			'GAME_IMAGE'		=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($game_data['game_image'], 60, 60, 'x', 'play', $game_data['cat_id'], $game_data['game_id']) : false,
			'GAME_TOTAL_PLAYS'	=> $this->arcade->number_format($game_data['total_plays']),
			'GAME_TOTAL_TIME'	=> $this->arcade->time_format($game_data['total_time']),
			'GAME_DOWNLOAD'		=> $this->arcade->number_format($game_data['game_download_total']),
			'GAME_RATING_IMG'	=> $this->arcade->set_rating_image($game_data, 'stats')
		));
	}

	private function main_data($mode = '')
	{
		if ($mode && !in_array($mode, array('challenge', 'tour')))
		{
			return;
		}

		global $_SID;

		$this->arcade->page_title('ARCADE_STATS');
		$cache_time = $this->arcade->hour($this->arcade_config['cache_time']);

		switch ($mode)
		{
			case 'challenge':
				$leader_title = 'CHALLENGE_LEADERS';
				$this->arcade->display()->stats_data('user', 'challenge_winners', 'most', 0, $this->arcade_config['challenge_leaders'], true, 'leaders_users', 'total_wins DESC, cc.champ_end_time ASC', false, false, false, $cache_time);
				$this->arcade->display()->stats_data('game', 'challenge_played_games', 'most', 0, $this->arcade_config['challenge_most_popular'], true, 'pop_games', '', false, false, true, $cache_time);
				$this->arcade->display()->stats_data('game', 'challenge_played_games', 'least', 0, $this->arcade_config['challenge_least_popular'], true, 'lpop_games', '', false, false, true, $cache_time);
				$this->arcade->display()->stats_data('user', 'challenge_played_users', 'most', 0, $this->arcade_config['challenge_most_played_users'], true, 'pop_users', '', false, false, false, $cache_time);
				$this->arcade->display()->stats_data('user', 'challenge_played_users', 'least', 0, $this->arcade_config['challenge_least_played_users'], true, 'lpop_users', '', false, false, false, $cache_time);

				$this->arcade->challenge->games_list();
				$this->arcade->challenge->users_list(false, true);
				$s_hidden_fields = array('mode' => 'stats', 'type' => 'challenge');
			break;

			case 'tour':
				$leader_title = 'TOURNAMENT_LEADERS';
				$this->arcade->display()->stats_data('user', 'tour_winners', 'most', 0, $this->arcade_config['tour_leaders'], true, 'leaders_users', 'total_wins DESC, t.tour_endtime ASC', false, false, false, $cache_time);
				$this->arcade->display()->stats_data('game', 'tour_played_games', 'most', 0, $this->arcade_config['tour_most_popular'], true, 'pop_games', '', false, false, true, $cache_time);
				$this->arcade->display()->stats_data('game', 'tour_played_games', 'least', 0, $this->arcade_config['tour_least_popular'], true, 'lpop_games', '', false, false, true, $cache_time);
				$this->arcade->display()->stats_data('user', 'tour_played_users', 'most', 0, $this->arcade_config['tour_most_played_users'], true, 'pop_users', '', false, false, false, $cache_time);
				$this->arcade->display()->stats_data('user', 'tour_played_users', 'least', 0, $this->arcade_config['tour_least_played_users'], true, 'lpop_users', '', false, false, false, $cache_time);

				$this->arcade->tournament->games_list();
				$this->arcade->tournament->users_list();
				$s_hidden_fields = array('mode' => 'stats', 'type' => 'tournament');
			break;

			default:
				$leader_title = 'LEADERS';
				$this->arcade->display()->stats_data('user', 'longest_highscores', 'least', 0, $this->arcade_config['longest_held_scores'], true, 'record_row', '', false, false, true, $cache_time);
				$this->arcade->display()->stats_data('user', 'highscores', 'most', 0, $this->arcade_config['arcade_leaders'], true, 'leaders_users', '', false, false, false, $cache_time);
				$this->arcade->display()->stats_data('user', 'super_champions', 'most', 0, $this->arcade_config['super_champions'], true, 'super_champions', '', false, false, false, $cache_time);
				$this->arcade->display()->stats_data('game', 'played_games', 'most', 0, $this->arcade_config['most_popular'], true, 'pop_games', '', false, false, true, $cache_time);
				$this->arcade->display()->stats_data('game', 'played_games', 'least', 0, $this->arcade_config['least_popular'], true, 'lpop_games', '', false, false, true, $cache_time);
				$this->arcade->display()->stats_data('user', 'played_users', 'most', 0, $this->arcade_config['most_played_users'], true, 'pop_users', '', false, false, false, $cache_time);
				$this->arcade->display()->stats_data('user', 'played_users', 'least', 0, $this->arcade_config['least_played_users'], true, 'lpop_users', '', false, false, false, $cache_time);

				if ($this->arcade->game()->download_stat_auth())
				{
					$this->arcade->display()->stats_data('game', 'downloaded_games', 'most', 0, $this->arcade_config['most_downloaded'], true, 'downloaded_games', '', false, false, true, $cache_time);
					$this->arcade->display()->stats_data('game', 'downloaded_games', 'least', 0, $this->arcade_config['least_downloaded'], true, 'ldownloaded_games', '', false, false, true, $cache_time);
				}

				$this->arcade->games_list('game_jump');
				$this->arcade->users_list();
				$s_hidden_fields = array('mode' => 'stats');
			break;
		}

		if (!empty($_SID))
		{
			$s_hidden_fields['sid'] = $_SID;
		}

		$this->template->assign_vars(array(
			'S_ACTION_GAME'			=> $this->arcade->url() . '#gamebox',
			'S_ACTION_USER'			=> $this->arcade->url() . '#userbox',
			'S_HIDDEN_FIELDS'		=> build_hidden_fields($s_hidden_fields),

			'L_ARCADE_STATS_TITLE'	=> $this->user->lang['ARCADE_' . (($mode) ? strtoupper($mode) . '_' : '') . 'STATS'],
			'L_ARCADE_LEADERS'		=> $this->user->lang['ARCADE_' . $leader_title]
		));
	}

	private function gen_data($mode, $type, &$start, &$total_data, $id = false, $zero = false)
	{
		global $arcade_page, $limit_cat, $sort_by_text, $sort_by_sql, $sort_cat, $sort_key, $sort_dir, $s_limit_cat, $s_sort_key, $s_sort_dir, $u_sort_param;

		if (!$id && $sort_cat)
		{
			$id = $sort_cat;
		}

		if (!($total_data = $this->arcade->get()->total($mode, $type, $id, $zero, true, false, true, $sort_cat)))
		{
			trigger_error('ARCADE_NO_STATS_DATA');
		}

		$this->arcade->valid_start($start, $total_data);
		$sort_key = ($sort_key) ? $sort_key : 'p';
		$sort_dir = ($sort_dir) ? $sort_dir : 'd';

		$con1 = $this->arcade_config[(($arcade_page == 'tournament') ? 'tournament_' : (($arcade_page == 'challenge') ? 'challenge_' : '')) . 'welcome_detailed_stats'];
		$con2 = ($arcade_page == 'arcade') ? $this->arcade_config['search_detailed_stats'] : false;
		gen_sort_selects($limit_cat, $sort_by_text, $sort_cat, $sort_key, $sort_dir, $s_limit_cat, $s_sort_key, $s_sort_dir, $u_sort_param);

		$order_by = $sort_by_sql[$sort_key] . ' ' . (($sort_dir == 'd') ? 'DESC' : 'ASC');

		if ($sort_by_sql[$sort_key] == 'total_wins')
		{
			switch ($type)
			{
				case 'challenge_winners':
					$order_by .= ', cc.champ_end_time ASC';
				break;

				case 'tour_winners':
					$order_by .= ', t.tour_endtime ASC';
				break;
			}
		}

		$this->arcade->display()->stats_data($mode, $type, 'most', $start, $this->arcade_config['stat_items_per_page'], true, str_replace(array('challenge_', 'tour_'), '', $type), $order_by, $id, $zero, true, 0, true, $sort_cat);
		$this->arcade->display()->main_box($arcade_page, $con1, $con2);
	}
}
