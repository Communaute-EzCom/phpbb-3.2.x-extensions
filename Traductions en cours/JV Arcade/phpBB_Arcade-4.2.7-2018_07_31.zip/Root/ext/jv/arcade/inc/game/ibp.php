<?php
/**
*
* @package phpBB Arcade
* @version $Id: ibp.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class ibp
{
	protected $db, $user, $request, $root_path, $php_ext;

	public function __construct($db, $user, $request, $arcade, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->user = $user;
		$this->request = $request;
		$this->arcade = $arcade;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	function game_data()
	{
		$this->request->enable_super_globals();

		$post_data = '';
		if (!empty($_POST))
		{
			foreach ($_POST as $k => $v)
			{
				if (in_array($k, array('gname', 'gscore', 'arcadegid', 'enscore')))
				{
					$post_data .= (($post_data) ? "\n" : '') . "$k=$v";
				}
			}

			$sql = 'UPDATE ' . ARCADE_SESSIONS_TABLE . "
					SET post_data = '" . $this->db->sql_escape($post_data) . "'
					WHERE phpbb_session_id = '" . $this->db->sql_escape($this->user->session_id) . "'
						AND session_id = '" . $this->db->sql_escape($this->arcade->game()->session->game_sid) . "'
						AND user_id = " . (int) $this->user->data['user_id'];
			$this->db->sql_query($sql);
		}

		$get_data = '';
		if (!empty($_GET))
		{
			foreach ($_GET as $k => $v)
			{
				$get_data .= (($get_data) ? '&amp;' : '') . "$k=$v";
			}
		}

		$params = ($post_data && $get_data) ? "$get_data" : '';

		redirect(append_sid($this->root_path . 'arcade.' . $this->php_ext, $params) . '#game_done');
	}
}
