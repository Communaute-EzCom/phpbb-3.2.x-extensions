<?php
/**
*
* @package phpBB Arcade
* @version $Id: phpbb.php 2026 2018-06-27 07:57:42Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class phpbb
{
	protected $db, $auth, $user, $config, $arcade_config, $arcade, $root_path, $php_ext;

	public function __construct($db, $auth, $user, $config, $arcade_config, $arcade, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->user = $user;
		$this->config = $config;
		$this->arcade_config = $arcade_config;
		$this->arcade = $arcade;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function create_game_announcement($games_data)
	{
		$game_announce = $forum_id = false;

		if ($this->start_announcement('game_announce', 'game_announce', $game_announce, $forum_id))
		{
			$user_data = array();
			$this->set_author($user_data);
			$ignore_cat_ids = array_map('intval', explode(',', $this->arcade_config['game_announce_ignore_cats']));

			foreach ($games_data as $game_data)
			{
				if (in_array($game_data['cat_id'], $ignore_cat_ids))
				{
					continue;
				}

				$post_id = (!empty($game_data['post_id'])) ? (int) $game_data['post_id'] : false;
				$type = ($post_id) ? 'edit' : 'create';
				$forum_data = $this->create_announcement('add_game', $type, $forum_id, $game_announce, $game_data, $post_id);

				if ($type == 'create' && count($forum_data))
				{
					$sql_ary = array(
						'topic_id'	=> (int) $forum_data['topic_id'],
						'post_id'	=> (int) $forum_data['post_id']
					);

					$sql = 'UPDATE ' . ARCADE_GAMES_TABLE . '
							SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
							WHERE game_id = ' . (int) $game_data['game_id'];
					$this->db->sql_query($sql);
				}
			}

			$this->set_author($user_data, true);
		}

		return $forum_id;
	}

	public function create_tour_announcement($method, $type, $tour_data, $post_id = false)
	{
		$tour_announce = $forum_id = false;

		if ($this->start_announcement('tour_announce', $method, $tour_announce, $forum_id))
		{
			$user_data = array();
			$this->set_author($user_data);

			foreach ($tour_data as $tour_id => $row)
			{
				$row['tour_id'] = (int) $tour_id;
				$forum_data = $this->create_announcement($method, $type, $forum_id, $tour_announce, $row['game_data'], $post_id, $row);

				if ($type == 'create' && count($forum_data))
				{
					$sql_ary = array(
						'topic_id'	=> (int) $forum_data['topic_id'],
						'post_id'	=> (int) $forum_data['post_id']
					);

					$sql = 'UPDATE ' . ARCADE_TOUR_TABLE . '
							SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
							WHERE tour_id = ' . $row['tour_id'];
					$this->db->sql_query($sql);
				}
			}

			$this->set_author($user_data, true);
		}

		return $forum_id;
	}

	public function create_report_game_announcement($report_message, &$report_data, $game_data)
	{
		$type = 'create';
		$report_game_announce = $forum_id = false;

		if ($this->start_announcement('report_game_announce', 'report_game_announce', $report_game_announce, $forum_id))
		{
			// use original author
			$report_username		= ($this->user->data['user_colour']) ? '[color=#' . $this->user->data['user_colour'] . ']' . $this->user->data['username'] . '[/color]' : $this->user->data['username'];
			$report_username_link	= '[url=' . generate_board_url() . '/memberlist.' . $this->php_ext . '?mode=viewprofile&amp;u=' . $this->user->data['user_id'] . ']' . $report_username . '[/url]';

			$user_data = array();
			$this->set_author($user_data);

			// prepare
			$report_game_announce['message'] = str_replace('[report_username]',		$report_username, $report_game_announce['message']);
			$report_game_announce['message'] = str_replace('[report_username_link]',$report_username_link, $report_game_announce['message']);
			$report_game_announce['message'] = str_replace('[report_type]',			$this->arcade->display_report_type($report_data['report_type']), $report_game_announce['message']);
			$report_game_announce['message'] = str_replace('[report_desc]',			$report_message, $report_game_announce['message']);
			// prepare

			$forum_data = $this->create_announcement('report_game', $type, $forum_id, $report_game_announce, $game_data);

			if (count($forum_data))
			{
				$report_data += array(
					'topic_id'	=> (int) $forum_data['topic_id'],
					'post_id'	=> (int) $forum_data['post_id']
				);
			}

			$this->set_author($user_data, true);
		}

		return $forum_id;
	}

	public function create_champions_game_announcement($champions, $time)
	{
		$type = 'create';
		$champions_game_announce = $forum_id = false;

		if ($this->start_announcement('champions_game_announce', 'champions_game_announce', $champions_game_announce, $forum_id))
		{
			$user_data = array();
			$this->set_author($user_data);

			$next_reset_score_date = $this->arcade->gen_datetime($time, true, $this->arcade_config['auto_reset_score_gc'], $this->arcade_config['auto_reset_score_hour']);

			// prepare
			$champions_game_announce['subject'] = str_replace('[create_date]', $this->arcade->gen_datetime($time, true), $champions_game_announce['subject']);
			$champions_game_announce['message'] = str_replace('[next_auto_reset_date]', $next_reset_score_date, $champions_game_announce['message']);
			// prepare

			$this->create_announcement('champions_game', $type, $forum_id, $champions_game_announce, $champions);

			$this->set_author($user_data, true);
		}

		return $forum_id;
	}

	/**
	* Post announcement
	*/
	public function create_announcement($method, &$type, $forum_id, $announce_data, $game_data, $post_id = false, $tour_data = false)
	{
		if (empty($announce_data) || empty($forum_id) || empty($game_data))
		{
			return;
		}

		if (!isset($this->user->lang['TOO_MANY_URLS']))
		{
			$this->user->add_lang('posting');
		}

		switch ($method)
		{
			case 'champions_game':
				$subject = $this->prepare_champions_announce($announce_data['subject'], $game_data, true);
				$text	 = $this->prepare_champions_announce($announce_data['message'], $game_data);
			break;

			default:
				if ($tour_data) {
					$subject = $this->prepare_tour_announce($method, $tour_data, $announce_data['subject'], $game_data, true);
					$text	 = $this->prepare_tour_announce($method, $tour_data, $announce_data['message'], $game_data);
				}
				else {
					$subject = $this->prepare_announce($announce_data['subject'], $game_data, true);
					$text	 = $this->prepare_announce($announce_data['message'], $game_data);
				}
		}

		// variables to hold the parameters for submit_post
		$poll = $uid = $bitfield = $options = '';

		generate_text_for_storage($text, $uid, $bitfield, $options, $announce_data['allow_bbcode'], $announce_data['allow_urls'], $announce_data['allow_smilies']);

		$data = array(
			'forum_id'			=> $forum_id,
			'poster_id'			=> (int) $this->user->data['user_id'],
			'icon_id'			=> false,

			'enable_bbcode'		=> $announce_data['allow_bbcode'],
			'enable_smilies'	=> $announce_data['allow_smilies'],
			'enable_urls'		=> $announce_data['allow_urls'],
			'enable_sig'		=> false,

			'message'			=> $text,
			'message_md5'		=> md5($text),

			'bbcode_bitfield'	=> $bitfield,
			'bbcode_uid'		=> $uid,

			'post_edit_locked'	=> 0,
			'post_approved'		=> 1,
			'topic_title'		=> $subject,
			'topic_status'		=> false,
			'notify_set'		=> false,
			'notify'			=> false,
			'post_time'			=> 0,
			'forum_name'		=> '',
			'enable_indexing'	=> true
		);

		if (!$tour_data && $type == 'create')
		{
			$this->topic_ids($forum_id, $subject);
		}

		if ($type == 'edit')
		{
			$topic_row = array();

			if ($post_id)
			{
				$sql = 'SELECT t.*, p.*
						FROM ' . TOPICS_TABLE . ' t, ' . POSTS_TABLE . ' p
						WHERE t.topic_id = p.topic_id
							AND p.post_id = ' . (int) $post_id;
				$result = $this->db->sql_query($sql);
				$topic_row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				if (!empty($topic_row))
				{
					$data = array_merge($topic_row, $data);

					$text1 = $topic_row['post_text'];
					decode_message($text1, $topic_row['bbcode_uid']);

					$text2 = $data['message'];
					decode_message($text2, $data['bbcode_uid']);

					// no change post title and message
					if ($topic_row['topic_title'] == $data['topic_title'] && $text1 == $text2)
					{
						return $data;
					}
				}
			}

			if (!$post_id || empty($topic_row))
			{
				$type = 'create';
			}
		}
		else if ($type == 'reply')
		{
			$data['topic_id'] = ($tour_data) ? $tour_data['topic_id'] : $game_data['topic_id'];
		}

		$mode = $type;
		if ($type == 'create')
		{
			$mode = 'post';
		}

		$post_author_name = $this->user->data['username'];

		if (!function_exists('submit_post'))
		{
			include($this->root_path . 'includes/functions_posting.' . $this->php_ext);
		}

		submit_post($mode, $subject, $post_author_name, POST_NORMAL, $poll, $data);

		return $data;
	}

	/**
	* Send a private message with the
	* message set in the acp
	*/
	public function send_pm($type, $data, $other = true)
	{
		if (!$this->user->data['is_registered'] || !isset($data['other_user_id']) || $data['other_user_id'] <= ANONYMOUS)
		{
			return;
		}

		$options = 0;
		$uid = $bitfield = '';
		$use_lang = ($other) ? $data['other_user_lang'] : $this->user->data['user_lang'];

		if (($pm_msg = $this->arcade->announce_lang("{$type}_pm", $use_lang, 'pm')) === false || !$pm_msg['subject'] || !$pm_msg['message'])
		{
			return;
		}

		$pm_lang = $use_lang;
		$this->arcade->message_language($pm_lang);

		if ($pm_lang != $use_lang)
		{
			return;
		}

		if (!isset($this->user->lang['TOO_MANY_URLS']))
		{
			$this->user->add_lang('posting');
		}

		$subject = $pm_msg['subject'];
		$message = $pm_msg['message'];

		$this->prepare_pm('subject', $type, $subject, $data, true);
		$this->prepare_pm('message', $type, $message, $data);

		$this->announce_sub($pm_msg);

		generate_text_for_storage($message, $uid, $bitfield, $options, $pm_msg['allow_bbcode'], $pm_msg['allow_urls'], $pm_msg['allow_smilies']);

		$user_data = array();
/*
		if (!empty($this->config['jv_system_bot_user_id']))
		{
			$user_data = $this->arcade->userdata('set_auth', $this->config['jv_system_bot_user_id']);
		}
*/
		if (empty($user_data['user_id']))
		{
			$user_data = array(
				'user_id'	=> $this->user->data['user_id'],
				'username'	=> $this->user->data['username'],
				'user_ip'	=> $this->user->ip
			);
		}

		$pm_data = array(
			'address_list'			=> ($other) ? array('u' => array($data['other_user_id'] => 'to')) : array('u' => array($user_data['user_id'] => 'to')),
			'from_user_id'			=> ($other) ? $user_data['user_id'] : $data['user_id'],
			'from_user_ip'			=> ($other) ? $user_data['user_ip'] : $data['user_ip'],
			'from_username'			=> ($other) ? $user_data['username'] : $data['username'],
			'reply_from_root_level'	=> 0,
			'reply_from_msg_id'		=> 0,
			'icon_id'				=> 0,
			'enable_sig'			=> false,
			'enable_bbcode'			=> $pm_msg['allow_bbcode'],
			'enable_urls'			=> $pm_msg['allow_urls'],
			'enable_smilies'		=> $pm_msg['allow_smilies'],
			'bbcode_bitfield'		=> $bitfield,
			'bbcode_uid'			=> $uid,
			'message'				=> $message
		);

		if (!function_exists('submit_pm'))
		{
			include($this->root_path . 'includes/functions_privmsgs.' . $this->php_ext);
		}

		unset($pm_msg, $data);
		submit_pm('post', $subject, $pm_data, false);
	}

	public function delete_topics($topic_ids)
	{
		$topic_ids = array_map('intval', (is_array($topic_ids)) ? array_unique($topic_ids) : array($topic_ids));

		if (!count($topic_ids))
		{
			return;
		}

		if (!function_exists('delete_topics'))
		{
			include($this->root_path . 'includes/functions_admin.' . $this->php_ext);
		}

		delete_topics('topic_id', $topic_ids);
	}

	public function group_memberships($group_id_ary = false, $user_id_ary = false, $return_bool = false)
	{
		if (!function_exists('group_memberships'))
		{
			include($this->root_path . 'includes/functions_user.' . $this->php_ext);
		}

		return group_memberships($group_id_ary, $user_id_ary, $return_bool);
	}

	public function topic_ids($forum_id, $term)
	{
		if (!is_array($term))
		{
			$term = array($term);
		}

		if (!$forum_id || !count($term))
		{
			return false;
		}

		$sql = 'SELECT topic_id
				FROM ' . TOPICS_TABLE . '
				WHERE forum_id = ' . (int) $forum_id . '
				AND ' . $this->db->sql_in_set('topic_title', $term) . '
				ORDER BY topic_id ASC';
		$result = $this->db->sql_query($sql);
		$topic_ids = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$topic_ids[] = (int) $row['topic_id'];
		}
		$this->db->sql_freeresult($result);

		if (count($topic_ids))
		{
			$this->delete_topics($topic_ids);
		}
	}

	public function delete_topics_not_existing_games($forum_id)
	{
		$sql = 'SELECT t.topic_id
				FROM ' . ARCADE_GAMES_TABLE . ' g, ' . TOPICS_TABLE . ' t
				WHERE g.topic_id = t.topic_id';
		$result = $this->db->sql_query($sql);
		$topic_ids = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$topic_ids[] = (int) $row['topic_id'];
		}
		$this->db->sql_freeresult($result);

		if (count($topic_ids))
		{
			$sql = 'SELECT topic_id
					FROM ' . TOPICS_TABLE . '
					WHERE forum_id = ' . (int) $forum_id . '
					AND ' . $this->db->sql_in_set('topic_id', $topic_ids, true) . '
					ORDER BY topic_id ASC';
			$result = $this->db->sql_query($sql);
			$delete_topic_ids = array();
			while ($row = $this->db->sql_fetchrow($result))
			{
				$delete_topic_ids[] = (int) $row['topic_id'];
			}
			$this->db->sql_freeresult($result);

			if (count($delete_topic_ids))
			{
				$this->delete_topics($delete_topic_ids);
			}
		}
	}

	public function get_user_rank($user_rank, $user_posts = 0)
	{
		if (!function_exists('phpbb_get_user_rank'))
		{
			include($this->root_path . 'includes/functions_display.' . $this->php_ext);
		}

		return phpbb_get_user_rank(array('user_rank' => $user_rank), $user_posts);
	}

	private function start_announcement($type, $method, &$announce, &$forum_id)
	{
		$lang_dir = $this->arcade_config['announce_lang'];
		if (!$this->arcade_config[$type] || !$this->arcade_config[$type . '_forum'] || ($announce = $this->arcade->announce_data($lang_dir, $method)) === false || !$announce['subject'] || !$announce['message'])
		{
			return false;
		}

		$this->arcade->message_language($lang_dir);

		if ($lang_dir != $this->arcade_config['announce_lang'])
		{
			return false;
		}

		$this->announce_sub($announce);

		$sql = 'SELECT forum_id
				FROM ' . FORUMS_TABLE . '
				WHERE forum_id = ' . (int) $this->arcade_config[$type . '_forum'];
		$result = $this->db->sql_query($sql);
		$forum_id = (int) $this->db->sql_fetchfield('forum_id');
		$this->db->sql_freeresult($result);

		return ($forum_id) ? true : false;
	}

	/**
	* Replace place holders for announcement
	*/
	private function prepare_announce($text, $data, $skip_bbcode = false)
	{
		global $lang;

		$cat_id				= (int) $data['cat_id'];
		$game_id			= (int) $data['game_id'];

		$game_cat_link		= (!$skip_bbcode) ? '[arcade-js=game_category_link]arcade.' . $this->php_ext . '?mode=cat&amp;c=' . $cat_id . '&amp;g=' . $game_id . '#g' . $game_id . '[/arcade-js]' : $data['cat_name'];
		$game_width			= (int) $data['game_width'];
		$game_height		= (int) $data['game_height'];
		$game_desc			= $data['game_desc'];
		$game_image			= (!$skip_bbcode) ? '[arcade-js=img]arcade.' . $this->php_ext . '?img=' . $data['game_image'] . '[/arcade-js]' : '';
		$game_image_link	= (!$skip_bbcode) ? '[url=' . generate_board_url() . '/arcade.' . $this->php_ext . '?mode=play&amp;g=' . $game_id . $this->arcade->gametop . ']' . str_replace('js=img', 'js=play_img', $game_image) . '[/url]' : '';
		$game_link			= (!$skip_bbcode) ? '[arcade-js=play_link]arcade.' . $this->php_ext . '?mode=play&amp;g=' . $game_id . $this->arcade->gametop . '[/arcade-js]' : '';
		$game_popup_link	= (!$skip_bbcode) ? '[arcade_popup=' . $game_width . ',' . $game_height . ']arcade.' . $this->php_ext . '?mode=popup&amp;g=' . $game_id . '[/arcade_popup]' : '';
		$game_download_link	= (!$skip_bbcode) ? '[arcade-js=download_game_link]arcade.' . $this->php_ext . '?mode=download&amp;g=' . $game_id . $this->arcade->gametop . '[/arcade-js]' : '';
		$game_stats_link	= (!$skip_bbcode) ? '[arcade-js=game_stats_link]arcade.' . $this->php_ext . '?mode=stats&amp;g=' . $game_id . '#gamebox[/arcade-js]' : '';
		$game_control		= str_replace($this->root_path, '/', $this->arcade->game()->control($data['game_control'], 'src'));
		$game_control		= (!$skip_bbcode && $game_control) ? '[img]' . generate_board_url() . $game_control . '[/img]' : '';
		$game_control	   .= (!$skip_bbcode && $data['game_control_desc']) ? '<br>' . $data['game_control_desc'] : '';
		$game_type			= $this->arcade->game()->type($data['game_type'], true);
		$game_save_type		= $this->arcade->game()->save_type($data['game_save_type'], true);
		$game_filesize		= get_formatted_filesize($data['game_filesize']);
		$game_installdate	= $this->user->format_date($data['game_installdate'], false, true);
		$px					= " {$lang['PIXEL']}";

		$text = str_replace('[game_id]',			$game_id,			$text);
		$text = str_replace('[game_desc]',			$game_desc,			$text);
		$text = str_replace('[game_control]',		$game_control,		$text);
		$text = str_replace('[game_image]',			$game_image,		$text);
		$text = str_replace('[game_image_link]',	$game_image_link,	$text);
		$text = str_replace('[game_name]',			$data['game_name'],	$text);
		$text = str_replace('[game_popup_link]',	$game_popup_link,	$text);
		$text = str_replace('[game_download_link]',	$game_download_link,$text);
		$text = str_replace('[game_stats_link]',	$game_stats_link,	$text);
		$text = str_replace('[game_link]',			$game_link,			$text);
		$text = str_replace('[game_installdate]',	$game_installdate,	$text);
		$text = str_replace('[game_filesize]',		$game_filesize,		$text);
		$text = str_replace('[game_save_type]',		$game_save_type,	$text);
		$text = str_replace('[game_width]',			$game_width  . $px,	$text);
		$text = str_replace('[game_height]',		$game_height . $px,	$text);
		$text = str_replace('[cat_id]',				$cat_id,			$text);
		$text = str_replace('[game_cat]',			$data['cat_name'],	$text);
		$text = str_replace('[game_cat_link]',		$game_cat_link,		$text);
		$text = str_replace('[game_type]',			$game_type,			$text);

		$this->normalize_text($text);

		return $text;
	}

	private function prepare_tour_announce($method, $tour_data, $text, $data, $skip_bbcode = false)
	{
		global $lang;

		$group_helper = $this->arcade->container('phpbb_group_helper');

		$tour_link = $plays_max = $reward = $start_time = $end_time = $tour_end_link = '';
		$cat_name = $tour_games = $tour_games_link = $tour_groups = $tour_groups_link = '';

		$arcade_url = generate_board_url() . '/arcade.' . $this->php_ext;

		$tour_id	= (int) $tour_data['tour_id'];
		$tour_name	= $tour_data['tour_name'];

		if ($method == 'tour_announce')
		{
			if ($tour_data['reward_1'] > 0)
			{
				$reward  = '<br>' . $lang['ARCADE_TOUR_MSG_REWARD'];

				for ($x = 1; $x <= 3; $x++)
				{
					if ($tour_data['reward_' . $x] > 0)
					{
						$reward .= '<br>' . sprintf($lang['ARCADE_TOUR_MSG_REWARD_' . $x], $this->arcade->number_format((float) $tour_data['reward_' . $x]), $this->arcade->points()->data['name']);
					}
				}

				$reward .= '<br>';
			}

			$plays_max	= (int) $tour_data['plays_max'];
			$tour_link	= (!$skip_bbcode) ? '[url=' . $arcade_url . '?mode=tournament&amp;tour_id=' . $tour_id . '#tour_top]' . $tour_name . '[/url]' : $tour_name;
			$plays_max	= ($plays_max > 0) ? $this->arcade->number_format($plays_max) : $lang['ARCADE_INFINITE'];
			$start_time	= $this->user->format_date($tour_data['tour_starttime'], false, true);
			$end_time	= $this->user->format_date($tour_data['tour_endtime'], false, true);
		}
		else if ($method == 'tour_end_announce')
		{
			$tour_end_link = (!$skip_bbcode) ? '[url=' . $arcade_url . '?mode=tournament&amp;tour_id=' . $tour_id . '&amp;type=final#tour_top]' . $tour_name . '[/url]' : $tour_name;

			$x=0;
			if (!$skip_bbcode && !empty($tour_data['ud']))
			{
				foreach ($tour_data['ud'] as $key => $row)
				{
					$x++;
					if (!empty($row['user_id']))
					{
						$trofy			= '[img]' . generate_board_url() . '/' . str_replace($this->root_path, '', $this->arcade->get()->leaders_image($x, false, 'src')) . '[/img]';
						$win_name		= ($row['user_colour']) ? '[color=#' . $row['user_colour'] . ']' . $row['username'] . '[/color]' : $row['username'];
						$win_name_link	= '[url=' . $arcade_url . '?mode=stats&amp;type=tournament&amp;tour_id=' . $tour_id . '&amp;u=' . $row['user_id'] . ']' . $win_name . '[/url] ' . $trofy;
						$win_name	   .= " {$trofy}";
						$point_msg		= (!empty($row['reward']) && $row['reward'] > 0) ? sprintf($lang['ARCADE_TOUR_MSG_REWARD_END'], $this->arcade->number_format((float) $row['reward']), $this->arcade->points()->data['name']) : '';
					}
					else
					{
						$win_name = $win_name_link = '-';
					}

					if ($win_name != '-' && !empty($point_msg))
					{
						if (strpos($text, "{{$x}_ARCADE_POINT_SYSTEM_MSG}") !== false)
						{
							$text = str_replace("{{$x}_ARCADE_POINT_SYSTEM_MSG}", $point_msg, $text);
						}
						else
						{
							$win_name .= " {$point_msg}";
							$win_name_link .= " {$point_msg}";
						}
					}
					else
					{
						$text = str_replace("{{$x}_ARCADE_POINT_SYSTEM_MSG}", '', $text);
					}

					$text = str_replace("[{$x}_username]",		$win_name,		$text);
					$text = str_replace("[{$x}_username_link]",	$win_name_link,	$text);
				}
			}

			if ($x < 3)
			{
				while ($x < 3)
				{
					$x++;
					$text = str_replace("[{$x}_username]", '-', $text);
					$text = str_replace("[{$x}_username_link]", '-', $text);
					$text = str_replace("{{$x}_ARCADE_POINT_SYSTEM_MSG}", '', $text);
				}
			}
		}

		if (!$skip_bbcode)
		{
			if ($method == 'tour_announce')
			{
				if (count($data))
				{
					foreach ($data as $gd)
					{
						if ($cat_name != $gd['cat_name'])
						{
							$tour_games		 .= (($cat_name) ? '[/list][/list]<br>' : '') . '[list][*][b]' . $gd['cat_name'] . '[/b]';
							$tour_games_link .= (($cat_name) ? '[/list][/list]<br>' : '') . '[list][*][url=' . $arcade_url . '?mode=cat&amp;c=' . $gd['cat_id'] . '#top_games][b]' . $gd['cat_name'] . '[/b][/url]';

							$tour_games		 .= '[list]';
							$tour_games_link .= '[list]';
						}

						$cat_name		  = $gd['cat_name'];
						$tour_games		 .= '[*]' . $gd['game_name'];
						$tour_games_link .= '[*][url=' . $arcade_url . '?mode=play&amp;g=' . $gd['game_id'] . $this->arcade->gametop . ']' . $gd['game_name'] . '[/url]';
					}
					$tour_games		 .= '[/list][/list]';
					$tour_games_link .= '[/list][/list]';
				}

				if (count($tour_data['tour_groups']))
				{
					$tour_groups		= '[list]';
					$tour_groups_link	= '[list]';
					foreach ($tour_data['tour_groups'] as $group_id => $row)
					{
						$group_name = $group_helper->get_name($row['group_name']);

						$group_name = ($row['group_type'] == GROUP_SPECIAL) ? '[b]' . $group_name . '[/b]' : $group_name;
						$group_name = ($row['group_colour']) ? '[color=#' . $row['group_colour'] . ']' . $group_name . '[/color]' : $group_name;
						$tour_groups	  .= '[*]' . $group_name . '';
						$tour_groups_link .= '[*][url=' . generate_board_url() . '/memberlist.' . $this->php_ext . '?mode=group&amp;g=' . $group_id . ']' . $group_name . '[/url]';
					}
					$tour_groups	  .= '[/list]';
					$tour_groups_link .= '[/list]';
				}
			}
			else if ($method == 'tour_end_announce')
			{
				if (count($data))
				{
					foreach ($data as $gd)
					{
						if ($cat_name != $gd['cat_name'])
						{
							$tour_games		 .= (($cat_name) ? '[/list][/list]<br>' : '') . '[list][*][b]' . $gd['cat_name'] . '[/b]';
							$tour_games_link .= (($cat_name) ? '[/list][/list]<br>' : '') . '[list][*][url=' . $arcade_url . '?mode=cat&amp;c=' . $gd['cat_id'] . '#top_games][b]' . $gd['cat_name'] . '[/b][/url]';

							$tour_games		 .= '[list]';
							$tour_games_link .= '[list]';
						}

						$username = $username_link = $lang['ARCADE_NOT_BEEN_PLAYED'];
						if ($gd['score_date'])
						{
							$username		= ($gd['user_colour']) ? '[color=#' . $gd['user_colour'] . ']' . $gd['username'] . '[/color]' : $gd['username'];
							$username_link	= $lang['ARCADE_FIRST'] . ': [url=' . $arcade_url . '?mode=stats&amp;type=tournament&amp;tour_id=' . $tour_id . '&amp;u=' . $gd['user_id'] . ']' . $username . '[/url] ';
							$username		= $lang['ARCADE_FIRST'] . ': ' . $username;
						}

						$cat_name		  = $gd['cat_name'];
						$tour_games		 .= '[*]' . $gd['game_name'] . '&nbsp;&bull;&nbsp;' . $username;
						$tour_games_link .= '[*][url=' . $arcade_url . '?mode=stats&amp;type=tournament&amp;tour_id=' . $tour_id . '&amp;g=' . $gd['game_id'] . $this->arcade->gametop . ']' . $gd['game_name'] . '[/url]&nbsp;&bull;&nbsp;' . $username_link;
					}
					$tour_games		 .= '[/list][/list]';
					$tour_games_link .= '[/list][/list]';
				}
			}
		}

		$text = str_replace('[tour_id]',					$tour_id,			$text);
		$text = str_replace('[tour_name]',					$tour_name,			$text);
		$text = str_replace('[tour_games]',					$tour_games,		$text);
		$text = str_replace('[tour_games_link]',			$tour_games_link,	$text);
		$text = str_replace('[tour_plays_max]',				$plays_max,			$text);
		$text = str_replace('{ARCADE_POINT_SYSTEM_MSG}',	$reward,			$text);
		$text = str_replace('[tour_groups]',				$tour_groups,		$text);
		$text = str_replace('[tour_groups_link]',			$tour_groups_link,	$text);
		$text = str_replace('[tour_link]',					$tour_link,			$text);
		$text = str_replace('[tour_starttime]',				$start_time,		$text);
		$text = str_replace('[tour_endtime]',				$end_time,			$text);
		$text = str_replace('[tour_end_link]',				$tour_end_link,		$text);

		$this->normalize_text($text);

		return $text;
	}

	private function prepare_champions_announce($text, $data, $skip_bbcode = false)
	{
		if (!$skip_bbcode)
		{
			$users_list = $users_list_link = '';
			$rank = $actual_rank = $last_value = 0;
			$arcade_url = generate_board_url() . '/arcade.' . $this->php_ext;

			foreach ($data as $key => $row)
			{
				$this->arcade->get()->actual_rank($actual_rank, $rank, $row['total_wins'], $last_value);
				$username		= ($row['user_colour']) ? '[color=#' . $row['user_colour'] . ']' . $row['username'] . '[/color]' : $row['username'];
				$username_link	= '[url=' . $arcade_url . '?mode=stats&amp;u=' . $row['user_id'] . ']' . $username . '[/url]';

				$users_list .= $rank . '. ' . $username . ' (' . $row['total_wins'] . ')<br>';
				$users_list_link .= $rank . '. ' . $username_link . ' (' . $row['total_wins'] . ')<br>';
			}

			$text = str_replace('[users_list]'		, $users_list		, $text);
			$text = str_replace('[users_list_link]'	, $users_list_link	, $text);
		}

		$this->normalize_text($text);

		return $text;
	}

	/**
	* Replace the placeholder inside the private message
	*/
	private function prepare_pm($mode, $type, &$text, $ac_data, $skip_bbcode = false)
	{
		global $lang;

		$orig_type = $type;
		switch ($type)
		{
			case 'challenge_accept':
			case 'challenge_reject':
			case 'challenge_withdraw':
			case 'challenge_report_game':
				$type = 'challenge_action';
			break;

			case 'challenge_final_tie':
			case 'challenge_final_loser':
			case 'challenge_final_winner':
				$type = 'challenge_end';
			break;
		}

		$arcade_url	= generate_board_url() . '/arcade.' . $this->php_ext;
		$old_user_id = $old_username = $old_user_link = $old_score = '';
		$new_user_id = $new_username = $new_user_link = $new_score = '';

		switch ($type)
		{
			case 'arcade':
			case 'arcade_super_champion':
			case 'challenge':
			case 'challenge_action':
				$new_user_id		= (int) $this->user->data['user_id'];
				$new_username		= (!$skip_bbcode && $this->user->data['user_colour']) ? '[color=#' . $this->user->data['user_colour'] . ']' . $this->user->data['username'] . '[/color]' : $this->user->data['username'];
				$new_user_link		= (!$skip_bbcode) ? '[url=' . $arcade_url . '?mode=stats' . ((strpos($type, 'challenge') !== false) ? '&amp;type=challenge' : '') . '&amp;u=' . $new_user_id . '#userbox]' . $new_username . '[/url]' : $new_username;
			break;
		}

		switch ($type)
		{
			case 'arcade':
			case 'arcade_super_champion':
			case 'challenge':
			case 'challenge_end':
				$lang_key			= (in_array($type, array('challenge', 'challenge_end'))) ? 'game_chall_stats_link' : 'game_stats_link';
				$type_chall			= (in_array($type, array('challenge', 'challenge_end'))) ? '&amp;type=challenge' : '';
				$game_name			= $ac_data['game_name'];
				$game_id			= (int) $ac_data['game_id'];
				$cat_id				= (int) $ac_data['cat_id'];
				$game_width			= (int) $ac_data['game_width'];
				$game_height		= (int) $ac_data['game_height'];
				$game_link			= $arcade_url . '?mode=play&amp;g=' . $game_id . $this->arcade->gametop;

				$game_image			= (!$skip_bbcode) ? '[arcade-js=img]arcade.' . $this->php_ext . '?img=' . $ac_data['game_image'] . '[/arcade-js]' : '';
				$game_image_link	= (!$skip_bbcode) ? '[url=' . $arcade_url . '?mode=play&amp;g=' . $game_id . $this->arcade->gametop . ']' . str_replace('js=img', 'js=play_img', $game_image) . '[/url]' : '';
				$game_link			= (!$skip_bbcode) ? '[url=' . $game_link . ']' . $game_name . '[/url]' : '';
				$game_popup_link	= (!$skip_bbcode) ? '[arcade_popup=' . $game_width . ',' . $game_height . ']arcade.' . $this->php_ext . '?mode=popup&amp;g=' . $game_id . '[/arcade_popup]' : '';
				$game_stats_link	= (!$skip_bbcode) ? '[arcade-js=' . $lang_key . ']arcade.' . $this->php_ext . '?mode=stats' . $type_chall . '&amp;g=' . $game_id . '#gamebox[/arcade-js]' : '';
			break;
		}

		switch ($type)
		{
			case 'arcade':
			case 'arcade_super_champion':
				$old_user_id		= (int) $ac_data['other_user_id'];
				$old_username		= (!$skip_bbcode && $ac_data['other_user_colour']) ? '[color=#' . $ac_data['other_user_colour'] . ']' . $ac_data['other_username'] . '[/color]' : $ac_data['other_username'];
				$old_user_link		= (!$skip_bbcode) ? '[url=' . $arcade_url . '?mode=stats&amp;u=' . $old_user_id . '#userbox]' . $lang['ARCADE_HERE'] . '[/url]' : $old_username;
				$old_score			= $ac_data['old_score'];
				$new_score			= $ac_data['new_score'];
			break;

			case 'challenge':
				$tour_bet			= ($ac_data['bet'] > 0) ? '<br>' . sprintf($lang['CHALLENGE_MSG_TOURNAMENT_BET'], $this->arcade->number_format((float) $ac_data['bet']) . ' ' . $this->arcade->points()->data['name']) : '';
				$deduction			= ($ac_data['total_cost'] > 0) ? '<br>' . sprintf($lang['CHALLENGE_MSG_DEDUCTION_' . (($ac_data['bet'] > 0) ? (($ac_data['free_play']) ? 'BET' : 'BET_COST') : 'COST')], $this->arcade->number_format((float) $ac_data['total_cost']) . ' ' . $this->arcade->points()->data['name']) . '<br>' . $lang['CHALLENGE_MSG_REJECT_REFUND'] : '';
				$point_msg			= $tour_bet . $deduction;
			break;

			case 'challenge_action':
				$games_name			= $ac_data['games_name'];
				$point_msg			= ($ac_data['total_cost'] > 0) ? '<br>' . sprintf($lang['CHALLENGE_MSG_REFUND' . (($ac_data['tc_num'] > 1) ? 'S' : '')], $this->arcade->number_format((float) $ac_data['total_cost']) . ' ' . $this->arcade->points()->data['name']) : '';
			break;

			case 'challenge_end':
				if ($orig_type == 'challenge_final_tie')
				{
					$opponent_user_id	= (int) $ac_data['user_id'];
					$opponent_username	= (!$skip_bbcode && $ac_data['user_colour']) ? '[color=#' . $ac_data['user_colour'] . ']' . $ac_data['username'] . '[/color]' : $ac_data['username'];
					$opponent_user_link	= (!$skip_bbcode) ? '[url=' . $arcade_url . '?mode=stats&amp;type=challenge&amp;u=' . $opponent_user_id . '#userbox]' . $opponent_username . '[/url]' : $opponent_username;
					$user_score			= $this->arcade->number_format((float) $ac_data['winner_score']);
				}
				else
				{
					$win				= ($ac_data['winner'] == $ac_data['other_user_id']) ? true : false;
					$winner_user_id		= (int) $ac_data[(($win) ? 'other_user_id' : 'user_id')];
					$winner_username	= (!$skip_bbcode && $ac_data[(($win) ? 'other_user_colour' : 'user_colour')]) ? '[color=#' . $ac_data[(($win) ? 'other_user_colour' : 'user_colour')] . ']' . $ac_data[(($win) ? 'other_username' : 'username')] . '[/color]' : $ac_data[(($win) ? 'other_username' : 'username')];
					$winner_user_link	= (!$skip_bbcode) ? '[url=' . $arcade_url . '?mode=stats&amp;type=challenge&amp;u=' . $winner_user_id . '#userbox]' . $winner_username . '[/url]' : $winner_username;
					$winner_score		= $this->arcade->number_format((float) $ac_data['winner_score']);
					$loser_user_id		= (int) $ac_data[((!$win) ? 'other_user_id' : 'user_id')];
					$loser_username		= (!$skip_bbcode && $ac_data[((!$win) ? 'other_user_colour' : 'user_colour')]) ? '[color=#' . $ac_data[((!$win) ? 'other_user_colour' : 'user_colour')] . ']' . $ac_data[((!$win) ? 'other_username' : 'username')] . '[/color]' : $ac_data[((!$win) ? 'other_username' : 'username')];
					$loser_user_link	= (!$skip_bbcode) ? '[url=' . $arcade_url . '?mode=stats&amp;type=challenge&amp;u=' . $loser_user_id . '#userbox]' . $loser_username . '[/url]' : $loser_username;
					$loser_score		= $this->arcade->number_format((float) $ac_data['loser_score']);
				}

				$prize				= ($ac_data['prize'] && $ac_data['bet_msg']) ? '<br>' . sprintf($lang[$ac_data['bet_msg']], $this->arcade->number_format((float) $ac_data['prize']) . ' ' . $this->arcade->points()->data['name']) : '';
				$game_cost_refund	= ($ac_data['refund_game_cost']) ? '<br>' . sprintf($lang['CHALLENGE_MSG_GAME_COST_REFUND'], $this->arcade->number_format((float) $ac_data['refund_game_cost']) . ' ' . $this->arcade->points()->data['name']) : '';
				$point_msg			= $prize . $game_cost_refund;
			break;
		}

		switch ($type)
		{
			case 'challenge':
				$search_keys = array('[challenger_user_id]', '[challenger_username]', '[challenger_user_link]');
				$replace_val = array($new_user_id, $new_username, $new_user_link);

				$text = str_replace($search_keys, $replace_val, $text);
			case 'challenge_end':
			case 'arcade':
			case 'arcade_super_champion':
				$search_keys = array(
					'[game_id]', '[game_name]', '[game_width]', '[game_height]', '[game_image]',
					'[game_link]', '[game_image_link]', '[game_popup_link]',
					'[old_user_id]', '[old_username]', '[old_user_link]', '[old_score]',
					'[new_user_id]', '[new_username]', '[new_user_link]', '[new_score]',
					'[game_stats_link]'
				);

				$replace_val = array(
					$game_id, $game_name, $game_width, $game_height, $game_image,
					$game_link, $game_image_link, $game_popup_link,
					$old_user_id, $old_username, $old_user_link, $old_score,
					$new_user_id, $new_username, $new_user_link, $new_score,
					$game_stats_link
				);

				$text = str_replace($search_keys, $replace_val, $text);
			break;

			case 'challenge_action':
				if ($orig_type == 'challenge_withdraw')
				{
					$search_keys = array('[challenger_user_id]', '[challenger_username]', '[challenger_user_link]', '[games_name]', '[game_name]');
				}
				else
				{
					$search_keys = array('[opponent_user_id]', '[opponent_username]', '[opponent_user_link]', '[games_name]', '[game_name]');
				}

				$replace_val = array($new_user_id, $new_username, $new_user_link, $games_name, $games_name);

				$text = str_replace($search_keys, $replace_val, $text);
			break;
		}

		switch ($type)
		{
			case 'challenge_end':
				if ($orig_type == 'challenge_final_tie')
				{
					$search_keys = array('[opponent_user_id]', '[opponent_username]', '[opponent_user_link]', '[user_score]');
					$replace_val = array($opponent_user_id, $opponent_username, $opponent_user_link, $user_score);
				}
				else
				{
					$search_keys = array(
						'[winner_user_id]', '[winner_username]', '[winner_user_link]', '[winner_score]',
						'[loser_user_id]', '[loser_username]', '[loser_user_link]', '[loser_score]'
					);

					$replace_val = array(
						$winner_user_id, $winner_username, $winner_user_link, $winner_score,
						$loser_user_id, $loser_username, $loser_user_link, $loser_score
					);
				}

				$text = str_replace($search_keys, $replace_val, $text);
			case 'challenge':
			case 'challenge_action':
				if ($mode == 'message')
				{
					if (!empty($point_msg))
					{
						$text = (strpos($text, '{ARCADE_POINT_SYSTEM_MSG}') !== false) ? str_replace('{ARCADE_POINT_SYSTEM_MSG}', $point_msg, $text) : $text . '<br><br>' . $point_msg;
					}
					else
					{
						$text = str_replace('{ARCADE_POINT_SYSTEM_MSG}', '', $text);
					}
				}

				$view_challenge = (!$skip_bbcode) ? '[arcade-js=view_challenge]arcade.' . $this->php_ext . '?mode=challenge#boxtop[/arcade-js]' : '';
				$text = str_replace('[view_challenge]', $view_challenge, $text);
			break;
		}

		$this->normalize_text($text);
	}

	private function normalize_text(&$text)
	{
		$text = utf8_normalize_nfc(html_entity_decode(str_replace(array('<br />', '<br>', '<', '>'), array("\n", "\n", '[', ']'), $text)));
	}

	// Author user data replace and restore from $this->user->data.
	private function set_author(&$user_data, $restore = false)
	{
		$ignore_keys = array('user_type', 'user_email', 'user_password', 'user_style');

		if ($restore)
		{
			if (count($user_data))
			{
				// Restore the user_data.
				foreach ($user_data as $key => $value)
				{
					if (!in_array($key, $ignore_keys))
					{
						$this->user->data[$key] = $value;
					}
				}

				$this->auth->acl($this->user->data);
				$this->user->data['is_registered'] = $user_data['is_registered'];
				$user_data = array();
			}
		}
		else
		{
			if ($this->arcade_config['announce_author'])
			{
				if ($this->arcade_config['announce_author'] != $this->user->data['username'])
				{
					$row = $this->arcade->userdata('all_user_data', false, $this->arcade_config['announce_author']);
				}
			}
			else if (!empty($this->config['jv_system_bot_user_id']))
			{
				$row = $this->arcade->userdata('all_user_data', $this->config['jv_system_bot_user_id']);
			}

			if (!empty($row['user_id']))
			{
				// Overwritten user_data.
				foreach ($row as $key => $value)
				{
					if (!in_array($key, $ignore_keys))
					{
						$user_data[$key] = $this->user->data[$key];
						$this->user->data[$key] = $value;
					}
				}

				$this->auth->acl($this->user->data);
				$user_data['is_registered'] = (!empty($this->user->data['is_registered'])) ? true : false;
				$this->user->data['is_registered'] = ($row['user_id'] != ANONYMOUS && ($row['user_type'] == USER_NORMAL || $row['user_type'] == USER_FOUNDER)) ? true : false;
				unset($row);
			}
		}
	}

	private function announce_sub(&$data)
	{
		$data = array_merge($data, generate_text_for_edit('', '', 7));
	}
}
