<?php
/**
*
* @package phpBB Arcade
* @version $Id: score.php 1985 2018-05-29 14:11:16Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\game;

class score
{
	private $game_id, $save_highscore;

	protected $db, $auth, $request, $user, $template, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext;

	public function __construct($db, $auth, $request, $user, $template, $arcade_config, $arcade_auth, $arcade, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	public function send($mode, $game_id, $game_data = array(), $score = 0)
	{
		$this->game_id = $game_id;

		if (!$this->user->data['is_bot'])
		{
			// If you are not logged in the score is never saved...
			// Lets show you a nice message and send you on your way.
			if (!$this->user->data['is_registered'])
			{
				$this->arcade->game()->update_last_play_time();

				if (empty($game_data))
				{
					redirect(append_sid("{$this->root_path}ucp.{$this->php_ext}", 'mode=login'));
				}

				$message = sprintf($this->user->lang['ARCADE_REGISTER_MESSAGE_SCORE'], $this->arcade->number_format(intval($this->arcade_config['install_games'])));
				$message .= (!$this->arcade->game()->session->game_popup) ? '<br>' . sprintf($this->user->lang['ARCADE_REGISTER_LOGIN_MESSAGE'], '<a href="' . append_sid("{$this->root_path}ucp.{$this->php_ext}", "mode=register") . '">', '</a>', '<a href="' . append_sid("{$this->root_path}ucp.{$this->php_ext}", 'mode=login&amp;redirect=' . urlencode("arcade.{$this->php_ext}")) . '">', '</a>') : '';

				$this->arcade->game()->session->set_cookie();
				trigger_error($message . $this->arcade->return_links($game_data, true, $this->arcade->game()->session->game_popup));
			}
			else
			{
				// We can't continue if we don't have a game_id
				if (empty($this->game_id) && $mode == 'score')
				{
					$this->arcade->game()->session->set_cookie();
				}
				else
				{
					switch ($mode)
					{
						case 'score':
							if (!$this->game_id || !$this->arcade_auth->acl_get('c_score', $this->arcade->get()->game_field($this->game_id, 'cat_id')) || !check_form_key('arcade_score'))
							{
								$this->arcade->game()->session->set_cookie();

								$message = $this->user->lang[(!$this->game_id || !$this->arcade_auth->acl_get('c_score', $this->arcade->get()->game_field($this->game_id, 'cat_id')) ? 'NO_PERMISSION_ARCADE_SCORE' : 'FORM_INVALID')];

								if ($this->game_id  && empty($game_data))
								{
									$game_data = $this->arcade->get()->game_cat_data($this->game_id);
								}

								if (!empty($game_data))
								{
									$this->arcade->add_navlink('cat_game', 'mode=play', '', $game_data);
									$message .= $this->arcade->return_links($game_data, true, $this->arcade->game()->session->game_popup);
								}
								else
								{
									$message .= $this->arcade->gbl($this->arcade->game()->session->game_popup);
								}

								trigger_error($message);
							}
							else if ($this->arcade_config['game_comment'] && $this->arcade_auth->acl_get('c_comment', $this->arcade->get()->game_field($this->game_id, 'cat_id')))
							{
								$this->user->add_lang('posting');

								$comment_data = array(
									'comment_text'		=> $this->request->variable('message', '', true),
									'comment_bitfield'	=> '',
									'comment_options'	=> 0,
									'comment_uid'		=> '',
								);

								$enable_bbcode	= ($this->arcade_config['parse_bbcode']) ? (($this->request->variable('disable_bbcode', false)) ? false : true) : false;
								$enable_smilies	= ($this->arcade_config['parse_smilies']) ? (($this->request->variable('disable_smilies', false)) ? false : true) : false;
								$enable_urls	= ($this->arcade_config['parse_links']) ? (($this->request->variable('disable_magic_url', false)) ? false : true) : false;

								generate_text_for_storage($comment_data['comment_text'], $comment_data['comment_uid'], $comment_data['comment_bitfield'], $comment_data['comment_options'], $enable_bbcode, $enable_urls, $enable_smilies);

								$sql = 'UPDATE ' . ARCADE_SCORES_TABLE . '
										SET ' . $this->db->sql_build_array('UPDATE', $comment_data) . '
										WHERE user_id = ' . (int) $this->user->data['user_id'] . '
										AND   game_id = ' . (int) $this->game_id;
								$this->db->sql_query($sql);

								$this->game_over();
								$this->done();
							}
						break;

						default:
							if (!empty($game_data))
							{
								if (!$this->arcade->game()->session->game_popup)
								{
									$this->arcade->add_navlink('cat_game', 'mode=play', '', $game_data);
								}

								if (!$this->arcade_auth->acl_get('c_score', $game_data['cat_id']))
								{
									$this->arcade->game()->session->set_cookie();
									$this->arcade->game()->update_plays($game_data['game_id'], $game_data['cat_id'], $game_data['total_time'], $game_data['current_time']);

									send_status_line(403, 'Forbidden');
									trigger_error($this->user->lang['NO_PERMISSION_ARCADE_SCORE'] . $this->arcade->return_links($game_data, true, $this->arcade->game()->session->game_popup));
								}

								$error_score = ($this->arcade_config['game_zero_negative_score'] && !is_numeric($score)) ? true : false;
								$cat_test	 = ($game_data['cat_test'] == ARCADE_CAT_TEST) ? true : false;

								if ($error_score || $cat_test)
								{
									if ($error_score)
									{
										$message = $this->user->lang['ARCADE_SCORE_ERROR'] . $this->arcade->return_links($game_data, true, $this->arcade->game()->session->game_popup);
									}
									else if ($cat_test)
									{
										$this->template->assign_var('S_ARCADE_CAT_TEST_MODE', true);

										$message = sprintf($this->user->lang['ARCADE_TEST_SCORE'], $this->arcade->number_format($score)) . $this->arcade->return_links($game_data, true, $this->arcade->game()->session->game_popup);
										if ($this->user->data['is_registered'] && $this->auth->acl_get('a_') && defined('DEBUG'))
										{
											$message .= '<br><br>' . $this->arcade->game()->debug($game_data);
										}
									}

									$this->arcade->game()->session->set_cookie();
									$this->arcade->game()->update_plays($game_data['game_id'], $game_data['cat_id'], $game_data['total_time'], $game_data['current_time']);
									trigger_error($message);
								}

								$save_score			= false;
								$high_score_type	= ($game_data['game_scoretype'] == SCORETYPE_HIGH) ? true : false;
								$first_score		= ($game_data['game_highuser'] == 0 && $game_data['game_highdate'] == 0) ? true : false;

								if (!$this->arcade_config['game_zero_negative_score'] && (!is_numeric($score) || $score <= 0))
								{
									$score_desc = $this->user->lang['ARCADE_ZERO_NEGATIVE_SCORE'];

									$this->arcade->game()->update_plays($game_data['game_id'], $game_data['cat_id'], $game_data['total_time'], $game_data['current_time']);

									$game_challenge = $game_tournament = false;

									if ($this->arcade->access('challenge', false))
									{
										$game_challenge = $this->arcade->challenge()->check($game_data);
									}

									if ($this->arcade->access('tour', false))
									{
										$game_tournament = $this->arcade->tournament()->check($game_data['game_id'], $high_score_type);
									}

									$this->game_over($score_desc);
									$this->done($game_data, $game_challenge, $game_tournament);
								}

								$game_data['game_highscore'] = (!$high_score_type && $first_score) ? $score + 1 : $game_data['game_highscore'];
								$comment_columns = ($this->arcade_config['game_comment']) ? ', s.comment_text, s.comment_bitfield, s.comment_options, s.comment_uid' : '';

								$sql_array = array(
									'SELECT'	=> "s.user_id, s.score $comment_columns",
									'FROM'		=> array(ARCADE_SCORES_TABLE => 's'),
									'WHERE'		=> 's.game_id = ' . (int) $game_data['game_id'] . '
										AND s.user_id = ' . (int) $this->user->data['user_id']
								);
								$sql = $this->db->sql_build_query('SELECT', $sql_array);
								$result = $this->db->sql_query_limit($sql, 1);
								$sdata = $this->db->sql_fetchrow($result);
								$this->db->sql_freeresult($result);

								// If the user has no current score we insert it.
								if (!$sdata)
								{
									$sql_ary = array(
										'game_id'		=> (int) $game_data['game_id'],
										'user_id'		=> (int) $this->user->data['user_id'],
										'score'			=> (float) $score,
										'score_date'	=> (int) $game_data['current_time'],
										'comment_text'	=> ''
									);

									$this->db->sql_return_on_error(true);
									$this->db->sql_query('INSERT INTO ' . ARCADE_SCORES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
									$this->db->sql_return_on_error(false);

									$save_score = true;
								}
								else
								{
									$old_score = $sdata['score'];
									// So you have an old score, is you new one better? (Make sure we check the scoretype)
									if (($high_score_type && $old_score < $score) || (!$high_score_type && $old_score > $score))
									{
										// Update score data
										$sql_ary = array(
											'score'			=> $score,
											'score_date'	=> $game_data['current_time']
										);

										$sql = 'UPDATE ' . ARCADE_SCORES_TABLE . '
												SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
												WHERE game_id = ' . (int) $game_data['game_id'] . '
												AND user_id   = ' . (int) $this->user->data['user_id'];
										$this->db->sql_query($sql);

										$save_score = true;
									}
								}

								$lastscore = '';
								$my_place = $position = $actual_position = 0;
								$sql_array = array(
									'SELECT'	=> "s.user_id, s.score",
									'FROM'		=> array(ARCADE_SCORES_TABLE => 's'),
									'WHERE'		=> 's.game_id = ' . (int) $game_data['game_id'],
									'ORDER_BY'	=> 's.score ' . (($high_score_type) ? 'DESC' : 'ASC') . ', s.score_date ASC'
								);
								$sql = $this->db->sql_build_query('SELECT', $sql_array);
								$result = $this->db->sql_query($sql);
								while ($row = $this->db->sql_fetchrow($result))
								{
									$actual_position++;

									if ($lastscore != $row['score'])
									{
										$position = $actual_position;
									}

									if ($this->user->data['user_id'] == $row['user_id'])
									{
										$my_place = $position;
										break;
									}

									$lastscore = $row['score'];
								}
								$this->db->sql_freeresult($result);

								$game_challenge = $game_tournament = false;

								if ($this->arcade->access('challenge', false))
								{
									$game_challenge = $this->arcade->challenge()->check($game_data, $score);
								}

								if ($this->arcade->access('tour', false))
								{
									$game_tournament = $this->arcade->tournament()->check($game_data['game_id'], $high_score_type, $score, $game_data['current_time'], $game_data['total_time']);
								}

								$nf_score		= $this->arcade->number_format($score);
								$game_highscore	= (!$this->arcade->hidden_score($game_data['game_id'], $game_data['game_highuser'])) ? $this->arcade->number_format($game_data['game_highscore']) : $this->user->lang['HIDDEN'];

								$game_ary = array();
								$new_highscore = $new_superscore = $save_superscore = false;
								$this->save_highscore = (($high_score_type && $game_data['game_highscore'] < $score) || (!$high_score_type && $game_data['game_highscore'] > $score) || ($this->arcade_config['game_zero_negative_score'] && $score <= 0 && $first_score)) ? true : false;

								// Here we check if you are the new highscore holder
								if ($this->save_highscore)
								{
									$game_ary = array(
										'game_highscore'	=> $score,
										'game_highuser'		=> $this->user->data['user_id'],
										'game_highdate'		=> $game_data['current_time']
									);

									$super_champion_id = false;

									if ($score > 0)
									{
										$sql_ary = array(
											'user_id'		=> (int) $this->user->data['user_id'],
											'score'			=> $score,
											'score_date'	=> $game_data['current_time']
										);

										if ($super_champion = $this->arcade->game()->super_champion($game_data['game_id']))
										{
											if (($high_score_type && $super_champion['score'] < $score) || (!$high_score_type && $super_champion['score'] > $score))
											{
												$save_superscore = true;
												$super_champion_id = (int) $super_champion['user_id'];
												$this->arcade->game()->update_super_score($sql_ary, $game_data['game_id']);
												$super_score = (!$this->arcade->hidden_score($game_data['game_id'], $super_champion_id)) ? $this->arcade->number_format($super_champion['score']) : $this->user->lang['HIDDEN'];
											}
										}
										else
										{
											$save_superscore = true;
											$this->arcade->game()->update_super_score($sql_ary, $game_data['game_id']);
										}
									}

									$equal_hs_user		= ($super_champion_id && $game_data['game_highuser'] == $super_champion_id) ? true : false;
									$new_osuperuser		= ($super_champion_id && $super_champion_id != $this->user->data['user_id']) ? true : false;
									$new_highscore		= ($game_data['game_highuser'] != $this->user->data['user_id']) ? true : false;
									$update_highscore	= (!$first_score && $new_highscore) ? true : false;
									$new_superscore		= ($save_superscore && (!$super_champion_id || $new_osuperuser)) ? true : false;
									$update_superscore	= ($super_champion_id && $new_superscore) ? true : false;

									if ($this->arcade_config['arcade_pm'])
									{
										if ($update_highscore)
										{
											$this->send_pm_loser_user('arcade', $game_data['game_highuser'], $game_highscore, $nf_score, $game_data);
										}

										if ($update_superscore && (!$update_highscore || !$equal_hs_user))
										{
											$this->send_pm_loser_user('arcade_super_champion', $super_champion_id, $super_score, $nf_score, $game_data);
										}
									}

									if ($update_highscore)
									{
										$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
												SET arcade_total_wins = arcade_total_wins - 1
												' . (($update_superscore && $equal_hs_user) ? ', arcade_total_super_scores = arcade_total_super_scores - 1' : '') . '
												WHERE user_id = ' . (int) $game_data['game_highuser'];
										$this->db->sql_query($sql);
									}

									if ($update_superscore && (!$update_highscore || !$equal_hs_user))
									{
										$sql = 'UPDATE ' . ARCADE_USERS_TABLE . '
												SET arcade_total_super_scores = arcade_total_super_scores - 1
												WHERE user_id = ' . $super_champion_id;
										$this->db->sql_query($sql);
									}

									$score_desc = $this->user->lang['ARCADE_CONGRAT'] . ' ';

									if ($first_score)
									{
										$score_desc .= sprintf($this->user->lang['ARCADE_SCORE_FIRST_SAVED'], $game_data['game_name'], $nf_score);
									}
									else if (!$super_champion_id || ($super_champion_id && $game_data['game_highscore'] != $super_champion['score']))
									{
										$own = ($game_data['game_highuser'] == $this->user->data['user_id']) ? '_OWN' : '';
										$score_desc .= sprintf($this->user->lang['ARCADE_SCORE_NEW' . $own . '_HIGH_SCORE_SAVED'], $game_data['game_name'], $nf_score, $game_highscore);
									}

									if ($super_champion_id)
									{
										$score_desc .= ($first_score || ($game_data['game_highscore'] != $super_champion['score'])) ? '<br>' : '';
										$own = ($super_champion_id == $this->user->data['user_id']) ? '_OWN' : '';
										$score_desc .= sprintf($this->user->lang['ARCADE_SCORE_NEW' . $own . '_SUPER_RECORD_SAVED'], $game_data['game_name'], $nf_score, $super_score);
									}

									if ($this->arcade->points()->data['show'])
									{
										$super_reward		= (float) $this->arcade_config['super_record_reward'];
										$add_super_points	= ($super_champion_id && $super_reward > 0) ? true : false;

										$s_points			= (!$first_score || $this->arcade_config['first_score_reward']) ? true : false;
										$add_points			= ($s_points && (!$this->arcade_auth->acl_get('c_playfree', $game_data['cat_id']) || ($this->arcade_auth->acl_get('c_playfree', $game_data['cat_id']) && $this->arcade_config['playfree_reward']))) ? true : false;

										if ($add_points)
										{
											$reward = $this->arcade->points()->game_reward($game_data);

											if ($reward > 0)
											{
												// If we are using the jackpot setting we must clear the jackpot
												if ($this->arcade->points()->use_game_jackpot($game_data))
												{
													$this->arcade->points()->set_game_jackpot('clear', $game_data);
												}
											}
											else
											{
												$add_points = false;
											}
										}

										if ($add_points || $add_super_points)
										{
											$total_reward = ($add_points && $add_super_points) ? ($reward + $super_reward) : (($add_points) ? $reward : $super_reward);
											$this->arcade->points()->set('add', $this->user->data['user_id'], $total_reward);

											$msg = (($add_points && $add_super_points) ? '(' . $this->arcade->number_format($reward) . ' + ' . $this->arcade->number_format($super_reward) . ')' : $this->arcade->number_format(($add_points) ? $reward : $super_reward)) . ' ' . $this->arcade->points->data['name'];
											$score_desc .= '<br><br>' . $this->user->lang['ARCADE_CONGRAT'] . ' ' . sprintf($this->user->lang['ARCADE_SCORE_ADD_REWARD'], $msg, $this->arcade->points()->data['name'], $this->arcade->number_format($this->arcade->points()->data['total']) . ' ' . $this->arcade->points()->data['name']);
										}
									}

									if ($this->arcade->shout()->data['show'] && $score > 0)
									{
										$ignore_cat_ids = array_map('intval', explode(',', $this->arcade_config['shout_ignore_cats']));

										if (!in_array($game_data['cat_id'], $ignore_cat_ids))
										{
											$scd = array(
												'first_score'			=> $first_score,
												'own_new_highscore'		=> ($game_data['game_highuser'] == $this->user->data['user_id']) ? true : false,
												'first_super_score'		=> (!$super_champion_id && $save_superscore) ? true : false,
												'new_superscore'		=> ($super_champion_id && $save_superscore) ? true : false,
												'own_new_superscore'	=> ($super_champion_id == $this->user->data['user_id']) ? true : false,
											);

											if ($msg = $this->arcade->shout()->msg($scd, $game_data, $nf_score))
											{
												$this->arcade->shout()->send($msg, $game_data['current_time'], $this->arcade_config['shout_user_id']);
											}
										}
									}
								}
								else
								{
									if (!$save_score)
									{
										$score_desc = sprintf($this->user->lang['ARCADE_SCORE_NO_SAVED'], $nf_score, $this->arcade->number_format($old_score));
									}
									else
									{
										$score_desc = sprintf($this->user->lang['ARCADE_SCORE_SAVED'], $nf_score, $game_highscore);
									}

									if ($my_place > 0)
									{
										$score_desc .= '<br>' . sprintf($this->user->lang['ARCADE_SCORE_PLACE'], $this->arcade->number_format($my_place));
									}
								}

								$cat_ary = array(
									'cat_last_play_game_id'		=> $game_data['game_id'],
									'cat_last_play_game_name'	=> $game_data['game_name'],
									'cat_last_play_user_id'		=> $this->user->data['user_id'],
									'cat_last_play_score'		=> $score,
									'cat_last_play_time'		=> $game_data['current_time'],
									'cat_last_play_username'	=> $this->user->data['username'],
									'cat_last_play_user_colour'	=> $this->user->data['user_colour']
								);

								$this->arcade->game()->update_plays($game_data['game_id'], $game_data['cat_id'], $game_data['total_time'], $game_data['current_time'], $game_ary, $cat_ary, false, $new_highscore, $new_superscore);

								if ($this->save_highscore)
								{
									$this->arcade->cache_purge('score');
								}

								if ($this->arcade_config['game_comment'] && $this->arcade_auth->acl_get('c_comment', $game_data['cat_id']))
								{
									$this->user->add_lang('posting');

									$comment_data = array(
										'text'			=> '',
										'allow_bbcode'	=> true,
										'allow_smilies'	=> true,
										'allow_urls'	=> true
									);

									if (isset($sdata['comment_text']))
									{
										$comment_data = generate_text_for_edit($sdata['comment_text'], $sdata['comment_uid'], $sdata['comment_options']);
									}

									add_form_key('arcade_score');

									$enable_bbcode	= ($this->arcade_config['parse_bbcode']) ? (bool) $this->arcade->optionget('bbcode') : false;
									$enable_smilies	= ($this->arcade_config['parse_smilies']) ? (bool) $this->arcade->optionget('smilies') : false;
									$enable_urls	= ($this->arcade_config['parse_links']) ? true : false;
									$enable_img		= false;
									$enable_flash	= false;
									$enable_qoute	= false;

									if ($enable_smilies && !$this->arcade->game()->session->game_popup)
									{
										// Generate smiley listing
										if (!function_exists('generate_smilies'))
										{
											include($this->root_path . 'includes/functions_posting.' . $this->php_ext);
										}

										generate_smilies('inline', false);
									}

									if ($enable_bbcode)
									{
										// Build custom bbcodes array
										if (!function_exists('display_custom_bbcodes'))
										{
											include($this->root_path . 'includes/functions_display.' . $this->php_ext);
										}

										display_custom_bbcodes();
									}

									$s_hidden_fields = array(
										'mode'				=> 'score',
										'g'					=> $game_data['game_id'],
										'c'					=> $game_data['cat_id'],
										'arcade_gsid'		=> $this->request->variable('arcade_gsid', ''),
										'game_sid'			=> $this->request->variable('game_sid', ''),
										'game_challenge'	=> $game_challenge,
										'game_tournament'	=> $game_tournament
									);

									if ($this->arcade->game()->session->game_popup)
									{
										$s_hidden_fields['gp'] = $this->arcade->game()->session->game_popup;
									}

									$this->game_over($score_desc);

									$this->template->assign_vars(array(
										'S_ACTION'				=> $this->arcade->url() . '#game_done',
										'S_HIDDEN_FIELDS'		=> build_hidden_fields($s_hidden_fields),
										'S_BBCODE_ALLOWED'		=> $enable_bbcode,
										'S_SMILIES_ALLOWED'		=> ($enable_smilies) ? true : false,
										'S_SMILIES_POPUP'		=> ($enable_smilies && $this->arcade->game()->session->game_popup) ? true : false,
										'S_LINKS_ALLOWED'		=> $enable_urls,

										'S_BBCODE_CHECKED'		=> (!$comment_data['allow_bbcode']) ? ' checked="checked"' : '',
										'S_SMILIES_CHECKED'		=> (!$comment_data['allow_smilies']) ? ' checked="checked"' : '',
										'S_MAGIC_URL_CHECKED'	=> (!$comment_data['allow_urls']) ? ' checked="checked"' : '',

										'S_BBCODE_QUOTE'		=> $enable_qoute,
										'S_BBCODE_FLASH'		=> $enable_flash,
										'S_BBCODE_IMG'			=> $enable_img,

										'U_SMILIES'				=> append_sid("{$this->root_path}posting.{$this->php_ext}", 'mode=smilies'),

										'BBCODE_STATUS'			=> sprintf($this->user->lang['BBCODE_IS_' . (($enable_bbcode) ? 'ON' : 'OFF')], '<a href="' . append_sid("{$this->root_path}faq.{$this->php_ext}", 'mode=bbcode') . '">', '</a>'),
										'IMG_STATUS'			=> $this->user->lang['IMAGES_ARE_' . (($enable_img) ? 'ON' : 'OFF')],
										'FLASH_STATUS'			=> $this->user->lang['FLASH_IS_' . (($enable_flash) ? 'ON' : 'OFF')],
										'SMILIES_STATUS'		=> $this->user->lang['SMILIES_ARE_' . (($enable_smilies) ? 'ON' : 'OFF')],
										'URL_STATUS'			=> $this->user->lang['URL_IS_' . (($enable_urls) ? 'ON' : 'OFF')],

										'GAME_NAME'				=> $game_data['game_name'],
										'SCORE_COMMENT'			=> $comment_data['text'],
										'POPUP_HEIGHT'			=> $this->arcade_config['smilies_popup_height'],
										'POPUP_WIDTH'			=> $this->arcade_config['smilies_popup_width']
									));

									if (!$this->arcade->game()->session->game_popup && $this->auth->acl_get('u_arcade_view_whoisplaying'))
									{
										$this->arcade->display()->online_playing();
									}

									$this->arcade->display()->page($this->user->lang['INDEX'], 'arcade/score_body.html');
								}

								$this->game_over($score_desc);
								$this->done($game_data, $game_challenge, $game_tournament);
							}
						break;
					}
				}
			}
		}

		// Something went wrong or bot, lets send them to the arcade index.
		redirect($this->arcade->url());
	}

	private function game_over($msg = '')
	{
		$game_over = ($msg != '') ? true : false;
		$popup = $this->arcade->game()->session->game_popup;
		$save_highscore = (!empty($this->save_highscore)) ? true : false;

		if ($game_over)
		{
			$vars = array('save_highscore', 'popup');
			extract($this->arcade->phpbb_dispatcher()->trigger_event('jv.arcade.game.score.game_over', compact($vars)));
		}

		$this->template->assign_vars(array(
			'S_ARCADE_GAME_OVER'		=> $game_over,
			'S_GAME_NEW_RECORD'			=> (!empty($this->save_highscore)) ? true : false,
			'S_ARCADE_GAME_OVER_SOUND'	=> ($this->arcade_config['game_over_sound'] && $this->arcade->optionget('game_over_sound')),
			'S_USE_SIMPLE_HEADER'		=> $this->arcade->game()->session->game_popup,

			'ARCADE_SCORE_DESC'			=> $msg
		));

		if ($this->arcade->optionget('game_over_animation') && (($this->arcade_config['anim_game_over_winner'] && $save_highscore) || ($this->arcade_config['anim_game_over_losing'] && !$save_highscore)))
		{
			$this->template->assign_vars(array(
				'S_ARCADE_GAME_OVER_ANIMATION_' . (($save_highscore) ? 'NEW_RECORD' : 'LOSING') => true,
				'S_ARCADE_GAME_OVER_ANIMATION_SOUND'	=> $this->arcade->optionget('game_over_animation_sound'),

				'SRC_ARCADE_GAME_OVER_ANIMATION'		=> "{$this->arcade->ext_path()}animation/game_over/index.html"
			));
		}
	}

	private function send_pm_loser_user($mode, $user_id, $old_score, $new_score, $game_data)
	{
		$other_user = $this->arcade->userdata('set_auth', $user_id);

		if ($this->arcade->optionget('arcade_pm', $other_user['user_arcade_options'], true))
		{
			$auth2 = new \phpbb\auth\auth();
			$auth2->acl($other_user);

			if ($auth2->acl_get('u_arcade_pm'))
			{
				// This sets the score data that is available to use
				// in the pm sent when you lose a highscore. It
				// is customizable in the ACP
				$score_data = array(
					'cat_id'					=> $game_data['cat_id'],
					'game_id'					=> $game_data['game_id'],
					'game_name'					=> $game_data['game_name'],
					'old_score'					=> $old_score,
					'new_score'					=> $new_score,
					'game_image'				=> $game_data['game_image'],
					'game_width'				=> $game_data['game_width'],
					'game_height'				=> $game_data['game_height'],

					'other_user_id'				=> $other_user['user_id'],
					'other_username'			=> $other_user['username'],
					'other_user_colour'			=> $other_user['user_colour'],
					'other_user_lang'			=> $other_user['user_lang'],
					'other_user_arcade_options'	=> $other_user['user_arcade_options']
				);

				$this->arcade->phpbb()->send_pm($mode, $score_data);

				unset($score_data);
			}

			unset($auth2);
		}

		unset($other_user);
	}

	private function done($game_info = false, $game_challenge = false, $game_tournament = false)
	{
		$s_nav = (!$this->arcade->game()->session->game_popup && !$game_info) ? true : false;

		if (!$game_info)
		{
			$game_info = $this->arcade->get()->game_cat_data($this->game_id, true);
		}

		if ($s_nav)
		{
			$this->arcade->add_navlink('cat_game', 'mode=play', '', $game_info);
		}

		if ($this->arcade->game()->session->game_popup)
		{
			$message  = sprintf($this->user->lang['ARCADE_POPUP_DONE'], $game_info['game_name'], '<a href="' . $this->arcade->url("mode=" . (($this->arcade->game()->session->game_popup) ? 'popup' : 'play') . "&amp;g={$game_info['game_id']}") . '">', $game_info['game_name'], '</a>');
			$message .= $this->arcade->refresh_close_win($game_info);
		}
		else
		{
			$message = sprintf($this->user->lang['ARCADE_FULL_DONE'], $game_info['game_name']) . $this->arcade->return_links($game_info);

			$game_challenge  = (bool) $this->request->variable('game_challenge', $game_challenge);
			$game_tournament = (bool) $this->request->variable('game_tournament', $game_tournament);

			if ($game_challenge && $this->arcade->access('challenge'))
			{
				$message .= '<br><br>' . sprintf($this->user->lang['ARCADE_JUMP_CHALLENGE_MAIN_PAGE'], '<a href="' . $this->arcade->url('mode=challenge') . '">', '</a>');
			}

			if ($game_tournament && $this->arcade->access('tour'))
			{
				$message .= '<br><br>' . sprintf($this->user->lang['ARCADE_JUMP_TOURNAMENT_MAIN_PAGE'], '<a href="' . $this->arcade->url('mode=tournament') . '">', '</a>');
			}
		}

		$this->arcade->game()->session->set_cookie();

		$GLOBALS['arcade_skip_disable_img'] = 1;

		if ($this->arcade->optionget('game_over_random_games') && $this->arcade_config['random_games_game_over_enable'] && $this->arcade_config['random_games_game_over'] > 0)
		{
			$game_ids = $this->arcade->get()->random_game($this->arcade_config['random_games_game_over'], $game_info['cat_id'], $game_info['game_id']);

			if (is_array($game_ids) && count($game_ids))
			{
				foreach (array_values($game_ids) as $gid)
				{
					if ($this->arcade->get()->game_field($gid, 'cat_id', false))
					{
						$this->template->assign_block_vars('random_games', array(
							'GAME_IMAGE' => ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($this->arcade->get()->game_field($gid, 'game_image'), 50, 50, 'x', ($this->arcade->game()->session->game_popup) ? 'popup' : 'play', $this->arcade->get()->game_field($gid, 'cat_id'), $gid) : '',
							'GAME_NAME'  => $this->arcade->get()->game_name($this->arcade->get()->game_field($gid, 'game_name'), true, ($this->arcade->game()->session->game_popup) ? 'popup' : 'play', $this->arcade->get()->game_field($gid, 'cat_id'), $gid, 'x')
						));
					}
				}
			}
		}

		$game_fav_data = $this->arcade->get()->fav_data($this->user->data['user_id'], $game_info["game_id"]);

		$this->template->assign_vars(array(
			'S_SCORE_DONE'			=> true,

			'L_ARCADE_DONE'			=> $message,

			'GAME_RATING_IMG'		=> $this->arcade->set_rating_image($game_info),
			'GAME_FAV_IMG'			=> (is_array($game_fav_data)) ? $this->arcade->set_fav_image($game_fav_data, $game_info['game_id']) : '',
			'GAME_IMAGE'			=> ($this->arcade->optionget('view_game_image')) ? $this->arcade->get()->game_image($game_info['game_image'], 50, 50, 'x', ($this->arcade->game()->session->game_popup) ? 'popup' : 'play', $game_info['cat_id'], $game_info['game_id']) : '',
		));

		unset($GLOBALS['arcade_skip_disable_img']);

		if (!$this->arcade->game()->session->game_popup && $this->auth->acl_get('u_arcade_view_whoisplaying'))
		{
			$this->arcade->display()->online_playing();
		}

		$this->arcade->display()->page($this->user->lang['INDEX'], 'arcade/score_body.html');
	}
}
