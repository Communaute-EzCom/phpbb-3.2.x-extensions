<?php
/**
*
* @package phpBB Arcade
* @version $Id: portal.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc\detect;

class portal
{
	public $data = array();

	protected $config, $arcade;

	public function __construct($config, $arcade)
	{
		$this->config = $config;
		$this->arcade = $arcade;
	}

	public function main()
	{
		$this->data = array(
			'installed'	=> false,
			'show'		=> false,
			'type'		=> false,
			'enabled'	=> false
		);

		if ($this->arcade->ext_enable('board3/portal'))
		{
			$this->data['type'] = ARCADE_BOARD3_PORTAL;
			$this->data['installed'] = true;
			$this->data['enabled'] = !empty($this->config['board3_enable']);
		}
		else if ($this->arcade->ext_enable('stoker/portal'))
		{
			$this->data['type'] = ARCADE_SIMPLE_PORTAL;
			$this->data['installed'] = true;
			$this->data['enabled'] = !empty($this->config['portal_enable']);
		}
		else if ($this->arcade->ext_enable('phpbbireland/portal'))
		{
			$this->data['type'] = ARCADE_KISS_PORTAL;
			$this->data['installed'] = true;
			$this->data['enabled'] = !empty($this->config['portal_enabled']);
		}

		$this->data['show'] = ($this->data['installed'] && $this->data['enabled']) ? true : false;
	}
}
