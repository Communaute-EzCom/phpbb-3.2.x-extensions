<?php
/**
*
* @package phpBB Arcade
* @version $Id: menu.php 1875 2018-02-28 09:40:16Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\inc;

class menu
{
	protected $db, $cache, $user, $auth, $config, $template, $arcade, $arcade_auth, $arcade_config, $php_ext;

	public function __construct($db, $cache, $user, $auth, $config, $template, $arcade, $arcade_auth, $arcade_config, $php_ext)
	{
		$this->db = $db;
		$this->cache = $cache;
		$this->user = $user;
		$this->auth = $auth;
		$this->config = $config;
		$this->template = $template;
		$this->arcade = $arcade;
		$this->arcade_auth = $arcade_auth;
		$this->arcade_config = $arcade_config;
		$this->php_ext = $php_ext;
	}

	public function main()
	{
		foreach ($this->obtain_menu() as $parent_id => $menu)
		{
			if ($menu['menu_display'] && (!$menu['auth'] || $this->auth($menu['auth'])))
			{
				$url = $onclick = '';

				if ($menu['menu_page'])
				{
					$sid = (strpos($menu['params'], 'sid={SID}') !== false) ? $this->user->session_id : false;
					$params = str_replace(array('{USER_ID}', 'sid={SID}'), array($this->user->data['user_id'], ''), $menu['params']);

					if ($menu['menu_page'] == 'onclick')
					{
						$url = '#';
						$onclick = ' onclick="' . $params . '"';
					}
					else
					{
						if ($menu['menu_page'] == 'data-jvarcade')
						{
							$url = '#';
							$onclick = " {$params}";
						}
						else
						{
							$url = $this->arcade->url($params, $menu['menu_page'], $sid, ($menu['menu_top'] == 1) ? true : $menu['menu_top']);
							$onclick = ($menu['new_window']) ? ' onclick="window.open(this.href); return false;"' : '';
						}
					}
				}

				$title = $this->arcade->lang_value($menu['menu_name'] . '_EXPLAIN', true);

				$this->template->assign_block_vars($menu['menu_tpl'], array(
					'URL'		=> $url,
					'FA'		=> ($menu['menu_fa']) ? $menu['menu_fa'] : false,
					'TITLE'		=> ($title) ? $title : $this->arcade->lang_value('ARCADE_' . $menu['menu_name'] . '_EXPLAIN', true),
					'NAME'		=> $this->arcade->lang_value($menu['menu_name']),
					'ONCLICK'	=> $onclick
				));
			}
		}
	}

	private function auth($menu_auth)
	{
		$menu_auth = trim($menu_auth);

		// Generally allowed to access menu if menu_auth is empty
		if (!$menu_auth)
		{
			return true;
		}

		// With the code below we make sure only those elements get eval'd we really want to be checked
		preg_match_all('/(?:
			"[^"\\\\]*(?:\\\\.[^"\\\\]*)*"		|
			\'[^\'\\\\]*(?:\\\\.[^\'\\\\]*)*\'	|
			[(),]								|
			[^\s(),]+)/x', $menu_auth, $match);

		// Valid tokens for auth and their replacements
		$valid_tokens = array(
			'pa:acl_([a-z0-9_]+)'		=> '(int) $this->auth->acl_get(\'\\1\')',
			'pa:aclc_([a-z0-9_]+)'		=> '(int) $this->arcade_auth->acl_getc_global(\'\\1\')',
			'pa:aclf_([a-z0-9_]+)'		=> '(int) $this->auth->acl_getf_global(\'\\1\')',
			'pa:acfg_([a-z0-9_]+)'		=> '!empty($this->arcade_config[\'\\1\'])',
			'pa:!acfg_([a-z0-9_]+)'		=> 'empty($this->arcade_config[\'\\1\'])',
			'pa:cfg_([a-z0-9_]+)'		=> '!empty($this->config[\'\\1\'])',
			'pa:!cfg_([a-z0-9_]+)'		=> 'empty($this->config[\'\\1\'])',
			'pa:user_([a-z0-9_]+)'		=> '!empty($this->user->data[\'\\1\'])',
			'pa:!user_([a-z0-9_]+)'		=> 'empty($this->user->data[\'\\1\'])',
			'pa:points_([a-z0-9_]+)'	=> '!empty($this->arcade->points()->data[\'\\1\'])',
			'pa:portal_([a-z0-9_]+)'	=> '!empty($this->arcade->portal()->data[\'\\1\'])',
			'pa:shout_([a-z0-9_]+)'		=> '!empty($this->arcade->shout()->data[\'\\1\'])',
			'pa:ext_([a-zA-Z0-9_/]+)'	=> '!empty($this->arcade->ext_enable(\'\\1\'))'
		);

		$tokens = $match[0];
		for ($i = 0, $size = count($tokens); $i < $size; $i++)
		{
			$token = &$tokens[$i];

			switch ($token)
			{
				case ')':
				case '(':
				case '&&':
				case '||':
				case ',':
				break;

				default:
					if (!preg_match('#(?:' . str_replace('pa:', '', implode(array_keys($valid_tokens), ')|(?:')) . ')#', $token))
					{
						$token = '';
					}
					else
					{
						$token = 'pa:' . $token;
					}
				break;
			}
		}

		$is_auth = false;

		eval('$is_auth = (int) (' . preg_replace(array_map(function($value) {return '#' . $value . '#';}, array_keys($valid_tokens)), array_values($valid_tokens), implode(' ', $tokens)) . ');');

		return $is_auth;
	}

	public function obtain_menu()
	{
		if (($menu_data = $this->cache->get('_arcade_menu')) === false)
		{
			$data = $menu_data = array();

			$sql = 'SELECT *
					FROM ' . ARCADE_MENU_TABLE . '
					ORDER BY left_id ASC';
			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$data[$row['menu_id']] = array(
						'parent_id'		=> $row['parent_id'],
						'menu_type'		=> $row['menu_type'],
						'menu_name'		=> $row['menu_name'],
						'menu_display'	=> $row['menu_display'],
						'menu_page'		=> $row['menu_page'],
						'menu_top'		=> $row['menu_top'],
						'menu_fa'		=> $row['menu_fa'],
						'new_window'	=> $row['new_window'],
						'params'		=> $row['params'],
						'auth'			=> $row['auth'],
						'left_id'		=> $row['left_id'],
						'right_id'		=> $row['right_id']
				);
			}
			$this->db->sql_freeresult($result);

			$mids = array();
			foreach ($data as $menu_id => $row)
			{
				if (in_array($menu_id, $mids))
				{
					continue;
				}

				// Main menu and sub menu
				$row['menu_tpl'] = (!$row['parent_id']) ? 'arcade_menu' : 'arcade_menu.submenu';
				$menu_data[] = $row;
				$mids[] = $menu_id;

				if ($row['parent_id'])
				{
					foreach ($data as $mid => $sub)
					{
						if ($row['left_id'] < $sub['left_id'] && $row['right_id'] > $sub['right_id'])
						{
							// Sub.sub menu and Sub.sub.sub menu
							$sub['menu_tpl'] = ($menu_id == $sub['parent_id']) ? 'arcade_menu.submenu.subsubmenu' : 'arcade_menu.submenu.subsubmenu.subsubsubmenu';
							$menu_data[] = $sub;
							$mids[] = $mid;
						}
					}
				}
			}

			unset($data);
			$this->cache->put('_arcade_menu', $menu_data);
		}

		return $menu_data;
	}
}
