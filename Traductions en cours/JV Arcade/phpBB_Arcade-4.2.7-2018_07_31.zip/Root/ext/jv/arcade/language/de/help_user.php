<?php
/**
*
* @package phpBB Arcade
* @version $Id: help_user.php 1875 2018-02-28 09:40:16Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'ARCADE_HELP_FAQ_BLOCK_INTRO'						=> 'Einleitung',
	'ARCADE_HELP_FAQ_BLOCK_GENERAL'						=> 'Allgemeine Fragen',
	'ARCADE_HELP_FAQ_BLOCK_USER_SET'					=> 'Benutzereinstellungen',
	'ARCADE_HELP_FAQ_BLOCK_PLAYING'						=> 'Fragen zu den spielen',
	'ARCADE_HELP_FAQ_BLOCK_CAT'							=> 'Fragen zu den Kategorien',
	'ARCADE_HELP_FAQ_BLOCK_SEARCH'						=> 'Fragen zur Suche',
	'ARCADE_HELP_FAQ_BLOCK_FAV'							=> 'Fragen zu deinen Lieblingsspielen',
	'ARCADE_HELP_FAQ_BLOCK_CHALLENGE'					=> 'Fragen zu den Herausforderungen',
	'ARCADE_HELP_FAQ_BLOCK_TOUR'						=> 'Fragen zu den Turnieren',
	'ARCADE_HELP_FAQ_BLOCK_POINTS'						=> 'Fragen zum Punktesystem',
	'ARCADE_HELP_FAQ_BLOCK_ARCADE'						=> 'Fragen zu phpBB Arcade',
// step 1
	'ARCADE_HELP_FAQ_INTRO_ARCADE_ANSWER'				=> 'Die Spielhalle bietet Unterhaltung für die Benutzer, mit einer Vielzahl von Flash und HTML5-Spielen. Die Berechtigung, die Spielhalle zu benutzen, wird vom Administrator festgelegt. Doch bestimmte Funktionen können auch über den Persönlichen Bereich ein- oder ausgeschaltet werden. Dafür wirst du vielleicht diese Anleitung nützlich finden.',
	'ARCADE_HELP_FAQ_INTRO_ARCADE_QUESTION'				=> 'Was ist die Spielhalle?',

	'ARCADE_HELP_FAQ_INTRO_REG_ANSWER'					=> 'Abhängig von den Einstellungen des Administrators der Spielhalle, kann es möglich sein, dass eine Registrierung nicht unbedingt erforderlich ist, um die Spiele zu verwenden. Es ist aber anzumerken, dass du, wenn du dich registrierst, Zugriff auf viele weitere Funktionen der Spielhalle hast. (Beispielsweise kannst du deine Punkte und Fortschritte speichern, die Spiele kommentieren, deine Lieblingsspiele als Favoriten speichern, die Spiele bewerten, anderen Benutzern eine Herausforderung für ein Duell senden, oder an einem gestarteten Turnier teilnehmen, und andere nützliche Dinge.) Natürlich ist auch die Verwendung dieser Funktionen abhängig von den Einstellungen des Administrators, so dass dir manche vielleicht nicht zur Verfügung stehen.',
	'ARCADE_HELP_FAQ_INTRO_REG_QUESTION'				=> 'Warum soll ich mich überhaupt registrieren?',

	'ARCADE_HELP_FAQ_INTRO_FUN_ANSWER'					=> 'Die Spielhalle bietet viele Funktionen, allerdings werden nur die verfügbar sein, die vom Administrator eingeschaltet wurden.
															<br><strong>Funktionen:</strong>
															<ul>
																<li>Einstellungen anpassen.</li>
																<li>Spielekategorien.</li>
																<li>Anzeige neuer Spiele.</li>
																<li>Zufälliges Spiel spielen.</li>
																<li>Lieblingsspiele speichern und auswählen.</li>
																<li>Spiele bewerten.</li>
																<li>Spiele suchen.</li>
																<li>Fehler in Spielen melden.</li>
																<li>Spiele herunterladen.</li>
																<li>Spiele in einem neuen Fenster spielen (Popup).</li>
																<li>Spielen im Vollbild.</li>
																<li>Ändern der Größe von Spielen.</li>
																<li>Hintergrundbeleuchtung für Spiele an / aus.</li>
																<li>Turniere mit mehreren Spielen, zwischen mehreren Benutzern.</li>
																<li>Herausforderung anderer Mitglieder für einzelne Spiele.</li>
																<li>Erzeugen von Zufallsherausforderungen.</li>
																<li>Separate detaillierte Statistiken.</li>
																<li>Spiele-Statistiken.</li>
																<li>Benutzerstatistiken.</li>
																<li>Kategorienstatistiken.</li>
																<li>Rangliste.</li>
																<li>Verwendung von Punktesystemen.</li>
																<li>Und vieles mehr…</li>
															</ul>',
	'ARCADE_HELP_FAQ_INTRO_FUN_QUESTION'				=> 'Welche Funktionen bietet die Spielhalle?',
// step 2
	'ARCADE_HELP_FAQ_GENERAL_GAME_RATING_ANSWER'		=> 'Die Spiele-Bewertung ist eine nützliche Funktion. Sie erleichtert das Finden guter Spiele. Wenn ein Spiel gut ist, werden viele Benutzer eine hohe Bewertung abgeben, und es wird in der Statistik immer oben liegen. Damit sind die am besten bewerteten Spiele für die Benutzer leicht zu finden.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_RATING_QUESTION'		=> 'Was ist die Spiele-Bewertung?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_RANDOM_ANSWER'		=> 'Ein zufällig vom System ausgewähltes Spiel ist eine schöne Sache, weil das Spiel nicht in einer bestimmten Kategorie ausgewählt wird. So wird es auf Dauer nicht langweilig, weil du beispielsweise oft andere Spiele, und nicht immer in der gleichen Kategorie, spielst.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_RANDOM_QUESTION'		=> 'Was ist ein zufälliges Spiel?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_BUG_ANSWER'			=> 'Zuerst warte bitte einen Moment. Manche Spiele haben wegen ihrer Größe eine längere Ladezeit. Ein defektes Spiel sollte dem Administrator gemeldet werden, damit dieser das Problem so schnell wie möglich lösen kann. Jedes Spiel enthält einen Link für eine Fehlermeldung, der dafür verwendet werden soll. Bitte verwende diesen Link, denn er enthält alle für uns wichtigen, spezifischen Informationen zum Spiel, und du kannst auswählen, welche Art von Problem aufgetreten ist. Eine ausführlichere Fehlerbeschreibung wäre wünschenswert. Bitte teile uns auch mit, welcher Browser in welcher Version verwendet wurde, denn es ist nicht sicher, dass dieser Fehler bei anderen Browsern ebenfalls auftritt.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_BUG_QUESTION'			=> 'Was ist zu tun, wenn ein Spiel nicht funktioniert?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_DOWNLOAD_ANSWER'		=> 'Ja, wenn der Administrator das erlaubt.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_DOWNLOAD_QUESTION'	=> 'Können die Spiele heruntergeladen werden?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_NAME_LINK_ANSWER'		=> 'Der Spielname erscheint nur dann als Link, wenn du die notwendigen Spielberechtigungen besitzt.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_NAME_LINK_QUESTION'	=> 'Die meisten Namen der Spiele sind Links, aber einige erscheinen als Klartext. Warum?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_USER_STAT_ANSWER'		=> 'Wenn die Berechtigung zur Benutzung des Menüs erteilt wurde, kannst du auf das Menü „Statistiken“ klicken, und daraus unterhalb den Eintrag „Benutzer“ wählen.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_USER_STAT_QUESTION'	=> 'Wie kann ich die Spielestatistik der Benutzer ansehen?',

	'ARCADE_HELP_FAQ_GENERAL_USER_RECORD_ANSWER'		=> 'Ja, dazu klickst du in der Spielhalle auf das Avatar des Benutzers, um die Benutzerinformation zu öffnen, und dann auf den Link unter dem Avatar „Benutzerrekorde ansehen“.',
	'ARCADE_HELP_FAQ_GENERAL_USER_RECORD_QUESTION'		=> 'Kann ich mir nur die Rekorde eines Benutzers ansehen?',

	'ARCADE_HELP_FAQ_GENERAL_SUPER_CHAMP_ANSWER'		=> 'Der Superchampion ist der oberste aller Meister, der den höchsten, jemals erreichten, Rekord eines Spieles hält. Der Superchampion hat keine normale Meisterschaft, außer er hält auch in der aktuellen Spielperiode einen Rekord auf dem ersten Platz. Wenn der Administrator die Spielhalle neu startet, werden die Rekorde zurückgesetzt. Er hat aber die Möglichkeit, die Punktstände der Superchampions zu erhalten, so dass man immer sehen kann, welches Ergebnis das höchste, jemals erreichte, für das Spiel war.',
	'ARCADE_HELP_FAQ_GENERAL_SUPER_CHAMP_QUESTION'		=> 'Was ist ein Superchampion?',

	'ARCADE_HELP_FAQ_GENERAL_RANG_LIST_ANSWER'			=> 'Die Rangliste berücksichtigt die Anzahl der verdienten Meisterschaften der Benutzer. Je mehr Meisterschaften ein Benutzer erreicht hat, umso höher ist sein Rang. Die Rangbilder können durch den Administrator bestimmt werden, und zwar in der Weise, dass sie mit einer zu erreichenden Anzahl von Meisterschaften verbunden werden, und entsprechend erscheinen.',
	'ARCADE_HELP_FAQ_GENERAL_RANG_LIST_QUESTION'		=> 'Was ist die Rangliste?',
// step 3
	'ARCADE_HELP_FAQ_USER_SET_CONFIG_ANSWER'			=> 'Wenn du ein registrierter Benutzer bist, werden alle deine Einstellungen in der Datenbank gespeichert. Um sie zu ändern, klicke auf den Link „Persönlicher Bereich“ (normalerweise zu sehen am oberen Seitenrand). Dort kannst du alle hier genannten Einstellungen bearbeiten.',
	'ARCADE_HELP_FAQ_USER_SET_CONFIG_QUESTION'			=> 'Wie kann ich meine Einstellungen ändern?',

	'ARCADE_HELP_FAQ_USER_SET_CHALL_DISABLE_ANSWER'		=> 'Wenn du von anderen Benutzern keine Herausforderungen zu einem Wettkampf erhalten möchtest, kannst du die Funktion abschalten. Du wirst dann auch selbst nicht in der Lage sein, einen anderen Benutzer herauszufordern. Bitte beachte, dass die Herausforderung auch durch den Administrator für alle abgeschaltet werden kann.',
	'ARCADE_HELP_FAQ_USER_SET_CHALL_DISABLE_QUESTION'	=> 'Du möchtest die Herausforderungen abschalten?',

	'ARCADE_HELP_FAQ_USER_SET_IMG_DISABLE_ANSWER'		=> 'Wenn das Laden der Seite zu langsam ist, kannst du die Anzeige der Avatare und Bilder abschalten.',
	'ARCADE_HELP_FAQ_USER_SET_IMG_DISABLE_QUESTION'		=> 'Du möchtest die Anzeige von Avataren und Bildern der Spiele abschalten?',

	'ARCADE_HELP_FAQ_USER_SET_CAT_STYLE_ANSWER'			=> 'Die Spielhalle kann in verschiedenen Stilrichtungen angezeigt werden. Du kannst auswählen, welche du verwenden möchtest. Diese Einstellung kann vom Administrator vorgegeben und überschrieben werden.',
	'ARCADE_HELP_FAQ_USER_SET_CAT_STYLE_QUESTION'		=> 'Was ist der Kategoriestil?',

	'ARCADE_HELP_FAQ_USER_SET_FAV_MANAGE_ANSWER'		=> 'Hier kannst du deine als Favoriten hinzugefügten Lieblingsspiele wieder entfernen, oder markieren und hervorheben.',
	'ARCADE_HELP_FAQ_USER_SET_FAV_MANAGE_QUESTION'		=> 'Was ist Favoriten verwalten?',
// step 4
	'ARCADE_HELP_FAQ_PLAYING_NOT_PLAY_ANSWER'			=> 'Das kann mehrere unterschiedliche Gründe haben:
															<ul>
																<li>Damit die Spiele laufen, ist es wichtig, dass der <a href="http://www.adobe.com/go/getflashplayer/" title="Adobe Flash Player herunterladen">„Flash Player“</a> auf deinem Computer installiert ist, bevorzugt in der neuesten Version.</li>
																<li>Möglicherweise verfügt der Browser nicht über „JavaScript“, oder dieses ist auf der Seite deaktiviert.</li>
																<li>Der Administrator hat keine Berechtigung zum Spielen erteilt.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_NOT_PLAY_QUESTION'			=> 'Warum kann ich nicht spielen?',

	'ARCADE_HELP_FAQ_PLAYING_NOT_SAVE_SCORE_ANSWER'		=> 'Das kann mehrere unterschiedliche Gründe haben:
															<ul>
																<li>Stelle zuerst sicher, dass die Verwendung von „Cookies“ in deinem Browser erlaubt ist.</li>
																<li>Stelle sicher, dass du angemeldet bist.</li>
																<li>Das Spiel wurde nicht korrekt gestartet.</li>
																<li>Das Spiel ist defekt.</li>
																<li>Der Administrator hat keine Berechtigung zum Speichern der Punkte erteilt.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_NOT_SAVE_SCORE_QUESTION'	=> 'Warum kann ich meine Ergebnisse nicht speichern?',

	'ARCADE_HELP_FAQ_PLAYING_GAME_SIZE_ANSWER'			=> 'Einige Spiele passen sich dem Spielfeld nicht so gut an. Du hast dann die Möglichkeit, den Informationsblock zu schließen, um den Platz für das Spiels zu vergrößern. Es ist außerdem möglich, die zoom in/zoom out-Funktion zu benutzen, und im Vollbild oder in einem neuen Fenster zu spielen, wenn der Administrator die Berechtigung erteilt hat.',
	'ARCADE_HELP_FAQ_PLAYING_GAME_SIZE_QUESTION'		=> 'Was ist zu tun, wenn das Spiel zu groß oder zu klein ist?',

	'ARCADE_HELP_FAQ_PLAYING_POPUP_ANSWER'				=> 'Ja, wenn der Administrator es erlaubt hat.',
	'ARCADE_HELP_FAQ_PLAYING_POPUP_QUESTION'			=> 'Kann ich die Spiele in einem neuen Fenster spielen?',

	'ARCADE_HELP_FAQ_PLAYING_FULL_SCREEN_ANSWER'		=> 'Ja, wenn der Administrator die Änderung der Spielauflösung erlaubt hat.',
	'ARCADE_HELP_FAQ_PLAYING_FULL_SCREEN_QUESTION'		=> 'Kann ich die Spiele im Vollbild spielen?',

	'ARCADE_HELP_FAQ_PLAYING_MOBILE_ANSWER'				=> 'Ja, doch in den absolut meisten Fällen funktionieren nur Html5-Spiele auf Mobilgeräten.',
	'ARCADE_HELP_FAQ_PLAYING_MOBILE_QUESTION'			=> 'Kann ich mit einem Mobiltelefon spielen?',

	'ARCADE_HELP_FAQ_PLAYING_BACKLIGHT_ANSWER'			=> 'Die Hintergrundbeleuchtung verfügt über zwei nützliche Eigenschaften.
															<ul>
																<li>Das Spiel wird ungestört über einem abgedunkelten Raum ausgeführt.</li>
																<li>Die Buttons und Links außerhalb des Spiels sind inaktiv, so dass man nicht versehentlich darauf klicken kann. Das verhindert das Laden einer anderen Seite während des Spiels.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_BACKLIGHT_QUESTION'		=> 'Was ist die Hintergrundbeleuchtung?',

	'ARCADE_HELP_FAQ_PLAYING_WHITE_SCREEN_ANSWER'		=> 'Es kann sein, dass das Spiel sehr umfangreich ist, und du bei einer langsameren Internetverbindung etwas warten musst, bis es geladen wurde.',
	'ARCADE_HELP_FAQ_PLAYING_WHITE_SCREEN_QUESTION'		=> 'Das Spiel startet mit einem weißen Bildschirm, warum?',

	'ARCADE_HELP_FAQ_PLAYING_HIDDEN_SCORE_ANSWER'		=> 'Für das fragliche Spiel läuft gerade eine Herausforderung, und die Ergebnisse werden so lange vor allen beteiligten Personen versteckt, bis die Herausforderung beendet ist.',
	'ARCADE_HELP_FAQ_PLAYING_HIDDEN_SCORE_QUESTION'		=> 'In der Ergebnisliste steht für den Meister, statt eines Rekordes, der Text „versteckt“ , warum?',
// step 5
	'ARCADE_HELP_FAQ_CAT_USER_PERMISSION_ANSWER'		=> 'Wenn du eine Kategorie betrittst, findest du ganz unten „Spielhallenbefugnisse“, und darunter die für dich geltenden Berechtigungen.',
	'ARCADE_HELP_FAQ_CAT_USER_PERMISSION_QUESTION'		=> 'Welche Berechtigungen gelten für mich?',

	'ARCADE_HELP_FAQ_CAT_PASSWORD_ANSWER'				=> 'Wenn eine Kategorie durch ein Passwort geschützt ist, musst du einen Administraor danach fragen.',
	'ARCADE_HELP_FAQ_CAT_PASSWORD_QUESTION'				=> 'Die Kategorie erfordert ein Passwort, was ist zu tun?',

	'ARCADE_HELP_FAQ_CAT_AGE_ANSWER'					=> 'Es ist möglich, dass Administratoren leicht zu spielende Spiele für Kinder in einer Kategorie gesammelt haben, und nur Jugendliche darin spielen können. Ebenso ist es möglich, dass sich Spiele in einer Kategorie befinden, die für Minderjährige nicht geeignet sind, und die können dann nur von Erwachsenen gespielt werden.',
	'ARCADE_HELP_FAQ_CAT_AGE_QUESTION'					=> 'Einige Kategorien sind durch eine Altersbegrenzung geschützt, warum?',

	'ARCADE_HELP_FAQ_CAT_STAT_ANSWER'					=> 'Ja, wenn du eine Kategorie betrittst, wirst du den Link „Kategorienstatistik ansehen“ neben dem Namen der Kategorie sehen.',
	'ARCADE_HELP_FAQ_CAT_STAT_QUESTION'					=> 'Ich möchte die Statistik für bestimmte Kategorien ansehen, geht das?',
// step 6
	'ARCADE_HELP_FAQ_SEARCH_GAME_ANSWER'				=> 'Wenn die Suchfunktion eingeschaltet ist, kannst du etwa in der Mitte der Seite ein Suchfeld finden, wo du den Namen des gewünschten Spiels eingeben kannst. Die Suche berücksichtigt auch die Spielbeschreibungen, so dass auch Spiele ausgegeben werden, in deren Beschreibung das gesuchte Wort vorkommt.',
	'ARCADE_HELP_FAQ_SEARCH_GAME_QUESTION'				=> 'Wie kann ich ein bestimmtes Spiel finden?',

	'ARCADE_HELP_FAQ_SEARCH_SNIP_GAME_ANSWER'			=> 'Die Suchmaschine berücksichtigt automatisch auch eingegebene Wortteile. Wenn in die Suchbox <strong>pac</strong> eingegeben wird, wird das Spiel <strong>Pacman</strong> gefunden werden.',
	'ARCADE_HELP_FAQ_SEARCH_SNIP_GAME_QUESTION'			=> 'Wie suche ich ein Spiel, dessen Namen ich nicht genau weiß?',
// step 7
	'ARCADE_HELP_FAQ_FAV_ANSWER'						=> 'Wenn du ein Spiel als Lieblingsspiel markierst, ist es später nicht mehr nötig, es unter der großen Anzahl von Spielen zu suchen. In deiner Favoritenliste ist es schnell zu wiederzufinden, und du sparst eine Menge Zeit.',
	'ARCADE_HELP_FAQ_FAV_QUESTION'						=> 'Welchen Nutzen hat es, ein Spiel als Lieblingsspiel zu markieren?',

	'ARCADE_HELP_FAQ_FAV_HIGHLIGHT_ANSWER'				=> 'Du hast die Möglichkeit, die Spiele, die du am meisten spielst, zusätzlich unter den Lieblingsspielen hervorzuheben. Das kannst du in den Einstellungen im Persönlichen Bereich tun.',
	'ARCADE_HELP_FAQ_FAV_HIGHLIGHT_QUESTION'			=> 'Ich habe zu viele Lieblingsspiele. Wie kann ich einige Spiele leichter finden?',
// step 8
	'ARCADE_HELP_FAQ_CHALLENGE_PERMISSION_ANSWER'		=> 'Die Herausforderung ist nur sichtbar, wenn sie eingeschaltet ist, und wenn der Administrator dir den Zugriff erlaubt hat.',
	'ARCADE_HELP_FAQ_CHALLENGE_PERMISSION_QUESTION'		=> 'Warum kann ich die Herausforderung nicht sehen?',

	'ARCADE_HELP_FAQ_CHALLENGE_ACCEPT_ANSWER'			=> 'Wenn du eine Herausforderung erhalten hast, musst du diese zunächst auf der Herausforderungsseite annehmen, und das Spiel dort starten. Erst dann startet das Duell.',
	'ARCADE_HELP_FAQ_CHALLENGE_ACCEPT_QUESTION'			=> 'Ich habe eine Herausforderung erhalten, dann spielte ich das Spiel, aber es steht immer noch da, dass ich eine Herausforderung erhalten habe. Warum wurde das Spiel nicht berücksichtigt?',

	'ARCADE_HELP_FAQ_CHALLENGE_START_ANSWER'			=> 'Auf der Herausforderungsseite klickst du auf den Button „Herausforderung“, und wählst die gewünschten Einstellungen aus dem Formular. Hier hast du die folgenden Möglichkeiten:
															<ul>
																<li>Ein Spiel aus der Liste wählen.</li>
																<li>Ein Lieblingsspiel auswählen. <em>Nur möglich, wenn du Lieblingsspiele gespeichert hast.</em></li>
																<li>Den Gegner aus der Benutzerliste wählen.</li>
																<li>Den Gegner aus der Freundesliste wählen. <em>Nur möglich, wenn du Freunde gespeichert hast.</em></li>
															</ul>
															<br>Nachdem du ein Spiel und einen Gegner gewählt hast, kannst du mit einem Klick auf den Button „Herausforderung senden“ die Anfrage absenden. Der Gegner muss darauf antworten, damit das Duell starten kann.
															<br>Hinweis: <em>Wenn ein Punktesystem installiert und aktiv ist, kannst du auch einen Spieleinsatz festlegen. Der Spieleinsatz kann wählbar, oder durch den Administrator fest vorgegeben sein.</em>',
	'ARCADE_HELP_FAQ_CHALLENGE_START_QUESTION'			=> 'Wie starte ich eine Herausforderung?',

	'ARCADE_HELP_FAQ_CHALLENGE_ARRIVED_ANSWER'			=> 'Jemand möchte ein Spiel gegen dich spielen, und hat dir eine Herausforderung gesendet. Du kannst annehmen, oder ablehnen.',
	'ARCADE_HELP_FAQ_CHALLENGE_ARRIVED_QUESTION'		=> 'Was bedeutet „Herausforderung erhalten“?',

	'ARCADE_HELP_FAQ_CHALLENGE_SENT_ANSWER'				=> 'Das sind die Herausforderungen, die du gegen andere Benutzer gestartet hast. Diese Duelle können auch abgebrochen werden.',
	'ARCADE_HELP_FAQ_CHALLENGE_SENT_QUESTION'			=> 'Was bedeutet „Herausforderungen gesendet“?',

	'ARCADE_HELP_FAQ_CHALLENGE_ONGOING_ANSWER'			=> 'Das sind gestartete Herausforderungen für ein Spiel, die angenommen worden sind, und die von beiden Parteien nun gespielt werden können. Sollte für das Spiel ein Fehler gemeldet werden, wird das Duell abgebrochen.',
	'ARCADE_HELP_FAQ_CHALLENGE_ONGOING_QUESTION'		=> 'Was bedeutet „Laufende Herausforderungen“?',

	'ARCADE_HELP_FAQ_CHALLENGE_GAME_CHAMP_ANSWER'		=> 'Wenn du in dem normalen Fenster spielst, findest du neben dem Spielfeld unter anderem die Box „Spieloptionen“. In dieser Box findest du einen Link „Meister herausfordern“. Du kannst den Rekordhalter einfach herausfordern, indem du auf den Link klickst. Er muss die Herausforderung akzeptieren, ehe das Duell starten kann.',
	'ARCADE_HELP_FAQ_CHALLENGE_GAME_CHAMP_QUESTION'		=> 'Wie kann ich möglichst leicht einen Superchampion herausfordern?',

	'ARCADE_HELP_FAQ_CHALLENGE_PRACTICE_ANSWER'			=> 'Ja, so lange du die Herausforderung noch nicht akzeptiert hast, kannst du das Spiel ohne Bewertung spielen. Doch wenn du die Herausforderung einmal angenommen hast, wird es gewertet, und es gibt keine weitere Möglichkeit zu üben.',
	'ARCADE_HELP_FAQ_CHALLENGE_PRACTICE_QUESTION'		=> 'Ich habe eine Herausforderung erhalten, gibt es eine Möglichkeit dafür zu üben?',

	'ARCADE_HELP_FAQ_CHALLENGE_POINTS_ANSWER'			=> 'Wenn ein Benutzer dich herausfordert, der einen Wetteinsatz von beispielsweise 100 Punkten bestimmt hat, werden diese im Moment der Herausforderung von deinem Guthaben abgezogen. Wenn die Kosten des Spielstarts beispielsweie 5 Punkte betragen, werden auch diese abgezogen. Insgesamt zieht dir das System also 105 Punkte ab, um die gesamten Kosten der Herausforderung zu decken. Falls du die Herausforderung ablehnst, wird dir dieser abgezogene Betrag sofort zurück erstattet. Auch im Falle, dass die Herausforderung angenommen wurde, das Spiel aber nicht gespielt wird, oder dass die Herausforderung vorher abläuft, werden Einsatz und Spielkosten ebenfalls zurück erstattet.',
	'ARCADE_HELP_FAQ_CHALLENGE_POINTS_QUESTION'			=> 'Ich wurde herausgefordert, und verlor eine Menge Guthaben, warum?',

	'ARCADE_HELP_FAQ_CHALLENGE_BUG_GAME_ANSWER'			=> 'In diesem Fall benutze bitte den Link „Spiel melden“, der bei den Spieloptionen enthalten ist. Die Herausforderung wird sofort gelöscht, und dein Wetteinsatz und die Spielkosten werden dir umgehend erstattet.',
	'ARCADE_HELP_FAQ_CHALLENGE_BUG_GAME_QUESTION'		=> 'Ich wurde herausgefordert, aber das betreffende Spiel ist fehlerhaft. Was soll ich tun?',

	'ARCADE_HELP_FAQ_CHALLENGE_DRAW_BET_ANSWER'			=> 'Wenn eine Herausforderung mit einem Unentschieden endet, bekommen beide Spieler ihren Einsatz zurück.',
	'ARCADE_HELP_FAQ_CHALLENGE_DRAW_BET_QUESTION'		=> 'Was passiert mit dem Einsatz, wenn das Duell unentschieden endet?',

	'ARCADE_HELP_FAQ_CHALLENGE_EXP_TIME_ANSWER'			=> 'Das Ablaufdatum steht für die Zeit, zu der die Herausforderungen automatisch gelöscht werden. Bis dahin müssen die Herausforderungen angenommen worden sein.',
	'ARCADE_HELP_FAQ_CHALLENGE_EXP_TIME_QUESTION'		=> 'Was ist das „Ablaufdatum“?',

	'ARCADE_HELP_FAQ_CHALLENGE_END_ANSWER'				=> 'Die Herausforderung sendet bei jeder Runde eine Benachrichtigung als Private Nachricht, wenn der Versand Privater Nachrichten aktiviert ist.',
	'ARCADE_HELP_FAQ_CHALLENGE_END_QUESTION'			=> 'Wie erfahre ich, dass eine Herausforderung beendet ist?',

	'ARCADE_HELP_FAQ_CHALLENGE_PREVENT_ANSWER'			=> 'Du kannst die Herausforderung in den Einstellungen im Persönlichen Bereich abschalten.',
	'ARCADE_HELP_FAQ_CHALLENGE_PREVENT_QUESTION'		=> 'Wie verhindere ich, dass ich herausgefordert werde?',
// step 9
	'ARCADE_HELP_FAQ_TOUR_PRACTICE_ANSWER'				=> 'Ja, bevor das Turnier startet, kannst du die Spiele ohne Bewertung spielen. Doch wenn es einmal gestartet ist, werden alle darin enthaltenen Spiele gewertet, gleichgültig von welchem Ort sie gestartet werden, und es gibt es keine Möglichkeit mehr, dafür zu üben.',
	'ARCADE_HELP_FAQ_TOUR_PRACTICE_QUESTION'			=> 'Gibt es eine Möglichkeit, dafür zu üben?',

	'ARCADE_HELP_FAQ_TOUR_PLAY_NUM_ANSWER'				=> 'Jeder Spielstart wird gezählt, unabhängig davon, ob der Punktestand gespeichert wurde, oder nicht.',
	'ARCADE_HELP_FAQ_TOUR_PLAY_NUM_QUESTION'			=> 'Ich habe ein Spiel gespielt, aber die Punkte wurden nicht gespeichert. Trotzdem wurde die Anzahl der Spielversuche erhöht. Warum?',

	'ARCADE_HELP_FAQ_TOUR_NO_RESULT_ANSWER'				=> 'Nur die für das Turnier zugelassenen Gruppen können teilnehmen. Stelle sicher, dass du Mitglied dieser Gruppe(n) bist.',
	'ARCADE_HELP_FAQ_TOUR_NO_RESULT_QUESTION'			=> 'Ich habe ein Spiel gespielt, aber ich sehe keine Ergebnisse des Turniers. Warum?',

	'ARCADE_HELP_FAQ_TOUR_RIGHT_RESULT_ANSWER'			=> 'Wenn die festgelegte maximale Anzahl an Spielversuchen in einem Turnier erreicht wurde, werden weitere Ergebnisse nicht mehr im Turnier gewertet.',
	'ARCADE_HELP_FAQ_TOUR_RIGHT_RESULT_QUESTION'		=> 'Ich habe ein Spiel noch einmal gespielt, und ein besseres Ergebnis erhalten, aber es wurde im Turnier nicht gewertet. Warum?',
// step 10
	'ARCADE_HELP_FAQ_POINTS_SYSTEM_ANSWER'				=> 'Ein Punktesystem ist eine komplexe Ergänzung, die der Administrator hinzufügen kann, um sie im Forum oder in der Spielhalle zu nutzen. Wenn das Punktesystem verwendet wird, kann in der Spielhalle eine Vielzahl von Kosten und Belohnungen benutzt werden.',
	'ARCADE_HELP_FAQ_POINTS_SYSTE_QUESTION'				=> 'Was ist das Punktesystem?',

	'ARCADE_HELP_FAQ_POINTS_REWARD_ANSWER'				=> 'Die Belohnung erhält man üblicherweise in zwei Fällen: wenn ein Rekord erzielt wird, und wenn ein Superchampiontitel gewonnen wird. Die Höhe der Belohnung legt der Administrator fest.',
	'ARCADE_HELP_FAQ_POINTS_REWARD_QUESTION'			=> 'Was ist die Belohnung?',

	'ARCADE_HELP_FAQ_POINTS_JACKPOT_ANSWER'				=> 'Der Jackpot stammt aus den Spielkosten. Beim Start eines jeden Spieles werden die Spielkosten in einem Topf gesammelt. Dieser wächst so lange an, bis jemand diesen Jackpot gewonnen hat, oder bis die Obergrenze erreicht ist. Die minimale/maximale Höhe des Jackpots wird vom Administrator festgelegt.',
	'ARCADE_HELP_FAQ_POINTS_JACKPOT_QUESTION'			=> 'Was ist der Jackpot?',

	'ARCADE_HELP_FAQ_POINTS_COST_ANSWER'				=> 'Die Spielkosten sind der Betrag, der für jedes Spiel beim Start von deinem Guthaben abgezogen wird. Beachte bitte, dass diese Kosten für einzelne Spiele oder Kategorien unterschiedlich sein können. Die Höhe der Spielkosten legt der Administrator fest.',
	'ARCADE_HELP_FAQ_POINTS_COST_QUESTION'				=> 'Was sind die Spielkosten?',

	'ARCADE_HELP_FAQ_POINTS_DOWNLOAD_COST_ANSWER'		=> 'Die Downloadkosten sind der Betrag, der für jedes Herunterladen eines Spiels von deinem Guthaben abgezogen wird. Beachte bitte, dass diese Kosten für einzelne Spiele oder Kategorien unterschiedlich sein können. Die Höhe der Downloadkosten legt der Administrator fest.',
	'ARCADE_HELP_FAQ_POINTS_DOWNLOAD_COST_QUESTION'		=> 'Was sind die Downloadkosten?',
// step 11
	'ARCADE_HELP_FAQ_ARCADE_CREATE_ANSWER'				=> 'Diese Erweiterung (in ihrer Originalform) wurde von <a href="https://jv-arcade.com/">JV-Arcade Group</a> erstellt, die auch das Urheberrecht ausübt. Sie wurde entwickelt und veröffentlicht unter der GNU General Public License, und kann frei weitergegeben werden. Nähere Informationen finden sich unter diesem Link.',
	'ARCADE_HELP_FAQ_ARCADE_CREATE_QUESTION'			=> 'Wer hat die Arcade geschrieben?',

	'ARCADE_HELP_FAQ_ARCADE_NOT_AVAILABLE_X_ANSWER'		=> 'Diese Erweiterung wurde von der JV-Arcade Group erstellt,und lizenziert. Wenn du glaubst, dass neue Dienste oder Funktionen notwendig sind, oder du Fehler gefunden hast, dann besuche bitte das <a href="https://jv-arcade.com/New_Ideas.html">JV-Arcade New Ideas Centre</a>, wo weitere Informationen verfügbar sind.',
	'ARCADE_HELP_FAQ_ARCADE_NOT_AVAILABLE_X_QUESTION'	=> 'Warum ist Funktion X nicht verfügbar?'
));
