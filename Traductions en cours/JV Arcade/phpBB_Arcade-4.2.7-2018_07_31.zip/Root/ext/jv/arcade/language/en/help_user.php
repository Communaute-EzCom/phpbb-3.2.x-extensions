<?php
/**
*
* @package phpBB Arcade
* @version $Id: help_user.php 1875 2018-02-28 09:40:16Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'ARCADE_HELP_FAQ_BLOCK_INTRO'						=> 'Introduction',
	'ARCADE_HELP_FAQ_BLOCK_GENERAL'						=> 'General Questions',
	'ARCADE_HELP_FAQ_BLOCK_USER_SET'					=> 'User settings',
	'ARCADE_HELP_FAQ_BLOCK_PLAYING'						=> 'Questions about playing',
	'ARCADE_HELP_FAQ_BLOCK_CAT'							=> 'Questions about categories',
	'ARCADE_HELP_FAQ_BLOCK_SEARCH'						=> 'Questions about search',
	'ARCADE_HELP_FAQ_BLOCK_FAV'							=> 'Questions about favorite games',
	'ARCADE_HELP_FAQ_BLOCK_CHALLENGE'					=> 'Questions about challenges',
	'ARCADE_HELP_FAQ_BLOCK_TOUR'						=> 'Questions about tournaments',
	'ARCADE_HELP_FAQ_BLOCK_POINTS'						=> 'Questions about points system',
	'ARCADE_HELP_FAQ_BLOCK_ARCADE'						=> 'Questions about phpBB Arcade',
// step 1
	'ARCADE_HELP_FAQ_INTRO_ARCADE_ANSWER'				=> 'The arcade provides entertainment for the users with a multitude of flash and Html5 games. Permission to use the arcade is defined by the administrator, but certain services can also be enabled/disabled in your User Control Panel. Even with this you may find the following guide useful.',
	'ARCADE_HELP_FAQ_INTRO_ARCADE_QUESTION'				=> 'What is the arcade?',

	'ARCADE_HELP_FAQ_INTRO_REG_ANSWER'					=> 'Depending on the settings of the administrator of the arcade, it may be possible that registration is not necessary to use the games. Please note that if you register and enter the arcade, then many additional useful functions can be accessed within. (For example, you can save your score and progress, comment games, save your games as favorites, rate the games, send a challenge to other users for a duel, participate in a started tournament, and other useful things.) Of course, use of these features depends on the settings of the administrator. Because of your permissions or membergroup, some of them may or may not not be available for you.',
	'ARCADE_HELP_FAQ_INTRO_REG_QUESTION'				=> 'Why should I register at all?',

	'ARCADE_HELP_FAQ_INTRO_FUN_ANSWER'					=> 'In the arcade many features are included, but only those are available which are activated by the administrator.
															<br><strong>Functions:</strong>
															<ul>
																<li>Settings and customizations.</li>
																<li>Game categories.</li>
																<li>Display of new games.</li>
																<li>Playing of random games.</li>
																<li>Store and select favorite games.</li>
																<li>Rating games.</li>
																<li>Search games.</li>
																<li>Report game errors.</li>
																<li>Download games.</li>
																<li>Play games in a new window (popup).</li>
																<li>Play in full screen.</li>
																<li>Change game screen size.</li>
																<li>Backlight for games on/off.</li>
																<li>Tournaments with several games between multiple users.</li>
																<li>Challenge other members in individual games.</li>
																<li>Create of random challenges.</li>
																<li>Separate detailed statistics.</li>
																<li>Game statistics.</li>
																<li>User statistics.</li>
																<li>Category statistics.</li>
																<li>Ranking.</li>
																<li>Use of point systems (via the Points mod).</li>
																<li>And much more…</li>
															</ul>',
	'ARCADE_HELP_FAQ_INTRO_FUN_QUESTION'				=> 'What features are included in the arcade?',
// step 2
	'ARCADE_HELP_FAQ_GENERAL_GAME_RATING_ANSWER'		=> 'The game rating is a useful feature. It makes it easy for users to search according to how users have rated it and if a game is rated good then it will be more popular. The statistics of the game is always at the top of the screen so users can find easily the best rated games.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_RATING_QUESTION'		=> 'What is the game rating?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_RANDOM_ANSWER'		=> 'A random game, chosen by the system, is a beautiful thing because it is not chosen from a specific category. So, it will not be boring in the long run, because you do not always play in the same category, for example.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_RANDOM_QUESTION'		=> 'What is a random game?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_BUG_ANSWER'			=> 'At first wait a moment, please. Some games load a little bit longer, because of their size. A broken game should be reported to the administrator, so that he/she can solve the problem as quickly as possible. Each game contains a link for an error message to be used for this. Please use this link, because it contains all specific information about the game, that is important for us, and you can choose what type of problem has occurred. A more extensive error description is desirable. Please also let us know which browser and which version was used, because it is not certain that this error also occurs in other browsers.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_BUG_QUESTION'			=> 'What to do if a game does not work?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_DOWNLOAD_ANSWER'		=> 'Yes, if authorized by the administrator.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_DOWNLOAD_QUESTION'	=> 'Can the games be downloaded?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_NAME_LINK_ANSWER'		=> 'The game’s name appears as a link, if you are authorized to play this game.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_NAME_LINK_QUESTION'	=> 'The most names of the games are links, but some names will appear as plain text, why?',

	'ARCADE_HELP_FAQ_GENERAL_GAME_USER_STAT_ANSWER'		=> 'If the permission was granted to use the menus, you can click the button “Statistics” button and select “User” below.',
	'ARCADE_HELP_FAQ_GENERAL_GAME_USER_STAT_QUESTION'	=> 'How do I view the game statistics of users?',

	'ARCADE_HELP_FAQ_GENERAL_USER_RECORD_ANSWER'		=> 'Yes, in the arcade, you have to click on the user’s avatar to open the user information, and then click on the link “View all user’s highscores” under his avatar.',
	'ARCADE_HELP_FAQ_GENERAL_USER_RECORD_QUESTION'		=> 'Can I view only the records of a user?',

	'ARCADE_HELP_FAQ_GENERAL_SUPER_CHAMP_ANSWER'		=> 'The super champion is the top champion of all users, who holds the highest-ever achieved record of games. The super champion has no regular trophy, unless he holds a record at the first place in the current period, too. If the administrator resets the arcade it is possible to retain the super champions highscores, so you can always view the highest result ever achieved for the game.',
	'ARCADE_HELP_FAQ_GENERAL_SUPER_CHAMP_QUESTION'		=> 'What is a super champion?',

	'ARCADE_HELP_FAQ_GENERAL_RANG_LIST_ANSWER'			=> 'The ranking takes into account the amount of trophies earned, the more trophy has a user is better rank. The rank image determination administrator, add the picture, in a way that connects the trophy given quantity of some rank images.',
	'ARCADE_HELP_FAQ_GENERAL_RANG_LIST_QUESTION'		=> 'What is a ranking?',
// step 3
	'ARCADE_HELP_FAQ_USER_SET_CONFIG_ANSWER'			=> 'If you are registered all your settings are stored in the database. To alter them click the UCP link (generally at the top of the page). Here you can change all your settings.',
	'ARCADE_HELP_FAQ_USER_SET_CONFIG_QUESTION'			=> 'How do I change my settings?',

	'ARCADE_HELP_FAQ_USER_SET_CHALL_DISABLE_ANSWER'		=> 'If you don’t want to be challenged by other users to a duel, you can choose to disable this function. If you turn it off you will not be able to challenge another user, too. Please note, challenge can also be disabled for all users by the administrator.',
	'ARCADE_HELP_FAQ_USER_SET_CHALL_DISABLE_QUESTION'	=> 'You want to deactivate the challenges?',

	'ARCADE_HELP_FAQ_USER_SET_IMG_DISABLE_ANSWER'		=> 'You can choose to deactivate it if the page loading is too slowly. For example, you may have a slow internet connection or a slow server connection.',
	'ARCADE_HELP_FAQ_USER_SET_IMG_DISABLE_QUESTION'		=> 'You want to turn off display of avatars and game images?',

	'ARCADE_HELP_FAQ_USER_SET_CAT_STYLE_ANSWER'			=> 'The arcade can be shown in different styles, you can customize which one you like. This option can be disabled by the administrator.',
	'ARCADE_HELP_FAQ_USER_SET_CAT_STYLE_QUESTION'		=> 'What is the category style?',

	'ARCADE_HELP_FAQ_USER_SET_FAV_MANAGE_ANSWER'		=> 'Here you can remove your added favorite games, or mark and highlight them.',
	'ARCADE_HELP_FAQ_USER_SET_FAV_MANAGE_QUESTION'		=> 'What is manage favorites?',
// step 4
	'ARCADE_HELP_FAQ_PLAYING_NOT_PLAY_ANSWER'			=> 'This can have many causes:
															<ul>
																<li>To run the games it is important to have the <a href="http://www.adobe.com/go/getflashplayer/" title="Get Adobe Flash player">“flash player”</a> installed on your computer, preferably in it’s latest version.</li>
																<li>Maybe your browser does not have “JavaScript” installed, or it is disabled on this page.</li>
																<li>The administrator did not grant you permission to play.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_NOT_PLAY_QUESTION'			=> 'I can not play games, why?',

	'ARCADE_HELP_FAQ_PLAYING_NOT_SAVE_SCORE_ANSWER'		=> 'This can have many causes:
															<ul>
																<li>First make sure that your browser is enabled to use “Cookies”.</li>
																<li>Make sure that you are logged in.</li>
																<li>The game does not start correctly.</li>
																<li>The game is broken.</li>
																<li>The administrator has not granted you permission to save the scores.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_NOT_SAVE_SCORE_QUESTION'	=> 'I can not save my scores, why?',

	'ARCADE_HELP_FAQ_PLAYING_GAME_SIZE_ANSWER'			=> 'Some games may not fit into the design of forum, so it is possible to close the information block, thereby increasing the game space. It is also possible to zoom in or zoom out on the games, you can play in full screen or perhaps in a new window, if the administrator has allowed that permission.',
	'ARCADE_HELP_FAQ_PLAYING_GAME_SIZE_QUESTION'		=> 'What to do when a game\'s screen size is too big or too small?',

	'ARCADE_HELP_FAQ_PLAYING_POPUP_ANSWER'				=> 'Yes, if it is allowed by administrator.',
	'ARCADE_HELP_FAQ_PLAYING_POPUP_QUESTION'			=> 'Can I play games in a new window?',

	'ARCADE_HELP_FAQ_PLAYING_FULL_SCREEN_ANSWER'		=> 'Yes, if zoom in is allowed by administrator.',
	'ARCADE_HELP_FAQ_PLAYING_FULL_SCREEN_QUESTION'		=> 'Can I play games in full screen?',

	'ARCADE_HELP_FAQ_PLAYING_MOBILE_ANSWER'				=> 'Yes, but in most cases only Html5 games run on mobile devices.',
	'ARCADE_HELP_FAQ_PLAYING_MOBILE_QUESTION'			=> 'Can I play on a mobile phone?',

	'ARCADE_HELP_FAQ_PLAYING_BACKLIGHT_ANSWER'			=> 'The backlight has two useful properties:
															<ul>
																<li>The game is running in the comfort of a darkened room.</li>
																<li>The buttons and links are inactive outside of the game, so you can not accidentally click on it. This prevents the loading of another page during the game.</li>
															</ul>',
	'ARCADE_HELP_FAQ_PLAYING_BACKLIGHT_QUESTION'		=> 'What is the backlight?',

	'ARCADE_HELP_FAQ_PLAYING_WHITE_SCREEN_ANSWER'		=> 'It may be that the game is very extensive, and you have to wait until it has loaded, due to a slower internet connection.',
	'ARCADE_HELP_FAQ_PLAYING_WHITE_SCREEN_QUESTION'		=> 'Game launches a white screen, why?',

	'ARCADE_HELP_FAQ_PLAYING_HIDDEN_SCORE_ANSWER'		=> 'This game is in a challenge with two or more players. The result for all involved users are hidden until the challenge is finished.',
	'ARCADE_HELP_FAQ_PLAYING_HIDDEN_SCORE_QUESTION'		=> 'In the list of results the text “hidden” is written, instead of of the champion\'s score, why?',
// step 5
	'ARCADE_HELP_FAQ_CAT_USER_PERMISSION_ANSWER'		=> 'If you enter a category you can “Permissions” find at the bottom of the screen and your permissions are listed below that.',
	'ARCADE_HELP_FAQ_CAT_USER_PERMISSION_QUESTION'		=> 'Which permissions apply to me?',

	'ARCADE_HELP_FAQ_CAT_PASSWORD_ANSWER'				=> 'If a category is password protected, you have to send a request to an administrator.',
	'ARCADE_HELP_FAQ_CAT_PASSWORD_QUESTION'				=> 'Category requires a password, what can I do?',

	'ARCADE_HELP_FAQ_CAT_AGE_ANSWER'					=> 'It is possible for administrators to collect easy games for children in a category, and minors only can play in it.  It is also possible that games are in a category that are not suitable for minors, and these should only be played by adults.',
	'ARCADE_HELP_FAQ_CAT_AGE_QUESTION'					=> 'Some categories are protected by an age limit, why?',

	'ARCADE_HELP_FAQ_CAT_STAT_ANSWER'					=> 'Yes, if you enter a category, you will see a link “View category statistics” next to the category name.',
	'ARCADE_HELP_FAQ_CAT_STAT_QUESTION'					=> 'I would like to see statistics for individual categories, is it possible?',
// step 6
	'ARCADE_HELP_FAQ_SEARCH_GAME_ANSWER'				=> 'If the search function is active, you will find a search box around the middle of the page, where you can enter the name of the game. The search also takes into account the game descriptions. So, if you can find the word in a game description the game will show in the search results.',
	'ARCADE_HELP_FAQ_SEARCH_GAME_QUESTION'				=> 'How can I find a specific game?',

	'ARCADE_HELP_FAQ_SEARCH_SNIP_GAME_ANSWER'			=> 'The search engine automatically takes into account partial words. For example, if you type in the search box <strong>pac</strong> you will get the <strong>Pacman</strong> game.',
	'ARCADE_HELP_FAQ_SEARCH_SNIP_GAME_QUESTION'			=> 'How can I search a game, if I do not know the name exactly?',
// step 7
	'ARCADE_HELP_FAQ_FAV_ANSWER'						=> 'When you highlight a game as favorite game, it is no longer necessary to seek it among the large number of games. In your favorites list you can find it quickly, and you will save a lot of time.',
	'ARCADE_HELP_FAQ_FAV_QUESTION'						=> 'What is the advantage to mark a game as favorite game?',

	'ARCADE_HELP_FAQ_FAV_HIGHLIGHT_ANSWER'				=> 'You have the option, to additional highlight the games you play most frequently among the favorite games. You can do that in your User Control Panel.',
	'ARCADE_HELP_FAQ_FAV_HIGHLIGHT_QUESTION'			=> 'I have too many favorite games. How can I find some games easier?',
// step 8
	'ARCADE_HELP_FAQ_CHALLENGE_PERMISSION_ANSWER'		=> 'The challenge is visible only if it is activated, and if the administrator has allowed you to access challenges.',
	'ARCADE_HELP_FAQ_CHALLENGE_PERMISSION_QUESTION'		=> 'I can not see the challenges, why?',

	'ARCADE_HELP_FAQ_CHALLENGE_ACCEPT_ANSWER'			=> 'If you have received a challenge, you need to accept it first on the challenge page and start the game there. Then the challenge will start correctly.',
	'ARCADE_HELP_FAQ_CHALLENGE_ACCEPT_QUESTION'			=> 'I have received a challenge, then I played the game, but it is still saying that I have received a challenge. Why is the game was not counted?',

	'ARCADE_HELP_FAQ_CHALLENGE_START_ANSWER'			=> 'On the challenge page you click on the button "challenge", and then choose the required settings from the form. Here you have the following options:
															<ul>
																<li>Select a game from the list.</li>
																<li>Select a favorite game. <em>Possible only if you have marked some favorite games.</em></li>
																<li>Select the opponent from user list.</li>
																<li>Select a friend. <em>Possible only if you have marked users as friends.</em></li>
															</ul>
															<br>After you have chosen a game and opponent, you can send this request by clicking the “Challenge”. To start the challenge the opponent has to respond to the request.
															<br>Note: <em>If a points system is installed and active, you can also specify a bet. The bet can be freely selectable, or it can be predefined by administrator.</em>',
	'ARCADE_HELP_FAQ_CHALLENGE_START_QUESTION'			=> 'How do I start a challenge?',

	'ARCADE_HELP_FAQ_CHALLENGE_ARRIVED_ANSWER'			=> 'Somebody wants to play a game against you and sent you a challenge. You can accept or decline.',
	'ARCADE_HELP_FAQ_CHALLENGE_ARRIVED_QUESTION'		=> 'What is a “Challenge request”?',

	'ARCADE_HELP_FAQ_CHALLENGE_SENT_ANSWER'				=> 'These are the challenges that you launched against other users. These duels may also be canceled.',
	'ARCADE_HELP_FAQ_CHALLENGE_SENT_QUESTION'			=> 'What is “Challenges sent”?',

	'ARCADE_HELP_FAQ_CHALLENGE_ONGOING_ANSWER'			=> 'These are launched challenges which have been accepted and which can be played by both parties now. If an error is reported for this game the challenge will be canceled.',
	'ARCADE_HELP_FAQ_CHALLENGE_ONGOING_QUESTION'		=> 'What is “Ongoing Challenges”?',

	'ARCADE_HELP_FAQ_CHALLENGE_GAME_CHAMP_ANSWER'		=> 'If you play in normal window, you can find boxes at the side including the box “Game options”. In this box you will find the link “Challenge champion”. You can simply challenge the record holder by clicking on this link. He/she has to accept the challenge before the duel can start.',
	'ARCADE_HELP_FAQ_CHALLENGE_GAME_CHAMP_QUESTION'		=> 'How can I simply challenge a game champion?',

	'ARCADE_HELP_FAQ_CHALLENGE_PRACTICE_ANSWER'			=> 'Yes, wait to accept the challenge and you can play this game without being in the duel. But once you have accepted the challenge it will be evaluated and there is no chance for further practice.',
	'ARCADE_HELP_FAQ_CHALLENGE_PRACTICE_QUESTION'		=> 'A challenge has arrived for me, is there a way to practice?',

	'ARCADE_HELP_FAQ_CHALLENGE_POINTS_ANSWER'			=> 'If a user challenged you and has set a bet, for example, 100 points, then this will be deducted from your balance at the same time challenge is incoming. If the game costs 5 points, for example, this is deducted, too. So the system will deduct a total of 105 points from your balance to cover the full cost of the challenge. In case you decline this challenge you will be immediately refunded this sum. Even if the challenge is accepted, but the game is not played, or the challenge time runs out before you start, your bet and game cost will also be refunded.',
	'ARCADE_HELP_FAQ_CHALLENGE_POINTS_QUESTION'			=> 'I was challenged and lost a lot of my balance, why?',

	'ARCADE_HELP_FAQ_CHALLENGE_BUG_GAME_ANSWER'			=> 'In this case use “Report game” link, please. You will find it in game options of every game. Your bet and game cost will be refunded immediately.',
	'ARCADE_HELP_FAQ_CHALLENGE_BUG_GAME_QUESTION'		=> 'I was challenged, but that game is broken, what should I do?',

	'ARCADE_HELP_FAQ_CHALLENGE_DRAW_BET_ANSWER'			=> 'If a challenge ends with a tie the cost of the bet will be transferred back to each player.',
	'ARCADE_HELP_FAQ_CHALLENGE_DRAW_BET_QUESTION'		=> 'What happens to the bet if the challenge ends in a draw?',

	'ARCADE_HELP_FAQ_CHALLENGE_EXP_TIME_ANSWER'			=> 'The expiration date is the time when the challenges are deleted automatically. Until then the challenges have to be accepted.',
	'ARCADE_HELP_FAQ_CHALLENGE_EXP_TIME_QUESTION'		=> 'What is the “Expiration time”?',

	'ARCADE_HELP_FAQ_CHALLENGE_END_ANSWER'				=> 'Each user is notified by private message, if it is enabled on the send private message.',
	'ARCADE_HELP_FAQ_CHALLENGE_END_QUESTION'			=> 'How do I know that the challenge has ended?',

	'ARCADE_HELP_FAQ_CHALLENGE_PREVENT_ANSWER'			=> 'You can deactivate challenges in your User Control Panel.',
	'ARCADE_HELP_FAQ_CHALLENGE_PREVENT_QUESTION'		=> 'How do I prevent becoming challenged?',
// step 9
	'ARCADE_HELP_FAQ_TOUR_PRACTICE_ANSWER'				=> 'Yes Before the tournament starts you can play the games without evaluation. But if it has already started, all the games contained therein will be evaluated for tournament, regardless of which place they are started, and there is no way for further practice.',
	'ARCADE_HELP_FAQ_TOUR_PRACTICE_QUESTION'			=> 'Is there any way to practice for tournaments?',

	'ARCADE_HELP_FAQ_TOUR_PLAY_NUM_ANSWER'				=> 'Each game start is counted, irrespective of whether the score has been stored or not.',
	'ARCADE_HELP_FAQ_TOUR_PLAY_NUM_QUESTION'			=> 'I have played a game, but the points were not saved. Nevertheless, the number of game plays was increased. Why?',

	'ARCADE_HELP_FAQ_TOUR_NO_RESULT_ANSWER'				=> 'Only the group(s) that are authorized for this tournament can participate. Make sure you are a member of this group(s).',
	'ARCADE_HELP_FAQ_TOUR_NO_RESULT_QUESTION'			=> 'I have played a game, but I do not see any tournament results, why?',

	'ARCADE_HELP_FAQ_TOUR_RIGHT_RESULT_ANSWER'			=> 'If reached the specified maximum number of game plays, no further results will be counted in the tournament.',
	'ARCADE_HELP_FAQ_TOUR_RIGHT_RESULT_QUESTION'		=> 'I have played a game again with better results, but it was not written into the tournament, why?',
// step 10
	'ARCADE_HELP_FAQ_POINTS_SYSTEM_ANSWER'				=> 'A points system is a complex modification the administrator can add to use in the forum or the arcade. If the points system is used in the arcade, a variety of costs and rewards can be used.',
	'ARCADE_HELP_FAQ_POINTS_SYSTE_QUESTION'				=> 'What is the point system?',

	'ARCADE_HELP_FAQ_POINTS_REWARD_ANSWER'				=> 'The reward is normally available in two cases: if a record is obtained, and if a Super Champion title will be won. The amount of the reward is defined by the administrator.',
	'ARCADE_HELP_FAQ_POINTS_REWARD_QUESTION'			=> 'What is the reward?',

	'ARCADE_HELP_FAQ_POINTS_JACKPOT_ANSWER'				=> 'The jackpot is formed from the cost of the game. At the start of each game, the game costs are collected in a pot. It grows, until someone has won this jackpot, or until the limit is reached. The minimum/maximum amount of this jackpot is defined by the administrator.',
	'ARCADE_HELP_FAQ_POINTS_JACKPOT_QUESTION'			=> 'What is the jackpot?',

	'ARCADE_HELP_FAQ_POINTS_COST_ANSWER'				=> 'The game cost is the sum, which will be deducted from your balance for each game start. Please note, that the cost of individual games or categories may be different. The amount of the cost is defined by the administrator.',
	'ARCADE_HELP_FAQ_POINTS_COST_QUESTION'				=> 'What is the game cost?',

	'ARCADE_HELP_FAQ_POINTS_DOWNLOAD_COST_ANSWER'		=> 'The download cost is the sum, which will be deducted from your balance for each game you download. Please note, that the cost of individual games or categories may be different. The amount of the cost is defined by the administrator.',
	'ARCADE_HELP_FAQ_POINTS_DOWNLOAD_COST_QUESTION'		=> 'What is the download cost?',
// step 11
	'ARCADE_HELP_FAQ_ARCADE_CREATE_ANSWER'				=> 'This extension (original form) was created by <a href="https://jv-arcade.com/">JV-Arcade Group</a>, which owns the copyright. It was developed and published under the GNU General Public License, and may be redistributed freely. For more information see the link.',
	'ARCADE_HELP_FAQ_ARCADE_CREATE_QUESTION'			=> 'Who wrote the Arcade?',

	'ARCADE_HELP_FAQ_ARCADE_NOT_AVAILABLE_X_ANSWER'		=> 'This extension was created and licensed by JV-Arcade Group. If you believe, that new services or features are necessary, or you have found mistakes, visit the <a href="https://jv-arcade.com/New_Ideas.html">JV-Arcade New Ideas Centre</a>, please, where additional information is available.',
	'ARCADE_HELP_FAQ_ARCADE_NOT_AVAILABLE_X_QUESTION'	=> 'Why is feature X not available?'
));
