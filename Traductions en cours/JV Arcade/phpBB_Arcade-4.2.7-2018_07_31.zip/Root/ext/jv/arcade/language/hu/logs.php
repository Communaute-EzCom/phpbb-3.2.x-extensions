<?php
/**
*
* @package phpBB Arcade
* @version $Id: logs.php 2035 2018-07-25 11:10:48Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

//Arcade
$lang = array_merge($lang, array(
	'ARCADE_SCORE_ERR_GAME_HACK'					=> 'Játék hackelésének érzékelése',
	'ARCADE_SCORE_ERR_GG'							=> 'helytelen játék kód érkezett',
	'ARCADE_SCORE_ERR_GG_RANDCHAR'					=> 'játék kód nem érkezett',
	'ARCADE_SCORE_ERR_GS'							=> 'helytelen eredmény kód érkezett',
	'ARCADE_SCORE_ERR_GS_GG_RANDCHAR'				=> 'eredmény, játék kód nem érkezett',
	'ARCADE_SCORE_ERR_GS_RANDCHAR'					=> 'eredmény kód nem érkezett',
	'ARCADE_SCORE_ERR_MICRO_TIME'					=> 'túllépte az ellenőrzési időt',
	'ARCADE_SCORE_ERR_PCH'							=> 'helytelen eredmény változó kód érkezett',
	'ARCADE_SCORE_ERR_TIME_HACK'					=> 'játékidő manipulálás érzékelése',

	'LOG_ACL_ADD_CATEGORY_LOCAL_C_'					=> '<strong>Kategória jogosultság módosítása</strong> Kategória=(%1$s)<br>» Megváltoztatott jog=(%2$s)',
	'LOG_ACL_ADD_GROUP_LOCAL_C_'					=> '<strong>Csoport jogosultság módosítása</strong> Kategória=(%1$s)<br>» Megváltoztatott jog=(%2$s)',
	'LOG_ACL_ADD_USER_LOCAL_C_'						=> '<strong>Felhasználói jogosultság módosítása</strong> Kategória=(%1$s)<br>» Megváltoztatott jog=(%2$s)',
	'LOG_ACL_ARCADE_RESTORE_PERMISSIONS'			=> '<strong>Saját jogosultság helyreállítása, miután más jogosultságát használta</strong><br>» %s',
	'LOG_ACL_ARCADE_TRANSFER_PERMISSIONS'			=> '<strong>Jogosultság átvétele</strong><br>» %s',
	'LOG_ACL_DEL_CATEGORY_LOCAL_C_'					=> '<strong>%1$s kategória jogosultság felhasználó vagy csoport eltávólítása<br>» %2$s',
	'LOG_ARCADE_ADD_CAT'							=> '<strong>Új kategória létrehozása</strong><br>» Új kategória neve:(%s)',
	'LOG_ARCADE_ADD_GAME'							=> '<strong>Játék telepítése a(z) %s kategóriába</strong><br>» %s',
	'LOG_ARCADE_ADD_GAMES'							=> '<strong>Játékok telepítése a(z) %s kategóriába</strong><br>» %s',
	'LOG_ARCADE_ALL_ANNOUNCE_RESTORE_DEFAULT_DATA'	=> '<strong>Összes közlemény adatai, alaphelyzetbe állítása</strong>',
	'LOG_ARCADE_ANNOUNCE_CREATE_DB_DATA'			=> '<strong>„%s” üzenet létrehozása az adatbázisba</strong><br>» Nyelv: %s',
	'LOG_ARCADE_ANNOUNCE_GENERAL_SETTINGS'			=> '<strong>Közlemény elsődleges beállítások módosítása</strong>',
	'LOG_ARCADE_APAGE'								=> '<strong>Játékterem oldal beállítások módosítása</strong>',
	'LOG_ARCADE_ARCADE_PM'							=> '<strong>Játéktermi privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_ARCADE_SUPER_CHAMPION_PM'			=> '<strong>„Szuper bajnoki cím elvesztése” privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_AUTO_RESET_SCORE'					=> '<strong>Eredmények automatikus visszaállítása</strong>',
	'LOG_ARCADE_AUTO_RESET_SCORE_SETTINGS'			=> '<strong>Eredmények automatikus visszaállítás beállítások módosítása</strong>',
	'LOG_ARCADE_BACKUP_CAT'							=> '<strong>Biztonsági mentés</strong><br>» Kategória: %s',
	'LOG_ARCADE_BACKUP_CATS'						=> '<strong>Biztonsági mentés</strong><br>» Kategóriák: %s',
	'LOG_ARCADE_BACKUP_EMPTY'						=> '<strong>Biztonsági könyvtár kiürítése</strong>',
	'LOG_ARCADE_CATEGORY_COPIED_PERMISSIONS'		=> '<strong>Kategória jogosultság másolása</strong> honnan %1$s<br>» %2$s',
	'LOG_ARCADE_CAT_EDIT'							=> '<strong>Kategória módosítása</strong><br>» Kategória=(%s)',
	'LOG_ARCADE_CHALLENGE'							=> '<strong>Kihívás beállítások módosítása</strong>',
	'LOG_ARCADE_CHALLENGE_ACCEPT_PM'				=> '<strong>Kihívás „elfogadása” privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_CHALLENGE_FINAL_LOSER_PM'			=> '<strong>Kihívás „vége/vesztes” privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_CHALLENGE_FINAL_TIE_PM'				=> '<strong>Kihívás „vége/döntetlen” privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_CHALLENGE_FINAL_WINNER_PM'			=> '<strong>Kihívás „vége/nyertes” privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_CHALLENGE_PM'						=> '<strong>Kihívás privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_CHALLENGE_REJECT_PM'				=> '<strong>Kihívás „visszautasítása” privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_CHALLENGE_REPORT_GAME_PM'			=> '<strong>Kihívás „hibás játék jelentése” privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_CHALLENGE_WITHDRAW_PM'				=> '<strong>Kihívás „visszavonása” privát üzenet módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_CLEAR_ADMIN_LOG'					=> '<strong>Adminisztrátori napló kiürítése</strong>',
	'LOG_ARCADE_CLEAR_ALL_USERS_BANNED'				=> '<strong>Összes felhasználó kitiltásának feloldása</strong>',
	'LOG_ARCADE_CLEAR_CRITICAL_LOG'					=> '<strong>Hibanapló kiürítése</strong>',
	'LOG_ARCADE_CLEAR_MOD_LOG'						=> '<strong>Moderátori napló kiürítése</strong>',
	'LOG_ARCADE_CLEAR_REPORTS'						=> '<strong>Hibabejelentések törlése</strong>',
	'LOG_ARCADE_CLEAR_USERS_BANNED'					=> '<strong>Felhasználók kitiltásának feloldása</strong><br>» %s',
	'LOG_ARCADE_CLEAR_USERS_LOG'					=> '<strong>Felhasználói napló kiürítése</strong>',
	'LOG_ARCADE_CLEAR_USER_BANNED'					=> '<strong>Felhasználó kitiltásának feloldása</strong><br>» %s',
	'LOG_ARCADE_CPAGE'								=> '<strong>Kihívás oldal beállítások módosítása</strong>',
	'LOG_ARCADE_CREATE_INSTALL_FILE'				=> '<strong>Játék telepítő fájl készítése</strong><br>» %s',
	'LOG_ARCADE_DELETE_GAME'						=> '<strong>Játék törlése</strong><br>» %s',
	'LOG_ARCADE_DELETE_GAMES'						=> '<strong>Játékok törlése</strong><br>» %s',
	'LOG_ARCADE_DELETE_SCORE'						=> '<strong>Játékpont törlése, felhasználó: (%3$s)%1$s%2$s</strong><br>» (%4$s)',
	'LOG_ARCADE_DELETE_SUPER_CHAMPION_SCORE'		=> '<strong>%s felhasználó szuper bajnok eredmény törlése</strong><br>» Játék: %s',
	'LOG_ARCADE_DEL_CAT'							=> '<strong>Kategória törlése</strong><br>» %s',
	'LOG_ARCADE_DEL_CATS'							=> '<strong>Kategória törlése az alkategóriákkal együtt</strong><br>» %s',
	'LOG_ARCADE_DEL_DELETED_GAMES'					=> '<strong>Törölt játékok listájának törlése.</strong>',
	'LOG_ARCADE_DEL_GAMES'							=> '<strong>Kategória törlése a játékokkal együtt</strong><br>» Kategória=%s',
	'LOG_ARCADE_DEL_GAMES_CATS'						=> '<strong>Kategória törlése játékokkal és alkategóriákkal együtt</strong><br>» Kategória neve:(%s)',
	'LOG_ARCADE_DEL_GAMES_MOVE_CATS'				=> '<strong>(%2$s) kategória törlése játékokkal együtt</strong><br>» Alkategóriák áthelyezve:(%1$s) kategóriába',
	'LOG_ARCADE_DEL_MOVE_CATS'						=> '<strong>Kategória törlése, alkategóriák áthelyezve</strong> (%1$s)<br>» (%2$s)',
	'LOG_ARCADE_DEL_MOVE_GAMES'						=> '<strong>(%2$s) kategóriának törlése, benne lévő játékok áthelyezve</strong><br>» Játékok új kategóriája=(%1$s)',
	'LOG_ARCADE_DEL_MOVE_GAMES_CATS'				=> '<strong>(%2$s) kategória törlése az alkategóriákkal együtt</strong><br>» játékok áthelyezése:(%1$s)-kategóriába',
	'LOG_ARCADE_DEL_MOVE_GAMES_MOVE_CATS'			=> '<strong>(%3$s) kategória törlése</strong><br>» Alkategóriák áthelyezve:(%2$s)-kategóriába<br>» Játékok áthelyezve:(%1$s)-kategóriába',
	'LOG_ARCADE_EDIT_GAME'							=> '<strong>Játék szerkesztése</strong><br>» %s',
	'LOG_ARCADE_EDIT_GAME_RESET_INSTALL_DATE'		=> '<strong>Játék szerkesztése és a telepítési dátum ki resetelése</strong><br>» %s',
	'LOG_ARCADE_EDIT_SCORE'							=> '<strong>%1$s felhasználó eredmény módosítása</strong><br>» Játék: %2$s',
	'LOG_ARCADE_ERROR_GAME_FILE_MISSING'			=> '<strong>A „%s” játéknak hiányoznak egyes fájljai vagy extra fájljai</strong><br>» %s',
	'LOG_ARCADE_ERROR_PLAYING_TIME'					=> '<strong>A „%s” játék játszási ideje elveszett</strong><br>» Elért eredmény: %s',
	'LOG_ARCADE_EXT_SETTINGS'						=> '<strong>Kiterjesztések beállításainak módosítása</strong>',
	'LOG_ARCADE_FEATURE'							=> '<strong>Funkció beállítások módosítása</strong>',
	'LOG_ARCADE_FORM_SCORE_ERROR'					=> '<strong>A „%s” játék helytelen eredmény űrlapot küldött</strong><br>Típus: %s<br>Mentési típus: %s<br>Eredmény: %s<br><strong>Hiba:</strong> (%s)',
	'LOG_ARCADE_FORM_SCORE_ERRORS'					=> '<strong>A „%s” játék helytelen eredmény űrlapot küldött</strong><br>Típus: %s<br>Mentési típus: %s<br>Eredmény: %s<br><strong>Hibák:</strong> (%s)',
	'LOG_ARCADE_GAME'								=> '<strong>Játék beállítások módosítása</strong>',
	'LOG_ARCADE_GAME_ANNOUNCE'						=> '<strong>Játék közlemény módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_GAME_ANNOUNCE_SYNC'					=> '<strong>Játék közlemények újraszinkronizálása</strong>',
	'LOG_ARCADE_GAME_DATA_EMPTY_ERROR'				=> '<strong>A „%s” játék nem küldött (arcadegid vagy enscore) kódot, a játék valószínüleg hibás</strong><br>» Eredmény: %s',
	'LOG_ARCADE_GAME_FILE_NOT_FOUND'				=> '<strong>A „%s” játék egyik fájla nem található</strong><br>» Fájl: %s',
	'LOG_ARCADE_GAME_INSTALL_FILE_NOT_FOUND'		=> '<strong>A „%s” játék telepítő fájla nem található</strong><br>» Fájl: %s',
	'LOG_ARCADE_GAME_INSTALL_FILE_UNWRITABLE'		=> '<strong>A „%s” játék telepítő fájla nem írható</strong><br>» Fájl: %s',
	'LOG_ARCADE_GAME_NOT_DETECT_FILESIZE'			=> '<strong>Nem sikerült meghatározni a játék fájljainak méretét</strong><br>» %s',
	'LOG_ARCADE_GAME_NOT_DETECT_HW'					=> '<strong>Nem sikerült meghatározni a játék szélességét és magasságát</strong><br>» %s',
	'LOG_ARCADE_GLOBAL_ANNOUNCE'					=> '<strong>Globális közlemény módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_G_MOVE_DOWN'						=> '%s <strong>játék mozgatása lefele</strong>',
	'LOG_ARCADE_G_MOVE_UP'							=> '%s <strong>játék mozgatása felfele</strong>',
	'LOG_ARCADE_LOAD'								=> '<strong>Terhelés beállítások módosítása</strong>',
	'LOG_ARCADE_MENUS_DELETE'						=> '<strong>Menü törlése az almenükkel együtt</strong><br>» %s',
	'LOG_ARCADE_MENU_ADD'							=> '<strong>Új menű hozzáadása</strong><br>» %s',
	'LOG_ARCADE_MENU_DELETE'						=> '<strong>Menü törlése</strong><br>» %s',
	'LOG_ARCADE_MENU_EDIT'							=> '<strong>Menü szerkesztése</strong><br>» %s',
	'LOG_ARCADE_MENU_MOVE_DOWN'						=> '%1$s <strong>menü mozgatása lefele</strong> a %2$s menü alá',
	'LOG_ARCADE_MENU_MOVE_UP'						=> '%1$s <strong>menü mozgatása felfele</strong> a %2$s menü fölé',
	'LOG_ARCADE_MOVE_DOWN'							=> '%1$s <strong>kategória mozgatása lefele</strong> a %2$s kategória alá',
	'LOG_ARCADE_MOVE_GAME'							=> '<strong>Játék áthelyezése a(z) %1$s kategóriából a(z) %2$s kategóriába</strong><br>» %3$s',
	'LOG_ARCADE_MOVE_GAMES'							=> '<strong>Játékok áthelyezése a(z) %1$s kategóriából a(z) %2$s kategóriába</strong><br>» %3$s',
	'LOG_ARCADE_MOVE_UP'							=> '%1$s <strong>kategória mozgatása felfele</strong> a %2$s kategória fölé',
	'LOG_ARCADE_PAAR'								=> '<strong>phpBB Arcade - Aktivitási rang módosítása</strong>',
	'LOG_ARCADE_PATH'								=> '<strong>Útvonal beállítások módosítása</strong>',
	'LOG_ARCADE_PURGE_SESSIONS'						=> '<strong>Játék munkamenetek kiürítése</strong>',
	'LOG_ARCADE_RESET_ARCADE'						=> '<strong>Játékterem újraindítása</strong>%s%s',
	'LOG_ARCADE_RESET_CHALLENGE'					=> '<strong>Kihívások újraindítása</strong>',
	'LOG_ARCADE_RESET_COMMENT'						=> '<strong>Játék kommentek újraindítása</strong>',
	'LOG_ARCADE_RESET_DOWNLOADS'					=> '<strong>Letöltési statisztika újraindítása</strong>',
	'LOG_ARCADE_RESET_GAME'							=> '<strong>Játék adatok újraindítása%s%s%s%s</strong><br>» %s',
	'LOG_ARCADE_RESET_GAMES'						=> '<strong>Játékok adatainak újraindítása%s%s%s%s</strong><br>» %s',
	'LOG_ARCADE_RESET_GAMES_SCORES'					=> '<strong>Játékok eredményeinek újraindítása%s%s</strong><br>» %s',
	'LOG_ARCADE_RESET_GAME_SCORES'					=> '<strong>Játék eredmények újraindítása%s%s</strong><br>» %s',
	'LOG_ARCADE_RESET_INSTALL_DATE_GAME'			=> '<strong>Játék telepítési dátum ki resetelése</strong><br>» %s',
	'LOG_ARCADE_RESET_INSTALL_DATE_GAMES'			=> '<strong>Játékok telepítési dátumok ki resetelése</strong><br>» %s',
	'LOG_ARCADE_RESET_JACKPOT'						=> '<strong>Összes játék főnyereményének újraindítása</strong>',
	'LOG_ARCADE_RESET_PLAYING_RECORD'				=> '<strong>Valaha játszott felhasználó számának lenullázása</strong>',
	'LOG_ARCADE_RESET_POINTS'						=> '<strong>Összes pont újraindítása</strong>',
	'LOG_ARCADE_RESET_SCORES_ALL'					=> '<strong>Összes felhasználó eredményének törlése</strong>',
	'LOG_ARCADE_RESET_SUPER_CHAMPION'				=> '<strong>Szuper bajnokok újraindítása</strong>',
	'LOG_ARCADE_RESET_USERS_DATA'					=> '<strong>Összes felhasználó adatainak törlése</strong>',
	'LOG_ARCADE_RESET_USERS_SCORE'					=> '<strong>Összes felhasználó elért eredményeinek törlése</strong>',
	'LOG_ARCADE_RESET_USERS_SETTINGS'				=> '<strong>Felhasználók beállításainak alaphelyzetbe állítása</strong>',
	'LOG_ARCADE_RESET_USER_ALL'						=> '<strong>Felhasználó adatainak törlése</strong><br>» %s',
	'LOG_ARCADE_RESET_USER_SCORES'					=> '<strong>Felhasználó eredményeinek törlése%s%s</strong><br>» %s',
	'LOG_ARCADE_RESET_USER_SUPER_RECORDS'			=> '<strong>Felhasználó szuper rekordjainak törlése</strong><br>» %s',
	'LOG_ARCADE_RESTORE_DEFAULT_DATA_ANNOUNCE'		=> '<strong>Közlemény adatok alaphelyzetbe állítása</strong><br>» %s',
	'LOG_ARCADE_RESTORE_DEFAULT_DATA_PM'			=> '<strong>Privát üzenet adatok alaphelyzetbe állítása</strong><br>» %s',
	'LOG_ARCADE_RESYNC_TOTALS_DATA'					=> '<strong>Játéktermi adatok újraszinkronizálása</strong>',
	'LOG_ARCADE_RESYNC_USERS_TOTAL_DATA'			=> '<strong>Felhasználók adatainak újraszinkronizálása</strong>',
	'LOG_ARCADE_SETTINGS'							=> '<strong>Elsődleges beállítások módosítása</strong>',
	'LOG_ARCADE_SYNC_CAT'							=> '<strong>Kategória szinkronizálása</strong><br>» Kategória=%s',
	'LOG_ARCADE_SYNC_GAME'							=> '<strong>Játék szinkronizálása</strong><br>» Játék=%s',
	'LOG_ARCADE_SYNC_GAMES'							=> '<strong>Játékok szinkronizálása</strong><br>» Játékok=%s',
	'LOG_ARCADE_TOURNAMENT'							=> '<strong>Verseny beállítások módosítása</strong>',
	'LOG_ARCADE_TOUR_ANNOUNCE'						=> '<strong>Verseny közlemény módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_TOUR_CREATE'						=> '<strong>Verseny létrehozása</strong><br>» %s',
	'LOG_ARCADE_TOUR_DELETE'						=> '<strong>Verseny törlése</strong><br>» %s',
	'LOG_ARCADE_TOUR_EDIT'							=> '<strong>Verseny szerkesztése</strong><br>» %s',
	'LOG_ARCADE_TOUR_END_ANNOUNCE'					=> '<strong>Verseny vége közlemény módosítása</strong><br>» Nyelv: %s',
	'LOG_ARCADE_TPAGE'								=> '<strong>Verseny oldal beállítások módosítása</strong>',
	'LOG_ARCADE_UNDEFINED_SCORE'					=> '<strong>A „%s” játék meghatározatlan éredményt küldött</strong>',
	'LOG_ARCADE_UNPACK_GAME'						=> '<strong>Játék kicsomagolása</strong><br>» %s',
	'LOG_ARCADE_UNPACK_GAMES'						=> '<strong>Játékok kicsomagolása</strong><br>» %s',
	'LOG_ARCADE_UPLOAD_UNPACK_GAME'					=> '<strong>Játék feltöltése és kicsomagolása</strong><br>» %s',
	'LOG_ARCADE_USERS_DEFAULT_SETTINGS'				=> '<strong>Felhasználók alapértelmezett beállítások módosítása</strong>',
	'LOG_ARCADE_USER_BANNED'						=> '<strong>Felhasználó kitiltása</strong><br>» %s',
	'LOG_ARCADE_USER_MAIN_SETTINGS'					=> '<strong>Főbeállítások módosítása</strong>',
	'LOG_ARCADE_USER_MANAGE_FAVORITES'				=> '<strong>Kedvenc játékok kezelése</strong>',
	'LOG_ARCADE_USER_POST_SETTINGS'					=> '<strong>Hozzászólás beállítások módosítása</strong>',
	'LOG_ARCADE_USER_SET_UPDATE'					=> '<strong>Felhasználó beállításainak módosítása</strong><br>» %s',
	'LOG_ARCADE_VERSION_CHECK_DISABLED'				=> '<strong>Automatikus verzió ellenőrzés kikapcsolása</strong>',
	'LOG_ARCADE_VERSION_CHECK_ENABLED'				=> '<strong>Automatikus verzió ellenőrzés bekapcsolása</strong>',
	'LOG_C_ROLE_ADD'								=> '<strong>Kategória hozzáadása</strong><br>» %s',
	'LOG_C_ROLE_EDIT'								=> '<strong>Kategória szerkesztése</strong><br>» %s',
	'LOG_C_ROLE_REMOVED'							=> '<strong>Kategória törlése</strong><br>» %s',
));
