<?php
/**
*
* @package phpBB Arcade
* @version $Id: info_ucp_arcade.php 2045 2018-07-26 15:28:27Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

//Arcade
$lang = array_merge($lang, array(
	'UCP_ARCADE'							=> 'phpBB Arcade',
	'UCP_ARCADE_CAT_GAMES_STYLE'			=> 'Category games style',
	'UCP_ARCADE_CAT_STYLE'					=> 'Category style',
	'UCP_ARCADE_DELETE_FAVORITE'			=> 'Delete favorite game',
	'UCP_ARCADE_DELETE_FAVORITES'			=> 'Delete favorite games',
	'UCP_ARCADE_DELETE_FAVORITES_CONFIRM'	=> 'Are you sure you want to delete these favorite games?',
	'UCP_ARCADE_DELETE_FAVORITE_CONFIRM'	=> 'Are you sure you want to delete this favorite game?',
	'UCP_ARCADE_DISPLAY_GAME_IMAGE'			=> 'Display game image',
	'UCP_ARCADE_DISPLAY_POPUP_ICON'			=> 'Display popup icon',
	'UCP_ARCADE_FAVORITES'					=> 'Manage favorites',
	'UCP_ARCADE_FAVORITES_DELETED'			=> 'Favorite games successfully deleted.',
	'UCP_ARCADE_FAVORITES_EXPLAIN'			=> 'You can view, highlight and delete your favorite games below.',
	'UCP_ARCADE_FAVORITE_DELETED'			=> 'Favorite game successfully deleted.',
	'UCP_ARCADE_GAME_OVER_ANIMATION'		=> 'Playing animation the end of the game',
	'UCP_ARCADE_GAME_OVER_ANIMATION_SOUND'	=> 'Enable animation sound',
	'UCP_ARCADE_GAME_OVER_RANDOM_GAMES'		=> 'Display random games the end of the game',
	'UCP_ARCADE_GAME_OVER_SOUND'			=> 'Playing game over sound the end of the game',
	'UCP_ARCADE_NO_PERM_PM_LOSS_HIGHSCORE'	=> 'You do not have permission to receive personal messages about loss of the trophy.',
	'UCP_ARCADE_POST'						=> 'Post settings',
	'UCP_ARCADE_POST_EXPLAIN'				=> 'Post personalization settings.',
	'UCP_ARCADE_SELECTED_HIGHLIGHT'			=> 'Selected highlight',
	'UCP_ARCADE_SELECTED_HIGHLIGHT_REMOVE'	=> 'Selected highlight remove',
	'UCP_ARCADE_SEND_PM_EXPLAIN'			=> 'When you lose a highscore or challenge to a user, a private message will be sent to notify you about it.',
	'UCP_ARCADE_SETTINGS'					=> 'Manage settings',
	'UCP_ARCADE_SETTINGS_EXPLAIN'			=> 'These settings control various aspects of the arcade.',
	'UCP_CAT_ARCADE'						=> 'Arcade',
	'UCP_CHALLENGE_ENABLED'					=> 'Challenge enabled',
	'UCP_CHALLENGE_ENABLED_EXPLAIN'			=> 'If enabled, users of the games challenge to a duel.',
));
