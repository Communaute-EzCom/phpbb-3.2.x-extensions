<?php
/**
*
* @package phpBB Arcade
* @version $Id: help_developer.php 2023 2018-06-24 14:52:20Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'ARCADE_ACP_HELP_FAQ_BLOCK_GENERAL'					=> 'Allgemein',
	'ARCADE_ACP_HELP_FAQ_BLOCK_INSTALL'					=> 'Installation/Aktualisierung/Deinstallation',
	'ARCADE_ACP_HELP_FAQ_BLOCK_SCORING'					=> 'Punktevergabe',
	'ARCADE_ACP_HELP_FAQ_BLOCK_GAMES'					=> 'Spiele',
	'ARCADE_ACP_HELP_FAQ_BLOCK_MODULES'					=> 'phpBB Arcade Module',
	'ARCADE_ACP_HELP_FAQ_BLOCK_DATA'					=> 'Spielhallendaten außerhalb der Spielhalle anzeigen',
// step 1
	'ARCADE_ACP_HELP_FAQ_GENERAL_FEATURES_ANSWER'		=> '<ul>
																<li>Unterstützung für zahlreiche Spiele</li>
																<li>Unbegrenzte Kategorien, Unterkategorien und Links (ahmt phpBB3-Foren nach)</li>
																<li>Umfangreiche ACP, MCP- und UCP-Module.</li>
																<li>Administratorenrechte für ACP-Module</li>
																<li>Moderatorenrechte für MCP-Module</li>
																<li>Globale spielhallenbasierte Befugnisse</li>
																<li>Lokale kategorienbasierte Befugnisse</li>
																<li>Passwortgeschützte Kategorien</li>
																<li>Altersgeschützte Kategorien</li>
																<li>Sehr einfache Spielinstallation</li>
																<li>Automatische Konvertierung aller tar-Archive unterstützter Spielspeichertypen</li>
																<li>zZeigt an, wer welches Spiel spielt</li>
																<li>Favoritensystem</li>
																<li>Eingebautes Spieldownloadsystem</li>
																<li>Detaillierte Statistiken</li>
																<li>Spielebewertungssystem</li>
																<li>Spielekommentarsystem</li>
																<li>Spielemeldesystem</li>
																<li>Spiele die Spiele normal oder in einem neuen Fenster</li>
																<li>Suchsystem</li>
																<li>Integration von Punktesystemen</li>
																<li>Und mehr…</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GENERAL_FEATURES_QUESTION'		=> 'Welche Funktionen bietet die phpBB Arcade?',

	'ARCADE_ACP_HELP_FAQ_GENERAL_STYLES_ANSWER'			=> '<ul>
																<li>Unterstützte Styles können <b><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_Arcade_Styles.html">HIER</a></b> heruntergeladen werden.</li>
																<li>Wenn du einen neuen Style erstellt hast, teile ihn bitte <b><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_Arcade_User_Styles.html">HIER</a></b> mit uns.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GENERAL_STYLES_QUESTION'		=> 'Welche Styles werden unterstützt?',

	'ARCADE_ACP_HELP_FAQ_GENERAL_LANGS_ANSWER'			=> '<ul>
																<li>Unterstützte Sprachpakete können <b><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_Arcade_Languages.html">HIER</a></b> heruntergeladen werden.</li>
																<li>Wenn du ein Sprachpaket für eine neue Sprache erstellt hast, teile es bitte <b><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_Arcade_User_Languages.html">HIER</a></b> mit uns.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GENERAL_LANGS_QUESTION'		=> 'Welche Sprachen werden unterstützt?',

	'ARCADE_ACP_HELP_FAQ_GENERAL_STYLES_IMG_ANSWER'		=> 'Ja. Jede Grafik innerhalb des Standard-Grafikpfades “[ROOT]/ext/jv/arcade/styles/all/theme/images/” kann styleabhängig sein. Hierzu musst du lediglich eine Grafik gleichen Namens im Verzeichnis “[ROOT]/ext/jv/arcade/styles/dein_style/theme/images/” platzieren. Falls ein Style keine solche Grafik hat, wird die Standardgrafik verwendet. Die gilt auch für die Kategoriegrafiken. Um styleabhängige Kategoriengrafiken zu verwenden, wähle zunächst die Standardgrafik aus “[ROOT]/ext/jv/arcade/styles/all/theme/images/cats/”, wenn du eine Kategorie erstellst/änderst. Lade dann eine Grafik gleichen Namens in den “[ROOT]/ext/jv/arcade/styles/dein_style/theme/images/cats/” Ordner hoch.',
	'ARCADE_ACP_HELP_FAQ_GENERAL_STYLES_IMG_QUESTION'	=> 'Kann ich innerhalb der Spielhalle styleabhängige Vorlagen nutzen?',
// step 2
	'ARCADE_ACP_HELP_FAQ_INSTALL_DB_ANSWER'				=> 'Die Spielhalle sollte korrekt mit allen Datenbanken zusammenarbeiten, die phpBB3 unterstützt.',
	'ARCADE_ACP_HELP_FAQ_INSTALL_DB_QUESTION'			=> 'Welche Datenbanken unterstützt die phpBB Arcade?',

	'ARCADE_ACP_HELP_FAQ_INSTALL_INSTALL_ANSWER'		=> '<ul>
																<li>Lade die letzte veröffentlichte Version herunter und entpacke sie.</li>
																<li>Kopiere die Dateien unter Beibehaltung der Ordnerstruktur auf deinen Server in das „[ROOT]/”-Verzeichnis des Forums.</li>
																<li>Gehe in das Administrator Control Panel und klicke auf dem Tab „Anpassen” im Menüeintrag der phpBB Arcade auf den Link „Aktivieren”, um phpBB Arcade zu installieren.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_INSTALL_INSTALL_QUESTION'		=> 'Wie installiere ich die phpBB Arcade?',

	'ARCADE_ACP_HELP_FAQ_INSTALL_UPDATE_ANSWER'			=> '<ul>
																<li>Lade die letzte veröffentlichte Version herunter und entpacke sie.</li>
																<li>Kopiere die Dateien unter Beibehaltung der Ordnerstruktur auf deinen Server in das „[ROOT]/”-Verzeichnis des Forums.</li>
																<li>Gehe in das Administrator Control Panel und klicke auf dem Tab „Anpassen” im Menüeintrag der phpBB Arcade auf den Link „Deaktivieren”. Nun klicke auf den Link „Aktivieren”, und deine phpBB Arcade ist aktualisiert.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_INSTALL_UPDATE_QUESTION'		=> 'Wie aktualisiere ich die phpBB Arcade?',

	'ARCADE_ACP_HELP_FAQ_INSTALL_UNINSTALL_ANSWER'		=> 'Gehe in das Administrator Control Panel und klicke auf dem Tab „Anpassen” im Menüeintrag der phpBB Arcade auf den Link „Deaktivieren”. Danach klicke auf den Link „Arbeitsdaten löschen”, danach entferne alle Dateien der phpBB Arcade von deinem Server.',
	'ARCADE_ACP_HELP_FAQ_INSTALL_UNINSTALL_QUESTION'	=> 'Wie deinstalliere ich die phpBB Arcade?',
// step 3
	'ARCADE_ACP_HELP_FAQ_SCORING_SAVE_ANSWER'			=> 'Das erste, was man überprüfen sollte, ist, ob der Spieltyp überhaupt von der Spielhalle unterstützt wird und die Punktevariable korrekt gesetzt ist. Die letzte zu überprüfende Einstellung betrifft die ACP-Einstellungen für die Cookies. Wenn deine Seiten-URL <strong>http://www.beispiel.com</strong> lautet, so sollte die Cookiedomain <strong>beispiel.com</strong> sein. Außerdem muss die Cookie Sicherheit (Cookies, Option „Sicherer Server“) im ACP, Registerkarte Allgemein, deaktiviert sein, denn diese unterstützt nur den Spieletyp phpBB Arcade.',
	'ARCADE_ACP_HELP_FAQ_SCORING_SAVE_QUESTION'			=> 'Warum werden meine Punkte nicht gespeichert?',

	'ARCADE_ACP_HELP_FAQ_SCORING_GUEST_SAVE_ANSWER'		=> 'Auch wenn du der Benutzergruppe „Gäste“ die richtigen Rechte erteilst, können sie in der Spielhalle keine Punkte speichern. Das ist so beabsichtigt.',
	'ARCADE_ACP_HELP_FAQ_SCORING_GUEST_SAVE_QUESTION'	=> 'Warum können Gäste keine Punkte speichern, obwohl sie die korrekten Rechte besitzen?',

	'ARCADE_ACP_HELP_FAQ_SCORING_TEST_CAT_ANSWER'		=> 'Öffne das ACP-Modul „Spielhalle verwalten“. Bearbeite die gewünschte Kategorie und setze dort die Option „Testmodus“ auf „Ja“.',
	'ARCADE_ACP_HELP_FAQ_SCORING_TEST_CAT_QUESTION'		=> 'Wie aktiviere ich den „Testmodus“ für eine Kategorie?',

	'ARCADE_ACP_HELP_FAQ_SCORING_TEST_ANSWER'			=> 'Er ermöglicht dir, zu spielen, ohne dass Daten oder Punkte gespeichert werden. Dadurch kannst du Spiele zunächst testen, um sicherzustellen, dass sie korrekt funktionieren. Wenn du ein Spiel beendet hast, wird dir angezeigt, welche Daten gespeichert worden wären. Falls du Administrator bist, und „DEBUG“ aktiviert ist, siehst du detailliertere Informationen.',
	'ARCADE_ACP_HELP_FAQ_SCORING_TEST_QUESTION'			=> 'Was ist der „Testmodus“?',
// step 4
	'ARCADE_ACP_HELP_FAQ_GAMES_TYPE_ANSWER'				=> 'Die Spielhalle unterstützt die folgenden Spieltypen:<br>
															<ul>
																<li>Flash</li>
																<li>Html5</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_TYPE_QUESTION'			=> 'Welche Spieletypen werden unterstützt?',

	'ARCADE_ACP_HELP_FAQ_GAMES_SAVE_TYPE_ANSWER'		=> 'Die Spielhalle unterstützt die folgenden Spielspeichertypen:<br>
															<ul>
																<li>Activity Mod</li>
																<li>Arcade Room</li>
																<li>V3 Arcade</li>
																<li>IBPro</li>
																<li>ArcadeLib</li>
																<li>IBPro V32</li>
																<li>phpBB Arcade</li>
																<li>Spiele ohne Rekordspeicherung</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_SAVE_TYPE_QUESTION'		=> 'Welche Spiel-Speichertypen werden unterstützt?',

	'ARCADE_ACP_HELP_FAQ_GAMES_INSTALL_ANSWER'			=> 'Die einfachste Möglichkeit ist, Spiele zu installieren, die bereits im phpBB Arcade- oder IBPro-Format vorliegen. Du kannst auch Spiele verwenden, die für Arcade Room gepackt wurden, wenn sie eine XML-Datei beinhalten. Die Spielhalle kann das Format des Spiels automatisch erkennen und in ein direkt installierbares Format konvertieren.',
	'ARCADE_ACP_HELP_FAQ_GAMES_INSTALL_QUESTION'		=> 'Was ist die einfachste Lösung, Spiele zu installieren?',

	'ARCADE_ACP_HELP_FAQ_GAMES_REQ_INSTALL_ANSWER'		=> 'Spiele, die du selbst zusammenstellst, müssen (standardmäßig) in <strong>[ROOT]/arcade/games/</strong> in ein Verzeichnis desselben Namens wie die SWF-Spieldatei hochgeladen werden. Wenn die Spieldatei <strong>test.swf</strong> heißt, wäre unter <strong>[ROOT]/arcade/games/</strong> also ein Verzeichnis des Namens <strong>test</strong> anzulegen.<br><br>In diesem Verzeichnis befänden sich:<br><ul><li>test.swf (Flash)</li><li>test.gif (50px x 50 px)</li><li>test.php (Installationsdatei; falls nicht vorhanden, ist keine Installation möglich)</li><li>index.htm (leere HTML-Datei)</li></ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_REQ_INSTALL_QUESTION'	=> 'Was wird benötigt, um ein Spiel zu installieren?',

	'ARCADE_ACP_HELP_FAQ_GAMES_HOW_INSTALL_ANSWER'		=> 'Es gibt drei Wege, ein Spiel zu installieren.<br>
															<ul>
																<li>Wenn du das Spiel mit dem eingebauten Downloadsystem heruntergeladen hast, steht dir ein komprimiertes Archiv zur Verfügung, das du per FTP in <strong>[ROOT]/arcade/install/</strong> hochladen und über das ACP installieren kannst.</li>
																<li>Wenn du das Spiel mit dem eingebauten Downloadsystem heruntergeladen hast, steht dir ein komprimiertes Archiv zur Verfügung, das du über das ACP-Modul „Hochladen/Entpacken“ auf deinen Server laden kannst. Ist dies erledigt, wird das Archiv automatisch entpackt, und du kannst das Spiel über das ACP hinzufügen.</li>
																<li>Eine weitere Möglichkeit ist es, alle zum Spiel gehörende Dateien einzeln in die jeweiligen Verzeichnisse hochzuladen und das Spiel manuell zu installieren.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_HOW_INSTALL_QUESTION'	=> 'Wie kann ich ein Spiel installieren?',

	'ARCADE_ACP_HELP_FAQ_GAMES_ZIP_ANSWER'				=> 'Ja. Folge den Anweisungen hier, damit dein komprimiertes Archiv die Grundvoraussetzungen erfüllt. Stelle dann sicher, dass du das Spielverzeichnis (normalerweise mit demselben Namen wie die SWF-Datei) in dieser Struktur erstellst: <strong>arcade/games/spielverzeichnis</strong>. Komprimiere dann das Verzeichnis und gebe dem komprimierten Archiv den Namen des Spielverzeichnisses.',
	'ARCADE_ACP_HELP_FAQ_GAMES_ZIP_QUESTION'			=> 'Kann ich meine eigene komprimierte Datei anlegen, um ein Spiel zu installieren',

	'ARCADE_ACP_HELP_FAQ_GAMES_INS_FILE_ANSWER'			=> 'Ja.<br><textarea rows="30" cols="30" readonly="readonly" onclick="this.focus(); this.select();">&lt;?php
/**
*
* @package phpBB Arcade
* @version 5.2.0
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
*	Spielinstallationsdatei für die phpBB Arcade
*
*	Unten findest du Informationen über einige Parameter, die gesetzt werden
*	müssen, um ein Spiel in der Spielhalle zu installieren. Du brauchst diese
*	Datei, damit das Spiel im ACP zur Installation angeboten wird.
*
*	Die einzigen einzustellenden Elemente sind Name des Spiels, Beschreibung, Steuerung,
*	Spieletyp, Breite, Höhe, Punktetyp und Rekord-Speichertyp.
*
*	Benutze die folgenden Konstanten für den Spieletyp:
*
*	GAME_TYPE_HTML5
*	GAME_TYPE_FLASH
*
*	Die Spielhalle unterstützt verschiedene Rekord-Speichertypen von Spielen. (phpBB Arcade, Activity Mod, IBPro, Arcadelib,
*	V3Arcade, IBProV32, Relax Arcade, Arcade Room, Olympus Arcade und Spiele, die keine Punkte übermitteln).
*	Benutze die folgenden Konstanten für den Rekord-Speichertyp:
*
*	AMOD_GAME
*	AR_GAME
*	IBPRO_GAME
*	ARCADELIB_GAME
*	V3ARCADE_GAME
*	IBPROV3_GAME
*	PHPBB_RA_GAME
*	OLYMPUS_GAME
*	PHPBBARCADE_GAME
*	NOSCORE_GAME
*
*	Die Spielkontrolle sollte auf die folgenden Konstanten gesetzt werden:
*
*	GAME_CONTROL_KEYBOARD_MOUSE
*	GAME_CONTROL_KEYBOARD
*	GAME_CONTROL_MOUSE
*
*	Benutze die Konstante GAME_CONTROL_KEYBOARD_MOUSE, wenn Maus und Tastatur erforderlich sind, um das Spiel zu spielen.
*	Benutze die Konstante GAME_CONTROL_KEYBOARD, wenn nur die Tastatur erforderlich ist, um das Spiel zu spielen.
*	Benutze die Konstante GAME_CONTROL_MOUSE, wenn nur die Maus erforderlich ist, um das Spiel zu spielen.
*	Wenn du eine zusätzliche Beschreibung erstellen möchtest, wie und mit welchen Tasten das Spiel zu spielen ist, kannst du diese in das Feld „game_control_desc“ schreiben.
*
*	Der Punktetyp sollte mit den folgenden Konstanten festgelegt werden:
*
*	SCORETYPE_HIGH
*	SCORETYPE_LOW
*
*	SCORETYPE_HIGH ist für Spiele, bei denen der beste Punktestand der höchste
*	ist. SCORETYPE_LOW ist für Spiele, bei denen der beste Punktestand der nied-
*	rigste ist.
*/

// ENTWICKLER BITTE BEACHTEN geändert - (\'game_name\', \'game_desc\', \'game_control_desc\')
//
// Alle Installationsdateien sollten UTF-8 als Kodierung benutzen und die Dateien sollten kein BOM enthalten (UTF-8 without BOM). Zeilenendeformatierung sollte UNIX sein (LF).
//
// Einige Zeichen, die du vielleicht kopieren möchtest: ‚ ‘ ’ « » „ “ ” …

if (!defined(\'IN_PHPBB\') || !defined(\'IN_PHPBB_ARCADE\'))
{
	exit;
}

$game_file = basename(__FILE__, \'.\' . substr(strrchr(__FILE__, \'.\'), 1));

$game_data = array(
	\'game_name\'			=> \'Name des Spiels\',
	\'game_desc\'			=> \'Gib hier eine Beschreibung des Spiels ein.\',
	\'game_control\'		=> GAME_CONTROL_MOUSE,
	\'game_control_desc\'	=> \'Gib eine Beschreibung der Steuerung des Spiels ein.\',
	\'game_image\'			=> $game_file . \'.gif\',
	\'game_swf\'			=> $game_file . \'.swf\',
	\'game_scorevar\'		=> $game_file,
	\'game_type\'			=> GAME_TYPE_HTML5,
	\'game_width\'			=> 320,
	\'game_height\'			=> 480,
	\'game_scoretype\'		=> SCORETYPE_HIGH,
	\'game_save_type\'		=> PHPBBARCADE_GAME
);

?&gt;</textarea>',
	'ARCADE_ACP_HELP_FAQ_GAMES_INS_FILE_QUESTION'		=> 'Gibt es eine Beispiel-Installationsdatei?',

	'ARCADE_ACP_HELP_FAQ_GAMES_OWN_INS_FILE_ANSWER'		=> 'Nein. Obwohl dies möglich ist, gibt es im ACP zwei Werkzeuge, die bei dieser Aufgabe helfen.<br>
															<ul>
																<li>Es gibt ein Werkzeug, das eine Installationsdatei komplett neu erzeugt. Gebe lediglich die benötigten Informationen ein, und du kannst die Installationsdatei herunterladen, anzeigen lassen oder auf dem Server speichern.</li>
																<li>Es gibt ein Werkzeug, das es ermöglicht, die Installatonsdateien von bereits installierten Spielen anzuzeigen oder herunterzuladen.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_GAMES_OWN_INS_FILE_QUESTION'	=> 'Muss ich die Installationsdatei von Hand erstellen?',

	'ARCADE_ACP_HELP_FAQ_GAMES_DELETE_ANSWER'			=> 'Du kannst ein Spiel entfernen, indem du das Modul „Spielhalle verwalten“ im ACP aufrufst. Alternativ kannst du das Modul „Spiele bearbeiten“ verwenden. Beachte bitte, dass die Dateien eines entfernten Spiels noch immer auf dem Server liegen und manuell entfernt werden müssen.',
	'ARCADE_ACP_HELP_FAQ_GAMES_DELETE_QUESTION'			=> 'Wie kann ich ein Spiel entfernen?',
// step 5
	'ARCADE_ACP_HELP_FAQ_MODULES_ANSWER'				=> '<strong><br>Die Spielhalle beinhaltet folgende ACP-Module:<br></strong>
															<strong>Konfiguration</strong><br>
															<ul>
																<li><strong>Allgemeine Einstellungen</strong> - Allgemeine Spielhalleneinstellungen ändern</li>
																<li><strong>Erweiterungseinstellungen</strong> - Erweiterungseinstellungen für die Spielhalle steuern.</li>
																<li><strong>Spieleinstellungen</strong> - Spieleinstellungen der Spielhalle ändern</li>
																<li><strong>Herausforderungseinstellungen</strong> - Herausforderungsseinstellungen der Spielhalle ändern</li>
																<li><strong>Turniereinstellungen</strong> - Turniereinstellungen für die Spielhalle ändern.</li>
																<li><strong>Weitere Funktionen</strong> - Funktionen der Spielhalle einstellen</li>
																<li><strong>Spielhallen-Seiteneinstellungen</strong> - Seiteneinstellungen der Spielhalle ändern</li>
																<li><strong>Herausforderungs-Seiteneinstellungen</strong> - Seiteneinstellungen für Herausforderungen ändern</li>
																<li><strong>Turnier-Seiteneinstellungen</strong> - Seiteneinstellungen für Turnier ändern</li>
																<li><strong>Pfadeinstellungen</strong> - Pfadeinstellungen der Spielhalle ändern</li>
																<li><strong>Lasteinstellungen</strong> - Reduziert oder erhöht die Belastung der Spielhalle durch Ein-/Ausschalten einzelner Module</li>
															</ul><br>
															<strong>Spielhalle verwalten</strong><br>
															<ul>
																<li><strong>Menü verwalten</strong> - Du kannst Menüschaltflächen hinzufügen, bearbeiten oder löschen. Die Hauptschaltflächen des Menüs können nur verschoben oder umbenannt werden.</li>
																<li><strong>Kategorien verwalten</strong> - Kategorien und Spiele hinzufügen, ändern, entfernen, verschieben und neu abgleichen</li>
																<li><strong>Spiele verwalten</strong> - Spiele ändern/löschen</li>
																<li><strong>Benutzer verwalten</strong> - Spielstände für alle Spiele ändern</li>
																<li><strong>Turniere verwalten</strong> - Turniere bearbeiten/löschen.</li>
																<li><strong>Ankündigungen verwalten</strong> - Ankündigungen einstellen/bearbeiten.</li>
																<li><strong>Ränge verwalten</strong> - Ränge hinzufügen/bearbeiten und löschen.</li>
															</ul><br>
															<strong>Spielfunktion</strong><br>
															<ul>
																<li><strong>Spiele hinzufügen</strong> - Ein Spiel der Spielhalle hinzufügen, einer Kategorie können mehrere Spiele auf einmal hinzugefügt werden</li>
																<li><strong>Spiele hochladen/entpacken</strong> - Das Verzeichnis arcade/games enthält gepackte Spiele, du kannst aber auch selbst Spiele mittels des „Durchsuchen“-Buttons hochladen. Nach dem Hochladen/Entpacken stehen die Spiele zur Installation bereit</li>
																<li><strong>Spiele sichern</strong> - Sichert alle Spiele in den ausgewählten Kategorien</li>
																<li><strong>Spiele herunterladen</strong> - Lädt unter der phpBB-Spielhalle lauffähige Spiele von kompatiblen Seiten herunter</li>
															</ul><br>
															<strong>Werkzeuge</strong><br>
															<ul>
																<li><strong>Meldungen anzeigen</strong> - Alle Meldungen zu Spielen ansehen</li>
																<li><strong>Verbannte Benutzer</strong> - Verbannte Benutzer ansehen / entbannen.</li>
																<li><strong>Downloadstatistik</strong> - Statistik des Downloadsystems ansehen</li>
																<li><strong>Installationsdatei erstellen</strong> - Erzeugt eine neue Spielinstallationsdatei zum Herunterladen/Ansehen/Speichern auf dem Server, oder lädt eine bestehende Spielinstallationsdatei herunter, oder zeigt sie an</li>
																<li><strong>Benutzerhandbuch</strong> - Zeigt das phpBB Arcade-Benutzerhandbuch an</li>
															</ul><br>
															<strong>Spielhallenprotokolle</strong><br>
															<ul>
																<li><strong>Administratorprotokoll</strong> - Administrative Aktionen werden aufgelistet.</li>
																<li><strong>Moderationsprotokoll</strong> - Moderationsaktionen werden aufgelistet.</li>
																<li><strong>Benutzerprotokoll</strong> - Benutzeraktionen werden aufgelistet.</li>
																<li><strong>Fehlerprotokoll</strong> - Verschiedene Fehler werden aufgelistet.</li>
															</ul><br>
															<strong>Berechtigungsrollen</strong><br>
															<ul>
																<li><strong>Kategorienrollen</strong> - Ändert die Rollenzuweisungen für Spielhallenkategorien</li>
															</ul><br>
															<strong>Kategorienbasierte Berechtigungen</strong><br>
															<ul>
																<li><strong>Kategorienbefugnisse</strong> - Legt fest, welche Benutzer und Gruppen auf welche Teile der Spielhalle zugreifen dürfen</li>
																<li><strong>Benutzerbefugnisse für Kategorien</strong> - Spielhallenbefugnisse Benutzern zuweisen</li>
																<li><strong>Gruppenbefugnisse für Kategorien</strong> - Spielhallenbefugnisse Benutzergruppen zuweisen</li>
																<li><strong>Kategorienbefugnisse kopieren</strong> - Kategorienbefugnisse einer Kategorie in eine oder mehrere andere Kategorien kopieren</li>
															</ul><br>
															<strong>Berechtigungsmasken</strong><br>
															<ul>
																<li><strong>Spielhallenbefugnisse für Kategorien</strong> - Zeigt die Spielhallenbefugnisse von ausgewählten Benutzern/Gruppen und Kategorien an.</li>
															</ul><br>
															<strong>Installationsfunktionen</strong><br>
															<ul>
																<li><strong>Installationsprüfung</strong> - Prüfung, ob phpBB Arcade korrekt installiert ist.</li>
																<li><strong>Spieldaten aktualisieren</strong> - Die Spielegröße wird automatisch ermittelt und aktualisiert, wenn die Daten nicht korrekt sind.</li>
																<li><strong>Spielinstallationsdateien konvertieren</strong> - Konvertiert die Spielinstallationsdateien auf die aktuelle Version.</li>
															</ul><br>
															<strong>Die Spielhalle beinhaltet folgende MCP-Module:</strong><br>
															<ul>
																<li><strong>Spiele verwalten</strong> - Spiel bearbeiten/verschieben und zurücksetzen.</li>
																<li><strong>Turniere verwalten</strong> - Turnier erstellen/bearbeiten.</li>
															</ul><br>
															<strong>Die Spielhalle beinhaltet die folgenden UCP Module für die Benutzer:</strong><br>
															<ul>
																<li><strong>Einstellungen</strong> - Diese Einstellungen kontrollieren verschiedene Bereiche der Spielhalle.</li>
																<li><strong>Beitragseinstellungen</strong> - Anpassen von Beitragseinstellungen.</li>
																<li><strong>Favoriten verwalten</strong> - Du kannst deine Lieblingsspiele ansehen, markieren und entfernen.</li>
															</ul>',
	'ARCADE_ACP_HELP_FAQ_MODULES_QUESTION'				=> 'Welche ACP-Module hat die phpBB Arcade?',

	'ARCADE_ACP_HELP_FAQ_MODULES_AUTH_ANSWER'			=> 'Um alle Module zu sehen, musst du als Gründer eingetragen sein, oder die korrekten Administratorenbefugnisse besitzen. Wenn du dennoch nicht alle Module sehen kannst, liegt dies wahrscheinlich an doppelten Werten in der Tabelle acl_options. Bitte führe, um dies zu überprüfen, das Installationsscript mit der Option „Check installation“ aus.',
	'ARCADE_ACP_HELP_FAQ_MODULES_AUTH_QUESTION'			=> 'Wie kommt es, dass ich nicht alle ACP-Module sehen kann?',

	'ARCADE_ACP_HELP_FAQ_MODULES_ADD_AUTH_ANSWER'		=> 'Sobald die Spielhalle installiert ist, musst du die korrekten Befugnisse einstellen. Die Spielhalle verwendet kategorienbasierte Befugnisse, die das Befugnissystem von phpBB3 nachahmen; dies beinhaltet die Nutzung von Rollen. Du musst auch globale Benutzer-/Gruppenbefugnisse festlegen. Außerdem kannst du Administratorenbefugnisse verwenden, um Benutzer-/Gruppenzugriff auf ACP-Module der Spielhalle zu regeln.',
	'ARCADE_ACP_HELP_FAQ_MODULES_ADD_AUTH_QUESTION'		=> 'Wo muss ich die phpBB Arcade-Befugnisse einstellen?/Warum habe ich nicht die Befugnis, die Spielhalle aufzurufen?',

	'ARCADE_ACP_HELP_FAQ_MODULES_NO_GAMES_ANSWER'		=> 'Um Spiele hinzufügen zu können, müssen zuvor auch Kategorien erstellt worden sein, in die sie aufgenommen werden können. Verwende hierfür das ACP-Modul <strong>Spielhalle verwalten</strong>. Das Erstellen einer Kategorie ist sehr ähnlich dem Erstellen eines Forums in phpBB3.',
	'ARCADE_ACP_HELP_FAQ_MODULES_NO_GAMES_QUESTION'		=> 'Warum kann ich keine Spiele hinzufügen?',

	'ARCADE_ACP_HELP_FAQ_MODULES_DOWNLOAD_ANSWER'		=> 'Die Möglichkeit, Spiele herunterzuladen, wird über die Spielhallenbefugnisse gesteuert. Setze die Befugnisse nach deinen Bedürfnissen, und deine Benutzer werden den Link zum Herunterladen beim Betrachten oder Spielen der Spiele sehen. Um das Herunterladen zu vereinfachen, kannst du im ACP auch die globale Downloadfunktion aktivieren. Diese ermöglicht es anderen Nutzern der Spielhalle, Spiele aus deinem Forum über das Modul „Spiele herunterladen“ in ihrer Spielhalle zu installieren.',
	'ARCADE_ACP_HELP_FAQ_MODULES_DOWNLOAD_QUESTION'		=> 'Wie biete ich Spieledownloads an?',

	'ARCADE_ACP_HELP_FAQ_MODULES_USE_DOWNLOAD_ANSWER'	=> 'Alles, was du tun musst, ist, den Pfad zum Spielhallen-Wurzelverzeichnis des Forums einzugeben, das Spiele anbietet. Du wirst dann eine Auflistung der zum Download verfügbaren Spiele sehen. Wenn ein Spiel grün hervorgehoben wird, so bedeutet dies, dass sich dieses Spiel bereits auf deinem Server befindet. Bitte beachte, dass die Befugnisse zum Download von der Seite gesteuert werden, von der du die Spiele herunterlädst. So musst du zum Beispiel dort angemeldet sein, und/oder einer besonderen Benutzergruppe angehören, um Spiele herunterladen zu können. Kontaktiere den Administrator des Forums, wenn du hierzu Fragen hast.<br><br><a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/dev/images/acp_download_games.png"><img src="https://jv-arcade.com/dev/images/acp_download_games.png" width="300" border="0" alt="ACP Spiele herunterladen" title="ACP Spiele herunterladen"></a>',
	'ARCADE_ACP_HELP_FAQ_MODULES_USE_DOWNLOAD_QUESTION'	=> 'Wie verwende ich das Modul „Spiele herunterladen“?',

	'ARCADE_ACP_HELP_FAQ_MODULES_REQ_DOWNLOAD_ANSWER'	=> 'Dieses Modul setzt voraus, dass <strong>„allow_url_fopen“</strong> aktiviert oder PHPs <strong>cURL-Bibliothek</strong> installiert ist. Das kann überprüft werden, indem du die phpinfo()-Funktion deines Servers aufrufst. Wenn der Wert für <strong>„allow_url_fopen“</strong> auf „off“ steht und die <strong>cURL-Bibliothek</strong> nicht installiert ist, funktioniert das Modul nicht.',
	'ARCADE_ACP_HELP_FAQ_MODULES_REQ_DOWNLOAD_QUESTION'	=> 'Warum findet das Modul „Spiele herunterladen“ keine Spiele?',

	'ARCADE_ACP_HELP_FAQ_MODULES_NO_FAV_ANSWER'			=> 'Das Modul „meine Favoriten“ ist nur sichtbar, wenn du die entsprechenden Berechtigungen besitzt. Diese kann nur der Administrator einstellen.',
	'ARCADE_ACP_HELP_FAQ_MODULES_NO_FAV_QUESTION'		=> 'Warum kann ich das Modul „Favoriten“ nicht sehen?',
// step 6
	'ARCADE_ACP_HELP_FAQ_DATA_EXT_ANSWER'				=> 'Ja, es gibt Erweiterungen zur phpBB Arcade Software - siehe: <a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/phpBB_Arcade_Extensions.html">Extensions</a>',
	'ARCADE_ACP_HELP_FAQ_DATA_EXT_QUESTION'				=> 'Gibt es Erweiterungen?'
));
