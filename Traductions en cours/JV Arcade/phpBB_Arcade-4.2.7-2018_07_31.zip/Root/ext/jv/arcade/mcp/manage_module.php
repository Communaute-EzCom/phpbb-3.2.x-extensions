<?php
/**
*
* @package phpBB Arcade
* @version $Id: manage_module.php 2043 2018-07-26 13:45:52Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\mcp;

class manage_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $db, $cache, $auth, $request, $user, $template, $root_path;
	protected $arcade_config, $arcade_auth, $arcade;

	public function __construct()
	{
		global $db, $cache, $auth, $request, $user, $template, $phpbb_root_path;
		global $arcade_config, $arcade_auth, $arcade;

		define('IN_PHPBB_ARCADE', true);
		$arcade->auth_check('mcp');
		$arcade = $arcade->container('admin', true);

		$this->db = $db;
		$this->cache = $cache;
		$this->auth = $auth;
		$this->request = $request;
		$this->user = $user;
		$this->template = $template;
		$this->root_path = $phpbb_root_path;
		$this->arcade_config = $arcade_config;
		$this->arcade_auth = $arcade_auth;
		$this->arcade = $arcade;
	}

	function main($id, $mode)
	{
		$this->user->add_lang_ext('jv/arcade', 'info_acp_arcade');

		$start = $this->request->variable('start', 0);
		$action = $this->request->variable('action', '');
		$submit = $this->arcade->is_post_empty('submit');
		$update = ($this->request->variable('update', false)) ? true : false;
		$this->arcade->valid_start($start);

		$time = time();
		$errors = array();
		$page_title = 'MCP_ARCADE_MANAGE_GAMES';
		$return = false;

		switch ($mode)
		{
			case 'games':
				$this->tpl_name = 'arcade/mcp_manage_games';
				$form_key = 'mcp_arcade_games';
				add_form_key($form_key);

				if ($this->arcade->is_post_empty('edit') || $action == 'edit')
				{
					$page_title = 'ARCADE_EDIT_GAME';
					$l_title = $this->user->lang[$page_title];
					$l_title_explain = $this->user->lang[$page_title . '_EXPLAIN'];

					$game_id				= (int) $this->request->variable('g', 0);
					$reset_game_ins_date	= ($this->request->is_set_post('reset_game_install_date') && $this->auth->acl_gets('a_arcade_reset_game', 'm_arcade_reset_game')) ? true : false;
					$game_data				= $this->arcade->get->game_cat_data($game_id);

					if (!$game_data)
					{
						meta_refresh(5, $this->u_action);
						trigger_error($this->user->lang['NO_GAME_ID'] . '<br><br>' . sprintf($this->user->lang['RETURN_PAGE'], '<a href="' . $this->u_action . '">', '</a>'));
					}

					$old_cat_id			= (int) $this->request->variable('old_cat_id', 0);
					$old_game_scoretype	= (int) $this->request->variable('old_game_scoretype', 0);

					$data = array(
						'cat_id'			=> (int) $this->request->variable('cat_id', $game_data['cat_id']),
						'game_name'			=> ($this->auth->acl_gets('a_arcade_game', 'm_arcade_change_gamename')) ? $this->request->variable('game_name', $game_data['game_name'], true) : $game_data['game_name'],
						'game_desc'			=> $this->request->variable('game_desc', $game_data['game_desc'], true),
						'game_control'		=> (int) $this->request->variable('game_control', $game_data['game_control']),
						'game_control_desc'	=> $this->request->variable('game_control_desc', $game_data['game_control_desc'], true),
						'game_scoretype'	=> (int) $this->request->variable('game_scoretype', $game_data['game_scoretype']),
					);

					$s_hidden_fields = array(
						'old_cat_id'			=> $game_data['cat_id'],
						'old_game_scoretype'	=> $game_data['game_scoretype']
					);

					$this->template->assign_vars(array(
						'S_EDIT_GAME'				=> true,
						'S_CHANGE_GAME_NAME'		=> ($this->auth->acl_gets('a_arcade_game', 'm_arcade_change_gamename')) ? true : false,
						'S_RESET_GAME_INSTALL_DATE'	=> ($this->auth->acl_gets('a_arcade_reset_game', 'm_arcade_reset_game')) ? true : false,
						'S_GAME_CONTROL_OPTIONS'	=> $this->arcade->game_control_select($data['game_control']),
						'S_CAT_OPTIONS'				=> $this->arcade->make_cat_select($data['cat_id'], false, false, true, true, true),
						'S_GAME_SCORETYPE_OPTIONS'	=> $this->arcade->game_scoretype_select($data['game_scoretype']),
						'S_HIDDEN_FIELDS'			=> build_hidden_fields($s_hidden_fields),

						'U_ACTION'					=> $this->u_action . "&amp;action=edit&amp;g=$game_id",

						'GAME_NAME'					=> $data['game_name'],
						'GAME_DESC'					=> $data['game_desc'],
						'GAME_CONTROL_DESC'			=> $data['game_control_desc'],
						'GAME_WIDTH'				=> $game_data['game_width'],
						'GAME_HEIGHT'				=> $game_data['game_height'],
						'GAME_INSTALLDATE'			=> $this->user->format_date($game_data['game_installdate']),
						'GAME_FILESIZE'				=> get_formatted_filesize($game_data['game_filesize'])
					));

					if ($update)
					{
						if (!check_form_key($form_key))
						{
							$errors[] = $this->user->lang['FORM_INVALID'];
						}

						if (!$this->arcade_auth->acl_get('c_play', $data['cat_id']))
						{
							$errors[] = $this->user->lang['NO_PERMISSION_GAME_EDIT'];
						}

						if ($data['game_name'] != $game_data['game_name'])
						{
							$sql = 'SELECT game_id
									FROM ' . ARCADE_GAMES_TABLE . "
									WHERE game_name = '" . $this->db->sql_escape($data['game_name']) . "'";
							$result = $this->db->sql_query($sql);
							$g_id = $this->db->sql_fetchfield('game_id');
							$this->db->sql_freeresult($result);

							$data['game_name_clean'] = utf8_clean_string($data['game_name']);

							if ($g_id)
							{
								$errors[] = $this->user->lang['ARCADE_DUPLICATE_GAMENAME_ERROR'];
							}
						}

						if ($v = $this->arcade->validate_data('string', 'ARCADE_GAME_NAME', $data['game_name'], 1, 255))
						{
							$errors[] = $v;
						}

						$cat_data = $this->arcade->get_cat_info($data['cat_id']);
						if ($cat_data['cat_type'] != ARCADE_CAT_GAMES)
						{
							$errors[] = $this->user->lang['WRONG_CAT_TYPE'];
						}

						if ($reset_game_ins_date && !count($errors))
						{
							$errors = $this->arcade->reset_game('reset_game_install_date', $game_id, $old_cat_id);
						}

						if (!count($errors))
						{
							$sql = 'UPDATE ' . ARCADE_GAMES_TABLE. '
									SET ' . $this->db->sql_build_array('UPDATE', $data) . '
									WHERE game_id = ' . (int) $game_id;
							$this->db->sql_query($sql);

							if ($data['cat_id'] != $old_cat_id)
							{
								$this->arcade->set_last_play(array($data['cat_id'], $old_cat_id));
								$this->arcade->sync('category', array($data['cat_id'], $old_cat_id));
							}

							if ($data['game_scoretype'] != $old_game_scoretype)
							{
								$uh = array(
									'game_id'			=> $game_id,
									'game_scoretype'	=> $data['game_scoretype'],
								);

								$this->arcade->update_highscore($uh);
							}

							$log_key = 'LOG_ARCADE_EDIT_GAME' . (($reset_game_ins_date) ? '_RESET_INSTALL_DATE' : '');
							$this->arcade->add_log('mod', $data['cat_id'], $game_id, $log_key, $data['game_name']);

							$msg_key	 = ($reset_game_ins_date) ? '<br><br>' . sprintf($this->user->lang['RESET_INSTALL_DATE_GAME_SUCCESS'], $data['game_name']) : '';
							$back_links  = sprintf($this->user->lang['RETURN_PAGE'], '<br><br><a href="' . $this->u_action . "&amp;action=edit&amp;g=$game_id" . '">', '</a>');
							$back_links .= sprintf($this->user->lang['ACP_ARCADE_JUMP_MANAGE_GAMES'], '<br><br><a href="' . $this->u_action . '">', '</a>');
							$back_links .= sprintf($this->user->lang['ARCADE_JUMP_GAME'], '<br><br><a href="' . $this->arcade->url("mode=play&amp;g={$game_id}") . '">', '</a>');
							$back_links .= sprintf($this->user->lang['ARCADE_JUMP_CAT'], '&nbsp;&bull;&nbsp;<a href="' . $this->arcade->url("mode=cat&amp;c={$data['cat_id']}&amp;g=$game_id") . "#g$game_id" . '">', '</a>');
							$back_links .= sprintf($this->user->lang['ARCADE_JUMP_ARCADE_MAIN_PAGE'], '<br><br><a href="' . $this->arcade->url() . '">', '</a>');

							if ($this->arcade_config['game_announce'])
							{
								$this->arcade->phpbb()->create_game_announcement(array(array_merge($game_data, $data)));
							}

							$this->arcade->cache_purge();

							if ($this->arcade->game->install_file->row_update($game_id))
							{
								trigger_error($this->user->lang['ARCADE_GAME_UPDATED'] . $msg_key . $back_links);
							}
							else
							{
								trigger_error($this->user->lang['ARCADE_GAME_UPDATED_ERROR'] . $msg_key . $back_links, E_USER_WARNING);
							}
						}
					}

					$return = true;
				}

				if (!$return)
				{
					$x = 0;
					foreach ($this->arcade->games as $gid => $row)
					{
						if (!$this->arcade_auth->acl_get('c_play', $row['cat_id']))
						{
							continue;
						}

						$x++;
						$this->template->assign_block_vars('quick_jump', array(
							'GAME_ID'	=> $gid,
							'GAME_NAME'	=> $row['game_name'],
						));
					}

					$l_title = $this->user->lang[(($x) ? 'MCP_ARCADE_MANAGE_GAMES' : 'INFORMATION')];
					$l_title_explain = $this->user->lang[(($x) ? 'MCP_ARCADE_MANAGE_GAMES_EXPLAIN' : 'ARCADE_NO_GAMES')];
				}
			break;

			case 'tournament':
				$this->tpl_name = 'arcade/mcp_manage_tour';

				$this->arcade->container('tournament', true);

				$tour_id  = (int) $this->request->variable('tour_id', 0);

				$def_title = true;
				$tour_data = array();
				$form_key = 'mcp_arcade_tournament';
				add_form_key($form_key);

				switch ($action)
				{
					case 'create':
					case 'rand_create':
						$page_title = 'CREATE_TOUR';
						$l_title			= $this->user->lang[$page_title];
						$l_title_explain	= $this->user->lang['ARCADE_TOUR_EDIT_EXPLAIN'];
						$def_title = false;
					break;

					default:
						$page_title = 'MCP_ARCADE_MANAGE_TOUR';
					break;
				}

				if ($def_title)
				{
					$l_title			= $this->user->lang[$page_title];
					$l_title_explain	= $this->user->lang[$page_title . '_EXPLAIN'];
				}

				$td = array(
					'tour_name'			=> '',
					'tour_games'		=> array(),
					'tour_groups'		=> array(),
					'play_max'			=> 0,
					'reward_1'			=> 0.00,
					'reward_2'			=> 0.00,
					'reward_3'			=> 0.00,
					'post_id'			=> 0,
					'tour_starttime'	=> '',
					'tour_endtime'		=> ''
				);

				switch ($action)
				{
					case 'edit':
						if (!$tour_id)
						{
							$action = '';
							break;
						}

						$sql = 'SELECT *
								FROM ' . ARCADE_TOUR_TABLE . '
								WHERE tour_status <> ' . ARCADE_END_TOUR . "
								AND tour_id = $tour_id";
						$result = $this->db->sql_query($sql);
						$td = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);

						if (!$td)
						{
							$action = '';
							break;
						}

						$td['tour_games']		= array_map('intval', explode(',', $td['tour_games']));
						$td['tour_groups']		= array_map('intval', explode(',', $td['tour_groups']));
						$td['tour_starttime']	= $this->user->format_date($td['tour_starttime'], 'Y-m-d H:i', true);
						$td['tour_endtime']		= $this->user->format_date($td['tour_endtime'], 'Y-m-d H:i', true);

						$tour_data = array(
							'tour_id' => $tour_id
						);
					case 'create':
					case 'rand_create':
						$avg_games_num		= intval($this->arcade_config['tour_max_games'] / 2);
						$tour_started		= (!empty($td['tour_id']) && $td['tour_status'] == ARCADE_START_TOUR) ? true : false;
						$tour_games			= $this->request->variable('tour_games', array(0));
						$tour_cats			= $this->request->variable('tour_cats', array(0));
						$tour_groups		= $this->request->variable('tour_groups', array(0));
						$num_games			= (int) $this->request->variable('num_games', $avg_games_num);
						$tour_not_played	= $this->request->variable('tour_not_played', false);
						$group_helper		= $this->arcade->container('phpbb_group_helper');

						if ($submit && $action == 'rand_create')
						{
							$num_games = ($num_games < $this->arcade_config['tour_min_games'] || $num_games > $this->arcade_config['tour_max_games']) ? $avg_games_num : $num_games;
							$num_games = ($num_games < $this->arcade_config['tour_min_games']) ? $this->arcade_config['tour_min_games'] : $num_games;
							$tour_games = $this->arcade->get->random_game($num_games, $tour_cats, false, true, $tour_not_played);
						}

						$tour_data += array(
							'tour_name'			=> $this->request->variable('tour_name', $td['tour_name'], true),
							'tour_games'		=> (!$tour_started && !empty($tour_games)) ? $tour_games : $td['tour_games'],
							'tour_groups'		=> (!$tour_started && !empty($tour_groups)) ? $tour_groups : $td['tour_groups'],
							'play_max'			=> (!$tour_started) ? (int) $this->request->variable('play_max', $td['play_max']) : $td['play_max'],
							'tour_starttime'	=> (!$tour_started) ? $this->request->variable('tour_starttime', $td['tour_starttime']) : $td['tour_starttime'],
							'tour_endtime'		=> $this->request->variable('tour_endtime', $td['tour_endtime'])
						);

						if ($this->arcade_config['tour_reward_enable'] && $this->auth->acl_gets('a_', 'm_arcade_tour_reward') && $this->arcade->points->data['show'])
						{
							$tour_data += array(
								'reward_1' => (float) $this->request->variable('tour_reward_1', $td['reward_1']),
								'reward_2' => (float) $this->request->variable('tour_reward_2', $td['reward_2']),
								'reward_3' => (float) $this->request->variable('tour_reward_3', $td['reward_3'])
							);
						}
						else
						{
							$tour_data += array(
								'reward_1' => $td['reward_1'],
								'reward_2' => $td['reward_2'],
								'reward_3' => $td['reward_3']
							);
						}

						if ($submit)
						{
							if (!check_form_key($form_key))
							{
								$errors[] = $this->user->lang['FORM_INVALID'];
							}

							if ($v = $this->arcade->validate_data('string', 'ARCADE_TOUR_NAME', $tour_data['tour_name'], 3, 255))
							{
								$errors[] = $v;
							}

							if ($action == 'rand_create' && empty($tour_cats))
							{
								$errors[] = $this->user->lang['ARCADE_NO_SELECT_CATS'];
							}
							else
							{
								if (empty($tour_data['tour_games']))
								{
									foreach ($tour_data['tour_games'] as $game_id)
									{
										if (!$this->arcade->get->game_field($game_id, 'cat_id', false))
										{
											unset($tour_data['tour_games'][$game_id]);
										}
									}

									$tour_data['tour_games'] = array_map('intval', $tour_data['tour_games']);
								}

								if (empty($tour_data['tour_games']))
								{
									$errors[] = $this->user->lang['ARCADE_NO_SELECT_GAMES'];
								}
								else if (count($tour_data['tour_games']) < $this->arcade_config['tour_min_games'])
								{
									if ($action == 'rand_create')
									{
										$errors[] = sprintf($this->user->lang['ARCADE_TOUR_MIN_GAMES_CAT_ERROR'], $this->arcade->number_format($this->arcade_config['tour_min_games']));
									}
									else
									{
										$errors[] = sprintf($this->user->lang['ARCADE_TOUR_MIN_GAMES_ERROR'], count($tour_data['tour_games']), $this->arcade->number_format($this->arcade_config['tour_min_games']));
									}
								}
								else if (count($tour_data['tour_games']) > $this->arcade_config['tour_max_games'])
								{
									$errors[] = sprintf($this->user->lang['ARCADE_TOUR_MAX_GAMES_ERROR'], count($tour_data['tour_games']), $this->arcade->number_format($this->arcade_config['tour_max_games']));
								}
							}

							if (empty($tour_data['tour_groups']))
							{
								$errors[] = $this->user->lang['ARCADE_NO_SELECT_GROUPS'];
							}

							$tour_data['play_max'] = ($tour_data['play_max'] < 0 || $tour_data['play_max'] > 99) ? 0 : $tour_data['play_max'];

							if ($this->arcade_config['tour_reward_enable'] && $this->auth->acl_gets('a_', 'm_arcade_tour_reward') && $this->arcade->points->data['show'])
							{
								if ($v = $this->arcade->validate_data('float', 'ARCADE_TOUR_REWARD_1', $tour_data['reward_1'], $this->arcade_config['tour_reward_min'], $this->arcade_config['tour_reward_max']))
								{
									$errors[] = $v;
								}

								if ($v = $this->arcade->validate_data('float', 'ARCADE_TOUR_REWARD_2', $tour_data['reward_2'], $this->arcade_config['tour_reward_min'], $this->arcade_config['tour_reward_max']))
								{
									$errors[] = $v;
								}

								if ($v = $this->arcade->validate_data('float', 'ARCADE_TOUR_REWARD_3', $tour_data['reward_3'], $this->arcade_config['tour_reward_min'], $this->arcade_config['tour_reward_max']))
								{
									$errors[] = $v;
								}

								if ($tour_data['reward_1'] < $tour_data['reward_2'])
								{
									$errors[] = sprintf($this->user->lang['ARCADE_MIN_MAX_ERROR'], $this->user->lang['ARCADE_TOUR_REWARD_2'], $this->user->lang['ARCADE_TOUR_REWARD_1']);
								}

								if ($tour_data['reward_2'] < $tour_data['reward_3'])
								{
									$errors[] = sprintf($this->user->lang['ARCADE_MIN_MAX_ERROR'], $this->user->lang['ARCADE_TOUR_REWARD_3'], $this->user->lang['ARCADE_TOUR_REWARD_2']);
								}
							}

							$start_ary = $end_ary = array();
							$tour_st_ary = explode(' ', $tour_data['tour_starttime']);
							if (count($tour_st_ary) < 2)
							{
								$errors[] = sprintf($this->user->lang['ARCADE_TOUR_START_TIME_ERROR'], $tour_data['tour_starttime']);
							}
							else
							{
								list($tour_start_date, $tour_start_time) = $tour_st_ary;
								$start_ary = $this->arcade->validate_date($tour_start_date, $tour_start_time);

								if (!count($start_ary))
								{
									$errors[] = sprintf($this->user->lang['ARCADE_TOUR_START_TIME_ERROR'], $tour_data['tour_starttime']);
								}
							}

							$tour_et_ary = explode(' ', $tour_data['tour_endtime']);
							if (count($tour_et_ary) < 2)
							{
								$errors[] = sprintf($this->user->lang['ARCADE_TOUR_END_TIME_ERROR'], $tour_data['tour_endtime']);
							}
							else
							{
								list($tour_end_date, $tour_end_time) = $tour_et_ary;
								$end_ary = $this->arcade->validate_date($tour_end_date, $tour_end_time);

								if (!count($end_ary))
								{
									$errors[] = sprintf($this->user->lang['ARCADE_TOUR_END_TIME_ERROR'], $tour_data['tour_endtime']);
								}
							}

							if (count($start_ary) && count($end_ary))
							{
								$start_time	= $this->arcade->time_stamp($start_ary['year'], $start_ary['mon'], $start_ary['day'], $start_ary['hour'], $start_ary['min']);
								$end_time	= $this->arcade->time_stamp($end_ary['year'], $end_ary['mon'], $end_ary['day'], $end_ary['hour'], $end_ary['min']);

								if (!$tour_started && $start_time <= $time)
								{
									$errors[] = $this->user->lang['ARCADE_TOUR_START_CUR_TIME_ERROR'];
								}

								if ($start_time >= $end_time)
								{
									$errors[] = $this->user->lang['ARCADE_TOUR_START_END_TIME_ERROR'];
								}
								else if ($end_time <= $time)
								{
									$errors[] = $this->user->lang['ARCADE_TOUR_END_CUR_TIME_ERROR'];
								}
							}

							if (!count($errors))
							{
								$sql_ary = array(
									'tour_name'			=> $tour_data['tour_name'],
									'tour_games'		=> implode(',', $tour_data['tour_games']),
									'tour_groups'		=> implode(',', array_map('intval', $tour_data['tour_groups'])),
									'play_max'			=> $tour_data['play_max'],
									'tour_starttime'	=> $start_time,
									'tour_endtime'		=> $end_time
								);

								$sql_ary += array(
									'reward_1' => $tour_data['reward_1'],
									'reward_2' => $tour_data['reward_2'],
									'reward_3' => $tour_data['reward_3']
								);

								if ($tour_id)
								{
									$sql = 'UPDATE ' . ARCADE_TOUR_TABLE . '
											SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . "
											WHERE tour_id = $tour_id";
									$this->db->sql_query($sql);
								}
								else
								{
									$sql_ary['tour_time'] = $time;
									$this->db->sql_query('INSERT INTO ' . ARCADE_TOUR_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));
									$tour_id = (int) $this->db->sql_nextid();
								}

								$main_action = ($action == 'rand_create') ? 'create' : $action;

								if ($this->arcade_config['tour_announce'])
								{
									$tour_ary[$tour_id] = array(
										'tour_name'			=> $tour_data['tour_name'],
										'game_data'			=> $this->arcade->get->game_cat_data($tour_data['tour_games']),
										'tour_groups'		=> $this->arcade->get->group_data($tour_data['tour_groups']),
										'plays_max'			=> $tour_data['play_max'],
										'tour_starttime'	=> $start_time,
										'tour_endtime'		=> $end_time
									);

									$tour_ary[$tour_id] += array(
										'reward_1' => $tour_data['reward_1'],
										'reward_2' => $tour_data['reward_2'],
										'reward_3' => $tour_data['reward_3']
									);

									$this->arcade->phpbb()->create_tour_announcement('tour_announce', $main_action, $tour_ary, $td['post_id']);
								}

								$this->cache->destroy('_arcade_tours');
								$this->cache->destroy('_arcade_tour_check');
								$this->arcade->add_log('mod', 0, 0, 'LOG_ARCADE_TOUR_' . strtoupper($main_action), $tour_data['tour_name']);

								meta_refresh(5, $this->u_action);
								$message = $this->user->lang['ARCADE_TOUR_' . strtoupper($main_action) . '_SUCCESS'] . '<br><br>' . sprintf($this->user->lang['RETURN_PAGE'], '<a href="' . $this->u_action . '">', '</a>');
								trigger_error($message);
							}
						}

						$s_cat_options = $s_game_options = $old_cat = $s_group_options = '';
						$cats_count = $games_count = $groups_count = 0;

						if ($action == 'rand_create')
						{
							$sql = 'SELECT cat_id
									FROM ' . ARCADE_CATS_TABLE . '
									WHERE cat_status = ' . ITEM_LOCKED . ' OR cat_test = ' . ARCADE_CAT_TEST;
							$result = $this->db->sql_query($sql);
							$cat_ignore_ids = array();
							while ($row = $this->db->sql_fetchrow($result))
							{
								$cat_ignore_ids[] = (int) $row['cat_id'];
							}
							$this->db->sql_freeresult($result);

							if ($s_cat_options = $this->arcade->make_cat_select($tour_cats, $cat_ignore_ids, true, true))
							{
								$cats_count = count(explode('</option>', $s_cat_options)) - 1;
							}
						}
						else
						{
							$sql = 'SELECT g.game_id, g.game_name, g.game_name_clean, c.cat_id, c.cat_name
									FROM ' . ARCADE_GAMES_TABLE . ' g, ' . ARCADE_CATS_TABLE . ' c
									WHERE g.cat_id = c.cat_id
									AND ' . $this->db->sql_in_set('c.cat_id', $this->arcade->get->permissions('c_play'), false, true) . '
									AND c.cat_status = ' . ITEM_UNLOCKED . '
									AND c.cat_test <> ' . ARCADE_CAT_TEST . '
									AND g.game_save_type <> ' . NOSCORE_GAME . '
									ORDER BY c.cat_name ASC, g.game_name_clean ASC';
							$result = $this->db->sql_query($sql);
							while ($row = $this->db->sql_fetchrow($result))
							{
								if ($old_cat != $row['cat_name'])
								{
									$s_game_options .= (($old_cat) ? "</optgroup>\n" : '') . '<optgroup label="' . $row['cat_name'] . '">' . "\n";
									$cats_count++;
								}

								$s_game_options .= '<option' . ((in_array($row['game_id'], $tour_data['tour_games'])) ? ' selected="selected"' : '') . ' value="' . $row['game_id'] . '">&nbsp;&nbsp;&nbsp;&nbsp;' . $row['game_name'] . "</option>\n";

								$old_cat = $row['cat_name'];
								$games_count++;
							}
							$this->db->sql_freeresult($result);

							$s_game_options .= ($s_game_options) ? "</optgroup>\n" : '';
						}

						$sql = 'SELECT group_id, group_name, group_type
								FROM ' . GROUPS_TABLE . "
								WHERE group_name NOT IN ('BOTS', 'GUESTS')
								ORDER BY group_type DESC, group_name ASC";
						$result = $this->db->sql_query($sql);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$group_name = $group_helper->get_name($row['group_name']);
							$s_group_options .= '<option' . (($row['group_type'] == GROUP_SPECIAL) ? ' class="sep"' : '') . ' value="' . $row['group_id'] . '"' . ((in_array($row['group_id'], $tour_data['tour_groups'])) ? ' selected="selected"' : '') . '>' . $group_name . "</option>\n";
							$groups_count++;
						}
						$this->db->sql_freeresult($result);

						$s_hidden_fields = array(
							'action'	=> $action,
							'tour_id'	=> $tour_id
						);

						$this->template->assign_vars(array(
							'S_TOUR_CREATE'			=> true,
							'S_TOUR_EDIT'			=> ($action == 'edit') ? true : false,
							'S_RAND_CREATE'			=> ($action == 'rand_create') ? true : false,
							'S_TOUR_STARTED'		=> $tour_started,
							'S_CAT_OPTIONS'			=> ($s_cat_options) ? $s_cat_options : '',
							'S_GAME_OPTIONS'		=> $s_game_options,
							'S_GROUPS_OPTIONS'		=> $s_group_options,
							'S_MIN_GAMES'			=> ($this->arcade_config['tour_min_games']) ? sprintf($this->user->lang['ARCADE_MIN_GAMES_SELECTED_EXPLAIN'], $this->arcade->number_format($this->arcade_config['tour_min_games'])) : '',
							'S_MAX_GAMES'			=> ($this->arcade_config['tour_max_games']) ? sprintf($this->user->lang['ARCADE_MAX_GAMES_SELECTED_EXPLAIN'], $this->arcade->number_format($this->arcade_config['tour_max_games'])) : '',
							'S_HIDDEN_FIELDS'		=> build_hidden_fields($s_hidden_fields),
							'S_TOUR_NOT_PLAYED'		=> ($tour_not_played) ? ' checked="checked"' : '',

							'U_ACTION'				=> $this->u_action,
							'U_CREATE_TOUR'			=> $this->u_action . '&amp;action=' . (($action == 'create') ? 'rand_' : '') . 'create' . (($tour_data['tour_name']) ? '&amp;tour_name=' . $tour_data['tour_name'] : ''),

							'TOUR_MIN_GAMES'		=> intval($this->arcade_config['tour_min_games']),
							'TOUR_MAX_GAMES'		=> intval($this->arcade_config['tour_max_games']),
							'NUM_GAMES'				=> $num_games,
							'NUM_RANDOM_GAMES_EXP'	=> sprintf($this->user->lang['ARCADE_NUM_RANDOM_GAMES_EXPLAIN'], intval($this->arcade_config['tour_min_games']), intval($this->arcade_config['tour_max_games'])),
							'OPTIONS_COUNT'			=> $cats_count + $games_count,
							'CATS_COUNT'			=> $cats_count,
							'GAMES_COUNT'			=> $games_count,
							'GROUPS_COUNT'			=> $groups_count,
							'TOUR_NAME'				=> $tour_data['tour_name'],
							'PLAY_MAX'				=> $tour_data['play_max'],
							'TOUR_STARTTIME'		=> $tour_data['tour_starttime'],
							'TOUR_ENDTIME'			=> $tour_data['tour_endtime']
						));

						if ($this->arcade_config['tour_reward_enable'] && $this->auth->acl_gets('a_', 'm_arcade_tour_reward') && $this->arcade->points->data['show'])
						{
							$this->template->assign_vars(array(
								'S_TOUR_REWARD'	=> true,
								'S_MIN_REWARD'	=> ($this->arcade_config['tour_reward_min'] > 0) ? sprintf($this->user->lang['ARCADE_MIN_REWARD_EXPLAIN'], $this->arcade->number_format($this->arcade_config['tour_reward_min']), $this->arcade->points->data['name']) : '',
								'S_MAX_REWARD'	=> ($this->arcade_config['tour_reward_max'] > 0) ? sprintf($this->user->lang['ARCADE_MAX_REWARD_EXPLAIN'], $this->arcade->number_format($this->arcade_config['tour_reward_max']), $this->arcade->points->data['name']) : '',

								'TOUR_REWARD_1'	=> $this->arcade->number_format($tour_data['reward_1'], true),
								'TOUR_REWARD_2'	=> $this->arcade->number_format($tour_data['reward_2'], true),
								'TOUR_REWARD_3'	=> $this->arcade->number_format($tour_data['reward_3'], true)
							));
						}
					break;
				}

				if (!$action)
				{
					if ($total_tours = $this->arcade->get->total('game', 'total_tours'))
					{
						$sql = 'SELECT *
								FROM ' . ARCADE_TOUR_TABLE . '
								WHERE tour_status <> ' . ARCADE_END_TOUR . '
								ORDER BY tour_time DESC, tour_id DESC';
						$result = $this->db->sql_query_limit($sql, $this->arcade_config['acp_items_per_page'], $start);
						while ($row = $this->db->sql_fetchrow($result))
						{
							$url = $this->u_action . "&amp;tour_id={$row['tour_id']}";

							$this->template->assign_block_vars('tours', array(
								'NAME'				=> $row['tour_name'],
								'CREATE_TIME'		=> $this->user->format_date($row['tour_time'], false, true),

								'L_STATUS'			=> $this->user->lang['ARCADE_' . (($row['tour_status'] == ARCADE_WAIT_TOUR) ? 'WAIT' : 'ONGOING')],

								'U_EDIT'			=> $url . '&amp;action=edit'
							));
						}
						$this->db->sql_freeresult($result);

						$this->arcade->container('phpbb_pagination')->generate_template_pagination($this->u_action, 'pagination', 'start', $total_tours, $this->arcade_config['acp_items_per_page'], $start);
					}

					$this->template->assign_vars(array(
						'FOLDER_IMAGE'	=> '<img src="' . ((defined('PHPBB_ADMIN_PATH')) ? PHPBB_ADMIN_PATH : $this->root_path . 'adm/') . 'images/icon_folder.gif" alt="' . $this->user->lang['TOURNAMENT'] . '" title="' . $this->user->lang['TOURNAMENT'] . '">',
						'ICON_EDIT'		=> '<img src="' . ((defined('PHPBB_ADMIN_PATH')) ? PHPBB_ADMIN_PATH : $this->root_path . 'adm/') . 'images/icon_edit.gif" alt="' . $this->user->lang['ARCADE_EDIT'] . '" title="' . $this->user->lang['ARCADE_EDIT'] . '">'
					));
				}
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}

		$this->page_title = $page_title;

		if (count($errors))
		{
			$this->template->assign_vars(array(
				'S_ERROR'	=> true,
				'ERROR_MSG'	=> implode('<br>', $errors)
			));
		}

		$this->template->assign_vars(array(
			'L_TITLE'			=> (!empty($l_title)) ? $l_title : '',
			'L_TITLE_EXPLAIN'	=> (!empty($l_title_explain)) ? $l_title_explain : ''
		));
	}
}
