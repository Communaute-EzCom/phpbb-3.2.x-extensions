<?php
/**
*
* @package phpBB Arcade
* @version $Id: manage_info.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade\mcp;

class manage_info
{
	function module()
	{
		return array(
			'filename'			=> '\jv\arcade\mcp\manage_module',
			'title'				=> 'MCP_ARCADE',
			'modes'				=> array(
				'games'			=> array('title' => 'MCP_ARCADE_MANAGE_GAMES'	, 'auth' => 'ext_jv/arcade && acl_u_arcade && acl_m_arcade_game', 'cat' => array('MCP_CAT_ARCADE')),
				'tournament'	=> array('title' => 'MCP_ARCADE_MANAGE_TOUR'	, 'auth' => 'ext_jv/arcade && acl_u_arcade && acl_m_arcade_tour', 'cat' => array('MCP_CAT_ARCADE'))
			)
		);
	}
}
