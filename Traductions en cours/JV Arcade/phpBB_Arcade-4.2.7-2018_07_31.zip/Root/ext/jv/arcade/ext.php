<?php
/**
*
* @package phpBB Arcade
* @version $Id: ext.php 1897 2018-03-03 20:42:21Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade;

use phpbb\extension\base;

class ext extends base
{
	public function is_enableable()
	{
		return defined('PHPBB_VERSION') && phpbb_version_compare(PHPBB_VERSION, '3.2.2', '>=');
	}
}
