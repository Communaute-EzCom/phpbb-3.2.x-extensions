<?php
/**
*
* @package phpBB Arcade
* @version $Id: arcade.php 1985 2018-05-29 14:11:16Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

define('IN_PHPBB', true);
define('IN_PHPBB_ARCADE', true);
define('PHPBB_ARCADE_START', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);

if (!empty($_GET['swf']) || !empty($_GET['img']))
{
	// Fixed if the game send a duplicate swf parameter.
	if (count($_GET) > 2 && !empty($_GET['vars']))
	{
		$_GET['swf'] = 'JVA_Game_Score';
		$_GET['p'] = 1;
	}

	include($phpbb_root_path . 'arcade/file.' . $phpEx);
}

include($phpbb_root_path . 'common.' . $phpEx);

if (!class_exists('jv\arcade\inc\arcade') || !isset($arcade))
{
	redirect(append_sid($phpbb_root_path . 'index.' . $phpEx));
}

$mode			= strtolower($request->variable('mode', ''));
$type			= strtolower($request->variable('type', ''));
$detailed_stats	= strtolower($request->variable('ds', ''));
$cat_id			= (int) $request->variable('c', 0);
$game_id		= (int) $request->variable('g', 0);
$user_id		= (int) $request->variable('u', 0);
$style_id		= (int) $request->variable('style', 0);
$tour_id		= (int) $request->variable('tour_id', 0);
$start			= (int) $request->variable('start', 0);

$arcade->valid_start($start);

$inc_challenge	= (($type == 'challenge') || strpos($mode, 'challenge') !== false || strpos($detailed_stats, 'challenge') !== false) ? true : false;
$inc_tour		= ($mode == 'tournament' || $type == 'tournament' || strpos($detailed_stats, 'tour') !== false) ? true : false;
$arcade_page	= ($inc_challenge) ? 'challenge' : (($inc_tour) ? 'tour' : 'arcade');

$update_session_page = (!$request->variable('champion_challenge', false)) ? true : false;

$user->session_begin($update_session_page);
$auth->acl($user->data);

if (($scoretype = $arcade->send_score($mode)) !== false)
{
	$arcade->container('scoretype')->set($scoretype);
}

$arcade->container('arcade')->style($style_id, $cat_id, $game_id);

$arcade->setup(false, $style_id);
$arcade->auth_check($arcade_page, $mode, $type);

$challenge_id = ($user->data['is_registered']) ? (int) $request->variable('cid', 0) : false;

$arcade = $arcade->container('arcade', true, false, ($arcade_page == 'challenge') ? 'challenge' : (($arcade_page == 'tour' && $mode == 'stats') ? 'tournament' : null));
$arcade->add_navlink('add', '', 'ARCADE_INDEX');

$arcade->check_module($user_id, $cat_id, $game_id, $tour_id, $detailed_stats, $mode, $type, $start, $challenge_id);

$vars = array('mode', 'type', 'detailed_stats', 'arcade_page', 'user_id', 'game_id', 'cat_id', 'tour_id', 'start');
extract($arcade->phpbb_dispatcher()->trigger_event('jv.arcade.main', compact($vars)));

switch ($arcade_page)
{
	case 'challenge':
		$arcade->page_title = 'ARCADE_CHALLENGE';
		$arcade->add_navlink('add', 'mode=challenge', 'CHALLENGE');
		$page_html = 'challenge';

		if ($mode != 'stats')
		{
			$arcade->challenge->display($mode, $game_id, $user_id, $detailed_stats);
		}
	break;

	case 'tour':
		$arcade->page_title = 'ARCADE_TOURNAMENT';
		$arcade->add_navlink('add', 'mode=tournament', 'TOURNAMENT');
		$page_html = 'tournament';

		if ($mode != 'stats')
		{
			$arcade->container('tournament')->main(true, true, $tour_id, $type, true);
		}
	break;

	default:
		$arcade->page_title = 'ARCADE_INDEX';
		$page_html = ARCADE_INDEX_PAGE;
		$arcade->display->category();
	break;
}

$arcade->display->online_playing();
$arcade->display->page($arcade->lang_value($arcade->page_title), "@jv_arcade/arcade/{$page_html}_body.html");
