<?php
/**
*
* @package JV Points System
* @version $Id: points_change.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

class points_change
{
	public $tpl_name;

	protected $container, $phpbb_log, $db, $user, $auth, $request, $template, $jv_points, $root_path, $php_ext;

	public function __construct()
	{
		global $phpbb_container, $phpbb_log, $db, $user, $auth, $request, $template, $jv_points, $phpbb_root_path, $phpEx;

		$this->container = $phpbb_container;
		$this->phpbb_log = $phpbb_log;
		$this->db = $db;
		$this->user = $user;
		$this->auth = $auth;
		$this->request = $request;
		$this->template = $template;
		$this->jv_points = $jv_points;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
	}

	public function main($mode)
	{
		$error = array();
		$this->tpl_name = 'points_change';

		$form_key = 'jv_points_change_user_points';
		add_form_key($form_key);

		$controller_helper = $this->container->get('controller.helper');

		$submit			= $this->request->is_set_post('submit');
		$update			= $this->request->is_set_post('update');
		$user_id		= (int) $this->request->variable('u', 0);
		$amount_user	= (float) $this->request->variable('amount_user', 0.00);
		$username		= $this->request->variable('username', '', true);

		$user_type = array(USER_NORMAL, USER_FOUNDER);

		if ($this->auth->acl_get('a_'))
		{
			$user_type[] = USER_INACTIVE;
		}

		if ($user_id)
		{
			$sql = 'SELECT user_id, username, user_points
					FROM ' . USERS_TABLE . "
					WHERE user_type IN (" . implode(', ', $user_type) . ")
					AND user_id = $user_id";
			$result = $this->db->sql_query($sql);
			$userdata = $this->db->sql_fetchrow($result);
			$this->db->sql_freeresult($result);

			if ($userdata)
			{
				$submit = true;
				$username = $userdata['username'];
			}
		}

		if ($submit)
		{
			if (empty($userdata) && !check_form_key($form_key))
			{
				$error[] = $this->user->lang['FORM_INVALID'];
			}

			if ($amount_user < 0)
			{
				$error[] = $this->user->lang['JV_POINTS_ERROR_MINUS_VALUE'];
			}

			if (!$username)
			{
				$error[] = $this->user->lang['NO_USER_SPECIFIED'];
				$submit = false;
			}
			else if (empty($userdata))
			{
				$sql = 'SELECT user_id, username, user_points
						FROM ' . USERS_TABLE . "
						WHERE user_type IN (" . implode(', ', $user_type) . ")
						AND username_clean = '" . $this->db->sql_escape(utf8_clean_string($username)) . "'";
				$result = $this->db->sql_query($sql);
				$userdata = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);

				if (!$userdata)
				{
					$error[] = $this->user->lang['NO_USER'];
					$submit = false;
				}
			}

			if (!count($error))
			{
				$username = $userdata['username'];
				$amount_user = ($update) ? $amount_user : $userdata['user_points'];

				if ($update)
				{
					$this->jv_points->set($userdata['user_id'], $amount_user);

					$return_page = '<br><br>' . sprintf($this->user->lang['RETURN_PAGE'], '<a href="' . $controller_helper->route('jv_points_controller', array('mode' => $mode, 'u' => $userdata['user_id'])) . '">', '</a>');
					$this->phpbb_log->add('mod', $this->user->data['user_id'], $this->user->ip, 'JV_LOG_POINTS_USER_CHANGED', false, array($userdata['username'], $this->jv_points->number_format($userdata['user_points']), $this->jv_points->number_format($amount_user)));
					trigger_error(sprintf($this->user->lang['JV_POINTS_USER_CHANGED_SUCCESS'], $userdata['username']) . $return_page);
				}
			}
		}

		$s_hidden_fields = array('mode' => $mode);

		if ($submit)
		{
			$s_hidden_fields = array_merge($s_hidden_fields, array(
				'username'	=> $username,
				'update'	=> true
			));

			$this->template->assign_var('S_JV_CHANGE_USER_POINTS', true);
		}

		$this->template->assign_vars(array(
			'S_ERROR'				=> (count($error)) ? true : false,
			'ERROR_MSG'				=> implode('<br>', $error),

			'U_ACTION'				=> $controller_helper->route('jv_points_controller'),

			'JV_POINTS_NAME'		=> $this->jv_points->name(),
			'JV_AMOUNT_USER'		=> $this->jv_points->number_format($amount_user, true),
			'JV_MANAGE_USERNAME'	=> $username,

			'S_JV_HIDDEN_FIELDS'	=> build_hidden_fields($s_hidden_fields),

			'U_FIND_USERNAME'		=> append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=searchuser&amp;form=jv_points_change_user_points&amp;field=username&amp;select_single=true')
		));
	}
}
