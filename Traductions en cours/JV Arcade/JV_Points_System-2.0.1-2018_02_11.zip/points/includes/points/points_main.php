<?php
/**
*
* @package JV Points System
* @version $Id: points_main.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

class points_main
{
	public $tpl_name;

	protected $db, $user, $template, $jv_points;

	public function __construct()
	{
		global $db, $user, $template, $jv_points;

		$this->db = $db;
		$this->user = $user;
		$this->template = $template;
		$this->jv_points = $jv_points;
	}

	public function main($mode)
	{
		$this->tpl_name = 'points_main';

		$sql = 'SELECT user_id, username, username_clean, user_colour, user_points
				FROM ' . USERS_TABLE . '
				WHERE user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
				AND user_points > 0
				ORDER BY user_points DESC, username_clean ASC';
		$result = $this->db->sql_query_limit($sql, 10);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$this->template->assign_block_vars('most_points', array(
				'NAME'	 => get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
				'POINTS' => $this->jv_points->name_format($row['user_points'])
			));
		}
		$this->db->sql_freeresult($result);

		$username = get_username_string('full', $this->user->data['user_id'], $this->user->data['username']);

		$this->template->assign_var('JV_POINTS_MAIN_EXPLAIN', sprintf($this->user->lang['JV_POINTS_MAIN_EXPLAIN'], $username, $this->jv_points->name_format($this->user->data['user_points'])));
	}
}
