<?php
/**
*
* @package JV Points System
* @version $Id: points_info.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

class points_info
{
	public $tpl_name;

	protected $user, $auth, $config, $template, $jv_points;

	public function __construct()
	{
		global $user, $auth, $config, $template, $jv_points;

		$this->user = $user;
		$this->auth = $auth;
		$this->config = $config;
		$this->template = $template;
		$this->jv_points = $jv_points;
	}

	public function main($mode)
	{
		$this->tpl_name = 'points_info';

		$ext_count = 0;
		if ($this->config['jv_points_attach_ext'])
		{
			$ext_count = count(explode(', ', $this->config['jv_points_attach_ext']));
		}

		$this->template->assign_vars(array(
			'JV_POINTS_REG_START_BALANCE'		=> $this->jv_points->name_format($this->config['jv_points_reg_start_balance']),
			'JV_POINTS_NEW_TOPIC_REWARD'		=> $this->jv_points->name_format($this->config['jv_points_topic_reward']),
			'JV_POINTS_NEW_POST_REWARD'			=> $this->jv_points->name_format($this->config['jv_points_post_reward']),

			'JV_POINTS_NEW_POST_COST'			=> $this->jv_points->name_format((!$this->auth->acl_get('u_jv_points_ignore_post_cost')) ? $this->config['jv_points_post_cost'] : 0),
			'JV_POINTS_NEW_ATTACH_COST'			=> $this->jv_points->name_format((!$this->auth->acl_get('u_jv_points_ignore_download_cost')) ? $this->config['jv_points_attach_cost'] : 0),
			'JV_POINTS_NEW_ATTACH_COST_EXPLAIN'	=> ($this->config['jv_points_attach_cost'] > 0 && $this->config['jv_points_attach_ext'] && !$this->auth->acl_get('u_jv_points_ignore_download_cost')) ? sprintf($this->user->lang['JV_POINTS_NEW_ATTACH' . (($ext_count > 1) ? 'S' : '') . '_COST_EXPLAIN'], $this->config['jv_points_attach_ext']) : ''
		));
	}
}