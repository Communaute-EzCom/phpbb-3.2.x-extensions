<?php
/**
*
* @package JV Points System
* @version $Id: points_faq.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

class points_faq
{
	public $tpl_name;

	protected $container, $user, $template;

	public function __construct()
	{
		global $phpbb_container, $user, $template;

		$this->container = $phpbb_container;
		$this->user = $user;
		$this->template = $template;
	}

	public function main($mode)
	{
		$this->tpl_name = 'points_faq';
		$l_title = $this->container->get('jv.points.faq')->display();

		$this->template->assign_vars(array(
			'L_FAQ_TITLE'				=> $l_title,
			'L_BACK_TO_TOP'				=> $this->user->lang['BACK_TO_TOP'],

			'S_IN_FAQ'					=> true
		));
	}
}
