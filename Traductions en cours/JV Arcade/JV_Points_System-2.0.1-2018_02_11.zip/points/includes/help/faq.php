<?php
/**
*
* @package JV Points System
* @version $Id: faq.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\points\includes\help;

class faq extends \phpbb\help\controller\controller
{
	public function display()
	{
		$this->language->add_lang('help_faq', 'jv/points');

		$this->manager->add_block(
			'JV_POINTS_HELP_FAQ_BLOCK_INTRO',
			false,
			array(
				'JV_POINTS_HELP_FAQ_INTRO_SYSTEM_QUESTION'				=> 'JV_POINTS_HELP_FAQ_INTRO_SYSTEM_ANSWER',
				'JV_POINTS_HELP_FAQ_INTRO_MODULES_QUESTION'				=> 'JV_POINTS_HELP_FAQ_INTRO_MODULES_ANSWER'
			)
		);

		$this->manager->add_block(
			'JV_POINTS_HELP_FAQ_BLOCK_GENERAL',
			true,
			array(
				'JV_POINTS_HELP_FAQ_GENERAL_SAME_REWARD_COST_QUESTION'	=> 'JV_POINTS_HELP_FAQ_GENERAL_SAME_REWARD_COST_ANSWER',
				'JV_POINTS_HELP_FAQ_GENERAL_POST_REWARD_QUESTION'		=> 'JV_POINTS_HELP_FAQ_GENERAL_POST_REWARD_ANSWER',
				'JV_POINTS_HELP_FAQ_GENERAL_POST_REWARD_MOD_QUESTION'	=> 'JV_POINTS_HELP_FAQ_GENERAL_POST_REWARD_MOD_ANSWER',
				'JV_POINTS_HELP_FAQ_GENERAL_TRANSFER_QUESTION'			=> 'JV_POINTS_HELP_FAQ_GENERAL_TRANSFER_ANSWER'
			)
		);

		return $this->language->lang('JV_POINTS_GUIDE');
	}
}
