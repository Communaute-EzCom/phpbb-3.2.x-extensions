<?php
/**
*
* @package JV Points System
* @version $Id: points.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\points\includes;

class points
{
	protected $container, $db, $user, $auth, $config;

	public function __construct($phpbb_container, $db, $user, $auth, $config)
	{
		$this->container = $phpbb_container;
		$this->db = $db;
		$this->user = $user;
		$this->auth = $auth;
		$this->config = $config;
	}

	public function number_format($num, $default = false)
	{
		if ($default)
		{
			return number_format($num, 2, '.', '');
		}

		if (!$num)
		{
			return 0;
		}

		$decimals = explode('.', $num);
		if (!empty($decimals[1]) || !empty($decimals[2]))
		{
			$decimals = strlen(rtrim($decimals[1], '0'));
			$decimals = ($decimals > 2) ? 2 : $decimals;
		}
		else
		{
			$decimals = 0;
		}

		return number_format($num, $decimals, $this->user->lang['JV_POINTS_SEPARATOR_DECIMAL'], $this->user->lang['JV_POINTS_SEPARATOR_THOUSANDS']);
	}

	public function name_format($num)
	{
		$points = $this->number_format($num);
		return ($this->config['jv_points_name_pos'] == 'a') ? $points . ' ' . $this->name() : $this->name() . ' ' . $points;
	}

	public function name()
	{
		return ($this->config['jv_points_name_color']) ? '<strong style="color: #' . $this->config['jv_points_name_color'] . ';">' . $this->config['jv_points_name'] . '</strong>' : $this->config['jv_points_name'];
	}

	public function add($user_id, $amount)
	{
		$amount = (float) $amount;

		if (!$user_id || $amount <= 0)
		{
			return;
		}

		if (!is_array($user_id))
		{
			$user_id = array($user_id);
		}

		$sql = 'UPDATE ' . USERS_TABLE . "
				SET user_points = user_points + $amount
				WHERE " . $this->db->sql_in_set('user_id', array_map('intval', $user_id));
		$this->db->sql_query($sql);

		$this->actual_user('add', $user_id, $amount);
	}

	public function subtract($user_id, $amount, $zero = false)
	{
		$user_id = (int) $user_id;
		$amount  = (float) $amount;
		$return = false;

		if (!$user_id || $amount <= 0)
		{
			return $return;
		}

		$sql = 'SELECT user_points
				FROM ' . USERS_TABLE . "
				WHERE user_id = $user_id";
		$result = $this->db->sql_query($sql);
		$user_points = (float) $this->db->sql_fetchfield('user_points');
		$this->db->sql_freeresult($result);

		if ($user_points > 0)
		{
			$user_points -= $amount;

			if ($user_points >= 0)
			{
				$return = true;
			}

			if ($return || $zero)
			{
				$user_points = ($return) ? $user_points : 0;

				$this->set($user_id, $user_points);
			}
		}

		return $return;
	}

	public function set($user_id, $amount)
	{
		$amount  = (float) $amount;

		if (!$user_id || $amount < 0)
		{
			return;
		}

		if (!is_array($user_id))
		{
			$user_id = array($user_id);
		}

		$sql = 'UPDATE ' . USERS_TABLE . "
				SET user_points = $amount
				WHERE " . $this->db->sql_in_set('user_id', array_map('intval', $user_id));
		$this->db->sql_query($sql);

		$this->actual_user('set', $user_id, $amount);
	}

	public function display($user_type, $user_id, $points)
	{
		if ($user_type == USER_IGNORE || $user_id <= ANONYMOUS)
		{
			return false;
		}

		static $_cache_jv_user_points;

		if (empty($_cache_jv_user_points))
		{
			$_cache_jv_user_points = array(
				's_points_chg' => $this->auth->acl_gets('a_jv_points', 'm_jv_points_chg'),
				'u_points_chg' => $this->container->get('controller.helper')->route('jv_points_controller', array('mode' => 'change', 'u' => 'USER_ID'))
			);
		}

		return array(
			'S_HAS_JV_POINTS'		=> true,
			'S_HAS_JV_POINTS_CHG'	=> $_cache_jv_user_points['s_points_chg'],

			'U_JV_POINTS_CHG'		=> str_replace("USER_ID", $user_id, $_cache_jv_user_points['u_points_chg']),

			'JV_POINTS'				=> $this->name_format($points)
		);
	}

	public function post_reward($mode)
	{
		$reward = (float) $this->config['jv_points_post_reward'];

		if ($mode == 'post')
		{
			$reward += (float) $this->config['jv_points_topic_reward'];
		}

		return $reward;
	}

	public function actual_user($mode, $user_id, $amount)
	{
		if (in_array($this->user->data['user_id'], $user_id))
		{
			$this->user->data['user_points'] = ($mode == 'set') ? $amount : ($this->user->data['user_points'] + $amount);
		}
	}
}
