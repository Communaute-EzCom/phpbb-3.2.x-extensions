<?php
/**
*
* @package JV Points System
* @version $Id: v_1_0_0.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\points\migrations;

class v_1_0_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v310\extensions');
	}

	public function update_schema()
	{
		return array(
			'add_columns' => array(USERS_TABLE => array('user_points' => array('DECIMAL:15', 0.00)))
		);
	}

	public function revert_schema()
	{
		return array(
			'drop_columns' => array(USERS_TABLE => array('user_points'))
		);
	}

	public function update_data()
	{
		$sql = 'SELECT role_name
				FROM ' . ACL_ROLES_TABLE;
		$result = $this->sql_query($sql);
		$roles = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$roles[] = $row['role_name'];
		}
		$this->db->sql_freeresult($result);

		return array(
			// Add configs
			array('config.add', array('jv_points_enable', 1)),
			array('config.add', array('jv_points_name', 'Points')),
			array('config.add', array('jv_points_reg_start_balance', 0)),
			array('config.add', array('jv_points_post_reward', 0)),
			array('config.add', array('jv_points_topic_reward', 0)),
			array('config.add', array('jv_points_post_cost', 0)),
			array('config.add', array('jv_points_attach_cost', 0)),
			array('config.add', array('jv_points_attach_ext', '')),
			array('config.add', array('jv_points_name_color', '')),
			array('config.add', array('jv_points_name_pos', 'a')),

			// Add permissions
			array('permission.add', array('a_jv_points', true)),
			array('permission.add', array('m_jv_points_chg', true)),
			array('permission.add', array('u_jv_points_ignore_download_cost', true)),
			array('permission.add', array('u_jv_points_ignore_post_cost', true)),

			// Set permissions, if it exists the role
			array('if', array(
				(in_array('ROLE_ADMIN_FULL', $roles)),
				array('permission.permission_set', array('ROLE_ADMIN_FULL', array('a_jv_points')))
			)),
			array('if', array(
				(in_array('ROLE_MOD_FULL', $roles)),
				array('permission.permission_set', array('ROLE_MOD_FULL', array('m_jv_points_chg')))
			)),
			array('if', array(
				(in_array('ROLE_USER_FULL', $roles)),
				array('permission.permission_set', array('ROLE_USER_FULL', array('u_jv_points_ignore_download_cost', 'u_jv_points_ignore_post_cost')))
			)),
			// Add modules
			array('module.add', array(
				'acp', 'ACP_CAT_DOT_MODS', 'JV_ACP_CAT_POINTS'
			)),
			array('module.add', array(
				'acp', 'JV_ACP_CAT_POINTS', array(
					'module_basename'	=> '\jv\points\acp\points_module',
					'modes'				=> array('settings', 'manage')
				)
			))
		);
	}
}
