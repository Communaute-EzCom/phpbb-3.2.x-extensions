<?php
/**
*
* @package JV Points System
* @version $Id: v_2_0_0.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\points\migrations;

class v_2_0_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\points\migrations\v_1_0_0');
	}

	public function update_data()
	{
		return array(
			array('custom', array(array($this, 'fixed_bot_points')))
		);
	}

	public function fixed_bot_points()
	{
		$sql = "UPDATE {$this->table_prefix}users
				SET user_points = 0
				WHERE user_type = " . USER_IGNORE;
		$this->sql_query($sql);
	}
}
