<?php
/**
*
* @package JV Points System
* @version $Id: points_info.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\points\acp;

class points_info
{
	function module()
	{
		return array(
			'filename'			=> '\jv\points\acp\points_module',
			'title'				=> 'JV_ACP_POINTS',
			'modes'				=> array(
				'settings'		=> array('title' => 'JV_ACP_POINTS_SETTINGS',		'auth' => 'ext_jv/points && acl_a_jv_points', 'cat' => array('JV_ACP_CAT_POINTS')),
				'manage'		=> array('title' => 'JV_ACP_POINTS_MANAGE_USERS',	'auth' => 'ext_jv/points && acl_a_jv_points', 'cat' => array('JV_ACP_CAT_POINTS')),
			)
		);
	}
}
