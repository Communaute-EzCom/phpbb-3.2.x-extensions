<?php
/**
*
* @package JV Points System
* @version $Id: points_module.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\points\acp;

class points_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	const JV_POINTS_ADD = 1;
	const JV_POINTS_SUBTRACT = 2;
	const JV_POINTS_SET = 3;

	protected $db, $config, $user, $request, $template, $log, $jv_points, $root_path, $php_ext;

	public function __construct()
	{
		global $db, $config, $user, $request, $template, $phpbb_log, $jv_points, $phpbb_root_path, $phpEx;

		$this->db = $db;
		$this->config = $config;
		$this->user = $user;
		$this->request = $request;
		$this->template = $template;
		$this->log = $phpbb_log;
		$this->jv_points = $jv_points;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $phpEx;
	}

	public function main($id, $mode)
	{
		if ($mode != 'settings' && !$this->config['jv_points_enable'])
		{
			trigger_error('JV_POINTS_DISABLED', E_USER_WARNING);
		}

		$error = array();
		$action = $this->request->variable('action', '');
		$submit = $this->request->is_set_post('submit');
		$update = $this->request->is_set_post('update');

		switch ($mode)
		{
			case 'settings':
				$this->user->add_lang('acp/board');
				$form_key = 'acp_board';
				add_form_key($form_key);

				if (!function_exists('validate_data'))
				{
					include($this->root_path . 'includes/functions_user.' . $this->php_ext);
				}

				switch ($mode)
				{
					case 'settings':
						$display_vars = array(
							'title'	=> 'JV_ACP_POINTS_SETTINGS',
							'vars'	=> array(
								'legend1'						=> 'JV_ACP_POINTS_SETTINGS',
								'jv_points_enable'				=> array('lang' => 'JV_ACP_POINTS_ENABLE',			'validate' => 'bool',		'type' => 'radio:yes_no',	'explain' => true),
								'jv_points_name'				=> array('lang' => 'JV_ACP_POINTS_NAME',			'validate' => 'string',		'type' => 'text:12:30',		'explain' => true),
								'jv_points_name_color'			=> array('lang' => 'JV_ACP_POINTS_NAME_COLOR',		'validate' => 'string',		'type' => 'custom',			'explain' => true, 'method' => 'set_color'),
								'jv_points_name_pos'			=> array('lang' => 'JV_ACP_POINTS_NAME_POS',		'validate' => 'string',		'type' => 'custom',			'explain' => true, 'method' => 'set_position'),
								'jv_points_reg_start_balance'	=> array('lang' => 'JV_POINTS_REG_START_BALANCE',	'validate' => 'jvp_float:0','type' => 'text:12:11',		'explain' => true, 'append' => ' ' . $this->jv_points->name()),
								'jv_points_topic_reward'		=> array('lang' => 'JV_POINTS_NEW_TOPIC_REWARD',	'validate' => 'jvp_float:0','type' => 'text:12:11',		'explain' => true, 'append' => ' ' . $this->jv_points->name()),
								'jv_points_post_reward'			=> array('lang' => 'JV_POINTS_NEW_POST_REWARD',		'validate' => 'jvp_float:0','type' => 'text:12:11',		'explain' => true, 'append' => ' ' . $this->jv_points->name()),

								'jv_points_post_cost'			=> array('lang' => 'JV_POINTS_NEW_POST_COST',		'validate' => 'jvp_float:0','type' => 'text:12:11',		'explain' => true, 'append' => ' ' . $this->jv_points->name()),
								'jv_points_attach_cost'			=> array('lang' => 'JV_POINTS_NEW_ATTACH_COST',		'validate' => 'jvp_float:0','type' => 'text:12:11',		'explain' => true, 'append' => ' ' . $this->jv_points->name()),
								'jv_points_attach_ext'			=> array('lang' => 'JV_ACP_POINTS_NEW_ATTACH_EXT',	'validate' => 'string',		'type' => 'custom',			'explain' => true, 'method' => 'file_exts'),

								'legend2'						=> 'ACP_SUBMIT_CHANGES',
							)
						);
					break;

					default:
						trigger_error('NO_MODE', E_USER_ERROR);
					break;
				}

				if (isset($display_vars['lang']))
				{
					$this->user->add_lang($display_vars['lang']);
				}

				$this->new_config = clone $this->config;
				$cfg_array = (isset($_REQUEST['config'])) ? $this->request->variable('config', array('' => ''), true) : $this->new_config;

				validate_config_vars($display_vars['vars'], $cfg_array, $error);

				if ($submit && !check_form_key($form_key))
				{
					$error[] = $this->user->lang['FORM_INVALID'];
				}

				if (count($error))
				{
					$submit = false;
				}

				foreach ($display_vars['vars'] as $config_name => $null)
				{
					if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
					{
						continue;
					}

					$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

					if ($config_name == 'jv_points_name_color')
					{
						$submit_ary['colour'] = $config_value;
						$validation_checks = array('colour' => array('hex_colour', true));

						if ($validation_error = validate_data($submit_ary, $validation_checks))
						{
							$validation_error = array_map(array(&$this->user, 'lang'), $validation_error);
							$error = array_merge($error, $validation_error);
							$submit = false;
						}
					}

					if ($submit)
					{
						if ($config_name == 'jv_points_attach_ext')
						{
							$config_value = implode(', ', $this->request->variable('jv_points_attach_ext', array('')));
						}

						set_config($config_name, $config_value);
					}
				}

				if ($submit)
				{
					$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'JV_LOG_POINTS_CONFIG_' . strtoupper($mode));
					trigger_error($this->user->lang('CONFIG_UPDATED') . adm_back_link($this->u_action), E_USER_NOTICE);
				}

				$this->tpl_name = 'acp_board';
				$this->page_title = $display_vars['title'];

				$this->template->assign_vars(array(
					'L_TITLE'			=> $this->user->lang[$display_vars['title']],
					'L_TITLE_EXPLAIN'	=> $this->user->lang[$display_vars['title'] . '_EXPLAIN'],

					'S_ERROR'			=> (count($error)) ? true : false,
					'ERROR_MSG'			=> implode('<br>', $error),

					'U_ACTION'			=> $this->u_action
				));

				foreach ($display_vars['vars'] as $config_key => $vars)
				{
					if (!is_array($vars) && strpos($config_key, 'legend') === false)
					{
						continue;
					}

					if (strpos($config_key, 'legend') !== false)
					{
						$this->template->assign_block_vars('options', array(
							'S_LEGEND'	=> true,
							'LEGEND'	=> (isset($this->user->lang[$vars])) ? $this->user->lang[$vars] : $vars
						));

						continue;
					}

					$type = explode(':', $vars['type']);

					$l_explain = '';
					if ($vars['explain'] && isset($vars['lang_explain']))
					{
						$l_explain = (isset($this->user->lang[$vars['lang_explain']])) ? $this->user->lang[$vars['lang_explain']] : $vars['lang_explain'];
					}
					else if ($vars['explain'])
					{
						$l_explain = (isset($this->user->lang[$vars['lang'] . '_EXPLAIN'])) ? $this->user->lang[$vars['lang'] . '_EXPLAIN'] : '';
					}

					if (in_array($config_key, array('jv_points_reg_start_balance', 'jv_points_topic_reward', 'jv_points_post_reward', 'jv_points_post_cost', 'jv_points_attach_cost')))
					{
						$this->new_config[$config_key] = $this->jv_points->number_format($this->new_config[$config_key], true);
					}

					$content = build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars);

					if (empty($content))
					{
						continue;
					}

					$this->template->assign_block_vars('options', array(
						'KEY'			=> $config_key,
						'TITLE'			=> (isset($this->user->lang[$vars['lang']])) ? $this->user->lang[$vars['lang']] : $vars['lang'],
						'S_EXPLAIN'		=> $vars['explain'],
						'TITLE_EXPLAIN'	=> $l_explain,
						'CONTENT'		=> $content
					));

					unset($display_vars['vars'][$config_key]);
				}
			break;

			case 'manage':
				$this->tpl_name = 'acp_points';
				$this->page_title = 'JV_ACP_POINTS_MANAGE_USERS';
				$form_key = 'jv_acp_points';
				add_form_key($form_key);

				$this->user->add_lang('acp/groups');
				$amount_user	= (float) $this->request->variable('amount_user', 0.00);
				$username		= $this->request->variable('username', '', true);
				$group_ids		= $this->request->variable('group_ids', array(0));

				if ($submit)
				{
					if (!check_form_key($form_key))
					{
						$error[] = $this->user->lang['FORM_INVALID'];
					}

					switch($action)
					{
						case 'manage_user':
							if ($amount_user < 0)
							{
								$error[] = $this->user->lang['JV_POINTS_ERROR_MINUS_VALUE'];
							}

							if (!$username)
							{
								$error[] = $this->user->lang['NO_USER_SPECIFIED'];
							}
							else
							{
								$userdata = $this->userdata($username, true);

								if (!count($userdata))
								{
									$error[] = $this->user->lang['NO_USER'];
								}
							}

							if (!count($error))
							{
								foreach ($userdata as $user_id => $row)
								{
									$username = $row['username'];
									$amount_user = ($update) ? $amount_user : $row['user_points'];

									if ($update)
									{
										$this->jv_points->set($user_id, $amount_user);

										$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'JV_LOG_POINTS_USER_CHANGED', false, array($username, $this->jv_points->number_format($row['user_points']), $this->jv_points->number_format($amount_user)));
										trigger_error(sprintf($this->user->lang['JV_POINTS_USER_CHANGED_SUCCESS'], $username) . adm_back_link($this->u_action), E_USER_NOTICE);
									}
								}
							}
						break;

						case 'manage_users':
							$amount_users	= (float) $this->request->variable('amount_users', 0.00);
							$usernames		= $this->request->variable('usernames', '', true);
							$users_task		= (int) $this->request->variable('users_task', 0);

							if ($amount_users < 0)
							{
								$error[] = $this->user->lang['JV_POINTS_ERROR_MINUS_VALUE'];
							}

							if (!$usernames)
							{
								$error[] = $this->user->lang['NO_USER_SPECIFIED'];
							}
							else
							{
								$userdata = $this->userdata($usernames, true);

								if (!count($userdata))
								{
									$error[] = $this->user->lang['NO_USER'];
								}
							}

							if (!$amount_users && in_array($users_task, array(self::JV_POINTS_ADD, self::JV_POINTS_SUBTRACT)))
							{
								$error[] = $this->user->lang['JV_ACP_POINTS_ERROR_ZERO_VALUE'];
							}

							if (!in_array($users_task, array(self::JV_POINTS_ADD, self::JV_POINTS_SUBTRACT, self::JV_POINTS_SET)))
							{
								$error[] = $this->user->lang['JV_ACP_POINTS_ERROR_NO_FUNCTION'];
							}

							if (!count($error))
							{
								$name_ary = array();
								foreach ($userdata as $user_id => $row)
								{
									$name_ary[] = $row['username'];

									if ($users_task == self::JV_POINTS_SUBTRACT)
									{
										$this->jv_points->subtract($user_id, $amount_users, true);
										$log = 'JV_LOG_POINTS_SUBTRACT_USER' . ((count($name_ary) > 1) ? 'S' : '');
									}
								}

								if ($users_task == self::JV_POINTS_ADD)
								{
									$this->jv_points->add(array_keys($userdata), $amount_users);
									$log = 'JV_LOG_POINTS_ADD_USER' . ((count($name_ary) > 1) ? 'S' : '');
								}
								else if ($users_task == self::JV_POINTS_SET)
								{
									$this->jv_points->set(array_keys($userdata), $amount_users);
									$log = 'JV_LOG_POINTS_SET_USER' . ((count($name_ary) > 1) ? 'S' : '');
								}

								$message = (count($name_ary) > 1) ? 'JV_ACP_POINTS_USERS_CHANGED_SUCCESS' : 'JV_POINTS_USER_CHANGED_SUCCESS';

								$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, $log, false, array(implode(', ', $name_ary), $this->jv_points->number_format($amount_users)));
								trigger_error(sprintf($this->user->lang[$message], implode(', ', $name_ary)) . adm_back_link($this->u_action), E_USER_NOTICE);
							}
						break;

						case 'manage_groups':
							$amount_groups		= (float) $this->request->variable('amount_groups', 0.00);
							$groups_task		= (int) $this->request->variable('groups_task', 0);
							$group_all_users	= $this->request->variable('group_all_users', false);
							$log_group			= $this->request->variable('log_group', false);

							if ($amount_groups < 0)
							{
								$error[] = $this->user->lang['JV_POINTS_ERROR_MINUS_VALUE'];
							}

							if (!count($group_ids))
							{
								$error[] = $this->user->lang['NO_GROUP'];
							}
							else
							{
								$groups = array();
								$group_userdata = $this->group_userdata($group_ids, $groups, $group_all_users, true);

								if (!count($group_userdata))
								{
									$error[] = $this->user->lang['JV_ACP_POINTS_SELECT_GROUP' . ((count($group_ids) > 1) ? 'S' : '') . '_NO_USER'];
								}
							}

							$type = '';
							if ($groups_task == self::JV_POINTS_ADD)
							{
								$type = 'ADD';
							}
							else if ($groups_task == self::JV_POINTS_SUBTRACT)
							{
								$type = 'SUBTRACT';
							}
							else if ($groups_task == self::JV_POINTS_SET)
							{
								$type = 'SET';
							}

							if (!$amount_groups && in_array($type, array('ADD', 'SUBTRACT')))
							{
								$error[] = $this->user->lang['JV_ACP_POINTS_ERROR_ZERO_VALUE'];
							}

							if (!in_array($type, array('ADD', 'SUBTRACT', 'SET')))
							{
								$error[] = $this->user->lang['JV_ACP_POINTS_ERROR_NO_FUNCTION'];
							}

							if (!count($error))
							{
								$name_ary = array();
								foreach ($group_userdata as $user_id => $row)
								{
									$name_ary[] = $row['username'];

									if ($type == 'SUBTRACT')
									{
										$this->jv_points->subtract($user_id, $amount_groups, true);
									}
								}

								if ($type == 'ADD')
								{
									$this->jv_points->add(array_keys($group_userdata), $amount_groups);
								}
								else if ($type == 'SET')
								{
									$this->jv_points->set(array_keys($group_userdata), $amount_groups);
								}

								if ($log_group)
								{
									$log_data = implode(', ', $groups);
									$log = 'JV_LOG_POINTS_' . $type . (($group_all_users) ? '' : '_USERS_DEFAULT') . '_GROUP' . ((count($groups) > 1) ? 'S' : '');
									$message = 'JV_ACP_POINTS' . (($group_all_users) ? '' : '_USERS_DEFAULT') . '_GROUP' . ((count($groups) > 1) ? 'S' : '') . '_CHANGED_SUCCESS';
								}
								else
								{
									$log_data = implode(', ', $name_ary);
									$log = 'JV_LOG_POINTS_' . $type . '_USER' . ((count($name_ary) > 1) ? 'S' : '');
									$message = (count($name_ary) > 1) ? 'JV_ACP_POINTS_USERS_CHANGED_SUCCESS' : 'JV_POINTS_USER_CHANGED_SUCCESS';
								}

								$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, $log, false, array($log_data, $this->jv_points->number_format($amount_groups)));
								trigger_error(sprintf($this->user->lang[$message], $log_data) . adm_back_link($this->u_action), E_USER_NOTICE);
							}
						break;
					}
				}

				if (!$action || $action == 'manage_groups')
				{
					$ignore_groups = array('BOTS', 'GUESTS');

					$sql = 'SELECT group_id, group_type, group_name
							FROM ' . GROUPS_TABLE . '
							WHERE ' . $this->db->sql_in_set('group_name', $ignore_groups, true) . '
							ORDER BY group_type DESC, group_name ASC';

					$result = $this->db->sql_query($sql);
					while ($row = $this->db->sql_fetchrow($result))
					{
						$checked = (in_array($row['group_id'], $group_ids)) ? 'checked="checked"' : '';

						$this->template->assign_block_vars('groups', array(
							'DATA' => '<input class="radio" type="checkbox" name="group_ids[]" value="' . (int) $row['group_id'] . '" ' . $checked . '>&nbsp;' . (($row['group_type'] == GROUP_SPECIAL) ? '<strong>' . $this->user->lang['G_' . $row['group_name']] . '</strong>' : ((!empty($this->user->lang[$row['group_name']])) ? : $row['group_name'])) . '<br>'
						));
					}
					$this->db->sql_freeresult($result);
				}

				switch($action)
				{
					case 'manage_user':
						$this->page_title = 'JV_ACP_POINTS_MANAGE_USER';

						if (!count($error))
						{
							$hidden_fields = build_hidden_fields(array(
								'username'	=> $username,
								'action'	=> $action,
								'update'	=> true
							));
						}
						else
						{
							$hidden_fields = build_hidden_fields(array('action' => $action));
						}

						$this->template->assign_vars(array(
							'S_JV_MANAGE_USER'			=> true,
							'S_JV_MANAGE_USER_POINTS'	=> (!count($error)) ? true : false,
							'S_JV_HIDDEN_FIELDS'		=> $hidden_fields
						));
					break;

					case 'manage_users':
						$this->template->assign_vars(array(
							'S_JV_MANAGE_USERS'			=> true,

							'JV_USERS_TASK'				=> $users_task,
							'JV_AMOUNT_USERS'			=> $this->jv_points->number_format($amount_users, true),
							'JV_MANAGE_USERNAMES'		=> (!empty($name_ary)) ? implode("\n", $name_ary) : $usernames
						));
					break;

					case 'manage_groups':
						$this->template->assign_vars(array(
							'S_JV_MANAGE_GROUPS'	=> true,
							'S_GROUP_ALL_USERS'		=> $group_all_users,
							'S_LOG_GROUP'			=> $log_group,

							'JV_GROUPS_TASK'		=> $groups_task,
							'JV_AMOUNT_GROUPS'		=> $this->jv_points->number_format($amount_groups, true)
						));
					break;

					default:
						$this->template->assign_vars(array(
							'S_JV_MANAGE_USER'		=> true,
							'S_JV_MANAGE_USERS'		=> true,
							'S_JV_MANAGE_GROUPS'	=> true,
							'S_GROUP_ALL_USERS'		=> true,
							'S_LOG_GROUP'			=> true,
							'S_JV_HIDDEN_FIELDS'	=> build_hidden_fields(array('action' => 'manage_user'))
						));
				}

				$this->template->assign_vars(array(
					'S_JV_POINTS_MANAGE_USERS'	=> true,
					'L_TITLE'					=> $this->user->lang[$this->page_title],
					'L_TITLE_EXPLAIN'			=> $this->user->lang[$this->page_title . '_EXPLAIN'],

					'S_ERROR'					=> (count($error)) ? true : false,
					'ERROR_MSG'					=> implode('<br>', $error),

					'U_ACTION'					=> $this->u_action,

					'JV_POINTS_NAME'			=> $this->jv_points->name(),
					'JV_AMOUNT_USER'			=> $this->jv_points->number_format($amount_user, true),
					'JV_MANAGE_USERNAME'		=> $username,

					'S_JV_HIDDEN_FIELDS_USERS'	=> build_hidden_fields(array('action' => 'manage_users')),
					'S_JV_HIDDEN_FIELDS_GROUPS'	=> build_hidden_fields(array('action' => 'manage_groups')),

					'U_FIND_USERNAME'			=> append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=searchuser&amp;form=jv_acp_points_manage_user&amp;field=username&amp;select_single=true'),
					'U_FIND_USERNAMES'			=> append_sid("{$this->root_path}memberlist.{$this->php_ext}", 'mode=searchuser&amp;form=jv_acp_points_manage_users&amp;field=usernames')
				));
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}
	}

	public function set_color($value, $key)
	{
		$content = '<input name="config[' . $key . ']" type="text" id="' . $key . '" value="' . $value . '" size="12" maxlength="6">';

		if ($value)
		{
			$content .= '&nbsp;<span style="background-color: #' . $value . '">&nbsp; &nbsp;</span>';
		}

		$content .= '&nbsp;&nbsp;<span>[ <a href="#" id="color_palette_toggle">' . $this->user->lang['COLOUR_SWATCH'] . '</a> ]</span>
		<div id="color_palette_placeholder" style="display: none;" data-orientation="h" data-height="12" data-width="15" data-target="#' . $key . '"></div>';

		return $content;
	}

	public function set_position($value, $key)
	{
		$radio_ary = array('b' => 'JV_ACP_POINTS_BEFORE', 'a' => 'JV_ACP_POINTS_AFTER');
		return h_radio("config[$key]", $radio_ary, $value, $key);
	}

	public function file_exts($value, $key)
	{
		$select_tpl = '';
		$sql = 'SELECT group_id
				FROM ' . EXTENSION_GROUPS_TABLE . '
				WHERE group_name = "ARCHIVES"';
		$result = $this->db->sql_query($sql);
		$group_id = (int) $this->db->sql_fetchfield('group_id');
		$this->db->sql_freeresult($result);

		if ($group_id)
		{
			$sql = 'SELECT extension
					FROM ' . EXTENSIONS_TABLE . "
					WHERE group_id = $group_id
					ORDER BY extension";
			$result = $this->db->sql_query($sql);
			while ($extension = (string) $this->db->sql_fetchfield('extension'))
			{
				$select_tpl .= '<option' . (($value && in_array($extension, explode(', ', $value))) ? ' selected="selected"' : '') . ' value="' . $extension . '">' . $extension . '</option>';
			}
			$this->db->sql_freeresult($result);
		}

		if ($select_tpl)
		{
			$select_tpl = '<select id="' . $key . '" name="' . $key . '[]" multiple="multiple" size="10">' . $select_tpl . '</select><input type="hidden" name="config[' . $key . ']">';
		}

		return $select_tpl;
	}

	private function userdata($username, $ignore_user_inactive = false)
	{
		$user_type = array(USER_NORMAL, USER_FOUNDER);

		if (!$ignore_user_inactive)
		{
			$user_type[] = USER_INACTIVE;
		}

		$sql = 'SELECT user_id, username, user_points
				FROM ' . USERS_TABLE . '
				WHERE ' . $this->db->sql_in_set('username_clean', array_map('utf8_clean_string', explode("\n", $username))) . '
				AND user_type IN (' . implode(', ', $user_type) . ')';
		$result = $this->db->sql_query($sql);
		$userdata = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$userdata[$row['user_id']] = array(
				'username'		=> $row['username'],
				'user_points'	=> $row['user_points']
			);
		}
		$this->db->sql_freeresult($result);

		return $userdata;
	}

	private function group_userdata(&$group_ids, &$groups, $group_all_users, $ignore_user_inactive = false)
	{
		$user_type = array(USER_NORMAL, USER_FOUNDER);

		if (!$ignore_user_inactive)
		{
			$user_type[] = USER_INACTIVE;
		}

		$groups = $userdata = array();
		$sql = 'SELECT group_id, group_name, group_type
				FROM '. GROUPS_TABLE .'
				WHERE '. $this->db->sql_in_set('group_id', array_map('intval', $group_ids));
		$result  = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			$groups[$row['group_id']] = ($row['group_type'] == GROUP_SPECIAL) ? $this->user->lang['G_' . $row['group_name']] : ((!empty($this->user->lang[$row['group_name']])) ? : $row['group_name']);
		}
		$this->db->sql_freeresult($result);

		$group_ids = array_map('intval', array_keys($groups));

		if (count($group_ids))
		{
			if ($group_all_users)
			{
				$sql_array = array(
					'SELECT'			=> 'u.user_id, u.username, u.user_points',
					'FROM'				=> array(USER_GROUP_TABLE => 'ug'),
					'LEFT_JOIN'			=> array(
						array('FROM'	=> array(USERS_TABLE => 'u'), 'ON' => 'ug.user_id = u.user_id')
					),
					'WHERE'				=> 'u.user_type IN (' . implode(', ', $user_type) . ')
						AND ug.user_id = u.user_id
						AND ' . $this->db->sql_in_set('ug.group_id', $group_ids)
				);

				$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
			}
			else
			{
				$sql_array = array(
					'SELECT'	=> 'u.user_id, u.username, u.user_points',
					'FROM'		=> array(USERS_TABLE => 'u'),
					'WHERE'		=> $this->db->sql_in_set('u.group_id', $group_ids)
				);

				$sql = $this->db->sql_build_query('SELECT', $sql_array);
			}

			$result = $this->db->sql_query($sql);
			while ($row = $this->db->sql_fetchrow($result))
			{
				$userdata[$row['user_id']] = array(
					'username'		=> $row['username'],
					'user_points'	=> $row['user_points']
				);
			}
			$this->db->sql_freeresult($result);
		}

		return $userdata;
	}
}
