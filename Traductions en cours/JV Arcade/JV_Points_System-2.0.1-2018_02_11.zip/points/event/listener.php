<?php
/**
*
* @package JV Points System
* @version $Id: listener.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\points\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $user, $auth, $config, $template, $controller_helper, $jv_points, $root_path, $php_ext;

	public function __construct($user, $auth, $config, $template, $controller_helper, $jv_points, $root_path, $php_ext)
	{
		$this->user = $user;
		$this->auth = $auth;
		$this->config = $config;
		$this->template = $template;
		$this->controller_helper = $controller_helper;
		$this->jv_points = $jv_points;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.common'								=> 'common',
			'core.user_setup'							=> 'language',
			'core.permissions'							=> 'permissions_language',

			'core.page_header'							=> 'header',
			'core.download_file_send_to_browser_before'	=> 'download_file',

			'core.validate_config_variable'				=> 'validate_config_variable',
			'core.user_add_modify_data'					=> 'user_add_modify_data',
			'core.modify_posting_parameters'			=> 'modify_posting_parameters',
			'core.submit_post_end'						=> 'submit_post_end',
			'core.approve_posts_after'					=> 'approve_posts_after',

			'core.memberlist_prepare_profile_data'		=> 'memberlist_prepare_profile_data',
			'core.viewtopic_post_rowset_data'			=> 'viewtopic_post_rowset_data',
			'core.viewtopic_modify_post_row'			=> 'topic_post_member_info',
			'core.viewonline_overwrite_location'		=> 'viewonline'
		);
	}

	public function common()
	{
		global $jv_points;

		$jv_points = $this->jv_points;
	}

	public function language($event)
	{
		$event['lang_set_ext'] = array_merge($event['lang_set_ext'], array(
			array(
				'ext_name' => 'jv/points',
				'lang_set' => 'points'
			)
		));
	}

	public function permissions_language($event)
	{
		$event['categories'] = array_merge($event['categories'], array(
			'jv_points' => 'ACL_CAT_JV_POINTS',
		));

		$event['permissions'] = array_merge($event['permissions'], array(
			// Admin Permissions
			'a_jv_points'						=> array('lang' => 'ACL_A_JV_POINTS',						'cat' => 'misc'),

			// Mod Permissions
			'm_jv_points_chg'					=> array('lang' => 'ACL_M_JV_POINTS_CHG',					'cat' => 'jv_points'),

			// User Permissions
			'u_jv_points_ignore_download_cost'	=> array('lang' => 'ACL_U_JV_POINTS_IGNORE_DOWNLOAD_COST',	'cat' => 'jv_points'),
			'u_jv_points_ignore_post_cost'		=> array('lang' => 'ACL_U_JV_POINTS_IGNORE_POST_COST',		'cat' => 'jv_points')
		));
	}

	public function header()
	{
		if (!empty($this->config['jv_points_enable']) && $this->user->data['is_registered'])
		{
			$this->template->assign_vars(array(
				'S_IN_JV_POINST_SYSTEM'			=> true,
				'U_JV_POINTS'					=> $this->controller_helper->route('jv_points_controller'),

				'JV_USER_POINTS'				=> $this->jv_points->name() . ' [' . $this->jv_points->number_format($this->user->data['user_points']) . ']'
			));
		}
	}

	public function download_file($event)
	{
		$attach_cost = (float) $this->config['jv_points_attach_cost'];

		if ($attach_cost > 0 && $this->config['jv_points_attach_ext'] && $event['attach_id'])
		{
			if (in_array($event['attachment']['extension'], explode(', ', $this->config['jv_points_attach_ext'])))
			{
				if (!$this->auth->acl_get('u_jv_points_ignore_download_cost'))
				{
					$filename = $this->root_path . $this->config['upload_path'] . '/' . $event['attachment']['physical_filename'];
					if (@file_exists($filename) && @is_readable($filename))
					{
						if (!$this->jv_points->subtract($this->user->data['user_id'], $attach_cost))
						{
							$msg  = sprintf($this->user->lang['JV_POINTS_ATTACH_DOWNLOAD_NO_POINTS'], $this->jv_points->name());
							$msg .= '<br><br>';
							$msg .= sprintf($this->user->lang['JV_POINTS_MORE_INFO_HERE'], '<a href="' . $this->controller_helper->route('jv_points_controller', array('mode' => 'info')) . '">', '</a>');

							trigger_error($msg);
						}
					}
				}
			}
		}
	}

	public function validate_config_variable($event)
	{
		$type	= 0;
		$min	= 1;
		$max	= 2;

		$validator = explode(':', $event['config_definition']['validate']);

		switch ($validator[$type])
		{
			case 'jvp_float':
				$cfga = $event['cfg_array'];
				$cfga[$event['config_name']] = (float) $cfga[$event['config_name']];
				$event['cfg_array'] = $cfga;

				if (isset($validator[$min]) && $event['cfg_array'][$event['config_name']] < $validator[$min])
				{
					$event['error'] = array_merge($event['error'], array(sprintf($this->user->lang['SETTING_TOO_LOW'], $this->user->lang[$event['config_definition']['lang']], $validator[$min])));
				}
				else if (isset($validator[$max]) && $event['cfg_array'][$event['config_name']] > $validator[$max])
				{
					$event['error'] = array_merge($event['error'], array(sprintf($this->user->lang['SETTING_TOO_BIG'], $this->user->lang[$event['config_definition']['lang']], $validator[$max])));
				}
				else if (strpos($event['config_name'], '_max') !== false)
				{
					$min_name = str_replace('_max', '_min', $event['config_name']);

					if (isset($event['cfg_array'][$min_name]) && is_numeric($event['cfg_array'][$min_name]) && $event['cfg_array'][$event['config_name']] < $event['cfg_array'][$min_name])
					{
						$event['error'] = array_merge($event['error'], array(sprintf($this->user->lang['SETTING_TOO_LOW'], $this->user->lang[$event['config_definition']['lang']], (float) $event['cfg_array'][$min_name])));
					}
				}
			break;
		}
	}

	public function user_add_modify_data($event)
	{
		if ($event['sql_ary']['user_type'] == USER_IGNORE)
		{
			return;
		}

		$event['sql_ary'] = array_merge($event['sql_ary'], array('user_points' => (float) $this->config['jv_points_reg_start_balance']));
	}

	public function modify_posting_parameters($event)
	{
		if (!$this->auth->acl_get('u_jv_points_ignore_post_cost'))
		{
			$cost = (float) $this->config['jv_points_post_cost'];
			if (in_array($event['mode'], array('post', 'reply', 'quote')) && $cost > 0)
			{
				$reward = $this->jv_points->post_reward($event['mode']);
				$cost_write_post = ($cost > 0 && $reward < $cost) ? $cost - $reward : 0;

				if ($cost_write_post > 0 && $this->user->data['user_points'] < $cost_write_post)
				{
					$this->user->setup();
					$msg  = sprintf($this->user->lang['JV_POINTS_WRITE_POST_NO_POINTS'], $this->jv_points->name());
					$msg .= '<br><br>';
					$msg .= sprintf($this->user->lang['JV_POINTS_MORE_INFO_HERE'], '<a href="' . $this->controller_helper->route('jv_points_controller', array('mode' => 'info')) . '">', '</a>');

					trigger_error($msg);
				}
			}
		}
	}

	public function submit_post_end($event)
	{
		$add_points = ($this->user->data['user_type'] != USER_IGNORE && !empty($this->user->data['is_registered']) && $this->user->data['user_id'] != ANONYMOUS) ? true : false;

		if (in_array($event['mode'], array('post', 'reply', 'quote')))
		{
			if (!$this->auth->acl_get('f_noapprove', $event['data']['forum_id']))
			{
				$cost_write_post = ($this->auth->acl_get('u_jv_points_ignore_post_cost')) ? 0 : (float) $this->config['jv_points_post_cost'];
				$reward = 0;
			}
			else if ($this->auth->acl_get('u_jv_points_ignore_post_cost'))
			{
				$cost_write_post = 0;
				$reward = $this->jv_points->post_reward($event['mode']);
			}
			else
			{
				$cost = (float) $this->config['jv_points_post_cost'];
				$reward = $this->jv_points->post_reward($event['mode']);

				$cost_write_post = ($cost > 0 && $reward < $cost) ? $cost - $reward : 0;
				$reward = ($cost_write_post > 0) ? 0 : (($cost > 0) ? $reward - $cost : $reward);
			}

			if ($cost_write_post > 0)
			{
				$this->jv_points->subtract($this->user->data['user_id'], $cost_write_post);
			}
			else if ($add_points && $reward > 0)
			{
				$this->jv_points->add($this->user->data['user_id'], $reward);
			}
		}
	}

	public function approve_posts_after($event)
	{
		$topic_reward = (float) $this->config['jv_points_topic_reward'];
		$post_reward = (float) $this->config['jv_points_post_reward'];

		if ($topic_reward > 0 || $post_reward > 0)
		{
			$users = array();
			foreach ($event['post_info'] as $post_id => $post_data)
			{
				if ($post_data['user_type'] == USER_IGNORE || $post_data['user_id'] <= ANONYMOUS)
				{
					continue;
				}

				if (!isset($users[$post_data['user_id']]))
				{
					$users[$post_data['user_id']] = 0;
				}

				if ($topic_reward > 0  && !$post_data['topic_posts_approved'])
				{
					$users[$post_data['user_id']] += $topic_reward;
				}

				if ($post_reward > 0 && !$post_data['post_visibility'])
				{
					$users[$post_data['user_id']] += $post_reward;
				}

				if ($users[$post_data['user_id']] <= 0)
				{
					unset($users[$post_data['user_id']]);
				}
			}

			if (count($users))
			{
				foreach ($users as $user_id => $reward)
				{
					$this->jv_points->add($user_id, $reward);
				}

				unset($users);
			}
		}
	}

	public function memberlist_prepare_profile_data($event)
	{
		if ($event['data']['user_type'] == USER_IGNORE || $event['data']['user_id'] == ANONYMOUS)
		{
			return;
		}

		if (($user_points = $this->jv_points->display($event['data']['user_type'], $event['data']['user_id'], $event['data']['user_points'])) !== false)
		{
			$event['template_data'] = array_merge($event['template_data'], $user_points);
		}
	}

	public function viewtopic_post_rowset_data($event)
	{
		$event['rowset_data'] = array_merge($event['rowset_data'], array('user_points' => $event['row']['user_points']));
	}

	public function topic_post_member_info($event)
	{
		if ($event['user_poster_data']['user_type'] == USER_IGNORE || $event['poster_id'] == ANONYMOUS)
		{
			return;
		}

		if (($user_points = $this->jv_points->display($event['user_poster_data']['user_type'], $event['poster_id'], $event['row']['user_points'])) !== false)
		{
			$event['post_row'] = array_merge($event['post_row'], $user_points);
		}
	}

	public function viewonline($event)
	{
		if ($event['on_page'][1] == 'app' && strpos($event['row']['session_page'], 'app.' . $this->php_ext . '/points') !== false)
		{
			if (strpos($event['row']['session_page'], 'mode=info') !== false)
			{
				$event['location'] = $this->user->lang['JV_POINTS_INFO_VIEWING'];
				$event['location_url'] = $this->controller_helper->route('jv_points_controller', array('mode' => 'info'));
			}
			else if (strpos($event['row']['session_page'], 'mode=faq') !== false)
			{
				$event['location'] = $this->user->lang['JV_POINTS_FAQ_VIEWING'];
				$event['location_url'] = $this->controller_helper->route('jv_points_controller', array('mode' => 'faq'));
			}
			else
			{
				$event['location'] = $this->user->lang['JV_POINTS_VIEWING'];
				$event['location_url'] = $this->controller_helper->route('jv_points_controller');
			}
		}
	}
}
