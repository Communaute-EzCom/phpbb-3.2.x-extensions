<?php
/**
*
* @package JV Points System
* @version $Id: main.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\points\controller;

class main
{
	protected $ext_manager, $user, $auth, $config, $request, $template, $controller_helper, $jv_points, $root_path, $php_ext;

	public function __construct($ext_manager, $user, $auth, $config, $request, $template, $controller_helper, $jv_points, $phpbb_root_path, $php_ext)
	{
		$this->ext_manager = $ext_manager;
		$this->user = $user;
		$this->auth = $auth;
		$this->config = $config;
		$this->request = $request;
		$this->template = $template;
		$this->controller_helper = $controller_helper;
		$this->jv_points = $jv_points;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $php_ext;
	}

	public function main()
	{
		if (!$this->user->data['is_registered'])
		{
			if ($this->user->data['is_bot'])
			{
				redirect(append_sid("{$this->root_path}index.{$this->php_ext}"));
			}

			login_box('', $this->user->lang['JV_POINTS_LOGIN_EXPLAIN']);
		}

		if (!$this->config['jv_points_enable'])
		{
			trigger_error('JV_POINTS_DISABLED');
		}

		$mode = $this->request->variable('mode', 'main');

		$points_modules = array('main', 'info', 'faq');

		if ($this->auth->acl_gets('a_jv_points', 'm_jv_points_chg'))
		{
			$points_modules[] = 'change';
		}

		if (!in_array($mode, $points_modules))
		{
			$mode = 'main';
		}

		foreach ($points_modules as $p_module)
		{
			$this->template->assign_block_vars('points_tabs', array(
				'S_SELECTED'	=> ($p_module == $mode) ? true : false,
				'U_TITLE'		=> $this->controller_helper->route('jv_points_controller', array('mode' => $p_module)),
				'L_TITLE'		=> $this->user->lang['JV_POINTS_' . strtoupper($p_module)]
			));
		}

		include($this->root_path . 'includes/functions_module.' . $this->php_ext);

		$ext_path = $this->ext_manager->get_extension_path('jv/points', true) . 'includes/';
		$module = new \p_master($ext_path);

		$module->load('points', $mode);
		$module->display($this->user->lang['JV_POINTS_' . strtoupper($mode)]);
	}
}
