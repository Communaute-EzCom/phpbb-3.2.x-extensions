<?php
/**
*
* @package JV Points System
* @version $Id: points.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JV_POINTS_ADD_USER_EXPLAIN'			=> 'Entrer le nom de l’utilisateur dont vous voulez modifier le solde.',
	'JV_POINTS_AMOUNT'						=> 'Montant',
	'JV_POINTS_AMOUNT_USER_EXPLAIN'			=> 'Entrer le montant désiré afin de changer le solde de l’utilisateur.',
	'JV_POINTS_ATTACH_DOWNLOAD_NO_POINTS'	=> 'Vous n’avez pas assez de “%s” pour télécharger ce fichier.',
	'JV_POINTS_BALANCE'						=> 'Solde',
	'JV_POINTS_CHANGE'						=> 'Modifier le solde',
	'JV_POINTS_CHANGE_TITLE'				=> 'Modifier le solde de l’utilisateur',
	'JV_POINTS_CONTROL_PANEL'				=> 'Panneau de contrôle du Système de Points',
	'JV_POINTS_COSTS'						=> 'Coûts',
	'JV_POINTS_DISABLED'					=> 'Le Système de Points est actuellement désactivé.',
	'JV_POINTS_ERROR_MINUS_VALUE'			=> 'Le montant spécifié ne doit pas être une valeur négative.',
	'JV_POINTS_FAQ'							=> 'FAQ',
	'JV_POINTS_GUIDE'						=> 'Guide du Système de Points',
	'JV_POINTS_INFO'						=> 'Infos',
	'JV_POINTS_INFO_EXPLAIN'				=> 'Ici vous pouvez voir les paramètres actuels qui réglementent les récompenses et les coûts. Notez que l’administrateur peut modifier ces réglages à tout moment.',
	'JV_POINTS_INFO_TITLE'					=> 'Généralités',
	'JV_POINTS_FAQ_VIEWING'					=> 'Voir le guide du Système de points',
	'JV_POINTS_INFO_VIEWING'				=> 'Voir les généralités du Système de points',
	'JV_POINTS_LOGIN_EXPLAIN'				=> 'Il faut être connecté pour voir le panneau de contrôle du Système de Points.',
	'JV_POINTS_MAIN'						=> 'Aperçu',
	'JV_POINTS_MAIN_EXPLAIN'				=> 'Hello %s !<br><br>Solde actuel: %s.',
	'JV_POINTS_MAIN_TITLE'					=> 'Membres les plus fortunés',
	'JV_POINTS_MODIFY'						=> 'Modifier',
	'JV_POINTS_MORE_INFO_HERE'				=> 'Plus d’informations %sICI%s.',
	'JV_POINTS_NEW_ATTACH_COST'				=> 'Coût de téléchargement des fichiers joints',
	'JV_POINTS_NEW_ATTACH_COST_EXPLAIN'		=> 'Le coût de téléchargement s’applique aux fichiers avec l’extension suivante: “%s”.',
	'JV_POINTS_NEW_ATTACHS_COST_EXPLAIN'	=> 'Le coût de téléchargement s’applique aux fichiers avec les extensions suivantes: “%s”.',
	'JV_POINTS_NEW_POST_COST'				=> 'Coût d’un nouveau message',
	'JV_POINTS_NEW_POST_REWARD'				=> 'Récompense pour un nouveau message',
	'JV_POINTS_NEW_TOPIC_REWARD'			=> 'Récompense pour un nouveau sujet',
	'JV_POINTS_NO_USER'						=> 'Actuellement le solde de tous les utilisateurs est de zéro.',
	'JV_POINTS_REG_START_BALANCE'			=> 'Solde de départ des nouveaux membres',
	'JV_POINTS_REWARDS'						=> 'Récompenses',
	'JV_POINTS_SEPARATOR_DECIMAL'			=> '.',
	'JV_POINTS_SEPARATOR_THOUSANDS'			=> ',',
	'JV_POINTS_USER_CHANGED_SUCCESS'		=> 'Le solde de l’utilisateur “%s” a été changé avec succès.',
	'JV_POINTS_VIEWING'						=> 'Voir le panneau de contrôle du Système de Points',
	'JV_POINTS_WRITE_POST_NO_POINTS'		=> 'Vous n’avez pas assez de “%s” pour poster un nouveau message.',
));

?>