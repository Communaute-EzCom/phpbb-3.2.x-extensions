<?php
/**
*
* @package JV Points System
* @version $Id: info_acp_points.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JV_ACP_CAT_POINTS'										=> 'Système de Points',
	'JV_ACP_POINTS'											=> 'JV Points System',
	'JV_ACP_POINTS_ADD'										=> 'Ajouter',
	'JV_ACP_POINTS_AFTER'									=> 'Après',
	'JV_ACP_POINTS_AMOUNT_USERS_EXPLAIN'					=> 'Entrer le montant désiré afin de changer le solde de l’utilisateur.',
	'JV_ACP_POINTS_BEFORE'									=> 'Avant',
	'JV_ACP_POINTS_ENABLE'									=> 'Activer le Système de Points',
	'JV_ACP_POINTS_ENABLE_EXPLAIN'							=> 'Permet aux utilisateurs d’utiliser le Système de Points',
	'JV_ACP_POINTS_ERROR_NO_FUNCTION'						=> 'Vous n’avez spécifié aucune fonction.',
	'JV_ACP_POINTS_ERROR_ZERO_VALUE'						=> 'Le montant spécifé ne doit pas être zéro.',
	'JV_ACP_POINTS_GROUPS_CHANGED_SUCCESS'					=> 'Pour les groupes “%s”, tous les soldes des utilisateurs ont été modifiés avec succès.',
	'JV_ACP_POINTS_GROUP_ALL_USERS'							=> 'Tous les utilisateurs dans le groupe',
	'JV_ACP_POINTS_GROUP_ALL_USERS_EXPLAIN'					=> 'Si NON est sélectionné, cela ne s’appliquera qu’aux utilisateurs dont c’est le groupe par défaut.',
	'JV_ACP_POINTS_GROUP_CHANGED_SUCCESS'					=> 'Tous les soldes des utilisateurs du groupe “%s” ont été modifiés avec succès.',
	'JV_ACP_POINTS_LOG_FORMAT_GROUP'						=> 'Format de sélection',
	'JV_ACP_POINTS_LOG_FORMAT_GROUP_EXPLAIN'				=> 'On précise ici si la gestion se fera sur les noms de groupes ou si elle inclura les noms d’utilisateurs.',
	'JV_ACP_POINTS_MANAGE_GROUPS'							=> 'Gérer les groupes',
	'JV_ACP_POINTS_MANAGE_USER'								=> 'Gérer un utilisateur',
	'JV_ACP_POINTS_MANAGE_USERS'							=> 'Gestion des utilisateurs',
	'JV_ACP_POINTS_MANAGE_USERS_EXPLAIN'					=> 'Ici vous pouvez modifier les soldes des utilisateurs, individuellement, ou par lots, ou par groupes.',
	'JV_ACP_POINTS_MANAGE_USER_EXPLAIN'						=> 'Ici vous pouvez modifier le solde de l’utilisateur.',
	'JV_ACP_POINTS_NAME'									=> 'Nom des points',
	'JV_ACP_POINTS_NAME_COLOR'								=> 'Couleur du nom des points',
	'JV_ACP_POINTS_NAME_COLOR_EXPLAIN'						=> 'Si vous voulez changer la couleur du “Nom des points”, c’est ici.',
	'JV_ACP_POINTS_NAME_EXPLAIN'							=> 'C’est le nom que vous voulez donner pour les points sur votre forum. Il s’affichera sur le forum, à la place du mot points.',
	'JV_ACP_POINTS_NAME_POS'								=> 'Position du nom des points',
	'JV_ACP_POINTS_NAME_POS_EXPLAIN'						=> 'Ici vous pouvez préciser si le “Nom des points” sera positionné avant ou après le montant.',
	'JV_ACP_POINTS_NEW_ATTACH_EXT'							=> 'Sélectionner les extensions de fichiers',
	'JV_ACP_POINTS_NEW_ATTACH_EXT_EXPLAIN'					=> 'Les coûts de téléchargements ne s’appliqueront qu’aux extensions de fichiers sélectionnées.',
	'JV_ACP_POINTS_SELECT_FUNC'								=> 'Sélectionner la fonction',
	'JV_ACP_POINTS_SELECT_GROUPS_NO_USER'					=> 'L’utilisateur n’a pas pu être trouvé dans les groupes sélectionnés.',
	'JV_ACP_POINTS_SELECT_GROUP_NO_USER'					=> 'L’utilisateur n’a pas pu être trouvé dans le groupe sélectionné.',
	'JV_ACP_POINTS_SET'										=> 'Définir',
	'JV_ACP_POINTS_SETTINGS'								=> 'Paramètres généraux',
	'JV_ACP_POINTS_SETTINGS_EXPLAIN'						=> 'Les options ci-dessous vous permettent de personnaliser les différents paramètres généraux.',
	'JV_ACP_POINTS_SUBTRACT'								=> 'Soustraire',
	'JV_ACP_POINTS_USERS_CHANGED_SUCCESS'					=> 'Les soldes des utilisateurs “%s” ont été changés avec succès.',
	'JV_ACP_POINTS_USERS_DEFAULT_GROUPS_CHANGED_SUCCESS'	=> 'Les soldes des utilisateurs des groupes par défaut “%s” ont été changés avec succès.',
	'JV_ACP_POINTS_USERS_DEFAULT_GROUP_CHANGED_SUCCESS'		=> 'Les soldes des utilisateurs du groupe par défaut “%s” ont été changés avec succès.',
	'JV_LOG_POINTS_ADD_GROUP'								=> '<strong>Ajouter un montant pour tous les utilisateurs du groupe suivant: %s</strong><br>» Montant ajouté: %s',
	'JV_LOG_POINTS_ADD_GROUPS'								=> '<strong>Ajouter un montant pour tous les utilisateurs des groupes suivants: %s</strong><br>» Montant ajouté: %s',
	'JV_LOG_POINTS_ADD_USER'								=> '<strong>Ajouter un montant pour l’utilisateur suivant: %s</strong><br>» Montant ajouté: %s',
	'JV_LOG_POINTS_ADD_USERS'								=> '<strong>Ajouter un montant pour les utilisateurs suivants: %s</strong><br>» Montant ajouté: %s',
	'JV_LOG_POINTS_ADD_USERS_DEFAULT_GROUP'					=> '<strong>Ajouter un montant pour les utilisateurs du groupe par défaut suivant: %s</strong><br>» Montant ajouté: %s',
	'JV_LOG_POINTS_ADD_USERS_DEFAULT_GROUPS'				=> '<strong>Ajouter un montant pour les utilisateurs des groupes par défaut suivants: %s</strong><br>» Montant ajouté: %s',
	'JV_LOG_POINTS_CONFIG_SETTINGS'							=> '<strong>Paramètres spécifiques au système de modifications des montants.</strong>',
	'JV_LOG_POINTS_SET_GROUP'								=> '<strong>Définir un montant pour tous les utilisateurs du groupe suivant: %s</strong><br>» Montant défini: %s',
	'JV_LOG_POINTS_SET_GROUPS'								=> '<strong>Définir un montant pour tous les utilisateurs des groupes suivants: %s</strong><br>» Montant défini: %s',
	'JV_LOG_POINTS_SET_USER'								=> '<strong>Définir un montant pour l’utilisateur suivant: %s</strong><br>» Montant défini: %s',
	'JV_LOG_POINTS_SET_USERS'								=> '<strong>Définir un montant pour les utilisateurs suivants: %s</strong><br>» Montant défini: %s',
	'JV_LOG_POINTS_SET_USERS_DEFAULT_GROUP'					=> '<strong>Définir un montant pour les utilisateurs du groupe par défaut suivant: %s</strong><br>» Montant défini: %s',
	'JV_LOG_POINTS_SET_USERS_DEFAULT_GROUPS'				=> '<strong>Définir un montant pour les utilisateurs des groupes par défaut suivants: %s</strong><br>» Montant défini: %s',
	'JV_LOG_POINTS_SUBTRACT_GROUP'							=> '<strong>Soustraire un montant pour tous les utilisateurs du groupe suivant: %s</strong><br>» Montant soustrait: %s',
	'JV_LOG_POINTS_SUBTRACT_GROUPS'							=> '<strong>Soustraire un montant pour tous les utilisateurs des groupes suivants: %s</strong><br>» Montant soustrait: %s',
	'JV_LOG_POINTS_SUBTRACT_USER'							=> '<strong>Soustraire un montant pour l’utilisateur suivant: %s</strong><br>» Montant soustrait: %s',
	'JV_LOG_POINTS_SUBTRACT_USERS'							=> '<strong>Soustraire un montant pour les utilisateurs suivants: %s</strong><br>» Montant soustrait: %s',
	'JV_LOG_POINTS_SUBTRACT_USERS_DEFAULT_GROUP'			=> '<strong>Soustraire un montant pour les utilisateurs du groupe par défaut suivant: %s</strong><br>» Montant soustrait: %s',
	'JV_LOG_POINTS_SUBTRACT_USERS_DEFAULT_GROUPS'			=> '<strong>Soustraire un montant pour les utilisateurs des groupes par défaut suivants: %s</strong><br>» Montant soustrait: %s',
	'JV_LOG_POINTS_USER_CHANGED'							=> '<strong>Modification du solde de l’utilisateur %s. Solde original: %s</strong><br>» Nouveau solde: %s',
	'JV_POINTS_NEW_ATTACH_COST_EXPLAIN'						=> 'Si un utilisateur télécharge un fichier joint, ce montant sera soustrait.',
	'JV_POINTS_NEW_POST_COST_EXPLAIN'						=> 'Si un utilisateur poste un nouveau message, ce montant sera soustrait.',
	'JV_POINTS_NEW_POST_REWARD_EXPLAIN'						=> 'Si un utilisateur poste un nouveau message, il recevra cette récompense.<br><em>Remarque: se rajoute à la récompense de sujet si un nouveau sujet a été créé.</em>',
	'JV_POINTS_NEW_TOPIC_REWARD_EXPLAIN'					=> 'Si un utilisateur ouvre un nouveau sujet, il recevra cette récompense.',
	'JV_POINTS_REG_START_BALANCE_EXPLAIN'					=> 'Quand un nouveau membre s’enregistre sur le site, il reçoit ce solde de départ.',
));

?>