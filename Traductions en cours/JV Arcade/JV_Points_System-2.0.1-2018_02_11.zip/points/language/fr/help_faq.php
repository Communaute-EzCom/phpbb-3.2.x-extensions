<?php
/**
*
* @package JV Points System
* @version $Id: help_faq.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JV_POINTS_HELP_FAQ_BLOCK_INTRO'						=> 'Introduction',
	'JV_POINTS_HELP_FAQ_BLOCK_GENERAL'						=> 'Questions générales',
// step 1
	'JV_POINTS_HELP_FAQ_INTRO_SYSTEM_ANSWER'				=> 'Le Système de Points permet aux utilisateurs de gagner des récompenses et des points en certains endroits du forum. L’administrateur définit la façon de gagner ces points et à quoi ils peuvent servir. Ce guide vous sera utile pour en comprendre les subtilités.',
	'JV_POINTS_HELP_FAQ_INTRO_SYSTEM_QUESTION'				=> 'Qu’est-ce que le Système de Points ?',

	'JV_POINTS_HELP_FAQ_INTRO_MODULES_ANSWER'				=> 'Il y a beaucoup de modules inclus dans le Système de Points, mais ne sont disponibles que ceux qui ont été activés par l’administrateur. 
																<br><br><strong>Modules:</strong>
																<ul>
																	<li><strong>Aperçu</strong> - Sont affichés ici les utilisateurs qui ont les plus grands soldes ainsi que son propre solde courant.</li>
																	<li><strong>Généralités</strong> - On peut voir ici les paramètres actuels qui concernent les récompenses et les coûts.</li>
																	<li><strong>Guide</strong></li>
																</ul>',
	'JV_POINTS_HELP_FAQ_INTRO_MODULES_QUESTION'				=> 'Quels sont les modules inclus dans le Sytème de Points ?',
// step 2
	'JV_POINTS_HELP_FAQ_GENERAL_SAME_REWARD_COST_ANSWER'	=> 'Si accidentellement ces réglages ont été établis, le résultat est zéro.',
	'JV_POINTS_HELP_FAQ_GENERAL_SAME_REWARD_COST_QUESTION'	=> 'Qu’arrive-t-il si la récompense et le coût ont la même valeur ?',

	'JV_POINTS_HELP_FAQ_GENERAL_POST_REWARD_ANSWER'			=> 'Si votre nouveau message doit être approuvé par un modérateur, il faut attendre la confirmaton du modérateur pour recevoir la récompense.',
	'JV_POINTS_HELP_FAQ_GENERAL_POST_REWARD_QUESTION'		=> 'J’ai posté un message mais n’ai pas eu de récompense, pourquoi ?',

	'JV_POINTS_HELP_FAQ_GENERAL_POST_REWARD_MOD_ANSWER'		=> 'Quand les messages ont un coût et s’ils sont rejetés pour une quelconque raison, les coûts ne sont pas remboursés.',
	'JV_POINTS_HELP_FAQ_GENERAL_POST_REWARD_MOD_QUESTION'	=> 'J’ai posté un nouveau message qui a été rejeté par un modérateur, mais je n’ai pas récupéré le montant du coût, pourquoi ?',

	'JV_POINTS_HELP_FAQ_GENERAL_TRANSFER_ANSWER'			=> 'Cette fonctionnalité n’est pas disponible actuellement.',
	'JV_POINTS_HELP_FAQ_GENERAL_TRANSFER_QUESTION'			=> 'Est-il possible de transférer un certain montant à un autre utilisateur ?',
));
