<?php
/**
*
* @package JV Points System
* @version $Id: points.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JV_POINTS_ADD_USER_EXPLAIN'			=> 'Enter the name of the user whose balance you want to change.',
	'JV_POINTS_AMOUNT'						=> 'Amount',
	'JV_POINTS_AMOUNT_USER_EXPLAIN'			=> 'Enter the amount to which you want to change the user’s balance.',
	'JV_POINTS_ATTACH_DOWNLOAD_NO_POINTS'	=> 'You do not have enough “%s” to download this file.',
	'JV_POINTS_BALANCE'						=> 'Balance',
	'JV_POINTS_CHANGE'						=> 'Change balance',
	'JV_POINTS_CHANGE_TITLE'				=> 'Change user balance',
	'JV_POINTS_CONTROL_PANEL'				=> 'Points system control panel',
	'JV_POINTS_COSTS'						=> 'Costs',
	'JV_POINTS_DISABLED'					=> 'The points system is currently disabled.',
	'JV_POINTS_ERROR_MINUS_VALUE'			=> 'The specified amount must not be a minus value.',
	'JV_POINTS_FAQ'							=> 'FAQ',
	'JV_POINTS_GUIDE'						=> 'Points system guide',
	'JV_POINTS_INFO'						=> 'Information',
	'JV_POINTS_INFO_EXPLAIN'				=> 'Here you can read the current settings, why reward are and what’s costs. Note that the administrator can change these settings at any time.',
	'JV_POINTS_INFO_TITLE'					=> 'General information',
	'JV_POINTS_FAQ_VIEWING'					=> 'Viewing points system guide',
	'JV_POINTS_INFO_VIEWING'				=> 'Viewing points system general information',
	'JV_POINTS_LOGIN_EXPLAIN'				=> 'You must be logged in before you can view the points system control panel.',
	'JV_POINTS_MAIN'						=> 'Overview',
	'JV_POINTS_MAIN_EXPLAIN'				=> 'Hello %s!<br><br>Current balance: %s.',
	'JV_POINTS_MAIN_TITLE'					=> 'Those with the highest balance',
	'JV_POINTS_MODIFY'						=> 'Modify',
	'JV_POINTS_MORE_INFO_HERE'				=> 'More information %sHERE%s.',
	'JV_POINTS_NEW_ATTACH_COST'				=> 'Attachments download cost',
	'JV_POINTS_NEW_ATTACH_COST_EXPLAIN'		=> 'The cost of the download applies to the following file extension: “%s”.',
	'JV_POINTS_NEW_ATTACHS_COST_EXPLAIN'	=> 'The cost of the download applies to the following file extensions: “%s”.',
	'JV_POINTS_NEW_POST_COST'				=> 'Post writing cost',
	'JV_POINTS_NEW_POST_REWARD'				=> 'New post reward',
	'JV_POINTS_NEW_TOPIC_REWARD'			=> 'New topic reward',
	'JV_POINTS_NO_USER'						=> 'Currently each user’s balance is zero.',
	'JV_POINTS_REG_START_BALANCE'			=> 'New registered member starting balance',
	'JV_POINTS_REWARDS'						=> 'Rewards',
	'JV_POINTS_SEPARATOR_DECIMAL'			=> '.',
	'JV_POINTS_SEPARATOR_THOUSANDS'			=> ',',
	'JV_POINTS_USER_CHANGED_SUCCESS'		=> 'The balance of user “%s” was changed successfully.',
	'JV_POINTS_VIEWING'						=> 'Viewing points system control panel',
	'JV_POINTS_WRITE_POST_NO_POINTS'		=> 'You do not have enough “%s” to write a new post.',
));

?>