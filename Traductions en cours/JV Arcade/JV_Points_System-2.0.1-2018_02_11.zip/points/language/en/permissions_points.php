<?php
/**
*
* @package JV Points System
* @version $Id: permissions_points.php 282 2018-02-11 18:28:10Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'ACL_CAT_JV_POINTS'						=> 'Points'
));

// Admin Permissions
$lang = array_merge($lang, array(
	'ACL_A_JV_POINTS'						=> 'Can manage points system',
));

// Mod Permissions
$lang = array_merge($lang, array(
	'ACL_M_JV_POINTS_CHG'					=> 'Can change users balance',
));

// User Permissions
$lang = array_merge($lang, array(
	'ACL_U_JV_POINTS_IGNORE_DOWNLOAD_COST'	=> 'Can ignore download cost',
	'ACL_U_JV_POINTS_IGNORE_POST_COST'		=> 'Can ignore post write cost',
));
