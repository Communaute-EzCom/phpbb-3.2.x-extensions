# JV Points System

## Quick Install
You can install this on the latest release of phpBB 3.2 by following the steps below:

1. Unzip the downloaded release.
2. Copy the 'points' directory in the  (your forum root)/ext/jv/) directory.
3. Navigate in the ACP to 'Customise -> Manage extensions'.
4. Look for 'JV Points System' under the Disabled Extensions list, and click its 'Enable' link.
5. Set up and configure 'JV Points System' by navigating in the ACP to 'Extensions' -> 'JV Points System'.

## Update

1. Unzip the downloaded release.
2. Navigate in the ACP to 'Customise -> Manage extensions'.
3. Look for 'JV Points System' under the Enabled Extensions list, and click its 'Disable' link.
4. Copy the 'points' directory in the  (your forum root)/ext/jv/) directory.
5. Navigate in the ACP to 'Customise -> Manage extensions'.
6. Look for 'JV Points System' under the Disabled Extensions list, and click its 'Enable' link.
7. Set up and configure 'JV Points System' by navigating in the ACP to 'Extensions' -> 'JV Points System'.

## Uninstall

1. Navigate in the ACP to 'Customise -> Extension Management -> Extensions'.
2. Look for 'JV Points System' under the Enabled Extensions list, and click its 'Disable' link.
3. To permanently uninstall, click 'Delete Data' and then delete the '/ext/jv/points' directory.

## Support

https://jv-arcade.com/

## License
[GNU General Public License v2](https://opensource.org/licenses/GPL-2.0)
