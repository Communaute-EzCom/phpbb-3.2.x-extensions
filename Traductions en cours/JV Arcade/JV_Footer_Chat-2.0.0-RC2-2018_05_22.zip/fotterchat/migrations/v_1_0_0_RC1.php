<?php
/**
*
* @package JV Footer Chat
* @version $Id: v_1_0_0_RC1.php 397 2018-05-22 10:18:58Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\fotterchat\migrations;

class v_1_0_0_RC1 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\phpbb\db\migration\data\v310\extensions',
			'\phpbb\db\migration\data\v31x\v316'
		);
	}

	public function update_schema()
	{
		return array(
			'add_tables' => array(
				"{$this->table_prefix}jv_chat" => array(
					'COLUMNS'		=> array(
						'chat_id'		=> array('UINT', NULL, 'auto_increment'),
						'user_id'		=> array('UINT', 0),
						'author_id'		=> array('UINT', 0),
						'author_ip'		=> array('VCHAR:40', ''),
						'chat_msg'		=> array('MTEXT', ''),
						'chat_date'		=> array('TIMESTAMP', 0),
						'chat_bitfield'	=> array('VCHAR:255', ''),
						'chat_uid'		=> array('VCHAR:8', ''),
						'chat_new'		=> array('TINT:1', 0),
						'view_msg'		=> array('TINT:1', 0),
						'chat_delete'	=> array('UINT', 0)
					),
					'PRIMARY_KEY'		=> 'chat_id',
					'KEYS'				=> array(
						'user_id'		=> array('INDEX', 'user_id'),
						'author_id'		=> array('INDEX', 'author_id'),
						'chat_new'		=> array('INDEX', 'chat_new'),
						'view_msg'		=> array('INDEX', 'view_msg'),
						'chat_delete'	=> array('INDEX', 'chat_delete')
					),
				)
			),
			'add_columns' => array(
				"{$this->table_prefix}users" => array(
					'user_jv_chat_options'	=> array('UINT:11', 3),
					'user_jv_chat_data'		=> array('MTEXT', ''),
					'user_online_time'		=> array('UINT:11', 0),
					'user_most_time'		=> array('TIMESTAMP', 0),
				)
			)
		);
	}

	public function revert_schema()
	{
		return array(
			'drop_tables'	=> array("{$this->table_prefix}jv_chat"),
			'drop_columns'	=> array("{$this->table_prefix}users" => array('user_jv_chat_options', 'user_jv_chat_data', 'user_online_time', 'user_most_time'))
		);
	}
}
