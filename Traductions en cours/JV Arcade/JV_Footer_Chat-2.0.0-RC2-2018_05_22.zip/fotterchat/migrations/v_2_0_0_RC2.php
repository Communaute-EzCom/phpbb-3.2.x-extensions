<?php
/**
*
* @package JV Footer Chat
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\fotterchat\migrations;

class v_2_0_0_RC2 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\jv\fotterchat\migrations\v_1_0_0_RC1');
	}

	public function update_schema()
	{
		return array(
			'change_columns' => array("{$this->table_prefix}users" => array('user_jv_chat_data' => array('VCHAR:255', ''))),
		);
	}

	public function update_data()
	{
		$sql = "SELECT role_name
				FROM {$this->table_prefix}acl_roles";
		$result = $this->sql_query($sql);
		$roles = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$roles[] = $row['role_name'];
		}
		$this->db->sql_freeresult($result);

		return array(
			// Add permissions
			array('permission.add', array('u_jv_fotterchat', true)),
			// Set permissions, if it exists the role
			array('if', array(
				(in_array('ROLE_USER_STANDARD', $roles)),
				array('permission.permission_set', array('ROLE_USER_STANDARD', array('u_jv_fotterchat')))
			)),
			array('if', array(
				(in_array('ROLE_USER_LIMITED', $roles)),
				array('permission.permission_set', array('ROLE_USER_LIMITED', array('u_jv_fotterchat')))
			)),
			array('if', array(
				(in_array('ROLE_USER_FULL', $roles)),
				array('permission.permission_set', array('ROLE_USER_FULL', array('u_jv_fotterchat')))
			)),
			array('if', array(
				(in_array('ROLE_USER_NOPM', $roles)),
				array('permission.permission_set', array('ROLE_USER_NOPM', array('u_jv_fotterchat')))
			)),
			array('if', array(
				(in_array('ROLE_USER_NOAVATAR', $roles)),
				array('permission.permission_set', array('ROLE_USER_NOAVATAR', array('u_jv_fotterchat')))
			)),
			array('if', array(
				(in_array('ROLE_USER_NEW_MEMBER', $roles)),
				array('permission.permission_set', array('ROLE_USER_NEW_MEMBER', array('u_jv_fotterchat')))
			)),
		);
	}
}
