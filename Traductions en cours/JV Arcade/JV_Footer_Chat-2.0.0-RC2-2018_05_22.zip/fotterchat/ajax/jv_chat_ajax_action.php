<?php
/**
*
* @package JV Footer Chat
* @version $Id: jv_chat_ajax_action.php 397 2018-05-22 10:18:58Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!isset($_POST['mode']))
{
	exit;
}

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './../../../../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

$user->session_begin(false);
$auth->acl($user->data);
$user->setup();

$error		= false;
$mode		= $request->variable('mode', '');
$message	= utf8_normalize_nfc($request->variable('msg', '', true));
$user_id	= $request->variable('u', 0);

header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . 'GMT');
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Content-type: text/xml; charset=UTF-8');

echo "<" . "?xml version='1.0' encoding='UTF-8' ?" . "><jv_chat>";

if (!$phpbb_container->get('ext.manager')->is_enabled('jv/fotterchat') || !$mode || !$auth->acl_get('u_jv_fotterchat'))
{
	echo "</jv_chat>";

	garbage_collection();
	exit_handler();
}

$jv_chat = $phpbb_container->get('jv.fotterchat.main');
$jv_chat->user_data('data');

if (!$user->data['is_registered'])
{
	$jv_chat->jvc_print('error', 'Login');

	echo "</jv_chat>";

	garbage_collection();
	exit_handler();
}

if (!in_array($mode, array('online', 'online_list')) && !$jv_chat->optionget('online'))
{
	$mode = '';
}

$cset = false;
$chat_table = $phpbb_container->getParameter('jv.fotterchat.chat.table');
switch ($mode)
{
	case 'online':
	case 'sound':
	case 'busy':
		$cset = true;
		$value = ($user_id == 1) ? true : false;
		$jv_chat->optionset($mode, $value);

		$online	= ($jv_chat->optionget('online')) ? 'y' : 'n';
		$sound	= ($jv_chat->optionget('sound')) ? 'y' : 'n';
		$busy	= ($jv_chat->optionget('busy')) ? 'y' : 'n';

		$jv_chat->jvc_print('osb', "$online|$sound|$busy");
	break;

	case 'msg':
		if ($message == '' || !in_array($user_id, $jv_chat->data['msg_uids']))
		{
			break;
		}

		$user->add_lang('posting');

		if (!function_exists('parse_message'))
		{
			include($phpbb_root_path . 'includes/message_parser.' . $phpEx);
		}

		$message_parser = new parse_message($message);
		$message_parser->parse(true, true, true, false, false, false, $config['allow_post_links'], true);

		if (sizeof($message_parser->warn_msg))
		{
			$error = true;
			$jv_chat->jvc_print('error', implode('<br />', $message_parser->warn_msg));
		}
		else
		{
			$sql = 'SELECT user_jv_chat_data
					FROM ' . USERS_TABLE . '
					WHERE user_id = ' . (int) $user_id;
			$result = $db->sql_query($sql);
			$user_jv_chat_data = $db->sql_fetchfield('user_jv_chat_data');
			$db->sql_freeresult($result);

			$open_user	= $jv_chat->user_data('open_user', false, $user_jv_chat_data);
			$upactime	= $jv_chat->user_data('actime', false, $user_jv_chat_data);
			$jv_chat->update_user_data(array('user_jv_chat_data' => $upactime), $user_id);

			$sql_ary = array(
				'user_id'			=> (int) $user_id,
				'author_id'			=> (int) $user->data['user_id'],
				'author_ip'			=> $user->ip,
				'chat_msg'			=> (string) $message_parser->message,
				'chat_date'			=> $jv_chat->data['curtime'],
				'chat_bitfield'		=> (string) $message_parser->bbcode_bitfield,
				'chat_uid'			=> (string) $message_parser->bbcode_uid,
				'chat_new'			=> 1,
				'view_msg'			=> ($open_user == $user->data['user_id']) ? 1 : 0,
				'chat_delete'		=> 0
			);

			$db->sql_query('INSERT INTO ' . $chat_table . ' ' . $db->sql_build_array('INSERT', $sql_ary));

			$jv_chat->jvc_print('msg_dec', $message_parser->format_display(true, true, true, false));
			$jv_chat->jvc_print('msg_time', $user->format_date($jv_chat->data['curtime'], '| G:i'));

			if ($auth->acl_get('a_') || $auth->acl_get('m_'))
			{
				$jv_chat->jvc_print('msg_ip', $user->ip);
			}
		}

		unset($message_parser);
	break;

	case 'load_msg':
		$jv_chat->user_data('user_msg', $user_id);
		$jv_chat->user_data('add_user', $user_id);

		$sql = 'SELECT *
				FROM ' . $chat_table . '
				WHERE ((author_id = ' . (int) $user->data['user_id'] . ' AND user_id = ' . (int) $user_id . ') OR
						(user_id = ' . (int) $user->data['user_id'] . ' AND author_id   = ' . (int) $user_id . '))
				AND chat_delete <> ' . (int) $user->data['user_id'] . '
				ORDER BY chat_id DESC';
		$result = $db->sql_query_limit($sql, 20);

		$msgs = array();
		while ($row = $db->sql_fetchrow($result))
		{
			echo '<msgs>';
				$jv_chat->jvc_print("author", $row['author_id']);
				$jv_chat->jvc_print("msg", generate_text_for_display($row['chat_msg'], $row['chat_uid'], $row['chat_bitfield'], 7));
				$jv_chat->jvc_print("date", $user->format_date($row['chat_date'], '| G:i'));

				if ($auth->acl_get('a_') || $auth->acl_get('m_'))
				{
					$jv_chat->jvc_print("ip", $row['author_ip']);
				}

			echo '</msgs>';
		}
		$db->sql_freeresult($result);
	break;

	case 'view_msg':
		$jv_chat->user_data('user_msg', $user_id);

		$sql = 'UPDATE ' . $chat_table . '
				SET view_msg = 1
				WHERE author_id = ' . (int) $user_id . '
				AND user_id = ' . (int) $user->data['user_id'];
		$db->sql_query($sql);
	break;

	case 'delete_msg':
		$sql = 'SELECT chat_id, chat_delete
				FROM ' . $chat_table . '
				WHERE chat_date < ' . $jv_chat->data['curtime'] . '
				AND ((author_id = ' . (int) $user->data['user_id'] . ' AND user_id = ' . (int) $user_id . ') OR
					(user_id = ' . (int) $user->data['user_id'] . ' AND author_id = ' . (int) $user_id . '))';
		$result = $db->sql_query($sql);
		$delete_ids = $update_ids = array();
		while ($row = $db->sql_fetchrow($result))
		{
			if ($row['chat_delete'] == $user_id)
			{
				$delete_ids[] = $row['chat_id'];
			}
			else
			{
				$update_ids[] = $row['chat_id'];
			}
		}
		$db->sql_freeresult($result);

		if (sizeof($delete_ids))
		{
			$sql = 'DELETE FROM ' . $chat_table . '
					WHERE ' . $db->sql_in_set('chat_id', array_map('intval', $delete_ids));
			$db->sql_query($sql);
		}

		if (sizeof($update_ids))
		{
			$sql = 'UPDATE ' . $chat_table . '
					SET chat_delete = ' . (int) $user->data['user_id'] . '
					WHERE ' . $db->sql_in_set('chat_id', array_map('intval', $update_ids));
			$db->sql_query($sql);
		}
	break;

	case 'close':
		if ($user_id == $jv_chat->data['open_user'])
		{
			$jv_chat->user_data('user_msg');
		}

		$jv_chat->user_data('del_user', $user_id);
	break;

	case 'online_list':
		$user_id = ($user_id == 1) ? 1 : false;
	case 'user_msg':
		$jv_chat->user_data($mode, $user_id);
	break;
}

if (!$error)
{
	$jv_chat->user_data('uplt');

	if ($cset)
	{
		$ud = array(
			'user_jv_chat_options'	=> (int) $user->data['user_jv_chat_options'],
			'user_jv_chat_data'		=> $user->data['user_jv_chat_data']
		);
	}
	else
	{
		$ud = array('user_jv_chat_data' => $user->data['user_jv_chat_data']);
	}

	$jv_chat->update_user_data($ud);
}

$jv_chat->jvc_print('disc', $jv_chat->data['msg_uids_def']);
$jv_chat->jvc_print('lt', $jv_chat->data['lasttime']);

echo "</jv_chat>";
garbage_collection();
exit_handler();

?>