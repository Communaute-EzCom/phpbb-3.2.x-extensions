<?php
/**
*
* @package JV Footer Chat
* @version $Id: jv_chat_ajax.php 397 2018-05-22 10:18:58Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!isset($_POST['mode']))
{
	exit;
}

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './../../../../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

$user->session_begin(false);
$auth->acl($user->data);
$user->setup();

$mode = $request->variable('mode', '');
$uids = array_filter(array_map('intval', explode(',', $request->variable('ids', ''))));

header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . 'GMT');
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Content-type: text/xml; charset=UTF-8');

echo "<" . "?xml version='1.0' encoding='UTF-8' ?" . "><jv_chat>";

if (!$phpbb_container->get('ext.manager')->is_enabled('jv/fotterchat') || !$mode || !$auth->acl_get('u_jv_fotterchat'))
{
	echo "</jv_chat>";

	garbage_collection();
	exit_handler();
}

$jv_chat = $phpbb_container->get('jv.fotterchat.main');
$jv_chat->user_data('data');

if (!$user->data['is_registered'])
{
	$jv_chat->jvc_print('error', 'Login');

	echo "</jv_chat>";

	garbage_collection();
	exit_handler();
}

$chat_auto_block = false;
$sql_ary = array();
$chat_table = $phpbb_container->getParameter('jv.fotterchat.chat.table');

if (!$jv_chat->optionget('online'))
{
	$sql = 'SELECT author_id
			FROM ' . $chat_table . '
			WHERE user_id = ' . (int) $user->data['user_id'] . '
			AND view_msg = 0';
	$result = $db->sql_query_limit($sql, 1);
	$author_id = (int) $db->sql_fetchfield('author_id');
	$db->sql_freeresult($result);

	if ($author_id)
	{
		$chat_auto_block = true;
	}
}

if ($jv_chat->optionget('online') || $chat_auto_block)
{
	switch ($mode)
	{
		case 'start':
		case 'update':
		case 'check':
			if ($mode == 'start' || $mode == 'update' || $jv_chat->data['curtime'] <= ($jv_chat->data['actiontime'] + 5))
			{
				$limit = 0;
				$author = $msgs = $new_msgs = $cnew = array();
				$orig_ids = $jv_chat->data['msg_uids'];

				if ($mode == 'start')
				{
					foreach ($jv_chat->data['msg_uids'] as $uid)
					{
						if ($uid && !array_key_exists($uid, $msgs))
						{
							$msgs[$uid][] = array();
						}
					}

					$where = 'user_id = ' . (int) $user->data['user_id'] . '
								AND chat_delete <> ' . (int) $user->data['user_id'] . '
								AND (' . $db->sql_in_set('author_id', $jv_chat->data['msg_uids'], false, true) . ' OR view_msg = 0)';
				}
				else
				{
					$where = '(chat_new = 1
								AND user_id = ' . (int) $user->data['user_id'] . '
								AND ' . $db->sql_in_set('author_id', $jv_chat->data['msg_uids'], true, true) . ')';
				}

				$sql = 'SELECT author_id, view_msg
						FROM ' . $chat_table . "
						WHERE $where";
				$result = $db->sql_query($sql);
				while ($row = $db->sql_fetchrow($result))
				{
					unset($jv_chat->data['msg_uids'][array_search($row['author_id'], $jv_chat->data['msg_uids'])]);
					$author[$row['author_id']] = (!isset($author[$row['author_id']])) ? 1 : ((!$row['view_msg']) ? $author[$row['author_id']]+1 : $author[$row['author_id']]);
				}
				$db->sql_freeresult($result);

				if (sizeof($author))
				{
					$limit = max(0, array_values($author));
					$limit = $limit[0];

					if ($mode == 'start')
					{
						$jv_chat->data['msg_uids'] = array_unique(array_merge($jv_chat->data['msg_uids'], array_keys($author)));
					}
					else
					{
						$jv_chat->data['msg_uids'] = array_unique(array_keys($author));
					}
				}

				$jv_chat->data['msg_uids'] = array_filter(array_map('intval', $jv_chat->data['msg_uids']));

				$where = '';
				if (($mode == 'start' && sizeof($jv_chat->data['msg_uids'])) || (sizeof($author)))
				{
					$where .= '((' . $db->sql_in_set('author_id', $jv_chat->data['msg_uids']) . ' AND user_id = ' . (int) $user->data['user_id'] . ') OR
								(' . $db->sql_in_set('user_id', $jv_chat->data['msg_uids']) . ' AND author_id = ' . (int) $user->data['user_id'] . '))';
				}

				unset($author);

				if ($mode != 'start')
				{
					if ($where !== '')
					{
						$where .= ' OR ';
					}

					$where .= '(chat_new = 1 AND user_id = ' . (int) $user->data['user_id'] . ')';
				}

				if ($where !== '')
				{
					$sql = 'SELECT *
							FROM ' . $chat_table . '
							WHERE (' . $where . ')
							AND chat_delete <> ' . (int) $user->data['user_id'] . '
							ORDER BY chat_id DESC';
					$result = $db->sql_query($sql);
					$limit = ($limit > 20) ? $limit : 20;
					while ($row = $db->sql_fetchrow($result))
					{
						$user_id = ($user->data['user_id'] == $row['user_id']) ? $row['author_id'] : $row['user_id'];

						if (isset($msgs[$user_id]) && sizeof($msgs[$user_id]) == $limit)
						{
							continue;
						}

						if (($row['chat_new'] > 0 || !$row['view_msg']) && $user->data['user_id'] == $row['user_id'])
						{
							$cnew[$user_id][] = 1;

							if ($row['chat_new'] > 0)
							{
								$new_msgs[] = $row['chat_id'];
							}
						}

						$msgs[$user_id][] = array(
							'author'	=> $row['author_id'],
							'msg'		=> generate_text_for_display($row['chat_msg'], $row['chat_uid'], $row['chat_bitfield'], 7),
							'date'		=> $user->format_date($row['chat_date'], '| G:i'),
							'ip'		=> ($auth->acl_get('a_') || $auth->acl_get('m_')) ? $row['author_ip'] : ''
						);
					}
					$db->sql_freeresult($result);
				}

				if (sizeof($new_msgs))
				{
					if (sizeof($cnew))
					{
						foreach ($cnew as $uid => $NULL)
						{
							$jv_chat->user_data('add_user', $uid);
						}

						$jv_chat->jvc_print('ltdis', 1);
						$jv_chat->user_data('uplt');

						$sql_ary = array('user_jv_chat_data' => $user->data['user_jv_chat_data']);
					}

					$sql = 'UPDATE ' . $chat_table . '
							SET chat_new = 0
							WHERE ' . $db->sql_in_set('chat_id', array_map('intval', $new_msgs));
					$db->sql_query($sql);
				}

				if (sizeof($msgs))
				{
					foreach ($msgs as $user_id => $data)
					{
						echo '<lusers>';
						$jv_chat->jvc_print('user_id', $user_id);

						$jv_chat->jvc_print('cnew', ((!isset($cnew[$user_id])) ? 0 : count($cnew[$user_id])));

						foreach ($data as $row)
						{
							if (!isset($row['date']))
							{
								continue;
							}

							echo '<msgs_' . $user_id . '>';
								if ($row['date'] !== '')
								{
									$jv_chat->jvc_print('author', $row['author']);
									$jv_chat->jvc_print("msg", $row['msg']);
									$jv_chat->jvc_print("date", $row['date']);
								}

								if ($row['ip'] !== '')
								{
									$jv_chat->jvc_print("ip", $row['ip']);
								}

							echo '</msgs_' . $user_id . '>';
						}

						echo '</lusers>';
					}
				}

				if (sizeof($cnew) && $mode != 'start')
				{
					$mode = 'update';
				}

				$sql_in = '';
				$off_ids = array();
				$check_time = ($jv_chat->data['curtime'] - 60);

				if (sizeof($msgs))
				{
					if ($mode != 'start')
					{
						foreach ($orig_ids as $id)
						{
							if (in_array($id, array_keys($msgs)))
							{
								unset($msgs[$id]);
							}
						}
					}

					$off_ids = array_filter(array_map('intval', array_keys($msgs)));

					if (sizeof($off_ids))
					{
						$sql_in = ' OR (' . $db->sql_in_set('u.user_id', $off_ids) . ')';
					}

					unset($msgs);
				}

				if ($mode == 'start')
				{
					$user_name_profile	= get_username_string('full', $user->data['user_id'], $user->data['username'], $user->data['user_colour']);
					$user_avatar		= $jv_chat->user_avatar($user->data);
					$user_name			= ($user->data['user_colour']) ? '<span style="color:#' . $user->data['user_colour'] . '">' . $user->data['username'] . '</span>' : $user->data['username'];
					$user_busy			= ($jv_chat->optionget('busy')) ? 'y' : 'n';

					echo '<users_list>';
						$jv_chat->jvc_print('udis', 'y');
						$jv_chat->jvc_print('userid', $user->data['user_id']);
						$jv_chat->jvc_print('avatar', (($user_avatar) ? $user_avatar : 'no'));
						$jv_chat->jvc_print('name', $user_name);
						$jv_chat->jvc_print('p_name', $user_name_profile);
						$jv_chat->jvc_print('busy', $user_busy);
					echo '</users_list>';
				}

				$sql = 'SELECT u.user_id, u.username, u.username_clean, u.user_colour, u.user_avatar, u.user_avatar_type, u.user_most_time, u.user_options, u.user_jv_chat_options, s.session_viewonline
						FROM ' . USERS_TABLE . ' u
						LEFT JOIN ' . SESSIONS_TABLE . ' s ON u.user_id = s.session_user_id
						WHERE u.user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')
						AND u.user_id <> ' . (int) $user->data['user_id'] . "
						AND ((u.user_id = s.session_user_id AND u.user_most_time > $check_time) $sql_in)
						ORDER BY u.username_clean ASC";
				$result = $db->sql_query($sql);
				$online_users = array();

				while ($row = $db->sql_fetchrow($result))
				{
					$user_disabled = (!$jv_chat->optionget('online', $row['user_jv_chat_options'], true) || (!$row['session_viewonline'] && !$auth->acl_get('u_viewonline'))) ? true : false;

					// admin, moderator view - all online users
					$user_disabled = ($user->data['is_registered'] && $auth->acl_gets('a_', 'm_')) ? false : $user_disabled;

					if ((!empty($online_users[$row['user_id']])) || (!in_array($row['user_id'], $off_ids) && $user_disabled))
					{
						continue;
					}

					$no_add_list = (($row['user_most_time'] < $check_time) || $user_disabled || $chat_auto_block) ? true : false;
					$online_users[$row['user_id']] = ($no_add_list) ? 2 : 1;

					if ($mode == 'start' || ($mode == 'update' && !in_array($row['user_id'], $uids)))
					{
						$user_name_profile	= get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']);
						$user_avatar		= $jv_chat->user_avatar($row);
						$user_name			= ($row['user_colour']) ? '<span style="color:#' . $row['user_colour'] . '">' . $row['username'] . '</span>' : $row['username'];
						$user_name			= (!$no_add_list && !$row['session_viewonline']) ? '<em>' . $user_name . '</em>' : $user_name;
						$user_busy			= ($jv_chat->optionget('busy', $row['user_jv_chat_options'], true)) ? 'y' : 'n';

						echo '<users_list>';
							if ($no_add_list)
							{
								$jv_chat->jvc_print('udis', 'y');
							}

							$jv_chat->jvc_print('userid', $row['user_id']);
							$jv_chat->jvc_print('avatar', (($user_avatar) ? $user_avatar : 'no'));
							$jv_chat->jvc_print('name', $user_name);
							$jv_chat->jvc_print('p_name', $user_name_profile);
							$jv_chat->jvc_print('busy', $user_busy);
						echo '</users_list>';
					}
				}
				$db->sql_freeresult($result);

				foreach ($online_users as $user_id => $value)
				{
					if ($value == 2)
					{
						unset($online_users[$user_id]);
					}
				}

				$online_users = array_filter(array_keys($online_users));

				if (sizeof($online_users))
				{
					$jv_chat->jvc_print('ouids', implode('|', $online_users));
					unset($online_users);
				}

				$jv_chat->jvc_print('disc', $jv_chat->data['msg_uids_def']);
			}
			else
			{
				if (sizeof($uids))
				{
					$jv_chat->jvc_print('ouids', implode('|', $uids));
				}

				$jv_chat->jvc_print('disc', $jv_chat->data['msg_uids_def']);
			}
		break;
	}
}

$user_online_time	= intval($jv_chat->data['curtime'] - $user->data['user_most_time']);
$new_online_time	= intval($user->data['user_online_time'] + $user_online_time);

if (($jv_chat->data['curtime'] - $jv_chat->data['actiontime']) >= 25)
{
	$jv_chat->user_data('upactime');

	$sql_ary = array_merge($sql_ary, array(
		'user_jv_chat_data' => $user->data['user_jv_chat_data']
	));
}

if ($user_online_time > 0 && ($user_online_time < 120))
{
	$sql_ary = array_merge($sql_ary, array(
		'user_online_time' => $new_online_time
	));
}
else
{
	$new_online_time = $user->data['user_online_time'];
}

$sql_ary = array_merge($sql_ary, array(
	'user_most_time' => $jv_chat->data['curtime']
));


$jv_chat->update_user_data($sql_ary);

if (defined('IN_JATEK_VILAG'))
{
	$jv_chat->jvc_print('guot', $arcade->time_format($new_online_time));
}

$online			= ($jv_chat->optionget('online')) ? 'y' : 'n';
$sound			= ($jv_chat->optionget('sound')) ? 'y' : 'n';
$busy			= ($jv_chat->optionget('busy')) ? 'y' : 'n';
$online_list	= ($jv_chat->data['open_list']) ? 'y' : 'n';
$open_user		= ($jv_chat->data['open_user']) ? $jv_chat->data['open_user'] : 'n';

$jv_chat->jvc_print('osb', "$online|$sound|$busy");
$jv_chat->jvc_print('vs', "$online_list|$open_user");
$jv_chat->jvc_print('lt', $jv_chat->data['lasttime']);

echo "</jv_chat>";

garbage_collection();
exit_handler();

?>