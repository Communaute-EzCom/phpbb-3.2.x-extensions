<?php
/**
*
* @package JV Footer Chat
* @version $Id: listener.php 397 2018-05-22 10:18:58Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\fotterchat\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $ext_manager, $path_helper, $db, $auth, $user, $config, $template, $root_path, $php_ext, $chat_table;

	public function __construct($ext_manager, $path_helper, $db, $auth, $user, $config, $template, $root_path, $php_ext, $chat_table)
	{
		$this->ext_manager = $ext_manager;
		$this->path_helper = $path_helper;
		$this->db = $db;
		$this->auth = $auth;
		$this->user = $user;
		$this->config = $config;
		$this->template = $template;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->chat_table = $chat_table;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'			=> 'user_setup',
			'core.user_add_modify_data'	=> 'user_add_data',
			'core.page_footer_after'	=> 'page_footer_after',
			'core.permissions'			=> 'permissions_language',
			'core.delete_user_after'	=> 'delete_user'
		);
	}

	public function user_setup($event)
	{
		$event['lang_set_ext'] = array_merge($event['lang_set_ext'], array(
			array(
				'ext_name' => 'jv/fotterchat',
				'lang_set' => 'jv_chat'
			)
		));
	}

	public function user_add_data($event)
	{
		$event['sql_ary'] = array_merge($event['sql_ary'], array(
			'user_jv_chat_options'	=> 3,
			'user_jv_chat_data'		=> '',
			'user_online_time'		=> 0,
			'user_most_time'		=> 0
		));
	}

	public function page_footer_after()
	{
		if (!empty($this->user->data['is_registered']) && $this->auth->acl_get('u_jv_fotterchat'))
		{
			$root_path_ext = $this->ext_manager->get_extension_path('jv/fotterchat', true);
			$ext_web_path = $this->ext_web_path();

			$this->template->assign_vars(array(
				'S_IN_JV_CHAT'				=> true,
				'S_JV_CHAT_USER_ID'			=> $this->user->data['user_id'],

				'UA_JV_CHAT_AJAX'			=> append_sid("{$root_path_ext}ajax/jv_chat_ajax.{$this->php_ext}"),
				'UA_JV_CHAT_AJAX_ACTION'	=> append_sid("{$root_path_ext}ajax/jv_chat_ajax_action.{$this->php_ext}"),
				'UA_JV_CHAT_LOGIN'			=> append_sid("{$this->root_path}ucp.{$this->php_ext}", "mode=login"),

				'JV_CHAT_COOKIE_SETTINGS'	=> addslashes('; path=' . $this->config['cookie_path'] . ((!$this->config['cookie_domain'] || $this->config['cookie_domain'] == 'localhost' || $this->config['cookie_domain'] == '127.0.0.1') ? '' : '; domain=' . $this->config['cookie_domain']) . ((!$this->config['cookie_secure']) ? '' : '; secure')),
				'JV_CHAT_COOKIE_NAME'		=> $this->config['cookie_name'],

				'L_JV_CHAT_TITLE'			=> sprintf($this->user->lang['JV_CHAT_TITLE'], '<a href="https://jv-arcade.com/">', '</a>'),

				'T_JV_CHAT_SWF_PATH'		=> "{$ext_web_path}swf",
				'T_JV_CHAT_IMAGE_PATH'		=> "{$ext_web_path}styles/all/theme/images"
			));
		}
	}

	public function permissions_language($event)
	{
		$event['permissions'] = array_merge($event['permissions'], array(
			// User Permissions
			'u_jv_fotterchat' => array('lang' => 'ACL_U_JV_FOTTERCHAT' , 'cat' => 'misc')
		));
	}

	public function ext_web_path($ext_name = 'jv/fotterchat')
	{
		$web_path = (defined('PHPBB_USE_BOARD_URL_PATH') && PHPBB_USE_BOARD_URL_PATH) ? generate_board_url() . '/' : $this->path_helper->get_web_root_path();
		return $web_path . $this->ext_manager->get_extension_path($ext_name);
	}

	public function delete_user($event)
	{
		$sql = 'DELETE FROM ' . $this->chat_table . '
				WHERE ' . $this->db->sql_in_set('user_id', array_map('intval', $event['user_ids']));
		$this->db->sql_query($sql);
	}
}
