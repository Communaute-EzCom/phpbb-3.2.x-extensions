<?php
/**
*
* @package JV Footer Chat
* @version $Id: jv_chat.php 397 2018-05-22 10:18:58Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\fotterchat\core;

class jv_chat
{
	public $data = array();
	public $keyoptions = array('online' => 0, 'sound' => 1, 'busy' => 2);

	protected $path_helper, $db, $user, $root_path;

	public function __construct($path_helper, $db, $user, $root_path)
	{
		$this->path_helper = $path_helper;
		$this->db = $db;
		$this->user = $user;
		$this->root_path = $root_path;
	}

	public function optionget($key, $data = false, $other = false)
	{
		$var = ($other) ? $data : $this->user->data['user_jv_chat_options'];
		return ($var & 1 << $this->keyoptions[$key]) ? true : false;
	}

	public function optionset($key, $value, $data = false, $other = false)
	{
		$var = ($other) ? $data : $this->user->data['user_jv_chat_options'];

		if ($value && !($var & 1 << $this->keyoptions[$key]))
		{
			$var += 1 << $this->keyoptions[$key];
		}
		else if (!$value && ($var & 1 << $this->keyoptions[$key]))
		{
			$var -= 1 << $this->keyoptions[$key];
		}
		else
		{
			return ($other) ? $var : false;
		}

		if (!$other)
		{
			$this->user->data['user_jv_chat_options'] = $var;
			return true;
		}
		else
		{
			return $var;
		}
	}

	public function user_data($mode, $value = false, $data = false)
	{
		if ($data === false)
		{
			$data = $this->user->data['user_jv_chat_data'];
		}

		if ($data !== '')
		{
			$ud			= explode(':', $data);
			$user_ids	= array_filter((isset($ud[0])) ? array_map('intval', explode('|', $ud[0])) : array());
			$open_user	= (isset($ud[1])) ? (int) $ud[1] : 0;
			$open_list	= (isset($ud[2])) ? (int) $ud[2] : 0;
			$lasttime	= (isset($ud[3])) ? (int) $ud[3] : 0;
			$actiontime	= (isset($ud[4])) ? (int) $ud[4] : 0;
		}
		else
		{
			$user_ids	= array();
			$open_user	= 0;
			$open_list	= 0;
			$lasttime	= 0;
			$actiontime	= 0;
		}

		$vd = '';

		switch ($mode)
		{
			case 'data':
				$this->data = array(
					'msg_uids'		=> $user_ids,
					'msg_uids_def'	=> (sizeof($user_ids)) ? implode('|', $user_ids) : 0,
					'open_user'		=> $open_user,
					'open_list'		=> $open_list,
					'lasttime'		=> $lasttime,
					'curtime'		=> time(),
					'actiontime'	=> $actiontime
				);

				return;
			break;

			case 'open_user':
				return $open_user;
			break;

			case 'actime':
				$vd .= ((sizeof($user_ids)) ? implode('|', $user_ids) : '') . ":$open_user:$open_list:$lasttime:" . $this->data['curtime'];
				return $vd;
			break;

			case 'add_user':
				if ($value > 0 && !in_array($value, $user_ids))
				{
					$vd .= ((sizeof($user_ids)) ? implode('|', $user_ids) . "|$value" : $value) . ":$open_user:$open_list:$lasttime:$actiontime";
				}
				else
				{
					$vd .= $data;
				}
			break;

			case 'del_user':
				foreach ($user_ids as $id)
				{
					if ($id && $id != $value)
					{
						$vd .= ($vd == '') ? $id : "|$id";
					}
				}
				$vd .= ":$open_user:$open_list:$lasttime:$actiontime";
			break;

			case 'user_msg':
				$value = ($value) ? $value : 0;
				$vd .= ((sizeof($user_ids)) ? implode('|', $user_ids) : '') . ":$value:$open_list:$lasttime:$actiontime";
			break;

			case 'online_list':
				$value = ($value) ? $value : 0;
				$vd .= ((sizeof($user_ids)) ? implode('|', $user_ids) : '') . ":$open_user:$value:$lasttime:$actiontime";
			break;

			case 'uplt':
				$vd .= ((sizeof($user_ids)) ? implode('|', $user_ids) : '') . ":$open_user:$open_list:" . $this->data['curtime'] . ":$actiontime";
			break;

			case 'upactime':
				$vd .= ((sizeof($user_ids)) ? implode('|', $user_ids) : '') . ":$open_user:$open_list:$lasttime:" . $this->data['curtime'];
			break;
		}

		$this->user->data['user_jv_chat_data'] = $vd;
		$this->user_data('data');
	}

	public function update_user_data($sql_ary, $user_id = false)
	{
		if (!$user_id)
		{
			$user_id = $this->user->data['user_id'];
		}

		$sql = 'UPDATE ' . USERS_TABLE . '
				SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
				WHERE user_id = ' . (int) $user_id;
		$this->db->sql_query($sql);
	}

	public function user_avatar($data)
	{
		$user_avatar = $no_avatar = false;

		if ($this->user->optionget('viewavatars', $this->user->data['user_options']))
		{
			$user_row = array(
				'user_avatar'			=> $data['user_avatar'],
				'user_avatar_type'		=> $data['user_avatar_type'],
				'user_avatar_width'		=> 20,
				'user_avatar_height'	=> 20
			);

			$user_avatar = phpbb_get_user_avatar($user_row);

			if (!$user_avatar)
			{
				$no_avatar_user_path = $this->root_path . 'styles/' . rawurlencode($this->user->style['style_path']) . '/theme/images/no_avatar.gif';
				$no_avatar_all_path = $this->root_path . 'styles/all/theme/images/no_avatar.gif';
				$no_avatar_prosilver_path = $this->root_path . 'styles/prosilver/theme/images/no_avatar.gif';

				if (file_exists($no_avatar_user_path))
				{
					$no_avatar = $no_avatar_user_path;
				}
				else if (file_exists($no_avatar_all_path))
				{
					$no_avatar = $no_avatar_all_path;
				}
				else if ($no_avatar_user_path != $no_avatar_prosilver_path && file_exists($no_avatar_prosilver_path))
				{
					$no_avatar = $no_avatar_prosilver_path;
				}

				if ($no_avatar)
				{
					$user_avatar = '<img class="avatar" width="20" height="20" src="' . str_replace($this->root_path, $this->web_path(), $no_avatar) . '" alt="" />';
				}
			}
		}

		return $user_avatar;
	}

	public function web_path()
	{
		return (defined('PHPBB_USE_BOARD_URL_PATH') && PHPBB_USE_BOARD_URL_PATH) ? generate_board_url() . '/' : $this->path_helper->get_web_root_path();
	}

	public function jvc_print($xml, $value)
	{
		echo '<'.$xml.'>'. $this->xml($value) .'</'.$xml.'>';
	}

	private function xml($contents)
	{
		$contents = str_replace('&nbsp;', '', $contents);

		if ( preg_match('/\<(.*?)\>/xsi', $contents) )
		{
			$contents = preg_replace('/\<script[\s]+(.*)\>(.*)\<\/script\>/xsi', '', $contents);
		}

		if (!(strpos($contents, '>') === false) || !(strpos($contents, '<') === false) || !(strpos($contents, '&') === false))
		{
			if (!(strpos($contents, ']]>') === false))
			{
				return htmlspecialchars($contents);
			}
			else
			{
				return '<![CDATA[' . $contents . ']]>';
			}
		}
		else
		{
			return htmlspecialchars($contents);
		}

		return $contents;
	}
}

?>