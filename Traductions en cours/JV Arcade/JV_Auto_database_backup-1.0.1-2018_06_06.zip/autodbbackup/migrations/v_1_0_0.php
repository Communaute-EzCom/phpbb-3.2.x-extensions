<?php
/**
*
* @package JV Auto database backup
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\autodbbackup\migrations;

class v_1_0_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v32x\v322');
	}

	public function update_data()
	{
		return array(
			array('config.add', array('jv_autodbbackup_enable', 1)),
			array('config.add', array('jv_autodbbackup_days', 1)),
			array('config.add', array('jv_autodbbackup_last_gc', 0, true)),
			array('config.add', array('jv_autodbbackup_format', 'text')),
			array('config.add', array('jv_autodbbackup_optimize', 0)),

			array('module.add', array(
				'acp', 'ACP_CAT_DATABASE', array(
					'module_basename'	=> '\jv\autodbbackup\acp\autodbbackup_module',
					'modes'				=> array('settings')
				)
			))
		);
	}
}
