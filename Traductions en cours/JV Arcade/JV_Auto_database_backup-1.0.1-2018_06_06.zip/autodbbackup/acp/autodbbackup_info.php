<?php
/**
*
* @package JV Auto database backup
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\autodbbackup\acp;

class autodbbackup_info
{
	function module()
	{
		return array(
			'filename'	=> '\jv\autodbbackup\acp\autodbbackup_module',
			'title'		=> 'ACP_CAT_JV_AUTO_DATABASE',
			'modes'		=> array(
				'settings' => array('title' => 'ACP_CAT_JV_AUTO_DATABASE_SETTINGS', 'auth' => 'ext_jv/autodbbackup && acl_a_backup', 'cat' => array('ACP_CAT_DATABASE'), 'after' => 'ACP_BACKUP'),
			),
		);
	}
}
