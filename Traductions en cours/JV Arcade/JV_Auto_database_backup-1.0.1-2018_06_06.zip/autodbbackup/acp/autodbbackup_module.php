<?php
/**
*
* @package JV Auto database backup
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\autodbbackup\acp;

class autodbbackup_module
{
	public $u_action;
	public $tpl_name;
	public $page_title;

	protected $config, $user, $request, $template, $log;

	public function __construct()
	{
		global $config, $user, $request, $template, $phpbb_log;

		$this->config = $config;
		$this->user = $user;
		$this->request = $request;
		$this->template = $template;
		$this->log = $phpbb_log;
	}

	public function main($id, $mode)
	{
		$error = array();
		$submit = $this->request->is_set_post('submit');

		switch ($mode)
		{
			case 'settings':
				$this->user->add_lang('acp/database');

				$form_key = 'acp_board';
				add_form_key($form_key);

				$this->config['jv_autodbbackup_gc'] = $this->config['jv_autodbbackup_gc'] / 86400;

				$this->new_config = clone $this->config;
				$cfg_array = (isset($_REQUEST['config'])) ? $this->request->variable('config', array('' => ''), true) : $this->new_config;

				switch ($mode)
				{
					case 'settings':
						$display_vars = array(
							'title'	=> 'ACP_CAT_JV_AUTO_DATABASE_SETTINGS',
							'vars'	=> array(
								'legend1'					=> 'ACP_CAT_JV_AUTO_DATABASE_SETTINGS',
								'jv_autodbbackup_enable'	=> array('lang' => 'ACP_CAT_JV_AUTO_DATABASE',		'validate' => 'bool',		'type' => 'radio:enabled:disabled',	'explain' => false),
								'jv_autodbbackup_gc'		=> array('lang' => 'ACP_JV_AUTO_DATABASE_DAYS',		'validate' => 'int:1:30',	'type' => 'number:1:30',			'explain' => true,	'append' => ' ' . $this->user->lang['DAYS']),
								'jv_autodbbackup_format'	=> array('lang' => 'FILE_TYPE',						'validate' => 'string',		'type' => 'select',					'explain' => false,	'method' => 'autodbbackup_format'),
								'jv_autodbbackup_optimize'	=> array('lang' => 'ACP_JV_AUTO_DATABASE_OPTIMIZE',	'validate' => 'bool',		'type' => 'radio:enabled:disabled',	'explain' => true),

								'legend2'					=> 'ACP_SUBMIT_CHANGES'
							)
						);
					break;

					default:
						trigger_error('NO_MODE', E_USER_ERROR);
					break;
				}

				if (isset($display_vars['lang']))
				{
					$this->user->add_lang($display_vars['lang']);
				}

				validate_config_vars($display_vars['vars'], $cfg_array, $error);

				if ($submit && !check_form_key($form_key))
				{
					$error[] = $this->user->lang['FORM_INVALID'];
				}

				if (count($error))
				{
					$submit = false;
				}

				foreach ($display_vars['vars'] as $config_name => $data)
				{
					if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
					{
						continue;
					}

					$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

					if ($submit)
					{
						if ($config_name == 'jv_autodbbackup_gc')
						{
							$config_value = intval($config_value * 86400);
						}

						$this->config->set($config_name, $config_value);
					}
				}

				if ($submit)
				{
					$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_JV_AUTO_DB_BACKUP_SETTINGS');
					trigger_error($this->user->lang('CONFIG_UPDATED') . adm_back_link($this->u_action), E_USER_NOTICE);
				}

				$this->tpl_name = 'acp_board';
				$this->page_title = $display_vars['title'];

				$this->template->assign_vars(array(
					'L_TITLE'			=> $this->user->lang[$display_vars['title']],
					'L_TITLE_EXPLAIN'	=> $this->user->lang[$display_vars['title'] . '_EXPLAIN'],

					'S_ERROR'			=> (count($error)) ? true : false,
					'ERROR_MSG'			=> implode('<br>', $error),

					'U_ACTION'			=> $this->u_action
				));

				foreach ($display_vars['vars'] as $config_key => $vars)
				{
					if (!is_array($vars) && strpos($config_key, 'legend') === false)
					{
						continue;
					}

					if (strpos($config_key, 'legend') !== false)
					{
						$this->template->assign_block_vars('options', array(
							'S_LEGEND'	=> true,
							'LEGEND'	=> (isset($this->user->lang[$vars])) ? $this->user->lang[$vars] : $vars
						));

						continue;
					}

					$type = explode(':', $vars['type']);

					$l_explain = '';
					if ($vars['explain'] && isset($vars['lang_explain']))
					{
						$l_explain = (isset($this->user->lang[$vars['lang_explain']])) ? $this->user->lang[$vars['lang_explain']] : $vars['lang_explain'];
					}
					else if ($vars['explain'])
					{
						$l_explain = (isset($this->user->lang[$vars['lang'] . '_EXPLAIN'])) ? $this->user->lang[$vars['lang'] . '_EXPLAIN'] : '';
					}

					$content = build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars);

					if (empty($content))
					{
						continue;
					}

					$this->template->assign_block_vars('options', array(
						'KEY'			=> $config_key,
						'TITLE'			=> (isset($this->user->lang[$vars['lang']])) ? $this->user->lang[$vars['lang']] : $vars['lang'],
						'S_EXPLAIN'		=> $vars['explain'],
						'TITLE_EXPLAIN'	=> $l_explain,
						'CONTENT'		=> $content
					));

					unset($display_vars['vars'][$config_key]);
				}
			break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
			break;
		}
	}

	public function autodbbackup_format($value)
	{
		$option = '';
		$available_methods = array('gzip' => 'zlib', 'bzip2' => 'bz2');

		foreach ($available_methods as $type => $module)
		{
			if (!@extension_loaded($module))
			{
				continue;
			}

			$option .= '<option value="' . $type . '"'  . (($value == $type)  ? ' selected="selected"' : '') . '>' . $type . '</option>';
		}

		return $option . '<option value="text"'  . (($value == 'text')  ? ' selected="selected"' : '') . '>text</option>';
	}
}
