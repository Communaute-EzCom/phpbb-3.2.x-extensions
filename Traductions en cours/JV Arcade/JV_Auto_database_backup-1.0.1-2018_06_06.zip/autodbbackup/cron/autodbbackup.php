<?php
/**
*
* @package JV Auto database backup
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\autodbbackup\cron;

class autodbbackup extends \phpbb\cron\task\base
{
	protected $db, $user, $config, $log, $db_tools, $extractor, $table_prefix, $root_path, $php_ext;

	public function __construct($db, $user, $config, $log, $db_tools, $extractor, $table_prefix, $root_path, $php_ext)
	{
		$this->db			= $db;
		$this->user			= $user;
		$this->config		= $config;
		$this->log			= $log;
		$this->db_tools		= $db_tools;
		$this->extractor	= $extractor;
		$this->table_prefix	= $table_prefix;
		$this->root_path	= $root_path;
		$this->php_ext		= $php_ext;
	}

	public function run()
	{
		if (!function_exists('get_usable_memory'))
		{
			include($this->root_path . 'includes/acp/acp_database.' . $this->php_ext);
		}

		if ($this->config['jv_autodbbackup_optimize'])
		{
			switch ($this->db->get_sql_layer())
			{
				case 'mysql':
				case 'mysql4':
				case 'mysqli':
					$opt_tables = array();

					$tables = $this->db->sql_query('SHOW TABLE STATUS');
					while ($table = $this->db->sql_fetchrow($tables))
					{
						$engine = strtolower(!empty($table['Type']) ? $table['Type'] : $table['Engine']);

						// Data free should always be 0 for InnoDB tables
						if ($engine === 'innodb')
						{
							$table['Data_free'] = 0;
						}

						if ($table['Data_free'])
						{
							$opt_tables[] = $table['Name'];
						}
					}
					$this->db->sql_freeresult($tables);

					if (count($opt_tables))
					{
						$opt_tables = implode(', ', $opt_tables);
						$this->db->sql_query('OPTIMIZE TABLE ' . $opt_tables);
					}
				break;
			}
		}

		@set_time_limit(1200);
		@set_time_limit(0);

		$time		= time();
		$format		= $this->config['jv_autodbbackup_format'];
		$filename	= 'backup_' . $time . '_' . unique_id();
		$tables		= $this->db_tools->sql_list_tables();

		$this->extractor->init_extractor($format, $filename, $time, false, true);

		$this->extractor->write_start($this->table_prefix);
		foreach ($tables as $table_name)
		{
			$this->extractor->write_table($table_name);
			$this->extractor->write_data($table_name);
		}
		$this->extractor->write_end();

		$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_JV_AUTO_DB_' . ((!empty($opt_tables)) ? 'OPTIMIZE_BACKUP' : 'BACKUP'));

		$this->config->set('jv_autodbbackup_last_gc', $time, false);
	}

	public function is_runnable()
	{
		return !empty($this->config['jv_autodbbackup_gc']) && $this->config['jv_autodbbackup_enable'];
	}

	public function should_run()
	{
		return (int) $this->config['jv_autodbbackup_last_gc'] < time() - $this->config['jv_autodbbackup_gc'];
	}
}
