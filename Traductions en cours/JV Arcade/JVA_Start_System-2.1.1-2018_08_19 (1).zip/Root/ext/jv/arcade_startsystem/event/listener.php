<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

namespace jv\arcade_startsystem\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	private $localhost;
	protected $container, $config, $user, $auth, $template, $request, $ext, $arcade, $arcade_config, $root_path, $php_ext, $admin_path;

	public function __construct($container, $ext_manager, $config, $user, $auth, $template, $request, $ext, $root_path, $php_ext, $adm_relative_path)
	{
		$this->config = $config;
		$this->user = $user;
		$this->auth = $auth;
		$this->template = $template;
		$this->request = $request;
		$this->ext = $ext;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->admin_path = $root_path . $adm_relative_path;

		if ($ext_manager->is_available('jv/arcade') && $ext_manager->is_enabled('jv/arcade'))
		{
			$this->container = $container;
			$this->arcade = $container->get('jv.arcade.' . (($this->auth_activation()) ? 'admin' : 'arcade'));
			$this->arcade_config = $container->get('jv.arcade.config');
			$this->localhost = $this->arcade->localhost();
		}
	}

	static public function getSubscribedEvents()
	{
		return array(
			'jv.arcade.auth_check'				=> 'auth_check',
			'jv.arcade.acp_main_before'			=> 'acp_main',
			'jv.arcade.play_game_tpl_before'	=> 'play_game_tpl',
			'jv.arcade.header_tpl'				=> 'header_tpl'
		);
	}

	public function auth_check($event)
	{
		$error_version = (!defined('ARCADE_MIN_JVA_START_SYSTEM') || phpbb_version_compare($this->ext->version, ARCADE_MIN_JVA_START_SYSTEM, '<'));

		if (defined('IN_ADMIN'))
		{
			$this->user->add_lang_ext('jv/arcade_startsystem', 'acp_main');

			if ($this->auth_activation() && $this->request->variable('diff', false) && $this->arcade_config['activation_key'])
			{
				$this->arcade_config->set('activation_key', '');
			}

			if ($error_version)
			{
				$msg = ($this->auth_activation()) ? sprintf($this->user->lang['JVA_SS_NOT_COMPATIBLE'], '<a onclick="window.open(this.href); return false;" href="' . $this->arcade_config['support_domain'] . 'Downloads.html">', '</a>') : 'ACP_ARCADE_NOT_FOUND_JVA_START_SYSTEM_INFO';
				trigger_error($msg, E_USER_WARNING);
			}
			else if (!$this->localhost && !$this->arcade_config['activation_key'] && ($event['arcade_page'] != 'acp_main' || !$this->auth_activation()))
			{
				$this->user->add_lang_ext('jv/arcade_startsystem', 'acp_main');
				trigger_error('JVA_SS_NOT_ACTIVATED' . (($this->auth_activation()) ? '' : '_INFO'), E_USER_WARNING);
			}

			if (!$this->request->variable('new_activation_key', false) && ($this->arcade_config['activation_key'] || $this->localhost))
			{
				$this->template->assign_var('S_JVA_START_SYSTEM_ACTIVATED', true);
			}
		}
		else
		{
			if ($error_version)
			{
				trigger_error('NOT_AUTHORISED');
			}
		}
	}

	public function acp_main($event)
	{
		if ($event['mode'] == 'main' && ($this->auth_activation() || $event['action'] == 's_jva_start_system_desc'))
		{
			if ($this->request->is_set('new_activation_key'))
			{
				$event['action'] = '';
			}
			else if ($this->request->variable('remove_personal_data', false) && confirm_box(true))
			{
				$event['action'] = 'remove_personal_data';
			}
			else if ($this->arcade->is_set_get('hide_activation'))
			{
				$hide_activation = ($this->request->variable('hide_activation', false)) ? 1 : 0;
				$this->arcade_config->set('activation_hide', $hide_activation);
				$this->arcade_config['activation_hide'] = $hide_activation;
			}

			if ($event['action'])
			{
				switch($event['action'])
				{
					case 'activation':
						if (!$this->arcade->is_post_empty('data_confirm'))
						{
							redirect(append_sid("{$this->admin_path}index.{$this->php_ext}", 'i=acp_extensions&amp;mode=main&amp;action=disable_pre&amp;ext_name=jv%2Farcade_startsystem'));
						}

						$msg = $this->request->variable('msg', '');
						$rkey = $this->request->variable('rkey', '');
						$extime = $this->request->variable('extime', '');

						switch ($msg)
						{
							case 'ok':
								// Attention! The manual database manipulation is not worth anything! The key plays only a secondary role.
								$this->start_system_activate($rkey, $extime);

								trigger_error($this->user->lang['JVA_SS_ACTIVATION_SUCCESS'] . adm_back_link($event['u_action']), E_USER_NOTICE);
							break;

							case 'active':
								$msg = $this->user->lang['JVA_SS_ACTIVATION_KEY_ALREADY'];

								if (!$this->arcade_config['activation_key'])
								{
									$activation_time = (!$this->arcade_config['activation_start']) ? true : false;
									$this->start_system_activate($rkey, $extime, $activation_time);
								}
							break;

							case 'invalid':
								$msg = $this->user->lang['JVA_SS_ACTIVATION_KEY_INVALID'];
							break;

							case 'version':
								$msg = $this->user->lang['JVA_SS_ACTIVATION_KEY_INVALID_VERSION'];
							break;

							case 'blocked':
								$msg = sprintf($this->user->lang['JVA_SS_ACTIVATION_BLOCKED'], '<a href="mailto:support@jv-arcade.com">', '</a>');
							break;

							case 'no_connection':
								$msg = sprintf($this->user->lang['JVA_SS_SITE_NOT_AVAILABLE'], $this->arcade_config['connect_domain'], '<a href="' . $event['u_action'] . '&amp;action=temp_activation' . '">', '</a>');
							break;

							default:
								$msg = $this->user->lang['JVA_SS_ACTIVATION_INVALID'];
						}

						trigger_error($msg . adm_back_link($event['u_action']), E_USER_WARNING);
					break;

					case 'temp_activation':
						if (!$this->arcade_config['activation_key'])
						{
							$this->start_system_activate();
							trigger_error($this->user->lang['JVA_SS_ACTIVATION_SUCCESS'] . adm_back_link($event['u_action']), E_USER_NOTICE);
						}

						trigger_error($this->user->lang['JVA_SS_ACTIVATION_KEY_ALREADY'] . adm_back_link($event['u_action']), E_USER_WARNING);
					break;

					case 'view_personal_data':
						$event['mode_title_disable'] = true;
						$event['page_title'] = 'JVA_SS_VIEW_PERSONAL_DATA';

						$error = $this->request->variable('error', '');
						$status = $this->request->variable('status', '');

						if ($error == 'deny' || $this->user->data['user_id'] != $this->arcade_config['activation_user_id'])
						{
							trigger_error($this->user->lang['JVA_SS_NO_PERMISSION_VIEW_PERSONAL_DATA'] . adm_back_link($event['u_action']), E_USER_WARNING);
						}

						if ($error)
						{
							$error = ($error == 'no_connection') ? $this->user->lang('JVA_SS_WEBSITE_NO_CONNECTION', $this->arcade_config['connect_domain']) : $this->user->lang('JVA_SS_WEBSITE_ERROR_CONNECTION', $status, $error);
							trigger_error($error . adm_back_link($event['u_action']), E_USER_WARNING);
						}

						$pd = array(
							'web_registered'		=> $this->request->variable('web_registered', false),
							'web_url'				=> $this->request->variable('web_url', ''),
							'jva_ss_id'				=> $this->request->variable('jva_ss_id', ''),
							'web_active'			=> $this->request->variable('web_active', false),
							'install_time'			=> $this->request->variable('install_time', 0),
							'update_time'			=> $this->request->variable('update_time', 0),
							'web_first_play_time'	=> $this->request->variable('web_first_play_time', 0),
							'web_last_play_time'	=> $this->request->variable('web_last_play_time', 0),
							'web_plays'				=> $this->request->variable('web_plays', 0),
							'skip_time'				=> $this->request->variable('skip_time', 0),
							'phpbb_version'			=> $this->request->variable('phpbb_version', ''),
							'arcade_version'		=> $this->request->variable('arcade_version', ''),
							'web_admin'				=> $this->request->variable('web_admin', '', true),
							'web_admin_email'		=> $this->request->variable('web_admin_email', ''),
							'web_admin_ip'			=> $this->request->variable('web_admin_ip', ''),
							'web_key'				=> $this->request->variable('web_key', ''),
							'web_key_version'		=> $this->request->variable('web_key_version', ''),
							'web_key_exp_time'		=> $this->request->variable('web_key_exp_time', 0),
							'ar_display'			=> $this->request->variable('ar_display', false),
							'err'					=> $this->request->variable('err', '', true),
							'action'				=> $event['action']
						);

						$gen_pd = array(
							'JVA_SS_WEB_ADDRESS'		=> $pd['web_url'],
							'JVA_SS_ID'					=> $pd['jva_ss_id'],
							'JVA_SS_WEB_STATUS'			=> $this->user->lang[(($pd['web_active']) ? '' : 'IN') . 'ACTIVE'],
							'JVA_SS_INSTALL_DATE'		=> ($pd['install_time']) ? $this->user->format_date($pd['install_time']) : '-',
							'JVA_SS_UPDATE_DATE'		=> ($pd['update_time']) ? $this->user->format_date($pd['update_time']) : '-',
							'JVA_SS_FIRST_PLAY_DATE'	=> ($pd['web_first_play_time']) ? $this->user->format_date($pd['web_first_play_time']) : '-',
							'JVA_SS_LAST_PLAY_DATE'		=> ($pd['web_last_play_time']) ? $this->user->format_date($pd['web_last_play_time']) : '-',
							'JVA_SS_PLAY_NUM'			=> $pd['web_plays'],
							'JVA_SS_SKIP_TIME'			=> $pd['skip_time'],
							'JVA_SS_PHPBB_VERSION'		=> $pd['phpbb_version'],
							'JVA_SS_ARCADE_VERSION'		=> $pd['arcade_version'],
							'JVA_SS_USERNAME'			=> $pd['web_admin'],
							'JVA_SS_USER_EMAIL'			=> $pd['web_admin_email'],
							'JVA_SS_USER_IP'			=> $pd['web_admin_ip'],
							'JVA_SS_ACT_KEY'			=> $pd['web_key'],
							'JVA_SS_ACT_KEY_VERSION'	=> ($pd['web_key_version']) ? $pd['web_key_version'] : $this->user->lang['ARCADE_NONE'],
							'JVA_SS_ACT_KEY_EXP_DATE'	=> ($pd['web_key_exp_time']) ? $this->user->format_date($pd['web_key_exp_time']) : $this->user->lang['ARCADE_NONE'],
							'JVA_SS_USE_AR_RANK'		=> $this->user->lang[(($pd['ar_display']) ? 'YES' : 'NO')],
							'JVA_SS_ERROR_INFO'			=> ($pd['err']) ? $pd['err'] : '-'
						);

						$this->template->assign_vars($gen_pd + array(
							'S_JVA_START_SYSTEM'			=> true,
							'S_JVA_PERSONAL_DATA'			=> true,
							'S_JVA_START_SYSTEM_ACTIVATED'	=> false,
							'S_JVA_WEB_REGISTERED'			=> $pd['web_registered'],
							'S_JVA_WEB_ACTIVE'				=> $pd['web_active'],
							'S_HIDDEN_FIELDS'				=> build_hidden_fields($pd),
							'S_JVA_SS_BACK'					=> $this->back_link($event['u_action'], true, false),
							'S_JVA_SS_ID'					=> $this->arcade_config['jva_start_system_id'],
							'S_USERNAME'					=> $this->user->data['username'],
							'S_LANG_KEY'					=> $this->user->data['user_lang'],

							'U_JVA_BOARD_URL'				=> generate_board_url(),
							'U_START_SYSTEM_ACTIVATION'		=> $this->arcade_config['connect_domain'] . 'jva_start_system.php',

							'L_ARCADE_TITLE'				=> $this->user->lang[$event['page_title']],
							'L_ARCADE_TITLE_EXPLAIN'		=> $this->user->lang($event['page_title'] . '_EXPLAIN', $this->jva_web_host($this->arcade_config['connect_domain']), $this->jva_web_host($this->arcade_config['support_domain'])),

							'JVA_WEB_REGISTERED'			=> $this->user->lang['JVA_SS_' . (($pd['web_registered']) ? '' : 'UN') . 'REGISTERED']
						));

						if ($this->arcade->is_post_empty('download_personal_data'))
						{
							$this->download_personal_data($gen_pd);
						}

						if ($this->arcade->is_post_empty('remove_personal_data'))
						{
							if (!confirm_box(true))
							{
								$s_hidden_fields = array(
									'remove_personal_data'	=> 1,
									'type'					=> 'remove_personal_data',
									'web_url'				=> generate_board_url(),
									'jva_ss_id'				=> $this->arcade_config['jva_start_system_id'],
									'username'				=> $this->user->data['username'],
									'lang_key'				=> $this->user->data['user_lang']
								);

								confirm_box(false, 'JVA_SS_REMOVE_PERSONAL', build_hidden_fields($s_hidden_fields), '@jv_arcade_startsystem/confirm_body.html');
							}
						}
					break;

					case 'remove_personal_data':
						if ($this->request->variable('reply', '') == 'all_data_remove_success')
						{
							$this->arcade_config->set('activation_key', '');
							$this->arcade_config->set('activation_end', 0);
							$this->arcade_config->set('activation_start', 0);

							trigger_error($this->user->lang('JVA_SS_REMOVE_PERSONAL_DATA_SUCCESS', $this->jva_web_host($this->arcade_config['connect_domain'])) . adm_back_link($event['u_action']), E_USER_NOTICE);
						}
						else
						{
							trigger_error($this->user->lang['JVA_SS_REMOVE_PERSONAL_DATA_ERROR'] . adm_back_link($event['u_action']), E_USER_WARNING);
						}
					break;

					case 'jva_start_system_desc':
					case 's_jva_start_system_desc':
						$event['mode_title_disable'] = true;
						$this->user->add_lang_ext('jv/arcade_startsystem', 'jva_start_system');
						$event['page_title'] = 'ACP_JVA_START_SYSTEM_INSTRUCTION';

						$url_licens = $this->arcade_config['support_domain'] . 'License.html';
						$url_ar_rank = $this->arcade_config['support_domain'] . 'phpBB_Arcade_Activity_Rank.html';

						$this->template->assign_vars(array(
							'S_ARCADE_USE_ONLY_DESC'	=> true,
							'S_JVA_START_SYSTEM_DESC'	=> true,
							'L_ARCADE_TITLE'			=> $this->user->lang[$event['page_title']],
							'L_ARCADE_TITLE_EXPLAIN'	=> $this->user->lang('ACP_JVA_START_SYSTEM_INSTRUCTION_EXPLAIN', $this->jva_web_host($this->arcade_config['support_domain']), $this->arcade_config['support_domain'], $url_licens) . '</p><fieldset class="jvss">' . $this->user->lang('ACP_JVA_START_SYSTEM_EXPLAIN', $this->jva_web_host($this->arcade_config['connect_domain']), $this->jva_web_host($this->arcade_config['support_domain']), $this->arcade_config['support_domain'], $url_licens, $url_ar_rank) . '</fieldset><p>' . (($event['action'] == 'jva_start_system_desc') ? $this->back_link($event['u_action'], true) : '')
						));
					break;
				}
			}
			else
			{
				if ($this->localhost && (!$this->arcade_config['activation_key'] || $this->arcade_config['activation_key'] != 'Localhost'))
				{
					$this->start_system_activate('Localhost');
				}

				if (!$this->arcade_config['activation_key'] || $this->request->variable('new_activation_key', false))
				{
					$event['mode_title_disable'] = true;
					$event['page_title'] = 'JVA_SS_ACTIVATION';

					$s_hidden_fields = build_hidden_fields(array(
						'type'				=> 'activation',
						'action'			=> 'activation',
						'jva_ss_id'			=> $this->arcade_config['jva_start_system_id'],
						'lang_key'			=> $this->user->data['user_lang'],
						'arcade_version'	=> $this->arcade_config['version'],
						'web_return_url'	=> base64_encode(generate_board_url()),
						'username'			=> $this->user->data['username'],
						'useremail'			=> $this->user->data['user_email'],
						'userip'			=> $this->user->ip,
						'phpbb_version'		=> $this->config['version'],
						'newkey'			=> ($this->arcade_config['activation_key']) ? $this->arcade_config['activation_key'] : 0
					));

					$this->template->assign_vars(array(
						'S_JVA_START_SYSTEM'				=> true,
						'S_JVA_START_SYSTEM_ACTIVATION'		=> true,
						'S_JVA_START_SYSTEM_KEY'			=> $this->arcade_config['activation_key'],
						'S_JVA_START_SYSTEM_KEY_PRIVATE'	=> ($this->arcade_config['activation_key'] && !in_array($this->arcade_config['activation_key'], array('test', 'free'))) ? true : false,
						'S_HIDDEN_FIELDS'					=> $s_hidden_fields,

						'U_ACTION_JVA_START_SYSTEM'			=> $event['u_action'],
						'U_START_SYSTEM_ACTIVATION'			=> $this->arcade_config['connect_domain'] . 'jva_start_system.php',

						'JVA_SS_EXPLAIN'					=> sprintf($this->user->lang['JVA_SS_EXPLAIN'], $this->arcade_config['connect_domain'], $this->gen_personal_data(), $this->user->data['user_lang']),
						'JVA_SS_JVA_GI_EXPLAIN'				=> sprintf($this->user->lang['JVA_SS_JVA_GI_EXPLAIN'], $this->arcade_config['connect_domain'], $this->gen_personal_data(array(2, 4, 5, 6)), $this->ext->version, $this->user->data['user_lang'], $this->jva_web_host($this->arcade_config['support_domain'])),

						'JVA_SS_DETAIL_DESCRIPTION_CONFIRM'	=> $this->user->lang('JVA_SS_DETAIL_DESCRIPTION_CONFIRM', '<a href="'. $event['u_action'] . '&amp;action=jva_start_system_desc' .'">', '</a>'),
						'JVA_SS_PRIVACY_POLICY_CONFIRM'		=> $this->user->lang('JVA_SS_PRIVACY_POLICY_CONFIRM', '<a onclick="window.open(this.href); return false;" href="'. $this->arcade_config['support_domain'] . 'ucp.php?mode=privacy' .'">', '</a>'),
						'JVA_SS_LICENSE_CONFIRM'			=> $this->user->lang('JVA_SS_LICENSE_CONFIRM', '<a onclick="window.open(this.href); return false;" href="https://jv-arcade.com/License.html">', '</a>'),

						'L_ARCADE_TITLE'					=> $this->user->lang[$event['page_title']],
						'L_ARCADE_TITLE_EXPLAIN'			=> $this->user->lang[$event['page_title']. '_EXPLAIN']
					));
				}
				else
				{
					if ($this->arcade_config['activation_hide'])
					{
						$this->template->assign_vars(array(
							'S_JVA_START_SYSTEM'					=> true,
							'S_JVA_START_SYSTEM_ACTIVATION_HIDE'	=> true,

							'U_JVA_START_SYSTEM_SHOW_ACTIVATION'	=> $event['u_action'] . '&amp;hide_activation=0'
						));
					}
					else
					{
						$activation_key = ($this->arcade_config['activation_key'] == 'test') ? $this->user->lang['ARCADE_TEST'] : (($this->arcade_config['activation_key'] == 'free') ? $this->user->lang['ARCADE_FREE'] : $this->arcade_config['activation_key']);
						$s_hidden_fields = build_hidden_fields(array(
							'type'		=> 'personal_data',
							'action'	=> 'view_personal_data',
							'web_url'	=> generate_board_url(),
							'jva_ss_id'	=> $this->arcade_config['jva_start_system_id'],
							'username'	=> $this->user->data['username'],
							'lang_key'	=> $this->user->data['user_lang']
						));

						$this->template->assign_vars(array(
							'S_JVA_START_SYSTEM'					=> true,
							'S_JVA_LOCALHOST'						=> $this->localhost,
							'S_JVA_ACTIVATION_USER'					=> $this->arcade_config['jva_start_system_id'] && $this->arcade_config['activation_user_id'] && $this->user->data['user_id'] == $this->arcade_config['activation_user_id'],
							'S_JVA_START_SYSTEM_ACTIVATED_KEY_END'	=> ($this->arcade_config['activation_end'] && $this->arcade_config['activation_end'] < time()) ? true : false,
							'S_HIDDEN_FIELDS'						=> $s_hidden_fields,

							'U_ACTION_JVA_START_SYSTEM'				=> $event['u_action'],
							'U_JVA_START_SYSTEM_HIDE_ACTIVATION'	=> $event['u_action'] . '&amp;hide_activation=1',
							'U_START_SYSTEM_ACTIVATION'				=> $this->arcade_config['connect_domain'] . 'jva_start_system.php',

							'JVA_START_SYSTEM_ACTIVATED_KEY'		=> $activation_key,
							'JVA_START_SYSTEM_ACTIVATED_DATE'		=> $this->user->format_date($this->arcade_config['activation_start']),
							'JVA_START_SYSTEM_ACTIVATED_EXP_DATE'	=> ($this->arcade_config['activation_end']) ? $this->user->format_date($this->arcade_config['activation_end'], false, true) : $this->user->lang['ARCADE_NONE']
						));
					}
				}
			}
		}
	}

	public function play_game_tpl($event)
	{
		$event['tpl'] = array_merge($event['tpl'], array(
			'S_JVA_G_INTRO'					=> ($this->arcade_config['jva_gi_enable']) ? 'yes' : 'no',
			'S_JVA_SS_LOCAL_STORAGE'		=> $this->arcade_config['jva_ss_local_storage'],
			'S_GAME_SAVE_TYPE_KEY'			=> $this->arcade->game()->save_type($event['game_data']['game_save_type']),

			'JVA_G_INTRO_IMG_LOGO'			=> (file_exists($this->root_path . 'arcade/start_system/jva_game_intro/images/logo.png')) ? 'yes' : 'no',
			'JVA_G_INTRO_LOGO_TXT'			=> urlencode($this->arcade_config['jva_gi_logo']),
			'JVA_G_INTRO_LOGO_COLOR'		=> $this->arcade_config['jva_gi_logotcolor'],
			'JVA_G_INTRO_LOGO_SCOLOR'		=> $this->arcade_config['jva_gi_logotscolor'],
			'JVA_G_INTRO_GAME_NAME'			=> urlencode($event['game_data']['game_name']),
			'JVA_G_INTRO_GAME_DESC'			=> urlencode((($event['game_desc']) ? $event['game_desc'] : $this->user->lang['ARCADE_NO_INSTRUCTIONS'])),
			'JVA_G_INTRO_GAME_CONTROL_DESC'	=> urlencode((!$event['game_data']['game_control'] && !$event['game_control_desc']) ? $this->user->lang['ARCADE_NO_CONTROLS_DESC'] : $event['game_control_desc']),
			'JVA_G_INTRO_MAX_HIGHSCORES'	=> (int) $this->arcade_config['jva_gi_highscores'],
			'JVA_G_INTRO_SUPERCHAMPION'		=> urlencode(($event['use_super_champion'] && !empty($event['super_champion']['user_id'])) ? $this->user->lang['ARCADE_SUPER_CHAMPION'] . $this->user->lang['COLON'] . ' ' . $event['super_champion']['username'] . ' - ' . $event['super_champion']['f_score'] : ''),
			'JVA_G_INTRO_GAME_PRELOAD'		=> ($this->arcade_config['jva_gi_game_preload']) ? 'yes' : 'no',
			'JVA_START_SYSTEM_ID'			=> md5($this->arcade_config['jva_start_system_id']),
			'JVA_START_SYSTEM_KEY'			=> md5($this->arcade_config['activation_key']),

			'U_JVA_G_INTRO'					=> "{$this->root_path}arcade/start_system/jva_game_intro/index.html"
		));

		if ($this->auth->acl_get('a_arcade_install') && $this->user->data['user_type'] == USER_FOUNDER)
		{
			$event['tpl'] = array_merge($event['tpl'], array(
				'U_JVA_START_SYSTEM_ACTIVATION' => $this->arcade->adm_url('main', '&amp;mode=main&amp;new_activation_key=1&amp;diff=1')
			));
		}
	}

	public function header_tpl($event)
	{
		if ($event['mode'] != 'path')
		{
			$event['arcade_row'] = array_merge($event['arcade_row'], array(
				'JVA_G_INTRO_WIDTH'		=> 640,
				'JVA_G_INTRO_HEIGHT'	=> 426
			));
		}
	}

	private function auth_activation()
	{
		return (defined('IN_ADMIN') && $this->auth->acl_get('a_arcade_install') && $this->user->data['user_type'] == USER_FOUNDER);
	}

	private function start_system_activate($key = 'test', $end_time = 0, $activation_time = true)
	{
		$this->arcade_config->set('activation_key', $key);
		$this->arcade_config->set('activation_end', (int) $end_time);
		$this->arcade_config->set('activation_user_id', (int) $this->user->data['user_id']);

		if ($activation_time)
		{
			$this->arcade_config->set('activation_start', time());
		}
	}

	private function back_link($u_action, $ignore_br = false, $act = true)
	{
		return (($ignore_br) ? '' : '<br><br>') . '<a href="' . $u_action . (($act) ? '&amp;new_activation_key=1' : '') . '" style="float: ' . (($this->user->lang['DIRECTION'] == 'ltr') ? 'left' : 'right') . ';">&laquo; ' . $this->user->lang['BACK'] . '</a>';
	}

	private function jva_web_host($website)
	{
		return str_replace(array('https:', 'http:', '/'), '', $website);
	}

	private function gen_personal_data($unset_ids = array())
	{
		$data_ary = array('<strong>' . $this->user->lang['JVA_SS_ID'] . $this->user->lang['COLON'] . '</strong> ' . $this->arcade_config['jva_start_system_id'],
			'<strong>' . $this->user->lang['JVA_SS_WEB_ADDRESS'] . $this->user->lang['COLON'] . '</strong> ' . generate_board_url(),
			'<strong>' . $this->user->lang['JVA_SS_PHPBB_VERSION'] . $this->user->lang['COLON'] . '</strong> ' . $this->config['version'],
			'<strong>' . $this->user->lang['JVA_SS_ARCADE_VERSION'] . $this->user->lang['COLON'] . '</strong> ' . $this->arcade_config['version'],
			'<strong>' . $this->user->lang['JVA_SS_USERNAME'] . $this->user->lang['COLON'] . '</strong> ' . $this->user->data['username'],
			'<strong>' . $this->user->lang['JVA_SS_USER_EMAIL'] . $this->user->lang['COLON'] . '</strong> ' . $this->user->data['user_email'],
			'<strong>' . $this->user->lang['JVA_SS_USER_IP'] . $this->user->lang['COLON'] . '</strong> ' . $this->user->ip
		);

		foreach ($unset_ids as $key)
		{
			unset($data_ary[$key]);
		}

		return implode('<br>', $data_ary);
	}

	private function download_personal_data($pd)
	{
		$filetype = $this->request->variable('filetype', 'txt');
		$mimetype = ($filetype == 'txt') ? 'text/plain' : 'text/csv';

		$jva_ss_personal_data = $this->user->lang['JVA_SS_PERSONAL_DATA'] . $this->user->lang['COLON'] . "\n";
		foreach ($pd as $lang_key => $value)
		{
			$jva_ss_personal_data .= "\n" . $this->user->lang[$lang_key] . $this->user->lang['COLON'] . ' ' . $value;
		}

		$len = strlen($jva_ss_personal_data);
		header('Cache-Control: private, no-cache');
		header("Content-Type: $mimetype; name=\"jva_ss_personal_data.$filetype\"");
		header("Content-Length: $len");
		header("Content-disposition: attachment; filename=jva_ss_personal_data.$filetype");

		echo $jva_ss_personal_data;
		exit;
	}
}
