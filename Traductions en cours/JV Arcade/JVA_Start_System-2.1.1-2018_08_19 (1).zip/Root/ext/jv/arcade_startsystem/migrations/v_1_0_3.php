<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

namespace jv\arcade_startsystem\migrations;

use jv\arcade\inc\install\install as arcade_install;

class v_1_0_3 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\jv\arcade_startsystem\migrations\v_1_0_0',
			'\jv\arcade\migrations\v_4_2_3'
		);
	}

	public function update_data()
	{
		return array(
			array('custom', array(array($this, 'install_data')))
		);
	}

	public function revert_data()
	{
		return array(
			array('custom', array(array($this, 'remove_data')))
		);
	}

	public function install_data()
	{
		$arcade_install = new arcade_install($this->db, $this->php_ext, $this->table_prefix);

		$arcade_install->set_config(array(
			array('jva_start_system_id', unique_id()),
			array('activation_user_id', 0),
			array('activation_key', ''),
			array('activation_start', 0),
			array('activation_end', 0)
		));
	}

	public function remove_data()
	{
		if ($this->db_tools->sql_table_exists("{$this->table_prefix}arcade_config"))
		{
			$arcade_install = new arcade_install($this->db, $this->php_ext, $this->table_prefix);

			$arcade_install->delete_config(array(
				array('jva_start_system_id'),
				array('activation_user_id')
			));
		}
	}
}
