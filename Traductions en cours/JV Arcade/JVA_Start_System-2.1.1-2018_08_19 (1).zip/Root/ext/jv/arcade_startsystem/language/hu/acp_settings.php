<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JVA_GAME_INTRO'						=> 'JVA Game Intro',
	'JVA_GAME_INTRO_EXPLAIN'				=> 'A játék elindulása előtt egy bevezető kerül betöltésre, amely tartalmazza a játék leírását, vezérlését és az elért eredmények listáját.<br>Továbbá olvasd el a részletes leírást %sITT%s.',
	'JVA_GAME_INTRO_GAME_PRELOAD'			=> 'Játék betöltésének kijelzése',
	'JVA_GAME_INTRO_GAME_PRELOAD_EXPLAIN'	=> 'Ez az opció csak a Flash játékokra érvényes.<br>A játék kizárólag a böngésző gyorsítótárába lesz betöltve. Amennyiben nincs engedélyezve a böngésző gyorsítótár használata, akkor a játék kétszer fog betöltődni, így ez az eljárás csak lassítaná a játékok elindulását.<br><em>A böngésző gyorsítótár használata erősen ajánlott!</em>',
	'JVA_GAME_INTRO_LOGO'					=> 'Logo szövege',
	'JVA_GAME_INTRO_LOGO_COLOR'				=> 'Logo színe',
	'JVA_GAME_INTRO_LOGO_EXPLAIN'			=> 'Amennyiben itt megadsz egy szöveget, az felülírja az eredeti logot és kijelzésre fog kerülni. Viszont lehetőséged van saját kép logot is készítened, amit a „[root]/arcade/start_system/jva_game_intro/images/logo.png” néven lehet feltölteni a szerverre, a kép logo mindent felülír.',
	'JVA_GAME_INTRO_LOGO_SHADOW_COLOR'		=> 'Logo árnyék színe',
	'JVA_GAME_INTRO_PRIVATE_SETTINGS'		=> 'Ez a beállítás csak akkor érhető el, ha a „JVA Start System”-et privát kulccsal aktiválja egy alapító.',
	'JVA_GAME_INTRO_SCORES'					=> 'Eredmények száma',
	'JVA_GAME_INTRO_SCORES_EXPLAIN'			=> 'A megadott érték szerint kerülnek kilistázásra az elért eredmények.',
	'JVA_SS_LOCAL_STORAGE'					=> 'Helyi tároló',
	'JVA_SS_LOCAL_STORAGE_EXPLAIN'			=> 'A helyi tároló hasonlóképpen működik, mint a cookie-k. Adatokat tárolnak az eszközünkön. Egyes játékok sajnos manipulálhatóak ezáltal, például a pálya szintje vagy az elért pontszámunk. Itt lehetőséged van megakadályozni, hogy manipulálhassák az adatokat a felhasználók. Ennek viszont annyi a hátránya, hogy az elért pályaszintek figyelmen kívül lesznek hagyva a játék újrajátszásánál. Vedd figyelembe, hogy beépítésre került egy „score” változó szűrés. Tehát, ha nem is kapcsolod ki a teljes helyi tároló szolgáltatást, akkor is ha létezik a „score” változó, akkor ennek értékét mindig lenullázzuk. Viszont lehetnek olyan játékok amelynek nem ezt a változó nevet adták, ezért a 100% biztonság érdekében jobb kikapcsolni ezt a szolgáltatást.',
));
