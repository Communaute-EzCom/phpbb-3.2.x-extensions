<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

namespace jv\arcade_startsystem;

use phpbb\extension\base;

class ext extends base
{
	public function is_enableable()
	{
		return defined('ARCADE_VERSION') && phpbb_version_compare(ARCADE_VERSION, '4.2.7', '>=');
	}
}
