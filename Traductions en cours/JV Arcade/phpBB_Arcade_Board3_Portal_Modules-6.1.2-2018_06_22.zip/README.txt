# phpBB Arcade - Board3 portal arcade modules

## Quick Install
You can install this on the latest release of phpBB 3.2. by following the steps below:

1. Unzip the downloaded release.
2. Copy the 'ext' directory in the (your forum root)/) directory.
3. Navigate in the ACP to 'Customise -> Manage extensions'.
4. Look for 'phpBB Arcade - Board3 portal arcade modules' under the Disabled Extensions list, and click its 'Enable' link.
5. Set up and configure 'phpBB Arcade - Board3 portal arcade modules' by navigating in the ACP to 'Extensions' -> 'phpBB Arcade - Board3 portal arcade modules'.

## Update

1. Navigate in the ACP to 'Customise -> Manage extensions' - Look for 'phpBB Arcade - Board3 portal arcade modules' under the Enabled Extensions list, and click its 'Disable' link.
2. Unzip the downloaded release.
3. Copy the 'ext' directory in the  (your forum root)/) directory.
4. Navigate in the ACP to 'Customise -> Manage extensions' - Look for 'phpBB Arcade - Board3 portal arcade modules' under the Disabled Extensions list, and click its 'Enable' link.
5. Set up and configure 'phpBB Arcade - Board3 portal arcade modules' by navigating in the ACP to 'Extensions' -> 'phpBB Arcade - Board3 portal arcade modules'.

## Uninstall

1. Navigate in the ACP to 'Customise -> Extension Management -> Extensions'.
2. Look for 'phpBB Arcade - Board3 portal arcade modules' under the Enabled Extensions list, and click its 'Disable' link.
3. To permanently uninstall, click 'Delete Data' and then delete the '/ext/jv/arcade_b3portal' directory and '/ext/board3/portal/styles/all/theme/images/portal/' (portal_arcade.png, portal_arcade_challenge.png, portal_arcade_new.png, portal_arcade_tournament.png) files from your server via FTP.

## Support

https://jv-arcade.com/

## License
[GNU General Public License v2](https://opensource.org/licenses/gpl-2.0.php)
