<?php
/**
*
* @package phpBB Arcade - Board3 portal arcade modules
* @version $Id: v_6_0_1.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade_b3portal\migrations;

class v_6_0_1 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\phpbb\db\migration\data\v310\extensions',
			'\phpbb\db\migration\data\v31x\v316',
			'\board3\portal\migrations\v210',
			'\jv\arcade\migrations\v_4_0_RC4'
		);
	}

	public function revert_data()
	{
		if ($this->db_tools->sql_table_exists("{$this->table_prefix}portal_modules"))
		{
			$columns = $this->db_tools->sql_list_columns("{$this->table_prefix}portal_modules");

			if (isset($columns['module_id']) && isset($columns['module_classname']))
			{
				$portal_arcade_configs = array();

				$sql = "SELECT module_id
						FROM {$this->table_prefix}portal_modules
						WHERE module_classname " . $this->db->sql_like_expression('\\\jv\\\arcade_b3portal' . $this->db->get_any_char());
				$result = $this->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$portal_arcade_configs[] = "board3_display_game_image_{$row['module_id']}";
					$portal_arcade_configs[] = "board3_display_popup_icon_{$row['module_id']}";
					$portal_arcade_configs[] = "board3_displayed_data_{$row['module_id']}";
					$portal_arcade_configs[] = "board3_display_avatar_{$row['module_id']}";
				}
				$this->db->sql_freeresult($result);

				if (sizeof($portal_arcade_configs))
				{
					$sql = "DELETE FROM {$this->table_prefix}config
							WHERE " . $this->db->sql_in_set('config_name', $portal_arcade_configs);
					$this->sql_query($sql);
				}

				$sql = "DELETE FROM {$this->table_prefix}portal_modules
						WHERE module_classname " . $this->db->sql_like_expression('\\\jv\\\arcade_b3portal' . $this->db->get_any_char());
				$this->sql_query($sql);
			}
		}

		// Run if not installed board3 portal extension
		if (!isset($portal_arcade_configs))
		{
			$sql = "DELETE FROM {$this->table_prefix}config
					WHERE config_name " . $this->db->sql_like_expression('board3_display' . $this->db->get_any_char());
			$this->sql_query($sql);
		}

		return array();
	}
}
