<?php
/**
*
* @package phpBB Arcade - Board3 portal arcade modules
* @version $Id: arcade_most_played_users.php 1853 2018-02-20 10:45:14Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade_b3portal\modules;

class arcade_most_played_users extends \board3\portal\modules\module_base
{
	public $columns		= 10;
	public $name		= 'ARCADE_EXT_B3PORTAL_MOST_PLAYED_USERS_TITLE';
	public $image_src	= 'portal_arcade.png';
	public $language	= array(
		'vendor'	=> 'jv/arcade_b3portal',
		'file'		=> 'modules'
	);

	protected $arcade_b3portal, $config;

	function __construct($arcade_b3portal, $config)
	{
		$this->arcade_b3portal = $arcade_b3portal;
		$this->config = $config;
	}

	public function get_template_side($module_id)
	{
		if (!$this->arcade_b3portal->auth('stats'))
		{
			return;
		}

		$this->arcade_b3portal->module($module_id, 'user', 'played_users', 'pop_users');

		return '@jv_arcade_b3portal/modules/arcade_most_played_users.html';
	}

	public function get_template_acp($module_id)
	{
		return array(
			'title'			=> 'MODULE_OPTIONS',
			'vars'			=> array(
				'legend1'	=> 'ACP_PORTAL_GENERAL_INFO',
				"board3_display_avatar_$module_id"	=> array('lang' => 'ARCADE_DISPLAY_USER_AVATAR'			, 'validate' => 'bool',		'type' => 'radio:yes_no',	'explain' => false),
				"board3_displayed_data_$module_id"	=> array('lang' => 'ARCADE_EXT_B3PORTAL_DISPLAYED_DATA'	, 'validate' => 'int:1',	'type' => 'number:1',		'explain' => false)
			),
		);
	}

	public function install($module_id)
	{
		$this->config->set("board3_display_avatar_$module_id", 1);
		$this->config->set("board3_displayed_data_$module_id", 5);

		return true;
	}

	public function uninstall($module_id, $db)
	{
		$del_config = array(
			"board3_display_avatar_$module_id",
			"board3_displayed_data_$module_id"
		);

		$sql = 'DELETE FROM ' . CONFIG_TABLE . '
				WHERE ' . $db->sql_in_set('config_name', $del_config);
		return $db->sql_query($sql);
	}
}
