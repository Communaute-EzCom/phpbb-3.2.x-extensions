<?php
/**
*
* @package phpBB Arcade - Board3 portal arcade modules
* @version $Id: acp_settings.php 2015 2018-06-22 18:25:38Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade_b3portal\inc;

class acp_settings extends \jv\arcade\inc\ext\base
{
	public $version = '6.1.2';
	public $name = 'ARCADE_EXT_B3PORTAL';

	protected $arcade;

	public function __construct($arcade = null)
	{
		$this->arcade = $arcade;
	}

	public function get_language()
	{
		return array(
			'vendor'	=> 'jv/arcade_b3portal',
			'file'		=> 'acp_settings'
		);
	}

	public function get_template_acp()
	{
		$explain = (!defined('ARCADE_MIN_B3PORTAL_VERSION') || phpbb_version_compare($this->version, ARCADE_MIN_B3PORTAL_VERSION, '<')) ? 'ACP_ARCADE_EXT_DISABLED' : false;
		$explain = (!$explain && !$this->arcade->portal()->data['show']) ? 'ARCADE_EXT_B3PORTAL_DETECT' : $explain;

		return array(
			'legend1'					=> array('name' => false, 'explain' => $explain),
			'ext_b3portal'				=> array('lang' => 'ARCADE_EXT_B3PORTAL',			 'validate' => 'bool', 'type' => 'radio:enabled_disabled', 'explain' => true),
			'ext_b3portal_stat_auth'	=> array('lang' => 'ARCADE_EXT_B3PORTAL_STATS_AUTH', 'validate' => 'bool', 'type' => 'radio:enabled_disabled', 'explain' => true)
		);
	}
}
