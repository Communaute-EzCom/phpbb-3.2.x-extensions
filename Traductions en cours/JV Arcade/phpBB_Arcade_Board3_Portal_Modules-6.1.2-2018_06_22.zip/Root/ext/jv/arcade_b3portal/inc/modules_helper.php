<?php
/**
*
* @package phpBB Arcade - Board3 portal arcade modules
* @version $Id: modules_helper.php 2015 2018-06-22 18:25:38Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\arcade_b3portal\inc;

class modules_helper
{
	protected $auth, $config, $arcade, $arcade_config;

	public function __construct($auth, $config, $template, $ext, $arcade = null, $arcade_config = null)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->arcade = $arcade;
		$this->arcade_config = $arcade_config;

		if ($this->arcade && defined('ARCADE_MIN_B3PORTAL_VERSION') && phpbb_version_compare($ext->version, ARCADE_MIN_B3PORTAL_VERSION, '>=') && $this->arcade_config['ext_b3portal'] && $this->arcade->page() == 'portal')
		{
			$template->assign_var('S_ARCADE_EXT_BOARD3_PORTAL', true);
		}
	}

	public function auth($type = '', $page = '', $admin = false)
	{
		return $this->arcade && $this->arcade_config['ext_b3portal'] && $this->arcade->access($page, $admin) && (($this->arcade_config['ext_b3portal_stat_auth'] && in_array($type, array('full', 'stats'))) ? $this->auth->acl_get('u_arcade_viewstats') : true) && ((in_array($type, array('full', 'points'))) ? $this->arcade->points()->data['show'] : true);
	}

	public function config($type, $config_name, $config_value = '')
	{
		$this->arcade->change_config($type, $config_name, $config_value);
	}

	public function online_playing()
	{
		if ($this->auth->acl_get('u_arcade_view_whoisplaying'))
		{
			$this->arcade->display()->online_playing();

			return true;
		}

		return false;
	}

	public function module($module_id, $mode, $action, $tpl_key = '', $type = 'most', $order_by = '', $id = false, $zero = false, $ca = false, $s_can_play = false)
	{
		$mode = strtolower($mode);
		$key = (strpos($action, 'challenge') !== false) ? 'challenge' : ((strpos($action, 'tour') !== false) ? 'tournament' : 'arcade');

		if (!$mode || !$action || ($key == 'challenge' && !$this->arcade->access('challenge')) || ($key == 'tournament' && !$this->arcade->access('tour')))
		{
			return '';
		}

		$new_configs = array(
			"board3_display_avatar_$module_id"		=> (isset($this->config["board3_display_avatar_$module_id"])) ? array('display_user_avatar', $this->config["board3_display_avatar_$module_id"]) : false,
			"board3_display_game_image_$module_id"	=> (isset($this->config["board3_display_game_image_$module_id"])) ? array('display_game_image', $this->config["board3_display_game_image_$module_id"]) : false,
			"board3_display_popup_icon_$module_id"	=> (isset($this->config["board3_display_popup_icon_$module_id"])) ? array('display_game_popup_icon', $this->config["board3_display_popup_icon_$module_id"]) : false
		);

		foreach ($new_configs as $config_name => $ary)
		{
			if (is_array($ary) && $ary !== false)
			{
				$this->arcade->change_config('replace', $ary[0], $ary[1]);
			}
		}

		$return = '';
		$tpl_key = 'portal_arcade_' . (($key == 'challenge') ? 'challenge_' : (($key == 'tournament') ? 'tour_' : '')) . $tpl_key;
		$limit = intval((!empty($this->config["board3_displayed_data_$module_id"])) ? $this->config["board3_displayed_data_$module_id"] : 3);
		$cache_ttl = $this->arcade->hour($this->arcade_config['cache_time']);

		switch ($mode)
		{
			case 'display_leaders':
				$this->arcade->display()->leaders($key, "{$tpl_key}leaders");
			break;

			default:
				$return = $this->arcade->display()->stats_data($mode, $action, $type, 0, $limit, true, $tpl_key, $order_by, $id, $zero, $ca, $cache_ttl, false, false, $s_can_play);
			break;
		}

		foreach ($new_configs as $config_name => $ary)
		{
			if (is_array($ary) && $ary !== false)
			{
				$this->arcade->change_config('restore', $ary[0]);
			}
		}

		unset($new_configs);

		return $return;
	}
}
