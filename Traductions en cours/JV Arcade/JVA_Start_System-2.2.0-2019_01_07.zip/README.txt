# phpBB Arcade - JVA Start System

## Quick Install
You can install this on the latest release of phpBB 3.2. by following the steps below:

1. Unzip the downloaded JVA Start System release.
2. Copy all the JVA Start System files in the [root]/ directory of your forum.
3. Navigate in the ACP to 'Customise -> Manage extensions'.
4. Look for 'phpBB Arcade - JVA Start System' under the Disabled Extensions list, and click its 'Enable' link.

## Update

1. Navigate in the ACP to 'Customise -> Manage extensions' and Look for 'phpBB Arcade - JVA Start System' under the Enabled Extensions list, and click its 'Disable' link.
2. Unzip the downloaded phpBB Arcade - JVA Start System release.
3. Copy all the phpBB Arcade - JVA Start System files in the [root]/ directory of your phpBB forum.
4. Navigate in the ACP to 'Customise -> Manage extensions' and Look for 'phpBB Arcade - JVA Start System' under the Disabled Extensions list, and click its 'Enable' link.

## Uninstall

1. Navigate in the ACP to 'Customise -> Extension Management -> Extensions'.
2. Look for 'phpBB Arcade - JVA Start System' under the Enabled Extensions list, and click its 'Disable' link.
3. To permanently uninstall, click 'Delete Data' and then delete the '[root]/arcade/start_system/' and '[root]/ext/jv/arcade_startsystem' directory from your server via FTP.

## Support

https://jv-arcade.com/

## License
[JVA License v1] https://jv-arcade.com/License.html
