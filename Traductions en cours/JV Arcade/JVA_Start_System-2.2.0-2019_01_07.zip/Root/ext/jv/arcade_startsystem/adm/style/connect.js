/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

var jvass = {};

(function ($) {
	'use strict';

	jvass.ajax = function(url, type, l_yes) {
		var id = (type == 'activation' || type == 'personal_data') ? 'jva_start_system' : 'confirm';

		$.ajax({
			url: url,
			timeout: 5000,
			type: 'POST',
			async: true,
			cache: false,
			data: $('#' + id).serialize(),
			dataType: 'json',
			beforeSend: function () {
				$('#darkenwrapper').show();
				phpbb.loadingIndicator();
			},
			success: function (res) {
				var d;
				for (var key in res) {
					d = $('<input />', {type: 'hidden', name: key, value: res[key]});
					d.appendTo('#' + id);
				}

				if (type == 'remove_personal_data' && l_yes) {
					d = $('<input />', {type: 'hidden', name: 'confirm', value: l_yes});
					d.appendTo('#' + id);
				}

				$('#' + id).submit();
			},
			error: function (xhr, textStatus, errorThrown) {
				var errorText = 'no_connection';
				var responseText = false;

				try {
					responseText = JSON.parse(xhr.responseText);
					responseText = responseText.Message;
				} catch (e) {}

				if (typeof responseText === 'string' && responseText.length > 0)
				{
					errorText = responseText;
				}
				else if (typeof errorThrown === 'string' && errorThrown.length > 0) {
					errorText = errorThrown;
				}

				d = $('<input />', {type: 'hidden', name: 'status', value: textStatus});
				d.appendTo('#' + id);

				if (errorText == 'no_connection' && textStatus)
				{
					errorText = '-';
				}

				var d;
				d = $('<input />', {type: 'hidden', name: 'error', value: errorText});
				d.appendTo('#' + id);

				$('#'  + id).submit();
			},
			statusCode: {
				0:function(){
					if (type == 'activation') {
						d = $('<input />', {type: 'hidden', name: 'msg', value: 'no_connection'});
						d.appendTo('#' + id);
						$('#'  + id).submit();
					}
				}
			}
		});
	};
})(jQuery);
