<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JVA_SS_ACTIVATION'							=> 'JVA Start System aktiválás',
	'JVA_SS_ACTIVATION_EXPLAIN'					=> 'Itt elolvashatod az összes instrukciót ami a JVA Start System-hez tartozik, továbbá itt tudod aktiválni a rendszert amennyiben elfogadod a feltételeket.',
	'JVA_SS_ACTIVATION_BLOCKED'					=> 'Ez a weboldal megsértette a „JVA Start System” szoftver engedélyét, ezért blokkolásra került. A blokkolás okát megtudhatja a szoftver üzemeltetőjétől, valamint kérheti a blokkolás feloldását %sITT%s.',
	'JVA_SS_ACTIVATION_DATE'					=> 'Aktiválás időpontja',
	'JVA_SS_ACTIVATION_INVALID'					=> 'Érvénytelen aktiválási kísérlet!',
	'JVA_SS_ACTIVATION_KEY'						=> 'Aktivációs kulcs',
	'JVA_SS_ACTIVATION_KEY_ALREADY'				=> 'A megadott aktiváló kulcs már aktiválva lett!',
	'JVA_SS_ACTIVATION_KEY_EXPLAIN'				=> 'Itt három kulcs közül választhatsz. Ha ez éles weboldal akkor válaszd az „Ingyenes” kulcsot, ha ez egy teszt weboldal akkor válaszd a „Teszt” kulcsot, viszont, ha rendelkezel privát kulccsal akkor azt használd fel, de csak abban az esetben, ha ez egy éles weboldal.',
	'JVA_SS_ACTIVATION_KEY_INVALID'				=> 'A megadott aktiváló kulcs érvénytelen!',
	'JVA_SS_ACTIVATION_KEY_INVALID_VERSION'		=> 'A megadott aktiváló kulcs nem ehhez a „phpBB Arcade” verzióhoz tartozik!',
	'JVA_SS_ACTIVATION_KEY_UPDATED'				=> 'A használatban lévő aktiváló kulcs, sikeresen frissítve lett.',
	'JVA_SS_ACTIVATION_SHOW'					=> 'Aktiváló mező mutatása',
	'JVA_SS_ACTIVATION_SUCCESS'					=> 'A megadott aktiváló kulcs elfogadva, most már használatba veheted a phpBB Arcade.',
	'JVA_SS_ENABLE_ERROR1'						=> 'A kiterjesztés nem kapcsolható be mivel a <strong>„phpBB Arcade”</strong> nem aktív!',
	'JVA_SS_ENABLE_ERROR2'						=> 'A kiterjesztés nem kapcsolható be mert a <strong>„phpBB Arcade”</strong> verziója kisebb mint <strong>„%s”</strong> verzió!',
	'JVA_SS_NEW_KEY'							=> 'Új kulcs megadása',
	'JVA_SS_NOT_ACTIVATED'						=> 'A „JVA Start System” nincs aktiválva! Míg nem aktiválod a „JVA Start System”, addig a „phpBB Arcade” nem használható.',
	'JVA_SS_NOT_ACTIVATED_INFO'					=> 'A „JVA Start System”-et még nem aktiválta az alapító. Amint aktíválva lesz számodra is elérhető lesz a „phpBB Arcade”.',
	'JVA_SS_NOT_COMPATIBLE'						=> 'A telepített „JVA Start System” nem kompatibilis ezzel a „phpBB Arcade” verzióval. Kérlek frissítsd a „JVA Start System”-et.<br>» %sJVA Start System letöltése%s «',
	'JVA_SS_PRIVACY_POLICY'						=> 'Adatvédelmi irányelv',
	'JVA_SS_VIEW_PERSONAL_DATA'					=> 'Személyes adatok megtekintése',
	'JVA_SS_VIEW_PERSONAL_DATA_EXPLAIN'			=> 'Tárolt személyes adataim a „%s” weboldalon.',
	'JVA_SS_NO_PERMISSION_VIEW_PERSONAL_DATA'	=> 'Nincs jogosultságod megtekinteni másik alapító felhasználó személyes adatait.',
	'JVA_SS_REMOVE_PERSONAL_DATA'				=> 'Személyes adatok eltávolítása',
	'JVA_SS_REMOVE_PERSONAL_CONFIRM'			=> 'Biztos vagy benne, hogy eltávolítod az összes személyes adataidat és ezzel együtt megszünteted az aktiválásod?',
	'JVA_SS_REMOVE_PERSONAL_DATA_SUCCESS'		=> 'Az összes személyes adat eltávolításra került a „%s” weboldalról.',
	'JVA_SS_REMOVE_PERSONAL_DATA_ERROR'			=> 'Az adatok törlése nem járt sikerrel, kérlek próbáld újra.',
	'JVA_SS_WEB_ADDRESS'						=> 'Weboldal címe',
	'JVA_SS_ID'									=> 'Saját JVA Start System ID',
	'JVA_SS_ID_EXPLAIN'							=> 'A weboldalad egyedi azonosítója. A kapcsolat során használjuk biztonsági okokból.<br><i>Soha ne módosítsd és ne add ki ezt az ID másoknak!</i>',
	'JVA_SS_WEB_STATUS'							=> 'Weboldal státusza',
	'JVA_SS_INSTALL_DATE'						=> 'Telepítés dátuma',
	'JVA_SS_UPDATE_DATE'						=> 'Frissítés dátuma',
	'JVA_SS_FIRST_PLAY_DATE'					=> 'Első játszás dátuma',
	'JVA_SS_LAST_PLAY_DATE'						=> 'Utolsó játszás dátuma',
	'JVA_SS_PLAY_NUM'							=> 'Játszások száma',
	'JVA_SS_SKIP_TIME'							=> 'Reklám átugrásának várakozási ideje',
	'JVA_SS_PHPBB_VERSION'						=> 'phpBB verzió száma',
	'JVA_SS_ARCADE_VERSION'						=> 'phpBB Arcade verzió száma',
	'JVA_SS_USERNAME'							=> 'Felhasználói neved',
	'JVA_SS_USER_EMAIL'							=> 'Felhasználói E-mail címed',
	'JVA_SS_USER_IP'							=> 'Felhasználói IP címed',
	'JVA_SS_ACT_KEY'							=> 'Aktiváló kulcs',
	'JVA_SS_ACT_KEY_VERSION'					=> 'Aktiváló kulcs verziószáma',
	'JVA_SS_ACT_KEY_EXP_DATE'					=> 'Aktiváló kulcs lejárati ideje',
	'JVA_SS_USE_AR_RANK'						=> 'AR rang használata',
	'JVA_SS_ERROR_INFO'							=> 'Hiba információ',
	'JVA_SS_WEBSITE_NO_CONNECTION'				=> 'A „%s” weboldal jelenleg nem elérhető!',
	'JVA_SS_WEBSITE_ERROR_CONNECTION'			=> 'Hiba történt a lekérés közben. Státusz kód: %s, Hiba kód: %s',
	'JVA_SS_SITE_NOT_AVAILABLE'					=> 'Nincs kapcsolat a „%1$s” weboldallal!<br><br>Míg a „%1$s” weboldal nem elérhető addig is felajánlunk egy alternatív lehetőséget az aktiválásra. Kattints %2$s<strong>IDE</strong>%3$s az ideiglenes aktiválás érdekében.<br>Vedd figyelembe, amint elérhető lesz a „%1$s” weboldal úgy az ideiglenes aktiválásnak vége lesz. Ebben az esetben újra kell aktiválni a rendszert.',
	'JVA_SS_EXPLAIN'							=> '<strong style="color: #BC2A4D;">Figyelem!<br>Az aktiválás során személyes adatok kerülnek továbbításra és mentésre a %1$s weboldalra.</strong><br><br>
Érintett személyes adatok:<br>
%2$s<br>
<strong>Használt nyelvi azonosító:</strong> %3$s<br>
és az aktivációs kulcs.<br>
Továbbá mentésre kerül a telepítési és frissítési dátum.<br><br>

A tárolt adataidat úgy tudod a későbbiekben frissíteni, hogy újra aktiválod a rendszert.<br>
Amennyiben aktiválod a rendszert úgy a későbbiekben is lehetőséged nyílik a személyes adataid törlésére a %1$s weboldalról.',

	'JVA_SS_JVA_GI_EXPLAIN'						=> 'A „JVA Start System” tartalmazz egy „phpBB Arcade” kiterjesztést is aminek a neve „JVA Game Intro”.<br>
Ez a kiterjesztés is adatokat küld a %1$s weboldalra minden játék elindításánál.<br><br>
Érintett személyes adatok:<br>
%2$s<br>
<strong>JVA Start System verzió:</strong> %3$s<br>
<strong>Felhasználó alapító-e:</strong> Igaz vagy Hamis<br>
<strong>Használt nyelvi azonosító:</strong> %4$s<br>
és az aktivációs kulcs.<br>
Továbbá mentésre kerülnek a játszások száma és az első és utolsó játszás dátuma.<br><br>
<strong style="color: #BC2A4D;">A „%5$s” kijelenti, hogy a fórumba regisztrált felhasználók tevékenységei nem lesznek nyomon követve továbbá nem gyűjt és nem is tárol semmilyen személyes adatot.</strong>',

	'JVA_SS_DETAIL_DESCRIPTION_CONFIRM'			=> 'A %s„JVA Start System”%s leírását figyelmesen elolvastam és megértettem',
	'JVA_SS_PRIVACY_POLICY_CONFIRM'				=> 'Az %s„Adatvédelmi irányelvet”%s figyelmesen elolvastam és elfogadom',
	'JVA_SS_LICENSE_CONFIRM'					=> 'A %s„Licenszet”%s figyelmesen elolvastam és betartom',
	'JVA_SS_APPROVAL_PERSONAL_DATA_CONFIRM'		=> 'Jóváhagyom a személyes adatok elküldését és tárolását',
	'JVA_SS_ACTIVATION_SUBMIT'					=> 'Adatok küldése, Aktiválás',
	'JVA_SS_DISABLE_SUBMIT'						=> 'JVA Start System kikapcsolása',
	'JVA_SS_STORED_DATA'						=> 'Tárolt adatok',
	'JVA_SS_REGISTERED'							=> 'Regisztrált',
	'JVA_SS_UNREGISTERED'						=> 'Nem regisztrált',
	'JVA_SS_PERSONAL_DATA'						=> 'Személyes adatok',
	'JVA_SS_REMOVE_PERSONAL_DATA'				=> 'Személyes adatok törlése',
	'JVA_SS_DOWNLOAD_PERSONAL_DATA'				=> 'Személyes adatok letöltése',
));
