<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
// Some characters you may want to copy&paste: ‚ ‘ ’ « » „ “ ” …

$lang = array_merge($lang, array(
	'JVA_GAME_DANGEROUS_DISABLE'			=> 'Veszélyes játékok letiltása',
	'JVA_GAME_DANGEROUS_DISABLE_EXPLAIN'	=> 'Egyes játékok veszélyeztetik a szerver megfelelő működését, mert az adatokat a háttérben továbbítják és többször újratöltik a weblapot. Ez nagymértékben növeli a szerverterhelést, és az ilyen játékok automatikusan letiltásra kerülnek a biztonság érdekében. Itt azonban lehetőséged van arra, hogy saját felelősségedre kikapcsold ezt az automatikus blokkolási funkciót.',
	'JVA_GAME_INTRO'						=> 'JVA Game Intro',
	'JVA_GAME_INTRO_EXPLAIN'				=> 'A játék elindulása előtt egy bevezető kerül betöltésre, amely tartalmazza a játék leírását, vezérlését és az elért eredmények listáját.<br>Továbbá olvasd el a részletes leírást %sITT%s.',
	'JVA_GAME_INTRO_GAME_PRELOAD'			=> 'Játék betöltésének kijelzése',
	'JVA_GAME_INTRO_GAME_PRELOAD_EXPLAIN'	=> 'A játék fő fájljai kizárólag a böngésző gyorsítótárába lesz betöltve. Amennyiben nincs engedélyezve a böngésző gyorsítótár használata, akkor a fájl(ok) kétszer fognak betöltődni, így ez az eljárás csak lassítaná a játékok elindítását.<br><em>A böngésző gyorsítótár használata erősen ajánlott minden felhasználó számára!</em>',
	'JVA_GAME_INTRO_LOGO'					=> 'Logo szövege',
	'JVA_GAME_INTRO_LOGO_COLOR'				=> 'Logo színe',
	'JVA_GAME_INTRO_LOGO_EXPLAIN'			=> 'Amennyiben itt megadsz egy szöveget, az felülírja az eredeti logot és kijelzésre fog kerülni. Viszont lehetőséged van saját kép logot is készítened, amit a „[root]/arcade/start_system/jva_game_intro/images/logo.png” néven lehet feltölteni a szerverre, a kép logo mindent felülír.',
	'JVA_GAME_INTRO_LOGO_SHADOW_COLOR'		=> 'Logo árnyék színe',
	'JVA_GAME_INTRO_MUSIC'					=> 'Zene bekapcsolva',
	'JVA_GAME_INTRO_MUSIC_EXPLAIN'			=> 'Itt engedélyezheted vagy letilthatod a zene lejátszását. A zene véletlenszerűen töltődik be 1-3 ig. A zene fájlokat bármikor lecserélheted, de tartsd be a fájl neveket és a két alap formátum mindig legyen elérhető (ogg és mp3).',
	'JVA_GAME_INTRO_MUSIC_FLD'				=> 'Zene típusa',
	'JVA_GAME_INTRO_MUSIC_FLD_DEFAULT'		=> 'Alap',
	'JVA_GAME_INTRO_MUSIC_FLD_GAME'			=> 'Játék',
	'JVA_GAME_INTRO_MUSIC_FLD_CHRISTMAS'	=> 'Karácsonyi',
	'JVA_GAME_INTRO_PRIVATE_SETTINGS'		=> 'Az összes beállítás csak akkor érhető el, ha a „JVA Start System”-et privát kulccsal aktiválja egy alapító.',
	'JVA_GAME_INTRO_SCORES'					=> 'Eredmények száma',
	'JVA_GAME_INTRO_SCORES_EXPLAIN'			=> 'A megadott érték szerint kerülnek kilistázásra az elért eredmények.',
	'JVA_SS_LOCAL_STORAGE'					=> 'Helyi tároló',
	'JVA_SS_LOCAL_STORAGE_EXPLAIN'			=> 'A helyi tároló hasonlóképpen működik, mint a sütik. Adatokat tárolnak az eszközünkön. Egyes játékok sajnos manipulálhatóak ezáltal, például a pálya szintje vagy az elért pontszámunk. Itt lehetőséged van megakadályozni, hogy manipulálhassák az adatokat a felhasználók. Ennek viszont annyi a hátránya, hogy az elért pályaszintek figyelmen kívül lesznek hagyva a játék újra játszásánál. Vedd figyelembe, hogy beépítésre került egy „score” változó szűrés. Tehát, ha nem is kapcsolod ki a teljes helyi tároló szolgáltatást, akkor is ha létezik a „score” változó, akkor ennek értékét mindig lenullázzuk. Viszont lehetnek olyan játékok amelynek nem ezt a változó nevet adták, ezért a 100% biztonság érdekében jobb kikapcsolni ezt a szolgáltatást.',
));
