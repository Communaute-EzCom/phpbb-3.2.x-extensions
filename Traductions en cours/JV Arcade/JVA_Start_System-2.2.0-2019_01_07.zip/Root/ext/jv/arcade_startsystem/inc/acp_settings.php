<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

namespace jv\arcade_startsystem\inc;

class acp_settings extends \jv\arcade\inc\ext\base
{
	public $version;
	public $name = 'JVA_GAME_INTRO';

	protected $user, $php_ext, $admin_path, $arcade;

	public function __construct($container, $ext_manager, $user, $php_ext, $root_path, $adm_relative_path)
	{
		$this->user = $user;
		$this->php_ext = $php_ext;
		$this->admin_path = $root_path . $adm_relative_path;

		if ($ext_manager->is_available('jv/arcade') && $ext_manager->is_enabled('jv/arcade'))
		{
			$this->arcade = $container->get('jv.arcade.arcade');
			$this->arcade_config = $container->get('jv.arcade.config');
			$this->version = $this->arcade_config['jva_ss_version'];
		}
	}

	public function get_language()
	{
		return array(
			'vendor'	=> 'jv/arcade_startsystem',
			'file'		=> 'acp_settings'
		);
	}

	public function get_template_acp()
	{
		$explain = (!$this->arcade->privat()) ? 'JVA_GAME_INTRO_PRIVATE_SETTINGS' : false;

		$dv = array(
			'legend1'			=> array('name' => false, 'explain' => $explain),
			'jva_gi_enable'		=> array('lang' => 'JVA_GAME_INTRO',			'validate' => 'bool',	'type' => 'custom',			'explain' => true, 'lang_explain' => sprintf($this->user->lang['JVA_GAME_INTRO_EXPLAIN'], '<a onclick="window.open(this.href); return false;" href="' . append_sid("{$this->admin_path}index.{$this->php_ext}", 'i=-jv-arcade-acp-main_module&amp;mode=main&amp;action=s_jva_start_system_desc') . '">', '</a>'), 'method' => 'jva_gi_enable'),
			'jva_gi_music'		=> array('lang' => 'JVA_GAME_INTRO_MUSIC',		'validate' => 'bool',	'type' => 'radio:yes_no',	'explain' => true),
			'jva_gi_music_fld'	=> array('lang' => 'JVA_GAME_INTRO_MUSIC_FLD',	'validate' => 'int',	'type' => 'custom',			'explain' => false,	'method' => 'jva_gi_music_fld'),
		);

		// Attention! The modification is not worth anything! This plays only a secondary role.
		if ($this->arcade->privat())
		{
			$dv += array(
				'jva_gi_logo'			=> array('lang' => 'JVA_GAME_INTRO_LOGO',					'validate' => 'string:0:25',	'type' => 'text:27:25',				'explain'	=> true),
				'jva_gi_logotcolor'		=> array('lang' => 'JVA_GAME_INTRO_LOGO_COLOR',				'validate' => 'string:0:6',		'type' => 'custom',					'explain'	=> false,	'method' => 'set_color'),
				'jva_gi_logotscolor'	=> array('lang' => 'JVA_GAME_INTRO_LOGO_SHADOW_COLOR',		'validate' => 'string:0:6',		'type' => 'custom',					'explain'	=> false,	'method' => 'set_color'),
				'jva_gi_game_preload'	=> array('lang' => 'JVA_GAME_INTRO_GAME_PRELOAD',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true),
				'jva_gi_highscores'		=> array('lang' => 'JVA_GAME_INTRO_SCORES',					'validate' => 'int:3:8',		'type' => 'number:3:8',				'explain'	=> true),
				'jva_game_dang_disable'	=> array('lang' => 'JVA_GAME_DANGEROUS_DISABLE',			'validate' => 'bool',			'type' => 'radio:yes_no',			'explain'	=> true)
			);
		}

		$dv += array(
			'jva_ss_local_storage' => array('lang' => 'JVA_SS_LOCAL_STORAGE', 'validate' => 'bool', 'type' => 'radio:enabled_disabled', 'explain' => true)
		);

		return $dv;
	}

	public function jva_gi_enable($value, $key)
	{
		$value = (!$this->arcade->privat()) ? 1 : $value;
		$privat_arcade = ($this->arcade->privat()) ? '' : ' disabled="disabled"';

		return '<label><input class="radio" type="radio" name="config[' . $key . ']" value="1"' . (($value) ? ' checked="checked" id="' . $key . '"' : '') . $privat_arcade . '> ' . $this->user->lang['ENABLED'] . '</label>
				<label><input class="radio" type="radio" name="config[' . $key . ']" value="0"' . ((!$value) ? ' checked="checked" id="' . $key . '"' : '') . $privat_arcade . '> ' . $this->user->lang['DISABLED'] . '</label>';;
	}

	public function set_color($value, $key)
	{
		$content = '<input name="config[' . $key . ']" type="text" id="' . $key . '" value="' . $value . '" size="6" maxlength="6" />';

		if ($value)
		{
			$content .= '&nbsp;<span style="background-color: #' . $value . '">&nbsp; &nbsp;</span>';
		}

		$content .= (($key == 'jva_gi_logotcolor') ? '&nbsp;&nbsp;<span>[ <a href="#" id="color_palette_toggle">' . $this->user->lang['COLOUR_SWATCH'] . '</a> ]</span>' : '') . '
		<div style="display: none;" class="color_palette_placeholder" data-orientation="h" data-height="12" data-width="15" data-target="#' . $key . '"></div>';

		return $content;
	}

	public function jva_gi_music_fld($value, $key)
	{
		$option_ary = array(
			0	=> 'JVA_GAME_INTRO_MUSIC_FLD_DEFAULT',
			1	=> 'JVA_GAME_INTRO_MUSIC_FLD_GAME',
			2	=> 'JVA_GAME_INTRO_MUSIC_FLD_CHRISTMAS'
		);

		return '<select id="' . $key . '" name="config[' . $key . ']">' . $this->arcade->build_select($option_ary, $value) . '</select>';
	}
}
