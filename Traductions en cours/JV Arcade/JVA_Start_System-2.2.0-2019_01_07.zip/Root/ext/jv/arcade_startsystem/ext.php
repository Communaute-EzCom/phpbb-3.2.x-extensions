<?php
/**
*
* @package phpBB Arcade - JVA Start System
* @version $Id$
* @author 2011-2019 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2019 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://jv-arcade.com/License.html JVA License v1
*
*/

namespace jv\arcade_startsystem;

use phpbb\extension\base;

class ext extends base
{
	public function is_enableable()
	{
		$rv = '4.4.0';
		$error = false;
		$is_enableable = false;
		$em = $this->container->get('ext.manager');

		if (/*!$em->is_available('jv/arcade') ||*/ !$em->is_enabled('jv/arcade'))
		{
			$error = 1;
		}
		else
		{
			$arcade_config = $this->container->get('jv.arcade.config');
			$is_enableable = version_compare($arcade_config['version'], $rv, '>=');

			if (!$is_enableable)
			{
				$error = 2;
			}
		}

		if ($error)
		{
			$lang = $this->container->get('language');
			$lang->add_lang('acp_main', 'jv/arcade_startsystem');
			trigger_error($lang->lang('JVA_SS_ENABLE_ERROR' . $error, $rv), E_USER_WARNING);
		}

		return $is_enableable;
	}

/*
	public function disable_step()
	{

	}

	public function purge_step()
	{

	}
*/
}
