<?php
/**
*
* @package JV First Post On Every Page
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\firstpostoneverypage\migrations;

class v_1_0_0 extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v32x\v322');
	}

	public function update_schema()
	{
		return (!$this->db_tools->sql_column_exists(TOPICS_TABLE, 'topic_first_post_show')) ? array('add_columns' => array(TOPICS_TABLE => array('topic_first_post_show' => array('BOOL', 0)))) : array();
	}

	public function revert_schema()
	{
		return array(
			'drop_columns' => array(TOPICS_TABLE => array('topic_first_post_show'))
		);
	}
}
