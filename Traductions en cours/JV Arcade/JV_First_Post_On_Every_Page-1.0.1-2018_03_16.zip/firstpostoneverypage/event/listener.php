<?php
/**
*
* @package JV First Post On Every Page
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\firstpostoneverypage\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $db, $config, $auth, $user, $request, $template;

	public function __construct($db, $config, $auth, $user, $request, $template)
	{
		$this->db = $db;
		$this->config = $config;
		$this->auth = $auth;
		$this->user = $user;
		$this->request = $request;
		$this->template = $template;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.posting_modify_template_vars'				=> 'posting_modify_template',
			'core.modify_submit_post_data'					=> 'modify_submit_post_data',
			'core.submit_post_modify_sql_data'				=> 'submit_post_modify_sql_data',
			'core.viewtopic_get_post_data'					=> 'viewtopic_get_post_data',
			'core.viewtopic_assign_template_vars_before'	=> 'viewtopic_assign_template_vars_before',
			'core.acp_manage_forums_initialise_data'		=> 'acp_manage_forums_initialise_data',
			'core.acp_manage_forums_request_data'			=> 'acp_manage_forums_request_data',
			'core.acp_manage_forums_display_form'			=> 'acp_manage_forums_display_form',
			'core.acp_board_config_edit_add'				=> 'acp_board_config_edit_add'
		);
	}

	public function posting_modify_template($event)
	{
		if ($this->first_post_auth($event['mode'], $event['forum_id'], $event['post_id'], $event['post_data']))
		{
			$this->user->add_lang_ext('jv/firstpostoneverypage', 'posting');

			$event['page_data'] = array_merge($event['page_data'], array(
				'S_JV_EXT_FIRST_POST_SHOW_ALLOWED' => true,
				'S_JV_EXT_FIRST_POST_SHOW_CHECKED' => (!empty($event['post_data']['topic_first_post_show'])) ? ' checked="checked"' : ''
			));
		}
	}

	public function modify_submit_post_data($event)
	{
		$post_id = (!empty($event['data']['post_id'])) ? $event['data']['post_id'] : 0;

		if ($this->first_post_auth($event['mode'], $event['data']['forum_id'], $post_id, $event['data']))
		{
			$event['data'] = array_merge($event['data'], array('topic_first_post_show' => ($this->request->variable('topic_first_post_show', false)) ? 1 : 0));
		}
	}

	public function submit_post_modify_sql_data($event)
	{
		if (isset($event['data']['topic_first_post_show']) && ($event['post_mode'] == 'post' || $event['post_mode'] == 'edit_first_post' || $event['post_mode'] == 'edit_topic'))
		{
			$sql_data = $event['sql_data'];
			$sql_data[TOPICS_TABLE]['sql']['topic_first_post_show'] = $event['data']['topic_first_post_show'];
			$event['sql_data'] = $sql_data;
		}
	}

	public function viewtopic_get_post_data($event)
	{
		if ($this->config['all_forum_first_post_always'] || $event['topic_data']['forum_first_post_always'] || $event['topic_data']['topic_first_post_show'])
		{
			$post_list = array($event['topic_data']['topic_first_post_id']);
			$first_post_id_key = array_search($event['topic_data']['topic_first_post_id'], $event['post_list']);

			$new_sort = true;
			foreach ($event['post_list'] as $key => $value)
			{
				if ($value == $event['topic_data']['topic_first_post_id'])
				{
					if ($first_post_id_key)
					{
						continue;
					}
					else
					{
						$new_sort = false;
						break;
					}
				}

				$post_list[$key+1] = $value;
			}

			if ($new_sort)
			{
				$sql_ary = $event['sql_ary'];
				$sql_ary['WHERE'] = $this->db->sql_in_set('p.post_id', $post_list) . ' AND u.user_id = p.poster_id';

				$event['post_list'] = $post_list;
				$event['sql_ary'] = $sql_ary;
			}
		}
	}

	public function viewtopic_assign_template_vars_before($event)
	{
		$this->template->assign_var('S_JV_EXT_FIRST_POST_HIGHLIGHT', $this->config['all_forum_first_post_always'] || $event['topic_data']['forum_first_post_always'] || $event['topic_data']['topic_first_post_show']);
	}

	public function acp_manage_forums_initialise_data($event)
	{
		$event['forum_data'] += array('forum_first_post_always' => false);
	}

	public function acp_manage_forums_request_data($event)
	{
		$event['forum_data'] += array('forum_first_post_always' => $this->request->variable('forum_first_post_always', false));
	}

	public function acp_manage_forums_display_form($event)
	{
		$event['template_data'] += array('S_JV_EXT_FIRST_POST_ALWAYS' => $event['forum_data']['forum_first_post_always']);
	}

	public function acp_board_config_edit_add($event)
	{
		if ($event['mode']== 'features')
		{
			$display_vars = $event['display_vars'];
			$new_config = array('all_forum_first_post_always' => array('lang' => 'JV_EXT_ACP_SETTING_FIRST_POST_ALWAYS_SHOW', 'validate' => 'bool', 'type' => 'radio:yes_no', 'explain' => true));

			$index = array_search('display_last_subject', array_keys($event['display_vars']['vars']));
			$pos = ($index === false) ? count($event['display_vars']['vars']) : $index + 1;

			$display_vars['vars'] = array_merge(array_slice($event['display_vars']['vars'], 0, $pos), $new_config, array_slice($event['display_vars']['vars'], $pos));

			$event['display_vars'] = $display_vars;
		}
	}

	private function first_post_auth($mode, $forum_id, $post_id, $post_data)
	{
		return ($this->user->data['is_registered'] && ($mode == 'edit' && $post_data['topic_first_post_id'] == $post_id || $mode == 'post') &&
			(
				$this->auth->acl_get('a_') ||
				$this->auth->acl_get('m_lock', $forum_id) ||
				(!empty($post_data['topic_poster']) && $this->user->data['user_id'] == $post_data['topic_poster'] && $this->auth->acl_get('f_user_lock', $forum_id))
			)
		);
	}
}
