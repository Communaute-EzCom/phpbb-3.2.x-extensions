<?php
/**
*
* @package JV Disable Outbox PM Delete
* @version $Id$
* @author 2011-2015 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2015 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\disableoutboxpmdelete\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $user, $request, $template;

	public function __construct($user, $request, $template)
	{
		$this->user = $user;
		$this->request = $request;
		$this->template = $template;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'			=> 'language',
			'core.page_footer_after'	=> 'page_footer_after',
		);
	}

	public function language($event)
	{
		$event['lang_set_ext'] = array_merge($event['lang_set_ext'], array(
			array(
				'ext_name' => 'jv/disableoutboxpmdelete',
				'lang_set' => 'common'
			)
		));
	}

	public function page_footer_after()
	{
		$id = $this->request->variable('i', '');
		$mode = $this->request->variable('mode', '');
		$f = $this->request->variable('f', 0);
		$folder = $this->request->variable('folder', '');
		$action = $this->request->variable('action', '');
		$mark_option = $this->request->variable('mark_option', '');

		if (!empty($this->user->data['is_registered']) && $id == 'pm')
		{
			if ($f == PRIVMSGS_OUTBOX && ($mark_option == 'delete_marked' || $action == 'delete'))
			{
				trigger_error('JV_NO_AUTH_OUTBOX_DELETE_MESSAGE');
			}
			else if ($mode == 'view' && $f == PRIVMSGS_OUTBOX)
			{
				$this->template->assign_var('U_DELETE', false);
			}
			else if ($folder == 'outbox')
			{
				$this->template->assign_var('S_MARK_OPTIONS', '<option value="mark_important">' . $this->user->lang['MARK_IMPORTANT'] . '</option>');
			}
		}
	}
}
