<?php
/**
*
* @package JV Local URL To Text
* @version $Id$
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\localurltotext\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	private $local_url_text;
	protected $db, $php_ext, $arcade;

	public function __construct($db, $php_ext, $arcade = null)
	{
		$this->db = $db;
		$this->php_ext = $php_ext;
		$this->arcade = $arcade;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.modify_text_for_display_after'	=> 'modify_post_data',
			'core.modify_format_display_text_after'	=> 'modify_post_data'
		);
	}

	public function modify_post_data($event)
	{
		$pq = preg_quote(generate_board_url()) . '/(?|(viewforum|viewtopic|memberlist|arcade)\.'. $this->php_ext . ')([^"<>]*?)';

		if (preg_match_all('#(<a(?:\s+(?:href="'. $pq .'"|\w+="[^"<>]*?"))+>)([^<]+?)</a>#si', $event['text'], $matches, PREG_SET_ORDER))
		{
			foreach ($matches as $k => $match)
			{
				if (empty($match[2]) || ($match[2] == 'arcade' && !$this->arcade) || ($match[4] != $match[2] . '.' . $this->php_ext . $match[3]))
				{
					continue;
				}

				if (preg_match_all('/(?:\?|&|&amp;)([uftpcg])=(\d+)/', $match[0], $m))
				{
					// Use last param.
					$key = count($m[1]) - 1;
					$type = $m[1][$key];
					$id = (!empty($m[2][$key])) ? intval($m[2][$key]) : 0;

					if ($id && in_array($type, array('u', 'p', 't', 'f', 'c', 'g')) && !empty($match[4]))
					{
						$this->local_url_text[$type][$id]['search'][] = $match[4] . '</a>';
						$this->local_url_text[$type][$id]['search'] = array_unique($this->local_url_text[$type][$id]['search']);
					}
				}
			}

			if ($this->local_url_text)
			{
				$new_data = $this->find_new_search();

				if (count($new_data))
				{
					foreach ($new_data as $type => $ids)
					{
						$this->add_replace_text($type, $ids);
					}
				}

				$event['text'] = $this->replace_text($event['text']);
			}
		}
	}

	private function add_replace_text($type, $ids)
	{
		switch ($type)
		{
			case 'u':
				$sql = 'SELECT user_id, username, user_colour FROM ' . USERS_TABLE . '
						WHERE ' . $this->db->sql_in_set('user_id', $ids);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$this->local_url_text['u'][$row['user_id']]['replace'] = ($row['user_colour']) ? '<span style="color: #' . $row['user_colour'] . ';">' . $row['username'] . '</span>' : $row['username'];
				}
				$this->db->sql_freeresult($result);
			break;

			case 'p':
				$sql_ary = array(
					'SELECT'		=> 'p.post_id, f.forum_name, t.topic_title, u.username, u.user_colour',
					'FROM'			=> array(POSTS_TABLE => 'p'),
					'LEFT_JOIN'		=> array(
						array(
							'FROM'	=> array(TOPICS_TABLE => 't'),
							'ON'	=> 'p.topic_id = t.topic_id',
						),
						array(
							'FROM'	=> array(FORUMS_TABLE => 'f'),
							'ON'	=> 't.forum_id = f.forum_id',
						),
						array(
							'FROM'	=> array(USERS_TABLE => 'u'),
							'ON'	=> 'p.poster_id = u.user_id',
						),
					),
					'WHERE'			=> $this->db->sql_in_set('p.post_id', $ids)
				);

				$sql = $this->db->sql_build_query('SELECT', $sql_ary);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$replace = ($row['user_colour']) ? '<span style="color: #' . $row['user_colour'] . ';">' . $row['username'] . '</span>' : $row['username'];
					$replace = $replace . ' @ ' . censor_text($row['topic_title']);

					$this->local_url_text['p'][$row['post_id']]['replace'] = $replace;
				}
				$this->db->sql_freeresult($result);
			break;

			case 't':
				$sql_ary = array(
					'SELECT'		=> 't.topic_id, f.forum_name, t.topic_title',
					'FROM'			=> array(TOPICS_TABLE => 't'),
					'LEFT_JOIN'		=> array(
						array(
							'FROM'	=> array(FORUMS_TABLE => 'f'),
							'ON'	=> 't.forum_id = f.forum_id',
						),
					),
					'WHERE'			=> $this->db->sql_in_set('t.topic_id', $ids)
				);

				$sql = $this->db->sql_build_query('SELECT', $sql_ary);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$this->local_url_text['t'][$row['topic_id']]['replace'] = censor_text($row['topic_title']);
				}
				$this->db->sql_freeresult($result);
			break;

			case 'f':
				$sql = 'SELECT forum_id, forum_name FROM ' . FORUMS_TABLE . '
						WHERE ' . $this->db->sql_in_set('forum_id', $ids);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$this->local_url_text['f'][$row['forum_id']]['replace'] = censor_text($row['forum_name']);
				}
				$this->db->sql_freeresult($result);
			break;

			case 'c':
				$sql = 'SELECT cat_id, cat_name FROM ' . ARCADE_CATS_TABLE . '
						WHERE ' . $this->db->sql_in_set('cat_id', $ids);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$this->local_url_text['c'][$row['cat_id']]['replace'] = $row['cat_name'];
				}
				$this->db->sql_freeresult($result);
			break;

			case 'g':
				$sql = 'SELECT game_id, game_name FROM ' . ARCADE_GAMES_TABLE . '
						WHERE ' . $this->db->sql_in_set('game_id', $ids);
				$result = $this->db->sql_query($sql);
				while ($row = $this->db->sql_fetchrow($result))
				{
					$this->local_url_text['g'][$row['game_id']]['replace'] = $row['game_name'];
				}
				$this->db->sql_freeresult($result);
			break;
		}
	}

	private function find_new_search()
	{
		$new_data = array();

		foreach ($this->local_url_text as $type => $rows)
		{
			foreach ($rows as $id => $data)
			{
				if (!isset($data['replace']))
				{
					$new_data[$type][] = (int) $id;
				}
			}

			if (!empty($new_data[$type]))
			{
				$new_data[$type] = array_filter(array_unique($new_data[$type]));

				if (!count($new_data[$type]))
				{
					unset($new_data[$type]);
				}
			}
		}

		return $new_data;
	}

	private function replace_text($text)
	{
		foreach ($this->local_url_text as $type => $data)
		{
			foreach ($data as $id => $row)
			{
				if (empty($row['replace']))
				{
					continue;
				}

				$text = str_replace($row['search'], $row['replace'] . '</a>', $text);
			}
		}

		return $text;
	}
}
