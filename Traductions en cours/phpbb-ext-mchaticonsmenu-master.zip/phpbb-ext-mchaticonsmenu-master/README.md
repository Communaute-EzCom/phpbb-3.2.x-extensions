Installing phpBB extensions: https://www.phpbb.com/extensions/installing/

More information: https://kasimi.net
