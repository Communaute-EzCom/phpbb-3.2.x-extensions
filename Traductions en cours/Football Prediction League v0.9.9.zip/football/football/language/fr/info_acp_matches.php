<?php
/**
*
* info_acp_matches.php [en]
*
* @package phpBB Extension - Football Football
* @copyright (c) 2016 football (http://football.bplaced.net)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}


if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_FOOTBALL_MATCHES'					=> 'Horaires des matchs',
	'ACP_FOOTBALL_MATCHES_MANAGE'			=> 'Gérer les horaires des matchs',
	'ACP_FOOTBALL_MATCHES_MANAGE_EXPLAIN'	=> 'Ici, vous pouvez gérer les programmes de saison et de ligue. Vous pouvez ajouter l’appariement manquant au programme et gérer les données de match d’un jour de match.',
	'ACP_FOOTBALL_MATCHES_MANAGEMENT'		=> 'Gestion des calendriers de matchs',
	'DAY'									=> 'Jours',
	'FORMULA_GUEST'							=> 'Équipe d’invités',
	'FORMULA_GUEST_EXPLAIN'					=> 'Voir les explications de l’ équipe à domicile',
	'FORMULA_HOME'							=> 'Formula Home team',
	'FORMULA_HOME_EXPLAIN'					=> 'D = sera tiré au sort <br />L 100 = Jeu des perdants 100 <br />W 100 = Jeu des gagnants 100 <br /> W 100;101 = Jeux gagnants 100 et 101 <br /> G A1 = 1. Groupe A',
	'GENERATE_MATCHES'						=> 'Complétez les matchs planifiés',
	'INVALID_MDAY_DATE'						=> 'Aucune date de match valide. ',
	'KO'									=> 'KO',
	'LEAGUE'								=> 'Ligue',
	'MATCH_BEFORE_DELIVERY'					=> 'Le début du match commence avant la mise du match du jour. Ceci n’est pas permis.',
	'MATCH_BEGIN'							=> 'Début du match',
	'MATCH_CONFIRM_DELETE'					=> 'Si vous êtes sûr, que vous avez %1$s. match à partir de %2$s saison %3$s avec toutes les données de (programme et paris) vont être supprimés ?',
	'MATCH_CREATED'							=> '%1$s match a été créé avec succès. ',
	'MATCH_DELETED'							=> 'le match a été supprimée avec succès',
	'MATCH_DETAILS'							=> 'Donnée de match',
	'MATCH_EDIT_EXPLAIN'					=> 'Ici, vous pouvez éditer un match existante. Vous pouvez régler la date, les conditions  et la formule. ',
	'MATCH_GROUP'							=> 'Match de groupe du groupe',
	'MATCH_GUEST'							=> 'Invité',
	'MATCH_HOME'							=> 'Domicile',
	'MATCH_KO'								=> 'KO match',
	'MATCH_KO_EXPLAIN'						=> 'Ce match peut mener à une prolongation ou à une séance de tirs au but. ',
	'MATCH_NUMBER'							=> 'Match numéro',
	'MATCH_ODDS'							=> 'Cotes',
	'MATCH_RATING'							=> 'Cote d’évaluation',
	'MATCH_STATUS'							=> 'Status',
	'MATCH_STATUS_EXPLAIN'					=> '-2 = le match est clôturé à la 3ème date limite. <br />-1 = le match est clôturé à la 2ème date limite <br /> 0 = ouvert (pari possible), est fermé à la date limite <br /> 1 = plus de mise possible et toujours pas de résultat <br /> 2 = le résultat temporaire se trouve avant <br /> 3 = résultat final ne soit donné.',
	'MATCH_UPDATE_FAILED'					=> 'match n’a pas pu être mis à jour. ',
	'MATCH_UPDATED'							=> 'Match mises à jour avec succès ',
	'MATCHDAY'								=> 'Journée de match',
	'MATCHDAY_MISSED'						=> 'Avant que cette action puisse être effectuée, le jour de match manquant doit être enregistré. ',
	'MATCHES_CREATE_FAILED'					=> 'Le programme n’a pas pu être achevé. ',
	'MATCHES_CREATED'						=> '%1$s Les matchs ont été créées avec succès. ',
	'MATCHES_DEF'							=> 'Matchs d’appariement disponibles ',
	'MATCHES_DEF_EXPLAIN'					=> 'Il s’agit des matchs qui ont été créés par vous ou par un autre administrateur. Vous pouvez modifier les matchs ou les supprimer. ',
	'MATCHES_NO_DELETE'						=> 'Vous ne pouvez pas supprimer des matchs. Ceci ne peut être fait que par les administrateur.',
	'MONTH'									=> 'Mois',
	'NO_LEAGUE'								=> 'Il n’y a pas de ligue dans la saison %1$s. Veuillez d’abord créer une ligue dans la saison  %1$s. ',
	'NO_MATCH'								=> 'Ce jumelage n’existe pas. ',
	'NO_MATCH_BEGIN'						=> 'Le début du match est absent. ',
	'NO_MATCHDAY'							=> 'Il n’y a pas de jour de match dans %1$s saison %2$s. Veuillez d’abord créer des jours de matchs ',
	'NO_MATCHES_CREATED'					=> 'Aucun match n’a été inscrit jusqu’à présent. ',
	'NO_SEASON'								=> 'Il n’y a pas de saison. Veuillez d’abord créer une saison.',
	'ODD_1'									=> 'Domicile',
	'ODD_x'									=> 'Nul',
	'ODD_2'									=> 'Extérieur',
	'PREDICTION_LEAGUE'						=> 'Prediction Ligue',
	'SEASON'								=> 'Saison',
	'SELECT_MATCHDAY'						=> 'Jour de match choisir',
	'TOO_LARGE_MATCH_BEGIN_H'				=> 'L’information horaire, le match commençant trop largement. ',
	'TOO_LARGE_MATCH_BEGIN_MIN'				=> 'Informations sur les minutes, le match commençant dans trop longtemps. ',
	'TOO_SMALL_MATCH_BEGIN_H'				=> 'Informations horaires avec un début de match trop petit. ',
	'TOO_SMALL_MATCH_BEGIN_MIN'				=> 'Informations sur les minutes avec un début de match trop petit. ',
	'UNKNOWN'								=> 'Pas encore célèbre',
	'YEAR'									=> 'Année',
));
