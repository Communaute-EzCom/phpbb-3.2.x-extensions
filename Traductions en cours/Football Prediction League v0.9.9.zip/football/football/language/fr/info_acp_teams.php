<?php
/**
*
* info_acp_teams.php [en]
*
* @package phpBB Extension - Football Football
* @copyright (c) 2016 football (http://football.bplaced.net)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}


if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_FOOTBALL_TEAMS'					=> 'Équipes',
	'ACP_FOOTBALL_TEAMS_MANAGE'				=> 'Gérer les équipes',
	'ACP_FOOTBALL_TEAMS_MANAGE_EXPLAIN'		=> 'Ici, vous pouvez assigner des équipes d’une saison, d’une ligue. Vous pouvez supprimer ceux qui passent ou changer ou créer une nouvelle équipe, ainsi que le type, le nombre de jours de match, les victoires, le nom et numéro de l’équipe. ',
	'ACP_FOOTBALL_TEAMS_MANAGEMENT'			=> 'Gestion d’équipe',
	'ADD_TEAM'								=> 'Ajouter une équipe à la ligue',
	'LEAGUE'								=> 'Ligue',
	'MATCHDAY'								=> 'Jour de match',
	'NEW_TEAM'								=> 'Nouvelle équipe',
	'NO_LEAGUE'								=> 'Aucune ligue n’existe dans la saison %1$s. S’il vous plaît, créez d’’abord une ligue dans la saison %1$s. ',
	'NO_MATCHDAYS'							=> 'S’il vous plaît, mettre en place les  premiers jours de match , parce que les équipes doivent être assignées avec des rondes KO un jour de match. ',
	'NO_SEASON'								=> 'Il n’y a pas de saison. S’il vous plaît, créer d’abord une saison. ',
	'NO_TEAM'								=> 'Aucune équipe donnée. ',
	'NO_TEAMS_CREATED'						=> 'Aucune équipe n’a été créée jusqu’à maintenant. ',
	'NO_TEAMSYMBOL'							=> 'Pas de logo',
	'PREDICTION_LEAGUE'						=> 'Prédictiondiction Ligue',
	'SEASON'								=> 'Saison',
	'SELECT_LEAGUE'							=> 'Sélectionnez une ligue',
	'TEAM'									=> 'Équipe',
	'TEAM_ADDED'							=> 'Équipe ajoutée avec succès. ',
	'TEAM_AWAY'								=> 'absente',
	'TEAM_CONFIRM_DELETE'					=> 'Êtes vous sur de vouloir supprimer l’équipe de %1$s de la saison: %2$s de la ligue: %3$s et de toute ces donnée? ',
	'TEAM_CREATE_FAILED'					=> 'L’équipe n’a pas pu être créée. ',
	'TEAM_CREATED'							=> 'L’équipe crée avec succès. ',
	'TEAM_CURRENT'							=> 'Équipe spécialisée',
	'TEAM_DEF'								=> 'Équipes existantes',
	'TEAM_DEF_EXPLAIN'						=> 'Ce sont les équipes qui ont été créées par vous ou par un autre administrateur. Vous pouvez modifier les paramètres de l’équipe ou supprimer des équipes. ',
	'TEAM_DELETE'							=> 'Supprimer l’équipe',
	'TEAM_DELETED'							=> 'Equipe supprimée',
	'TEAM_DETAILS'							=> 'Données d’équipe',
	'TEAM_EDIT_EXPLAIN'						=> 'Ici, vous pouvez travailler au sein d’une équipe existante. Vous pouvez changer le nom, le nom abrégé de l’équipe ainsi que les emblèmes de l’équipe. ',
	'TEAM_GROUP'							=> 'Matches de groupe en groupe',
	'TEAM_GROUP_EXPLAIN'					=> 'Lettre du groupe dans lequel les matches de groupe sont refusés. ',
	'TEAM_MATCHES'							=> 'Matches',
	'TEAM_NAME'								=> 'Nom de l’équipe',
	'TEAM_NAME_DOUBLE'						=> 'Le nom de l’équipe est déjà utilisé ou a été attribué deux fois. ',
	'TEAM_NUMBER'							=> 'Ce n’est pas un numéro d’équipe valide. Le numéro d’équipe doit être compris entre 0 et 65535. ',
	'TEAM_ROUND'							=> 'Qualifications jusqu’au jour du match',
	'TEAM_ROUND_EXPLAIN'					=> 'Journée de match, l’équipe s’est qualifiée pour le moment. A propos de ce paramètre, seules les équipes sont proposées par la production du programme pour le choix qui se sont également qualifiées pour le tour net-parler. A propos du point de menu Qualification cette valeur peut être automatiquement mise après la fin du tour automatiquement pour toutes les équipes certifiées. ',
	'TEAM_SHORT'							=> 'Nom court de l’équipe:',
	'TEAM_SHORT_DOUBLE'						=> 'Le nom court est déjà utilisé ou a été attribué deux fois. ',
	'TEAM_SHORT_EXPLAIN'					=> 'Maximum 10 caractères pour  nom court de l’équipe. ',
	'TEAM_SYMBOL'							=> 'Blasons d’équipe',
	'TEAM_SYMBOL_EXPLAIN'					=> 'Les blasons facultatifs de l’équipe doivent être de 28x28 pixels. ',
	'TEAM_TAKEN'							=> 'Cette équipe existe déjà dans cette ligue. S’il vous plaît, choisissez un autre numéro d’équipe. ',
	'TEAM_UPDATE_FAILED'					=> 'Les paramètres d’équipe n’ont pas pu être mis à jour. ',
	'TEAM_UPDATED'							=> 'Mise à jour des paramètres de l’équipe avec succès. ',
	'TEAMS_NO_DELETE'						=> 'Vous ne pouvez supprimer aucune équipe. Seuls les fondateurs sont autorisés à le faire.',
	'TOO_LARGE_TEAM'						=> 'TL’ID d’équipe donnée doit être numérique (1-999999). S’il vous plaît, donnez un plus petit numéro d’équipe. ',
	'TOO_SHORT_TEAM_NAME'					=> 'Le nom de l’équipe doit être long d’au moins 3 caractères. ',
	'TOO_SHORT_TEAM_SHORT'					=> 'Le nom abrégé doit être long d’au moins 1 caractères. ',
	'TOO_SMALL_TEAM'						=> 'L’ID d’équipe donnée doit être numérique (1-999999). S’il vous plaît, donnez un plus grand numéro d’équipe.  ',
	'WRONG_DATA_TEAM_GROUP'					=> 'Aucun groupe valide pour les matches de groupe. Les groupes valides sont A-Z.',
));
