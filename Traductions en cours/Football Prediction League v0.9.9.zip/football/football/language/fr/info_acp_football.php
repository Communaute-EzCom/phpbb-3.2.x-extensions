<?php
/**
*
* info_acp_football.php [en]
*
* @package phpBB Extension - Football Football
* @copyright (c) 2016 football (http://football.bplaced.net)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}


if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_FOOTBALL'							=> 'Football',
	'ACP_FOOTBALL_MANAGEMENT'				=> 'Gérer Prono-Foot',
	'ACP_FOOTBALL_OPERATION'				=> 'Opérations de match',
	'ACP_FOOTBALL_MANAGE'					=> 'Gérer la liste des appareils',
	'ACP_FOOTBALL_CONFIGURATION'			=> 'Configuration de Prono-Foot',
	'ACP_FOOTBALL_SETTINGS'					=> 'Paramètres de Prono-Foot',
	'ACP_FOOTBALL_SETTINGS_EXPLAIN'			=> 'Ici, vous pouvez effectuer quelques réglages de base de Prono-Foot, lui donner un nom et une description appropriés et définir une annonce de côté de football et d’autres valeurs. ',
	'DISABLE_FOOTBALL'						=> 'Désactiver Prono-Foot',
	'DISABLE_FOOTBALL_EXPLAIN'				=> 'Vous pouvez désactiver Prono-Foot pour tous les utilisateurs. Si vous le souhaitez, vous pouvez afficher un message court (jusqu’à 255 signes). ',
	'DISPLAY_LAST_USERS'					=> 'Nombre de visiteurs du forum à afficher',
	'DISPLAY_LAST_USERS_EXPLAIN'			=> 'Limite les derniers visiteurs à afficher en bloc. 0 est utilisé pour supprimer l’affichage du bloc. ',
	'DISPLAY_LAST_RESULTS'					=> 'Nombre de résultats de match à afficher',
	'DISPLAY_LAST_RESULTS_EXPLAIN'			=> 'Limite les résultats du dernier match à afficher en bloc. Si plus de matches sont joués le dernier jour, tous les résultats de ce jour sont affichés. 0 est utilisé pour supprimer l’affichage du bloc. ',
	'DISPLAY_RANKS'							=> 'Nombre d’utilisateurs indiqués dans le classement total',
	'DISPLAY_RANKS_EXPLAIN'					=> 'Annonce des utilisateurs dans les listes de classement. Le ownrank est suspendu si nécessaire ci-dessous. ',
	'FOOTBALL_CODE'							=> 'Prono-Foot Code',
	'FOOTBALL_CODE_EXPLAIN'					=> 'Code d’accès au Prono-Foot, e.g., for cronjobs. ',
	'FOOTBALL_FULLSCREEN'					=> 'Pages Prono-Foot en mode plein écran',
	'FOOTBALL_FULLSCREEN_EXPLAIN'			=> 'Vous pouvez ainsi, contrairement au forum, afficher des pages Prono-Foot avec des marges minimales. ',
	'FOOTBALL_HEADER_ENABLE'				=> 'Utiliser l’image d’en-tête par ligue',
	'FOOTBALL_HEADER_ENABLE_EXPLAIN'		=> 'Ici vous pouvez définir si chaque ligue l’image associée à afficher dans l’en-tête. ',
	'FOOTBALL_INFO'							=> 'Afficher les informations Prono-Foots',
	'FOOTBALL_INFO_EXPLAIN'					=> 'ci, vous pouvez activer des informations courtes (jusqu’à 255 signes) au-dessus des côtés de football de phpBB3. ',
	'FOOTBALL_NAME'							=> 'Nom du Prono-Foot',
	'FOOTBALL_NAME_EXPLAIN'					=> 'Nom utilisé dans le menu Prono-Foot, en tant que lien vers la page d’accueil de Prono-Foot. ',
	'FOOTBALL_OVERRIDE_STYLE'				=> 'Remplacer le style',
	'FOOTBALL_OVERRIDE_STYLE_EXPLAIN'		=> 'Remplace le style dans Prono-Foot avec le style Prono-Foot par défaut. ',
	'FOOTBALL_MENU'							=> 'Afficher le menu Prono-Foot',
	'FOOTBALL_MENU_EXPLAIN'					=> 'Afficher le menu déroulant Prono-Foot dans la barre de navigation? ',
	'FOOTBALL_STYLE'						=> 'Style Prono-Foot par défaut',
	'FOOTBALL_UPDATE_SOURCE'				=> 'Lien vers la source de mise à jour',
	'FOOTBALL_UPDATE_SOURCE_EXPLAIN'		=> 'Mettre à jour le lien. Si vide, <var>http://football.bplaced.net/football/xml/football_xml_season.php</var> est automatiquement sélectionné. ',
	'FOOTBALL_UPDATE_CODE'					=> 'Mettre à jour du code',
	'FOOTBALL_UPDATE_CODE_EXPLAIN'			=> 'Seulement avec ce code, les mises à jour peuvent être téléchargées depuis cette page. ',
	'GUEST_VIEW'							=> 'Prono-Foot pour les invités visibles',
	'GUEST_VIEW_EXPLAIN'					=> 'Les invités devraient-ils pouvoir voir le Prono-Foot?',
	'USER_VIEW'								=> 'Prono-Foot uniquement pour les participants visibles',
	'USER_VIEW_EXPLAIN'						=> 'Le Prono-Foot devrait-il seulement être visible pour les participants?',
	'TIME_SHIFT'							=> 'Décalage dans le temps',
	'TIME_SHIFT_EXPLAIN'					=> 'Différence entre les heures et le fuseau horaire du panneau si l’hôte se trouve dans un autre fuseau horaire, de sorte que la remise des pourboires fonctionne correctement. ',
	'LEFT_COLUMN'							=> 'Largeur de la colonne de gauche en pixels',
	'LEFT_COLUMN_EXPLAIN'					=> 'Largeur optimale 180 pixels. Cette valeur ne devrait pas être insuffisante. ',
	'PREDICTION_LEAGUE'						=> 'Prono-Foot',
	'RIGHT_COLUMN'							=> 'Largeur de colonne droite en pixels',
	'RIGHT_COLUMN_EXPLAIN'					=> 'Optimalement 180 pixels. Cette valeur est rediffusée par des insertions externes si nécessaire. ',
	'USERS_PAGE'							=> 'Utilisateur par côté',
	'USERS_PAGE_EXPLAIN'					=> 'Nombre d’utilisateurs affichés dans la liste de classement et tous les paris. ',
	'WIN_NAME'								=> 'Gagner',
	'WIN_NAME_EXPLAIN'						=> 'Le nom ou la devise que vous voulez désaffecter pour les victoires dans le Prono-Foot',
	'ANNOUNCEMENT_TOPIC'					=> 'Annonce de publication',
	'CURRENT_VERSION'						=> 'Version actuelle',
	'DOWNLOAD_LATEST'						=> 'Télécharger la dernière version',
	'LATEST_VERSION'						=> 'Dernière version',
	'NOT_UP_TO_DATE'						=> '%s n’est pas à jour',
	'RELEASE_ANNOUNCEMENT'					=> 'Sujet de l’annonce',
	'UP_TO_DATE'							=> '%s est à jour',
	'FOOTBALL_VERSION_CHECK'				=> 'Vérification de la version de l’extension Prono-Foot',
	'ACP_FOOTBALL_FEATURES'					=> 'Caractéristiques du Prono-Foot',
	'ACP_FOOTBALL_FEATURES_EXPLAIN'			=> 'Ici vous pouvez activer certaines fonctions du Prono-Foot ou désactiver',
	'AUTO'									=> 'Automatique',
	'BANK'									=> 'Gérer le compte Prono-Foot',
	'BANK_EXPLAIN'							=> 'Les comptes Prono-Foot devraient-ils être maintenus avec des paris et des profits?',
	'FOOTBALL_BREADCRUMB'					=> 'Montrer le fil d’Ariane Prono-Foot',
	'FOOTBALL_BREADCRUMB_EXPLAIN'			=> 'Afficher un lien de miettes de pain à Prono-Foot? ',
	'FOOTBALL_SEASON_START'					=> 'Démarer la saison',
	'FOOTBALL_SEASON_START_EXPLAIN'			=> 'Démarer dans cette saison ou dans la saison auto-détectée si elle n’est pas déjà sélectionnée. ',
	'FOOTBALL_REMEMBER_ENABLE'				=> 'Activer le travail cron pour le rappel par e-mail',
	'FOOTBALL_REMEMBER_ENABLE_EXPLAIN'		=> 'Ici vous pouvez spécifier si un rappel doit être envoyé il y a 1 jour.',
	'FOOTBALL_REMEMBER_NEXT_RUN'			=> 'Suivant Cronjoblauf pour rappel par e-mail',
	'FOOTBALL_REMEMBER_NEXT_RUN_EXPLAIN'	=> ' Ici vous pouvez spécifier quand le travail cron pour le rappel Email sera rappelé. Après l’exécution du travail cron pour le jour suivant sera reportée à la même heure.',
	'FOOTBALL_SIDE'							=> 'Afficher la barre latérale Prono-Foot',
	'FOOTBALL_SIDE_EXPLAIN'					=> 'Afficher la barre latérale Prono-Foot avec les éléments de menu? ',
	'FOUNDER_DELETE'						=> 'Seuls les membres de la fondation peuvent supprimer',
	'FOUNDER_DELETE_EXPLAIN'				=> 'Suppression des données Prono-Foot comme les saisons, les ligues, les équipes, les matches et les horaires uniquement à la limite des membres de la fondation. ',
	'RESULTS_AT_TIME'						=> 'Entrer les résultats de la finale seulement après avoir joué',
	'RESULTS_AT_TIME_EXPLAIN'				=> 'Relâchez l’entrée des résultats de la correspondance finale dans Adminbereich seulement après avoir joué. L’entrée des résultats de correspondance temporaire par les utilisateurs est indépendante de cela. ',
	'SAME_ALLOWED'							=> 'Tous les paris sur une journée immédiatement',
	'SAME_ALLOWED_EXPLAIN'					=> 'Paris identiques (pourboire) avec tous les matches d’un permis de match ou interdire. ',
	'ULT_POINTS'							=> 'Intégrer les points ultimes',
	'ULT_POINTS_EXPLAIN'					=> 'Devrait-il être possible de laisser régler les points ou les profits dans Ultimate Points? De plus, les points ultimes doivent être installés. ',
	'ULT_POINTS_FACTOR'						=> 'Facteur de points ultime',
	'ULT_POINTS_FACTOR_EXPLAIN'				=> 'Facteur sur les points de la journée pour être créditeur dans les points ultimes. ',
	'UP_NONE'								=> 'Aucun',
	'UP_POINTS'								=> 'Points',
	'UP_WINS'								=> 'Victoires',
	'VIEW_BETS'								=> 'Afficher les paris immédiatement',
	'VIEW_BETS_EXPLAIN'						=> 'Tous les paris doivent-ils être indiqués immédiatement? Si non, ils ne sont indiqués qu’après la livraison. ',
	'VIEW_CURRENT'							=> 'Afficher la ligue en cours au démarrage',
	'VIEW_CURRENT_EXPLAIN'					=> 'Afficher la ligue avec le prochain match quand aucune ligue n’est sélectionnée? Sinon commence en première ligue',
	'VIEW_TENDENCIES'						=> 'Afficher les tendances immédiatement',
	'VIEW_TENDENCIES_EXPLAIN'				=> 'Est-ce que toutes les réponses doivent être indiquées immédiatement? Si non, ils ne sont indiqués qu’après la livraison. ',
	'WIN_HITS02'							=> 'Gains évaluation de coup direct avec des points éloignés',
	'WIN_HITS02_EXPLAIN'					=> 'Faut-il indiquer les gains de l’évaluation directe avec les points absents? Si non, il faut s’assurer qu’en plus aucun gain n’a été déposé dans les ligues existantes. ',
	'ACP_FOOTBALL_MENU'						=> 'Paramètres du menu',
	'ACP_FOOTBALL_MENU_EXPLAIN'				=> 'Ici vous pouvez déposer des références communautaires en tant que Menueinträge pour le menu Prono-Foot. Vous pouvez choisir librement le Menutext, en plus, donner un autre nom au lien vers la communauté. ',
	'MENU_DESC1'							=> 'Légende Lien 1',
	'MENU_DESC1_EXPLAIN'					=> 'La légende des liens ne peut pas contenir de caractères spéciaux non autorisés et ne doit pas dépasser 20 caractères. ',
	'MENU_DESC2'							=> 'Légende Lien 2',
	'MENU_DESC3'							=> 'Légende Lien 3',
	'MENU_LINK1'							=> 'Http-Lien 1',
	'MENU_LINK1_EXPLAIN'					=> 'Veuillez entrer les liens http ici. ',
	'MENU_LINK2'							=> 'Http-Lien 2',
	'MENU_LINK3'							=> 'Http-Lien 3',
	'MENU_NO_LINK'							=> 'Aucun dépôt de lien communautaire',
	'ACP_FOOTBALL_USERGUIDE'				=> 'Football guide',
	'ACP_FOOTBALL_USERGUIDE_EXPLAIN'		=> 'Ici vous pouvez trouver de l’aide pour les réglages du phpBB3 Football MOD.<br />Si vous avez des questions, s’il vous plaît vérifiez toujours ici!',
	'LOG_FOOTBALL_FEATURES'					=> '<strong>Prono-Foot caractéristiques modifiées</strong>',
	'LOG_FOOTBALL_MENU'						=> '<strong>Prono-Foot menu changé</strong>',
	'LOG_FOOTBALL_SETTINGS'					=> '<strong>Prono-Foot paramètres modifiés</strong>',
	'LOG_FOOTBALL_MSG_TEST'					=> 'Demander %s.',
	'LOG_FOOTBALL_MSG_TEST_TRAVEL'			=> 'Appelez avec un voyage dans le temps pour %s.',
	'LOG_FOOTBALL_REMEMBER_CRON'			=> 'Cronjob Football souvenez-vous %s',
	'LOG_FOOTBALL_REMEMBER_CRON_TEST'		=> 'Cronjob Football rappelez-vous appel d’essai%s',
	'LOG_PL_BACKUP'							=> '<strong>Prono-Foot sauvegarde</strong>',
	'FOOTBALL_REMEMBER_SUBJECT'				=> 'Veuillez parier %1$s %2$d. jour de match',
	'FOOTBALL_REMEMBER_SUBJECT_BOARD'		=> 'Envoi de mails de rappel %1$s %2$d',
	'FOOTBALL_REMEMBER_ERROR_EMAIL'			=> '%1$s reminder email to: %2$d échoué',
	'FOOTBALL_REMEMBER_ERROR_EMAIL_BOARD'	=> '%1$s bordereau de rappel de liste d’email a: %2$d échoué',
	'FOOTBALL_REMEMBER_NOBODY'				=> ' 	Personne n’a besoin d’être rappelé.',
	'FOOTBALL_REMEMBER_NO_DELIVERY'			=> 'Aucune prédiction à venir dans la période.',
	'FOOTBALL_REMEMBER_SEND'				=> '%1$s e-mail de rappel à: %2$d',
));
