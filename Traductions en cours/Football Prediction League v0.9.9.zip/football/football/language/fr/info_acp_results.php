<?php
/**
*
* info_acp_results.php [en]
*
* @package phpBB Extension - Football Football
* @copyright (c) 2016 football (http://football.bplaced.net)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}


if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_FOOTBALL_RESULTS'					=> 'Résultats du match',
	'ACP_FOOTBALL_RESULTS_MANAGE'			=> 'Gérer les résultats de match',
	'ACP_FOOTBALL_RESULTS_MANAGE_EXPLAIN'	=> 'Ici vous pouvez confirmer les résultats du match, donner, retirer ou prendre de l’évaluation.',
	'ACP_FOOTBALL_RESULTS_MANAGEMENT'		=> 'Gestion des résultats des matchs',
	'ADVICE'								=> 'Informations',
	'BETS_AND_RANKS'						=> 'Paris et classements',
	'DAY'									=> 'Jour',
	'DELETE'								=> 'Supprimer',
	'DELETE_EXPLAIN'						=> 'Supprimer le résultat du match et le statut sur 1 rang. ',
	'GUEST'									=> 'Invité',
	'HOME'									=> 'Domicile',
	'LEAGUE'								=> 'Ligue',
	'MATCH_BEGIN'							=> 'Début de match',
	'MATCH_STATUS_TITLE'					=> '-2=match is closed in the 3rd deadline -1=match is closed in the 2nd deadline 0=open (bet delivery possibly), is closed in the deadline 1=keine bet delivery more possibly and still no result 2=vorläufiges result lies before 3=endgültiges result lies before 4-6 = like 1-3, nevertheless, without evaluation. ',
	'MATCHDAY'								=> 'Journée de match',
	'MONTH'									=> 'Mois',
	'NO_LEAGUE'								=> 'Aucune ligue n’existe dans la saison %1$s. S’il vous plaît, créez d’abord une ligue dans la saison %1$s. ',
	'NO_MATCHDAY'							=> 'No matchday exists in %1$s season %2$s. Please, first matchdays create. ',
	'NO_MATCHES_CREATED'					=> 'Aucun match d’accouplement n’a été déposé jusqu’à présent.. ',
	'NO_SEASON'								=> 'Il n’y a pas de saison. Veuillez créer d’abord une saison. ',
	'NO_VALUATION'							=> 'Pas d’évaluation',
	'NO_VALUATION_EXPLAIN'					=> 'Take match from the evaluation, because this was shifted or was manipulated. ',
	'NUMBER'								=> 'No.',
	'OVERTIME'								=> 'Temps supplémentaire',
	'OVERTIME_EXPLAIN'						=> 'Résultat du match, y compris les tirs au but et les prolongations. ',
	'PREDICTION_LEAGUE'						=> 'Prediction Ligue',
	'RANKING'								=> 'Liste de classement',
	'RESULT'								=> 'Résultats finals',
	'RESULT_DELETED'						=> '%1$s e résultat du match a été supprimé. ',
	'RESULT_DETAILS'						=> 'Résultats du match',
	'RESULT_EXPLAIN'						=> 'Résultat du match après 90 minutes.',
	'RESULT_NO_VALUATION'					=> '%1$s Le match a été retiré du classement. ',
	'RESULT_SAVED'							=> '%1$s le résultat du match a été enregistré. ',
	'RESULTS_DELETED'						=> '%1$s les résultats des matchs ont été supprimés. ',
	'RESULTS_NO_VALUATION'					=> '%1$s Les matchs ont été retiré du classement. ',
	'RESULTS_SAVED'							=> '%1$s les résultats des matchs ont été enregistrés. ',
	'SAVE'									=> 'Envoyer',
	'SAVE_FAILED'							=> 'Les résultats du match n’ont pas pu être sauvegardés. ',
	'SEASON'								=> 'Saison',
	'SELECT'								=> 'Choix',
	'SELECT_EXPLAIN'						=> 'Only the matches marked here are not evaluated / removed stored/. ',
	'SELECT_MATCHDAY'						=> 'Matchday choose',
	'SET_STATUS_TO'							=> 'Le statut de la journée de match a été placé sur',
	'STATUS'								=> 'Statut',
	'VS'									=> 'Rencontre',
	'YEAR'									=> 'Année',
));
