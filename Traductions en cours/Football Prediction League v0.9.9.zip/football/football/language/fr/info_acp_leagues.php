<?php
/**
*
* info_acp_leagues.php [en]
*
* @package phpBB Extension - Football Football
* @copyright (c) 2016 football (http://football.bplaced.net)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}


if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_FOOTBALL_LEAGUES'					=> 'Ligues',
	'ACP_FOOTBALL_LEAGUES_MANAGE'			=> 'Gérer les ligues',
	'ACP_FOOTBALL_LEAGUES_MANAGE_EXPLAIN'	=> 'Ici vous pouvez administrer toutes les ligues. Vous pouvez supprimer les passes, changer ou créer une nouvelle ligue, ainsi que modifier le type, le nombre de matchs, les victoires, le nom et le pseudonyme de la ligue. ',
	'ACP_FOOTBALL_LEAGUES_MANAGEMENT'		=> 'Gestion des ligues',
	'ADD_GROUP'								=> 'Ajouter un groupe',
	'ADD_USERS'								=> 'Ajouter un utilisateur',
	'ADD_USERS_EXPLAIN'						=> 'Ici, vous pouvez ajouter un nouvel utilisateur à la Ligue de prédiction. S’il vous plaît, donnez des noms d’utilisateurs par ligne. ',
	'ALL_USERS'								=> 'Tous les utilisateurs',
	'BET_POINTS'							=> 'Pari',
	'BET_POINTS_EXPLAIN'					=> 'montant de la mise avant le début de la saison',
	'BET_TYPE_KO'							=> 'Parier sur KO-Matches',
	'BET_TYPE_KO_EXPLAIN'					=> 'Sur quel résultat devrait-on parier avec les matchs KO?',
	'CHECK_HIT_WINS'						=> 'Erreur lors de la frappe directe. Corrigez s’il vous plaît. ',
	'CHECK_HITS02_WINS'						=> 'Erreur lors de la frappe directe avec des points absents. Corrigez s’il vous plaît.. ',
	'CHECK_MATCHDAY_WINS'					=> 'Erreur gagne matchday. Corrigez s’il vous plaît. ',
	'CHECK_RULES_POST_ID'					=> 'Le numéro de contribution avec les règles doit être déposé à l’entrée par l’utilisateur. ',
	'CHECK_SEASON_WINS'						=> 'Erreur de gains saisonniers. Corrigez s’il vous plaît.. ',
	'CREATE_LEAGUE'							=> 'Créer une nouvelle ligue',
	'LEAGUE_BET_IN_TIME'					=> 'Remise des paris jusqu’au début de la partie correspondante',
	'LEAGUE_BET_IN_TIME_EXPLAIN'			=> 'Est-ce que l’utilisateur peut parier jusqu’au début de la partie correspondante, ou est-ce que la livraison de tous les matchs d’une journée ne peut être effectuée que jusqu’à trois (trois) rendez-vous?',
	'LEAGUE_CHAMP'							=> 'Championnat',
	'LEAGUE_CONFIRM_DELETE'					=> 'Etes-vous sûr (e) de vouloir supprimer %1$s de la saison %2$s avec toutes les données (matchdays, matches, paris et classements)?',
	'LEAGUE_CREATE_FAILED'					=> 'La ligue n’a pas pu être créée. ',
	'LEAGUE_CREATED'						=> 'La ligue a été créée avec succès. ',
	'LEAGUE_CURRENT'						=> 'Ligue actuelle',
	'LEAGUE_DEF'							=> 'Championnats existants',
	'LEAGUE_DEF_EXPLAIN'					=> 'Ce sont des ligues qui ont été créées par vous ou un autre administrateur. Vous pouvez modifier les paramètres de la ligue ou supprimer des ligues. ',
	'LEAGUE_DELETE'							=> 'Supprimer la ligue',
	'LEAGUE_DELETED'						=> 'Ligue supprimée',
	'LEAGUE_DETAILS'						=> 'Détails de la ligue',
	'LEAGUE_EDIT_EXPLAIN'					=> 'Ici vous pouvez éditer sur une ligue existante. Vous pouvez changer le type, le nombre de matchs, les victoires, le nom et le nom abrégé. ',
	'LEAGUE_JOIN_BY_USER'					=> 'S’inscrire à cette ligue de prédiction par les utilisateurs',
	'LEAGUE_JOIN_BY_USER_EXPLAIN'			=> 'Les utilisateurs du forum devraient-ils pouvoir se joindre à cette ligue de prédiction, ou seuls les administrateurs sont autorisés à le faire?',
	'LEAGUE_JOIN_IN_SEASON'					=> 'S’inscrire à cette ligue de prédiction au cours de la saison',
	'LEAGUE_JOIN_IN_SEASON_EXPLAIN'			=> 'Est-ce que les utilisateurs du forum peuvent participer pendant la saison?',
	'LEAGUE_KO'								=> 'KO round',
	'LEAGUE_MATCHDAYS'						=> 'Numéro des matchs',
	'LEAGUE_MATCHDAYS_EMPTY'				=> 'Le nombre de matches est absent. ',
	'LEAGUE_MATCHDAYS_EXPLAIN'				=> 'Avec le calcul du nombre de matches, il faut considérer que les matchs de différents tours peuvent être résumés en une journée, donc cela ne doit pas être tapé sur une ou plusieurs parties. ',
	'LEAGUE_MATCHES'						=> 'Nombre de matches le jour du match',
	'LEAGUE_MATCHES_EXPLAIN'				=> 'KO rounds avec un nombre différent de matches les jours de match, doit être réglé ici 0. ',
	'LEAGUE_MEMBERS'						=> 'Participant à la ligue de prédiction',
	'LEAGUE_NAME'							=> 'Nom de la ligue',
	'LEAGUE_NAME_EMPTY'						=> 'Le nom de la ligue doit être au moins 3 lettres. ',
	'LEAGUE_NO_MEMBER'						=> 'La ligue n’a pas d’utilisateurs',
	'LEAGUE_NUMBER'							=> 'La ligue donnée doit être numérique. S’il vous plaît, donnez un numéro de ligue de 1-99. ',
	'LEAGUE_POINTS'							=> 'Mode Points de cette Ligue de Prédiction',
	'LEAGUE_POINTS_DIFF'					=> 'Point correct de la différence de buts',
	'LEAGUE_POINTS_DIFF_EXPLAIN'			=> 'Points pour la différence de buts correcte. ',
	'LEAGUE_POINTS_HIT'						=> 'Points pour un résultat de coorption',
	'LEAGUE_POINTS_HIT_EXPLAIN'				=> 'Points si le pari avec le résultat est d’accord. ',
	'LEAGUE_POINTS_LAST'					=> 'Points depuis le dernier si quelqu’un n’a pas misé',
	'LEAGUE_POINTS_LAST_EXPLAIN'			=> 'L’utilisateur sans pari devrait-il recevoir automatiquement les points du pire utilisateur? Cela peut être, peut-être, aussi 0 points. ',
	'LEAGUE_POINTS_MODE'					=> 'Points Modus',
	'LEAGUE_POINTS_MODE_EXPLAIN'			=> '1 = points de vie directs et avec une bonne tendance jamais divergente porte un point de moins, cependant, l’esprit. Points de tendance Avec dessiner une déduction facile seulement avec la porte divergente. <br /> 2 = comme 1 déduction néanmoins pleine avec divergence de grille. <br /> 3 = coup direct ou points de tendance. <br /> 4 = points de vie directs, points de différence ou points de tendance. <br /> 5 = comme 4 sans points de différence sur le tirage. <br /> 6 = coup direct et points de tendance; points de différence sur la tendance de tirage à droite. ',
	'LEAGUE_POINTS_TENDENCY'				=> 'Points avec bonne tendance',
	'LEAGUE_POINTS_TENDENCY_EXPLAIN'		=> 'Points ou minimum de points avec tendance correcte. ',
	'LEAGUE_RULES_POST_ID'					=> 'Numéro de contribution avec les règles',
	'LEAGUE_RULES_POST_ID_EXPLAIN'			=> 'Post-ID avec les règles de cette ligue-Prediction League. Contribution indiquée annoncera au badge le Post-Id. ',
	'LEAGUE_SHORT'							=> 'Ligue du nom court',
	'LEAGUE_SHORT_EMPTY'					=> 'Le nom abrégé est absent. ',
	'LEAGUE_SHORT_EXPLAIN'					=> 'Abréviation à 3 chiffres, par exemple, e.g., 1SHEET, 2SHEET, German Football Association, CENTILITRE or tablespoon to the identification of the league in the download file. ',
	'LEAGUE_TAKEN'							=> 'Cette ligue existe déjà cette saison. S’il vous plaît, un autre numéro de la ligue sélectionne. ',
	'LEAGUE_TYPE'							=> 'Type de ligue',
	'LEAGUE_TYPE_EXPLAIN'					=> 'Avec des tours de match avec les matchs qui peuvent être décidés sur un round de KO rallongé est à choisir ici, même si les matchs simples de ce tour se terminent après 90 minutes. ',
	'LEAGUE_UPDATE_FAILED'					=> 'Les paramètres de la ligue n’ont pas pu être mis à jour. ',
	'LEAGUE_UPDATED'						=> 'Met à jour les paramètres de la ligue avec succès. ',
	'LEAGUE_USERS_ADD'						=> 'Utilisateur ajouté à la ligue. ',
	'LEAGUE_USERS_REMOVE'					=> 'Utilisateur de la ligue à distance. ',
	'LEAGUE_WIN_EXPLAIN'					=> 'Avec les champs de profit suivants, les gains sont classés par; donner à part. Donc 10.50; 5 pour le rang 1 = 10.50 euros et le rang 2 = 5 euros',
	'LEAGUE_WIN_HITS'						=> 'Win of direct hit evaluation',
	'LEAGUE_WIN_HITS_AWAY'					=> 'Gagnez une évaluation directe avec des points éloignés',
	'LEAGUE_WIN_HITS_AWAY_EXPLAIN'			=> 'Gagnez en euro pour le premier de l’évaluation de coup direct avec ceux que l’équipe adverse a pointés. ',
	'LEAGUE_WIN_HITS_EXPLAIN'				=> 'Gagnez en euro pour le premier classement de l’évaluation directe. ',
	'LEAGUE_WIN_MATCHDAYS'					=> 'Jour des profits',
	'LEAGUE_WIN_MATCHDAYS_EXPLAIN'			=> 'L’ordre gagne la journée. ',
	'LEAGUE_WIN_SEASON'						=> 'Bénéfices de la saison',
	'LEAGUE_WIN_SEASON_EXPLAIN'				=> 'Une commande unique gagne à la fin de la saison. ',
	'LEAGUE_WINS'							=> 'League of wins',
	'LEAGUES_NO_DELETE'						=> 'Vous ne pouvez supprimer aucune ligue. Seuls les membres de la fondation sont autorisés à le faire',
	'LEAGUES_NO_TEAM'						=> 'Cette ligue n’a pas d’équipes',
	'MEMBER'								=> 'Utilisateur',
	'MEMBER_ALL'							=> 'Tous les utilisateurs actifs de Boardmitglieder',
	'MEMBER_CONFIRM_DELETE'					=> 'Etes-vous sûr (e) de vouloir supprimer l’utilisateur électif de la Ligue de prédiction %1$s de la saison %2$s avec toutes les données (pari et classement)?',
	'MEMBER_DELETE'							=> 'Utilisateur de la ligue remove',
	'MEMBER_EXISTS'							=> 'Cet utilisateur est déjà participant à cette ligue de prédiction. ',
	'MEMBER_EXPLAIN'						=> 'Ceci est une liste de tous les utilisateurs de cette ligue. De là, vous pouvez mettre qui devrait être l’utilisateur de cette ligue. ',
	'NO_LEAGUE'								=> 'Aucune ligue donnée. ',
	'NO_LEAGUES_CREATED'					=> 'Aucune ligue n’a été créée jusqu’à présent. ',
	'NO_MATCHDAYS_KO'						=> 'Avec un tour de KO, seuls les matches doivent être saisis avant que les joueurs de la Ligue de Prévision puissent s’y joindre. ',
	'NO_MEMBERS_SELECTED'					=> 'Aucun membre n’a été sélectionné ou le membre électif n’est pas connu. ',
	'NO_SEASON'								=> 'Il n’y a pas de saison. S’il vous plaît, d’abord une saison créer. ',
	'SELECT_SEASON'							=> 'Sélection de la saison',
	'TOO_LARGE_LEAGUE'						=> 'La valeur de la ligue est trop grande. Ce ne sont que des ligues entre 1 - 99 possible. ',
	'TOO_LARGE_LEAGUE_MATCHDAYS'			=> 'Le nombre de matches est trop important. Elle doit être entre 1 et 99. ',
	'TOO_LARGE_LEAGUE_MATCHES'				=> 'Le nombre de matchs matchday est trop grand. Elle doit être comprise entre 0 et 99. ',
	'TOO_SHORT_LEAGUE_SHORT'				=> 'Le nom court de la ligue doit être long d’au moins 1 signe. ',
	'TOO_SHORT_SEASON'						=> 'Le nom de la ligue doit être long au moins 2 signes. ',
	'TOO_SMALL_LEAGUE'						=> 'La valeur de la ligue est trop petite. Ce ne sont que des ligues entre 1 et 99 possible. ',
	'TOO_SMALL_LEAGUE_MATCHDAYS'			=> 'Le nombre de matches est trop petit. Elle doit être entre  1 et 99. ',
	'TOO_SMALL_LEAGUE_MATCHES'				=> 'Le nombre de matchs matchday est trop petit. Elle doit être comprise entre 0 et 99. ',
));
