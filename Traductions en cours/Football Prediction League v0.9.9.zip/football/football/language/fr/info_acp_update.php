<?php
/**
*
* info_acp_update.php [en]
*
* @package phpBB Extension - Football Football
* @copyright (c) 2016 football (http://football.bplaced.net)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}


if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_FOOTBALL_UPDATE'					=> 'Mettre à jour la liste des matchs',
	'ACP_FOOTBALL_UPDATE_MANAGE'			=> 'Mettre à jour les listes des matchs',
	'ACP_FOOTBALL_UPDATE_MANAGE_EXPLAIN'	=> 'Vous pouvez ici mettre à jour les listes des matchs avec les données de la page de démonstration ou d’un autre site de Football. Tout d’abord, choisissez une ligue du site source qui a envoyé la mise à jour. Après avoir sélectionné la ligue de destination, vous obtenez des différences entre cette ligue et la mise à jour affichée et pouvez choisir les changements que vous voulez mettre à jour. Si vous voulez créer une nouvelle ligue, toutes les données sont transférées. , ',
	'ACP_FOOTBALL_UPDATE_MANAGEMENT'		=> 'Mettre à jour les listes des matchs',
	'ALLOW_URL_FOPEN'						=> 'Le paramètre PHP <var>allow_url_fopen</var> n’autorise pas l’accès à d’autres sites. <br />Vous devez télécharger des fichiers de mise à jour XML et les enregistrer dans root /. ',
	'CHOOSE_LEAGUES'						=> 'Sélectionner la liste des Matchs',
	'CHOOSE_OTHER_LEAGUE'					=> 'Sélectionner une autre liste de match',
	'COMPARE_UPDATE'						=> 'Comparer avec la base de données',
	'CURRENT_VALUE'							=> 'Valeur courante de la base de données',
	'DB_INSERT_SEASON'						=> '%s saison télécharger. ',
	'DB_INSERT_LEAGUE'						=> '%s ligue télécharger. ',
	'DB_INSERT_MATCHDAY'					=> '%s match télécharger. ',
	'DB_INSERT_MATCHDAYS'					=> '%s jours de match télécharger. ',
	'DB_INSERT_TEAM'						=> '%s équipe télécharger. ',
	'DB_INSERT_TEAMS'						=> '%s équipes télécharger. ',
	'DB_INSERT_MATCH'						=> '%s correspond télécharger. ',
	'DB_INSERT_MATCHES'						=> '%s correspond télécharger. ',
	'DB_UPDATE_BIT_DELIVER'					=> '%s jour de match dans la ligue avec pari dans le temps est défini. ',
	'DB_UPDATE_BIT_DELIVERIES'				=> '%s Match par match dans la ligue avec pari dans le temps est défini. ',
	'DB_UPDATE_DELIVER'						=> 'La livraison du jour de la journée %s s est nouvellement définie. ',
	'DB_UPDATE_DELIVERIES'					=> 'Les livraisons sur les jours de match %s ont été nouvellement définies. ',
	'DB_UPDATE_MATCHDAY'					=> '%s jour de la mise à jour. ',
	'DB_UPDATE_MATCHDAYS'					=> '%s Journée de match mis à jour. ',
	'DB_UPDATE_TEAM'						=> '%s équipe mise à jour. ',
	'DB_UPDATE_TEAMS'						=> '%s équipes mises à jour. ',
	'DB_UPDATE_MATCH'						=> '%s match mis à jour. ',
	'DB_UPDATE_MATCHES'						=> '%s matchs mis à jour.. ',
	'DB_UPDATE_STATUS_MATCHDAY'				=> 'Le nouveau statut est défini sur %s matchday. ',
	'DB_UPDATE_STATUS_MATCHDAYS'			=> 'Le nouveau statut a été défini sur %s matchdays. ',
	'DUPLICATE_TEAM'						=> 'Cet ID d’équipe est défini deux fois. ',
	'ERROR_OPEN_LEAGUE_XML'					=> 'Erreur! Le fichier XML de la ligue n’a pas pu être ouvert. S’il vous plaît vérifier le lien. ',
	'ERROR_OPEN_SEASON_XML'					=> 'Erreur! Le fichier XML de la saison n’a pas pu être ouvert. S’il vous plaît vérifier le lien. ',
	'ERROR_READ_LEAGUE_XML'					=> 'Erreur! Le fichier XML de la ligue n’a pas pu être lu. Bitte den Code ou mourir XML-Datei überprüfen ',
	'ERROR_READ_SEASON_XML'					=> 'Erreur! Le fichier XML de saison n’a pas pu être lu. S’il vous plaît vérifier le code. ',
	'ERROR_LOAD_LEAGUE_XML'					=> 'Erreur! Le fichier XML de la ligue n’a pas pu être lu. Veuillez vérifier le fichier %s. ',
	'ERROR_XML_CODE'						=> 'Mauvais code! Pour afficher le fichier XML, vous devez ajouter le code correct. ',
	'ERROR_XML_CREATE'						=> 'Erreur! Impossible de créer le fichier XML. ',
	'INSERT_LEAGUE'							=> 'Insérer une nouvelle ligue',
	'INSERT_MATCHDAYS'						=> 'Insérer les jours de match',
	'INSERT_MATCHES'						=> 'Insérer des correspondances',
	'INSERT_SEASON'							=> 'Insérer une nouvelle saison',
	'INSERT_TEAMS'							=> 'Insérer de nouvelles équipes',
	'LEAGUE_SHORTCUT'						=> 'raccourci de la ligue',
	'LOAD'									=> 'charger',
	'MAP_TEAMS'								=> 'Équipes de cartes',
	'MATCH_OF_GROUP'						=> 'Match sur groupe',
	'MATCHES'								=> 'Matches',
	'MISMATCH_LEAGUE_TYPE'					=> 'Leaguetype (%s) source fixture list does not fit the existing league.',
	'MISMATCH_MATCHDAYS'					=> 'Le nombre de tours (%s) de la liste des appareils source ne correspond pas à la ligue existante.',
	'MISMATCH_DB_MATCHDAYS'					=> 'Le nombre de tours (%s)  dans la base de données ne correspond pas à la ligue existante.',
	'MISMATCH_MATCHES'						=> 'Le nombre de correspondances (%s) de la liste des appareils source ne correspond pas à la ligue existante.',
	'MISMATCH_DB_MATCHES'					=> 'Le nombre de correspondances (%s) dans la base de données ne correspond pas à la ligue existante.',
	'MISMATCH_MOM'							=> 'Le nombre de matchs de la journée (%s) de la liste des appareils source ne correspond pas à la ligue existante.',
	'MISSING_TEAMS'							=> 'Les identifiants d’équipe suivants doivent encore être attribués: %s',
	'NEW_LEAGUE'							=> 'Nouvelle ligue',
	'NEW_LEAGUE_EXIST'						=> 'La nouvelle ligue %s existe déjà. ',
	'NEW_LEAGUE_EXPLAIN'					=> 'Pour une nouvelle ligue, veuillez indiquer ici le numéro de la ligue. Pour une ligue existante, ce numéro de ligue ne peut être écrasé, sinon toute ligue existante sera mise à jour. ',
	'NEW_TEAM'								=> 'Nouvelle équipe à insérer',
	'NO_DB_CHANGES'							=> 'Il n’y a pas eu de changements. ',
	'NO_DIFFERENCES'						=> 'Aucune différence trouvée. Les listes d’appareils sont identiques. ',
	'NO_XML_LEAGUE'							=> 'Aucun fichier de mise à jour trouvé sur root. ',
	'NO_XML_SEASON'							=> 'Aucune source de mise à jour trouvée. ',
	'NO_XML_ARRAY'							=> 'Erreur! Données non disponibles. S’il vous plaît répéter l’action à nouveau. ',
	'OTHER_FIELDS'							=> 'Autres champs',
	'PREDICTION_LEAGUE'						=> 'Ligue de prédiction',
	'SEASON'								=> 'Saison',
	'SELECT_EXPLAIN'						=> 'Seuls les enregistrements sélectionnés seront repris ici',
	'SHOW_UPDATE'							=> 'Afficher la nouvelle ligue',
	'SOURCE'								=> 'Source',
	'TARGET'								=> 'Cible',
	'TEAM_MAPPING'							=> 'Cartographie de l’équipe',
	'TEAM_NAME_SHORT'						=> 'Nom court',
	'TRANSFER_TEAM'							=> 'Équipe de transfert',
	'UPDATE_LEAGUE'							=> 'Mettre à jour la ligue',
	'UPDATE_MATCHDAYS'						=> 'Mettre à jour les jours de match',
	'UPDATE_MATCHES'						=> 'Mettre à jour les correspondances',
	'UPDATE_ONLY_FINAL'						=> 'Ne prend en charge que les résultats finaux',
	'UPDATE_SAME_STATUS'					=> 'Mettre à jour les résultats avec le même statut',
	'UPDATE_NEG_STATUS'						=> 'Prendre le statut négatif',
	'UPDATE_TEAMS'							=> 'Mettre à jour les équipes',
	'UPDATE_THIS'							=> 'Prendre en charge les modifications dans ce champ',
	'XML_SEASON_URL'						=> 'URL de la source de mise à jour',
	'XML_SEASON_URL_EXPLAIN'				=> 'URL vers football_xml_season.php ou localhost. En cas de localhost league_ *  les fichiers seront recherchés sur root. ',
));
