<?php
/**
*
* info_acp_seasons.php [en]
*
* @package phpBB Extension - Football Football
* @copyright (c) 2016 football (http://football.bplaced.net)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}


if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_FOOTBALL_SEASONS'					=> 'Saisons',
	'ACP_FOOTBALL_SEASONS_MANAGE'			=> 'Gérer les saisons',
	'ACP_FOOTBALL_SEASONS_MANAGE_EXPLAIN'	=> 'Ici vous pouvez administrer toutes les saisons. Vous pouvez supprimer les passes ou modifier ou créer une nouvelle saison, ainsi que modifier le nom et le pseudonyme de la saison.',
	'ACP_FOOTBALL_SEASONS_MANAGEMENT'		=> 'Gestion des saisons',
	'CREATE_SEASON'							=> 'Créer une nouvelle saison',
	'LEAGUES'								=> 'Ligues',
	'NO_SEASON'								=> 'Aucune saison donnée.',
	'NO_SEASONS_CREATED'					=> 'Aucune saison n’a été créée jusqu’a présent ',
	'PREDICTION_LEAGUE'						=> 'Ligue de prédiction',
	'SEASON'								=> 'Saison',
	'SEASON_CLOSED'							=> 'à l’unanimité',
	'SEASON_CONFIRM_DELETE'					=> 'Etes-vous sûr de vouloir supprimer la saison %1$s avec toutes les données (ligues, matches, calendriers des matchs, paris et listes de classement)?',
	'SEASON_CREATE_FAILED'					=> 'La saison n’a pas pu être créée. ',
	'SEASON_CREATED'						=> 'La saison a été créée avec succès. ',
	'SEASON_CURRENT'						=> 'Topical season',
	'SEASON_DEF'							=> 'Saisons existantes',
	'SEASON_DEF_EXPLAIN'					=> 'Ce sont des saisons qui ont été créées par vous ou un autre administrateur. Vous pouvez modifier les paramètres saisonniers ou supprimer les saisons. ',
	'SEASON_DELETE'							=> 'Supprimer la saison',
	'SEASON_DELETED'						=> 'Saison supprimée',
	'SEASON_DETAILS'						=> 'Détails de la saison',
	'SEASON_EDIT_EXPLAIN'					=> 'Ici vous pouvez travailler sur une saison existante. Vous pouvez changer son nom et le nom abrégé. ',
	'SEASON_NAME'							=> 'Nom saisonnier',
	'SEASON_NAME_EMPTY'						=> 'Le nom saisonnier est absent. Il doit être long au moins 4 signes. ',
	'SEASON_NAME_EXPLAIN'					=> 'Nom long de la saison, par exemple, "saison 2010/2011"',
	'SEASON_NAME_TAKEN'						=> 'Le nom saisonnier donné est déjà utilisé. S’il vous plaît, en sélectionne un autre. ',
	'SEASON_NUMBER'							=> 'La saison donnée doit être numériquement ( Ex: 1963-2099). S’il vous plaît, le nombre annuel, en ce que la saison se termine donner.. ',
	'SEASON_SHORT'							=> 'Saison abrégée',
	'SEASON_SHORT_EMPTY'					=> 'Le nom court de la saison est absent, elle doit être longue au moins 2 signes. ',
	'SEASON_SHORT_EXPLAIN'					=> 'Nom court de la saison qui est indiqué dans la boîte de choix. ',
	'SEASON_SHORT_TAKEN'					=> 'Le nom abrégé de la saison est déjà utilisé. S’il vous plaît, un autre sélectionne. ',
	'SEASON_TAKEN'							=> 'Cette saison existe déjà. S’il vous plaît, une autre saison sélectionne. ',
	'SEASON_UPDATE_FAILED'					=> 'Les paramètres saisonniers n’ont pas pu être mis à jour. ',
	'SEASON_UPDATED'						=> 'Mise à jour des paramètres saisonniers avec succès.. ',
	'SEASONS_NO_DELETE'						=> 'Vous pouvez supprimer aucune saison. Seuls les membres de la fondation sont autorisés à le faire',
	'SEASONS_NO_LEAGUE'						=> 'Cette saison n’a pas de ligue',
	'TOO_LARGE_SEASON'						=> 'La valeur de la saison est trop grande. Saison de 1963 - in 2099 possiblement. ',
	'TOO_SHORT_SEASON'						=> 'Le nom saisonnier doit être long d’au moins 4 signes. ',
	'TOO_SHORT_SEASON_SHORT'				=> 'Le nom abrégé de la saison doit être long d’au moins 2 signes.. ',
	'TOO_SMALL_SEASON'						=> 'La valeur de la saison est trop petite. Saison de 1963 - en 2099 peut-être.',
));
