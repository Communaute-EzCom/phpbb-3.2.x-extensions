<?php
/**
*
* info_acp_matchdays.php [en]
*
* @package phpBB Extension - Football Football
* @copyright (c) 2016 football (http://football.bplaced.net)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}


if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ACP_FOOTBALL_MATCHDAYS'					=> 'Jours de match',
	'ACP_FOOTBALL_MATCHDAYS_MANAGE'				=> 'Gérer les jours de matchs',
	'ACP_FOOTBALL_MATCHDAYS_MANAGE_EXPLAIN'		=> 'Ici, vous pouvez attribuer les jours de matchs de ligue d’une saison. Vous pouvez supprimer ceux qui sont déjà passés ou changer ou créer un nouveau jour de match, ainsi que le type, le nombre de jours de match, les victoires...',
	'ACP_FOOTBALL_MATCHDAYS_MANAGEMENT'			=> 'Gestion des jours de matchs',
	'ADD_MATCHDAY'								=> 'Jours de match de la ligue ajouter',
	'BACKWARD_DELIVERY'							=> 'Sélectionner la période',
	'BACKWARD_DELIVERY_EXPLAIN'					=> 'Période avant le début du premier jeu.',
	'CHANGE_DELIVERY'							=> 'Change Delivery',
	'CHANGE_DELIVERY_EXPLAIN'					=> 'Ici, vous pouvez fixer de nouvelles dates pour les jours de matchs à venir en fonction du premier coup d’envoi. Toutefois, il ne s’agit pas d’un transfert automatique pour les matches à venir. Avec la période 0, vous pouvez vérifier si un délai est postérieur au premier coup d’envoi et le corriger en conséquence. Si une date limite uniforme est fixée, cette fonction doit être appelée plusieurs fois avec éventuellement des périodes de temps différentes pour correspondre aux heures de coup d’envoi.',
	'DELIVERY'									=> 'délai de livraison',
	'DELIVERY_SET_TIME'							=> 'Date limite avant le début du premier match',
	'DELIVERY_NUMBER'							=> 'Remise Nr.',
	'GENERATE_MATCHDAY'							=> 'Génèrez les jours de matchs manquants ',
	'INVALID_DDAY1_DATE'						=> 'Aucune date limite valide. ',
	'INVALID_DDAY2_DATE'						=> 'Pas de 2ème échéance valide. ',
	'INVALID_DDAY3_DATE'						=> 'Pas de 3ème échéance valide. ',
	'LEAGUE'									=> 'Compétitions',
	'MATCHDAY'									=> 'Journée',
	'MATCHDAY_ADDED'							=> 'Jour de match ajouté avec succès. ',
	'MATCHDAY_CONFIRM_DELETE'					=> 'Si vous êtes sûr, que vous %1$s. Jour de match de la saison %2$s avec toutes les données (programme et paris) supprimer ?',
	'MATCHDAY_CONFIRM_REMOVE'					=> 'Êtes-vous sûr de vouloir supprimer tous les jours de matchs superflus de la saison ? %1$s avec toutes les données (programme et conseils) ?',
	'MATCHDAY_CREATE_FAILED'					=> 'Le jour du match n’a pas pu être créé. ',
	'MATCHDAY_CREATED'							=> '%1$s Le jour de match a été créé avec succès. ',
	'MATCHDAY_CURRENT'							=> 'Topical matchday',
	'MATCHDAY_DEF'								=> 'Jours de match déjà existant',
	'MATCHDAY_DEF_EXPLAIN'						=> 'Ce sont des jours de matchs qui ont été créés par vous ou par un autre administrateur. Vous pouvez modifier les paramètres de jour de match ou supprimer des jours de match. ',
	'MATCHDAY_DELETE'							=> 'Jour de match supprimer',
	'MATCHDAY_DELETED'							=> 'Supprimer les jours de matchs en trop',
	'MATCHDAY_DELIVERY'							=> 'Date limite',
	'MATCHDAY_DELIVERY_EXPLAIN'					=> 'Rendez-vous le jour de match ou les matchs suivants sont fermés et donc plus de mise n’est possible.Si la journée de match était déjà clôturée (statut 1), celle-ci peut redevenir ouverte à une date limite future. D’autres passages d’état ne sont possibles que par l’entrée ou l’extinction des résultats de ce jour de match.',
	'MATCHDAY_DELIVERY2'						=> '2ème délai ',
	'MATCHDAY_DELIVERY2_EXPLAIN'				=> 'Avec la réalisation de la première date limite, cette date est fixée comme prochaine date limite pour les prochains matches. ',
	'MATCHDAY_DELIVERY3'						=> '3ème délai',
	'MATCHDAY_DELIVERY3_EXPLAIN'				=> 'Avec l’accomplissement de la 2ème date limite, cette date est fixée comme prochaine date limite pour les prochains matchs. ',
	'MATCHDAY_DETAILS'							=> 'Données sur les jours de match',
	'MATCHDAY_EDIT_EXPLAIN'						=> 'Ici, vous pouvez retravailler un jour de match existant. Vous pouvez changer le type, le nombre de jours de match, les victoires, le nom et le nom court. ',
	'MATCHDAY_MATCHES'							=> 'Nombre de matchs de ce journée',
	'MATCHDAY_MATCHES_EXPLAIN'					=> 'Avec KO rounds l’information du nombre de matchs est obligatoire pour les autre jours de match. ',
	'MATCHDAY_NAME'								=> 'Nom de la journée',
	'MATCHDAY_NAME_DOUBLE'						=> 'Le nom du jour du match est déjà utilisé ou a été attribué deux fois. ',
	'MATCHDAY_NAME_EMPTY'						=> 'Le nom du jour du match doit être long d’au moins 3 lettres. ',
	'MATCHDAY_NUMBER'							=> 'Le jour de match donné doit être numérique (1-99). S’il vous plaît, donnez un numéro de jour de match. ',
	'MATCHDAY_STATUS'							=> 'Statut',
	'MATCHDAY_STATUS_EXPLAIN'					=> '0 = Ouverture (pari de lancement possible) <br /> 1 = plus de pari possible et toujours pas de résultats. <br /> 2 = les résultats temporaires se trouvent avant <br /> 3 = conclu, les résultats finaux sont donnés. ',
	'MATCHDAY_UPDATE_FAILED'					=> 'Les paramètres de jour de match n’ont pas pu être mis à jour. ',
	'MATCHDAY_UPDATED'							=> 'Mises à jour des paramètres de jour de match avec succès. ',
	'MATCHDAYS_CREATED'							=> '%1$s ont été créés avec succès. ',
	'MATCHDAYS_NO_DELETE'						=> 'Vous ne pouvez supprimer aucun jour de match. Seuls les administrateurs sont autorisés à le faire.',
	'MATCHDAYS_REMOVED'							=> 'Jours de matchs superflus arréter',
	'NEW_DELIVERY'								=> 'Nouvelle période',
	'NO_DELIVERIES_UPDATED'						=> 'Il n’y a pas de données de mises à jour.',
	'NO_DELIVERY'								=> 'La date limite est absente. ',
	'NO_DELIVERY2'								=> 'La 2e échéance est absente ou la 3e échéance doit être supprimée. ',
	'NO_LEAGUE'									=> 'Il n’y a pas de ligue dans la saison. %1$s. S’il vous plaît, créez d’abord une ligue dans la saison. %1$s.',
	'NO_MATCHDAYS_CREATED'						=> 'Aucun jour de match n’a été créé jusqu’à présent. ',
	'NO_MORE_MATCHDAYS'							=> 'Il n’a été ajouté aucun autre jour de match.',
	'NO_SEASON'									=> 'Il n’y a pas de saison. S’il vous plaît, créez d’abord une saison.',
	'OPEN_MATCH'								=> 'Le numéro de match. %s se trouve avant le terme facultatif pour le dépôt. Par conséquent, le délai de dépôt n’est pas autorisé.',
	'OPEN_MATCHES'								=> 'Le numéro de. %s se trouve avant le terme facultatif pour le dépôt. Par conséquent, le délai de dépôt n’est pas autorisé.',
	'PREDICTION_LEAGUE'							=> 'Prediction Ligue',
	'REMOVE_MATCHDAYS'							=> 'Supprimer les jours de matchs superflus',
	'SEASON'									=> 'Saison',
	'SELECT_LEAGUE'								=> 'Sélectionner une ligue',
	'SHOW_DELIVERY'								=> 'Afficher les délais',
	'TOO_LARGE_MATCHES'							=> 'Le nombre de matchs par jour est trop important. ',
	'TOO_SMALL_DELIVERY2'						=> 'La 2e échéance ne peut être antérieure à la 1re échéance. ',
	'TOO_SMALL_DELIVERY3'						=> 'La 3ème date limite ne peut être antérieure à la 2ème date limite.',
	'TOO_SMALL_MATCHES'							=> 'Le nombre de jours de matchs est trop petit. ',
	'UPDATE_DELIVER'							=> '%s Données de production sont mises à jour.',
	'UPDATE_DELIVERIES'							=> '%s mises à jour',
	'UPDATE_DELIVERY'							=> 'Nouvelles distributions',
	'UPDATE_DELIVERY_EXPLAIN'					=> 'Sélectionnez l’ensemble de données dont le délai de sortie doit être réinitialisé. Les délais de réalisation marqués en rouge sont postérieurs à la date de livraison nouvellement calculée.',
));
