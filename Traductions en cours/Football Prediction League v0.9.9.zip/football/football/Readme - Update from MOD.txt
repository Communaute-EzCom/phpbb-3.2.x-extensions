Follow the phpBB instruction to the convert from 3.0 to 3.1.
Don't remove football MOD permissions, custom profile fields and football tables in database.
Please remove recursive the "football MOD Version 0.9.3" ACP Modules in ACP-SYSTEM-MODUL MANAGEMENT.

Unzip Football Prediction League extension in folder ext/
Activate the Football Prediction League extension in ACP.
