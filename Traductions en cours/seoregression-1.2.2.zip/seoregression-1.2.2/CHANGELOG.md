# Changelog

## 1.2.2 - 28-08-2018
- Prise en charge du fichier de configuration de l’extension USU
- Correction d'un problème ne permettant pas de traiter les forums sans ID qui ne sont réécrits au format "répertoire virtuel" (issue #1)
- Amélioration du code

## 1.2.1 - 05-05-2018
- Prise en charge de la version française des URL
- Prise en charge des URL d'anciennes versions de phpBB SEO
- [Code] Gestion des réécritures statiques (= sans ID)

## 1.2.0 - 28-08-2017
- Meilleure prise en charge des URL contenant des faux positifs
- Meilleure prise en charge des URL contenant des éléments de pagination

## 1.1.0 - 25-08-2017
- Révision intégrale du code

## 1.0.0 - 07-01-2017

- Première version de l'extension
