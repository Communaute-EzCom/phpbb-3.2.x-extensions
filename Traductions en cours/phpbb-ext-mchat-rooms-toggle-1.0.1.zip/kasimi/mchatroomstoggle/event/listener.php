<?php

/**
 *
 * mChat Rooms Toggle. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018 kasimi - https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatroomstoggle\event;

use phpbb\event\data;
use phpbb\extension\manager;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/** @var manager */
	protected $ext_manager;

	/**
	 * @param manager $ext_manager
	 */
	public function __construct(
		manager $ext_manager
	)
	{
		$this->ext_manager = $ext_manager;
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents()
	{
		return [
			'core.user_setup'	=> 'user_setup',
		];
	}

	/**
	 * @param data $event
	 */
	public function user_setup(data $event)
	{
		if ($this->ext_manager->is_enabled('kasimi/mchatrooms'))
		{
			$event['lang_set_ext'] = array_merge($event['lang_set_ext'], [[
				'ext_name' => 'kasimi/mchatroomstoggle',
				'lang_set' => 'common',
			]]);
		}
	}
}
