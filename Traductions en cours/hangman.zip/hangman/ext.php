<?php
/*
*
* @package Hangman game
* @author dmzx (www.dmzx-web.net)
* @copyright (c) 2015 by dmzx (www.dmzx-web.net)
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

namespace dmzx\hangman;

/**
* @ignore
*/

class ext extends \phpbb\extension\base
{
}
