<?php

/**
 *
 * mChat Broadcast Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatbroadcast\controller;

use dmzx\mchat\core\log;
use kasimi\mchatbroadcast\ext;
use kasimi\mchatbroadcast\includes\broadcasts;
use phpbb\auth\auth;
use phpbb\exception\http_exception;
use phpbb\request\request_interface;
use Symfony\Component\HttpFoundation\JsonResponse;

class broadcast
{
	/** @var auth */
	protected $auth;

	/** @var request_interface */
	protected $request;

	/** @var broadcasts */
	protected $broadcasts;

	/** @var log */
	protected $mchat_log;

	/**
	 * @param auth				$auth
	 * @param request_interface	$request
	 * @param broadcasts		$broadcasts
	 * @param log				$mchat_log
	 */
	public function __construct(
		auth $auth,
		request_interface $request,
		broadcasts $broadcasts,
		log $mchat_log = null
	)
	{
		$this->auth				= $auth;
		$this->request			= $request;
		$this->broadcasts		= $broadcasts;
		$this->mchat_log		= $mchat_log;
	}

	/**
	 * @param int $broadcast_id
	 * @return JsonResponse
	 */
	public function broadcast($broadcast_id)
	{
		if (!$this->request->is_ajax() || !$this->auth->acl_get('u_mchat_broadcast'))
		{
			throw new http_exception(403, 'NO_AUTH_OPERATION');
		}

		if ($this->mchat_log === null)
		{
			throw new http_exception(404, 'EXTENSION_DISABLED', ['mChat']);
		}

		$broadcast = $this->broadcasts->get_broadcast($broadcast_id);

		if (!$broadcast)
		{
			throw new http_exception(404, 'URL_NOT_FOUND');
		}

		$this->mchat_log->add_log(ext::MCHAT_LOG_TYPE_BROADCAST_NAME, $broadcast_id);

		return new JsonResponse([
			'broadcast'		=> true,
			'broadcast_url'	=> $this->broadcasts->fix_broadcast_url($broadcast['url']),
		]);
	}
}
