<?php

/**
 *
 * mChat Broadcast Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatbroadcast\controller;

use kasimi\mchatbroadcast\includes\broadcasts;
use phpbb\json_response;
use phpbb\language\language;
use phpbb\log\log_interface;
use phpbb\request\request_interface;
use phpbb\template\template;
use phpbb\user;

class acp extends module_base
{
	/** @var user */
	protected $user;

	/** @var language */
	protected $lang;

	/** @var request_interface */
	protected $request;

	/** @var template */
	protected $template;

	/** @var log_interface */
	protected $log;

	/** @var broadcasts */
	protected $broadcasts;

	/**
	 * @param user				$user
	 * @param language			$lang
	 * @param request_interface	$request
	 * @param template			$template
	 * @param log_interface		$log
	 * @param broadcasts		$broadcasts
	 */
	public function __construct(
		user $user,
		language $lang,
		request_interface $request,
		template $template,
		log_interface $log,
	 	broadcasts $broadcasts
	)
	{
		$this->user			= $user;
		$this->lang			= $lang;
		$this->request		= $request;
		$this->template		= $template;
		$this->log			= $log;
		$this->broadcasts	= $broadcasts;
	}

	/**
	 * @param string $id
	 * @param string $mode
	 * @param string $u_action
	 */
	public function main($id, $mode, $u_action)
	{
		$ext_name = 'kasimi/mchatbroadcast';

		$this->tpl_name = 'acp_main_body';
		$this->page_title = 'MCHAT_BROADCAST';

		$this->lang->add_lang('acp', $ext_name);

		$action	= $this->request->variable('action', '');
		$broadcast_id = $this->request->variable('broadcast', 0);

		add_form_key($ext_name);

		switch ($action)
		{
			case 'add':

				$this->tpl_name = 'acp_add_edit_body';

				$this->template->assign_vars([
					'ACTION'	=> 'ADD',
					'U_BACK'	=> $u_action,
					'U_ACTION'	=> $u_action . '&amp;action=create',
				]);

				return;

			break;

			case 'create':

				if (!check_form_key($ext_name))
				{
					trigger_error($this->lang->lang('FORM_INVALID') . adm_back_link($u_action), E_USER_WARNING);
				}

				$broadcast = $this->get_broadcast_from_request($this->broadcasts->get_next_broadcast_id());

				if ($this->broadcasts->add_broadcast($broadcast))
				{
					$this->log('LOG_MCHAT_BROADCAST_CREATED', $broadcast);

					trigger_error($this->lang->lang('MCHAT_BROADCAST_CREATED') . adm_back_link($u_action));
				}

			break;

			case 'edit':

				$this->tpl_name = 'acp_add_edit_body';

				$broadcast = $this->broadcasts->get_broadcast($broadcast_id);

				if (!$broadcast)
				{
					trigger_error('URL_NOT_FOUND');
				}

				$this->template->assign_vars([
					'BROADCAST_TITLE'	=> $broadcast['title'],
					'BROADCAST_URL'		=> $broadcast['url'],
					'ACTION'			=> 'EDIT',
					'U_BACK'			=> $u_action,
					'U_ACTION'			=> $u_action . '&amp;action=modify&amp;broadcast=' . $broadcast_id,
				]);

				return;

			break;

			case 'modify':

				if (!check_form_key($ext_name))
				{
					trigger_error($this->lang->lang('FORM_INVALID') . adm_back_link($u_action), E_USER_WARNING);
				}

				$broadcast = $this->get_broadcast_from_request($broadcast_id);

				if ($this->broadcasts->set_broadcast($broadcast))
				{
					$this->log('LOG_MCHAT_BROADCAST_MODIFIED', $broadcast);

					trigger_error($this->lang->lang('MCHAT_BROADCAST_MODIFIED') . adm_back_link($u_action));
				}

			break;

			case 'up':
			case 'down':

				if (!check_link_hash($this->request->variable('hash', ''), 'mchatbroadcast'))
				{
					trigger_error($this->lang->lang('FORM_INVALID') . adm_back_link($u_action), E_USER_WARNING);
				}

				$move_result = $this->broadcasts->move_broadcast($broadcast_id, $action == 'up' ? -1 : 1);

				if ($this->request->is_ajax())
				{
					(new json_response())->send([
						'success' => $move_result,
					]);
				}

			break;

			case 'delete':

				if (confirm_box(true))
				{
					$delete_broadcast = $this->broadcasts->delete_broadcast($broadcast_id);

					if ($delete_broadcast)
					{
						$this->log('LOG_MCHAT_BROADCAST_DELETED', $delete_broadcast);
					}

					if ($this->request->is_ajax())
					{
						(new json_response())->send([
							'MESSAGE_TITLE'	=> $this->lang->lang('INFORMATION'),
							'MESSAGE_TEXT'	=> $this->lang->lang('MCHAT_BROADCAST_DELETED'),
							'REFRESH_DATA'	=> ['time' => 3],
						]);
					}
				}
				else
				{
					confirm_box(false, $this->lang->lang('CONFIRM_OPERATION'), build_hidden_fields([
						'action'		=> 'delete',
						'broadcast_id'	=> $broadcast_id,
					]));
				}

			break;
		}

		$broadcasts = $this->broadcasts->get_broadcasts();

		$hash = generate_link_hash('mchatbroadcast');

		foreach ($broadcasts as $broadcast)
		{
			$this->template->assign_block_vars('broadcasts', [
				'TITLE'				=> $broadcast['title'],
				'URL'				=> $broadcast['url'],
				'U_MOVE_UP'			=> $u_action . '&amp;action=up&amp;broadcast=' . $broadcast['id'] . '&amp;hash=' . $hash,
				'U_MOVE_DOWN'		=> $u_action . '&amp;action=down&amp;broadcast=' . $broadcast['id'] . '&amp;hash=' . $hash,
				'U_EDIT'			=> $u_action . '&amp;action=edit&amp;broadcast=' . $broadcast['id'],
				'U_DELETE'			=> $u_action . '&amp;action=delete&amp;broadcast=' . $broadcast['id'],
			]);
		}

		$this->template->assign_var('U_ACTION', $u_action . '&amp;action=add');
	}

	/**
	 * @param int $broadcast_id
	 * @return array
	 */
	protected function get_broadcast_from_request($broadcast_id)
	{
		return [
			'id'	=> $broadcast_id,
			'title'	=> $this->request->variable('broadcast_title', '', true),
			'url'	=> $this->request->variable('broadcast_url', ''),
		];
	}

	/**
	 * @param string $log_operation
	 * @param array $broadcast
	 */
	protected function log($log_operation, array $broadcast)
	{
		$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, $log_operation, false, [$broadcast['title']]);
	}
}
