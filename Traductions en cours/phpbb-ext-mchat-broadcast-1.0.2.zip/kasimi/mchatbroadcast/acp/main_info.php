<?php

/**
 *
 * mChat Broadcast Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatbroadcast\acp;

class main_info
{
	/**
	 * @return array
	 */
	public function module()
	{
		return [
			'filename'	=> '\kasimi\mchatbroadcast\acp\main_module',
			'title'		=> 'ACP_MCHAT_BROADCAST_TITLE',
			'modes'		=> [
				'broadcast' => [
					'title'		=> 'ACP_MCHAT_BROADCAST_TITLE',
					'auth'		=> 'ext_kasimi/mchatbroadcast && acl_a_mchat',
					'cat'		=> ['ACP_MCHAT_BROADCAST_TITLE'],
				],
			],
		];
	}
}
