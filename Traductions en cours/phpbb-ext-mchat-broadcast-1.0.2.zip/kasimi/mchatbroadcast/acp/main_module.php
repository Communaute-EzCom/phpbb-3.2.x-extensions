<?php

/**
 *
 * mChat Broadcast Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatbroadcast\acp;

class main_module extends base
{
	/**
	 * @return string
	 */
	protected function get_controller_service_id()
	{
		return 'kasimi.mchatbroadcast.controller.acp';
	}
}
