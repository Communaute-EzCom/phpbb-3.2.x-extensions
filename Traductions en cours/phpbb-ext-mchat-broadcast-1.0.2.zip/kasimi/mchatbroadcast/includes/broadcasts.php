<?php

/**
 *
 * mChat Broadcast Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatbroadcast\includes;

use dmzx\mchat\core\settings;

class broadcasts
{
	/** @var string */
	protected $root_path;

	/** @var settings */
	protected $mchat_settings;

	/**
	 * @param string	$root_path
	 * @param settings	$mchat_settings
	 */
	public function __construct(
		$root_path,
		settings $mchat_settings = null

	)
	{
		$this->root_path		= $root_path;
		$this->mchat_settings	= $mchat_settings;
	}

	/**
	 * @return bool
	 */
	public function is_mchat_enabled()
	{
		return $this->mchat_settings !== null;
	}

	/**
	 * @param int $broadcast_id
	 * @param array $broadcasts
	 * @return bool|int
	 */
	public function find_index($broadcast_id, array $broadcasts)
	{
		foreach ($broadcasts as $i => $broadcast)
		{
			if ($broadcast['id'] == $broadcast_id)
			{
				return $i;
			}
		}

		return false;
	}

	/**
	 * @param array $broadcast
	 * @return bool|array
	 */
	public function add_broadcast(array $broadcast)
	{
		$broadcasts = $this->get_broadcasts();

		if ($this->find_index($broadcast['id'], $broadcasts) !== false)
		{
			return false;
		}

		$broadcasts[] = $broadcast;

		$this->set_broadcasts($broadcasts);

		return $broadcast;
	}

	/**
	 * @param int $broadcast_id
	 * @return bool|array
	 */
	public function delete_broadcast($broadcast_id)
	{
		$broadcasts = $this->get_broadcasts();

		$index = $this->find_index($broadcast_id, $broadcasts);

		if ($index === false)
		{
			return false;
		}

		$deleted_broadcast = $broadcasts[$index];

		unset($broadcasts[$index]);

		$this->set_broadcasts($broadcasts);

		return $deleted_broadcast;
	}

	/**
	 * @param int $broadcast_id
	 * @return bool|array
	 */
	public function get_broadcast($broadcast_id)
	{
		$broadcasts = $this->get_broadcasts();

		$index = $this->find_index($broadcast_id, $broadcasts);

		return $index === false ? false : $broadcasts[$index];
	}

	/**
	 * @return array
	 */
	public function get_broadcasts()
	{
		return array_values(@json_decode($this->mchat_settings->cfg('mchat_broadcasts'), true)) ?: [];
	}

	/**
	 * @param array $broadcast
	 * @return bool|array
	 */
	public function set_broadcast(array $broadcast)
	{
		$broadcasts = $this->get_broadcasts();

		$index = $this->find_index($broadcast['id'], $broadcasts);

		if ($index === false)
		{
			return false;
		}

		$broadcasts[$index] = $broadcast;

		$this->set_broadcasts($broadcasts);

		return $broadcast;
	}

	/**
	 * @param array $broadcasts
	 */
	public function set_broadcasts(array $broadcasts)
	{
		$this->mchat_settings->set_cfg('mchat_broadcasts', @json_encode(array_values($broadcasts)) ?: []);
	}

	/**
	 * @param int $broadcast_id
	 * @param int $offset
	 * @return bool|array
	 */
	public function move_broadcast($broadcast_id, $offset)
	{
		$broadcasts = $this->get_broadcasts();

		$index = $this->find_index($broadcast_id, $broadcasts);

		if ($index === false)
		{
			return false;
		}

		$broadcast = $broadcasts[$index];

		$temp = array_splice($broadcasts, $index, 1);

		array_splice($broadcasts, max(0, $index + $offset), 0, $temp);

		$this->set_broadcasts($broadcasts);

		return $broadcast;
	}

	/**
	 * @return int
	 */
	public function get_next_broadcast_id()
	{
		$broadcasts = $this->get_broadcasts();

		$next_id = 0;

		foreach ($broadcasts as $broadcast)
		{
			$next_id = max($broadcast['id'], $next_id);
		}

		return $next_id + 1;
	}

	/**
	 * @param string $broadcast_url
	 * @return string
	 */
	public function fix_broadcast_url($broadcast_url)
	{
		if (strpos($broadcast_url, 'http') !== 0)
		{
			return $this->root_path . ltrim($broadcast_url, '/');
		}

		return $broadcast_url;
	}

	/**
	 * @return string
	 */
	public static function get_empty_broadcasts()
	{
		return json_encode([]);
	}
}
