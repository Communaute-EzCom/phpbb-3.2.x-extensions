<?php

/**
 *
 * mChat Broadcast Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatbroadcast\migrations;

use kasimi\mchatbroadcast\includes\broadcasts;
use phpbb\db\migration\container_aware_migration;
use phpbb\db\migration\exception;
use phpbb\db\migration\tool\module;

class m1_initial_data extends container_aware_migration
{
	/**
	 * @return array
	 */
	public static function depends_on()
	{
		return ['\phpbb\db\migration\data\v320\v320'];
	}

	/**
	 * @return array
	 */
	public function update_data()
	{
		return [
			['config_text.add', ['mchat_broadcasts', broadcasts::get_empty_broadcasts()]],
			['permission.add', ['u_mchat_broadcast', true]],

			['custom', [[$this, 'add_mchat_category']]],

			['module.add', [
				'acp',
				'ACP_CAT_MCHAT',
				[
					'module_basename'	=> '\kasimi\mchatbroadcast\acp\main_module',
					'modes'				=> ['broadcast'],
				],
			]],
		];
	}

	/**
	 * @throws exception
	 */
	public function add_mchat_category()
	{
		/** @var module $module */
		$module = $this->container->get('migrator.tool.module');

		if (!$module->exists('acp', 'ACP_CAT_DOT_MODS', 'ACP_CAT_MCHAT'))
		{
			$module->add('acp', 'ACP_CAT_DOT_MODS', 'ACP_CAT_MCHAT');
		}
	}
}
