<?php

/**
 *
 * mChat Broadcast Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatbroadcast\event;

use dmzx\mchat\core\settings;
use kasimi\mchatbroadcast\ext;
use kasimi\mchatbroadcast\includes\broadcasts;
use phpbb\auth\auth;
use phpbb\controller\helper;
use phpbb\event\data;
use phpbb\language\language;
use phpbb\template\template;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/** @var language */
	protected $lang;

	/** @var auth */
	protected $auth;

	/** @var helper */
	protected $helper;

	/** @var template */
	protected $template;

	/** @var broadcasts */
	protected $broadcasts;

	/** @var settings */
	protected $mchat_settings;

	/** @var boolean */
	protected $mchat_live_updates;

	/**
	 * @param language		$lang
	 * @param auth			$auth
	 * @param helper		$helper
	 * @param template		$template
	 * @param broadcasts	$broadcasts
	 * @param settings		$mchat_settings
	 */
	public function __construct(
		language $lang,
		auth $auth,
		helper $helper,
		template $template,
		broadcasts $broadcasts,
		settings $mchat_settings = null
	)
	{
		$this->lang				= $lang;
		$this->auth				= $auth;
		$this->helper			= $helper;
		$this->template			= $template;
		$this->broadcasts		= $broadcasts;
		$this->mchat_settings	= $mchat_settings;
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents()
	{
		return [
			'dmzx.mchat.global_text_settings_modify'				=> 'mchat_global_text_settings_modify',
			'dmzx.mchat.log_types_init'								=> 'mchat_log_types_init',
			'dmzx.mchat.render_page_after'							=> 'mchat_render_page_after',
			'dmzx.mchat.action_refresh_before'						=> 'mchat_action_refresh_before',
			'dmzx.mchat.action_refresh_get_messages_before'			=> 'mchat_action_refresh_get_messages_before',
			'dmzx.mchat.acp_globalsettings_modify_template_data'	=> ['acp_add_lang', 10],
			'core.permissions'										=> ['permissions', -10],
		];
	}

	/**
	 * @param data $event
	 */
	public function mchat_global_text_settings_modify(data $event)
	{
		$event['global_text_settings'] = array_merge($event['global_text_settings'], [
			'mchat_broadcasts' => ['default' => broadcasts::get_empty_broadcasts()],
		]);
	}

	/**
	 * @param data $event
	 */
	public function mchat_log_types_init(data $event)
	{
		$this->mchat_live_updates = $this->mchat_settings->cfg('mchat_live_updates');
		$this->mchat_settings->set_cfg('mchat_live_updates', true, true);

		$log_types = $event['log_types'];
		$log_types[ext::MCHAT_LOG_TYPE_BROADCAST_ID] = ext::MCHAT_LOG_TYPE_BROADCAST_NAME;
		$event['log_types'] = $log_types;
	}

	/**
	 *
	 */
	public function mchat_render_page_after()
	{
		$this->lang->add_lang('common', 'kasimi/mchatbroadcast');

		if ($this->auth->acl_get('u_mchat_broadcast'))
		{
			$broadcasts = $this->broadcasts->get_broadcasts();

			foreach ($broadcasts as $broadcast)
			{
				$this->template->assign_block_vars('broadcasts', [
					'TITLE'			=> $broadcast['title'],
					'U_BROADCAST'	=> $this->helper->route('kasimi_mchatbroadcast_broadcast', ['broadcast_id' => $broadcast['id']], false),
				]);
			}
		}
	}

	/**
	 * @param data $event
	 */
	public function mchat_action_refresh_before(data $event)
	{
		$event['need_log_update'] = true;
	}

	/**
	 * @param data $event
	 */
	public function mchat_action_refresh_get_messages_before(data $event)
	{
		$log_edit_del_ids = $event['log_edit_del_ids'];

		// If multiple broadcasts were sent since the last refresh, play the latest
		$broadcast_id = end($log_edit_del_ids[ext::MCHAT_LOG_TYPE_BROADCAST_NAME]);

		if ($broadcast_id)
		{
			$broadcast = $this->broadcasts->get_broadcast($broadcast_id);

			if ($broadcast)
			{
				$event['response'] = array_merge($event['response'], [
					'broadcast'		=> true,
					'broadcast_url'	=> $this->broadcasts->fix_broadcast_url($broadcast['url']),
				]);
			}
		}

		// Don't handle edited & deleted messages
		if (!$this->mchat_live_updates)
		{
			$log_edit_del_ids['edit'] = [];
			$log_edit_del_ids['del'] = [];

			$event['log_edit_del_ids'] = $log_edit_del_ids;
		}
	}

	/**
	 *
	 */
	public function acp_add_lang()
	{
		$this->lang->add_lang('acp', 'kasimi/mchatbroadcast');
	}

	/**
	 * @param data $event
	 */
	public function permissions(data $event)
	{
		if (isset($event['categories']['mchat']))
		{
			$event['permissions'] = array_merge($event['permissions'], [
				'u_mchat_broadcast' => [
					'lang'	=> 'ACL_U_MCHAT_BROADCAST',
					'cat'	=> 'mchat',
				],
			]);
		}
	}
}
