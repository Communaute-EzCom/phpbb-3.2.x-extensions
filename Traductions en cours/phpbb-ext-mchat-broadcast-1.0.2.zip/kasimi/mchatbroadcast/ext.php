<?php

/**
 *
 * mChat Broadcast Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatbroadcast;

use phpbb\extension\base;

class ext extends base
{
	const MCHAT_LOG_TYPE_BROADCAST_ID	= 24;
	const MCHAT_LOG_TYPE_BROADCAST_NAME	= 'broadcast';

	/**
	 * @return bool
	 */
	public function is_enableable()
	{
		return phpbb_version_compare(PHPBB_VERSION, '3.2.0', '>=') && phpbb_version_compare(PHP_VERSION, '5.4.7', '>=');
	}
}
