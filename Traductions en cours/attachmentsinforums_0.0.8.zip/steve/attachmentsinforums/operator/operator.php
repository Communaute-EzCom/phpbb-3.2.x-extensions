<?php
/*
 *
 * Topic/Post Attachments on Index and View Forum pages. An extension for the phpBB Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\attachmentsinforums\operator;

use Symfony\Component\DependencyInjection\ContainerInterface;

/**
* 
*/
class operator implements operator_interface
{
	/** @var \phpbb\auth\auth */
	protected $auth;
	
	/** @var \phpbb\config\config */
	protected $config;
	
	/** @var ContainerInterface */
	protected $container;
	
	/** @var \phpbb\db\driver\driver */
	protected $db;

	/** @var \phpbb\language\language */
	protected $language;

	/** @var \phpbb\template\template */	
	protected $template;
	
	/** @var \phpbb\user */
	protected $user;

	/** @var string phpEx */	
	protected $php_ext;
	
	/** @var string phpBB root path */	
	protected $root_path;
	
	/**
	 * Constructor
	 * 
	 */
	public function __construct(
		\phpbb\auth\auth $auth,
		\phpbb\config\config $config,
		ContainerInterface $container,
		\phpbb\db\driver\driver_interface $db,
		\phpbb\language\language $language,	
		\phpbb\template\template $template,
		\phpbb\user $user,
		$php_ext,
		$root_path)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->container = $container;
		$this->db = $db;
		$this->lang = $language;
		$this->template = $template;
		$this->user = $user;
		$this->php_ext = $php_ext;
		$this->root_path = $root_path;
	}

	public function aif_every_where($forum_id, $topic_id, $forum_attach_index, $attach_in_forums_enabled)
	{
		$this->user->add_lang_ext('steve/attachmentsinforums', 'common');
		
		$display_attach_in_forum = (($this->auth->acl_get('u_download') 
		&& $this->auth->acl_get('f_download', $forum_id)) && $this->user->optionget('viewimg')
		&& $forum_attach_index && $attach_in_forums_enabled);

		if (!isset($forum_id) || !isset($topic_id) || !$display_attach_in_forum)
		{
			return false;
		}
		
		$attach_limit = (isset($this->config['attach_in_forums_limit'])) ? (int) $this->config['attach_in_forums_limit'] : (int) 10;
		$attach_in_forum_types = explode("|", strtolower($this->config['attach_in_forum_types']));
		$attach_in_forum_types = str_replace(' ', '', $attach_in_forum_types);
		
		$sql_where = ($topic_id) ? 'p.topic_id = ' . (int) $topic_id : 'p.forum_id = ' . (int) $forum_id;
		
		$sql = 'SELECT a.*, p.forum_id, p.post_id, p.topic_id, p.post_subject
			FROM ' . ATTACHMENTS_TABLE . ' a LEFT JOIN ' . POSTS_TABLE . ' p ON a.post_msg_id = p.post_id
			WHERE ' . $sql_where . '
				AND ' . $this->db->sql_in_set('a.extension', $attach_in_forum_types) . '
				AND p.post_visibility = ' . ITEM_APPROVED . '
				AND a.in_message = 0
				AND a.is_orphan = 0
			ORDER BY a.filetime DESC';
		$result = $this->db->sql_query_limit($sql, (int) $attach_limit);
		
		$attachments = array();
		while ($row = $this->db->sql_fetchrow($result))
		{
			$attachments[] = $row;
		}
		$this->db->sql_freeresult($result);

		if (sizeof($attachments))
		{
			foreach ($attachments as $attachment)
			{
				$extensions = array();
				if (!extension_allowed($forum_id, $attachment['extension'], $extensions))
				{
					continue;
				}
				
				$attach_id = $attachment['attach_id'];
				$post_id = $attachment['post_msg_id'];
				
				$download_url = append_sid("{$this->root_path}download/file.{$this->php_ext}?id=$attach_id");
				
				$image_src = false;
				$image_extensions = array('gif', 'jpg', 'jpeg', 'png', 'svg', 'tga', 'tif', 'tiff');
				$archive = false;
				
				$filename = utf8_basename($attachment['real_filename']);

				if (in_array($attachment['extension'], $image_extensions, true))
				{
					$image_src = true;
					$thumbnail = ($attachment['thumbnail']) ? '&amp;t=1' : '';
					$img_src = $download_url . $thumbnail;
				}
				else
				{
					$archive = true;
					//path_helper
					$archive_img = generate_board_url() . '/ext/steve/attachmentsinforums/images/' . $this->config['attach_in_forum_archive_img'];
				}
				
				$attachment_row = array(
					'ALT'			=> $filename,
					'ARCHIVE'		=> $archive ? $download_url : '',
					'FILE_SRC'		=> ($image_src) ? $img_src : $archive_img,
					'ARCHIVE_TITLE'	=> sprintf($this->lang->lang('ATTACH_IN_FORUMS_DOWNLOAD'), $filename),
					'TITLE'			=> sprintf($this->lang->lang('AIF_VIEW_POST'), censor_text($attachment['post_subject'])),					
					'VIEW_POST'		=> append_sid("{$this->root_path}viewtopic.{$this->php_ext}?p=$post_id#p$post_id"),
				);
	
				$this->template->assign_block_vars('attachment', $attachment_row);
			}
			unset($attachments);
					
			$this->template->assign_vars(array(
				'NOWRAP'			=> (!empty($this->config['attach_in_forum_nowrap'])) ? true : false,
				'DISPLAIY_IN_ROWS'	=> (!empty($this->config['attach_in_forum_categories'])) ? true : false,
			));		
		}
		return (bool) $attach_in_forums_enabled;
	}
}
