<?php
/*
 *
 * Topic/Post Attachments on Index and View Forum pages. An extension for the phpBB Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\attachmentsinforums\operator;

/**
* Interface
*/
interface operator_interface
{
	/**
	* 
	* @access public
	*/			
	public function aif_every_where($forum_id, $topic_id, $forum_attach_index, $attach_in_forums_enabled);
}
