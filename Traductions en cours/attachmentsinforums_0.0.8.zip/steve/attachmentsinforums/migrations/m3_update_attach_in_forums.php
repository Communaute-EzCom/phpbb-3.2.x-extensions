<?php
/**
 *
 * Topic/Post Attachments on Index and View Forum pages. An extension for the phpBB Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\attachmentsinforums\migrations;

/**
* update migration
*/

class m3_update_attach_in_forums extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array(
			'\steve\attachmentsinforums\migrations\m2_update_attach_in_forums',
		);
	}
	
	public function update_data()
	{
		return array(
			array('config.remove', array('attach_in_forum_ids')),
			array('config.update', array('attach_in_forums_version', '0.0.7-dev')),
			array('config.add', array('attach_in_forum_archive_img', 'folder-icon.png')),
			array('config.add', array('attach_in_forum_nowrap', false)),
		);
	}
	
	public function revert_schema()
	{
		return array(
			'drop_columns'	=> array(
				$this->table_prefix . 'forums'		=> array(
					'forum_attach_type',
				),
			),	
		);
	}
}
