<?php
/**
 *
 * Topic/Post Attachments on Index and View Forum pages. An extension for the phpBB Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\attachmentsinforums\migrations;

class install_attach_in_forums extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return isset($this->config['attach_in_forums']);
	}
	
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v320\v320');
	}

	public function update_data()
	{
		return array(
			array('config.add', array('attach_in_forums', '0.0.5-dev')),
			array('config.add', array('attach_in_forums_enabled', 1)),
			array('config.add', array('attach_in_forums_limit', 10)),
			array('config.add', array('attach_in_forum_ids', '')),//not yet
			array('config.add', array('attach_in_forum_types', 'gif, png, jpg, jpeg, svg, tga, tif, tiff')),			
		);
	}
	
	public function update_schema()
	{		
		return array(
			'add_columns'	=> array(
				$this->table_prefix . 'forums'	=> array(
					'forum_attach_index'		=> array('BOOL', 1),
					'forum_attach_type'			=> array('VCHAR:255', ''),//not yet
				),
			),
		);		
	}
	
	public function revert_schema()
	{
		return array(
			'drop_columns'	=> array(
				$this->table_prefix . 'forums'		=> array(	
					'forum_attach_index',
					'forum_attach_type',//not yet
				),
			),	
		);
	}			
}
