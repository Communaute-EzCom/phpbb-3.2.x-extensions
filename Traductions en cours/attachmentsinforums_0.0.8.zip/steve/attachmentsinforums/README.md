# Topic/Post Attachments on Index and View Forum pages

## Installation

Copy the extension to phpBB/ext/steve/attachmentsinforums

Go to "ACP" > "Customise" > "Extensions" and enable the "Topic/Post Attachments on Index and View Forum pages" extension.

## License

[GPLv2](license.txt)
