<?php
/**
 *
 * Topic/Post Attachments on Index and View Forum pages. An extension for the phpBB Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_ATTACH_IN_FORUMS_ALLOW'				=> 'Display latest attachments on Index and View Forum pages',
	'ACP_ATTACH_IN_FORUM_CATEGORY'				=> 'Display latest attachments in forum categories',
	'ACP_ATTACH_IN_FORUMS_MAX'					=> 'Maximum number of attachments on Index and View Forum pages',
	'ACP_ATTACH_IN_FORUMS_NOWRAP'				=> 'Display attachments in-line or wrapped',
	'ACP_ATTACH_IN_FORUMS_TITLE'				=> 'Attachments on Index and View Forum pages',
	'ACP_ATTACH_IN_FORUMS_TYPES'				=> 'File Types allowed on Index and View Forum pages',
	'ACP_ATTACH_IN_FORUMS_TYPES_EXPLAIN'		=> 'Separate file Types with <strong>|</strong><br /> eg. gif|jpg|png',
	'ACP_ATTACHIN_FORUM_ARCHIVE_IMG'			=> 'Archive folder image',
	'ACP_ATTACHIN_FORUM_ARCHIVE_IMG_EXPLAIN'	=> 'Uploaded Image to: <strong>ext/steve/attachinforums/images</strong>',
	'ACP_ATTACH_IN_TOPICS'						=> 'Display latest attachments in topics',
	'ACP_MAX_IMAGE_SIZE'						=> 'Maximum image dimensions',
	'ACP_MAX_IMAGE_SIZE_EXPLAIN'				=> 'Maximum size of image attachments. Set both values to 0px by 0px to disable.',
	'AIF_COPYRIGHT'								=> '<a href="http://www.steven-clark.online/phpBB3-Extensions/">phpBB Attachments on Index</a>',
	'ATTACH_IN_FORUMS_DOWNLOAD'					=> 'Download: %1s',
	'AIF_VIEW_POST'								=> 'View post: %1s',
	'AIF_VERSION'								=> '0.0.8-dev',
));
