<?php
/**
 *
 * Topic/Post Attachments on Index and View Forum pages. An extension for the phpBB Forum Software package.
 * @author Steve <http://www.steven-clark.online/phpBB3-Extensions/>
 * @copyright (c) phpBB Limited <https://www.phpbb.com>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace steve\attachmentsinforums\event;

/**
 * @ignore
 */
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Topic/Post Attachments on Index and View Forum pages Event ACP listener.
 */
class acp_listener implements EventSubscriberInterface
{
	/** @var \phpbb\config\config */
	protected $config;
	
	/** @var \phpbb\controller\helper */
	protected $helper;

	/** @var \phpbb\language\language */
	protected $language;
	
	/** @var \phpbb\request\request */
	protected $request;
	
	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/**
	 * Constructor
	 */
	public function __construct(		
		\phpbb\config\config $config,
		\phpbb\controller\helper $helper,
		\phpbb\language\language $language,
		\phpbb\request\request $request,
		\phpbb\template\template $template,
		\phpbb\user $user)
	{	
		$this->config = $config;
		$this->helper = $helper;
		$this->lang = $language;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;		
	}
	
	static public function getSubscribedEvents()
	{
		return array(
			'core.acp_attachments_config_edit_add'		=> 'aif_attachments_config_edit_add',
			'core.acp_manage_forums_request_data'		=> 'aif_forums_request_data',
			'core.acp_manage_forums_initialise_data'	=> 'aif_forums_initialise_data',
			'core.acp_manage_forums_display_form'		=> 'aif_forums_display_form',
		);
	}

	public function aif_attachments_config_edit_add($event)
	{
		if ($event['mode'] == 'attach')
		{
			$this->user->add_lang_ext('steve/attachmentsinforums', 'common');
			$display_vars = $event['display_vars'];	
			$config_vars = array(
				'legend_attach_in_forums'	=> 'ACP_ATTACH_IN_FORUMS_TITLE',
				'attach_in_forums_enabled' 		=> array('lang' => 'ACP_ATTACH_IN_FORUMS_ALLOW', 	'validate' => 'bool', 		'type' => 'radio:yes_no','explain' => true),
				'attach_in_forums_limit' 		=> array('lang' => 'ACP_ATTACH_IN_FORUMS_MAX', 		'validate' => 'int:0:999', 	'type' => 'number:0:999', 'explain' => false),
				'attach_in_forum_types'			=> array('lang' => 'ACP_ATTACH_IN_FORUMS_TYPES', 	'validate' => 'string', 	'type' => 'text:30:255', 'explain' => true),
				'attach_in_forum_categories' 	=> array('lang' => 'ACP_ATTACH_IN_FORUM_CATEGORY', 	'validate' => 'bool', 		'type' => 'radio:yes_no','explain' => false),
				'attach_in_topics' 				=> array('lang' => 'ACP_ATTACH_IN_TOPICS', 			'validate' => 'bool', 		'type' => 'radio:yes_no','explain' => false),
				'attach_in_forum_nowrap' 		=> array('lang' => 'ACP_ATTACH_IN_FORUMS_NOWRAP', 	'validate' => 'bool', 		'type' => 'radio:yes_no','explain' => false),		
				'attach_in_forum_archive_img'	=> array('lang' => 'ACP_ATTACHIN_FORUM_ARCHIVE_IMG','validate' => 'string', 	'type' => 'text:30:255', 'explain' => true),	
			);
			$display_vars['vars'] = phpbb_insert_config_array($display_vars['vars'], $config_vars, array('before' => 'legend2'));
			
			$event['display_vars'] = $display_vars;
		}
	}

	public function aif_forums_request_data($event)
	{
		$forum_data = $event['forum_data'];
		$forum_data['forum_attach_index'] = $this->request->variable('forum_attach_index', 0);
		$event['forum_data'] = $forum_data;
	}

	public function aif_forums_initialise_data($event)
	{
 		$forum_data = $event['forum_data'];
		if ($event['action'] == 'add' && !$event['update'])
		{
			$forum_data['forum_attach_index'] = true;
		}
		$event['forum_data'] = $forum_data;
	}

	public function aif_forums_display_form($event)
	{
		$this->user->add_lang_ext('steve/attachmentsinforums', 'common');
		
		$forum_data = $event['forum_data'];
		$template_data = $event['template_data'];
		$template_data = array_merge($template_data, array(
			'S_FORUM_ATTACH_INDEX'		=> $forum_data['forum_attach_index'],
		));
		$event['template_data'] = $template_data;
	}	
}
