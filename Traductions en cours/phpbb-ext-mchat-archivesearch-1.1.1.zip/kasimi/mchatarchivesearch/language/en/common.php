<?php

/**
 *
 * mChat Archive Search. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters for use
// ’ » “ ” …

$lang = array_merge($lang, [
	'MCHAT_ARCHIVE_SEARCH'					=> 'Search archive…',
	'MCHAT_ARCHIVE_SEARCH_DATE'				=> 'Filter by date…',
	// %1 = number of search results, %2 = search keywords
	'MCHAT_ARCHIVE_SEARCH_RESULTS'			=> [
		1 => 'Search found <strong>%1$d</strong> match for: <strong>%2$s</strong>',
		2 => 'Search found <strong>%1$d</strong> matches for: <strong>%2$s</strong>',
	],
	// %1 = number of search results, %2 = search keywords, %3 = date
	'MCHAT_ARCHIVE_SEARCH_RESULTS_DATE'		=> [
		1 => 'Search found <strong>%1$d</strong> match on <strong>%3$s</strong> for: <strong>%2$s</strong>',
		2 => 'Search found <strong>%1$d</strong> matches on <strong>%3$s</strong> for: <strong>%2$s</strong>',
	],
	'MCHAT_ARCHIVE_SEARCH_JUMP'				=> 'Jump to date…',
	// Available languages: ca-ES,cs-CZ,da-DK,de-DE,en-GB,en-US,es-ES,fi-FI,fr-FR,it-IT,ja-JP,ko-KR,nl-NL,oc-FR,pl-PL,pt-BR,ru-RU,sk-SK,sv-SE,th-TH,tr-TR,ug-CN,vi-VN,zh-CN
	'MCHAT_ARCHIVE_SEARCH_DATE_PICKER_LANG'	=> 'en-GB',
]);
