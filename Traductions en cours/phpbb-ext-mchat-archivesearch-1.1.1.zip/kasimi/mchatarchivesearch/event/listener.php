<?php

/**
 *
 * mChat Archive Search. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018, kasimi, https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatarchivesearch\event;

use dmzx\mchat\core\functions;
use phpbb\auth\auth;
use phpbb\db\driver\driver_interface;
use phpbb\event\data;
use phpbb\language\language;
use phpbb\request\request_interface;
use phpbb\template\template;
use phpbb\user;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/** @var array */
	const DATE_FORMAT = [
		'php'	=> 'Y-n-j',
		'mysql'	=> '%Y-%c-%e',
	];

	/** @var user */
	protected $user;

	/** @var language */
	protected $lang;

	/** @var auth */
	protected $auth;

	/** @var request_interface */
	protected $request;

	/** @var driver_interface */
	protected $db;

	/** @var template */
	protected $template;

	/** @var functions */
	protected $functions;

	/** @var bool */
	protected $modify_total_message_count = true;

	/** @var string */
	protected $page;

	/** @var array */
	protected $request_vars;

	/** @var array */
	protected $template_data = [];

	/**
	 * @param user				$user
	 * @param language			$lang
	 * @param auth				$auth
	 * @param request_interface	$request
	 * @param driver_interface	$db
	 * @param template			$template
	 * @param functions			$functions
	 */
	public function __construct(
		user $user,
		language $lang,
		auth $auth,
		request_interface $request,
		driver_interface $db,
		template $template,
		functions $functions = null
	)
	{
		$this->user			= $user;
		$this->lang			= $lang;
		$this->auth			= $auth;
		$this->request		= $request;
		$this->db			= $db;
		$this->template		= $template;
		$this->functions	= $functions;
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents()
	{
		$priority = -50;

		return [
			'dmzx.mchat.render_page_before'					=> ['mchat_render_page_before',					$priority],
			'dmzx.mchat.render_page_get_messages_before'	=> ['mchat_render_page_get_messages_before',	$priority],
			'dmzx.mchat.get_messages_modify_sql'			=> ['mchat_get_messages_modify_sql', 			$priority],
			'dmzx.mchat.total_message_count_modify_sql'		=> ['mchat_total_message_count_modify_sql',		$priority],
			'dmzx.mchat.render_page_pagination_before'		=> ['mchat_render_page_pagination_before',		$priority],
			'dmzx.mchat.render_page_after'					=> ['mchat_render_page_after', 					$priority],
		];
	}

	/**
	 * @param data $event
	 */
	public function mchat_render_page_before(data $event)
	{
		$this->page = $event['page'];

		if ($this->page === 'archive')
		{
			$this->lang->add_lang('common', 'kasimi/mchatarchivesearch');

			$this->template_data['MCHAT_ARCHIVE_SEARCH_KEYWORDS_ALLOWED'] = $this->auth->acl_get('u_search');

			$this->request_vars = [
				'keywords'	=> $this->template_data['MCHAT_ARCHIVE_SEARCH_KEYWORDS_ALLOWED'] ? $this->request->variable('keywords', '', true) : '',
				'date'		=> $this->request->variable('date', ''),
			];
		}
	}

	/**
	 * @param data $event
	 */
	public function mchat_render_page_get_messages_before(data $event)
	{
		if ($this->page === 'archive')
		{
			$this->template_data['MCHAT_ARCHIVE_SEARCH_JUMPTO'] = true;

			if ($this->request_vars['keywords'] === '' && $this->request_vars['date'])
			{
				$date_timestamp = $this->date_to_timestamp_at_midnight(self::DATE_FORMAT['php'], $this->request_vars['date']);

				if ($date_timestamp)
				{
					$this->modify_total_message_count = false;

					$sql_where_jump_to_id = 'm.message_time >= ' . (int) $date_timestamp;
					$sql_order_by = 'm.message_id ASC';
					$num_subsequent_messages = max(0, $this->functions->mchat_total_message_count($sql_where_jump_to_id, $sql_order_by) - 1);
					$event['start'] = (int) floor($num_subsequent_messages / $event['limit']) * $event['limit'];
					$this->template_data['MCHAT_ARCHIVE_SEARCH_CURRENT_DATE'] = $this->request_vars['date'];

					$this->modify_total_message_count = true;
				}
			}
		}
	}

	/**
	 * @param data $event
	 */
	public function mchat_get_messages_modify_sql(data $event)
	{
		$this->sql_append_keywords($event);
	}

	/**
	 * @param data $event
	 */
	public function mchat_total_message_count_modify_sql(data $event)
	{
		if ($this->modify_total_message_count)
		{
			if (!empty($this->template_data['MCHAT_ARCHIVE_SEARCH_KEYWORDS_ALLOWED']) || !empty($this->template_data['MCHAT_ARCHIVE_SEARCH_JUMPTO']))
			{
				$this->assign_message_dates_tree_template_data($event['sql_array']);
			}

			$this->sql_append_keywords($event);
		}
	}

	/**
	 * @param array $sql_array
	 */
	protected function assign_message_dates_tree_template_data(array $sql_array)
	{
		if ($this->page === 'archive' && !isset($this->template_data['MCHAT_ARCHIVE_SEARCH_START_DATE']))
		{
			$user_utc_offset_seconds = $this->user->create_datetime()->format('Z');
			$user_utc_offset_hh_mm = ($user_utc_offset_seconds < 0 ? '-' : '+') . gmdate('H:i', abs($user_utc_offset_seconds));

			switch ($this->db->get_sql_layer())
			{
				case 'mysql':
				case 'mysqli':
				case 'mysql4':
					$sql_array['SELECT'] = "DATE_FORMAT(CONVERT_TZ(FROM_UNIXTIME(m.message_time), @@session.time_zone, '" . $this->db->sql_escape($user_utc_offset_hh_mm) . "'), '" . self::DATE_FORMAT['mysql'] . "') AS message_date";
				break;

				case 'mssql':
				case 'mssql_odbc':
				case 'mssqlnative':
				case 'oracle':
				case 'postgres':
				case 'sqlite3':
				default:
					return;
				break;
			}

			$sql_array['ORDER_BY'] = 'message_time ASC';

			$sql = $this->db->sql_build_query('SELECT_DISTINCT', $sql_array);
			$result = $this->db->sql_query($sql);
			$rows = $this->db->sql_fetchrowset($result);
			$this->db->sql_freeresult($result);

			$message_dates = array_column($rows, 'message_date');

			$this->template_data = array_merge($this->template_data, [
				'MCHAT_ARCHIVE_SEARCH_START_DATE'	=> reset($message_dates),
				'MCHAT_ARCHIVE_SEARCH_END_DATE'		=> end($message_dates),
				'MCHAT_ARCHIVE_SEARCH_DATES'		=> $this->build_tree_from_dates($message_dates, self::DATE_FORMAT['php'], explode('-', self::DATE_FORMAT['php'])),
			]);
		}
	}

	/**
	 * @param data $event
	 */
	protected function sql_append_keywords(data $event)
	{
		if ($this->page === 'archive' && $this->request_vars['keywords'] !== '')
		{
			$sql_array = $event['sql_array'];

			if ($sql_array['WHERE'])
			{
				$sql_array['WHERE'] = '(' . $sql_array['WHERE'] . ') AND ';
			}

			$sql_array['WHERE'] = $sql_array['WHERE'] . 'm.message ' . $this->db->sql_like_expression($this->db->get_any_char() . $this->request_vars['keywords'] . $this->db->get_any_char());

			$date_timestamp = $this->date_to_timestamp_at_midnight(self::DATE_FORMAT['php'], $this->request_vars['date']);

			if ($date_timestamp)
			{
				$date_end_timestamp = strtotime('+1 day', $date_timestamp);
				$sql_array['WHERE'] = $sql_array['WHERE'] . ' AND m.message_time >= ' . (int) $date_timestamp . ' AND m.message_time < ' . (int) $date_end_timestamp;
			}

			$event['sql_array'] = $sql_array;
		}
	}

	/**
	 * @param data $event
	 */
	public function mchat_render_page_pagination_before(data $event)
	{
		if ($this->page === 'archive')
		{
			$this->template_data['S_MCHAT_ARCHIVE_SEARCH_ACTION'] = $event['archive_url'];

			if ($this->request_vars['keywords'] !== '')
			{
				$event['archive_url'] = append_sid($event['archive_url'], array_filter($this->request_vars));

				$keywords_link = '<a href="' . $event['archive_url'] . '">' . $this->request_vars['keywords'] . '</a>';

				$date_timestamp = $this->date_to_timestamp_at_midnight(self::DATE_FORMAT['php'], $this->request_vars['date']);

				if ($date_timestamp)
				{
					$date = $this->user->format_date($date_timestamp, $this->lang->lang('DATE_FORMAT'));
					$this->template_data['MCHAT_ARCHIVE_SEARCH_CURRENT_DATE'] = $this->request_vars['date'];
					$this->template_data['MCHAT_TOTAL_MESSAGES'] = $this->lang->lang('MCHAT_ARCHIVE_SEARCH_RESULTS_DATE', $event['total_messages'], $keywords_link, $date);
				}
				else
				{
					$this->template_data['MCHAT_TOTAL_MESSAGES'] = $this->lang->lang('MCHAT_ARCHIVE_SEARCH_RESULTS', $event['total_messages'], $keywords_link);
				}
			}
		}
	}

	/**
	 * @param data $event
	 */
	public function mchat_render_page_after(data $event)
	{
		if ($this->page === 'archive')
		{
			if (isset($event['template_data']))
			{
				$event['template_data'] = array_merge($event['template_data'], $this->template_data);
			}
			else
			{
				// TODO Remove this to require at least mChat 2.1.1
				$this->template->assign_vars($this->template_data);
			}
		}
	}

	/**
	 * @param string $format
	 * @param string $date
	 * @return int
	 */
	protected function date_to_timestamp_at_midnight($format, $date)
	{
		$date = \DateTime::createFromFormat($format, $date);
		return $date ? (int) $date->setTime(0, 0)->format('U') : 0;
	}

	/**
	 * @param array $dates
	 * @param string $in_date_format
	 * @param array $out_date_formats
	 * @return array
	 */
	protected function build_tree_from_dates($dates, $in_date_format, $out_date_formats)
	{
		$tree = [];

		$num_formats = sizeof($out_date_formats);

		foreach ($dates as $date)
		{
			$datetime = \DateTime::createFromFormat($in_date_format, $date);

			$node = &$tree;

			for ($i = 0; $i < $num_formats - 1; $i++)
			{
				$node = &$node[$datetime->format($out_date_formats[$i])];
			}

			$node[] = $datetime->format($out_date_formats[$num_formats - 1]);
		}

		return $tree;
	}
}
