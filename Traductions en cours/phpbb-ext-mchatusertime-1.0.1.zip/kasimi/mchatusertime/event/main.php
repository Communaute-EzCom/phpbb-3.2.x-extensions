<?php

/**
 *
 * mChat User Time Addon. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2018 kasimi - https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatusertime\event;

use phpbb\event\data;
use phpbb\language\language;
use phpbb\user;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class main implements EventSubscriberInterface
{
	/** @var user */
	protected $user;

	/** @var language */
	protected $lang;

	/**
	 * @param user		$user
	 * @param language	$lang
	 */
	public function __construct(
		user $user,
		language $lang
	)
	{
		$this->user		= $user;
		$this->lang		= $lang;
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents()
	{
		return [
			'dmzx.mchat.ucp_settings_modify'			=> 'ucp_settings_modify',
			'dmzx.mchat.get_messages_modify_sql'		=> 'get_messages_modify_sql',
			'dmzx.mchat.message_modify_template_data'	=> ['message_modify_template_data', -100],
		];
	}

	/**
	 *
	 */
	public function ucp_settings_modify()
	{
		$this->lang->add_lang('common', 'kasimi/mchatusertime');
	}

	/**
	 * @param data $event
	 */
	public function get_messages_modify_sql($event)
	{
		$sql_array = $event['sql_array'];
		$sql_array['SELECT'] .= ', u.user_timezone';
		$event['sql_array'] = $sql_array;
	}

	/**
	 * @param data $event
	 */
	public function message_modify_template_data($event)
	{
		$author_id = $event['row']['user_id'];

		if ($this->user->data['user_id'] == $author_id || $this->user->data['user_id'] == ANONYMOUS || $author_id == ANONYMOUS || !$event['row']['user_timezone'])
		{
			return;
		}

		/** @var \DateTimeZone $user_tz */
		$user_tz = $this->user->timezone;
		$author_tz = $this->create_timezone($event['row']['user_timezone']);
		$this->user->timezone = $author_tz;
		$origin_offset = $user_tz->getOffset($this->user->create_datetime('@' . $event['row']['message_time'], $user_tz));
		$remote_offset = $author_tz->getOffset($this->user->create_datetime('@' . $event['row']['message_time'], $author_tz));
		$difference = $this->get_timezone_difference($origin_offset, $remote_offset);

		$event['template_data'] = array_merge($event['template_data'], [
			'MCHAT_USERNAME_FULL' => $this->lang->lang_array('MCHAT_USER_TIME', [
				abs($difference),
				$event['template_data']['MCHAT_USERNAME_FULL'],
				$this->pretty_print($difference),
				$this->user->format_date($event['row']['message_time']),
				str_replace('_', ' ', $author_tz->getName()),
				($remote_offset < 0 ? '-' : '+') . gmdate('H:i', abs($remote_offset)),
			]),
		]);

		$this->user->timezone = $user_tz;
	}

	/**
	 * @param int $origin_offset
	 * @param int $remote_offset
	 * @return int
	 */
	protected function get_timezone_difference($origin_offset, $remote_offset)
	{
		$diff_minutes = abs($origin_offset - $remote_offset);
		$sign = $origin_offset < $remote_offset ? +1 : -1;
		return $sign * $diff_minutes / 3600;
	}

	/**
	 * @param string $timezone
	 * @return \DateTimeZone
	 */
	protected function create_timezone($timezone)
	{
		try
		{
			return new \DateTimeZone($timezone);
		}
		catch (\Exception $e)
		{
			return new \DateTimeZone('UTC');
		}
	}

	/**
	 * @param float $number
	 * @return string
	 */
	protected function pretty_print($number)
	{
		$sign = $number > 0 ? '+' : ($number < 0 ? '-' : '±');

		$floor = abs($number > 0 ? floor($number) : ceil($number));

		$decimal = ltrim(abs($number) - $floor, '0');

		$decimals = [
			'.25'	=> '¼',
			'.5'	=> '½',
			'.75'	=> '¾',
		];

		if (isset($decimals[$decimal]))
		{
			$floor = $floor ?: '';
			$decimal = $decimals[$decimal];
		}

		return $sign . $floor . $decimal;
	}
}
