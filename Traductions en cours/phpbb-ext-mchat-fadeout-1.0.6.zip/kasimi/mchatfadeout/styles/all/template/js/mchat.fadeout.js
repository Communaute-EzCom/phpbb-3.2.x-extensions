/**
 *
 * @package phpBB Extension - mChat Fadeout
 * @copyright (c) 2018 kasimi - https://kasimi.net
 * @license proprietary
 *
 */

jQuery(function($) {

	"use strict";

	if (typeof mChat !== 'object') {
		return;
	}

	var $fadeOut = $('.mchat-fade-out');
	var fadeOutMinMessages = $fadeOut.data('fadeout-min-messages');
	var fadeOutLocationClass = $fadeOut.data('fadeout-location-class');

	if (typeof mChat.registerNavItem === 'function') {
		mChat.registerNavItem('fadeout', true, function(isEnabled) {
			$fadeOut.toggleClass(fadeOutLocationClass, isEnabled);
		});
	}

	var updateClass = function(count) {
		$fadeOut.toggleClass(fadeOutLocationClass, mChat.cached('messages').children().length + count >= fadeOutMinMessages);
	};

	$(mChat).on({
		mchat_add_message_animate_before: function() {
			updateClass(1);
		},
		mchat_delete_message_before: function() {
			updateClass(-1);
		},
		mchat_rooms_show_after: function() {
			updateClass(0);
		}
	});

});
