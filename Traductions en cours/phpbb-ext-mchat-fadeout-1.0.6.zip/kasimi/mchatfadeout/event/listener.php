<?php

/**
 *
 * @package phpBB Extension - mChat Fadeout
 * @copyright (c) 2018 kasimi - https://kasimi.net
 * @license proprietary
 *
 */

namespace kasimi\mchatfadeout\event;

use phpbb\language\language;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/** @var language */
	protected $lang;

	/**
	 * Constructor
	 *
	 * @param language $lang
	 */
	public function __construct(
		language $lang
	)
	{
		$this->lang = $lang;
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents()
	{
		return [
			'dmzx.mchat.ucp_settings_modify' => 'add_language',
		];
	}

	/**
	 *
	 */
	public function add_language()
	{
		$this->lang->add_lang('common', 'kasimi/mchatfadeout');
	}
}
