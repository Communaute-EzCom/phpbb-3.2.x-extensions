<?php
/**
*
* @package hjw calendar Extension
* @copyright (c) 2019 hjw
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
* Traduction par Benjamin Larue
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

// Common
$lang = array_merge($lang, array(
	'ACP_BIRTHDAY_ON_CALENDAR'				=> 'Afficher les anniversaires dans l’agenda ?',
	'ACP_CALENDAR_ALL'						=> 'Tous',
	'ACP_CALENDAR_ALLOWED_0'				=> 'Non autorisé',
	'ACP_CALENDAR_ALLOWED_1'				=> 'Autorisé',
	'ACP_CALENDAR_ANNIVERSARY'				=> 'Anniversaire',
	'ACP_CALENDAR_APPOINTMENT_CREATE'		=> 'Créer un évènement',
	'ACP_CALENDAR_APPOINTMENT_DESCRIPTION'	=> 'Description',
	'ACP_CALENDAR_APPOINTMENT_LINK'			=> 'Lien',
    'ACP_CALENDAR_APPOINTMENT_LIST'			=> 'Liste des évènements',
    'ACP_CALENDAR_APPOINTMENT_LIST_TEXT'	=> 'Ces évènements seront affichés dans l’agenda avec la couleur spécifiée.</p> 
												<p>Si l’année est spécifiée dans l’évènement, il sera affiché uniquement l’année en question, sauf si vous cochez la case "Anniversaire". Alors l’évènement sera affiché chaque année avec le nombre des années passées.',
	'ACP_CALENDAR_APPOINTMENT_NAME'			=> 'Nom de l’évènement',
	'ACP_CALENDAR_BIG'						=> 'Surligné',
	'ACP_CALENDAR_CHANGE'					=> 'Cliquez pour changer',
	'ACP_CALENDAR_COLOR'					=> 'Couleur',
	'ACP_CALENDAR_COLOR_B'					=> 'Couleur de fond',
	'ACP_CALENDAR_DATE'						=> 'Date (D.M.)',
	'ACP_CALENDAR_DATE_FROM'				=> 'Du (D.M.YYYY)',
	'ACP_CALENDAR_DATE_TO'					=> 'Au (D.M.YYYY)',
	'ACP_CALENDAR_DISPLAYOPTIONS'			=> 'Options d’affichage',
	'ACP_CALENDAR_EASTER_DAYS'				=> 'Les jours avant/suivant Pâques',
	'ACP_CALENDAR_ENTRIES'					=> 'Évènements dans l’agenda',
	'ACP_CALENDAR_EVENT'					=> 'Type d’évènement',
	'ACP_CALENDAR_EVENT_CONFIG'				=> 'Configuration',
	'ACP_CALENDAR_EVENT_CREATE'				=> 'Créer un type d’évènement',
	'ACP_CALENDAR_EVENT_SETTINGS'			=> 'Gérer les évènements',
	'ACP_CALENDAR_EVENT_SETTINGS_TEXT'		=> 'Les types correspondants d’évènements associés seront affichés dans l’agenda dans les 
												couleurs appropriées et dans l’ordre montré ici.',
	'ACP_CALENDAR_EVENTS'					=> 'Évènements',
	'ACP_FOOTBALL_ON_CALENDAR'				=> 'Afficher les matchs de football dans l’agenda ?',
	'ACP_CALENDAR_ON_INDEX_OFF'				=> 'L’aperçu des dates peut-il être caché pour aujourd’hui ?',
	'ACP_CALENDAR_FOR_GUESTS'				=> 'Afficher l’agenda pour les invités ?',
	'ACP_CALENDAR_FORUM_SETTINGS'			=> 'Paramètres des forums',
	'ACP_CALENDAR_FORUM_SETTINGS_TEXT'		=> 'Les évènements ne peuvent être créés que dans les forums apparaissant en vert.',
	'ACP_CALENDAR_SETTINGS'					=> 'Paramètres',
	'ACP_CALENDAR_INSTRUCTIONS'				=> 'Instructions',
	'ACP_CALENDAR_INSTRUCTIONS_TEXT'		=> 'Aperçu de la semaine ou prochains évènements ?',
	'ACP_CALENDAR_INSTRUCTIONS_TEXT_0'		=> 'Affichage de la semaine',
	'ACP_CALENDAR_INSTRUCTIONS_TEXT_1'		=> 'Il y a deux façons de créer des entrées dans l’agenda.</p>
												<p>Si d’une part l’utilisation de l’agenda est autorisée dans ce forum particulier et d’autre part qu’au moins un type d’évènement a déjà été créé, vous aurez la possibilité de créer un évènement directement lors de la création d’un nouveau sujet, sous la fenêtre de saisie du texte.
												Le nom apparaîtra alors dans l’agenda et ne devra pas être trop long pour y figurer en entier. Le titre du sujet sera alors affiché quand vous pointerez la souris dans l’agenda. Vous pourrez également y intégrer des informations supplémentaires. Un click sur le titre de l’évènement et vous atteindrez le sujet lié à cet évènement. La saisie d’une date de fin est facultative et à utiliser dans les évènements durant plusieurs jours.</p>
												<p>Lorsque vous créez un type d’évènement, vous pourrez choisir si vous voulez gérer la liste des participants. Dans ce cas, cette liste sera à compléter par les participants une fois que vous aurez créé l’évènement. Les invités et les robots ne seront pas affichés.</p>
												<p>Seuls seront affichés les évènements liés à des forums auquel le membre a la permission d’accès.</p>
												La seconde manière de créer des entrées dans l’agenda depuis le PCA. Vous pourrez d’ailleurs créer des évènements pointant vers un sujet spécifique.',
	'ACP_CALENDAR_LEGEND_DISPLAY'			=> 'Afficher la légende de l’évènement dans l’agenda ?',
	'ACP_CALENDAR_NAME'						=> 'Nom',
	'ACP_CALENDAR_NOTIFY'					=> 'Notifier le membre en cas de nouvel évènement ou de modification de l’agenda ?',
	'ACP_CALENDAR_NOTIFY_PARTICIPATING'		=> 'Notifier le membre en cas de nouveau participant ou de changement des participants ?',
	'ACP_CALENDAR_NUMBER_OF_WEEKS'			=> 'Nombre de semaines ?',
	'ACP_CALENDAR_NUMBER_PARTICIPATING'		=> 'Afficher le nombre de participants dans l’agenda ?',
	'ACP_CALENDAR_ONLY_PARTICIPANT'			=> 'Seulement les participants',
	'ACP_CALENDAR_ONLY_AUTOR'				=> 'Seulement l’auteur',
	'ACP_CALENDAR_SHOW'						=> 'Voir le jour de la semaine ?',
	'ACP_CALENDAR_SPECIAL_DAYS'				=> 'Jours spéciaux',
	'ACP_CALENDAR_SPECIAL_DAY_CREATE'		=> 'Créer le jour spécial',
	'ACP_CALENDAR_SPECIAL_DAYS_TEXT'		=> 'Les jours de fêtes mobiles sont basés sur le dimanche de Pâques.</p>
												<p>Les jours qui précèdent Pâques seront entrés avec une valeur négative.',
	'ACP_CALENDAR_PARTICIPANT'				=> 'Créer une liste de participants ?',
	'ACP_CALENDAR_PARTICIPANTS_NAME'		=> 'Afficher le nom des participants en passant la souris sur l’évènement dans l’agenda ?',
	'ACP_CALENDAR_0'						=> 'Non',
	'ACP_CALENDAR_1'						=> 'Oui',
	'ACP_WEEKBLOCK_TEMPLATE_0'				=> 'Pas affiché',
	'ACP_WEEKBLOCK_TEMPLATE_1'				=> 'Avant l’entête',
	'ACP_WEEKBLOCK_TEMPLATE_2'				=> 'Avant la navigation',
	'ACP_WEEKBLOCK_TEMPLATE_3'				=> 'Avant le pied de page',
	'ACP_WEEK_NEXT_1'						=> 'Aperçu des semaines',
	'ACP_WEEK_NEXT_2'						=> 'Prochains évènements',
	'ACP_WEEK_NEXT_3'						=> 'Les deux',
	'ACP_CALENDAR_EVENT_CONFIG'				=> 'Configuration',
	'ACP_CALENDAR_EVENT_LIST'				=> 'Liste des évènements manuels',
	'ACP_CALENDAR_FORUMS_CONFIG'			=> 'Configuration des forums',
	'ACP_CALENDAR_ONLY_FIRST_POST'			=> 'Afficher les évènements uniquement dans le premier message d’un sujet',
	'ACP_CALENDAR_RESET' 					=> 'Réinitialisation',
	'ACP_CALENDAR_SEND' 					=> 'Soumettre',
	'ACP_CALENDAR_SPECIAL_DAY'				=> 'Jour spécial',
	'ACP_CALENDAR_TAB_0'					=> 'Avant la boîte de message',
	'ACP_CALENDAR_TAB_1'					=> 'Dans un onglet sous la boîte de message',
	'ACP_CALENDAR_TAB_TEXT'					=> 'Afficher les réglages de l’agenda',
	'ACP_CALENDAR_TITLE'					=> 'Agenda',
	'ACP_CALENDAR_TO_DISPLAY'				=> 'voir',
	'ACP_CALENDAR_VERSION'					=> ' Version ',
	'ACP_CALENDAR_WEEK_DISPLAY'				=> 'Afficher le numéro de la semaine (correct uniquement si la semaine commence par un lundi)',
	'ACP_CALENDAR_WEEK_START'				=> 'Premier jour de la semaine',
));