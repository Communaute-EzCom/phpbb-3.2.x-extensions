<?php
/**
*
* @package hjw calendar Extension
* @copyright (c) 2019 hjw
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
* Traduction par Benjamin Larue
*
*/

/**
* DO NOT CHANGE
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

// Bot settings

$lang = array_merge($lang, array(
	'BIRTHDAY'					=> 'Anniversaire',
	'CALENDAR'					=> 'Agenda',
	'CALENDAR_ASK'				=> 'Voulez-vous participer à cet évènement ?',
	'CALENDAR_CANCELED'			=> 'Indique l’annulation de l’évènement',
	'CALENDAR_COMMENTS'			=> 'Commentaires',
	'CALENDAR_DATE'				=> 'Enregistrée',
	'CALENDAR_DATE_FORM'		=> 'j/m/Y',
	'CALENDAR_ENTER'			=> 'Enregistrer',
	'CALENDAR_ENTRY'			=> 'Entrée dans l’agenda',
	'CALENDAR_EVENT'			=> 'Type',
	'CALENDAR_EVENT_NAME'		=> 'Titre de l’évènement',
	'CALENDAR_EVERY_WEEKDAY'	=> 'tous les',
	'CALENDAR_FROM'				=> 'Du',
	'CALENDAR_GROUP'			=> 'Nombre total (1 si vous êtes seul)',
	'CALENDAR_MB'				=> 'Peut-être',
	'CALENDAR_NO'				=> 'Non',
	'CALENDAR_NO_ITEMS'			=> 'Aucune réponse jusqu’à maintenant',
	'CALENDAR_NUMBER'			=> 'Nombre',
	'CALENDAR_PART'				=> 'Participant',
	'CALENDAR_RESET'			=> 'Remise à zéro',
	'CALENDAR_REPEAT'			=> 'Évèmenent récurrent',
	'CALENDAR_REPEAT_DAYS_1'	=> 'Répéter tous les',
	'CALENDAR_REPEAT_DAYS_2'	=> ' jours',
	'CALENDAR_REPEAT_MONTH_1'	=> 'Même jour, tous les',
	'CALENDAR_REPEAT_MONTH_2'	=> 'mois',
	'CALENDAR_SEND'				=> 'Soumettre',
	'CALENDAR_TITLE'			=> 'Agenda',
	'CALENDAR_T_OFF'			=> 'Cacher les évènement pour aujourd’hui ',
	'CALENDAR_T_ON'				=> 'Afficher les évènements',
	'CALENDAR_TO'				=> 'Au (ne pas remplir si une seule journée)',
	'CALENDAR_UPCOMING_DATES'	=> 'Dates à venir',
	'CALENDAR_USERS'			=> 'Nom',
	'CALENDAR_WEEKLY_OVERVIEW'	=> 'Aperçu de la semaine',
	'CALENDAR_YES'				=> 'Oui',
	'PARTICIPANTS_LIST'			=> 'Liste des participants',
	'VIEWING_CALENDAR'			=> 'Regarde l’agenda',
));